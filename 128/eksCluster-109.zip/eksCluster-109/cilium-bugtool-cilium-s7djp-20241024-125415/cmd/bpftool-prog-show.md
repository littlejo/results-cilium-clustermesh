35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:15+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:15+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:16+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:16+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:16+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:16+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:20+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
485: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
486: sched_cls  name tail_handle_ipv4  tag b4d1f8b1f13c5787  gpl
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
487: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
510: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 153
511: sched_cls  name __send_drop_notify  tag f623ed456b3cdc34  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 154
512: sched_cls  name cil_from_container  tag 17179d9d2ed030d1  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 155
513: sched_cls  name tail_handle_arp  tag eaaa6a783e6362e6  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 156
514: sched_cls  name tail_handle_ipv4  tag bc4fe96d6cbd6499  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 157
515: sched_cls  name tail_ipv4_ct_ingress  tag bd8b0a5955f28557  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 158
516: sched_cls  name tail_ipv4_ct_egress  tag 942fed3cb3b03de5  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 159
517: sched_cls  name handle_policy  tag 4a4c5a9f504c2634  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 160
518: sched_cls  name tail_ipv4_to_endpoint  tag 686fb71e92371a7d  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 161
520: sched_cls  name tail_handle_ipv4_cont  tag 31379a3084f2ae3d  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 163
521: sched_cls  name __send_drop_notify  tag 82acac4a716611e8  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 165
522: sched_cls  name tail_handle_arp  tag 39fb2c95721cc276  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 166
523: sched_cls  name tail_ipv4_ct_ingress  tag 60e883fb9494fd05  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 167
524: sched_cls  name tail_ipv4_to_endpoint  tag 64731361fb01ead9  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,110,40,37,38
	btf_id 168
525: sched_cls  name tail_handle_ipv4  tag 234d6e860d27b60c  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 169
526: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 170
527: sched_cls  name handle_policy  tag 880858e3b34d34bf  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 171
529: sched_cls  name tail_ipv4_ct_egress  tag 942fed3cb3b03de5  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 173
530: sched_cls  name tail_handle_ipv4_cont  tag 7ffc260fe1e86a11  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,110,40,37,38,81
	btf_id 174
531: sched_cls  name cil_from_container  tag 9dedd9529a996ab3  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 175
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
536: sched_cls  name tail_handle_ipv4  tag 03cf646816014bbd  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 177
537: sched_cls  name __send_drop_notify  tag 7bd84cef8dfa0064  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
539: sched_cls  name handle_policy  tag 4161973ad3269b2c  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,111,82,83,112,41,80,101,39,84,75,40,37,38
	btf_id 179
540: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 180
543: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
544: sched_cls  name tail_handle_arp  tag af9203f29ec5085d  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 181
545: sched_cls  name tail_handle_ipv4_cont  tag 86c2ddd5b557401d  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,112,41,101,82,83,39,76,74,77,111,40,37,38,81
	btf_id 182
547: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 184
548: sched_cls  name tail_ipv4_ct_ingress  tag 1870fc50ee3591e8  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 185
549: sched_cls  name cil_from_container  tag 91af229aedb57943  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 111,76
	btf_id 186
550: sched_cls  name tail_ipv4_to_endpoint  tag 18301ff618cb2ab0  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,112,41,82,83,80,101,39,111,40,37,38
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 189
562: sched_cls  name __send_drop_notify  tag 7b1d37ebd9c1dbe1  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
563: sched_cls  name tail_handle_ipv4_from_host  tag 1a2246f8eb3dd33b  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 193
564: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 194
565: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 195
566: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 197
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 198
570: sched_cls  name __send_drop_notify  tag 7b1d37ebd9c1dbe1  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
571: sched_cls  name tail_handle_ipv4_from_host  tag 1a2246f8eb3dd33b  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 202
573: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 205
574: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 206
576: sched_cls  name __send_drop_notify  tag 7b1d37ebd9c1dbe1  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 208
577: sched_cls  name tail_handle_ipv4_from_host  tag 1a2246f8eb3dd33b  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
581: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 214
582: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 215
584: sched_cls  name __send_drop_notify  tag 7b1d37ebd9c1dbe1  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 217
585: sched_cls  name tail_handle_ipv4_from_host  tag 1a2246f8eb3dd33b  gpl
	loaded_at 2024-10-24T12:32:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 218
626: sched_cls  name tail_handle_ipv4_cont  tag 1001cecca071a2fd  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 233
627: sched_cls  name tail_ipv4_to_endpoint  tag e05c62f46003e6b5  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 234
628: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 235
629: sched_cls  name __send_drop_notify  tag 835406697bcce15d  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 236
630: sched_cls  name cil_from_container  tag f2aa15e761ef0d4c  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 237
631: sched_cls  name tail_handle_arp  tag 037f811fcbe1f05f  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 238
632: sched_cls  name tail_ipv4_ct_ingress  tag 57bb93e9d38d103f  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 239
634: sched_cls  name tail_ipv4_ct_egress  tag aaa73dfa398c7c60  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 241
635: sched_cls  name handle_policy  tag 00c39374474f3d47  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 242
636: sched_cls  name tail_handle_ipv4  tag cf7bd5493461b344  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
698: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
701: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3300: sched_cls  name tail_handle_arp  tag cdaaf4af3c9d05bf  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,630
	btf_id 3089
3302: sched_cls  name tail_handle_ipv4  tag 72319116f04b4fd7  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,630
	btf_id 3091
3304: sched_cls  name tail_ipv4_to_endpoint  tag 953c4f724b7c98f3  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,629,41,82,83,80,151,39,630,40,37,38
	btf_id 3094
3305: sched_cls  name tail_handle_ipv4_cont  tag e56d0b8befbc3e46  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,629,41,151,82,83,39,76,74,77,630,40,37,38,81
	btf_id 3096
3306: sched_cls  name cil_from_container  tag 49d50e0d7ad92fb2  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 630,76
	btf_id 3097
3309: sched_cls  name tail_ipv4_ct_egress  tag 4a6c9530b3e48c7f  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,630,82,83,629,84
	btf_id 3098
3310: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,630
	btf_id 3101
3313: sched_cls  name tail_ipv4_ct_ingress  tag 359bb44de2dd3587  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,630,82,83,629,84
	btf_id 3102
3314: sched_cls  name __send_drop_notify  tag dd5ec297c45ae4a3  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3105
3321: sched_cls  name handle_policy  tag 2273423443986204  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,630,82,83,629,41,80,151,39,84,75,40,37,38
	btf_id 3106
3355: sched_cls  name tail_ipv4_ct_egress  tag 9d885f82a2e2bb98  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3149
3356: sched_cls  name cil_from_container  tag acf50fca7bea3423  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3150
3358: sched_cls  name tail_handle_ipv4_cont  tag df4eab1bb3009416  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,641,41,145,82,83,39,76,74,77,642,40,37,38,81
	btf_id 3154
3360: sched_cls  name tail_handle_arp  tag b850b920b4f9e7a9  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,642
	btf_id 3156
3361: sched_cls  name tail_handle_ipv4  tag 9ec52239003ef5ec  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3152
3362: sched_cls  name tail_ipv4_to_endpoint  tag afc41102eaed0d36  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,641,41,82,83,80,145,39,642,40,37,38
	btf_id 3157
3363: sched_cls  name tail_ipv4_ct_ingress  tag 071b7a472b626e4f  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3158
3364: sched_cls  name tail_ipv4_ct_egress  tag 5bec0071bf255b27  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3160
3365: sched_cls  name tail_handle_ipv4  tag 652c3949a1d401cc  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,642
	btf_id 3161
3366: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,642
	btf_id 3162
3367: sched_cls  name __send_drop_notify  tag bc7a80fc5ed0f644  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3163
3368: sched_cls  name handle_policy  tag 20b657d0268b0414  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,639,41,80,148,39,84,75,40,37,38
	btf_id 3159
3369: sched_cls  name __send_drop_notify  tag f9ba38240ced3caf  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3165
3370: sched_cls  name handle_policy  tag d171e1e5f36033fc  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,642,82,83,641,41,80,145,39,84,75,40,37,38
	btf_id 3164
3371: sched_cls  name cil_from_container  tag b3026e0060312587  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 642,76
	btf_id 3167
3372: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3166
3373: sched_cls  name tail_handle_arp  tag efbcc20c0a068fc2  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3168
3374: sched_cls  name tail_ipv4_ct_ingress  tag 36e528fad7ffff6f  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3169
3375: sched_cls  name tail_handle_ipv4_cont  tag 493f7a6226ee0842  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,148,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3170
3376: sched_cls  name tail_ipv4_to_endpoint  tag b9e5cf379c2610b0  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,148,39,640,40,37,38
	btf_id 3171
