top - 12:54:16 up 31 min,  0 users,  load average: 1.67, 0.90, 0.47
Tasks:   6 total,   2 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.9 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.1 si,  0.0 st
MiB Mem :   3836.2 total,    289.5 free,   1052.5 used,   2494.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2602.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 295916  79812 S  43.8   7.5   1:09.72 cilium-+
    392 root      20   0 1229744  10140   3900 S   0.0   0.3   0:04.49 cilium-+
   3217 root      20   0 1240432  16600  11164 S   0.0   0.4   0:00.02 cilium-+
   3243 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3260 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3283 root      20   0    3728    488    436 R   0.0   0.0   0:00.00 bash
