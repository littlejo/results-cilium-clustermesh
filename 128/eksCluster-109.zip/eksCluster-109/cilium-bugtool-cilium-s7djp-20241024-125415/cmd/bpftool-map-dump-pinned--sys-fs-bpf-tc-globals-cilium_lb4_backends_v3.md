key: 0c 00 00 00  value: 0a 6d 00 1b 1f 90 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 6d 00 fd 09 4b 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 6d 00 ba 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 6d 00 ba 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 6d 00 f2 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f e1 d2 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 6d 00 f2 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f c3 60 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 9c 2b 01 bb 00 00  00 00 00 00
Found 9 elements
