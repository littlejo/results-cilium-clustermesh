{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.729Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.736Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.739Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.779Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.781Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.814Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.104Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.112Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.224Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.251Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.315Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.933Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.935Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.954Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.987Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.018Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.052Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.056Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.275Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.290Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.344Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.359Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.402Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.943Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.946Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.992Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.992Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.055Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.069Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.097Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.297Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.302Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.358Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.419Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.470Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.096Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.104Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.129Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.140Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.173Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.178Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.208Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.461Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.473Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.525Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.526Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.566Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.989Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.993Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.035Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.057Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.084Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.322Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.338Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.376Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.403Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.423Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.840Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.944Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.952Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.048Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.051Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.094Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.243Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.254Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.323Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.354Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.362Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.674Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.707Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.716Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.757Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.762Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.796Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.039Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.062Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.103Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.126Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.158Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.507Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.511Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.558Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.569Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.596Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.835Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.882Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.006Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.031Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.047Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.413Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.417Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.467Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.478Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.502Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.728Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.740Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.791Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.798Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.837Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.135Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.150Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.176Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.207Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.227Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.467Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.473Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.519Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.548Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.568Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.897Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.939Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.940Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.990Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.999Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.027Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.234Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.249Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.261Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.290Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.988Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.990Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.031Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.042Z",
  "value": "id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.067Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.376Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.382Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.066Z",
  "value": "id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.083Z",
  "value": "id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C"
}

