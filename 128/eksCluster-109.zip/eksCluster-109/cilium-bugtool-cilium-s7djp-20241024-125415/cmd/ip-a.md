1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d2:2e:c5:3c:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.225.210/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3547sec preferred_lft 3547sec
    inet6 fe80::8d2:2eff:fec5:3cfd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:29:9c:8c:c9:f7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.255.158/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::829:9cff:fe8c:c9f7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:91:76:fc:f2:da brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac91:76ff:fefc:f2da/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:21:83:f9:61:87 brd ff:ff:ff:ff:ff:ff
    inet 10.109.0.182/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b421:83ff:fef9:6187/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c6:f9:63:47:b5:3d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c4f9:63ff:fe47:b53d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:7b:7b:b7:3e:43 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7c7b:7bff:feb7:3e43/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc096d3f88ff4a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:2d:af:ec:47:95 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::602d:afff:feec:4795/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc28a194b9b93e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:e5:3d:13:87:49 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f8e5:3dff:fe13:8749/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8032aa005170@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:15:8e:13:eb:9e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6c15:8eff:fe13:eb9e/64 scope link 
       valid_lft forever preferred_lft forever
20: lxca50a97f6ffa7@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:1c:1b:9e:83:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::601c:1bff:fe9e:83b1/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc5b29b74f15a9@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:b4:96:96:2b:4d brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::b4b4:96ff:fe96:2b4d/64 scope link 
       valid_lft forever preferred_lft forever
24: lxca86088954805@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:93:06:b0:a0:2c brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::7893:6ff:feb0:a02c/64 scope link 
       valid_lft forever preferred_lft forever
