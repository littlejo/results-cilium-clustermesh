IP ADDRESS         LOCAL ENDPOINT INFO
10.109.0.240:0     id=145   sec_id=7259365 flags=0x0000 ifindex=24  mac=06:E9:B4:29:9E:6C nodemac=7A:93:06:B0:A0:2C   
10.109.0.242:0     id=1015  sec_id=7223033 flags=0x0000 ifindex=14  mac=3E:5E:FD:67:8F:D6 nodemac=FA:E5:3D:13:87:49   
10.109.0.224:0     id=647   sec_id=7248388 flags=0x0000 ifindex=20  mac=8E:DF:27:E9:D7:AF nodemac=62:1C:1B:9E:83:B1   
10.109.0.182:0     (localhost)                                                                                        
172.31.255.158:0   (localhost)                                                                                        
10.109.0.27:0      id=951   sec_id=7262308 flags=0x0000 ifindex=22  mac=CA:58:6D:1E:91:5D nodemac=B6:B4:96:96:2B:4D   
10.109.0.24:0      id=696   sec_id=4     flags=0x0000 ifindex=10  mac=C2:60:4B:1F:AE:0B nodemac=7E:7B:7B:B7:3E:43     
10.109.0.253:0     id=308   sec_id=7213293 flags=0x0000 ifindex=18  mac=52:6D:9C:D0:0D:49 nodemac=6E:15:8E:13:EB:9E   
172.31.225.210:0   (localhost)                                                                                        
10.109.0.186:0     id=351   sec_id=7223033 flags=0x0000 ifindex=12  mac=0E:8C:3D:F7:2E:63 nodemac=62:2D:AF:EC:47:95   
