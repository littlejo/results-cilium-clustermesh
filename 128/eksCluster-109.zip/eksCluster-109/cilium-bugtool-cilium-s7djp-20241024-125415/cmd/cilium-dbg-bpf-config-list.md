KEY             VALUE
AgentLiveness   1894908542856
UTimeOffset     3378462093750000
