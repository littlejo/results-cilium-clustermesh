alloc: 106.30MB (111464016 bytes)
total-alloc: 3.13GB (3356226024 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75803804
frees: 74677364
heap-alloc: 106.30MB (111464016 bytes)
heap-sys: 176.79MB (185376768 bytes)
heap-idle: 51.55MB (54059008 bytes)
heap-in-use: 125.23MB (131317760 bytes)
heap-released: 7.95MB (8331264 bytes)
heap-objects: 1126440
stack-in-use: 35.19MB (36896768 bytes)
stack-sys: 35.19MB (36896768 bytes)
stack-mspan-inuse: 2.07MB (2168960 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 996.79KB (1020713 bytes)
gc-sys: 5.48MB (5747712 bytes)
next-gc: when heap-alloc >= 150.81MB (158130840 bytes)
last-gc: 2024-10-24 12:54:21.676836137 +0000 UTC
gc-pause-total: 18.00307ms
gc-pause: 664514
gc-pause-end: 1729774461676836137
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0007134073610906899
enable-gc: true
debug-gc: false
