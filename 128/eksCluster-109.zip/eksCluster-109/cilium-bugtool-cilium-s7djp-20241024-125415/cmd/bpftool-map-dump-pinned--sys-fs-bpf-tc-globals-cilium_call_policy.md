key: 91 00 00 00  value: 28 0d 00 00
key: 34 01 00 00  value: 7b 02 00 00
key: 5f 01 00 00  value: 0f 02 00 00
key: 87 02 00 00  value: 2a 0d 00 00
key: b8 02 00 00  value: 1b 02 00 00
key: b7 03 00 00  value: f9 0c 00 00
key: f7 03 00 00  value: 05 02 00 00
Found 7 elements
