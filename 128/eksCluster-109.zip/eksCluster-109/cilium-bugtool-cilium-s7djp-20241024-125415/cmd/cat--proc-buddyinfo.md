Node 0, zone      DMA      2      2      5     41     20     10     11      5      2      3     42 
Node 0, zone   Normal    329      8      5      5      2      2      2      3      4      5      6 
