Endpoint ID: 145
Path: /sys/fs/bpf/tc/globals/cilium_policy_00145

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 308
Path: /sys/fs/bpf/tc/globals/cilium_policy_00308

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6048822   61212     0        
Allow    Ingress     1          ANY          NONE         disabled    5718483   60451     0        
Allow    Egress      0          ANY          NONE         disabled    7381267   72267     0        


Endpoint ID: 351
Path: /sys/fs/bpf/tc/globals/cilium_policy_00351

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3302     34        0        
Allow    Ingress     1          ANY          NONE         disabled    125860   1442      0        
Allow    Egress      0          ANY          NONE         disabled    18544    203       0        


Endpoint ID: 647
Path: /sys/fs/bpf/tc/globals/cilium_policy_00647

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 696
Path: /sys/fs/bpf/tc/globals/cilium_policy_00696

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6228288   76988     0        
Allow    Ingress     1          ANY          NONE         disabled    63314     769       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 951
Path: /sys/fs/bpf/tc/globals/cilium_policy_00951

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377521   4405      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1015
Path: /sys/fs/bpf/tc/globals/cilium_policy_01015

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2594     26        0        
Allow    Ingress     1          ANY          NONE         disabled    125596   1438      0        
Allow    Egress      0          ANY          NONE         disabled    17554    194       0        


Endpoint ID: 2073
Path: /sys/fs/bpf/tc/globals/cilium_policy_02073

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


