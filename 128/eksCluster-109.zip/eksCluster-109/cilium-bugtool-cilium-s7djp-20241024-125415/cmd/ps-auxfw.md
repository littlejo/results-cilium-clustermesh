USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3217  0.0  0.4 1240432 16380 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3231  0.0  0.0   3852  1296 ?        R    12:54   0:00  \_ bash -c cat /proc/net/xfrm_stat
root        3232  0.0  0.0   6408  1636 ?        R    12:54   0:00  \_ ps auxfw
root        3208  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  5.3  7.3 1539060 289268 ?      Ssl  12:32   1:09 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.3  0.2 1229744 10140 ?       Sl   12:32   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
