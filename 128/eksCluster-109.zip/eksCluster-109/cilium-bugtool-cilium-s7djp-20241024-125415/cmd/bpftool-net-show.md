xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 565
cilium_host(7) clsact/egress cil_from_host-cilium_host id 564
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 549
lxc096d3f88ff4a(12) clsact/ingress cil_from_container-lxc096d3f88ff4a id 531
lxc28a194b9b93e(14) clsact/ingress cil_from_container-lxc28a194b9b93e id 512
lxc8032aa005170(18) clsact/ingress cil_from_container-lxc8032aa005170 id 630
lxca50a97f6ffa7(20) clsact/ingress cil_from_container-lxca50a97f6ffa7 id 3371
lxc5b29b74f15a9(22) clsact/ingress cil_from_container-lxc5b29b74f15a9 id 3306
lxca86088954805(24) clsact/ingress cil_from_container-lxca86088954805 id 3356

flow_dissector:

netfilter:

