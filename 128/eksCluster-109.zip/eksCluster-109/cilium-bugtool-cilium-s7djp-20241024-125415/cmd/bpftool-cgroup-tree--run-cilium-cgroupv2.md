CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod844978ea_063f_4c8e_b6a1_5a84c956b67d.slice/cri-containerd-29aaf65e4bd2459959b78d5dde0d74a887c8f5175591a492d84084b3e30caab7.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod844978ea_063f_4c8e_b6a1_5a84c956b67d.slice/cri-containerd-c54e68c13af51941dee1364c6e503241c1a99b30c1a8e5f88c0d2eefab01a8d1.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcef3a9a2_dbc1_458b_834f_76430b87ea00.slice/cri-containerd-84b593bab699f7dc1988197eb16d4133211663f4e6bb15ee79e3e67aad008241.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcef3a9a2_dbc1_458b_834f_76430b87ea00.slice/cri-containerd-6db39f730944fd87e785bb8035c7544ab8b9e47e967aabb0cf9828eb42579163.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5298ed94_3b79_49d5_a10a_46fd5a83ffb7.slice/cri-containerd-c222856bceec37b91593efb03938665118c8d23f0a2ca929599b2fc79954888c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5298ed94_3b79_49d5_a10a_46fd5a83ffb7.slice/cri-containerd-d5f85ef62e937fc38f9b367c801544be904a3e69d9e055a2268d9e059a19e857.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod964fc1b7_c5d2_4f44_90a9_4a94e00950e4.slice/cri-containerd-0d86089a52b833dd8e0504a4f68015d1b8bfd2e127d09c88b66cb2bba6c1a459.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod964fc1b7_c5d2_4f44_90a9_4a94e00950e4.slice/cri-containerd-47b4427e12672efc4fa11438ec4cb47d5be81b871cc3c11318c531ed0ce557dc.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1b9c656b_4046_4b35_b705_c73c266a0d97.slice/cri-containerd-f249fc995fc42aabc5204259b6fbefe3c9801ea0ac95d4ddee9960ea7454d153.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1b9c656b_4046_4b35_b705_c73c266a0d97.slice/cri-containerd-76a4b0089687bbe06591936461b17a2a4e95b2d41e7aff31edaa3490770cfdd7.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54978789_4458_4d9b_ae24_5a44d09b5bc8.slice/cri-containerd-886325d6d65cf1e9c2e5180d56d5d66c893932b7ed9a2559243ef4899c6f1a5a.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54978789_4458_4d9b_ae24_5a44d09b5bc8.slice/cri-containerd-50e5ce996432a5621ee45bdf269f0c776fe8a3b6bed45eb2d509e9386c29b030.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54978789_4458_4d9b_ae24_5a44d09b5bc8.slice/cri-containerd-ba935a8ad89595ea1f8a8069a58ae64c29d9320279ece21a1a2f38484e1d3f23.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54978789_4458_4d9b_ae24_5a44d09b5bc8.slice/cri-containerd-22f7252342e768a42706e8b943d0941a97f621efa5a84958c7d3111356a48b8f.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db81a3a_c9b0_429c_8bad_ec609e1148a3.slice/cri-containerd-6b011f628d136bb1b42626dc3089f6cc7028d9b09afa5248b5fce4e8017c92b8.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db81a3a_c9b0_429c_8bad_ec609e1148a3.slice/cri-containerd-622fe1d278bd8150417090faebb273590a49257054287059714d599704a11a3d.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db81a3a_c9b0_429c_8bad_ec609e1148a3.slice/cri-containerd-2670c48381b2903ab2eb2e938ede84c845a5f101e9aa53e657b6132afc60b498.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode17276ac_9733_4268_bad7_6f896a3126aa.slice/cri-containerd-493de61eef599b72bbd037eda1f534ce39563e01a10aea1abf76e9f8f3020a59.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode17276ac_9733_4268_bad7_6f896a3126aa.slice/cri-containerd-8ec7b376aea66d7c31289bf3d52900590e073cbaa2ce53c8a58d85a8c9be4e9f.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9873c1e7_bc09_4d8e_bc3e_2701ca81fb32.slice/cri-containerd-34952cdbf028087a207760eace3467a4c312a9c8a873c6ce1473cf6a59899188.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9873c1e7_bc09_4d8e_bc3e_2701ca81fb32.slice/cri-containerd-5dd8bbc12b54112087d1cf72a893c489a1d4dae82f775ec894b9da0a43b70cd8.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7539bae3_a012_400e_9b49_e2de681ae051.slice/cri-containerd-6412c1f876870f9f04cff905927624702f4996e4697964ae47a5aa87c437b4e6.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7539bae3_a012_400e_9b49_e2de681ae051.slice/cri-containerd-9d77a27a8cb7e0fd1b8675b6362ad230bf8e3ddbb5829ee495013d0a898fdf17.scope
    109      cgroup_device   multi                                          
