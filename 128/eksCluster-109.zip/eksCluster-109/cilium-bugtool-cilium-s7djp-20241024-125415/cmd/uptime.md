 12:54:16 up 31 min,  0 users,  load average: 1.67, 0.90, 0.47
