[
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54978789_4458_4d9b_ae24_5a44d09b5bc8.slice/cri-containerd-886325d6d65cf1e9c2e5180d56d5d66c893932b7ed9a2559243ef4899c6f1a5a.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54978789_4458_4d9b_ae24_5a44d09b5bc8.slice/cri-containerd-22f7252342e768a42706e8b943d0941a97f621efa5a84958c7d3111356a48b8f.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54978789_4458_4d9b_ae24_5a44d09b5bc8.slice/cri-containerd-50e5ce996432a5621ee45bdf269f0c776fe8a3b6bed45eb2d509e9386c29b030.scope"
      }
    ],
    "ips": [
      "10.109.0.253"
    ],
    "name": "clustermesh-apiserver-668d8b7b9-qx58j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db81a3a_c9b0_429c_8bad_ec609e1148a3.slice/cri-containerd-2670c48381b2903ab2eb2e938ede84c845a5f101e9aa53e657b6132afc60b498.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db81a3a_c9b0_429c_8bad_ec609e1148a3.slice/cri-containerd-6b011f628d136bb1b42626dc3089f6cc7028d9b09afa5248b5fce4e8017c92b8.scope"
      }
    ],
    "ips": [
      "10.109.0.27"
    ],
    "name": "echo-same-node-86d9cc975c-hb654",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1b9c656b_4046_4b35_b705_c73c266a0d97.slice/cri-containerd-f249fc995fc42aabc5204259b6fbefe3c9801ea0ac95d4ddee9960ea7454d153.scope"
      }
    ],
    "ips": [
      "10.109.0.224"
    ],
    "name": "client-974f6c69d-k8rdj",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode17276ac_9733_4268_bad7_6f896a3126aa.slice/cri-containerd-8ec7b376aea66d7c31289bf3d52900590e073cbaa2ce53c8a58d85a8c9be4e9f.scope"
      }
    ],
    "ips": [
      "10.109.0.240"
    ],
    "name": "client2-57cf4468f-ptv58",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcef3a9a2_dbc1_458b_834f_76430b87ea00.slice/cri-containerd-6db39f730944fd87e785bb8035c7544ab8b9e47e967aabb0cf9828eb42579163.scope"
      }
    ],
    "ips": [
      "10.109.0.186"
    ],
    "name": "coredns-cc6ccd49c-2rk5t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod964fc1b7_c5d2_4f44_90a9_4a94e00950e4.slice/cri-containerd-0d86089a52b833dd8e0504a4f68015d1b8bfd2e127d09c88b66cb2bba6c1a459.scope"
      }
    ],
    "ips": [
      "10.109.0.242"
    ],
    "name": "coredns-cc6ccd49c-fsd56",
    "namespace": "kube-system"
  }
]

