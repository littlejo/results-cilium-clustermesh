REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     134255    10885024    677    bpf_overlay.c
Interface                   INGRESS     681297    248179900   1132   bpf_host.c
Policy denied               EGRESS      61        4514        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      135327    10964477    53     encap.h
Success                     EGRESS      153345    20129015    1308   bpf_lxc.c
Success                     EGRESS      57937     4702256     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     178091    20505755    86     l3.h
Success                     INGRESS     255636    26887292    235    trace.h
Unsupported L3 protocol     EGRESS      71        5350        1492   bpf_lxc.c
