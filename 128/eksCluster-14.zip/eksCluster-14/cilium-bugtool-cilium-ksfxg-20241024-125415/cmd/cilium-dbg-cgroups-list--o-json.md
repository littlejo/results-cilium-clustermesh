[
  {
    "containers": [
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94378f73_2874_47d2_acab_a104f82633df.slice/cri-containerd-de3639831b0b32b534cf6b4abe7e24b6beadfdfbeb23cc4da5097072dbd556f3.scope"
      },
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94378f73_2874_47d2_acab_a104f82633df.slice/cri-containerd-246d2e1cc841d6d2904b633cf689bac29d415fb3ff72ce57230f3c82f37dbebd.scope"
      },
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94378f73_2874_47d2_acab_a104f82633df.slice/cri-containerd-a6f451846a846400884a40306682d6b08b5d7e1e9ee1f428f0bafb66bdfe67ab.scope"
      }
    ],
    "ips": [
      "10.14.0.165"
    ],
    "name": "clustermesh-apiserver-8475447d64-tq7h4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08c440e7_4e21_47cf_b479_99e72d46321a.slice/cri-containerd-94fdecaa3cd353d3e54d86db669a65038812b211b06305d64be4864eeab9889b.scope"
      }
    ],
    "ips": [
      "10.14.0.223"
    ],
    "name": "coredns-cc6ccd49c-mrw8s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54712b5a_c1c7_4345_ada8_962feb4a22a7.slice/cri-containerd-b98dc9a42fd2c0fee65fefd7ee550848ef36d439bf9144a859307ef5257c4103.scope"
      }
    ],
    "ips": [
      "10.14.0.167"
    ],
    "name": "coredns-cc6ccd49c-nxd7k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86ca515e_0a66_44bf_9361_bb6ecb4931ca.slice/cri-containerd-18285b709d26bf2e851e8c714784cf5daf8720a8d843c6e6d564d58d5508e7a4.scope"
      }
    ],
    "ips": [
      "10.14.0.151"
    ],
    "name": "client-974f6c69d-k7gcl",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda27045f2_4341_4abb_ae06_b769e3a8ed3a.slice/cri-containerd-666ec20b9358dab9ab77f58788e9fead07719fb4f80108242e28ea3a819bb70a.scope"
      },
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda27045f2_4341_4abb_ae06_b769e3a8ed3a.slice/cri-containerd-9ae62d92f8ccfbb0cd540a23b8bf78f060caf9ae1ad69e07b03cd29bdcbf5329.scope"
      }
    ],
    "ips": [
      "10.14.0.8"
    ],
    "name": "echo-same-node-86d9cc975c-fc4k2",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96a6aef3_9c33_41aa_8d0d_aa6308d421e8.slice/cri-containerd-f408bfd0bf59376243536c277b254f41afead400c8493e0e88dd8e4da1755631.scope"
      }
    ],
    "ips": [
      "10.14.0.187"
    ],
    "name": "client2-57cf4468f-79vw2",
    "namespace": "cilium-test-1"
  }
]

