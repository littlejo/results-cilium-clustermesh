CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08c440e7_4e21_47cf_b479_99e72d46321a.slice/cri-containerd-555e6754e75a0054d885c9161b236a9b7110bac3a5ddbe706e86be48ad5172a6.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08c440e7_4e21_47cf_b479_99e72d46321a.slice/cri-containerd-94fdecaa3cd353d3e54d86db669a65038812b211b06305d64be4864eeab9889b.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod69435045_b607_41ea_bc14_bf7d04d9e59b.slice/cri-containerd-b244732780f0e555360173ca22674b77fbd8cb0f9b06b0cfa80c00f0a57151bb.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod69435045_b607_41ea_bc14_bf7d04d9e59b.slice/cri-containerd-cbb4a579535280086c82e023dca2129516fa710473bfa603b11aedd818d2d5fa.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54712b5a_c1c7_4345_ada8_962feb4a22a7.slice/cri-containerd-b98dc9a42fd2c0fee65fefd7ee550848ef36d439bf9144a859307ef5257c4103.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54712b5a_c1c7_4345_ada8_962feb4a22a7.slice/cri-containerd-916a88e723599a4a9dba115cd163f8f93905233b52d78106747c811e82716fab.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad1dd9a6_923e_4ee5_9602_897c9a6da12b.slice/cri-containerd-1d5c6cd671c75ea50816ac2127e7755b56dbcd04440c77aaf055df0eb6db44fa.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad1dd9a6_923e_4ee5_9602_897c9a6da12b.slice/cri-containerd-695c7b18ea0ffca68e1d7423fd6b0989fd77e2e8dd6b2caf5043b7fa1f9aa866.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15d7ee19_6262_431f_bc04_95ef535f3fb4.slice/cri-containerd-89bc898d9bc3d1f50cfd47d4712bbc37368df03772069e74c03f7a745a14e6fc.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15d7ee19_6262_431f_bc04_95ef535f3fb4.slice/cri-containerd-8d0c49ac9e4d33529ad93c5910be4d7bc11bc0ecaa4518825b6ee3eab7f7a3ea.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda27045f2_4341_4abb_ae06_b769e3a8ed3a.slice/cri-containerd-666ec20b9358dab9ab77f58788e9fead07719fb4f80108242e28ea3a819bb70a.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda27045f2_4341_4abb_ae06_b769e3a8ed3a.slice/cri-containerd-9ae62d92f8ccfbb0cd540a23b8bf78f060caf9ae1ad69e07b03cd29bdcbf5329.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda27045f2_4341_4abb_ae06_b769e3a8ed3a.slice/cri-containerd-b2e964caf5d86e47cce5e424eabb97bd040504a6aa6aedce0990382815f2348e.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d1c25d_fd5e_43e5_9790_cd5f138cc0a9.slice/cri-containerd-71458fa2464faf6ea7a88372e1fe28cf486cd755d78676b574bfa7642d9b4d5c.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d1c25d_fd5e_43e5_9790_cd5f138cc0a9.slice/cri-containerd-843eaf55d7bc5054c9891b6bbd760b8efa8e5018fef27bfc545cb6bdbca74ae2.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86ca515e_0a66_44bf_9361_bb6ecb4931ca.slice/cri-containerd-18285b709d26bf2e851e8c714784cf5daf8720a8d843c6e6d564d58d5508e7a4.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86ca515e_0a66_44bf_9361_bb6ecb4931ca.slice/cri-containerd-c75c0b705f020695366afc628b9d5ef9bf2bc39cf29a899ef8ff6d7740195edc.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96a6aef3_9c33_41aa_8d0d_aa6308d421e8.slice/cri-containerd-f408bfd0bf59376243536c277b254f41afead400c8493e0e88dd8e4da1755631.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96a6aef3_9c33_41aa_8d0d_aa6308d421e8.slice/cri-containerd-fc516a2423c7bd778dbf7e12cd3616be223f2fcc63027a7c6adfd77aca37b57e.scope
    683      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94378f73_2874_47d2_acab_a104f82633df.slice/cri-containerd-246d2e1cc841d6d2904b633cf689bac29d415fb3ff72ce57230f3c82f37dbebd.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94378f73_2874_47d2_acab_a104f82633df.slice/cri-containerd-71b991ca35b24b2faf79cb48d8bf47fbeaeb234b9099ef94399bb4d77969674d.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94378f73_2874_47d2_acab_a104f82633df.slice/cri-containerd-a6f451846a846400884a40306682d6b08b5d7e1e9ee1f428f0bafb66bdfe67ab.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94378f73_2874_47d2_acab_a104f82633df.slice/cri-containerd-de3639831b0b32b534cf6b4abe7e24b6beadfdfbeb23cc4da5097072dbd556f3.scope
    649      cgroup_device   multi                                          
