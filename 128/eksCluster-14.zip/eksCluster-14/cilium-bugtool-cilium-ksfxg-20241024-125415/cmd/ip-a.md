1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:5e:73:5f:64:b1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.140.198/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3403sec preferred_lft 3403sec
    inet6 fe80::45e:73ff:fe5f:64b1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:99:3e:60:89:bb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.163.207/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::499:3eff:fe60:89bb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:59:d5:94:22:d9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9059:d5ff:fe94:22d9/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:cc:b6:8e:3d:c2 brd ff:ff:ff:ff:ff:ff
    inet 10.14.0.172/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a8cc:b6ff:fe8e:3dc2/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b2:db:45:2d:aa:70 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b0db:45ff:fe2d:aa70/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:24:df:4f:5d:88 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5024:dfff:fe4f:5d88/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7557a3146baf@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:85:69:02:1a:ec brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9885:69ff:fe02:1aec/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc848dd4c606da@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:3c:4b:4b:fa:9a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fc3c:4bff:fe4b:fa9a/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf543f70cbcf8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:be:1a:04:b9:e5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::48be:1aff:fe04:b9e5/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc712a56128a16@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:2b:76:dd:27:2a brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::3c2b:76ff:fedd:272a/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc2379d7606f57@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:0c:2b:04:d0:80 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::200c:2bff:fe04:d080/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc505f6529ad89@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:62:15:80:4d:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::2c62:15ff:fe80:4da2/64 scope link 
       valid_lft forever preferred_lft forever
