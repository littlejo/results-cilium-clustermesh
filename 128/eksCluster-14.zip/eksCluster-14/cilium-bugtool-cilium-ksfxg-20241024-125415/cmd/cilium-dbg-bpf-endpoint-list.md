IP ADDRESS         LOCAL ENDPOINT INFO
10.14.0.167:0      id=2209  sec_id=983883 flags=0x0000 ifindex=14  mac=7A:5C:02:23:4A:12 nodemac=FE:3C:4B:4B:FA:9A    
10.14.0.151:0      id=3931  sec_id=988100 flags=0x0000 ifindex=20  mac=06:92:1A:92:FF:B1 nodemac=3E:2B:76:DD:27:2A    
172.31.140.198:0   (localhost)                                                                                        
172.31.163.207:0   (localhost)                                                                                        
10.14.0.223:0      id=130   sec_id=983883 flags=0x0000 ifindex=12  mac=DA:F0:5D:EA:72:72 nodemac=9A:85:69:02:1A:EC    
10.14.0.187:0      id=1205  sec_id=1002458 flags=0x0000 ifindex=22  mac=02:BA:50:13:38:F3 nodemac=22:0C:2B:04:D0:80   
10.14.0.75:0       id=1023  sec_id=4     flags=0x0000 ifindex=10  mac=6A:6F:02:95:86:62 nodemac=52:24:DF:4F:5D:88     
10.14.0.172:0      (localhost)                                                                                        
10.14.0.8:0        id=3550  sec_id=1016137 flags=0x0000 ifindex=24  mac=F2:41:75:0D:CA:CC nodemac=2E:62:15:80:4D:A2   
10.14.0.165:0      id=124   sec_id=1016586 flags=0x0000 ifindex=18  mac=36:5D:DB:29:C5:66 nodemac=4A:BE:1A:04:B9:E5   
