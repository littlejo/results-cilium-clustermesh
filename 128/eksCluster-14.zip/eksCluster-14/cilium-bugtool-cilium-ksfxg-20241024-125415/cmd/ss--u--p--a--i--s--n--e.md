Total: 577
TCP:   4516 (estab 298, closed 4198, orphaned 1, timewait 3733)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  318       309       9        
INET	  328       315       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                  172.31.140.198%ens5:68         0.0.0.0:*    uid:192 ino:86801 sk:1 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                            127.0.0.1:37129      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:27978 sk:2 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:29092 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15512 sk:4 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:29091 sk:1001 cgroup:/ v6only:1 <->                                      
UNCONN 0      0                                [::1]:323           [::]:*    ino:15513 sk:1002 cgroup:unreachable:e8e v6only:1 <->                        
UNCONN 0      0      [fe80::45e:73ff:fe5f:64b1]%ens5:546           [::]:*    uid:192 ino:15685 sk:1003 cgroup:unreachable:bd0 v6only:1 <->                
