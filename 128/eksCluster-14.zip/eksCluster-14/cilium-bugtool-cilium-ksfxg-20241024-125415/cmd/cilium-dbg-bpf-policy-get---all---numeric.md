Endpoint ID: 124
Path: /sys/fs/bpf/tc/globals/cilium_policy_00124

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6093408   61063     0        
Allow    Ingress     1          ANY          NONE         disabled    5339464   56351     0        
Allow    Egress      0          ANY          NONE         disabled    6486737   64359     0        


Endpoint ID: 130
Path: /sys/fs/bpf/tc/globals/cilium_policy_00130

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1996     19        0        
Allow    Ingress     1          ANY          NONE         disabled    167856   1922      0        
Allow    Egress      0          ANY          NONE         disabled    21544    243       0        


Endpoint ID: 1023
Path: /sys/fs/bpf/tc/globals/cilium_policy_01023

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6218528   77008     0        
Allow    Ingress     1          ANY          NONE         disabled    68752     830       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1205
Path: /sys/fs/bpf/tc/globals/cilium_policy_01205

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2209
Path: /sys/fs/bpf/tc/globals/cilium_policy_02209

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3900     41        0        
Allow    Ingress     1          ANY          NONE         disabled    169506   1947      0        
Allow    Egress      0          ANY          NONE         disabled    22187    251       0        


Endpoint ID: 3536
Path: /sys/fs/bpf/tc/globals/cilium_policy_03536

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3550
Path: /sys/fs/bpf/tc/globals/cilium_policy_03550

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    375362   4397      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3931
Path: /sys/fs/bpf/tc/globals/cilium_policy_03931

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


