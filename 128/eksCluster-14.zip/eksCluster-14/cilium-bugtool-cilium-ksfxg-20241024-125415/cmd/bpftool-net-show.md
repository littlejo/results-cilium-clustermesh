xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 506
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 495
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 488
cilium_host(7) clsact/egress cil_from_host-cilium_host id 493
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 552
lxc7557a3146baf(12) clsact/ingress cil_from_container-lxc7557a3146baf id 526
lxc848dd4c606da(14) clsact/ingress cil_from_container-lxc848dd4c606da id 539
lxcf543f70cbcf8(18) clsact/ingress cil_from_container-lxcf543f70cbcf8 id 624
lxc712a56128a16(20) clsact/ingress cil_from_container-lxc712a56128a16 id 3336
lxc2379d7606f57(22) clsact/ingress cil_from_container-lxc2379d7606f57 id 3348
lxc505f6529ad89(24) clsact/ingress cil_from_container-lxc505f6529ad89 id 3278

flow_dissector:

netfilter:

