top - 12:54:16 up 33 min,  0 users,  load average: 0.86, 0.53, 0.26
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 26.7 us, 36.7 sy,  0.0 ni, 33.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    280.7 free,   1058.2 used,   2497.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2597.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 296328  79232 S  26.7   7.5   1:07.45 cilium-+
   3287 root      20   0 1240432  16712  11484 S   6.7   0.4   0:00.03 cilium-+
    395 root      20   0 1229744  10068   3900 S   0.0   0.3   0:04.25 cilium-+
   3277 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
   3312 root      20   0    6576   2432   2104 R   0.0   0.1   0:00.00 top
   3337 root      20   0 1228744   3652   2976 S   0.0   0.1   0:00.00 gops
