markdown output at /tmp/cilium-bugtool-20241024-125416.614+0000-UTC-461885699/cmd/cilium-debuginfo-20241024-125447.235+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.614+0000-UTC-461885699/cmd/cilium-debuginfo-20241024-125447.235+0000-UTC.json
