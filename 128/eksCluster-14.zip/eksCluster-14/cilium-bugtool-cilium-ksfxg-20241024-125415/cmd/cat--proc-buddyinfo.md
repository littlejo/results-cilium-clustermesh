Node 0, zone      DMA    378     33      2     41     18      4      4      3      3      2     39 
Node 0, zone   Normal      4      5      1      1      3      2      2      2      2      3      8 
