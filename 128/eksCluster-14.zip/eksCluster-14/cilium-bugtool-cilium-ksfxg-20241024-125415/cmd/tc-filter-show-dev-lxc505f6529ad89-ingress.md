filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc505f6529ad89 direct-action not_in_hw id 3278 tag 5a34645c38956f3e jited 
