 12:54:16 up 33 min,  0 users,  load average: 0.86, 0.53, 0.26
