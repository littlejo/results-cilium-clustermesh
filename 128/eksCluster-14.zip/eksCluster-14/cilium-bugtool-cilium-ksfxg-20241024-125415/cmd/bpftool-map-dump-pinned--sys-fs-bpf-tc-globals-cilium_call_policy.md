key: 7c 00 00 00  value: 6a 02 00 00
key: 82 00 00 00  value: 18 02 00 00
key: ff 03 00 00  value: 2c 02 00 00
key: b5 04 00 00  value: 13 0d 00 00
key: a1 08 00 00  value: 1f 02 00 00
key: de 0d 00 00  value: de 0c 00 00
key: 5b 0f 00 00  value: 11 0d 00 00
Found 7 elements
