alloc: 95.32MB (99948176 bytes)
total-alloc: 3.15GB (3377846832 bytes)
sys: 219.07MB (229713236 bytes)
lookups: 0
mallocs: 75919844
frees: 74984178
heap-alloc: 95.32MB (99948176 bytes)
heap-sys: 172.60MB (180985856 bytes)
heap-idle: 50.52MB (52977664 bytes)
heap-in-use: 122.08MB (128008192 bytes)
heap-released: 3.70MB (3874816 bytes)
heap-objects: 935666
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.02MB (2117120 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 733.84KB (751449 bytes)
gc-sys: 5.48MB (5747712 bytes)
next-gc: when heap-alloc >= 154.10MB (161580888 bytes)
last-gc: 2024-10-24 12:54:24.550646174 +0000 UTC
gc-pause-total: 35.908483ms
gc-pause: 158403
gc-pause-end: 1729774464550646174
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.0005283165781291437
enable-gc: true
debug-gc: false
