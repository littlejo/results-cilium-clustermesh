REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     131898    10691743    677    bpf_overlay.c
Interface                   INGRESS     675860    248453310   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      131902    10687890    53     encap.h
Success                     EGRESS      152866    20054165    1308   bpf_lxc.c
Success                     EGRESS      55835     4525139     1694   bpf_host.c
Success                     EGRESS      596       156261      86     l3.h
Success                     INGRESS     176691    20402637    86     l3.h
Success                     INGRESS     253981    26767972    235    trace.h
Unsupported L3 protocol     EGRESS      73        5510        1492   bpf_lxc.c
