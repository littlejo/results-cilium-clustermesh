CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod977d80df_d149_43a5_b4a4_c3ae88412437.slice/cri-containerd-c6f5ad8744370335014d18130f314680ffa650f9a6065216999c0b8cc4097332.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod977d80df_d149_43a5_b4a4_c3ae88412437.slice/cri-containerd-e143692031e819e9134ee4313a1af05d4085773916da2e6005238825dcd62053.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7549999b_9f61_4930_8b1a_dc36682eaa90.slice/cri-containerd-11fca975dc45138e0f3e67d590c99e065140b5b41976a2f4e1a5c272eb11fa93.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7549999b_9f61_4930_8b1a_dc36682eaa90.slice/cri-containerd-dfd84a26d4fa0c4d175f66a17a1a58d825716c4286ce83704202985ed14af196.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod92344162_b9aa_4469_b421_e45d86d38a6f.slice/cri-containerd-0e2ade1b4eb58a3f6521c79811365acd59a27bf9d112e5384d703d2c3d8db0b7.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod92344162_b9aa_4469_b421_e45d86d38a6f.slice/cri-containerd-d2cbb1a8913df3b15b2842ad7d306406bb9b6b72cbe8bc6bc0e93e9f6ab670ca.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb15841e_2904_47ba_8fac_e72179ed206b.slice/cri-containerd-dd807f6cfa63bfd2bd395a7560b8718ab0917a52c03fe9d65c5767634b9936e4.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb15841e_2904_47ba_8fac_e72179ed206b.slice/cri-containerd-991b79e1de84d31150dd67beef9a816a483fad8f067d8a2ad3afdffa7861eaae.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4dda275_3165_4124_8ae5_26647ee1febf.slice/cri-containerd-caeb0007299e71c1f8c658816a7472cd7dd86d66b5f4aeb90eae8b84658eb2e5.scope
    708      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4dda275_3165_4124_8ae5_26647ee1febf.slice/cri-containerd-9b7c2c0a7cf0f9e41f9990b18714175db038c08eae3391904d46cf6c63df27af.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4dda275_3165_4124_8ae5_26647ee1febf.slice/cri-containerd-2f85c1e4c0b1a949a0fba7ae8899d0ad0e7f560e9649498cabb570fd0219f1df.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46ed3934_eb6d_4d5d_a235_bd89dc8dbde5.slice/cri-containerd-d5a709d31013a9da8640642307cc1dbb3248a1ffee17b80b5af9b179b277cd6b.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46ed3934_eb6d_4d5d_a235_bd89dc8dbde5.slice/cri-containerd-e512118312ed4a1fa6907db3590fe39beb0463b4bba481dd5b28c4733941a716.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46ed3934_eb6d_4d5d_a235_bd89dc8dbde5.slice/cri-containerd-243fdf7d452074184a43fbb6ab32d8d067363fcf15500b4b84a9881f1e94916b.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46ed3934_eb6d_4d5d_a235_bd89dc8dbde5.slice/cri-containerd-5986e85b5429c3e0e0a69c8c98d0eaf83556169798affe980f0fbdbdefda9001.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3263cf92_b8e9_4b53_aa8a_65318a9898f3.slice/cri-containerd-1665ef4415def7fcd5019a6f081ffcb2ae16093f7566abb12546f704875e0933.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3263cf92_b8e9_4b53_aa8a_65318a9898f3.slice/cri-containerd-8bf1682f1021e77d8ea7dbaa3ab6ab10bc4d04d30ad2201a056e61a89479da50.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod179376ce_d647_433f_9714_f3eba09d4c18.slice/cri-containerd-f881180cff3f45487283e9931fbb15c640fe42c5f3ad716223fc91b52fcb8149.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod179376ce_d647_433f_9714_f3eba09d4c18.slice/cri-containerd-99f00664d47afcacd9df140f8e2769236b81c00ceb08ecf0883b75c24225bb59.scope
    700      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16851750_fd83_4cdc_8d43_126e4e4818cc.slice/cri-containerd-e141cfc6f3610912cf012bebf2b929ef234659c1b0370af8ca33a350389412fd.scope
    696      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16851750_fd83_4cdc_8d43_126e4e4818cc.slice/cri-containerd-9133306888b5ab26a90cc2c866c37c5af270f57b57f5a327ee1f5a057ee2b050.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode00ec757_39da_4fa6_bca2_bdf4f82e6c55.slice/cri-containerd-08d5a54f0a24a0b5bfe1fc291f4e6d919f3ca6a15b76e9f7c7b617ec9b7160d7.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode00ec757_39da_4fa6_bca2_bdf4f82e6c55.slice/cri-containerd-279b0eb19f4bd9e8cccb1e523701d531e2701885a136feac4e1894fa21659b32.scope
    95       cgroup_device   multi                                          
