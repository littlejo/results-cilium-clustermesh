KEY             VALUE
AgentLiveness   1994034512562
UTimeOffset     3378461908203125
