29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:40+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:40+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:40+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:40+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:45+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name tail_handle_ipv4  tag 3a9469542dc71445  gpl
	loaded_at 2024-10-24T12:27:49+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
479: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:27:49+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:27:49+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:27:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
482: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 129
484: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,102
	btf_id 131
485: sched_cls  name tail_handle_ipv4_from_host  tag da3fd59be36b6351  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 132
487: sched_cls  name __send_drop_notify  tag 8f449636c5342082  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 134
488: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 135
489: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 137
490: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 138
493: sched_cls  name tail_handle_ipv4_from_host  tag da3fd59be36b6351  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 141
495: sched_cls  name __send_drop_notify  tag 8f449636c5342082  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 143
496: sched_cls  name __send_drop_notify  tag 8f449636c5342082  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 145
497: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 146
499: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 148
501: sched_cls  name tail_handle_ipv4_from_host  tag da3fd59be36b6351  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 150
504: sched_cls  name tail_handle_ipv4_from_host  tag da3fd59be36b6351  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 154
506: sched_cls  name __send_drop_notify  tag 8f449636c5342082  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 156
507: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 157
509: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:51+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 159
510: sched_cls  name tail_ipv4_ct_ingress  tag 80aa340025bbd6ce  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 162
511: sched_cls  name cil_from_container  tag 9bd8c1ea42feb02a  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 164
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 166
515: sched_cls  name tail_handle_ipv4  tag 55a0933ad1ebcf8b  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 167
516: sched_cls  name __send_drop_notify  tag 139a428033f91d63  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 169
517: sched_cls  name tail_handle_arp  tag 3917837403a3129d  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 170
518: sched_cls  name tail_ipv4_ct_egress  tag 23fbdd7190a73d96  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 171
522: sched_cls  name tail_handle_ipv4_cont  tag 314ce995f9155992  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 172
527: sched_cls  name tail_ipv4_to_endpoint  tag 0914e0393bab1f2f  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 176
531: sched_cls  name handle_policy  tag 90eb31c7fcec43c0  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 181
532: sched_cls  name tail_ipv4_ct_ingress  tag 12285ad5ad8ad779  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 185
533: sched_cls  name tail_ipv4_ct_egress  tag 23fbdd7190a73d96  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 186
534: sched_cls  name tail_handle_arp  tag 8a52e2e55936176e  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 189
535: sched_cls  name handle_policy  tag 86d10be343b023fc  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 187
536: sched_cls  name tail_handle_ipv4  tag bcb4dffbdfe17031  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 190
537: sched_cls  name cil_from_container  tag ee51a1c9f74876dc  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 192
538: sched_cls  name __send_drop_notify  tag 6c7a1bf9168aa081  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
539: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 194
540: sched_cls  name tail_handle_ipv4_cont  tag b5308f4f121de003  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 195
541: sched_cls  name handle_policy  tag 13af441b8bcd71de  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 191
542: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 197
543: sched_cls  name __send_drop_notify  tag eaaa450ce855369f  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
545: sched_cls  name tail_ipv4_to_endpoint  tag 1164c5d898e02de0  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 196
547: sched_cls  name tail_handle_arp  tag c1bc2a5b4ec46bc9  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 202
548: sched_cls  name tail_handle_ipv4  tag 6016dcc3ff33c887  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 200
549: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 203
550: sched_cls  name tail_ipv4_ct_ingress  tag c978efb437c89fc1  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 204
551: sched_cls  name cil_from_container  tag c7bf1539469819ca  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 205
552: sched_cls  name tail_handle_ipv4_cont  tag 45eda68a19416fde  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 206
553: sched_cls  name tail_ipv4_to_endpoint  tag b87a2d809c831dfd  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 207
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
561: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
562: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
565: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: sched_cls  name tail_ipv4_to_endpoint  tag 6e3d2449a7acc25a  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 221
610: sched_cls  name tail_handle_ipv4  tag a79f2dc1635e724f  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 222
611: sched_cls  name tail_handle_arp  tag 2dfe820036cd5665  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 223
613: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 225
614: sched_cls  name tail_ipv4_ct_ingress  tag 34b06df4adb9aa5a  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 226
615: sched_cls  name tail_ipv4_ct_egress  tag d5c2fcdf39f916e5  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 227
616: sched_cls  name __send_drop_notify  tag 8308aa6db066e359  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 228
617: sched_cls  name tail_handle_ipv4_cont  tag 058a469a1643bf8b  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 229
618: sched_cls  name cil_from_container  tag cb7440596e5dfa09  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 230
619: sched_cls  name handle_policy  tag 52ec409ce7d9ab07  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 231
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
681: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
684: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
685: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
688: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
689: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
692: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
693: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
696: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
697: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
700: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
701: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
704: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
705: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
708: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3283: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3077
3284: sched_cls  name tail_ipv4_ct_ingress  tag 02e6297bb2b00c86  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3078
3285: sched_cls  name tail_handle_arp  tag cbef847c87bd4c03  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3079
3286: sched_cls  name handle_policy  tag bf97ab1cf4f48b1d  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,149,39,84,75,40,37,38
	btf_id 3080
3289: sched_cls  name tail_handle_ipv4  tag b2c0587384448f9f  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3081
3290: sched_cls  name __send_drop_notify  tag ec1ac79b7c759903  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3086
3294: sched_cls  name tail_ipv4_ct_egress  tag 086681cf7777d6a9  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3087
3296: sched_cls  name cil_from_container  tag edb1c04ced2d435b  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3091
3297: sched_cls  name tail_handle_ipv4_cont  tag d6bf7e719831b4f4  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,149,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3093
3299: sched_cls  name tail_ipv4_to_endpoint  tag 22558eba98fd32fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,149,39,627,40,37,38
	btf_id 3094
3338: sched_cls  name tail_ipv4_ct_egress  tag e5adf7d955ae2e13  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3137
3339: sched_cls  name cil_from_container  tag b92e21087786bf4e  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,76
	btf_id 3140
3340: sched_cls  name tail_handle_ipv4_cont  tag ddc289e2c47fe313  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,146,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3139
3341: sched_cls  name tail_handle_ipv4  tag ffc22bd28c73bd8d  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,638
	btf_id 3141
3342: sched_cls  name __send_drop_notify  tag abeb6efbc356f521  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3143
3343: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,638
	btf_id 3144
3344: sched_cls  name tail_ipv4_to_endpoint  tag 28dcdda805568bf0  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,146,39,639,40,37,38
	btf_id 3142
3345: sched_cls  name tail_ipv4_to_endpoint  tag e7002e37b04d4a62  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,637,41,82,83,80,143,39,638,40,37,38
	btf_id 3145
3347: sched_cls  name handle_policy  tag 234f7ed304eaec19  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,146,39,84,75,40,37,38
	btf_id 3146
3348: sched_cls  name tail_handle_ipv4  tag 9e47ce1553066eb2  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3149
3349: sched_cls  name tail_handle_arp  tag de199512d97b5d1e  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3150
3350: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3151
3351: sched_cls  name handle_policy  tag 9e8489ade7785e69  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,638,82,83,637,41,80,143,39,84,75,40,37,38
	btf_id 3148
3352: sched_cls  name tail_ipv4_ct_egress  tag 6412bb5f4423f0d0  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3152
3353: sched_cls  name cil_from_container  tag 0839f15f14327484  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3154
3354: sched_cls  name __send_drop_notify  tag b50ea5c4ac501c32  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3155
3355: sched_cls  name tail_ipv4_ct_ingress  tag 849419c85ff2e0c2  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3153
3357: sched_cls  name tail_handle_arp  tag 7f1b72d265c7aa51  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,638
	btf_id 3157
3358: sched_cls  name tail_ipv4_ct_ingress  tag a38cca03914868ba  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3158
3359: sched_cls  name tail_handle_ipv4_cont  tag 3d30858fcd5f50cd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,637,41,143,82,83,39,76,74,77,638,40,37,38,81
	btf_id 3159
