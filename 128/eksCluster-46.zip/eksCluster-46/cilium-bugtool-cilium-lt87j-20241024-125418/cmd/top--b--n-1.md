top - 12:54:20 up 32 min,  0 users,  load average: 0.28, 0.35, 0.21
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 24.1 us, 34.5 sy,  0.0 ni, 41.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    280.9 free,   1057.6 used,   2497.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2597.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 299820  79160 S   6.7   7.6   1:06.13 cilium-+
   3217 root      20   0 1240432  16520  11484 S   6.7   0.4   0:00.03 cilium-+
    396 root      20   0 1229744   8628   2864 S   0.0   0.2   0:04.22 cilium-+
   3216 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3259 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3285 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
