Node 0, zone      DMA      1     96     23     30     15     33     37     10      4      4     35 
Node 0, zone   Normal    384     45     25     13     19      9      4      4      2      2      7 
