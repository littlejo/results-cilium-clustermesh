markdown output at /tmp/cilium-bugtool-20241024-125419.934+0000-UTC-954042092/cmd/cilium-debuginfo-20241024-125450.79+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125419.934+0000-UTC-954042092/cmd/cilium-debuginfo-20241024-125450.79+0000-UTC.json
