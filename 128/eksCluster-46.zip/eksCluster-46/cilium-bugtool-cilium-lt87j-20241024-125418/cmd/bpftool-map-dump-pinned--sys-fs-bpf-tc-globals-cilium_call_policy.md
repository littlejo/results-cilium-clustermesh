key: 4e 00 00 00  value: 17 02 00 00
key: e6 00 00 00  value: 1d 02 00 00
key: cb 01 00 00  value: d6 0c 00 00
key: 8e 05 00 00  value: 6b 02 00 00
key: 10 08 00 00  value: 17 0d 00 00
key: fc 08 00 00  value: 13 0d 00 00
key: d2 0e 00 00  value: 13 02 00 00
Found 7 elements
