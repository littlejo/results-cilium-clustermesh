alloc: 101.09MB (106001056 bytes)
total-alloc: 3.11GB (3337955856 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75453301
frees: 74421283
heap-alloc: 101.09MB (106001056 bytes)
heap-sys: 176.79MB (185376768 bytes)
heap-idle: 48.78MB (51150848 bytes)
heap-in-use: 128.01MB (134225920 bytes)
heap-released: 4.12MB (4325376 bytes)
heap-objects: 1032018
stack-in-use: 35.19MB (36896768 bytes)
stack-sys: 35.19MB (36896768 bytes)
stack-mspan-inuse: 2.13MB (2236960 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 951.38KB (974209 bytes)
gc-sys: 5.50MB (5772408 bytes)
next-gc: when heap-alloc >= 151.41MB (158770056 bytes)
last-gc: 2024-10-24 12:54:25.896296329 +0000 UTC
gc-pause-total: 38.928746ms
gc-pause: 163703
gc-pause-end: 1729774465896296329
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0005904209794145174
enable-gc: true
debug-gc: false
