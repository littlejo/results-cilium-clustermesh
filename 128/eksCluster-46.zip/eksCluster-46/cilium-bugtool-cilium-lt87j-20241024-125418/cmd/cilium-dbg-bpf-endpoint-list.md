IP ADDRESS         LOCAL ENDPOINT INFO
10.46.0.6:0        id=2300  sec_id=3137585 flags=0x0000 ifindex=22  mac=62:F4:95:91:F7:09 nodemac=BA:17:C6:4A:02:23   
10.46.0.172:0      id=1422  sec_id=3126924 flags=0x0000 ifindex=18  mac=C2:06:BB:D9:3B:DA nodemac=82:F7:89:9B:5F:8E   
10.46.0.24:0       id=459   sec_id=3087935 flags=0x0000 ifindex=24  mac=1A:5E:A5:67:C3:2B nodemac=FA:0D:A5:E1:77:2F   
10.46.0.200:0      id=2064  sec_id=3132918 flags=0x0000 ifindex=20  mac=2A:45:19:B8:96:4D nodemac=8E:FD:BD:38:A1:44   
10.46.0.198:0      id=3794  sec_id=3136591 flags=0x0000 ifindex=12  mac=1A:07:F6:83:D0:FA nodemac=96:F3:11:2A:DF:0B   
10.46.0.148:0      id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:51:FF:8A:F1:AE nodemac=D6:3E:37:E6:98:EC     
172.31.168.254:0   (localhost)                                                                                        
10.46.0.79:0       id=78    sec_id=3136591 flags=0x0000 ifindex=14  mac=BE:A8:D1:27:14:28 nodemac=B6:D1:6F:BA:23:A6   
10.46.0.151:0      (localhost)                                                                                        
172.31.188.57:0    (localhost)                                                                                        
