[
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46ed3934_eb6d_4d5d_a235_bd89dc8dbde5.slice/cri-containerd-d5a709d31013a9da8640642307cc1dbb3248a1ffee17b80b5af9b179b277cd6b.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46ed3934_eb6d_4d5d_a235_bd89dc8dbde5.slice/cri-containerd-e512118312ed4a1fa6907db3590fe39beb0463b4bba481dd5b28c4733941a716.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46ed3934_eb6d_4d5d_a235_bd89dc8dbde5.slice/cri-containerd-5986e85b5429c3e0e0a69c8c98d0eaf83556169798affe980f0fbdbdefda9001.scope"
      }
    ],
    "ips": [
      "10.46.0.172"
    ],
    "name": "clustermesh-apiserver-66555447c9-zk7dh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4dda275_3165_4124_8ae5_26647ee1febf.slice/cri-containerd-2f85c1e4c0b1a949a0fba7ae8899d0ad0e7f560e9649498cabb570fd0219f1df.scope"
      },
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4dda275_3165_4124_8ae5_26647ee1febf.slice/cri-containerd-caeb0007299e71c1f8c658816a7472cd7dd86d66b5f4aeb90eae8b84658eb2e5.scope"
      }
    ],
    "ips": [
      "10.46.0.24"
    ],
    "name": "echo-same-node-86d9cc975c-9qvhm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod92344162_b9aa_4469_b421_e45d86d38a6f.slice/cri-containerd-d2cbb1a8913df3b15b2842ad7d306406bb9b6b72cbe8bc6bc0e93e9f6ab670ca.scope"
      }
    ],
    "ips": [
      "10.46.0.79"
    ],
    "name": "coredns-cc6ccd49c-v4dnx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16851750_fd83_4cdc_8d43_126e4e4818cc.slice/cri-containerd-e141cfc6f3610912cf012bebf2b929ef234659c1b0370af8ca33a350389412fd.scope"
      }
    ],
    "ips": [
      "10.46.0.6"
    ],
    "name": "client2-57cf4468f-m6h7n",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod179376ce_d647_433f_9714_f3eba09d4c18.slice/cri-containerd-99f00664d47afcacd9df140f8e2769236b81c00ceb08ecf0883b75c24225bb59.scope"
      }
    ],
    "ips": [
      "10.46.0.200"
    ],
    "name": "client-974f6c69d-wcm64",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7549999b_9f61_4930_8b1a_dc36682eaa90.slice/cri-containerd-dfd84a26d4fa0c4d175f66a17a1a58d825716c4286ce83704202985ed14af196.scope"
      }
    ],
    "ips": [
      "10.46.0.198"
    ],
    "name": "coredns-cc6ccd49c-knt7p",
    "namespace": "kube-system"
  }
]

