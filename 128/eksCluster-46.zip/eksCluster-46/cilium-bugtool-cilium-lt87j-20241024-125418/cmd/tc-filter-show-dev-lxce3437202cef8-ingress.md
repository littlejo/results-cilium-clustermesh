filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce3437202cef8 direct-action not_in_hw id 3339 tag b92e21087786bf4e jited 
