xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 499
ens6(5) clsact/ingress cil_from_netdev-ens6 id 509
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 490
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 482
cilium_host(7) clsact/egress cil_from_host-cilium_host id 484
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 551
lxce0bf8173a1fc(12) clsact/ingress cil_from_container-lxce0bf8173a1fc id 511
lxcd30694f1c9f5(14) clsact/ingress cil_from_container-lxcd30694f1c9f5 id 537
lxcb1f49121d3e6(18) clsact/ingress cil_from_container-lxcb1f49121d3e6 id 618
lxce3437202cef8(20) clsact/ingress cil_from_container-lxce3437202cef8 id 3339
lxcb82ce1dff6ad(22) clsact/ingress cil_from_container-lxcb82ce1dff6ad id 3353
lxcf2df55bcb90d(24) clsact/ingress cil_from_container-lxcf2df55bcb90d id 3296

flow_dissector:

netfilter:

