Endpoint ID: 78
Path: /sys/fs/bpf/tc/globals/cilium_policy_00078

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2604     26        0        
Allow    Ingress     1          ANY          NONE         disabled    155366   1791      0        
Allow    Egress      0          ANY          NONE         disabled    21255    238       0        


Endpoint ID: 230
Path: /sys/fs/bpf/tc/globals/cilium_policy_00230

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6211486   76725     0        
Allow    Ingress     1          ANY          NONE         disabled    65358     790       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 459
Path: /sys/fs/bpf/tc/globals/cilium_policy_00459

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378801   4429      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1422
Path: /sys/fs/bpf/tc/globals/cilium_policy_01422

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6091356   61715     0        
Allow    Ingress     1          ANY          NONE         disabled    5448177   57456     0        
Allow    Egress      0          ANY          NONE         disabled    7397909   72349     0        


Endpoint ID: 2064
Path: /sys/fs/bpf/tc/globals/cilium_policy_02064

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2300
Path: /sys/fs/bpf/tc/globals/cilium_policy_02300

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2642
Path: /sys/fs/bpf/tc/globals/cilium_policy_02642

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3794
Path: /sys/fs/bpf/tc/globals/cilium_policy_03794

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3292     34        0        
Allow    Ingress     1          ANY          NONE         disabled    155817   1793      0        
Allow    Egress      0          ANY          NONE         disabled    20025    224       0        


