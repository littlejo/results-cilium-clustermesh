[
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda85c83c0_6885_48a2_b9c9_978fcb802d33.slice/cri-containerd-98dbc4d2578c68157464f7e25503a53c800d0c5dc9434f6f572ca522dd9f72e4.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda85c83c0_6885_48a2_b9c9_978fcb802d33.slice/cri-containerd-83ef4995a1e9dd778f2e35533a5e1b3b1e988e24f2a66b4875f37d063ee9e298.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda85c83c0_6885_48a2_b9c9_978fcb802d33.slice/cri-containerd-59477abdbd0e30eb2ee5f6fd01e4933394ea92396c58788099c82279af493499.scope"
      }
    ],
    "ips": [
      "10.110.0.134"
    ],
    "name": "clustermesh-apiserver-84bd455bd7-knstj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9b93e46_f0fc_46a7_99c7_91c03afb87a7.slice/cri-containerd-b240e4b62aba769e5227664fba2486d3f5c9bddfcd95b91b6111ce575e88cef8.scope"
      }
    ],
    "ips": [
      "10.110.0.193"
    ],
    "name": "client-974f6c69d-svttn",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e5cd97b_4167_4e4e_bd1f_073ea4bc38c2.slice/cri-containerd-bab4e9fc3ed5162abf4495f140a9d350cb6369566e24f702823e029c1f5a8242.scope"
      }
    ],
    "ips": [
      "10.110.0.237"
    ],
    "name": "client2-57cf4468f-sd5gw",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e1e794b_faca_4436_8015_abc814b7038f.slice/cri-containerd-a2dbbbc91b1bb5f1594e66cf39dc6e02e8b87235ddbe7bccbdb8719fef3ad2c5.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e1e794b_faca_4436_8015_abc814b7038f.slice/cri-containerd-4cb2eebb9e8193c8b01df4dee390bb35d2cb55be74fb85383c80d8dee839a4e5.scope"
      }
    ],
    "ips": [
      "10.110.0.39"
    ],
    "name": "echo-same-node-86d9cc975c-96hkf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7493,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf892bff_7221_4695_b713_e91c133c71b4.slice/cri-containerd-5be80f90ba728826ff7c69e713644cf21d527b6e7bca99490c658e1c611f32db.scope"
      }
    ],
    "ips": [
      "10.110.0.241"
    ],
    "name": "coredns-cc6ccd49c-66bdg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc181e488_e04b_4012_af98_5558c2d5e389.slice/cri-containerd-de7cf901200ae46685f3e87821e35009656dbe03672609a4d0ebcf7f41cdef04.scope"
      }
    ],
    "ips": [
      "10.110.0.200"
    ],
    "name": "coredns-cc6ccd49c-52tmw",
    "namespace": "kube-system"
  }
]

