CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf892bff_7221_4695_b713_e91c133c71b4.slice/cri-containerd-5be80f90ba728826ff7c69e713644cf21d527b6e7bca99490c658e1c611f32db.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf892bff_7221_4695_b713_e91c133c71b4.slice/cri-containerd-e15515737084defb4972a8eeefd1073a4d59ac7221ee11a84049aa1151f93185.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc181e488_e04b_4012_af98_5558c2d5e389.slice/cri-containerd-de7cf901200ae46685f3e87821e35009656dbe03672609a4d0ebcf7f41cdef04.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc181e488_e04b_4012_af98_5558c2d5e389.slice/cri-containerd-25d96ab2144bac559e091888a843ae84403b5c17f98c269574d9a48fb56d7b8f.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e3b813c_196f_43f3_9007_2a638831390c.slice/cri-containerd-c1c5582fa9261094fa51821ff513b6d67e941e99990de80c8ccb551e86c938c7.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e3b813c_196f_43f3_9007_2a638831390c.slice/cri-containerd-4b16b35e9f1bdbd32c8f1cd4142a5e96dc8934e08587d1801f881b099df01d1a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbcc6c7d8_fc59_410a_8ea6_0c904b63bc25.slice/cri-containerd-2a2cf5ae3028cc419ce72bb727680ece41b2b8aa7bfb499fb088dccbacfc6f57.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbcc6c7d8_fc59_410a_8ea6_0c904b63bc25.slice/cri-containerd-9f6f6d22311fe2335328a144bcee72e4794f8138bbb176eec3c5894ee0f41f0a.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9b93e46_f0fc_46a7_99c7_91c03afb87a7.slice/cri-containerd-b240e4b62aba769e5227664fba2486d3f5c9bddfcd95b91b6111ce575e88cef8.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9b93e46_f0fc_46a7_99c7_91c03afb87a7.slice/cri-containerd-2c22ef55b1cc8954b8078277599ac5ad570ed3840ea9bc55415f77dd5925e4be.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e5cd97b_4167_4e4e_bd1f_073ea4bc38c2.slice/cri-containerd-bab4e9fc3ed5162abf4495f140a9d350cb6369566e24f702823e029c1f5a8242.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e5cd97b_4167_4e4e_bd1f_073ea4bc38c2.slice/cri-containerd-e3ba3a15aa204d958690a30149cd13729c8304c4a4da7e5088ae4f78514a5589.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda85c83c0_6885_48a2_b9c9_978fcb802d33.slice/cri-containerd-59477abdbd0e30eb2ee5f6fd01e4933394ea92396c58788099c82279af493499.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda85c83c0_6885_48a2_b9c9_978fcb802d33.slice/cri-containerd-83ef4995a1e9dd778f2e35533a5e1b3b1e988e24f2a66b4875f37d063ee9e298.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda85c83c0_6885_48a2_b9c9_978fcb802d33.slice/cri-containerd-98dbc4d2578c68157464f7e25503a53c800d0c5dc9434f6f572ca522dd9f72e4.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda85c83c0_6885_48a2_b9c9_978fcb802d33.slice/cri-containerd-b08036cc6b72c0ea59b6fa46b450346d67079e7922d2d5bfa5bccffccaf11eeb.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf03a30c0_7aa3_4ce3_8f4c_5dbb662dff00.slice/cri-containerd-dff0fbaf82815df7f5f0b1f1410e07ea7a703d4d29267418758a1e89878e0bc0.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf03a30c0_7aa3_4ce3_8f4c_5dbb662dff00.slice/cri-containerd-d103c93ef4da0229c3665252732a90bcf8695d7eb6bffe94a8254167110884dd.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83ee4bda_e1ff_43d0_96ff_f48835962843.slice/cri-containerd-b19d87d1981023b39362148acc266434cabc6642ff8f4beeab21b438e09bf6e8.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83ee4bda_e1ff_43d0_96ff_f48835962843.slice/cri-containerd-4a60ef6767738cd831ba5a9904eb7609eb467d0976f88f7c5ac70d3a0ea1df49.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e1e794b_faca_4436_8015_abc814b7038f.slice/cri-containerd-4cb2eebb9e8193c8b01df4dee390bb35d2cb55be74fb85383c80d8dee839a4e5.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e1e794b_faca_4436_8015_abc814b7038f.slice/cri-containerd-a2dbbbc91b1bb5f1594e66cf39dc6e02e8b87235ddbe7bccbdb8719fef3ad2c5.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e1e794b_faca_4436_8015_abc814b7038f.slice/cri-containerd-139b7106346200b53de164b4931f9a88d13ec8c54de011f55f2274f2a40efcd7.scope
    720      cgroup_device   multi                                          
