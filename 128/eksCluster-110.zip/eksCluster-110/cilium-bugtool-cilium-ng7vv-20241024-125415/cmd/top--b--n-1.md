top - 12:54:16 up 31 min,  0 users,  load average: 0.33, 0.48, 0.34
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 24.1 us, 31.0 sy,  0.0 ni, 41.4 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    293.4 free,   1045.6 used,   2497.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2609.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 294356  79168 S   6.7   7.5   1:02.02 cilium-+
   3242 root      20   0 1240432  16476  11292 S   6.7   0.4   0:00.03 cilium-+
    395 root      20   0 1229744   9160   2924 S   0.0   0.2   0:04.33 cilium-+
   3247 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3270 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3309 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3328 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
