key: 52 00 00 00  value: 16 02 00 00
key: 32 03 00 00  value: 7e 02 00 00
key: 35 03 00 00  value: 2e 0d 00 00
key: fb 03 00 00  value: 2a 02 00 00
key: f2 05 00 00  value: 24 0d 00 00
key: ad 06 00 00  value: 2e 02 00 00
key: 07 0e 00 00  value: f2 0c 00 00
Found 7 elements
