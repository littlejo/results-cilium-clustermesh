Node 0, zone      DMA    169     51     23      2      0      4      8      1      3      3     42 
Node 0, zone   Normal    181     15     13     19     27     12      8      4      3      5      5 
