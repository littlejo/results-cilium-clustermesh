filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcaf9f4d3ae3a9 direct-action not_in_hw id 3357 tag 61f75bf3c4103c73 jited 
