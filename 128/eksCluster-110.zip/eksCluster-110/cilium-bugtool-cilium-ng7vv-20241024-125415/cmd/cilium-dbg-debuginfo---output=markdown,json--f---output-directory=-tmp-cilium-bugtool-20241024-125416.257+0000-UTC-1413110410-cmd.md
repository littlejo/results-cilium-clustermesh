markdown output at /tmp/cilium-bugtool-20241024-125416.257+0000-UTC-1413110410/cmd/cilium-debuginfo-20241024-125447.155+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.257+0000-UTC-1413110410/cmd/cilium-debuginfo-20241024-125447.155+0000-UTC.json
