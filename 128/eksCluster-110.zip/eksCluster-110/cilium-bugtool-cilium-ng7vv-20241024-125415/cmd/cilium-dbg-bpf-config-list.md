KEY             VALUE
AgentLiveness   1895503157222
UTimeOffset     3378462093750000
