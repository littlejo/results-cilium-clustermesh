IP ADDRESS         LOCAL ENDPOINT INFO
10.110.0.200:0     id=1709  sec_id=7333905 flags=0x0000 ifindex=14  mac=16:A5:2A:23:EE:6F nodemac=C6:E0:80:33:2D:78   
10.110.0.134:0     id=818   sec_id=7276234 flags=0x0000 ifindex=18  mac=C2:39:5F:D5:93:CB nodemac=66:BB:91:BD:25:BB   
172.31.184.30:0    (localhost)                                                                                        
10.110.0.39:0      id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC   
10.110.0.241:0     id=82    sec_id=7333905 flags=0x0000 ifindex=12  mac=9A:34:AA:70:6E:FA nodemac=9A:F8:65:93:21:95   
172.31.132.102:0   (localhost)                                                                                        
10.110.0.37:0      (localhost)                                                                                        
10.110.0.193:0     id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9   
10.110.0.158:0     id=1019  sec_id=4     flags=0x0000 ifindex=10  mac=7A:97:0F:88:1D:40 nodemac=12:DF:6A:8A:83:99     
10.110.0.237:0     id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88   
