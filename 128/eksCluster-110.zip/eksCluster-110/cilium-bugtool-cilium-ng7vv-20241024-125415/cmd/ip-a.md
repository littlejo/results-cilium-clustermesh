1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:48:0e:50:a8:71 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.132.102/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3546sec preferred_lft 3546sec
    inet6 fe80::448:eff:fe50:a871/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e7:78:5f:41:9d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.184.30/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4e7:78ff:fe5f:419d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:79:c3:56:4a:82 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f079:c3ff:fe56:4a82/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:6f:d6:86:9f:c1 brd ff:ff:ff:ff:ff:ff
    inet 10.110.0.37/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::bc6f:d6ff:fe86:9fc1/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 32:ae:c7:21:77:f4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::30ae:c7ff:fe21:77f4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:df:6a:8a:83:99 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::10df:6aff:fe8a:8399/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca7108a94d785@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:f8:65:93:21:95 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::98f8:65ff:fe93:2195/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf2d359fa25d1@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:e0:80:33:2d:78 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c4e0:80ff:fe33:2d78/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3a9e776b1cf4@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:bb:91:bd:25:bb brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::64bb:91ff:febd:25bb/64 scope link 
       valid_lft forever preferred_lft forever
20: lxce353469764c7@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:86:6e:9a:32:f9 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::8086:6eff:fe9a:32f9/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcaf9f4d3ae3a9@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:32:25:28:f7:88 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::2032:25ff:fe28:f788/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc08f570599c0f@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:6f:ae:4b:ae:fc brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::c86f:aeff:fe4b:aefc/64 scope link 
       valid_lft forever preferred_lft forever
