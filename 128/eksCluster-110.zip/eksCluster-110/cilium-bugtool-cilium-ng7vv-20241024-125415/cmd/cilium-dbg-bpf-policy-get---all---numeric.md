Endpoint ID: 82
Path: /sys/fs/bpf/tc/globals/cilium_policy_00082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4500     44        0        
Allow    Ingress     1          ANY          NONE         disabled    127021   1456      0        
Allow    Egress      0          ANY          NONE         disabled    19185    212       0        


Endpoint ID: 609
Path: /sys/fs/bpf/tc/globals/cilium_policy_00609

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 818
Path: /sys/fs/bpf/tc/globals/cilium_policy_00818

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6092245   60277     0        
Allow    Ingress     1          ANY          NONE         disabled    5055760   53162     0        
Allow    Egress      0          ANY          NONE         disabled    5917580   59340     0        


Endpoint ID: 821
Path: /sys/fs/bpf/tc/globals/cilium_policy_00821

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1019
Path: /sys/fs/bpf/tc/globals/cilium_policy_01019

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6241461   77008     0        
Allow    Ingress     1          ANY          NONE         disabled    62635     759       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1522
Path: /sys/fs/bpf/tc/globals/cilium_policy_01522

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1709
Path: /sys/fs/bpf/tc/globals/cilium_policy_01709

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1396     16        0        
Allow    Ingress     1          ANY          NONE         disabled    126889   1454      0        
Allow    Egress      0          ANY          NONE         disabled    16974    185       0        


Endpoint ID: 3591
Path: /sys/fs/bpf/tc/globals/cilium_policy_03591

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376958   4393      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


