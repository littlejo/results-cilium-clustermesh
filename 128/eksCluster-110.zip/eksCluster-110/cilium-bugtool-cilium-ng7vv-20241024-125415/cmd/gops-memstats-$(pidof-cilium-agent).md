alloc: 78.31MB (82114088 bytes)
total-alloc: 3.06GB (3283546264 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 74667337
frees: 74090492
heap-alloc: 78.31MB (82114088 bytes)
heap-sys: 176.92MB (185516032 bytes)
heap-idle: 53.16MB (55746560 bytes)
heap-in-use: 123.76MB (129769472 bytes)
heap-released: 7.70MB (8069120 bytes)
heap-objects: 576845
stack-in-use: 35.03MB (36732928 bytes)
stack-sys: 35.03MB (36732928 bytes)
stack-mspan-inuse: 2.04MB (2140960 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 963.84KB (986969 bytes)
gc-sys: 5.54MB (5813440 bytes)
next-gc: when heap-alloc >= 148.51MB (155728824 bytes)
last-gc: 2024-10-24 12:54:43.484907135 +0000 UTC
gc-pause-total: 11.579917ms
gc-pause: 67505
gc-pause-end: 1729774483484907135
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.000698564940418337
enable-gc: true
debug-gc: false
