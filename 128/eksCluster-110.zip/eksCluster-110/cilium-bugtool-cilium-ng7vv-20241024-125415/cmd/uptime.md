 12:54:16 up 31 min,  0 users,  load average: 0.33, 0.48, 0.34
