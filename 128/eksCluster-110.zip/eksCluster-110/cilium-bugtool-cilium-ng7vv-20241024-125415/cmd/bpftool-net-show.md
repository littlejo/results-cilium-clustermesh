xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 590
ens6(5) clsact/ingress cil_from_netdev-ens6 id 593
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 578
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 576
cilium_host(7) clsact/egress cil_from_host-cilium_host id 573
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 503
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 504
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 551
lxca7108a94d785(12) clsact/ingress cil_from_container-lxca7108a94d785 id 530
lxcf2d359fa25d1(14) clsact/ingress cil_from_container-lxcf2d359fa25d1 id 563
lxc3a9e776b1cf4(18) clsact/ingress cil_from_container-lxc3a9e776b1cf4 id 644
lxce353469764c7(20) clsact/ingress cil_from_container-lxce353469764c7 id 3365
lxcaf9f4d3ae3a9(22) clsact/ingress cil_from_container-lxcaf9f4d3ae3a9 id 3357
lxc08f570599c0f(24) clsact/ingress cil_from_container-lxc08f570599c0f id 3302

flow_dissector:

netfilter:

