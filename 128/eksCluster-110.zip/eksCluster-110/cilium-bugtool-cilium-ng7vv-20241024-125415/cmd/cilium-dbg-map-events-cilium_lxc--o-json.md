{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.350Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.363Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.987Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.998Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.032Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.055Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.073Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.325Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.329Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.389Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.426Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.464Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.049Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.137Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.154Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.214Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.233Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.425Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.429Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.488Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.515Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.564Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.124Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.129Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.164Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.175Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.216Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.220Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.257Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.483Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.502Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.535Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.614Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.623Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.155Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.156Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.208Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.212Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.258Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.274Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.355Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.574Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.578Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.639Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.643Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.690Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.106Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.117Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.167Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.174Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.206Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.442Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.444Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.491Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.494Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.537Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.850Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.893Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.908Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.941Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.954Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.978Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.240Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.244Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.344Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.351Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.391Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.716Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.723Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.755Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.781Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.799Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.047Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.057Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.122Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.141Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.164Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.532Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.585Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.607Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.646Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.673Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.683Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.920Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.925Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.969Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.983Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.020Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.387Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.489Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.519Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.561Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.567Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.598Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.792Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.793Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.839Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.867Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.897Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.224Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.255Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.265Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.311Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.321Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.348Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.595Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.617Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.644Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.687Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.699Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.048Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.058Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.099Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.112Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.137Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.417Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.434Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.463Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.509Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.106Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.109Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.139Z",
  "value": "id=3591  sec_id=7319895 flags=0x0000 ifindex=24  mac=B6:F1:7F:6D:84:43 nodemac=CA:6F:AE:4B:AE:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.143Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.179Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.456Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.462Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.178Z",
  "value": "id=1522  sec_id=7287857 flags=0x0000 ifindex=20  mac=8A:40:98:CA:E9:21 nodemac=82:86:6E:9A:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.181Z",
  "value": "id=821   sec_id=7308813 flags=0x0000 ifindex=22  mac=C2:F5:E2:B7:39:7F nodemac=22:32:25:28:F7:88"
}

