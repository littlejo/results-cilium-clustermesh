USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3270  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3248  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3247  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3242  0.0  0.3 1240432 15592 ?       Dsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3297  0.0  0.0   6408  1632 ?        R    12:54   0:00  \_ ps auxfw
root        3298  0.0  0.3 1240432 15592 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3232  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3226  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.7  7.3 1539060 289868 ?      Ssl  12:32   1:01 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.3  0.2 1229744 9160 ?        Sl   12:32   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
