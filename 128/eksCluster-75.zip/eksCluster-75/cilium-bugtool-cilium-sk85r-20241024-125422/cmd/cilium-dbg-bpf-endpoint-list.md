IP ADDRESS         LOCAL ENDPOINT INFO
172.31.218.106:0   (localhost)                                                                                        
10.75.0.27:0       id=1729  sec_id=5025907 flags=0x0000 ifindex=12  mac=7E:0D:0F:2A:F7:43 nodemac=A2:7E:95:44:CB:F7   
10.75.0.253:0      id=2552  sec_id=5026816 flags=0x0000 ifindex=24  mac=6A:78:78:CE:F4:9C nodemac=AE:31:A4:96:00:FB   
10.75.0.130:0      id=1503  sec_id=5008796 flags=0x0000 ifindex=20  mac=8A:56:29:2A:C3:6D nodemac=36:44:0D:58:6F:38   
10.75.0.238:0      id=1432  sec_id=4995656 flags=0x0000 ifindex=22  mac=62:80:68:89:28:51 nodemac=66:F3:3C:AC:A8:6D   
10.75.0.56:0       id=2334  sec_id=5013326 flags=0x0000 ifindex=18  mac=CE:AA:39:4F:F4:A8 nodemac=E2:67:3F:09:F6:A4   
172.31.199.151:0   (localhost)                                                                                        
10.75.0.100:0      id=394   sec_id=4     flags=0x0000 ifindex=10  mac=1E:62:45:46:2B:38 nodemac=52:B8:89:6C:93:EC     
10.75.0.216:0      id=105   sec_id=5025907 flags=0x0000 ifindex=14  mac=66:CA:7D:2D:FD:78 nodemac=76:C8:A6:04:80:B4   
10.75.0.213:0      (localhost)                                                                                        
