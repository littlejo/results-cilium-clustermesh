USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3198  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3186  0.0  0.4 1240432 16104 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3217  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3218  0.0  0.0   3852  1292 ?        R    12:54   0:00  \_ bash -c hostname
root        3166  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  5.0  7.7 1539388 303896 ?      Ssl  12:29   1:13 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.3  0.2 1229744 10052 ?       Sl   12:30   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
