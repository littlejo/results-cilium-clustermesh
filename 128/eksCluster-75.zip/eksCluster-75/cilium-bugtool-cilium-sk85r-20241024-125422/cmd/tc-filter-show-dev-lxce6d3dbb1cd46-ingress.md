filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce6d3dbb1cd46 direct-action not_in_hw id 3293 tag 9b7c1f5d0d19bc3b jited 
