[
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podccf14def_db72_4edc_8dd6_02ff9984f28b.slice/cri-containerd-9066b40116902fdbe2928a506f0b70ce30240024dd678be8474c7a82bcccacc4.scope"
      }
    ],
    "ips": [
      "10.75.0.253"
    ],
    "name": "client2-57cf4468f-qfch6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f2c4db8_7fca_44b2_a378_40cd9cc940a6.slice/cri-containerd-36521ac36477f2c84bd5f1048e458ce06966f3f2c22f0967216cd54145632884.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f2c4db8_7fca_44b2_a378_40cd9cc940a6.slice/cri-containerd-391794705d0bf1bb15d26b7bf80999cb4f6f7d9bb02e5c5016f99db67bd165b8.scope"
      }
    ],
    "ips": [
      "10.75.0.238"
    ],
    "name": "echo-same-node-86d9cc975c-wrr2x",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c9866_4b35_492c_ae67_3093ea40297e.slice/cri-containerd-8e076439e61441246f782091f1c23be8e83f2c12c6bda133eab381f8cfe2d6b3.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c9866_4b35_492c_ae67_3093ea40297e.slice/cri-containerd-5482364a4319ed94c68817b16613df1ce56f34b9d459f236485dde2d653e84b9.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c9866_4b35_492c_ae67_3093ea40297e.slice/cri-containerd-579e733e16e7163453081028b4ea9e5a913ab8869c7ff59a127d6d7aa9f0ed58.scope"
      }
    ],
    "ips": [
      "10.75.0.56"
    ],
    "name": "clustermesh-apiserver-bd647cd46-t7psw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a0197ce_b7a6_40d4_b238_1e7333983983.slice/cri-containerd-aa6b28c5680a0275e006dc27a86d408edc21b835421427d3f0fe661d5d1dc3bd.scope"
      }
    ],
    "ips": [
      "10.75.0.216"
    ],
    "name": "coredns-cc6ccd49c-q26fd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e3effc1_3857_4b93_8912_327ee7592697.slice/cri-containerd-dc1131f515dfc47700853932a09dcc323035554a940593cd483c068e83958660.scope"
      }
    ],
    "ips": [
      "10.75.0.27"
    ],
    "name": "coredns-cc6ccd49c-f5jr5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ad95128_a615_479e_acda_0baead45dec9.slice/cri-containerd-88431abf9d1adce44c33624fce92ed5c4673d328f4c5639774e0cb423b6dd12e.scope"
      }
    ],
    "ips": [
      "10.75.0.130"
    ],
    "name": "client-974f6c69d-rd22p",
    "namespace": "cilium-test-1"
  }
]

