 12:54:24 up 32 min,  0 users,  load average: 0.33, 0.53, 0.35
