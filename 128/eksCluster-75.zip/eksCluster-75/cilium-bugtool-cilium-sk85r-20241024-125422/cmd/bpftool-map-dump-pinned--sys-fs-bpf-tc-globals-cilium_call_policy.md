key: 69 00 00 00  value: 07 02 00 00
key: 8a 01 00 00  value: 1a 02 00 00
key: 98 05 00 00  value: dc 0c 00 00
key: df 05 00 00  value: 1f 0d 00 00
key: c1 06 00 00  value: 11 02 00 00
key: 1e 09 00 00  value: 74 02 00 00
key: f8 09 00 00  value: 1c 0d 00 00
Found 7 elements
