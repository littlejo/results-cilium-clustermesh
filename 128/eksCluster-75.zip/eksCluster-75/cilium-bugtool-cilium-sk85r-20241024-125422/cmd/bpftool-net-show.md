xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 578
ens6(5) clsact/ingress cil_from_netdev-ens6 id 586
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 572
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 561
cilium_host(7) clsact/egress cil_from_host-cilium_host id 563
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 544
lxcb7f0e6307295(12) clsact/ingress cil_from_container-lxcb7f0e6307295 id 534
lxc0fbbf1f2c768(14) clsact/ingress cil_from_container-lxc0fbbf1f2c768 id 517
lxca2af36adf8e9(18) clsact/ingress cil_from_container-lxca2af36adf8e9 id 632
lxc4cedf520e033(20) clsact/ingress cil_from_container-lxc4cedf520e033 id 3344
lxce6d3dbb1cd46(22) clsact/ingress cil_from_container-lxce6d3dbb1cd46 id 3293
lxc8d2f1acfa2fc(24) clsact/ingress cil_from_container-lxc8d2f1acfa2fc id 3358

flow_dissector:

netfilter:

