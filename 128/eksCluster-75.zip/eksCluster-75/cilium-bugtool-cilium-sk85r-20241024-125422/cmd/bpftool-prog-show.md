35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:20+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:20+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:25+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:30:07+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:30:07+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:30:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag f07f7d1f92704d26  gpl
	loaded_at 2024-10-24T12:30:07+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
510: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 153
512: sched_cls  name tail_ipv4_ct_ingress  tag 9ab62c4146a7e177  gpl
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 155
513: sched_cls  name tail_handle_arp  tag 9c8d12542fa69869  gpl
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 156
514: sched_cls  name __send_drop_notify  tag bcd374e25fc6fbaa  gpl
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 157
515: sched_cls  name tail_ipv4_to_endpoint  tag a2629499fbdfede3  gpl
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 158
516: sched_cls  name tail_handle_ipv4  tag d49a1dd426688a93  gpl
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 159
517: sched_cls  name cil_from_container  tag f5cada0374416bb5  gpl
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 160
518: sched_cls  name tail_ipv4_ct_egress  tag 96074a0304138832  gpl
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 161
519: sched_cls  name handle_policy  tag 9dd052d964fac15f  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 162
520: sched_cls  name tail_handle_ipv4_cont  tag 09c1f22f094c545b  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 163
521: sched_cls  name tail_handle_arp  tag 06a86d637f23672a  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 165
522: sched_cls  name tail_ipv4_ct_ingress  tag 223c03d70ae616e4  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 166
523: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
526: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
527: sched_cls  name tail_ipv4_ct_egress  tag 96074a0304138832  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 167
529: sched_cls  name handle_policy  tag 2ddeebb390cf2ff8  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,101,39,84,75,40,37,38
	btf_id 169
530: sched_cls  name tail_handle_ipv4_cont  tag 48c2d2bab84a748b  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,109,41,101,82,83,39,76,74,77,110,40,37,38,81
	btf_id 170
531: sched_cls  name tail_ipv4_to_endpoint  tag 13b247d396dcb235  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,101,39,110,40,37,38
	btf_id 171
532: sched_cls  name __send_drop_notify  tag 0937eea12c580c27  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 172
533: sched_cls  name tail_handle_ipv4  tag a7124fef1bafcabb  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 173
534: sched_cls  name cil_from_container  tag 47448c1c43f63ad0  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 174
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 175
536: sched_cls  name tail_handle_ipv4_cont  tag 2880f068ce73e517  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,112,41,100,82,83,39,76,74,77,113,40,37,38,81
	btf_id 177
537: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 178
538: sched_cls  name handle_policy  tag b0c389dcf3bb76fa  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,113,82,83,112,41,80,100,39,84,75,40,37,38
	btf_id 179
540: sched_cls  name tail_ipv4_ct_ingress  tag 2b071f69646fe9a9  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 181
541: sched_cls  name __send_drop_notify  tag 3a052f97a1d71c8f  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 182
542: sched_cls  name tail_handle_ipv4  tag 28439eb46cf38fd4  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 183
543: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 184
544: sched_cls  name cil_from_container  tag 2430533843e35837  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 113,76
	btf_id 185
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: sched_cls  name tail_ipv4_to_endpoint  tag 2c4bd8c0020f1e42  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,112,41,82,83,80,100,39,113,40,37,38
	btf_id 186
550: sched_cls  name tail_handle_arp  tag 463236789620d963  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name tail_handle_ipv4_from_host  tag 580b96aec706c123  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 189
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
562: sched_cls  name __send_drop_notify  tag 254f6df48864055e  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
563: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 193
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 195
566: sched_cls  name __send_drop_notify  tag 254f6df48864055e  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 197
569: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 200
570: sched_cls  name tail_handle_ipv4_from_host  tag 580b96aec706c123  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 201
572: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
573: sched_cls  name __send_drop_notify  tag 254f6df48864055e  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
576: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 208
577: sched_cls  name tail_handle_ipv4_from_host  tag 580b96aec706c123  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
578: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 210
581: sched_cls  name __send_drop_notify  tag 254f6df48864055e  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
584: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 217
585: sched_cls  name tail_handle_ipv4_from_host  tag 580b96aec706c123  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 218
586: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 219
626: sched_cls  name tail_ipv4_to_endpoint  tag 116bf1a9f704db98  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 233
627: sched_cls  name tail_ipv4_ct_ingress  tag a9e80620155bd835  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 234
628: sched_cls  name handle_policy  tag 7541baf64dbefb42  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 235
629: sched_cls  name tail_handle_ipv4  tag 2d77848a082d1cbf  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 236
631: sched_cls  name tail_ipv4_ct_egress  tag 1a1df1292f5862dc  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 238
632: sched_cls  name cil_from_container  tag 1275963d3544ab66  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 239
633: sched_cls  name tail_handle_ipv4_cont  tag a88960a489d0309b  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 240
634: sched_cls  name tail_handle_arp  tag 1cc71a1108cfdccd  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 241
635: sched_cls  name __send_drop_notify  tag ba3b7b3209e77f53  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 242
636: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
698: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
701: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
716: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3289: sched_cls  name tail_ipv4_ct_ingress  tag 33bb669642bf4cfc  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3077
3290: sched_cls  name tail_handle_ipv4  tag e5959b4b8b509398  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3078
3292: sched_cls  name handle_policy  tag 8da6d06e34c455ba  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,148,39,84,75,40,37,38
	btf_id 3081
3293: sched_cls  name cil_from_container  tag 9b7c1f5d0d19bc3b  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3083
3294: sched_cls  name tail_handle_ipv4_cont  tag 35a2003e8e066f22  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,148,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3084
3296: sched_cls  name tail_ipv4_ct_egress  tag d9fd73572c3f3b5c  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3085
3297: sched_cls  name tail_handle_arp  tag c44aa634019f2f69  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3087
3298: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3088
3301: sched_cls  name tail_ipv4_to_endpoint  tag 5865979f4a60e768  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,148,39,627,40,37,38
	btf_id 3089
3303: sched_cls  name __send_drop_notify  tag 87ddd97469f8329d  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3093
3344: sched_cls  name cil_from_container  tag 7f3a47c62a92dcab  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3139
3345: sched_cls  name tail_ipv4_ct_egress  tag daf324e8582b5fd1  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3140
3346: sched_cls  name tail_ipv4_ct_ingress  tag 9975cec1c3948392  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3141
3347: sched_cls  name tail_ipv4_to_endpoint  tag e93b22a89eb2a7ed  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,151,39,637,40,37,38
	btf_id 3138
3348: sched_cls  name __send_drop_notify  tag db7b39809586f830  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3142
3349: sched_cls  name __send_drop_notify  tag 059cf5e6b3d28929  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3143
3350: sched_cls  name tail_handle_ipv4_cont  tag eebb3ffa7ba05428  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,145,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3145
3351: sched_cls  name tail_handle_ipv4  tag d8e209fe1387be87  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3144
3352: sched_cls  name tail_ipv4_to_endpoint  tag a2131a69243d8e9b  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,145,39,639,40,37,38
	btf_id 3146
3353: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3148
3354: sched_cls  name tail_handle_ipv4  tag 2948475d25fd92dc  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3149
3355: sched_cls  name tail_handle_arp  tag 7ce80f9856799aca  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3150
3356: sched_cls  name handle_policy  tag e18978ed62c04df5  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,151,39,84,75,40,37,38
	btf_id 3147
3358: sched_cls  name cil_from_container  tag 8502dba6aca8a2bc  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3153
3359: sched_cls  name handle_policy  tag f7eb12ac0f1711a4  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,145,39,84,75,40,37,38
	btf_id 3151
3361: sched_cls  name tail_ipv4_ct_egress  tag 1042ae2d6e04308e  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3154
3362: sched_cls  name tail_handle_arp  tag 0087b9f604c0488a  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3156
3363: sched_cls  name tail_ipv4_ct_ingress  tag eb4a7591782dd125  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3157
3364: sched_cls  name tail_handle_ipv4_cont  tag 3d2e8146f686a763  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,151,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3158
3365: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3159
