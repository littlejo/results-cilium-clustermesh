Node 0, zone      DMA     52      2      2     18     26     10     45     14      6      3     33 
Node 0, zone   Normal    252     48     14     31     16      8      2      2      2      3      7 
