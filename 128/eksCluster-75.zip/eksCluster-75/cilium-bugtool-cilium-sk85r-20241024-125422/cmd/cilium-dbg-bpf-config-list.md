KEY             VALUE
AgentLiveness   1958150442468
UTimeOffset     3378461986328125
