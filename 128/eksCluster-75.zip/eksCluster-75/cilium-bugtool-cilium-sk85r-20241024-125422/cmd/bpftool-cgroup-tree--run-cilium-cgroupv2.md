CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e3effc1_3857_4b93_8912_327ee7592697.slice/cri-containerd-785d84210b1a3a38e78fc0bedf173256aeffce73a8448af9aeb24322a9ceb0f2.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e3effc1_3857_4b93_8912_327ee7592697.slice/cri-containerd-dc1131f515dfc47700853932a09dcc323035554a940593cd483c068e83958660.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1ddd2a6_7ab3_44cd_a593_eda7ad84cdca.slice/cri-containerd-d1517da066617a32063e50a340d00c7e06d31935afd45b9faa4fbe83029510df.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1ddd2a6_7ab3_44cd_a593_eda7ad84cdca.slice/cri-containerd-4eb1e19e2d1775d0e75bf502862d3dcc4360bd7712218471d73ba89b15f9ae34.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c0dfbd3_8476_4ede_bf5b_0b15027cb655.slice/cri-containerd-a8544a3cb4d440c3b7d44c0d914ec0d500f992bc6958380945812bd67892fe19.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c0dfbd3_8476_4ede_bf5b_0b15027cb655.slice/cri-containerd-89f17cf45342315e7a69a9ae1604863227438893d088f53fe16fe9119bc241d0.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a0197ce_b7a6_40d4_b238_1e7333983983.slice/cri-containerd-fc92d0ebd7654ed09954d11c897af085b7a5c5dbab8d7672d298606151bc7c09.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a0197ce_b7a6_40d4_b238_1e7333983983.slice/cri-containerd-aa6b28c5680a0275e006dc27a86d408edc21b835421427d3f0fe661d5d1dc3bd.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c9866_4b35_492c_ae67_3093ea40297e.slice/cri-containerd-fa5390cdfcd2d79148bb281a3fc51011c100e8bacaee9f14c55f1a6afa9dc72f.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c9866_4b35_492c_ae67_3093ea40297e.slice/cri-containerd-579e733e16e7163453081028b4ea9e5a913ab8869c7ff59a127d6d7aa9f0ed58.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c9866_4b35_492c_ae67_3093ea40297e.slice/cri-containerd-5482364a4319ed94c68817b16613df1ce56f34b9d459f236485dde2d653e84b9.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c9866_4b35_492c_ae67_3093ea40297e.slice/cri-containerd-8e076439e61441246f782091f1c23be8e83f2c12c6bda133eab381f8cfe2d6b3.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f2c4db8_7fca_44b2_a378_40cd9cc940a6.slice/cri-containerd-36521ac36477f2c84bd5f1048e458ce06966f3f2c22f0967216cd54145632884.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f2c4db8_7fca_44b2_a378_40cd9cc940a6.slice/cri-containerd-391794705d0bf1bb15d26b7bf80999cb4f6f7d9bb02e5c5016f99db67bd165b8.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f2c4db8_7fca_44b2_a378_40cd9cc940a6.slice/cri-containerd-75e7f706fbb8c4cf55aa24af94fb2c33b82946c280a56c778e48efd01d39e90d.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39b597a8_7755_4020_80b0_b94f75a445ec.slice/cri-containerd-fd78b097f513e92c9e94576f813f6251ab4fbef87011a817eab41d6fb25e0574.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39b597a8_7755_4020_80b0_b94f75a445ec.slice/cri-containerd-b3acf25333c8f44fbbcf707a4e9625f90cc0465a6a93a041f5efb737d4cba69e.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84a12fa6_8add_434c_a185_31ffd005ba2e.slice/cri-containerd-51088fda290c11dea3471da2482260bba21bbaa1347ea9549eee05472a9ac11e.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84a12fa6_8add_434c_a185_31ffd005ba2e.slice/cri-containerd-61ffa9a32696f24d076031ecf50983bb04586e54b45d607108fca518a7690bdc.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ad95128_a615_479e_acda_0baead45dec9.slice/cri-containerd-88431abf9d1adce44c33624fce92ed5c4673d328f4c5639774e0cb423b6dd12e.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ad95128_a615_479e_acda_0baead45dec9.slice/cri-containerd-ad17d4978d974e49f21bdb5486d0d5d7f24ee4086a27465d16831e1b4f7578a9.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podccf14def_db72_4edc_8dd6_02ff9984f28b.slice/cri-containerd-84655361d29f8f63319595995fd0289f6b2a0cfba1b30e597ce211315e195184.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podccf14def_db72_4edc_8dd6_02ff9984f28b.slice/cri-containerd-9066b40116902fdbe2928a506f0b70ce30240024dd678be8474c7a82bcccacc4.scope
    717      cgroup_device   multi                                          
