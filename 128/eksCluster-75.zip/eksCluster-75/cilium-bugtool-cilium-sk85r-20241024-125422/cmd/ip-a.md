1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:55:23:a9:c7:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.199.151/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3484sec preferred_lft 3484sec
    inet6 fe80::855:23ff:fea9:c72f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ca:a2:83:c8:09 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.218.106/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8ca:a2ff:fe83:c809/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:32:46:d9:4a:24 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e832:46ff:fed9:4a24/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:bb:fb:a7:10:80 brd ff:ff:ff:ff:ff:ff
    inet 10.75.0.213/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::84bb:fbff:fea7:1080/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e6:35:43:13:24:fd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e435:43ff:fe13:24fd/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:b8:89:6c:93:ec brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::50b8:89ff:fe6c:93ec/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb7f0e6307295@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:7e:95:44:cb:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a07e:95ff:fe44:cbf7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0fbbf1f2c768@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:c8:a6:04:80:b4 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::74c8:a6ff:fe04:80b4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca2af36adf8e9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:67:3f:09:f6:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e067:3fff:fe09:f6a4/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc4cedf520e033@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:44:0d:58:6f:38 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::3444:dff:fe58:6f38/64 scope link 
       valid_lft forever preferred_lft forever
22: lxce6d3dbb1cd46@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:f3:3c:ac:a8:6d brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::64f3:3cff:feac:a86d/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc8d2f1acfa2fc@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:31:a4:96:00:fb brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::ac31:a4ff:fe96:fb/64 scope link 
       valid_lft forever preferred_lft forever
