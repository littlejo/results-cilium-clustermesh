alloc: 132.64MB (139085328 bytes)
total-alloc: 3.15GB (3383604736 bytes)
sys: 227.64MB (238699860 bytes)
lookups: 0
mallocs: 76108540
frees: 74771422
heap-alloc: 132.64MB (139085328 bytes)
heap-sys: 178.64MB (187318272 bytes)
heap-idle: 20.90MB (21913600 bytes)
heap-in-use: 157.74MB (165404672 bytes)
heap-released: 5.20MB (5455872 bytes)
heap-objects: 1337118
stack-in-use: 37.31MB (39124992 bytes)
stack-sys: 37.31MB (39124992 bytes)
stack-mspan-inuse: 2.46MB (2583840 bytes)
stack-mspan-sys: 2.86MB (3002880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1227857 bytes)
gc-sys: 5.53MB (5803152 bytes)
next-gc: when heap-alloc >= 148.35MB (155556360 bytes)
last-gc: 2024-10-24 12:54:16.947589572 +0000 UTC
gc-pause-total: 38.230671ms
gc-pause: 78021
gc-pause-end: 1729774456947589572
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0007145907594486406
enable-gc: true
debug-gc: false
