Endpoint ID: 105
Path: /sys/fs/bpf/tc/globals/cilium_policy_00105

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    220182   1982      0        
Allow    Ingress     1          ANY          NONE         disabled    141740   1626      0        
Allow    Egress      0          ANY          NONE         disabled    67313    664       0        


Endpoint ID: 394
Path: /sys/fs/bpf/tc/globals/cilium_policy_00394

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6238208   77099     0        
Allow    Ingress     1          ANY          NONE         disabled    59952     722       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 468
Path: /sys/fs/bpf/tc/globals/cilium_policy_00468

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1432
Path: /sys/fs/bpf/tc/globals/cilium_policy_01432

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    381717   4453      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1503
Path: /sys/fs/bpf/tc/globals/cilium_policy_01503

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1729
Path: /sys/fs/bpf/tc/globals/cilium_policy_01729

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    215358   1950      0        
Allow    Ingress     1          ANY          NONE         disabled    142503   1642      0        
Allow    Egress      0          ANY          NONE         disabled    66733    662       0        


Endpoint ID: 2334
Path: /sys/fs/bpf/tc/globals/cilium_policy_02334

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6190254   61553     0        
Allow    Ingress     1          ANY          NONE         disabled    5673879   58260     0        
Allow    Egress      0          ANY          NONE         disabled    6049305   60731     0        


Endpoint ID: 2552
Path: /sys/fs/bpf/tc/globals/cilium_policy_02552

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


