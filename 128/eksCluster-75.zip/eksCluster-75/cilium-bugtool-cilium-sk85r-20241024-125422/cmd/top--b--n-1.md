top - 12:54:24 up 32 min,  0 users,  load average: 0.33, 0.53, 0.35
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.8 us, 31.0 sy,  0.0 ni, 51.7 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    281.8 free,   1058.6 used,   2495.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2596.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539388 303896  78456 S   0.0   7.7   1:13.99 cilium-+
    394 root      20   0 1229744  10052   3836 S   0.0   0.3   0:04.46 cilium-+
   3166 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3186 root      20   0 1240432  16540  11548 S   0.0   0.4   0:00.02 cilium-+
   3198 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3229 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3247 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
