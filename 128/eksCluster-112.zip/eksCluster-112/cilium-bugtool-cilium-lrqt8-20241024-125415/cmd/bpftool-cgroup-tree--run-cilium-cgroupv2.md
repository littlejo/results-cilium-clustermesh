CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8dc5f2c0_aaf9_498a_9198_f78043a7fb5d.slice/cri-containerd-8816e22dcd3041a7750a2b747aea50aeb3dbd091541c00b82d4319718201cc3e.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8dc5f2c0_aaf9_498a_9198_f78043a7fb5d.slice/cri-containerd-fc870b6ce44d321f930cbb9c5382a554ad7e13a6af6dbcbbbc385a55f2c81c29.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10fc11c1_22e8_43af_8802_d613e8254a61.slice/cri-containerd-f1d6c97e6d8f27d43ac56fd6668aca3f5f072b29816dabc29f177108e6ba7bbb.scope
    525      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10fc11c1_22e8_43af_8802_d613e8254a61.slice/cri-containerd-5cb0f93e87c0c728d6046545f2a886bd50856260f73841c526d2a5757b78a807.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1510480e_8856_4b67_9704_2245df977a5d.slice/cri-containerd-2edce443f6fb4226c2a4e788e539ab60d51a6ddb41b9fce9b9ab577ec6a56c7d.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1510480e_8856_4b67_9704_2245df977a5d.slice/cri-containerd-17298441d38e0799881d1fa0476386f52e79e715f5a5c10f374e64f1404b2680.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod612111c9_5c7b_4ea8_a31b_3cc89c4e5446.slice/cri-containerd-4a28b14d3a15adaeec186d0fc78c5a49a4bac8009284e884ba06be4779029798.scope
    518      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod612111c9_5c7b_4ea8_a31b_3cc89c4e5446.slice/cri-containerd-f54a5456835c69816ba100ca541071e5f57b59db6a0ff943f14a144a2ea806cf.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78d9164d_bbb3_4e76_8f9b_717d0c9e41cf.slice/cri-containerd-30f583f6947cb4a5d2389e5b9c23bd6b9583e369af4f5b8a43b770584c679c48.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78d9164d_bbb3_4e76_8f9b_717d0c9e41cf.slice/cri-containerd-b2f78d4cab700bd4781d24f4d0b85913b975b06872130c979edec177c55e350a.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podddf5fd2b_97b6_4d5d_b6ec_39f070ae83d9.slice/cri-containerd-ffaec65c5cbb48f524b99ccc334889be60d2e4a21715d885ee89fd40b7f3bdba.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podddf5fd2b_97b6_4d5d_b6ec_39f070ae83d9.slice/cri-containerd-a09def86bf52af7aa84f5289fe694d671dabf7fffa951b0444f08dbe2bd5baf1.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4cb27cfb_8324_4775_b60c_f43b83238ef1.slice/cri-containerd-ba9a079d0ba6e2ac18435dff3801e7441a11dc823a8ca1034ad0f0b0e25d63e9.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4cb27cfb_8324_4775_b60c_f43b83238ef1.slice/cri-containerd-73a51eed8dc0233b342a6db8e88dce458feb0fc4c0c87c167d13785334457682.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode32681e8_e930_4ad4_8eba_4db377467cc2.slice/cri-containerd-fd7a4d01824b6a84a99e35e45ab634f10db35859edd61589e24db5f55f184c76.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode32681e8_e930_4ad4_8eba_4db377467cc2.slice/cri-containerd-e6b6f21386a8c9721b7e2a11e7e040dc1039ff34a492043ff4a7321766e2e990.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode32681e8_e930_4ad4_8eba_4db377467cc2.slice/cri-containerd-f2cff6d15d6af3a7bcc75d8b7abe1308a5890ed5bbb28df66b93244443cfb953.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ce9e03c_b2d4_4ec7_b584_0dbf2d2ad0f9.slice/cri-containerd-928c14476b1b2860723c63fe8b1f8bb16883ae9cf78b1a950dbdbed6af4def32.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ce9e03c_b2d4_4ec7_b584_0dbf2d2ad0f9.slice/cri-containerd-ae10f919892a63515323d322f7f5740ae678d8bd2973a3f6ceb17100dca20241.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb48e3c9_3ddf_4200_8be2_a634216ba39a.slice/cri-containerd-b641dd5abd0040c71693f00a25f56cb223e2877f697006d17daad44c854860e1.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb48e3c9_3ddf_4200_8be2_a634216ba39a.slice/cri-containerd-0ff130f8ef62baa38b508b8ba91605500c13a0b7c2271349f39edb414e1ffc9a.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb48e3c9_3ddf_4200_8be2_a634216ba39a.slice/cri-containerd-bbf3baa6727e875810b5d631ab1d57ebb032dfcc079fca09cb571b23564a24b4.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb48e3c9_3ddf_4200_8be2_a634216ba39a.slice/cri-containerd-163542ba2c300b9ca39455d94b238614d83d81d421dbb781f2602ec5fbe42379.scope
    650      cgroup_device   multi                                          
