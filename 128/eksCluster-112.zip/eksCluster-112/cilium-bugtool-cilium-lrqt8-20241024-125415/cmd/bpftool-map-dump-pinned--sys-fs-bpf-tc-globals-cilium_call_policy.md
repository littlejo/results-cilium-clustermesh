key: 19 00 00 00  value: 6e 02 00 00
key: 2a 01 00 00  value: 1c 02 00 00
key: 9a 02 00 00  value: 02 0d 00 00
key: ce 02 00 00  value: 13 0d 00 00
key: 97 03 00 00  value: fc 01 00 00
key: a7 0d 00 00  value: d9 0c 00 00
key: 20 0f 00 00  value: 15 02 00 00
Found 7 elements
