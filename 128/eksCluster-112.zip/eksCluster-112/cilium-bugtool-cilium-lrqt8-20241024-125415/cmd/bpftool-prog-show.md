29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:17+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:17+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:21+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name tail_handle_ipv4  tag 00a9aef2b4de92e7  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
479: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
480: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:32:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
504: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 153
505: sched_cls  name __send_drop_notify  tag 222a9eefab8e6150  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 154
506: sched_cls  name tail_ipv4_to_endpoint  tag 127155275e26eee4  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 155
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 156
508: sched_cls  name handle_policy  tag 9223dc92f0ec7fd8  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 157
509: sched_cls  name tail_handle_ipv4_cont  tag 0cccf15b8325b852  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 158
510: sched_cls  name cil_from_container  tag 6e9b12683742a781  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 108,76
	btf_id 159
511: sched_cls  name tail_handle_ipv4  tag eb8db7d8f0f80ac3  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 160
513: sched_cls  name tail_ipv4_ct_ingress  tag 260f12a090c6e78f  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 162
514: sched_cls  name tail_handle_arp  tag b77ec808158a5baa  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 163
515: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
518: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
519: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 165
520: sched_cls  name __send_drop_notify  tag 203c58f1587771fe  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 166
521: sched_cls  name tail_ipv4_ct_ingress  tag 048496d2c92c9016  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 167
522: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
525: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
526: sched_cls  name cil_from_container  tag e67ef9710994ab7f  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 168
527: sched_cls  name tail_ipv4_ct_egress  tag 6304dc0bcc3ea4c2  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 169
528: sched_cls  name tail_handle_ipv4_cont  tag 34f2791f137b0e23  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,110,41,101,82,83,39,76,74,77,109,40,37,38,81
	btf_id 170
529: sched_cls  name tail_handle_arp  tag 92c183ab369687eb  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 171
530: sched_cls  name tail_ipv4_to_endpoint  tag c3286ae6133fe028  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,110,41,82,83,80,101,39,109,40,37,38
	btf_id 172
532: sched_cls  name tail_handle_ipv4  tag 879a90c90548acfa  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 174
533: sched_cls  name handle_policy  tag 47a008d1f3dc4384  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,110,41,80,101,39,84,75,40,37,38
	btf_id 175
534: sched_cls  name tail_handle_ipv4  tag ae936f72552b5fdf  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 177
535: sched_cls  name tail_ipv4_ct_egress  tag 6304dc0bcc3ea4c2  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 178
536: sched_cls  name tail_ipv4_to_endpoint  tag e16cef04366957a7  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,114,41,82,83,80,100,39,113,40,37,38
	btf_id 179
537: sched_cls  name tail_handle_ipv4_cont  tag 67bef908e6920227  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,114,41,100,82,83,39,76,74,77,113,40,37,38,81
	btf_id 180
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 181
539: sched_cls  name tail_ipv4_ct_ingress  tag bb9c8c379534605c  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 182
540: sched_cls  name handle_policy  tag b862f597a6642b1c  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,114,41,80,100,39,84,75,40,37,38
	btf_id 183
541: sched_cls  name __send_drop_notify  tag 47cde7e10502b66f  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 184
542: sched_cls  name cil_from_container  tag 6fabd2a1165b5cbf  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 185
544: sched_cls  name tail_handle_arp  tag a47de0b3d8b813d9  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 187
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
553: sched_cls  name __send_drop_notify  tag 235b45c7ed8c93e7  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
554: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 190
556: sched_cls  name tail_handle_ipv4_from_host  tag cfa2bc98f303e51f  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 192
557: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 193
558: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 194
561: sched_cls  name __send_drop_notify  tag 235b45c7ed8c93e7  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
564: sched_cls  name tail_handle_ipv4_from_host  tag cfa2bc98f303e51f  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 201
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
566: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
567: sched_cls  name __send_drop_notify  tag 235b45c7ed8c93e7  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
570: sched_cls  name tail_handle_ipv4_from_host  tag cfa2bc98f303e51f  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 208
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 209
573: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 211
574: sched_cls  name __send_drop_notify  tag 235b45c7ed8c93e7  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
577: sched_cls  name tail_handle_ipv4_from_host  tag cfa2bc98f303e51f  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 216
578: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 217
580: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:47+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 219
620: sched_cls  name tail_handle_ipv4  tag 2703b079fcb15160  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 233
621: sched_cls  name tail_handle_arp  tag 77344edf3d215b3b  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 234
622: sched_cls  name handle_policy  tag db7bfe47c1cd7097  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 235
623: sched_cls  name cil_from_container  tag 7f8c484e61173f5f  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 236
624: sched_cls  name __send_drop_notify  tag 93b07a80d84de85c  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 237
625: sched_cls  name tail_ipv4_ct_egress  tag 3ce9d9935997d314  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 238
627: sched_cls  name tail_ipv4_ct_ingress  tag 1e0e3c4cb26d7881  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 240
628: sched_cls  name tail_ipv4_to_endpoint  tag f2e69fe93ff33c50  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 241
629: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 242
630: sched_cls  name tail_handle_ipv4_cont  tag 2625a01ebc13e785  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 243
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
692: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
695: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
696: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
699: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
700: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
703: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
712: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
715: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3272: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,625
	btf_id 3065
3275: sched_cls  name tail_handle_ipv4_cont  tag b42cb6ab1e4fea6c  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,626,41,148,82,83,39,76,74,77,625,40,37,38,81
	btf_id 3069
3278: sched_cls  name tail_handle_ipv4  tag 788053ce0e5e8a98  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,625
	btf_id 3071
3279: sched_cls  name tail_handle_arp  tag e96541462ab62731  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,625
	btf_id 3074
3280: sched_cls  name cil_from_container  tag 8b2a1f5b994cbe5d  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 625,76
	btf_id 3075
3281: sched_cls  name __send_drop_notify  tag 27ca10005df935b1  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3076
3282: sched_cls  name tail_ipv4_ct_egress  tag 52b7086168a7cacf  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,625,82,83,626,84
	btf_id 3077
3285: sched_cls  name tail_ipv4_ct_ingress  tag 3f3cd9f6b7bd21c7  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,625,82,83,626,84
	btf_id 3078
3289: sched_cls  name handle_policy  tag 3b270444da428adf  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,625,82,83,626,41,80,148,39,84,75,40,37,38
	btf_id 3082
3290: sched_cls  name tail_ipv4_to_endpoint  tag 5046d32116b978cb  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,626,41,82,83,80,148,39,625,40,37,38
	btf_id 3085
3327: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3127
3328: sched_cls  name tail_handle_arp  tag 3669cec71d78c45a  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3128
3329: sched_cls  name tail_ipv4_ct_egress  tag dcfacae7d286350f  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3129
3330: sched_cls  name handle_policy  tag 6afcdda1320ed6f0  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,635,82,83,636,41,80,151,39,84,75,40,37,38
	btf_id 3125
3331: sched_cls  name tail_ipv4_ct_egress  tag bf870e2973016812  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3131
3332: sched_cls  name cil_from_container  tag 0dace04adcb1e2ff  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 635,76
	btf_id 3132
3333: sched_cls  name tail_handle_ipv4  tag d4793df4bf890f6f  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3130
3334: sched_cls  name tail_handle_ipv4  tag 8e345a5e6533e9b1  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,635
	btf_id 3133
3335: sched_cls  name tail_handle_arp  tag 703289f7dce58085  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,635
	btf_id 3135
3336: sched_cls  name __send_drop_notify  tag 7baa58b6ef5f953f  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3136
3338: sched_cls  name tail_ipv4_to_endpoint  tag 6487b64d52febdf0  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,145,39,637,40,37,38
	btf_id 3134
3339: sched_cls  name tail_ipv4_ct_ingress  tag 7d283fbf26f9779f  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3138
3340: sched_cls  name tail_handle_ipv4_cont  tag 2c26a33d903d0132  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,145,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3139
3341: sched_cls  name __send_drop_notify  tag 70d3ac9424f8b464  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3141
3342: sched_cls  name cil_from_container  tag 0e223cd0e3f4fb14  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3142
3343: sched_cls  name tail_handle_ipv4_cont  tag e638e5cc4bdd5ab0  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,636,41,151,82,83,39,76,74,77,635,40,37,38,81
	btf_id 3140
3344: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,635
	btf_id 3143
3346: sched_cls  name tail_ipv4_ct_ingress  tag d88a3f6f29890dec  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3146
3347: sched_cls  name handle_policy  tag e722cb77e19d8349  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,145,39,84,75,40,37,38
	btf_id 3147
3348: sched_cls  name tail_ipv4_to_endpoint  tag cc29bb372865270e  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,636,41,82,83,80,151,39,635,40,37,38
	btf_id 3144
