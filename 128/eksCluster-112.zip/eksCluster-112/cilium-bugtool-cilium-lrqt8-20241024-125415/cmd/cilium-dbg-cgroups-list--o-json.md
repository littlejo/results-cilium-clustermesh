[
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod612111c9_5c7b_4ea8_a31b_3cc89c4e5446.slice/cri-containerd-f54a5456835c69816ba100ca541071e5f57b59db6a0ff943f14a144a2ea806cf.scope"
      }
    ],
    "ips": [
      "10.112.0.57"
    ],
    "name": "coredns-cc6ccd49c-zlcc2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10fc11c1_22e8_43af_8802_d613e8254a61.slice/cri-containerd-5cb0f93e87c0c728d6046545f2a886bd50856260f73841c526d2a5757b78a807.scope"
      }
    ],
    "ips": [
      "10.112.0.130"
    ],
    "name": "coredns-cc6ccd49c-hpk5s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podddf5fd2b_97b6_4d5d_b6ec_39f070ae83d9.slice/cri-containerd-a09def86bf52af7aa84f5289fe694d671dabf7fffa951b0444f08dbe2bd5baf1.scope"
      }
    ],
    "ips": [
      "10.112.0.121"
    ],
    "name": "client-974f6c69d-pttf7",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb48e3c9_3ddf_4200_8be2_a634216ba39a.slice/cri-containerd-163542ba2c300b9ca39455d94b238614d83d81d421dbb781f2602ec5fbe42379.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb48e3c9_3ddf_4200_8be2_a634216ba39a.slice/cri-containerd-bbf3baa6727e875810b5d631ab1d57ebb032dfcc079fca09cb571b23564a24b4.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb48e3c9_3ddf_4200_8be2_a634216ba39a.slice/cri-containerd-0ff130f8ef62baa38b508b8ba91605500c13a0b7c2271349f39edb414e1ffc9a.scope"
      }
    ],
    "ips": [
      "10.112.0.141"
    ],
    "name": "clustermesh-apiserver-5c85b98d74-5hlcv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78d9164d_bbb3_4e76_8f9b_717d0c9e41cf.slice/cri-containerd-b2f78d4cab700bd4781d24f4d0b85913b975b06872130c979edec177c55e350a.scope"
      }
    ],
    "ips": [
      "10.112.0.196"
    ],
    "name": "client2-57cf4468f-mfxnx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode32681e8_e930_4ad4_8eba_4db377467cc2.slice/cri-containerd-fd7a4d01824b6a84a99e35e45ab634f10db35859edd61589e24db5f55f184c76.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode32681e8_e930_4ad4_8eba_4db377467cc2.slice/cri-containerd-e6b6f21386a8c9721b7e2a11e7e040dc1039ff34a492043ff4a7321766e2e990.scope"
      }
    ],
    "ips": [
      "10.112.0.36"
    ],
    "name": "echo-same-node-86d9cc975c-hpfpp",
    "namespace": "cilium-test-1"
  }
]

