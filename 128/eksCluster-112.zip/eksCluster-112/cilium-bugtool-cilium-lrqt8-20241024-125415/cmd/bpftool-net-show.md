xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 558
cilium_host(7) clsact/egress cil_from_host-cilium_host id 554
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 510
lxc57b79c0e8f00(12) clsact/ingress cil_from_container-lxc57b79c0e8f00 id 526
lxcd500837d93d3(14) clsact/ingress cil_from_container-lxcd500837d93d3 id 542
lxc644e94173b0f(18) clsact/ingress cil_from_container-lxc644e94173b0f id 623
lxcb0bbba89b3ba(20) clsact/ingress cil_from_container-lxcb0bbba89b3ba id 3342
lxcbe7489c36165(22) clsact/ingress cil_from_container-lxcbe7489c36165 id 3280
lxca6cb5d2844c0(24) clsact/ingress cil_from_container-lxca6cb5d2844c0 id 3332

flow_dissector:

netfilter:

