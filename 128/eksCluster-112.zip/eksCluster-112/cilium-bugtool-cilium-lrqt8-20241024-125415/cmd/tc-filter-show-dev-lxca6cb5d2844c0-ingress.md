filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca6cb5d2844c0 direct-action not_in_hw id 3332 tag 0dace04adcb1e2ff jited 
