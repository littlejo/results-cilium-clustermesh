IP ADDRESS         LOCAL ENDPOINT INFO
10.112.0.196:0     id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B   
10.112.0.36:0      id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3   
172.31.182.158:0   (localhost)                                                                                        
10.112.0.8:0       (localhost)                                                                                        
172.31.177.209:0   (localhost)                                                                                        
10.112.0.141:0     id=25    sec_id=7408221 flags=0x0000 ifindex=18  mac=82:AC:83:13:6F:1E nodemac=26:52:EB:C3:B6:12   
10.112.0.130:0     id=298   sec_id=7466403 flags=0x0000 ifindex=14  mac=36:09:70:FD:E3:30 nodemac=72:71:E7:4E:B4:8C   
10.112.0.121:0     id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB   
10.112.0.63:0      id=919   sec_id=4     flags=0x0000 ifindex=10  mac=3A:CD:5A:21:49:05 nodemac=EA:C2:30:66:6A:7D     
10.112.0.57:0      id=3872  sec_id=7466403 flags=0x0000 ifindex=12  mac=42:64:55:4B:01:DF nodemac=C2:7B:C7:93:96:D9   
