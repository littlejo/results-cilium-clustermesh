filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb0bbba89b3ba direct-action not_in_hw id 3342 tag 0e223cd0e3f4fb14 jited 
