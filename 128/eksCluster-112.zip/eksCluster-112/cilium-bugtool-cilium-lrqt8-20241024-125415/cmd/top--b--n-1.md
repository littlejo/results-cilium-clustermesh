top - 12:54:16 up 31 min,  0 users,  load average: 0.52, 0.44, 0.24
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 41.4 us, 48.3 sy,  0.0 ni, 10.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    292.3 free,   1048.2 used,   2495.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2606.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 290452  79148 S  46.7   7.4   1:04.72 cilium-+
   3291 root      20   0 1240432  15832  11100 S   6.7   0.4   0:00.03 cilium-+
    418 root      20   0 1229744   8844   2864 S   0.0   0.2   0:04.37 cilium-+
   3326 root      20   0 1229000   4048   3388 S   0.0   0.1   0:00.00 gops
   3328 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3339 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3340 root      20   0 1229000   4040   3376 S   0.0   0.1   0:00.00 gops
   3348 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3384 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
