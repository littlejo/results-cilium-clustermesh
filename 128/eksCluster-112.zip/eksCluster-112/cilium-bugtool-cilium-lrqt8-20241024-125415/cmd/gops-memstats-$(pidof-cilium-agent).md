alloc: 89.80MB (94164568 bytes)
total-alloc: 3.11GB (3340918344 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75567053
frees: 74736144
heap-alloc: 89.80MB (94164568 bytes)
heap-sys: 172.66MB (181051392 bytes)
heap-idle: 49.63MB (52043776 bytes)
heap-in-use: 123.03MB (129007616 bytes)
heap-released: 3.30MB (3465216 bytes)
heap-objects: 830909
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.06MB (2161440 bytes)
stack-mspan-sys: 2.82MB (2953920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 940.47KB (963041 bytes)
gc-sys: 5.49MB (5760072 bytes)
next-gc: when heap-alloc >= 149.48MB (156746328 bytes)
last-gc: 2024-10-24 12:54:29.73900172 +0000 UTC
gc-pause-total: 26.51885ms
gc-pause: 69244
gc-pause-end: 1729774469739001720
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006948756919821414
enable-gc: true
debug-gc: false
