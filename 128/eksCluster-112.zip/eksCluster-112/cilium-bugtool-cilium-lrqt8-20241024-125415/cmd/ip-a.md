1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:65:df:e6:09:41 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.177.209/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3548sec preferred_lft 3548sec
    inet6 fe80::465:dfff:fee6:941/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3a:82:d2:54:c9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.182.158/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::43a:82ff:fed2:54c9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:a4:78:a7:19:5e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8a4:78ff:fea7:195e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:4c:60:d5:1b:ef brd ff:ff:ff:ff:ff:ff
    inet 10.112.0.8/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::584c:60ff:fed5:1bef/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 1e:0b:b5:a9:eb:1d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1c0b:b5ff:fea9:eb1d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:c2:30:66:6a:7d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::e8c2:30ff:fe66:6a7d/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc57b79c0e8f00@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:7b:c7:93:96:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c07b:c7ff:fe93:96d9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd500837d93d3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:71:e7:4e:b4:8c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::7071:e7ff:fe4e:b48c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc644e94173b0f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:52:eb:c3:b6:12 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2452:ebff:fec3:b612/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcb0bbba89b3ba@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:ae:60:49:51:ab brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7cae:60ff:fe49:51ab/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcbe7489c36165@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:51:e8:09:40:f3 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::ec51:e8ff:fe09:40f3/64 scope link 
       valid_lft forever preferred_lft forever
24: lxca6cb5d2844c0@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:cc:29:86:af:2b brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::5ccc:29ff:fe86:af2b/64 scope link 
       valid_lft forever preferred_lft forever
