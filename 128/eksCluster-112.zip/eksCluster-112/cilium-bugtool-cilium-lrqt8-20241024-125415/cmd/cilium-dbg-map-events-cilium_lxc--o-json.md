{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:27.640Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.182Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.182Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.221Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.256Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.258Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.489Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.495Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.563Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.576Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.619Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.270Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.276Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.341Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.361Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.390Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.582Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.590Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.651Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.691Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.738Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.277Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.282Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.350Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.360Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.397Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.400Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.435Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.635Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.682Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.727Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.742Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.781Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.351Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.352Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.404Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.409Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.466Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.471Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.506Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.742Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.743Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.798Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.801Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.903Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.352Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.355Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.403Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.411Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.440Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.660Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.678Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.700Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.730Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.740Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.313Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.356Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.362Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.402Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.430Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.440Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.679Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.687Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.746Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.754Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.790Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.182Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.223Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.228Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.357Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.359Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.404Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.614Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.631Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.673Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.710Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.728Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.182Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.216Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.227Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.267Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.287Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.308Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.556Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.560Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.623Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.633Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.662Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.038Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.068Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.084Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.115Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.137Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.389Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.406Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.472Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.572Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.573Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.827Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.887Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.897Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.936Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.966Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.990Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.204Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.212Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.272Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.290Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.311Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.590Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.630Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.631Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.682Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.700Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.722Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.965Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.984Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.989Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.020Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.724Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.727Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.763Z",
  "value": "id=3495  sec_id=7413426 flags=0x0000 ifindex=22  mac=BA:B2:31:7B:81:48 nodemac=EE:51:E8:09:40:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.772Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.795Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.174Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.185Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.933Z",
  "value": "id=718   sec_id=7408269 flags=0x0000 ifindex=20  mac=AE:B5:E0:FC:D5:0F nodemac=7E:AE:60:49:51:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.936Z",
  "value": "id=666   sec_id=7420801 flags=0x0000 ifindex=24  mac=3E:50:A3:F6:21:22 nodemac=5E:CC:29:86:AF:2B"
}

