filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd500837d93d3 direct-action not_in_hw id 542 tag 6fabd2a1165b5cbf jited 
