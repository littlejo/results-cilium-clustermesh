Endpoint ID: 25
Path: /sys/fs/bpf/tc/globals/cilium_policy_00025

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6113162   61251     0        
Allow    Ingress     1          ANY          NONE         disabled    5288117   55726     0        
Allow    Egress      0          ANY          NONE         disabled    6666915   65966     0        


Endpoint ID: 298
Path: /sys/fs/bpf/tc/globals/cilium_policy_00298

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2376     25        0        
Allow    Ingress     1          ANY          NONE         disabled    126916   1458      0        
Allow    Egress      0          ANY          NONE         disabled    17828    196       0        


Endpoint ID: 666
Path: /sys/fs/bpf/tc/globals/cilium_policy_00666

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 718
Path: /sys/fs/bpf/tc/globals/cilium_policy_00718

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 919
Path: /sys/fs/bpf/tc/globals/cilium_policy_00919

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6216690   76822     0        
Allow    Ingress     1          ANY          NONE         disabled    64552     781       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1559
Path: /sys/fs/bpf/tc/globals/cilium_policy_01559

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3495
Path: /sys/fs/bpf/tc/globals/cilium_policy_03495

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379213   4422      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3872
Path: /sys/fs/bpf/tc/globals/cilium_policy_03872

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3520     35        0        
Allow    Ingress     1          ANY          NONE         disabled    125799   1445      0        
Allow    Egress      0          ANY          NONE         disabled    17306    190       0        


