USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3291  0.0  0.3 1240176 15588 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3315  0.0  0.0   6408  1632 ?        R    12:54   0:00  \_ ps auxfw
root        3317  0.0  0.0   3728   488 ?        R    12:54   0:00  \_ bash -c hostname
root           1  4.9  7.3 1539060 288248 ?      Ssl  12:32   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         418  0.3  0.2 1229744 8844 ?        Sl   12:32   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
