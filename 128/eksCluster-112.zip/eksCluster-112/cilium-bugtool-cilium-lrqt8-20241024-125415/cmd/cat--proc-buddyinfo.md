Node 0, zone      DMA     97     73      2      3     11     11      6      5      3      3     41 
Node 0, zone   Normal     80      2      0      1      5      2      2      3      1      3      8 
