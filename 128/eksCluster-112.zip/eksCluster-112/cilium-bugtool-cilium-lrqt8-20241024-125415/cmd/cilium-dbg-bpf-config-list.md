KEY             VALUE
AgentLiveness   1893722356582
UTimeOffset     3378462097656250
