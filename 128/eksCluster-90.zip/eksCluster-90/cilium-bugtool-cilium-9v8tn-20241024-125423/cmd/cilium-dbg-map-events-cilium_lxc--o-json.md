{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.534Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.569Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.599Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.622Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.638Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.900Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.914Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.995Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.020Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.053Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.624Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.625Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.670Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.671Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.716Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.719Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.750Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.980Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.993Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.067Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.113Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.190Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.699Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.707Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.733Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.752Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.793Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.802Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.828Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.049Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.054Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.106Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.138Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.158Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.734Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.736Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.803Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.815Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.843Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.888Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.895Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.147Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.151Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.252Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.288Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.333Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.727Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.756Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.795Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.829Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.837Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.100Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.111Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.162Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.171Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.204Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.587Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.624Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.625Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.680Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.683Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.716Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.939Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.940Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.035Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.041Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.114Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.538Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.554Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.590Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.612Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.628Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.875Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.891Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.929Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.950Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.987Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.376Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.407Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.422Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.463Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.463Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.470Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.719Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.723Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.777Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.781Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.830Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.233Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.270Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.274Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.351Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.388Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.434Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.643Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.654Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.708Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.727Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.766Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.136Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.168Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.185Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.222Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.224Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.505Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.531Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.556Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.575Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.610Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.895Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.929Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.962Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.985Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.020Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.042Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.278Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.306Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.358Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.373Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.021Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.025Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.062Z",
  "value": "id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.071Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.105Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.363Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.366Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.045Z",
  "value": "id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.054Z",
  "value": "id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF"
}

