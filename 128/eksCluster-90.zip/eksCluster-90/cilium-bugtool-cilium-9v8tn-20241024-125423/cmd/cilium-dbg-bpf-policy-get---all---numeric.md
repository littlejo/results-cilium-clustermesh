Endpoint ID: 33
Path: /sys/fs/bpf/tc/globals/cilium_policy_00033

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 382
Path: /sys/fs/bpf/tc/globals/cilium_policy_00382

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6169316   61217     0        
Allow    Ingress     1          ANY          NONE         disabled    5093994   53515     0        
Allow    Egress      0          ANY          NONE         disabled    6012824   60341     0        


Endpoint ID: 445
Path: /sys/fs/bpf/tc/globals/cilium_policy_00445

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382474   4461      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 494
Path: /sys/fs/bpf/tc/globals/cilium_policy_00494

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6241565   77321     0        
Allow    Ingress     1          ANY          NONE         disabled    65039     795       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1305
Path: /sys/fs/bpf/tc/globals/cilium_policy_01305

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1375
Path: /sys/fs/bpf/tc/globals/cilium_policy_01375

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1619
Path: /sys/fs/bpf/tc/globals/cilium_policy_01619

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2744     27        0        
Allow    Ingress     1          ANY          NONE         disabled    136898   1574      0        
Allow    Egress      0          ANY          NONE         disabled    19511    215       0        


Endpoint ID: 1688
Path: /sys/fs/bpf/tc/globals/cilium_policy_01688

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3152     33        0        
Allow    Ingress     1          ANY          NONE         disabled    135759   1561      0        
Allow    Egress      0          ANY          NONE         disabled    19399    215       0        


