[
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f58cae2_a193_4eca_b3c8_5dae23616c42.slice/cri-containerd-594f951fa3ba74e43dde462946d6fe6a0c0902fc6b7456a8e02ee63da5ac88de.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f58cae2_a193_4eca_b3c8_5dae23616c42.slice/cri-containerd-9188b4a706eabc1ee0815467ff3a7614537fe99d5a0bd68f53dbab114926c625.scope"
      }
    ],
    "ips": [
      "10.90.0.166"
    ],
    "name": "echo-same-node-86d9cc975c-fvx9h",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde6bc3f2_c5a6_40bc_b235_f3cdf6eee0d2.slice/cri-containerd-a34e2fcbe6e12fae90ddb8d0f6f461a5185ed7c9f98497ad4489db96181ccab2.scope"
      }
    ],
    "ips": [
      "10.90.0.66"
    ],
    "name": "coredns-cc6ccd49c-6ftcs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe59c455_34d7_415f_9d34_5c898fc16b6e.slice/cri-containerd-7013c1517f0b3e47ba858614047cbbd6317e59ea35d5eca27bd47c468310bb00.scope"
      }
    ],
    "ips": [
      "10.90.0.248"
    ],
    "name": "coredns-cc6ccd49c-mhsqq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc137a2b5_8e49_461a_8103_6df161d5600a.slice/cri-containerd-e78a1c0b92a8a4803729cac11e258bee76bd9a574ab4a4ca53fdc00dad24cf3f.scope"
      }
    ],
    "ips": [
      "10.90.0.26"
    ],
    "name": "client2-57cf4468f-58p8l",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9660522_c9c6_4430_8762_401ed3e3bf11.slice/cri-containerd-6e6e8fa38e3122ae2dc737fa6104c4ddc649f63d4ff08d4b88462bdd3aabd35b.scope"
      }
    ],
    "ips": [
      "10.90.0.115"
    ],
    "name": "client-974f6c69d-fknjl",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ee9f0d0_d387_4223_a977_0ed6ae4df9ec.slice/cri-containerd-8d4559bcb9f9150e184175a68aae7546c34e175d810c15ff666bf1d87fba4030.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ee9f0d0_d387_4223_a977_0ed6ae4df9ec.slice/cri-containerd-6eda07dbcb618fc539199210a71a82cbcc9c04d8c2e277f0b18361754a1e6f9d.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ee9f0d0_d387_4223_a977_0ed6ae4df9ec.slice/cri-containerd-2b8c8ad25b04455b8b07748e709dece83cbd553f4de15a2591b4930ce8f42e32.scope"
      }
    ],
    "ips": [
      "10.90.0.6"
    ],
    "name": "clustermesh-apiserver-5df447788-qf8lq",
    "namespace": "kube-system"
  }
]

