xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 578
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 561
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 544
cilium_host(7) clsact/egress cil_from_host-cilium_host id 547
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 567
lxcca8c5374de72(12) clsact/ingress cil_from_container-lxcca8c5374de72 id 552
lxc8199982bf5b7(14) clsact/ingress cil_from_container-lxc8199982bf5b7 id 530
lxca441efc0236a(18) clsact/ingress cil_from_container-lxca441efc0236a id 645
lxc02681018baad(20) clsact/ingress cil_from_container-lxc02681018baad id 3350
lxc3f011d96bc90(22) clsact/ingress cil_from_container-lxc3f011d96bc90 id 3364
lxc6348125bf740(24) clsact/ingress cil_from_container-lxc6348125bf740 id 3304

flow_dissector:

netfilter:

