KEY             VALUE
AgentLiveness   1934852430382
UTimeOffset     3378462033203125
