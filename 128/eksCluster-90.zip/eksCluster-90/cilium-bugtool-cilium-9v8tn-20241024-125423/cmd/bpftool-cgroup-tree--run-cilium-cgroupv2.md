CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde6bc3f2_c5a6_40bc_b235_f3cdf6eee0d2.slice/cri-containerd-a34e2fcbe6e12fae90ddb8d0f6f461a5185ed7c9f98497ad4489db96181ccab2.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde6bc3f2_c5a6_40bc_b235_f3cdf6eee0d2.slice/cri-containerd-5f56bfa089cbba0ce167b9b8a74c6be9a76cd4909ee70522f508641fe9b3b619.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe59c455_34d7_415f_9d34_5c898fc16b6e.slice/cri-containerd-523c36dfb1f40ff26c5e8b551dac6d58f96187604f54ce5deebe82834473ce01.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe59c455_34d7_415f_9d34_5c898fc16b6e.slice/cri-containerd-7013c1517f0b3e47ba858614047cbbd6317e59ea35d5eca27bd47c468310bb00.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod406b90ce_9c74_451e_8e93_226d05626c19.slice/cri-containerd-875f4b08d339183bc1e9269289d6089827621ec1419a14adb8d37397c1f32a87.scope
    96       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod406b90ce_9c74_451e_8e93_226d05626c19.slice/cri-containerd-cddc389889a72cf9d39d77356a457ae63a797d08573ad7276c458309fdd121c0.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbd2204b_7513_4762_8ed0_31b4e43a5ec1.slice/cri-containerd-56b48b90f6169189dbdf6d76a8ac25357d11c68b0cf6d376817043e32ef77dcf.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbd2204b_7513_4762_8ed0_31b4e43a5ec1.slice/cri-containerd-6abb0e7db84c6eec4f8e0846c64310e5f309302ac08a810509b7804c858345fc.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc137a2b5_8e49_461a_8103_6df161d5600a.slice/cri-containerd-e78a1c0b92a8a4803729cac11e258bee76bd9a574ab4a4ca53fdc00dad24cf3f.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc137a2b5_8e49_461a_8103_6df161d5600a.slice/cri-containerd-66147a82a7d3ddf53aa46443a06734295b9eb795056dafce93094b595bf75854.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f58cae2_a193_4eca_b3c8_5dae23616c42.slice/cri-containerd-9188b4a706eabc1ee0815467ff3a7614537fe99d5a0bd68f53dbab114926c625.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f58cae2_a193_4eca_b3c8_5dae23616c42.slice/cri-containerd-a18dd711a820db0bff5163a49c6de2530b72ee35c691b918968be09c38b70ac6.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f58cae2_a193_4eca_b3c8_5dae23616c42.slice/cri-containerd-594f951fa3ba74e43dde462946d6fe6a0c0902fc6b7456a8e02ee63da5ac88de.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9660522_c9c6_4430_8762_401ed3e3bf11.slice/cri-containerd-624fee7369c5f0623c5d460e188dec99c58b872a2925d98a0c5077a76250ae43.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9660522_c9c6_4430_8762_401ed3e3bf11.slice/cri-containerd-6e6e8fa38e3122ae2dc737fa6104c4ddc649f63d4ff08d4b88462bdd3aabd35b.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ee9f0d0_d387_4223_a977_0ed6ae4df9ec.slice/cri-containerd-2b8c8ad25b04455b8b07748e709dece83cbd553f4de15a2591b4930ce8f42e32.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ee9f0d0_d387_4223_a977_0ed6ae4df9ec.slice/cri-containerd-cc23a24a635beb6fe1be0aef383bea626da1e23635dd73bd21856ffd716fac74.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ee9f0d0_d387_4223_a977_0ed6ae4df9ec.slice/cri-containerd-6eda07dbcb618fc539199210a71a82cbcc9c04d8c2e277f0b18361754a1e6f9d.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ee9f0d0_d387_4223_a977_0ed6ae4df9ec.slice/cri-containerd-8d4559bcb9f9150e184175a68aae7546c34e175d810c15ff666bf1d87fba4030.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5f0db95b_edb8_43e7_843c_9bdf70357f62.slice/cri-containerd-f108aa63eb1ef5099286fd511cad495682725d81c1d4dab0dca45786390d2dc9.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5f0db95b_edb8_43e7_843c_9bdf70357f62.slice/cri-containerd-811248e58f6c8be083337f6fe16b6e166afdee6044b558468f6d9210adcd1f5a.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddba3e62a_a881_4955_8117_d30a3912c5a6.slice/cri-containerd-c4203f2514476a7d8762bcce0386b6163d4fcfacb94aa5a74785f52e47051b87.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddba3e62a_a881_4955_8117_d30a3912c5a6.slice/cri-containerd-4f4b60f8dea125d699ff7686c36725f5b058439fe456aac8ed2616ceb37e393b.scope
    97       cgroup_device   multi                                          
