 12:54:25 up 31 min,  0 users,  load average: 0.35, 0.41, 0.21
