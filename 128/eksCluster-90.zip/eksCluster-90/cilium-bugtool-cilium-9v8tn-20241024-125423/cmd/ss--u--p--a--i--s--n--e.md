Total: 590
TCP:   3077 (estab 313, closed 2745, orphaned 0, timewait 2282)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  332       320       12       
INET	  342       326       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33833 sk:a2b cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15312 sk:a2c cgroup:unreachable:e8e <->                                    
UNCONN 0      0                   172.31.138.25%ens5:68         0.0.0.0:*    uid:192 ino:133284 sk:a2d cgroup:unreachable:bd0 <->                           
UNCONN 0      0                            127.0.0.1:34979      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:32645 sk:a2e fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33832 sk:a2f cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15313 sk:a30 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::429:e6ff:fe85:85fd]%ens5:546           [::]:*    uid:192 ino:16489 sk:a31 cgroup:unreachable:bd0 v6only:1 <->                   
