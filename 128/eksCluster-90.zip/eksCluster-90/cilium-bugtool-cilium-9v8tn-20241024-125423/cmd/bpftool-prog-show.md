35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
96: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name tail_handle_ipv4  tag 53d29513d9369fae  gpl
	loaded_at 2024-10-24T12:31:00+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:31:00+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:31:00+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
487: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:31:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 163
519: sched_cls  name tail_handle_ipv4_cont  tag 4c2adcd10f8ea709  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 165
520: sched_cls  name tail_ipv4_ct_ingress  tag 84ca6830cf0a2b27  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 167
521: sched_cls  name __send_drop_notify  tag 52a2cea2fff11500  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 168
524: sched_cls  name tail_ipv4_to_endpoint  tag 191fb05d938a12de  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 169
525: sched_cls  name tail_ipv4_ct_egress  tag 38f84482531cd33e  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 172
528: sched_cls  name tail_handle_ipv4  tag 3b3efa483e1f7b1d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 173
529: sched_cls  name tail_handle_arp  tag c3407807d2bac42a  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 176
530: sched_cls  name cil_from_container  tag 300fce274653d9fa  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 177
537: sched_cls  name tail_handle_ipv4_cont  tag dbf141f91fa403b7  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 185
538: sched_cls  name handle_policy  tag 0eec2aa1918f6e63  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 181
539: sched_cls  name handle_policy  tag fadb429c8f3adbf8  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 186
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 187
542: sched_cls  name tail_handle_ipv4_from_host  tag 47d35be85be0a4ec  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 190
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 192
544: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
546: sched_cls  name tail_ipv4_to_endpoint  tag 418fa06dd7f3642e  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 191
547: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 196
548: sched_cls  name __send_drop_notify  tag f0515aec32ddd2c1  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 197
549: sched_cls  name tail_ipv4_ct_ingress  tag bf47e8970a979c1d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 195
551: sched_cls  name tail_handle_arp  tag cc6b2c9ec1d957b0  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 199
552: sched_cls  name cil_from_container  tag c714202b556bc7e5  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 200
555: sched_cls  name __send_drop_notify  tag f0515aec32ddd2c1  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
556: sched_cls  name tail_ipv4_ct_egress  tag 38f84482531cd33e  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 201
557: sched_cls  name __send_drop_notify  tag ffbcfc2835465644  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
559: sched_cls  name tail_handle_ipv4_from_host  tag 47d35be85be0a4ec  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 209
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 210
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 211
563: sched_cls  name __send_drop_notify  tag f0515aec32ddd2c1  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
565: sched_cls  name tail_handle_ipv4  tag 73b545bad9b082af  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 207
567: sched_cls  name cil_from_container  tag bd1d4101a4eac2c7  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 124,76
	btf_id 219
568: sched_cls  name __send_drop_notify  tag d5705976d07a0393  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 220
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,124
	btf_id 221
570: sched_cls  name tail_handle_arp  tag 2c9296990aa0bc05  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,124
	btf_id 222
571: sched_cls  name tail_handle_ipv4_from_host  tag 47d35be85be0a4ec  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 216
572: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 224
574: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 226
575: sched_cls  name tail_handle_ipv4  tag 5a444f2afeb81077  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,124
	btf_id 223
576: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 228
578: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 231
580: sched_cls  name __send_drop_notify  tag f0515aec32ddd2c1  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
582: sched_cls  name tail_handle_ipv4_from_host  tag 47d35be85be0a4ec  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 235
583: sched_cls  name handle_policy  tag 040dc276221d586f  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,124,82,83,123,41,80,100,39,84,75,40,37,38
	btf_id 229
584: sched_cls  name tail_ipv4_ct_ingress  tag bce2bbc351d8bc40  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,124,82,83,123,84
	btf_id 236
585: sched_cls  name tail_ipv4_to_endpoint  tag 18e9a23a36790592  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,123,41,82,83,80,100,39,124,40,37,38
	btf_id 237
586: sched_cls  name tail_handle_ipv4_cont  tag d1eb801f1f512a09  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,123,41,100,82,83,39,76,74,77,124,40,37,38,81
	btf_id 238
587: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,124,82,83,123,84
	btf_id 239
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name tail_handle_ipv4  tag fb58ec5100327bbd  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 253
644: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 254
645: sched_cls  name cil_from_container  tag 49b534713d851367  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 255
646: sched_cls  name tail_handle_arp  tag 48e297478f327610  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 256
647: sched_cls  name tail_ipv4_ct_egress  tag 5528dd1317a84f5d  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 257
649: sched_cls  name handle_policy  tag 2fc0538db06c52ca  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 259
650: sched_cls  name __send_drop_notify  tag 27fdcba8599e6481  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 260
651: sched_cls  name tail_ipv4_ct_ingress  tag 254393188749efae  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 261
652: sched_cls  name tail_handle_ipv4_cont  tag 470ab1a515128c3c  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 262
653: sched_cls  name tail_ipv4_to_endpoint  tag 68eacfcd6874cd4e  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
723: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
726: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
727: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
730: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
731: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
734: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
735: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
738: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
739: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
742: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3295: sched_cls  name tail_ipv4_ct_ingress  tag 0a828ba138cc1261  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3085
3298: sched_cls  name tail_handle_ipv4  tag 9a030cf37fca3df9  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,632
	btf_id 3086
3300: sched_cls  name tail_ipv4_ct_egress  tag 4b38ffa3d843b96e  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3091
3301: sched_cls  name __send_drop_notify  tag a721f9b46f58374e  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3092
3303: sched_cls  name tail_ipv4_to_endpoint  tag 1a6cc54ac9706546  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,631,41,82,83,80,157,39,632,40,37,38
	btf_id 3094
3304: sched_cls  name cil_from_container  tag d5d859f26a9487a1  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 632,76
	btf_id 3096
3308: sched_cls  name tail_handle_ipv4_cont  tag 4e6b91ed9fe0c45e  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,631,41,157,82,83,39,76,74,77,632,40,37,38,81
	btf_id 3099
3311: sched_cls  name handle_policy  tag 2d891c3a7bad648a  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,632,82,83,631,41,80,157,39,84,75,40,37,38
	btf_id 3101
3312: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,632
	btf_id 3104
3313: sched_cls  name tail_handle_arp  tag 97c42fd753b0f2de  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,632
	btf_id 3105
3350: sched_cls  name cil_from_container  tag a2ac9293fe621092  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 641,76
	btf_id 3146
3351: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,644
	btf_id 3148
3352: sched_cls  name tail_ipv4_ct_ingress  tag db0afa564f4c194b  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3147
3353: sched_cls  name tail_ipv4_ct_egress  tag 4ac20b0b8784ee8c  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3150
3354: sched_cls  name tail_ipv4_to_endpoint  tag 2de4c0f9399ea3d2  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,642,41,82,83,80,151,39,641,40,37,38
	btf_id 3151
3355: sched_cls  name __send_drop_notify  tag 87b480a2f51a0825  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3152
3356: sched_cls  name handle_policy  tag 28e9da31983cbf07  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,644,82,83,643,41,80,154,39,84,75,40,37,38
	btf_id 3149
3357: sched_cls  name tail_handle_ipv4  tag aa3b59670a52c4cf  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,641
	btf_id 3153
3358: sched_cls  name tail_handle_arp  tag 2135c7247624f337  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,641
	btf_id 3155
3360: sched_cls  name tail_handle_ipv4  tag b8b38999c1ba16ab  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,644
	btf_id 3154
3361: sched_cls  name tail_handle_ipv4_cont  tag 14f952896e01973b  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,642,41,151,82,83,39,76,74,77,641,40,37,38,81
	btf_id 3157
3362: sched_cls  name tail_handle_ipv4_cont  tag 5d629c259c2e248a  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,643,41,154,82,83,39,76,74,77,644,40,37,38,81
	btf_id 3158
3363: sched_cls  name tail_ipv4_ct_ingress  tag c96eea94049caaae  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3160
3364: sched_cls  name cil_from_container  tag 72ce0af794210766  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 644,76
	btf_id 3161
3365: sched_cls  name tail_handle_arp  tag c08e474e0dfe6efc  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,644
	btf_id 3162
3367: sched_cls  name __send_drop_notify  tag 066529ce58e21e86  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3164
3368: sched_cls  name handle_policy  tag c743f5c27b1874e9  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,641,82,83,642,41,80,151,39,84,75,40,37,38
	btf_id 3159
3369: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,641
	btf_id 3166
3370: sched_cls  name tail_ipv4_to_endpoint  tag d7fd14aeb31f13c5  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,643,41,82,83,80,154,39,644,40,37,38
	btf_id 3165
3371: sched_cls  name tail_ipv4_ct_egress  tag c5f2cf849dc85531  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3167
