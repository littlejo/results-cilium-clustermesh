1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:29:e6:85:85:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.138.25/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3505sec preferred_lft 3505sec
    inet6 fe80::429:e6ff:fe85:85fd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d0:b1:de:dc:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.156.221/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d0:b1ff:fede:dcd7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:4f:e8:3b:08:6b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84f:e8ff:fe3b:86b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:74:3f:5a:e1:7e brd ff:ff:ff:ff:ff:ff
    inet 10.90.0.247/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b474:3fff:fe5a:e17e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0e:15:9b:dd:dc:43 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c15:9bff:fedd:dc43/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:d4:a8:a1:75:83 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::64d4:a8ff:fea1:7583/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcca8c5374de72@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:9d:23:2d:95:7c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b49d:23ff:fe2d:957c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8199982bf5b7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:24:95:09:df:e6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3c24:95ff:fe09:dfe6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca441efc0236a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:51:02:e2:66:65 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2051:2ff:fee2:6665/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc02681018baad@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:c0:65:55:ff:7e brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::94c0:65ff:fe55:ff7e/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc3f011d96bc90@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:7c:86:87:fb:ef brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::b07c:86ff:fe87:fbef/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc6348125bf740@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:21:41:39:b6:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::2821:41ff:fe39:b6e2/64 scope link 
       valid_lft forever preferred_lft forever
