top - 12:54:25 up 31 min,  0 users,  load average: 0.81, 0.50, 0.24
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s):  9.7 us, 32.3 sy,  0.0 ni, 58.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    304.2 free,   1035.8 used,   2496.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2619.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3233 root      20   0 1240432  16420  11356 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1539060 286208  78140 S   0.0   7.3   1:03.39 cilium-+
    391 root      20   0 1229744  10196   3836 S   0.0   0.3   0:04.36 cilium-+
   3199 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3205 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3225 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3239 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3246 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3281 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3299 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
