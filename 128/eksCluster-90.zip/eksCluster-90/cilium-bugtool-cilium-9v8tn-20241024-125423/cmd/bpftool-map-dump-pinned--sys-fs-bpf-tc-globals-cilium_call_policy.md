key: 21 00 00 00  value: 1c 0d 00 00
key: 7e 01 00 00  value: 89 02 00 00
key: bd 01 00 00  value: ef 0c 00 00
key: ee 01 00 00  value: 47 02 00 00
key: 19 05 00 00  value: 28 0d 00 00
key: 53 06 00 00  value: 1b 02 00 00
key: 98 06 00 00  value: 1a 02 00 00
Found 7 elements
