IP ADDRESS         LOCAL ENDPOINT INFO
10.90.0.66:0       id=1688  sec_id=5968002 flags=0x0000 ifindex=14  mac=D2:7F:F4:CF:10:D3 nodemac=3E:24:95:09:DF:E6   
172.31.156.221:0   (localhost)                                                                                        
10.90.0.248:0      id=1619  sec_id=5968002 flags=0x0000 ifindex=12  mac=A6:EB:B2:F8:20:3C nodemac=B6:9D:23:2D:95:7C   
10.90.0.166:0      id=445   sec_id=6018779 flags=0x0000 ifindex=24  mac=0E:D9:53:39:B3:83 nodemac=2A:21:41:39:B6:E2   
172.31.138.25:0    (localhost)                                                                                        
10.90.0.26:0       id=33    sec_id=6017915 flags=0x0000 ifindex=22  mac=F2:B0:98:DB:0B:6E nodemac=B2:7C:86:87:FB:EF   
10.90.0.16:0       id=494   sec_id=4     flags=0x0000 ifindex=10  mac=DE:9F:C3:1B:53:1C nodemac=66:D4:A8:A1:75:83     
10.90.0.247:0      (localhost)                                                                                        
10.90.0.6:0        id=382   sec_id=5985380 flags=0x0000 ifindex=18  mac=7A:DE:26:93:F0:34 nodemac=22:51:02:E2:66:65   
10.90.0.115:0      id=1305  sec_id=5976206 flags=0x0000 ifindex=20  mac=2E:C0:DB:A3:03:B0 nodemac=96:C0:65:55:FF:7E   
