alloc: 129.07MB (135339888 bytes)
total-alloc: 3.07GB (3296443560 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74978957
frees: 73604789
heap-alloc: 129.07MB (135339888 bytes)
heap-sys: 172.70MB (181092352 bytes)
heap-idle: 24.27MB (25452544 bytes)
heap-in-use: 148.43MB (155639808 bytes)
heap-released: 3.98MB (4169728 bytes)
heap-objects: 1374168
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.31MB (2421920 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 992.02KB (1015833 bytes)
gc-sys: 5.54MB (5811368 bytes)
next-gc: when heap-alloc >= 149.47MB (156731640 bytes)
last-gc: 2024-10-24 12:54:26.93549365 +0000 UTC
gc-pause-total: 13.838315ms
gc-pause: 124006
gc-pause-end: 1729774466935493650
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006810931909519126
enable-gc: true
debug-gc: false
