Node 0, zone      DMA      0     63      9      3      1      4      5      3      4      4     40 
Node 0, zone   Normal    227    159      7      4      1      3      5      4      2      3      7 
