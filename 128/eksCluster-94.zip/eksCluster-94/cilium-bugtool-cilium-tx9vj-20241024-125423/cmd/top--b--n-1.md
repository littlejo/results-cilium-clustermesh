top - 12:54:26 up 31 min,  0 users,  load average: 1.58, 0.81, 0.43
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.7 us, 36.7 sy,  0.0 ni, 53.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    291.8 free,   1049.3 used,   2495.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2605.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 294648  79228 S   0.0   7.5   1:04.74 cilium-+
    581 root      20   0 1229744  10044   3900 S   0.0   0.3   0:04.37 cilium-+
   3445 root      20   0 1240432  16248  11164 S   0.0   0.4   0:00.02 cilium-+
   3451 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3481 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3499 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3504 root      20   0 1615752   8268   6200 S   0.0   0.2   0:00.00 runc:[2+
