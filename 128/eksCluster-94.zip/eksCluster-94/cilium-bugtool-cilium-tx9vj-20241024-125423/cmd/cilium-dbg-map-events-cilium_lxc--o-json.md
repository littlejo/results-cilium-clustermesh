{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.742Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.779Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.356Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.367Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.425Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.426Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.460Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.737Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.740Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.800Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.847Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.858Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.408Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.423Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.478Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.484Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.514Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.759Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.767Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.826Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.842Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.874Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.473Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.478Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.517Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.525Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.579Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.583Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.616Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.830Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.839Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.916Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.996Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.012Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.495Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.503Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.536Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.556Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.602Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.609Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.667Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.855Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.910Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.911Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.964Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.975Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.977Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.289Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.306Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.356Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.356Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.395Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.593Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.603Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.673Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.692Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.719Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.180Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.185Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.233Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.248Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.274Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.516Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.523Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.578Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.597Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.631Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.045Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.086Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.096Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.143Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.143Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.151Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.396Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.400Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.460Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.493Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.502Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.930Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.006Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.042Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.076Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.080Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.261Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.274Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.344Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.358Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.390Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.792Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.804Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.844Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.856Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.887Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.067Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.074Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.119Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.128Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.166Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.497Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.537Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.562Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.598Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.599Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.617Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.871Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.876Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.980Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.003Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.055Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.370Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.377Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.426Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.437Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.465Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.673Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.679Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.700Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.704Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.723Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.401Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.402Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.453Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.462Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.491Z",
  "value": "id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.748Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.754Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.516Z",
  "value": "id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.518Z",
  "value": "id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE"
}

