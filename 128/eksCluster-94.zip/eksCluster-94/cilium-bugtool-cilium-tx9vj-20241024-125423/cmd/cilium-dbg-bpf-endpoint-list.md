IP ADDRESS         LOCAL ENDPOINT INFO
10.94.0.214:0      id=834   sec_id=6255645 flags=0x0000 ifindex=20  mac=A2:D8:0E:6F:99:B1 nodemac=22:E2:EA:C5:98:B2   
10.94.0.104:0      id=1364  sec_id=6236584 flags=0x0000 ifindex=22  mac=92:38:B0:B0:46:E6 nodemac=B6:3F:FE:97:43:9E   
172.31.190.190:0   (localhost)                                                                                        
10.94.0.128:0      id=618   sec_id=6285281 flags=0x0000 ifindex=18  mac=6A:52:C4:CE:12:18 nodemac=1E:A4:7C:94:A1:24   
10.94.0.135:0      id=969   sec_id=6291173 flags=0x0000 ifindex=14  mac=B6:AB:35:ED:86:B4 nodemac=16:2A:F9:B8:07:97   
10.94.0.69:0       id=424   sec_id=4     flags=0x0000 ifindex=10  mac=2E:67:2A:09:3B:16 nodemac=F2:E2:5A:EE:71:1E     
10.94.0.26:0       (localhost)                                                                                        
10.94.0.174:0      id=3274  sec_id=6291173 flags=0x0000 ifindex=12  mac=EA:17:0B:B1:74:E3 nodemac=76:DE:61:15:D5:6C   
10.94.0.162:0      id=1685  sec_id=6232096 flags=0x0000 ifindex=24  mac=9A:D8:02:F1:7B:C6 nodemac=EE:D9:46:4B:8A:AE   
172.31.159.1:0     (localhost)                                                                                        
