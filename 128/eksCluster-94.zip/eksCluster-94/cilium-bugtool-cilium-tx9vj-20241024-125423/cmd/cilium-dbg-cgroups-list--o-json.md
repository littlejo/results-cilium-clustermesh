[
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod549aa527_5fc0_4178_9610_da7e7e908831.slice/cri-containerd-49f0be6a32450482e8a1eb32b39b459e365bbd3182daf7c261f598340759c34d.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod549aa527_5fc0_4178_9610_da7e7e908831.slice/cri-containerd-10dbcd7f4fc7b23c671b6de1a5bf51d2ca7c9a1d98d5981eef2a2753c785e53c.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod549aa527_5fc0_4178_9610_da7e7e908831.slice/cri-containerd-4dfc5aa4d2a5530926069b4507d47a02b456df3d7962fce0f54ba559523f6892.scope"
      }
    ],
    "ips": [
      "10.94.0.128"
    ],
    "name": "clustermesh-apiserver-64b6f684b7-6fgj2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcde2c28_2f3e_43f4_9cba_7e280758d8fe.slice/cri-containerd-7ab7416a4d8c43135f2b6bdbbd758ae32aa5d9ae3b0d19cb3bde41b1aef8aac9.scope"
      }
    ],
    "ips": [
      "10.94.0.135"
    ],
    "name": "coredns-cc6ccd49c-cxqmb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84636fe6_8abb_4df5_a7df_157c4df53ce8.slice/cri-containerd-e1113fb639bdda778a82d649f94f2bf05a9fa3f5a37d4e126d610c5b2069bce6.scope"
      }
    ],
    "ips": [
      "10.94.0.162"
    ],
    "name": "client2-57cf4468f-2njrj",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb10b8289_81ba_47b5_8eb9_62ae84adffa9.slice/cri-containerd-2c22f6e63fad20f018d998b8a75647e9f1a023a929296ed8f2cd226ad448e92a.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb10b8289_81ba_47b5_8eb9_62ae84adffa9.slice/cri-containerd-12cafbef74b90359398b775cb0a5eceffaf451901aea7b0a6a2de05e9daa62fc.scope"
      }
    ],
    "ips": [
      "10.94.0.104"
    ],
    "name": "echo-same-node-86d9cc975c-49r82",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6d9cd66_4fb8_46fb_9efe_7133196d7abd.slice/cri-containerd-999c99a3891d7d261956d3cdfc67fa32fc75d7feee73ad4a6b409052ae13a177.scope"
      }
    ],
    "ips": [
      "10.94.0.174"
    ],
    "name": "coredns-cc6ccd49c-lzmgl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa90f014_79a2_403c_bc7d_1672196d7c49.slice/cri-containerd-6eb0032422011fef091379efaf953f048711d461ef65719c0be92d0eae2d79a1.scope"
      }
    ],
    "ips": [
      "10.94.0.214"
    ],
    "name": "client-974f6c69d-m8s26",
    "namespace": "cilium-test-1"
  }
]

