KEY             VALUE
AgentLiveness   1930750207592
UTimeOffset     3378462042968750
