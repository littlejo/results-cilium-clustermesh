Node 0, zone      DMA      1      1      3     27     31     65     28      9      4      3     37 
Node 0, zone   Normal   1381    325     66      3      2      1      2      2      1      3      6 
