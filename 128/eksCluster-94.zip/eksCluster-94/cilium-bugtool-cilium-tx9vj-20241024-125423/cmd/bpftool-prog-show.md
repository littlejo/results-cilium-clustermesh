35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:52+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
485: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
486: sched_cls  name tail_handle_ipv4  tag 20f1b9d1394ee7f5  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
487: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
489: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 130
491: sched_cls  name __send_drop_notify  tag 1428386ed47a8689  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 132
492: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,102
	btf_id 133
493: sched_cls  name tail_handle_ipv4_from_host  tag b78f06938d3125b4  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 134
494: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 135
495: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 137
497: sched_cls  name __send_drop_notify  tag 1428386ed47a8689  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 139
499: sched_cls  name tail_handle_ipv4_from_host  tag b78f06938d3125b4  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 141
500: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 142
502: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 145
503: sched_cls  name __send_drop_notify  tag 1428386ed47a8689  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 146
505: sched_cls  name tail_handle_ipv4_from_host  tag b78f06938d3125b4  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 148
506: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 149
510: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 154
511: sched_cls  name __send_drop_notify  tag 1428386ed47a8689  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 155
513: sched_cls  name tail_handle_ipv4_from_host  tag b78f06938d3125b4  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 157
514: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 158
517: sched_cls  name tail_ipv4_ct_egress  tag 6def0de1cae4ab4b  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 164
522: sched_cls  name handle_policy  tag 708dc0303007a2ee  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 165
523: sched_cls  name __send_drop_notify  tag c54638f3f227265c  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 170
524: sched_cls  name tail_ipv4_ct_ingress  tag 7499caea5f4e29f5  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 171
531: sched_cls  name tail_ipv4_to_endpoint  tag 30bb21dda1661662  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 172
532: sched_cls  name cil_from_container  tag 0bd48a8e6f95dbde  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 179
534: sched_cls  name tail_handle_arp  tag 92a2da674b4e0b42  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 182
535: sched_cls  name tail_handle_ipv4_cont  tag 19e4158aec8afab5  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 180
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 183
537: sched_cls  name tail_handle_ipv4  tag 29a1ed6fd41ec066  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 185
538: sched_cls  name tail_ipv4_to_endpoint  tag c66e2e040e8146bd  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 184
539: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 187
540: sched_cls  name __send_drop_notify  tag 2789504e15d07ccc  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 188
541: sched_cls  name tail_handle_ipv4_cont  tag ae19e9500324844b  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 186
542: sched_cls  name tail_handle_ipv4  tag b1d1ed5d90db3c0a  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 189
543: sched_cls  name tail_ipv4_ct_egress  tag 6def0de1cae4ab4b  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 191
544: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 192
545: sched_cls  name tail_handle_ipv4_cont  tag 3378f83f38d25c79  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 194
546: sched_cls  name tail_ipv4_ct_ingress  tag 35c3db45643202da  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 193
547: sched_cls  name tail_handle_ipv4  tag 9adba475df2e865d  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 195
548: sched_cls  name tail_handle_arp  tag 6d2272cb9b22a965  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 197
549: sched_cls  name cil_from_container  tag 89ef233e73c5d621  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 198
551: sched_cls  name tail_ipv4_to_endpoint  tag d2c5856b735bc205  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 196
552: sched_cls  name tail_ipv4_ct_ingress  tag bd4083a536fcdf44  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 201
554: sched_cls  name __send_drop_notify  tag bcaa16c8e825b7d8  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
555: sched_cls  name tail_handle_arp  tag 785ef17e42c4828d  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 204
556: sched_cls  name handle_policy  tag 73c9500bc8f59fb1  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 205
557: sched_cls  name cil_from_container  tag f32de962146ebe5d  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 206
558: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 207
559: sched_cls  name handle_policy  tag 7bb2a0449d29cc6f  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 200
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
567: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
575: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
615: sched_cls  name tail_handle_ipv4_cont  tag 63916452d3ea3c41  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 221
616: sched_cls  name tail_ipv4_ct_egress  tag ca5351060bee816f  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 222
617: sched_cls  name tail_ipv4_ct_ingress  tag 86b241b53a10dbea  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 223
618: sched_cls  name tail_ipv4_to_endpoint  tag 7d5d378cfabbee7a  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 224
620: sched_cls  name __send_drop_notify  tag 2923661db7374255  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 226
621: sched_cls  name handle_policy  tag 4bdb28f7ea588444  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 227
622: sched_cls  name tail_handle_arp  tag 889d923b9233c6fb  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 228
623: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 229
624: sched_cls  name cil_from_container  tag 1a3ba0d16513a4b3  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 230
625: sched_cls  name tail_handle_ipv4  tag 402066deecdc61fb  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 231
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
676: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
679: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
680: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
683: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
695: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
698: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3278: sched_cls  name __send_drop_notify  tag 253d94bc54031536  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3065
3279: sched_cls  name tail_handle_ipv4_cont  tag af1fcc60c9994a19  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,625,41,146,82,83,39,76,74,77,626,40,37,38,81
	btf_id 3066
3280: sched_cls  name tail_ipv4_ct_ingress  tag 967a1f760968f749  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,626,82,83,625,84
	btf_id 3067
3281: sched_cls  name cil_from_container  tag beaace8246066aeb  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 626,76
	btf_id 3068
3282: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,626
	btf_id 3069
3283: sched_cls  name handle_policy  tag 5db39da5a555f110  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,626,82,83,625,41,80,146,39,84,75,40,37,38
	btf_id 3070
3284: sched_cls  name tail_handle_arp  tag 875352539f57e223  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,626
	btf_id 3071
3285: sched_cls  name tail_handle_ipv4  tag 7ac16826c89f1c5d  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,626
	btf_id 3072
3287: sched_cls  name tail_ipv4_ct_egress  tag a7d2a2856beb95b8  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,626,82,83,625,84
	btf_id 3074
3288: sched_cls  name tail_ipv4_to_endpoint  tag 8a7e13d99567ac1c  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,625,41,82,83,80,146,39,626,40,37,38
	btf_id 3075
3311: sched_cls  name tail_handle_arp  tag f0ce459951094c31  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,631
	btf_id 3101
3312: sched_cls  name cil_from_container  tag 79e62934d07f574f  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3103
3313: sched_cls  name __send_drop_notify  tag 54ffb07eb825ecb2  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3104
3314: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3105
3315: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,631
	btf_id 3106
3316: sched_cls  name tail_handle_ipv4_cont  tag c3140b2001cff95e  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,632,41,143,82,83,39,76,74,77,631,40,37,38,81
	btf_id 3108
3317: sched_cls  name tail_ipv4_to_endpoint  tag fbfcc35658e8665e  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,151,39,633,40,37,38
	btf_id 3107
3318: sched_cls  name tail_handle_ipv4  tag 36cf35c0d0659809  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,631
	btf_id 3109
3319: sched_cls  name __send_drop_notify  tag 12bd6531b241ba2b  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3111
3320: sched_cls  name tail_handle_arp  tag c6f922cef2d3ee5f  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3110
3321: sched_cls  name tail_handle_ipv4  tag f72ac3c27307d00e  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3113
3322: sched_cls  name handle_policy  tag d0d10f60b8d2619f  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,631,82,83,632,41,80,143,39,84,75,40,37,38
	btf_id 3112
3323: sched_cls  name tail_handle_ipv4_cont  tag 919286fd2b41df24  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,151,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3114
3325: sched_cls  name tail_ipv4_ct_egress  tag f8345b1c98939412  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3117
3326: sched_cls  name tail_ipv4_ct_egress  tag 14c1aeb812c6c465  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,631,82,83,632,84
	btf_id 3115
3327: sched_cls  name handle_policy  tag 5f359259bcfd6b60  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,151,39,84,75,40,37,38
	btf_id 3119
3328: sched_cls  name tail_ipv4_to_endpoint  tag c12ff38b9704d6bd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,632,41,82,83,80,143,39,631,40,37,38
	btf_id 3118
3329: sched_cls  name cil_from_container  tag 344741fa11dbe2a2  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 631,76
	btf_id 3120
3331: sched_cls  name tail_ipv4_ct_ingress  tag 7494bed6ca03557c  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3121
3332: sched_cls  name tail_ipv4_ct_ingress  tag 2e3f155118dbc2fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,631,82,83,632,84
	btf_id 3123
