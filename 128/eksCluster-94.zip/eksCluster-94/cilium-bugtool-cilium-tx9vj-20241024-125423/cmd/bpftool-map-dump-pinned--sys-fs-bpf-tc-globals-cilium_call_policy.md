key: a8 01 00 00  value: 2c 02 00 00
key: 6a 02 00 00  value: 6d 02 00 00
key: 42 03 00 00  value: fa 0c 00 00
key: c9 03 00 00  value: 2f 02 00 00
key: 54 05 00 00  value: d3 0c 00 00
key: 95 06 00 00  value: ff 0c 00 00
key: ca 0c 00 00  value: 0a 02 00 00
Found 7 elements
