CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6d9cd66_4fb8_46fb_9efe_7133196d7abd.slice/cri-containerd-d1b3efa1227fa617526bda4da49f6af68aa33d1d5396126bf8089f1a7306a1f6.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6d9cd66_4fb8_46fb_9efe_7133196d7abd.slice/cri-containerd-999c99a3891d7d261956d3cdfc67fa32fc75d7feee73ad4a6b409052ae13a177.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80dd471a_7f96_448e_8ee0_4494085e921d.slice/cri-containerd-8042d1e000b1ac0693c52b841bec746324642677edfca989b65dcb0291affc60.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80dd471a_7f96_448e_8ee0_4494085e921d.slice/cri-containerd-a01beb17930b01c8f0047ccb390e3ef4dad6582b470c869ca441e228bc7dc05e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7aa18df3_3887_4ab4_b568_ab4e19b3e9f5.slice/cri-containerd-e3b9f3c5987aa8ab4c71e984e0f2d824c11fa4ab84f620d2be8550ae9da45093.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7aa18df3_3887_4ab4_b568_ab4e19b3e9f5.slice/cri-containerd-84868d4331cf9b72e7a5c57b4049e621d5a4c689bcf10988b79077a2f16052f2.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcde2c28_2f3e_43f4_9cba_7e280758d8fe.slice/cri-containerd-7ab7416a4d8c43135f2b6bdbbd758ae32aa5d9ae3b0d19cb3bde41b1aef8aac9.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcde2c28_2f3e_43f4_9cba_7e280758d8fe.slice/cri-containerd-47251f805518e2d40154779a468b24b990c292b7d3f4deacc8ef6728184e1d35.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84636fe6_8abb_4df5_a7df_157c4df53ce8.slice/cri-containerd-10d9115b92e4802b203461144f1148a08354bc050dd99f03d6fbdef68172f878.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84636fe6_8abb_4df5_a7df_157c4df53ce8.slice/cri-containerd-e1113fb639bdda778a82d649f94f2bf05a9fa3f5a37d4e126d610c5b2069bce6.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podafe6448e_f3a5_448c_8e81_c72d4d9d99fb.slice/cri-containerd-07b4b9f372485b94ee58e7e43b873e8dd0881df8349c2e8efcd1bedb975f108b.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podafe6448e_f3a5_448c_8e81_c72d4d9d99fb.slice/cri-containerd-1be87ef915938a62e48145d61d5a453e78287e53701df3f6be3e3cca7ae76226.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb10b8289_81ba_47b5_8eb9_62ae84adffa9.slice/cri-containerd-12cafbef74b90359398b775cb0a5eceffaf451901aea7b0a6a2de05e9daa62fc.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb10b8289_81ba_47b5_8eb9_62ae84adffa9.slice/cri-containerd-2c22f6e63fad20f018d998b8a75647e9f1a023a929296ed8f2cd226ad448e92a.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb10b8289_81ba_47b5_8eb9_62ae84adffa9.slice/cri-containerd-9300ae014c33dc07a70b0c2e85fa80c5a7937729be6954f934b3467d65f461b8.scope
    683      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa90f014_79a2_403c_bc7d_1672196d7c49.slice/cri-containerd-dee05d776c0df8db3340dcce80bfb5107724e5ff23c13a34e3ff27b50a68801f.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa90f014_79a2_403c_bc7d_1672196d7c49.slice/cri-containerd-6eb0032422011fef091379efaf953f048711d461ef65719c0be92d0eae2d79a1.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod549aa527_5fc0_4178_9610_da7e7e908831.slice/cri-containerd-10dbcd7f4fc7b23c671b6de1a5bf51d2ca7c9a1d98d5981eef2a2753c785e53c.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod549aa527_5fc0_4178_9610_da7e7e908831.slice/cri-containerd-49f0be6a32450482e8a1eb32b39b459e365bbd3182daf7c261f598340759c34d.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod549aa527_5fc0_4178_9610_da7e7e908831.slice/cri-containerd-4dfc5aa4d2a5530926069b4507d47a02b456df3d7962fce0f54ba559523f6892.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod549aa527_5fc0_4178_9610_da7e7e908831.slice/cri-containerd-f132cdddc21e278df0a53c56ff1b310a8a7a18919895cbfba6bc9b943b81dac2.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f92c7d7_a0d3_4748_b2bd_ae4c2ae2a1d2.slice/cri-containerd-1b0f49006dedfc6a5c09f22c151b9ad1277fe3606acc57b00dc0d94459de91d4.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f92c7d7_a0d3_4748_b2bd_ae4c2ae2a1d2.slice/cri-containerd-af860520a386ca26dbff5dac6638f7449fa897ad3dfa681d3ee9fe77ecdd38c6.scope
    109      cgroup_device   multi                                          
