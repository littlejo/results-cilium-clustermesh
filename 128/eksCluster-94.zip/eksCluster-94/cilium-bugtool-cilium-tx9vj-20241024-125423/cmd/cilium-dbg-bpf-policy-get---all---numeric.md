Endpoint ID: 319
Path: /sys/fs/bpf/tc/globals/cilium_policy_00319

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 424
Path: /sys/fs/bpf/tc/globals/cilium_policy_00424

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6240942   77305     0        
Allow    Ingress     1          ANY          NONE         disabled    62432     758       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 618
Path: /sys/fs/bpf/tc/globals/cilium_policy_00618

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6164772   61885     0        
Allow    Ingress     1          ANY          NONE         disabled    5324963   56145     0        
Allow    Egress      0          ANY          NONE         disabled    6678460   66096     0        


Endpoint ID: 834
Path: /sys/fs/bpf/tc/globals/cilium_policy_00834

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 969
Path: /sys/fs/bpf/tc/globals/cilium_policy_00969

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3792     38        0        
Allow    Ingress     1          ANY          NONE         disabled    132996   1522      0        
Allow    Egress      0          ANY          NONE         disabled    19223    213       0        


Endpoint ID: 1364
Path: /sys/fs/bpf/tc/globals/cilium_policy_01364

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    384272   4483      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1685
Path: /sys/fs/bpf/tc/globals/cilium_policy_01685

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3274
Path: /sys/fs/bpf/tc/globals/cilium_policy_03274

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2104     22        0        
Allow    Ingress     1          ANY          NONE         disabled    133458   1529      0        
Allow    Egress      0          ANY          NONE         disabled    19924    221       0        


