xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(5) clsact/ingress cil_from_netdev-ens6 id 510
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 495
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 492
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 557
lxce527e22ad1f7(12) clsact/ingress cil_from_container-lxce527e22ad1f7 id 532
lxc3001dc2426c0(14) clsact/ingress cil_from_container-lxc3001dc2426c0 id 549
lxcb586e2f05472(18) clsact/ingress cil_from_container-lxcb586e2f05472 id 624
lxc840d64e89a54(20) clsact/ingress cil_from_container-lxc840d64e89a54 id 3329
lxce4194bf7a38f(22) clsact/ingress cil_from_container-lxce4194bf7a38f id 3281
lxc99a754e50c4d(24) clsact/ingress cil_from_container-lxc99a754e50c4d id 3312

flow_dissector:

netfilter:

