REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     132358    10712460    677    bpf_overlay.c
Interface                   INGRESS     663907    246373188   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      132186    10708453    53     encap.h
Success                     EGRESS      148920    19780376    1308   bpf_lxc.c
Success                     EGRESS      55743     4518651     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     172916    19792032    86     l3.h
Success                     INGRESS     250758    26184610    235    trace.h
Unsupported L3 protocol     EGRESS      74        5600        1492   bpf_lxc.c
