 12:54:25 up 31 min,  0 users,  load average: 1.58, 0.81, 0.43
