1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ae:80:03:8a:1d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.159.1/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3509sec preferred_lft 3509sec
    inet6 fe80::4ae:80ff:fe03:8a1d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c5:b0:b0:f8:8d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.190.190/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4c5:b0ff:feb0:f88d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:63:a9:68:98:f0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c63:a9ff:fe68:98f0/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:2f:3a:d4:02:75 brd ff:ff:ff:ff:ff:ff
    inet 10.94.0.26/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ac2f:3aff:fed4:275/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2a:58:a8:45:81:5c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2858:a8ff:fe45:815c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:e2:5a:ee:71:1e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f0e2:5aff:feee:711e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce527e22ad1f7@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:de:61:15:d5:6c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::74de:61ff:fe15:d56c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3001dc2426c0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:2a:f9:b8:07:97 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::142a:f9ff:feb8:797/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb586e2f05472@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:a4:7c:94:a1:24 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1ca4:7cff:fe94:a124/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc840d64e89a54@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:e2:ea:c5:98:b2 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::20e2:eaff:fec5:98b2/64 scope link 
       valid_lft forever preferred_lft forever
22: lxce4194bf7a38f@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:3f:fe:97:43:9e brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::b43f:feff:fe97:439e/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc99a754e50c4d@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:d9:46:4b:8a:ae brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::ecd9:46ff:fe4b:8aae/64 scope link 
       valid_lft forever preferred_lft forever
