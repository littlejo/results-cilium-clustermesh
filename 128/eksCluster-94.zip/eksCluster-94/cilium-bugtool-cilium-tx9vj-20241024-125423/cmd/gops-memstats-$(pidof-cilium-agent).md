alloc: 77.09MB (80833016 bytes)
total-alloc: 3.08GB (3310883384 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75035951
frees: 74413374
heap-alloc: 77.09MB (80833016 bytes)
heap-sys: 176.38MB (184950784 bytes)
heap-idle: 54.78MB (57442304 bytes)
heap-in-use: 121.60MB (127508480 bytes)
heap-released: 7.55MB (7913472 bytes)
heap-objects: 622577
stack-in-use: 35.59MB (37322752 bytes)
stack-sys: 35.59MB (37322752 bytes)
stack-mspan-inuse: 2.05MB (2151360 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1001.42KB (1025457 bytes)
gc-sys: 5.50MB (5772408 bytes)
next-gc: when heap-alloc >= 149.39MB (156646680 bytes)
last-gc: 2024-10-24 12:54:45.817031044 +0000 UTC
gc-pause-total: 22.152889ms
gc-pause: 116794
gc-pause-end: 1729774485817031044
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006533762408199691
enable-gc: true
debug-gc: false
