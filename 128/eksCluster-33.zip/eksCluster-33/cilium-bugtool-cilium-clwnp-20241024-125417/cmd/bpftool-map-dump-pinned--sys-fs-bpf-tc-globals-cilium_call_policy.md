key: c5 01 00 00  value: 21 02 00 00
key: ce 01 00 00  value: 0b 0d 00 00
key: 3a 06 00 00  value: 0e 02 00 00
key: fa 06 00 00  value: 03 02 00 00
key: 58 07 00 00  value: 74 02 00 00
key: 60 08 00 00  value: 0c 0d 00 00
key: 94 09 00 00  value: d3 0c 00 00
Found 7 elements
