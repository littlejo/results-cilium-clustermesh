IP ADDRESS         LOCAL ENDPOINT INFO
172.31.207.135:0   (localhost)                                                                                        
10.33.0.201:0      id=1786  sec_id=4     flags=0x0000 ifindex=10  mac=36:A4:C9:AD:83:3C nodemac=02:B5:E7:64:4B:FF     
10.33.0.129:0      id=453   sec_id=2234376 flags=0x0000 ifindex=14  mac=0A:79:53:FA:14:33 nodemac=E6:F3:D6:9A:23:FC   
10.33.0.186:0      id=2452  sec_id=2233215 flags=0x0000 ifindex=22  mac=62:36:16:94:AD:D3 nodemac=5A:5F:42:DE:5E:07   
172.31.201.190:0   (localhost)                                                                                        
10.33.0.207:0      id=2144  sec_id=2254611 flags=0x0000 ifindex=24  mac=EA:FC:81:CD:A1:A0 nodemac=66:2B:C1:EF:D1:CD   
10.33.0.122:0      id=462   sec_id=2273171 flags=0x0000 ifindex=20  mac=2A:21:5C:C4:62:22 nodemac=7A:2D:84:FD:69:51   
10.33.0.93:0       id=1594  sec_id=2234376 flags=0x0000 ifindex=12  mac=9E:06:76:4E:29:5C nodemac=1E:02:F9:1C:DE:B4   
10.33.0.213:0      (localhost)                                                                                        
10.33.0.178:0      id=1880  sec_id=2279997 flags=0x0000 ifindex=18  mac=CA:E8:73:52:96:BD nodemac=92:FC:FC:81:89:D1   
