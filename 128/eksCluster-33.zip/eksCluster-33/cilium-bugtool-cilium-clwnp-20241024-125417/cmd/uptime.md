 12:54:19 up 33 min,  0 users,  load average: 0.59, 0.60, 0.32
