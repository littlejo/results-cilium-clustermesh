1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d0:bb:91:8c:53 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.207.135/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3426sec preferred_lft 3426sec
    inet6 fe80::8d0:bbff:fe91:8c53/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:3c:f6:0f:e2:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.201.190/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::83c:f6ff:fe0f:e2cb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:d6:aa:b7:38:a3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1cd6:aaff:feb7:38a3/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:9b:b9:9b:f3:a7 brd ff:ff:ff:ff:ff:ff
    inet 10.33.0.213/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::889b:b9ff:fe9b:f3a7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 72:1e:7c:05:99:e7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::701e:7cff:fe05:99e7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:b5:e7:64:4b:ff brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b5:e7ff:fe64:4bff/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd82366107d2e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:02:f9:1c:de:b4 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1c02:f9ff:fe1c:deb4/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8b748a17e4e9@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:f3:d6:9a:23:fc brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e4f3:d6ff:fe9a:23fc/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc00794fa36417@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:fc:fc:81:89:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::90fc:fcff:fe81:89d1/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc56b5ad31b6bf@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:2d:84:fd:69:51 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::782d:84ff:fefd:6951/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc57b5963e3b4f@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:5f:42:de:5e:07 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::585f:42ff:fede:5e07/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc90b4285ea7a0@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:2b:c1:ef:d1:cd brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::642b:c1ff:feef:d1cd/64 scope link 
       valid_lft forever preferred_lft forever
