Node 0, zone      DMA    343     40      5     38     25     53     32      6      2      3     44 
Node 0, zone   Normal      3     51      7      0      2      3      2      3      1      1      9 
