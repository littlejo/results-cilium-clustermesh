Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable    342     38      2     38     23      7      4      3      2      1      0 
Node    0, zone      DMA, type      Movable      1      1      1      0      1     46     27      3      0      1     28 
Node    0, zone      DMA, type  Reclaimable      0      1      0      1      1      0      1      1      1      1      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      0      1      0      0      0      1      0      0      1     15 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable      0     50      6      0      0      2      0      1      0      0      1 
Node    0, zone   Normal, type      Movable      0      0      0      0      1      1      1      1      0      0      8 
Node    0, zone   Normal, type  Reclaimable      3      1      1      0      1      0      1      1      1      1      0 
Node    0, zone   Normal, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA           40          424           16            0           32            0 
Node 0, zone   Normal          104         1364           32            0            0            0 
