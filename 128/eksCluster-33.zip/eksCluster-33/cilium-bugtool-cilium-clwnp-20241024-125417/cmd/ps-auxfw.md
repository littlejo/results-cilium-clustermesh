USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3182  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3176  0.0  0.4 1240432 16420 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3205  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3206  0.0  0.0   3852  1288 ?        R    12:54   0:00  \_ bash -c hostname
root           1  4.2  7.4 1538804 292864 ?      Ssl  12:27   1:08 cilium-agent --config-dir=/tmp/cilium/config-map
root         400  0.2  0.2 1229744 9948 ?        Sl   12:27   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
