[
  {
    "containers": [
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode87512e1_1e52_44e7_a774_e36261792882.slice/cri-containerd-58d3ac7e513b842496095c6357dc0e5f967482b9af6b0c561774f374ae3244de.scope"
      },
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode87512e1_1e52_44e7_a774_e36261792882.slice/cri-containerd-4f07621ef533966e8ffa9bda55487ef34404c11afdda7173f27a3990df013b00.scope"
      }
    ],
    "ips": [
      "10.33.0.186"
    ],
    "name": "echo-same-node-86d9cc975c-9z55g",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7620,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2c46867_1fc0_412c_bc66_87408472210a.slice/cri-containerd-220ba658d58991c62d05264720a4ce07d1fa73a91437141e207fa7e7bbccde8b.scope"
      }
    ],
    "ips": [
      "10.33.0.93"
    ],
    "name": "coredns-cc6ccd49c-67fbz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98df6a4f_679a_40c6_97bd_61f522391b24.slice/cri-containerd-98ad825522fd1afb4a3d98d0f294926962bbd644a9aa3278779d3d726effd0f8.scope"
      }
    ],
    "ips": [
      "10.33.0.207"
    ],
    "name": "client2-57cf4468f-r249n",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7704,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f4f0f47_ecf8_4812_bdde_6ee02b0a9762.slice/cri-containerd-2f8753ada8fa14e9ba96e523ec36809d634d4ce0c1e4873cae9548e53828a122.scope"
      }
    ],
    "ips": [
      "10.33.0.129"
    ],
    "name": "coredns-cc6ccd49c-jbrxw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb617fa8e_dd4b_499d_8cc1_a37f8630f684.slice/cri-containerd-824213253ee9aa1eb28d3950657c3f93211b0d0694a15a24f7902b620a89fa81.scope"
      }
    ],
    "ips": [
      "10.33.0.122"
    ],
    "name": "client-974f6c69d-m6zx9",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e9aa868_26cd_4ff4_9bc8_568423a27d55.slice/cri-containerd-fe7e76532c1abc5895902f2abcbc1ac359e73e959ac69f39684b7af09e785c4a.scope"
      },
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e9aa868_26cd_4ff4_9bc8_568423a27d55.slice/cri-containerd-bf853cbaa301f205ee748740d88628403ade1c8ff4fe1bcc27ad0f28ce77ca26.scope"
      },
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e9aa868_26cd_4ff4_9bc8_568423a27d55.slice/cri-containerd-a6a790290cf3bbe2b92af0821a76f69edd968e813d10e053ef5b27264614e478.scope"
      }
    ],
    "ips": [
      "10.33.0.178"
    ],
    "name": "clustermesh-apiserver-56c84ccb84-k8lkj",
    "namespace": "kube-system"
  }
]

