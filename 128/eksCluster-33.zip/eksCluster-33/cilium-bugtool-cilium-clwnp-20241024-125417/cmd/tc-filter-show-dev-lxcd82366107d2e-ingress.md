filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd82366107d2e direct-action not_in_hw id 521 tag 92dcd9caf0c64f21 jited 
