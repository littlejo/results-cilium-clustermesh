alloc: 97.70MB (102446000 bytes)
total-alloc: 3.02GB (3244933552 bytes)
sys: 219.07MB (229713236 bytes)
lookups: 0
mallocs: 73963294
frees: 72954055
heap-alloc: 97.70MB (102446000 bytes)
heap-sys: 172.66MB (181051392 bytes)
heap-idle: 51.05MB (53526528 bytes)
heap-in-use: 121.62MB (127524864 bytes)
heap-released: 7.38MB (7741440 bytes)
heap-objects: 1009239
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.03MB (2126080 bytes)
stack-mspan-sys: 2.72MB (2856000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 780.56KB (799297 bytes)
gc-sys: 5.52MB (5784768 bytes)
next-gc: when heap-alloc >= 149.04MB (156281480 bytes)
last-gc: 2024-10-24 12:54:24.415983859 +0000 UTC
gc-pause-total: 29.950124ms
gc-pause: 114412
gc-pause-end: 1729774464415983859
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005814739760608705
enable-gc: true
debug-gc: false
