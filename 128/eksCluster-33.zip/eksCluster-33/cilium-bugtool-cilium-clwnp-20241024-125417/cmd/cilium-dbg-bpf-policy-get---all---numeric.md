Endpoint ID: 453
Path: /sys/fs/bpf/tc/globals/cilium_policy_00453

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2342     25        0        
Allow    Ingress     1          ANY          NONE         disabled    156324   1790      0        
Allow    Egress      0          ANY          NONE         disabled    21205    237       0        


Endpoint ID: 462
Path: /sys/fs/bpf/tc/globals/cilium_policy_00462

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 651
Path: /sys/fs/bpf/tc/globals/cilium_policy_00651

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1594
Path: /sys/fs/bpf/tc/globals/cilium_policy_01594

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3554     35        0        
Allow    Ingress     1          ANY          NONE         disabled    155603   1784      0        
Allow    Egress      0          ANY          NONE         disabled    20825    232       0        


Endpoint ID: 1786
Path: /sys/fs/bpf/tc/globals/cilium_policy_01786

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6233952   77045     0        
Allow    Ingress     1          ANY          NONE         disabled    62294     750       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1880
Path: /sys/fs/bpf/tc/globals/cilium_policy_01880

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6058703   59767     0        
Allow    Ingress     1          ANY          NONE         disabled    4765338   49824     0        
Allow    Egress      0          ANY          NONE         disabled    5707164   57576     0        


Endpoint ID: 2144
Path: /sys/fs/bpf/tc/globals/cilium_policy_02144

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2452
Path: /sys/fs/bpf/tc/globals/cilium_policy_02452

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378720   4418      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


