CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod688b692e_d3de_421f_b090_04d05924b033.slice/cri-containerd-9a18ed42368f5d455ffc7cb729a4e5b4df3b2661968976d8f16687ae1f94ecb3.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod688b692e_d3de_421f_b090_04d05924b033.slice/cri-containerd-3c0b0f7b971dd3ab7029de0437a2a963c6e3d16640a688e8907482ece51b6c27.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod667cd771_d6ed_4002_8575_c0cf912c9fa7.slice/cri-containerd-2d13f969e12119334daef59f403c456f30b81869f32a28a2f3eae76fce4a184a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod667cd771_d6ed_4002_8575_c0cf912c9fa7.slice/cri-containerd-3cbc7d6b39cd4df0c006356065bfcf709b0178fcfae6c8b102d5311d7391fa61.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2c46867_1fc0_412c_bc66_87408472210a.slice/cri-containerd-b8863cb1789ce1b46dc2d6aeef665ddacac6f3382b880319c1261386935b038e.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2c46867_1fc0_412c_bc66_87408472210a.slice/cri-containerd-220ba658d58991c62d05264720a4ce07d1fa73a91437141e207fa7e7bbccde8b.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f4f0f47_ecf8_4812_bdde_6ee02b0a9762.slice/cri-containerd-bd02abc8db1f374be66bb467fec809e663fb531f1c198edfa0caef4f2235a455.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f4f0f47_ecf8_4812_bdde_6ee02b0a9762.slice/cri-containerd-2f8753ada8fa14e9ba96e523ec36809d634d4ce0c1e4873cae9548e53828a122.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e9aa868_26cd_4ff4_9bc8_568423a27d55.slice/cri-containerd-ad1308fd5adad8c3065d82b76c51fc0feffec0552a18b16bd7a8d6134124cddd.scope
    644      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e9aa868_26cd_4ff4_9bc8_568423a27d55.slice/cri-containerd-a6a790290cf3bbe2b92af0821a76f69edd968e813d10e053ef5b27264614e478.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e9aa868_26cd_4ff4_9bc8_568423a27d55.slice/cri-containerd-bf853cbaa301f205ee748740d88628403ade1c8ff4fe1bcc27ad0f28ce77ca26.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e9aa868_26cd_4ff4_9bc8_568423a27d55.slice/cri-containerd-fe7e76532c1abc5895902f2abcbc1ac359e73e959ac69f39684b7af09e785c4a.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff465aef_2597_4266_9763_81971ae5a861.slice/cri-containerd-12ba23f36f356f40652603f0a38006fc046498a14624f2fbc81954a6e0439b3f.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff465aef_2597_4266_9763_81971ae5a861.slice/cri-containerd-1010a3f0b1832c5ab4a23b6d9a3b97749bf6443deb588f5016e758a172b80229.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode87512e1_1e52_44e7_a774_e36261792882.slice/cri-containerd-58d3ac7e513b842496095c6357dc0e5f967482b9af6b0c561774f374ae3244de.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode87512e1_1e52_44e7_a774_e36261792882.slice/cri-containerd-9899eabde79afd29648a16b814803784018b21b73835e1d37edad2a921235055.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode87512e1_1e52_44e7_a774_e36261792882.slice/cri-containerd-4f07621ef533966e8ffa9bda55487ef34404c11afdda7173f27a3990df013b00.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98df6a4f_679a_40c6_97bd_61f522391b24.slice/cri-containerd-98ad825522fd1afb4a3d98d0f294926962bbd644a9aa3278779d3d726effd0f8.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98df6a4f_679a_40c6_97bd_61f522391b24.slice/cri-containerd-4c6ac453104df2b569c6bf9c3cb57971674483392688e563e01ea1b78bb93c82.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb617fa8e_dd4b_499d_8cc1_a37f8630f684.slice/cri-containerd-4579319fbd99935486e4942b1736337fabdbcb41a0dfdcbcc4bd5a331054edd9.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb617fa8e_dd4b_499d_8cc1_a37f8630f684.slice/cri-containerd-824213253ee9aa1eb28d3950657c3f93211b0d0694a15a24f7902b620a89fa81.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a73e81e_64f8_49eb_b07b_47524d49801a.slice/cri-containerd-155f448b11f548693730390ac223f68f2d727668de9a1027d72d1c5aa4f0595c.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a73e81e_64f8_49eb_b07b_47524d49801a.slice/cri-containerd-e81b2e52c549ad1c530f3e01becbc58f81cd0f04af716d19c58aff80d32645de.scope
    105      cgroup_device   multi                                          
