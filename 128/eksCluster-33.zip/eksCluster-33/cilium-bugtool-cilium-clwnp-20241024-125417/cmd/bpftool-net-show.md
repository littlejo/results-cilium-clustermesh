xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 578
ens6(5) clsact/ingress cil_from_netdev-ens6 id 584
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 572
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 563
cilium_host(7) clsact/egress cil_from_host-cilium_host id 562
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 513
lxcd82366107d2e(12) clsact/ingress cil_from_container-lxcd82366107d2e id 521
lxc8b748a17e4e9(14) clsact/ingress cil_from_container-lxc8b748a17e4e9 id 549
lxc00794fa36417(18) clsact/ingress cil_from_container-lxc00794fa36417 id 630
lxc56b5ad31b6bf(20) clsact/ingress cil_from_container-lxc56b5ad31b6bf id 3353
lxc57b5963e3b4f(22) clsact/ingress cil_from_container-lxc57b5963e3b4f id 3297
lxc90b4285ea7a0(24) clsact/ingress cil_from_container-lxc90b4285ea7a0 id 3341

flow_dissector:

netfilter:

