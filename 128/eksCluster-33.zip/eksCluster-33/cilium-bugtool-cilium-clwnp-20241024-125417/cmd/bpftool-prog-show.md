35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:18+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:18+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:19+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:19+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:19+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:19+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:23+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:27:20+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:27:20+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:27:20+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag 9a63b5c7edefefd2  gpl
	loaded_at 2024-10-24T12:27:20+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
510: sched_cls  name tail_handle_arp  tag dd43e6bc31be29c1  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 153
511: sched_cls  name tail_handle_ipv4  tag a2f2748c0e03804f  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 154
512: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 155
513: sched_cls  name cil_from_container  tag fecc1b907da4907d  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,76
	btf_id 156
514: sched_cls  name __send_drop_notify  tag 07392a07b97ac9b5  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 157
515: sched_cls  name handle_policy  tag 5f939aff3e14645a  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 158
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 160
518: sched_cls  name tail_handle_ipv4_cont  tag 143d0d7a5e80c1fb  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 161
519: sched_cls  name tail_ipv4_to_endpoint  tag 39910d74726bc589  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 162
520: sched_cls  name tail_ipv4_ct_ingress  tag 48ed1db696969b55  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 163
521: sched_cls  name cil_from_container  tag 92dcd9caf0c64f21  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 165
522: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 166
523: sched_cls  name __send_drop_notify  tag a7656ae72772c602  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 167
524: sched_cls  name tail_handle_ipv4_cont  tag a93c48e2241f85eb  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,110,40,37,38,81
	btf_id 168
526: sched_cls  name handle_policy  tag ecd01acaebf8cd28  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 170
527: sched_cls  name tail_ipv4_ct_egress  tag eaba7071677b47ad  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 171
528: sched_cls  name tail_handle_arp  tag 8c325e5df6a875b1  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 172
529: sched_cls  name tail_ipv4_to_endpoint  tag 4a3e49595a7ee6b7  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,110,40,37,38
	btf_id 173
530: sched_cls  name tail_handle_ipv4  tag fb5de603912b1fec  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 174
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
536: sched_cls  name tail_ipv4_ct_ingress  tag 3caf38df05decb8d  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 175
539: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
540: sched_cls  name tail_handle_ipv4_cont  tag d9a49b534d51e7aa  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,101,82,83,39,76,74,77,114,40,37,38,81
	btf_id 177
541: sched_cls  name tail_handle_arp  tag 8e025344b924f711  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 178
543: sched_cls  name tail_ipv4_ct_egress  tag eaba7071677b47ad  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 180
544: sched_cls  name tail_ipv4_to_endpoint  tag 41f9e71a3847b385  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,101,39,114,40,37,38
	btf_id 181
545: sched_cls  name handle_policy  tag 41c20cd2473028f4  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,114,82,83,113,41,80,101,39,84,75,40,37,38
	btf_id 182
546: sched_cls  name __send_drop_notify  tag 3cf920cb75d5658a  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 183
547: sched_cls  name tail_handle_ipv4  tag 4de57d19d62ee8ee  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 184
548: sched_cls  name tail_ipv4_ct_ingress  tag 23890c7e49bc4ba0  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 185
549: sched_cls  name cil_from_container  tag 5dfa2e9ad3682e33  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,76
	btf_id 186
550: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
561: sched_cls  name __send_drop_notify  tag 002b105be9219f2e  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
562: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 192
563: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
564: sched_cls  name tail_handle_ipv4_from_host  tag d16fb73dc5abe8ce  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 194
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 195
566: sched_cls  name tail_handle_ipv4_from_host  tag d16fb73dc5abe8ce  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 197
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 198
570: sched_cls  name __send_drop_notify  tag 002b105be9219f2e  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
572: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
573: sched_cls  name __send_drop_notify  tag 002b105be9219f2e  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
576: sched_cls  name tail_handle_ipv4_from_host  tag d16fb73dc5abe8ce  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 208
577: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 209
578: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 210
582: sched_cls  name tail_handle_ipv4_from_host  tag d16fb73dc5abe8ce  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 215
583: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 216
584: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 217
586: sched_cls  name __send_drop_notify  tag 002b105be9219f2e  gpl
	loaded_at 2024-10-24T12:27:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
626: sched_cls  name tail_ipv4_ct_ingress  tag 1e2ec4ffcfaaada7  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 233
627: sched_cls  name tail_ipv4_to_endpoint  tag 68d75aa2da43a609  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 234
628: sched_cls  name handle_policy  tag 899024363e47f0c6  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 235
629: sched_cls  name __send_drop_notify  tag 708220418f7f9b65  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 236
630: sched_cls  name cil_from_container  tag 2695a3e29dfc7fc9  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 237
631: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 238
632: sched_cls  name tail_handle_ipv4  tag adb2b2856c87f3bf  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 239
633: sched_cls  name tail_ipv4_ct_egress  tag bdc2cdb752b7a38e  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 240
634: sched_cls  name tail_handle_ipv4_cont  tag b0c09526e604bad2  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 241
636: sched_cls  name tail_handle_arp  tag 5ebc5a690f706d3f  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 243
641: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
644: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
687: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
690: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
691: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
694: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3280: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,628
	btf_id 3069
3283: sched_cls  name handle_policy  tag d2ccbde2ff8e3856  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,628,82,83,627,41,80,148,39,84,75,40,37,38
	btf_id 3070
3285: sched_cls  name tail_handle_ipv4_cont  tag 9dc19c01b3955b87  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,627,41,148,82,83,39,76,74,77,628,40,37,38,81
	btf_id 3073
3286: sched_cls  name tail_handle_arp  tag 30d27cef63a2ae57  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,628
	btf_id 3075
3288: sched_cls  name tail_ipv4_to_endpoint  tag 288fd467386fba7f  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,627,41,82,83,80,148,39,628,40,37,38
	btf_id 3076
3290: sched_cls  name tail_ipv4_ct_egress  tag cf5747c4c1e22bf4  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3078
3294: sched_cls  name tail_handle_ipv4  tag dac30ebcb72cbaea  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,628
	btf_id 3080
3295: sched_cls  name tail_ipv4_ct_ingress  tag a564e8b203cbc01e  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3084
3297: sched_cls  name cil_from_container  tag cd8fdb3c23706986  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 628,76
	btf_id 3085
3299: sched_cls  name __send_drop_notify  tag ebe46912cdb78de1  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3087
3334: sched_cls  name tail_handle_arp  tag 6938a668f5b8f46d  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3128
3335: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3127
3336: sched_cls  name tail_ipv4_ct_egress  tag 81929e9ca4d03508  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3130
3338: sched_cls  name tail_handle_arp  tag 2ffafcb5bb24fd43  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3132
3339: sched_cls  name handle_policy  tag fc1c38f130dc8f25  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,145,39,84,75,40,37,38
	btf_id 3129
3340: sched_cls  name handle_policy  tag ecce1bca116eed3c  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,153,39,84,75,40,37,38
	btf_id 3133
3341: sched_cls  name cil_from_container  tag eb83a3c584a0f24f  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3135
3342: sched_cls  name tail_handle_ipv4  tag d57956d8fbaa4feb  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3134
3343: sched_cls  name tail_handle_ipv4  tag 06815617e2488477  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3136
3344: sched_cls  name __send_drop_notify  tag 26ed32c0c9420dc3  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3138
3345: sched_cls  name tail_ipv4_ct_ingress  tag 00d13ccc9d5dafb8  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3137
3346: sched_cls  name tail_ipv4_ct_ingress  tag a038dbf013c95b4d  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3139
3347: sched_cls  name tail_handle_ipv4_cont  tag b9b8b89c92058d2c  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,153,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3140
3348: sched_cls  name tail_ipv4_ct_egress  tag ba5c25a8a98fac82  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3141
3349: sched_cls  name __send_drop_notify  tag 0efe0612cabe8d04  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3143
3350: sched_cls  name tail_ipv4_to_endpoint  tag 12fe5eb507bed509  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,153,39,637,40,37,38
	btf_id 3142
3351: sched_cls  name tail_ipv4_to_endpoint  tag 134ab8764b475054  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,145,39,636,40,37,38
	btf_id 3144
3352: sched_cls  name tail_handle_ipv4_cont  tag c4a5394a589a4c5f  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,145,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3145
3353: sched_cls  name cil_from_container  tag b893ab4c691e4a26  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3146
3354: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3147
