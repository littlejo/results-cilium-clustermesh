IP ADDRESS         LOCAL ENDPOINT INFO
10.8.0.168:0       id=373   sec_id=4     flags=0x0000 ifindex=10  mac=6E:57:71:D3:27:5D nodemac=7A:39:5A:11:60:CD    
10.8.0.25:0        id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC   
10.8.0.8:0         id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A   
10.8.0.117:0       id=654   sec_id=652009 flags=0x0000 ifindex=18  mac=62:00:05:7D:E7:10 nodemac=56:0A:99:E5:3D:71   
172.31.185.116:0   (localhost)                                                                                       
10.8.0.180:0       id=2562  sec_id=614716 flags=0x0000 ifindex=12  mac=26:47:01:EE:81:F6 nodemac=8E:B4:07:6A:3D:B1   
10.8.0.245:0       (localhost)                                                                                       
10.8.0.252:0       id=3572  sec_id=614716 flags=0x0000 ifindex=14  mac=2A:09:5C:2F:D9:87 nodemac=E6:6A:43:A0:D4:A4   
10.8.0.97:0        id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8   
172.31.163.236:0   (localhost)                                                                                       
