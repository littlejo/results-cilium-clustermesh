filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcdc32df5c0ace direct-action not_in_hw id 3305 tag 5868aa3d26798c2f jited 
