key: 1c 00 00 00  value: ec 0c 00 00
key: 75 01 00 00  value: 06 02 00 00
key: 8e 02 00 00  value: 6e 02 00 00
key: 10 03 00 00  value: f5 0c 00 00
key: b4 04 00 00  value: b3 0c 00 00
key: 02 0a 00 00  value: 20 02 00 00
key: f4 0d 00 00  value: f8 01 00 00
Found 7 elements
