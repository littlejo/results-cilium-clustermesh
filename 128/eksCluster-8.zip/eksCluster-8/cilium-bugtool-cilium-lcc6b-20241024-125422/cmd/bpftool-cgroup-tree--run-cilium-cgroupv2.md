CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d9de32c_aa25_4043_9d44_47023cfd26c4.slice/cri-containerd-1a7df851ad3f0c9ff6e5cb668b6a5343e7fab6b9f64af3ede59cf3558b20b540.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d9de32c_aa25_4043_9d44_47023cfd26c4.slice/cri-containerd-3a83a98f572eca54143a397ab5ba4ee7c222d44573462ae8c0157e792d6c268d.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c17b366_ffd4_4e01_a9cb_92ac01439d73.slice/cri-containerd-9339f7cb6e835e5b73ccbac17dc4b72a253ed7b71774985410c590b51966abb6.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c17b366_ffd4_4e01_a9cb_92ac01439d73.slice/cri-containerd-99e83e84e9b65a43af966bed79eb18eba068eb21aee8def9e81f01a493e58f38.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3b432955_5f44_4cf9_be5f_5dc8f1e806ac.slice/cri-containerd-377cfe1f102e1ad49431a1a75574dc1e2f4f2688e85f3ed2aeee1540f1339fbc.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3b432955_5f44_4cf9_be5f_5dc8f1e806ac.slice/cri-containerd-0d15a2cb6355a7272b5c32d3555d8b379c7c9214a4b2bfdd6f3d722c9b2fb202.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod90f01991_2518_4b20_b3a1_c59f4728c0bb.slice/cri-containerd-4bb10e9b357548a98ca5fd991920595a9362cf023080a788f611c4c02e32f305.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod90f01991_2518_4b20_b3a1_c59f4728c0bb.slice/cri-containerd-a53de55ea5ab80430c7f2a9d0cd63273c5e2e358c07a2434db207e8b7700bec7.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode4116fc3_234a_4e40_98ed_60b8c9b0cbfc.slice/cri-containerd-4bb333189a59135d677f3ebd64ec0a7bfa5f26c40034879148cd42f7da0b3d7e.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode4116fc3_234a_4e40_98ed_60b8c9b0cbfc.slice/cri-containerd-d50a3244180679c9f2c394d0d8668625a244919f1fe5d9a9bae60256bdece841.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd08530cd_86a6_47e6_a171_da7ff6cbbe32.slice/cri-containerd-dd0023ec47ce9a4caa13714143d600960e05a724df3c367f56f902a6c7944e11.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd08530cd_86a6_47e6_a171_da7ff6cbbe32.slice/cri-containerd-c1c50219d11056bc62c15c58f4cd65df808b576ad30d48f985c405986699ec8d.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd08530cd_86a6_47e6_a171_da7ff6cbbe32.slice/cri-containerd-b5a0b4d02080761354c14ca8f99a888561064924bae5e107481ca14ea39b72e3.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd08530cd_86a6_47e6_a171_da7ff6cbbe32.slice/cri-containerd-b03ee638fe7c948140e09bb45fce9762cc2b548fed5120f19fdcef8affa2202f.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54dba559_73ba_4459_89ce_66b2720ba3bd.slice/cri-containerd-4dff33c1243754172a37d641b5c7dcd23e2145ec13e43e39194e8c2889a15921.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54dba559_73ba_4459_89ce_66b2720ba3bd.slice/cri-containerd-83dbf1e26e23bc1d11a8bdc0f9ee70896c5fffe17b5aa5849c8f2768a811c187.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod975d86cb_47ed_496f_98c8_966fd9616293.slice/cri-containerd-c465384b86317131b4cbe9b9255d91c7b2deb6ba385be5c7eba6fefaae5e5807.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod975d86cb_47ed_496f_98c8_966fd9616293.slice/cri-containerd-95d2524958b3ca756bbc67241477008e0cd6cadf5c73c7bbba17df4ada0c1766.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b19e7fd_ecc8_406e_8f03_d98eacf4110f.slice/cri-containerd-e4f73c2e0c24e1fa9427fbc138665b2de865eac4140b441cf4231f0c1c01263b.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b19e7fd_ecc8_406e_8f03_d98eacf4110f.slice/cri-containerd-b1858d886e32e8c4eea0591a968ef9bba344800bde99ffa6c9cc5f0aaeb76635.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0afc809_fb37_4618_b1ed_3cef49ad9ec9.slice/cri-containerd-a0f9d5088336f441e4d3bf9d3d83c4e646ee70380d12792a5fe51d7275f1f85e.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0afc809_fb37_4618_b1ed_3cef49ad9ec9.slice/cri-containerd-f4fb4c4fc34fdc3b80b0a61f9e2b0de967b8f4cfca384ffb25f6db1a5210a928.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0afc809_fb37_4618_b1ed_3cef49ad9ec9.slice/cri-containerd-42a47de26294309e7ae3075e1b0b1a237b55365cae0de520018eaed8afa0b1bf.scope
    711      cgroup_device   multi                                          
