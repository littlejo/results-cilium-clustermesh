[
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0afc809_fb37_4618_b1ed_3cef49ad9ec9.slice/cri-containerd-42a47de26294309e7ae3075e1b0b1a237b55365cae0de520018eaed8afa0b1bf.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0afc809_fb37_4618_b1ed_3cef49ad9ec9.slice/cri-containerd-f4fb4c4fc34fdc3b80b0a61f9e2b0de967b8f4cfca384ffb25f6db1a5210a928.scope"
      }
    ],
    "ips": [
      "10.8.0.25"
    ],
    "name": "echo-same-node-86d9cc975c-shzkc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3b432955_5f44_4cf9_be5f_5dc8f1e806ac.slice/cri-containerd-377cfe1f102e1ad49431a1a75574dc1e2f4f2688e85f3ed2aeee1540f1339fbc.scope"
      }
    ],
    "ips": [
      "10.8.0.180"
    ],
    "name": "coredns-cc6ccd49c-tw2pr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd08530cd_86a6_47e6_a171_da7ff6cbbe32.slice/cri-containerd-b03ee638fe7c948140e09bb45fce9762cc2b548fed5120f19fdcef8affa2202f.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd08530cd_86a6_47e6_a171_da7ff6cbbe32.slice/cri-containerd-b5a0b4d02080761354c14ca8f99a888561064924bae5e107481ca14ea39b72e3.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd08530cd_86a6_47e6_a171_da7ff6cbbe32.slice/cri-containerd-dd0023ec47ce9a4caa13714143d600960e05a724df3c367f56f902a6c7944e11.scope"
      }
    ],
    "ips": [
      "10.8.0.117"
    ],
    "name": "clustermesh-apiserver-54844cb554-7tt6b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b19e7fd_ecc8_406e_8f03_d98eacf4110f.slice/cri-containerd-b1858d886e32e8c4eea0591a968ef9bba344800bde99ffa6c9cc5f0aaeb76635.scope"
      }
    ],
    "ips": [
      "10.8.0.97"
    ],
    "name": "client2-57cf4468f-p56lw",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c17b366_ffd4_4e01_a9cb_92ac01439d73.slice/cri-containerd-99e83e84e9b65a43af966bed79eb18eba068eb21aee8def9e81f01a493e58f38.scope"
      }
    ],
    "ips": [
      "10.8.0.252"
    ],
    "name": "coredns-cc6ccd49c-8dqxg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod975d86cb_47ed_496f_98c8_966fd9616293.slice/cri-containerd-95d2524958b3ca756bbc67241477008e0cd6cadf5c73c7bbba17df4ada0c1766.scope"
      }
    ],
    "ips": [
      "10.8.0.8"
    ],
    "name": "client-974f6c69d-ln7wh",
    "namespace": "cilium-test-1"
  }
]

