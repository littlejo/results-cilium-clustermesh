xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 574
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 553
cilium_host(7) clsact/egress cil_from_host-cilium_host id 557
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 516
lxcabcde6badbb0(12) clsact/ingress cil_from_container-lxcabcde6badbb0 id 534
lxcd1982fe88eee(14) clsact/ingress cil_from_container-lxcd1982fe88eee id 512
lxcd2a9fbcbc62e(18) clsact/ingress cil_from_container-lxcd2a9fbcbc62e id 625
lxcca12ef5f74df(20) clsact/ingress cil_from_container-lxcca12ef5f74df id 3315
lxcca14187eebb6(22) clsact/ingress cil_from_container-lxcca14187eebb6 id 3250
lxcdc32df5c0ace(24) clsact/ingress cil_from_container-lxcdc32df5c0ace id 3305

flow_dissector:

netfilter:

