Node 0, zone      DMA      3      2      2      1      9      4      5      2      3      3     49 
Node 0, zone   Normal    197      9      8      0      4      6      4      2      2      4      7 
