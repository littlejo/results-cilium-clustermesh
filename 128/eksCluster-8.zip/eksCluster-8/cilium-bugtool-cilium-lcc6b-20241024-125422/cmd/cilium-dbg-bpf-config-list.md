KEY             VALUE
AgentLiveness   2037751948743
UTimeOffset     3378461773437500
