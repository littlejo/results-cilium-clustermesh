{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.991Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.036Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.048Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.072Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.321Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.328Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.425Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.501Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.518Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.042Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.050Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.074Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.107Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.129Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.166Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.181Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.392Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.410Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.450Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.489Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.495Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.103Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.110Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.134Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.149Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.192Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.196Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.226Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.451Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.463Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.527Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.534Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.566Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.095Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.100Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.204Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.236Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.280Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.291Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.463Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.468Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.523Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.554Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.565Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.959Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.963Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.009Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.031Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.053Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.266Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.278Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.342Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.347Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.381Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.753Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.786Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.807Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.860Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.866Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.904Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.204Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.226Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.298Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.332Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.337Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.692Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.721Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.730Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.772Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.785Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.812Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.030Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.036Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.084Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.085Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.132Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.490Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.524Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.536Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.564Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.564Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.586Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.865Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.878Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.914Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.929Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.963Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.360Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.431Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.460Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.530Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.530Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.540Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.728Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.733Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.775Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.777Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.812Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.826Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.216Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.223Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.271Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.277Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.308Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.522Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.531Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.577Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.587Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.627Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.932Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.966Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.972Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.018Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.025Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.056Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.351Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.355Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.393Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.432Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.061Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.064Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.095Z",
  "value": "id=1204  sec_id=621304 flags=0x0000 ifindex=22  mac=8A:61:15:9B:E4:25 nodemac=BA:EB:DB:0A:70:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.126Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.138Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.399Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.408Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.091Z",
  "value": "id=28    sec_id=607882 flags=0x0000 ifindex=20  mac=DE:5D:97:23:A9:B0 nodemac=52:4D:F7:0F:B7:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.094Z",
  "value": "id=784   sec_id=600811 flags=0x0000 ifindex=24  mac=06:6D:78:4C:12:72 nodemac=BE:3B:DE:B9:0D:E8"
}

