alloc: 75.67MB (79347560 bytes)
total-alloc: 3.02GB (3241489920 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 73953271
frees: 73404872
heap-alloc: 75.67MB (79347560 bytes)
heap-sys: 177.47MB (186089472 bytes)
heap-idle: 53.20MB (55779328 bytes)
heap-in-use: 124.27MB (130310144 bytes)
heap-released: 10.23MB (10723328 bytes)
heap-objects: 548399
stack-in-use: 34.53MB (36208640 bytes)
stack-sys: 34.53MB (36208640 bytes)
stack-mspan-inuse: 2.05MB (2148320 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 984.67KB (1008297 bytes)
gc-sys: 5.47MB (5739640 bytes)
next-gc: when heap-alloc >= 146.08MB (153172504 bytes)
last-gc: 2024-10-24 12:54:19.878077053 +0000 UTC
gc-pause-total: 21.074727ms
gc-pause: 81223
gc-pause-end: 1729774459878077053
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005391732585153251
enable-gc: true
debug-gc: false
