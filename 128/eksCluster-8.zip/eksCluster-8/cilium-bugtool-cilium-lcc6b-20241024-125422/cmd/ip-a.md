1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a8:7d:58:06:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.185.116/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3374sec preferred_lft 3374sec
    inet6 fe80::4a8:7dff:fe58:6d9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:49:9d:64:2e:bd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.163.236/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::449:9dff:fe64:2ebd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:ed:2b:f6:54:66 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ced:2bff:fef6:5466/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:65:ee:76:ae:97 brd ff:ff:ff:ff:ff:ff
    inet 10.8.0.245/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6465:eeff:fe76:ae97/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5e:e0:75:23:ed:22 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5ce0:75ff:fe23:ed22/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:39:5a:11:60:cd brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7839:5aff:fe11:60cd/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcabcde6badbb0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:b4:07:6a:3d:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::8cb4:7ff:fe6a:3db1/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd1982fe88eee@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:6a:43:a0:d4:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::e46a:43ff:fea0:d4a4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd2a9fbcbc62e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:0a:99:e5:3d:71 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::540a:99ff:fee5:3d71/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcca12ef5f74df@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:4d:f7:0f:b7:0a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::504d:f7ff:fe0f:b70a/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcca14187eebb6@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:eb:db:0a:70:cc brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::b8eb:dbff:fe0a:70cc/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcdc32df5c0ace@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:3b:de:b9:0d:e8 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::bc3b:deff:feb9:de8/64 scope link 
       valid_lft forever preferred_lft forever
