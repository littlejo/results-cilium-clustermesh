USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3212  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3195  0.0  0.4 1240432 16312 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3245  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3247  0.0  0.0   3728   488 ?        R    12:54   0:00  \_ bash -c ip a
root           1  3.5  7.2 1539060 286100 ?      Ssl  12:24   1:03 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 8584 ?        Sl   12:24   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
