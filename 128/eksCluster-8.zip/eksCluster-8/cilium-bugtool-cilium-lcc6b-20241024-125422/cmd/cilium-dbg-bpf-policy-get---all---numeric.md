Endpoint ID: 28
Path: /sys/fs/bpf/tc/globals/cilium_policy_00028

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 373
Path: /sys/fs/bpf/tc/globals/cilium_policy_00373

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6192393   76677     0        
Allow    Ingress     1          ANY          NONE         disabled    65858     793       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 654
Path: /sys/fs/bpf/tc/globals/cilium_policy_00654

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5380174   55157     0        
Allow    Ingress     1          ANY          NONE         disabled    4638294   48517     0        
Allow    Egress      0          ANY          NONE         disabled    5229603   54472     0        


Endpoint ID: 784
Path: /sys/fs/bpf/tc/globals/cilium_policy_00784

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1204
Path: /sys/fs/bpf/tc/globals/cilium_policy_01204

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    351734   4114      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2562
Path: /sys/fs/bpf/tc/globals/cilium_policy_02562

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3802     38        0        
Allow    Ingress     1          ANY          NONE         disabled    169192   1944      0        
Allow    Egress      0          ANY          NONE         disabled    20925    235       0        


Endpoint ID: 2612
Path: /sys/fs/bpf/tc/globals/cilium_policy_02612

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3572
Path: /sys/fs/bpf/tc/globals/cilium_policy_03572

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2094     22        0        
Allow    Ingress     1          ANY          NONE         disabled    169192   1944      0        
Allow    Egress      0          ANY          NONE         disabled    22297    252       0        


