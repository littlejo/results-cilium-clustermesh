29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:31+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:20:31+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:20:32+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:20:32+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:20:32+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:32+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:20:36+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:20:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:20:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:20:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:24:41+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
479: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:24:41+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
480: sched_cls  name tail_handle_ipv4  tag 7bc9b9daa8b9af88  gpl
	loaded_at 2024-10-24T12:24:41+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:24:41+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
504: sched_cls  name handle_policy  tag a24dd98083f51a0b  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 153
505: sched_cls  name tail_handle_ipv4  tag 34d82a87176370c9  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 154
507: sched_cls  name tail_ipv4_ct_egress  tag 13810e3b9306d443  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 156
508: sched_cls  name __send_drop_notify  tag dfc2f9093e7efd67  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 157
509: sched_cls  name tail_handle_arp  tag bfa9a7a73e03faef  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 158
510: sched_cls  name tail_handle_ipv4_cont  tag 60c31f322ba029ac  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 159
511: sched_cls  name tail_ipv4_ct_ingress  tag 98d71fa899f6f20a  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 160
512: sched_cls  name cil_from_container  tag 5734b1d398b88ffd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 161
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 162
514: sched_cls  name tail_ipv4_to_endpoint  tag 941f205c9b34437d  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 163
515: sched_cls  name tail_handle_ipv4  tag 7de5d0a0169b01b3  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 165
516: sched_cls  name cil_from_container  tag 0838d227be31f248  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 110,76
	btf_id 166
517: sched_cls  name tail_handle_arp  tag 0e3f06d07baac9ba  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 167
518: sched_cls  name handle_policy  tag e9c03015afe49c62  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,110,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 168
519: sched_cls  name tail_handle_ipv4_cont  tag 6923e83f1877a34a  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,110,40,37,38,81
	btf_id 169
520: sched_cls  name tail_ipv4_ct_ingress  tag 6011b57d1a7cb067  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 170
522: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 172
523: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 173
524: sched_cls  name __send_drop_notify  tag 7bd305a8a9121198  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
525: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
528: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
529: sched_cls  name tail_ipv4_to_endpoint  tag 16e2f840055f4e42  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,110,40,37,38
	btf_id 175
530: sched_cls  name tail_handle_arp  tag 15bad3e246a95cbf  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 177
531: sched_cls  name __send_drop_notify  tag 4db127f20ae31388  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
533: sched_cls  name tail_ipv4_ct_egress  tag 13810e3b9306d443  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 180
534: sched_cls  name cil_from_container  tag 3166fbf3da9fb42c  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 181
535: sched_cls  name tail_handle_ipv4  tag 0b91ec921daef83e  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 182
536: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
539: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
540: sched_cls  name tail_ipv4_ct_ingress  tag bb28f056cd0dd56a  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 183
541: sched_cls  name tail_handle_ipv4_cont  tag ed67aecde673824d  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,101,82,83,39,76,74,77,113,40,37,38,81
	btf_id 184
542: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 185
543: sched_cls  name tail_ipv4_to_endpoint  tag 64fec5153ba0bdfb  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,101,39,113,40,37,38
	btf_id 186
544: sched_cls  name handle_policy  tag 7ae956e71ad315a7  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,101,39,84,75,40,37,38
	btf_id 187
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
553: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 189
554: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 190
556: sched_cls  name __send_drop_notify  tag cb988f74012eddea  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
557: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 193
558: sched_cls  name tail_handle_ipv4_from_host  tag e86cdfff69219e91  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 194
560: sched_cls  name __send_drop_notify  tag cb988f74012eddea  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 197
562: sched_cls  name tail_handle_ipv4_from_host  tag e86cdfff69219e91  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 199
564: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 201
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
567: sched_cls  name tail_handle_ipv4_from_host  tag e86cdfff69219e91  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 205
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 208
571: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 209
572: sched_cls  name __send_drop_notify  tag cb988f74012eddea  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
574: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 213
575: sched_cls  name __send_drop_notify  tag cb988f74012eddea  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
577: sched_cls  name tail_handle_ipv4_from_host  tag e86cdfff69219e91  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 216
580: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 219
620: sched_cls  name __send_drop_notify  tag f429226a6b0652f3  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
621: sched_cls  name tail_ipv4_ct_ingress  tag 7d4d88c5516fac37  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 234
622: sched_cls  name handle_policy  tag d95d3c1013722e97  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 235
623: sched_cls  name tail_handle_ipv4  tag 3b4bbe7d89208b8a  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 236
624: sched_cls  name tail_ipv4_to_endpoint  tag d686c917875d3fc6  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 237
625: sched_cls  name cil_from_container  tag 8b582cc82a823925  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 238
626: sched_cls  name tail_handle_arp  tag 55dead4f4663cde1  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 239
627: sched_cls  name tail_handle_ipv4_cont  tag 691ff4fcb0d8c052  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 240
629: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 242
630: sched_cls  name tail_ipv4_ct_egress  tag 1570cb8e7c54b3fe  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 243
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
692: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
695: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
696: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
699: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
700: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
703: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
712: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
715: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3250: sched_cls  name cil_from_container  tag 4f7dbf2811c59e0c  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 622,76
	btf_id 3041
3251: sched_cls  name handle_policy  tag 44ab525af4d30aa2  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,622,82,83,621,41,80,148,39,84,75,40,37,38
	btf_id 3042
3252: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,622
	btf_id 3043
3253: sched_cls  name tail_handle_ipv4_cont  tag 04762578a854fc67  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,621,41,148,82,83,39,76,74,77,622,40,37,38,81
	btf_id 3044
3255: sched_cls  name __send_drop_notify  tag f94f27c427ea7e4d  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3046
3256: sched_cls  name tail_ipv4_ct_ingress  tag f59200dccf1a3fdf  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,622,82,83,621,84
	btf_id 3049
3257: sched_cls  name tail_handle_arp  tag c8898263eaadfc6c  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,622
	btf_id 3050
3262: sched_cls  name tail_ipv4_to_endpoint  tag 7e8fbd7b5f029a9a  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,621,41,82,83,80,148,39,622,40,37,38
	btf_id 3051
3263: sched_cls  name tail_handle_ipv4  tag 7d4dcb9a14c0fd56  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,622
	btf_id 3056
3266: sched_cls  name tail_ipv4_ct_egress  tag c6dc352206885059  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,622,82,83,621,84
	btf_id 3057
3305: sched_cls  name cil_from_container  tag 5868aa3d26798c2f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 632,76
	btf_id 3101
3306: sched_cls  name tail_ipv4_ct_egress  tag b21415673aa2e9a1  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3103
3307: sched_cls  name tail_ipv4_ct_ingress  tag a21d83266c83970a  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3105
3308: sched_cls  name handle_policy  tag dbcfe66454939642  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,145,39,84,75,40,37,38
	btf_id 3104
3309: sched_cls  name tail_ipv4_ct_ingress  tag 7c4b31c47a28bb1f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3107
3310: sched_cls  name __send_drop_notify  tag 821da3db8d61fc03  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3108
3311: sched_cls  name tail_handle_arp  tag e4f7708a3b6095a5  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3109
3312: sched_cls  name tail_ipv4_to_endpoint  tag ad09e63eb9401082  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,631,41,82,83,80,149,39,632,40,37,38
	btf_id 3106
3313: sched_cls  name tail_ipv4_to_endpoint  tag f2d2b427dd71e54f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,145,39,633,40,37,38
	btf_id 3110
3314: sched_cls  name tail_handle_ipv4_cont  tag c37bc78b5c6e09d0  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,145,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3112
3315: sched_cls  name cil_from_container  tag a3e5cedc869eaa46  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3113
3317: sched_cls  name handle_policy  tag 14e5cb624a53405f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,632,82,83,631,41,80,149,39,84,75,40,37,38
	btf_id 3111
3318: sched_cls  name tail_ipv4_ct_egress  tag b9723d4c83ea81ae  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3115
3319: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,632
	btf_id 3116
3320: sched_cls  name tail_handle_arp  tag 692e196b6f00fc46  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,632
	btf_id 3118
3321: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3117
3322: sched_cls  name tail_handle_ipv4  tag a76b434f8b911cda  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,632
	btf_id 3119
3323: sched_cls  name __send_drop_notify  tag 0082f33fb48e3ee2  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3121
3324: sched_cls  name tail_handle_ipv4  tag fe714f5a2a196fc4  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3120
3325: sched_cls  name tail_handle_ipv4_cont  tag a284987e3739de32  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,631,41,149,82,83,39,76,74,77,632,40,37,38,81
	btf_id 3122
