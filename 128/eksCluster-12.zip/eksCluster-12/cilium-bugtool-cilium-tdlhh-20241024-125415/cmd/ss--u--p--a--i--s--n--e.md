Total: 561
TCP:   4664 (estab 290, closed 4355, orphaned 0, timewait 3896)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  309       300       9        
INET	  319       306       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:42343      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:28054 sk:14f8 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.163.37%ens5:68         0.0.0.0:*    uid:192 ino:87442 sk:14f9 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:29228 sk:14fa cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15423 sk:14fb cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:29227 sk:14fc cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15424 sk:14fd cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::43a:5aff:fe09:b923]%ens5:546           [::]:*    uid:192 ino:15540 sk:14fe cgroup:unreachable:bd0 v6only:1 <->                   
