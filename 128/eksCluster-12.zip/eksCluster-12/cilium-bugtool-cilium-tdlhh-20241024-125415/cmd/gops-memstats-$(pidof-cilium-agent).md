alloc: 115.88MB (121505080 bytes)
total-alloc: 3.15GB (3377497672 bytes)
sys: 227.07MB (238101844 bytes)
lookups: 0
mallocs: 75909631
frees: 74613678
heap-alloc: 115.88MB (121505080 bytes)
heap-sys: 180.73MB (189505536 bytes)
heap-idle: 49.25MB (51642368 bytes)
heap-in-use: 131.48MB (137863168 bytes)
heap-released: 13.22MB (13860864 bytes)
heap-objects: 1295953
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.19MB (2298880 bytes)
stack-mspan-sys: 2.74MB (2872320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 762.48KB (780777 bytes)
gc-sys: 5.50MB (5764120 bytes)
next-gc: when heap-alloc >= 150.30MB (157598744 bytes)
last-gc: 2024-10-24 12:54:17.801911975 +0000 UTC
gc-pause-total: 18.980841ms
gc-pause: 84465
gc-pause-end: 1729774457801911975
num-gc: 103
num-forced-gc: 0
gc-cpu-fraction: 0.0005611594245427352
enable-gc: true
debug-gc: false
