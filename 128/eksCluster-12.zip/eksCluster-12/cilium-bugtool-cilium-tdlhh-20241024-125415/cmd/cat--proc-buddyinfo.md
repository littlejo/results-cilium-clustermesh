Node 0, zone      DMA      9    100     20      6      5      7      5     10      6      2     43 
Node 0, zone   Normal    222     56      9     16     21      8      3      2      2      3      7 
