[
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod444a556e_c987_4b3b_bc9c_4bb5e4541d12.slice/cri-containerd-39962f74f7590adc65a0f3d2049b290a8cf71071f94c836bb6837d8b2eb51817.scope"
      }
    ],
    "ips": [
      "10.12.0.55"
    ],
    "name": "client2-57cf4468f-c2djc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9d0a08c6_fa7c_4cc7_ab20_e10295128f08.slice/cri-containerd-af7afe823eee399dd2c937770f0356b16c838d2d0ee70702fc592f233678ddd8.scope"
      },
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9d0a08c6_fa7c_4cc7_ab20_e10295128f08.slice/cri-containerd-e8b2aad75cc6e4f0b0132523eda49580acc4521bd40d95cfae69ee497494763e.scope"
      }
    ],
    "ips": [
      "10.12.0.238"
    ],
    "name": "echo-same-node-86d9cc975c-vjd25",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e0231db_7008_44eb_bc32_ec6a2adf2641.slice/cri-containerd-6db7005455becae515756dc0ca62efe6c8c8dac87ccaa1931f26f6b4c9f37c1f.scope"
      },
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e0231db_7008_44eb_bc32_ec6a2adf2641.slice/cri-containerd-e6c0d80c477a6294cb4840a9a619537d3cd8bec27594b6c4e9c147682c78a7a5.scope"
      },
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e0231db_7008_44eb_bc32_ec6a2adf2641.slice/cri-containerd-5195a3e0bc80a6546c0db0df7d9d3f477c51cea6935fc7e41f535e4395466e15.scope"
      }
    ],
    "ips": [
      "10.12.0.162"
    ],
    "name": "clustermesh-apiserver-69989676b5-5gcp4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode31df577_a49f_482d_b5bc_497a9b719759.slice/cri-containerd-c4d8ae76c9e6345532dcc592cbb49b2b5ade0f69e6b92b0cd1e73a8bac2492d7.scope"
      }
    ],
    "ips": [
      "10.12.0.121"
    ],
    "name": "coredns-cc6ccd49c-gkxth",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40f7bc91_5a8c_4015_92c9_b15ea03d58e2.slice/cri-containerd-3383c84a1b65970f68bbd69b150ab31946a81fa2ac58513228388b4f42566af8.scope"
      }
    ],
    "ips": [
      "10.12.0.147"
    ],
    "name": "coredns-cc6ccd49c-zrzxn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71da232f_9b76_4746_a552_18ac5e276619.slice/cri-containerd-44f9c5102ef6916279b88ae4ea60a57703fd15cdc03423fc4b5b6b8b9ba8ee18.scope"
      }
    ],
    "ips": [
      "10.12.0.52"
    ],
    "name": "client-974f6c69d-tqcpf",
    "namespace": "cilium-test-1"
  }
]

