ip-172-31-163-37.eu-west-3.compute.internal
