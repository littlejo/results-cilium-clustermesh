{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:27.840Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.392Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.395Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.437Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.452Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.476Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.699Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.713Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.784Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.802Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.851Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.432Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.463Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.474Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.510Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.521Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.772Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.776Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.832Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.838Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.886Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.364Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.369Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.469Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.489Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.525Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.542Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.563Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.745Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.747Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.805Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.809Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.855Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.447Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.451Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.483Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.499Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.535Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.546Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.571Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.813Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.815Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.866Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.872Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.913Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.380Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.389Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.428Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.470Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.528Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.741Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.746Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.793Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.798Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.840Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.244Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.249Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.293Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.313Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.331Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.572Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.575Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.623Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.626Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.671Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.042Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.093Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.116Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.146Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.151Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.180Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.381Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.415Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.496Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.519Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.542Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.932Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.966Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.992Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.009Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.028Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.058Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.282Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.290Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.365Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.379Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.413Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.738Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.791Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.792Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.831Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.842Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.865Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.084Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.088Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.136Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.152Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.176Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.497Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.585Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.600Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.670Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.670Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.675Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.883Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.892Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.948Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.957Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.992Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.299Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.327Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.340Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.382Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.397Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.430Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.638Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.650Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.660Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.695Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.412Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.415Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.448Z",
  "value": "id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.463Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.490Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.756Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.764Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.449Z",
  "value": "id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.454Z",
  "value": "id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51"
}

