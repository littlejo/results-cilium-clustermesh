REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     137189    11124148    677    bpf_overlay.c
Interface                   INGRESS     681524    248037417   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      139055    11275468    53     encap.h
Success                     EGRESS      144586    19405873    1308   bpf_lxc.c
Success                     EGRESS      596       156299      86     l3.h
Success                     EGRESS      60845     4939812     1694   bpf_host.c
Success                     INGRESS     167829    19194460    86     l3.h
Success                     INGRESS     245400    25577565    235    trace.h
Unsupported L3 protocol     EGRESS      71        5330        1492   bpf_lxc.c
