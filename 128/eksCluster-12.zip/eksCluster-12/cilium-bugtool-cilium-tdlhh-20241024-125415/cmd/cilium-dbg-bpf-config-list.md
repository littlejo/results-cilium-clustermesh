KEY             VALUE
AgentLiveness   2039383364170
UTimeOffset     3378461812500000
