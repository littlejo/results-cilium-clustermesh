CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode31df577_a49f_482d_b5bc_497a9b719759.slice/cri-containerd-d5700c682f1a727a5c892a596fbc1f144ce2e689034f0b3acd7b4003976c9b3e.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode31df577_a49f_482d_b5bc_497a9b719759.slice/cri-containerd-c4d8ae76c9e6345532dcc592cbb49b2b5ade0f69e6b92b0cd1e73a8bac2492d7.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbab8d35e_1c6b_4eb5_acac_3d8ddf405cd1.slice/cri-containerd-f4844479160b1acf0377800082f66995ba19da833b796fb469595f231dea1a2e.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbab8d35e_1c6b_4eb5_acac_3d8ddf405cd1.slice/cri-containerd-012aa4f1b2b726d80b8cbb461ffbfcd6c88c519893b21144d51e28f3876d7e22.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod863ee176_c30d_4a0e_9933_dfe6c1c403bf.slice/cri-containerd-caa114e45e9be6678118ad42a8305fca532a7b99d85691bb529cc2096eee559e.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod863ee176_c30d_4a0e_9933_dfe6c1c403bf.slice/cri-containerd-0471554ee55f37dec413bca33d7d701d57ba0d2db83cb9a8ee89c4c4210abec3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40f7bc91_5a8c_4015_92c9_b15ea03d58e2.slice/cri-containerd-2af991bbed45d50e97282da071ae64eac8f5c4f58875dc950fc90c32c3274473.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40f7bc91_5a8c_4015_92c9_b15ea03d58e2.slice/cri-containerd-3383c84a1b65970f68bbd69b150ab31946a81fa2ac58513228388b4f42566af8.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee8e1898_b9af_4528_a107_3c05a6c55fef.slice/cri-containerd-8e647de0b23b20d132e06ded8e868f32178d299e6a8a9233b692e2785762bff6.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee8e1898_b9af_4528_a107_3c05a6c55fef.slice/cri-containerd-6b1b1c77c6506430bfb34930e30fd3488ba494475fe2b46d0f9ab27ebda0e049.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3240acf_e206_4ea0_9ee6_20beda89646c.slice/cri-containerd-ffd2902e125506552dc534597dfac720d52d83bc8a9e33df2f47b6b39b76fbb9.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3240acf_e206_4ea0_9ee6_20beda89646c.slice/cri-containerd-2abdb80951fe5224125d8fe042f0fbc92c2a7347c02fd867c38b7a37bcb3ee5e.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9d0a08c6_fa7c_4cc7_ab20_e10295128f08.slice/cri-containerd-af7afe823eee399dd2c937770f0356b16c838d2d0ee70702fc592f233678ddd8.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9d0a08c6_fa7c_4cc7_ab20_e10295128f08.slice/cri-containerd-e8b2aad75cc6e4f0b0132523eda49580acc4521bd40d95cfae69ee497494763e.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9d0a08c6_fa7c_4cc7_ab20_e10295128f08.slice/cri-containerd-6792c614d9c79478f4429cbedd63d6826643ea7a937679bfa566c9ce8eb46f48.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71da232f_9b76_4746_a552_18ac5e276619.slice/cri-containerd-f992c0265fa340121c13a8ec930f697950208fe785cd6f0f9f4f67648c4cd3c0.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71da232f_9b76_4746_a552_18ac5e276619.slice/cri-containerd-44f9c5102ef6916279b88ae4ea60a57703fd15cdc03423fc4b5b6b8b9ba8ee18.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e0231db_7008_44eb_bc32_ec6a2adf2641.slice/cri-containerd-e8b44a156f5f2ee6180b25a23e6a3fa6b786ce8ee8cea3c587d55d316e1fea13.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e0231db_7008_44eb_bc32_ec6a2adf2641.slice/cri-containerd-e6c0d80c477a6294cb4840a9a619537d3cd8bec27594b6c4e9c147682c78a7a5.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e0231db_7008_44eb_bc32_ec6a2adf2641.slice/cri-containerd-5195a3e0bc80a6546c0db0df7d9d3f477c51cea6935fc7e41f535e4395466e15.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e0231db_7008_44eb_bc32_ec6a2adf2641.slice/cri-containerd-6db7005455becae515756dc0ca62efe6c8c8dac87ccaa1931f26f6b4c9f37c1f.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod444a556e_c987_4b3b_bc9c_4bb5e4541d12.slice/cri-containerd-39962f74f7590adc65a0f3d2049b290a8cf71071f94c836bb6837d8b2eb51817.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod444a556e_c987_4b3b_bc9c_4bb5e4541d12.slice/cri-containerd-87a17f076304d1f26015def08881143171a7699813726210332ecbcdc0eea3c8.scope
    705      cgroup_device   multi                                          
