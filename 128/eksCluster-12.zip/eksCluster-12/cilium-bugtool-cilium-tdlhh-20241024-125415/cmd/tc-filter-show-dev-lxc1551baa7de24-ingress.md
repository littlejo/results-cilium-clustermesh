filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc1551baa7de24 direct-action not_in_hw id 3286 tag b484ea608516180a jited 
