Endpoint ID: 326
Path: /sys/fs/bpf/tc/globals/cilium_policy_00326

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2842     29        0        
Allow    Ingress     1          ANY          NONE         disabled    169337   1948      0        
Allow    Egress      0          ANY          NONE         disabled    20399    228       0        


Endpoint ID: 1016
Path: /sys/fs/bpf/tc/globals/cilium_policy_01016

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378111   4407      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1210
Path: /sys/fs/bpf/tc/globals/cilium_policy_01210

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1258
Path: /sys/fs/bpf/tc/globals/cilium_policy_01258

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6229152   77005     0        
Allow    Ingress     1          ANY          NONE         disabled    71246     857       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1777
Path: /sys/fs/bpf/tc/globals/cilium_policy_01777

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1790
Path: /sys/fs/bpf/tc/globals/cilium_policy_01790

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6126176   60956     0        
Allow    Ingress     1          ANY          NONE         disabled    4871193   51004     0        
Allow    Egress      0          ANY          NONE         disabled    6172237   61512     0        


Endpoint ID: 2409
Path: /sys/fs/bpf/tc/globals/cilium_policy_02409

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3054     31        0        
Allow    Ingress     1          ANY          NONE         disabled    167827   1925      0        
Allow    Egress      0          ANY          NONE         disabled    21360    238       0        


Endpoint ID: 3140
Path: /sys/fs/bpf/tc/globals/cilium_policy_03140

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


