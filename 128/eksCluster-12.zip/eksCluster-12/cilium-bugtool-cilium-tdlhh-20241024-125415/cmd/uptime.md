 12:54:16 up 33 min,  0 users,  load average: 0.38, 0.46, 0.29
