IP ADDRESS         LOCAL ENDPOINT INFO
10.12.0.121:0      id=2409  sec_id=870181 flags=0x0000 ifindex=12  mac=EA:E2:B0:37:A6:73 nodemac=4E:18:DA:E0:A0:C1   
10.12.0.145:0      (localhost)                                                                                       
172.31.156.191:0   (localhost)                                                                                       
10.12.0.109:0      id=1258  sec_id=4     flags=0x0000 ifindex=10  mac=62:28:A9:95:C6:E9 nodemac=C2:71:98:1A:5A:06    
10.12.0.147:0      id=326   sec_id=870181 flags=0x0000 ifindex=14  mac=02:E2:0E:65:C4:C1 nodemac=E2:BA:E5:E1:BF:CE   
10.12.0.162:0      id=1790  sec_id=862330 flags=0x0000 ifindex=18  mac=66:B2:3A:C5:D3:9D nodemac=C6:5F:6F:98:5B:3B   
10.12.0.238:0      id=1016  sec_id=877812 flags=0x0000 ifindex=24  mac=DE:20:9F:13:11:99 nodemac=12:F2:08:8D:4A:17   
172.31.163.37:0    (localhost)                                                                                       
10.12.0.52:0       id=1210  sec_id=873400 flags=0x0000 ifindex=20  mac=9A:BD:5F:E8:5B:1C nodemac=BA:75:2A:06:17:51   
10.12.0.55:0       id=1777  sec_id=882868 flags=0x0000 ifindex=22  mac=D2:1F:25:D8:0F:01 nodemac=22:4B:0D:3D:C9:53   
