xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 571
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 565
cilium_host(7) clsact/egress cil_from_host-cilium_host id 564
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 528
lxcdb7064d12790(12) clsact/ingress cil_from_container-lxcdb7064d12790 id 545
lxcdc1bda695d6f(14) clsact/ingress cil_from_container-lxcdc1bda695d6f id 510
lxcf81bc18c0bb9(18) clsact/ingress cil_from_container-lxcf81bc18c0bb9 id 628
lxc988b53045bcf(20) clsact/ingress cil_from_container-lxc988b53045bcf id 3352
lxc2436d29eae65(22) clsact/ingress cil_from_container-lxc2436d29eae65 id 3344
lxc1551baa7de24(24) clsact/ingress cil_from_container-lxc1551baa7de24 id 3286

flow_dissector:

netfilter:

