key: 46 01 00 00  value: ff 01 00 00
key: f8 03 00 00  value: d1 0c 00 00
key: ba 04 00 00  value: 0c 0d 00 00
key: ea 04 00 00  value: 16 02 00 00
key: f1 06 00 00  value: 16 0d 00 00
key: fe 06 00 00  value: 79 02 00 00
key: 69 09 00 00  value: 1e 02 00 00
Found 7 elements
