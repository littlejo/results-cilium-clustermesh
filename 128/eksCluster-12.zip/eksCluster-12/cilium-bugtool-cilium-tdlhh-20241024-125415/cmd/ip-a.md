1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3a:5a:09:b9:23 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.163.37/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3401sec preferred_lft 3401sec
    inet6 fe80::43a:5aff:fe09:b923/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:74:ff:bf:61:db brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.156.191/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::474:ffff:febf:61db/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:4f:7c:04:e8:f2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5c4f:7cff:fe04:e8f2/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:d4:4f:0d:5a:49 brd ff:ff:ff:ff:ff:ff
    inet 10.12.0.145/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::60d4:4fff:fe0d:5a49/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 16:9f:bc:9a:78:b2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::149f:bcff:fe9a:78b2/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:71:98:1a:5a:06 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c071:98ff:fe1a:5a06/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcdb7064d12790@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:18:da:e0:a0:c1 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4c18:daff:fee0:a0c1/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcdc1bda695d6f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:ba:e5:e1:bf:ce brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e0ba:e5ff:fee1:bfce/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf81bc18c0bb9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:5f:6f:98:5b:3b brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c45f:6fff:fe98:5b3b/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc988b53045bcf@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:75:2a:06:17:51 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::b875:2aff:fe06:1751/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc2436d29eae65@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:4b:0d:3d:c9:53 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::204b:dff:fe3d:c953/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc1551baa7de24@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:f2:08:8d:4a:17 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::10f2:8ff:fe8d:4a17/64 scope link 
       valid_lft forever preferred_lft forever
