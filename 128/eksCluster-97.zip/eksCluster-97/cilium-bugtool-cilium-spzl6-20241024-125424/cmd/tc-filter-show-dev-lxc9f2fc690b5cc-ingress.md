filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc9f2fc690b5cc direct-action not_in_hw id 3369 tag 41b5a02504fe7dac jited 
