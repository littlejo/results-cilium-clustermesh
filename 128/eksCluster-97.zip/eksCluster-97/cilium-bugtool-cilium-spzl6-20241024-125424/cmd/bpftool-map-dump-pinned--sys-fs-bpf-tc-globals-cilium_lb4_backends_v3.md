key: 08 00 00 00  value: 0a 61 00 95 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f e1 4c 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 61 00 95 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f ce df 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 61 00 6b 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 9f 7c 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 61 00 ab 00 35 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 61 00 53 1f 90 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 61 00 ab 23 c1 00 00  00 00 00 00
Found 9 elements
