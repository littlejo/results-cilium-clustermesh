{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.315Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.317Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.365Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.078Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.083Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.135Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.142Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.172Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.412Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.416Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.469Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.492Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.523Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.158Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.173Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.218Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.264Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.318Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.562Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.586Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.636Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.649Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.683Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.232Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.236Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.274Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.302Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.330Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.351Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.368Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.637Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.643Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.701Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.706Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.753Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.288Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.298Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.345Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.361Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.388Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.655Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.671Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.779Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.791Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.815Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.180Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.205Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.237Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.261Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.281Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.505Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.514Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.581Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.601Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.627Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.991Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.016Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.064Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.088Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.113Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.333Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.366Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.415Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.448Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.466Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.839Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.888Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.953Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.984Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.984Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.999Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.165Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.181Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.238Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.243Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.278Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.720Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.731Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.784Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.789Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.822Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.060Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.069Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.106Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.123Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.167Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.178Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.208Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.564Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.594Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.610Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.649Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.663Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.910Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.979Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.036Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.085Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.101Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.329Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.378Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.385Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.436Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.453Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.474Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.697Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.717Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.759Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.768Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.813Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.123Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.137Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.188Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.197Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.232Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.236Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.490Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.490Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.508Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.550Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.207Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.361Z",
  "value": "id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.451Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.451Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.514Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.777Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.793Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.458Z",
  "value": "id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.463Z",
  "value": "id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B"
}

