alloc: 132.20MB (138621296 bytes)
total-alloc: 3.13GB (3365003088 bytes)
sys: 227.32MB (238363988 bytes)
lookups: 0
mallocs: 75919155
frees: 74579342
heap-alloc: 132.20MB (138621296 bytes)
heap-sys: 180.61MB (189382656 bytes)
heap-idle: 28.98MB (30384128 bytes)
heap-in-use: 151.63MB (158998528 bytes)
heap-released: 13.86MB (14532608 bytes)
heap-objects: 1339813
stack-in-use: 35.34MB (37060608 bytes)
stack-sys: 35.34MB (37060608 bytes)
stack-mspan-inuse: 2.38MB (2496000 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 994.10KB (1017961 bytes)
gc-sys: 5.54MB (5811392 bytes)
next-gc: when heap-alloc >= 150.48MB (157787480 bytes)
last-gc: 2024-10-24 12:54:26.45405079 +0000 UTC
gc-pause-total: 11.017572ms
gc-pause: 959292
gc-pause-end: 1729774466454050790
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006826443712692452
enable-gc: true
debug-gc: false
