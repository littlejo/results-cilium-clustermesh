IP ADDRESS         LOCAL ENDPOINT INFO
172.31.252.188:0   (localhost)                                                                                        
10.97.0.160:0      (localhost)                                                                                        
10.97.0.153:0      id=343   sec_id=6480725 flags=0x0000 ifindex=20  mac=9E:9E:1D:70:D3:8B nodemac=B2:ED:5C:A0:80:3B   
172.31.206.223:0   (localhost)                                                                                        
10.97.0.149:0      id=1467  sec_id=6426532 flags=0x0000 ifindex=14  mac=32:B4:75:6A:A7:88 nodemac=0E:FA:64:9A:BB:94   
10.97.0.104:0      id=1408  sec_id=6422852 flags=0x0000 ifindex=22  mac=32:EC:82:C4:C1:34 nodemac=3E:58:C5:17:27:27   
10.97.0.171:0      id=106   sec_id=6426532 flags=0x0000 ifindex=12  mac=42:79:16:1A:94:ED nodemac=6E:9B:6C:89:3C:E9   
10.97.0.83:0       id=3246  sec_id=6432645 flags=0x0000 ifindex=24  mac=CE:4F:57:8F:05:07 nodemac=6E:0C:57:B4:5F:EC   
10.97.0.107:0      id=150   sec_id=6439496 flags=0x0000 ifindex=18  mac=86:37:70:D4:60:DD nodemac=12:2C:DE:B9:04:92   
10.97.0.112:0      id=810   sec_id=4     flags=0x0000 ifindex=10  mac=EE:F2:A1:77:B8:5F nodemac=3E:FB:82:59:43:EE     
