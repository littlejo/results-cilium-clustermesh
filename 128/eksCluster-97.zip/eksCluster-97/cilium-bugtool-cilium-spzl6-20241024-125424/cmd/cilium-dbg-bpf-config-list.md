KEY             VALUE
AgentLiveness   1926892595707
UTimeOffset     3378462052734375
