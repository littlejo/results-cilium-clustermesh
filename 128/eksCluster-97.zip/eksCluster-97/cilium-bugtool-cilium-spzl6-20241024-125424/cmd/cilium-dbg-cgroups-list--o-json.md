[
  {
    "containers": [
      {
        "cgroup-id": 7666,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod738aab76_01ae_4729_9941_f179536462b9.slice/cri-containerd-4dea6d652d45190cfac68b955d501818281d73a2d4c7478cbd8f3fea4b5f69d4.scope"
      }
    ],
    "ips": [
      "10.97.0.149"
    ],
    "name": "coredns-cc6ccd49c-6chrr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9898,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbe1b952c_d01c_4b48_946b_b9a79f5d7c66.slice/cri-containerd-4030ac8e1cecd9dfe0df23784f0e6e4818fa8200fed699c0ad89f63f896394f2.scope"
      }
    ],
    "ips": [
      "10.97.0.153"
    ],
    "name": "client-974f6c69d-gg4bp",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10066,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cc8bef7_dabb_4379_bc7d_4bcc07824892.slice/cri-containerd-55705f7d92b5195ff18052f3eb27d59c986a47bab42f234353e1a7d70837d290.scope"
      },
      {
        "cgroup-id": 9982,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cc8bef7_dabb_4379_bc7d_4bcc07824892.slice/cri-containerd-fdb200da63cfd5f3440092b854283b0acb081b79bce3d356cdf3b68437cf689a.scope"
      }
    ],
    "ips": [
      "10.97.0.83"
    ],
    "name": "echo-same-node-86d9cc975c-zbpdp",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9814,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5ffe13b_da3e_44f7_8f50_a361b9418dae.slice/cri-containerd-e5131aebad94a987f7ee93d7726614524e9ab44a9ab7a6e1660a156a3ce92b39.scope"
      }
    ],
    "ips": [
      "10.97.0.104"
    ],
    "name": "client2-57cf4468f-zlszs",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9142,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb652965c_1cc2_4a1b_b102_ecc7938fc07f.slice/cri-containerd-6d0397fa5974e5572df8dc6c28d80a5d3f8e8d96510ccff768a299856275e04e.scope"
      },
      {
        "cgroup-id": 9226,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb652965c_1cc2_4a1b_b102_ecc7938fc07f.slice/cri-containerd-9db1fe0849a84b014ffb116c3323d20bc434ab3409b2339592b107530831c4fd.scope"
      },
      {
        "cgroup-id": 9058,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb652965c_1cc2_4a1b_b102_ecc7938fc07f.slice/cri-containerd-454f2269d85f36eca21fc3445c8d4d272cc371037ff4d9c125bf5af1a30b5242.scope"
      }
    ],
    "ips": [
      "10.97.0.107"
    ],
    "name": "clustermesh-apiserver-7dc489df5c-rhdsg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7582,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6b50775_7af5_4ca4_ac18_72b08fd407f7.slice/cri-containerd-cd804414eb6114e078715bee9f38dd0c87c1252d1c9ad0d624bc7f046e2b3c12.scope"
      }
    ],
    "ips": [
      "10.97.0.171"
    ],
    "name": "coredns-cc6ccd49c-xgt49",
    "namespace": "kube-system"
  }
]

