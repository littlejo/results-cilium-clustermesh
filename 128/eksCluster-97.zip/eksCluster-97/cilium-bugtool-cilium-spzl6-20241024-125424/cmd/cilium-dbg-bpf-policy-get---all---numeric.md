Endpoint ID: 106
Path: /sys/fs/bpf/tc/globals/cilium_policy_00106

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2088     22        0        
Allow    Ingress     1          ANY          NONE         disabled    130517   1488      0        
Allow    Egress      0          ANY          NONE         disabled    19414    214       0        


Endpoint ID: 150
Path: /sys/fs/bpf/tc/globals/cilium_policy_00150

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6044539   60996     0        
Allow    Ingress     1          ANY          NONE         disabled    5799752   61387     0        
Allow    Egress      0          ANY          NONE         disabled    7455326   73032     0        


Endpoint ID: 343
Path: /sys/fs/bpf/tc/globals/cilium_policy_00343

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 434
Path: /sys/fs/bpf/tc/globals/cilium_policy_00434

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 810
Path: /sys/fs/bpf/tc/globals/cilium_policy_00810

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6249894   77270     0        
Allow    Ingress     1          ANY          NONE         disabled    62196     751       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1408
Path: /sys/fs/bpf/tc/globals/cilium_policy_01408

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1467
Path: /sys/fs/bpf/tc/globals/cilium_policy_01467

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3808     38        0        
Allow    Ingress     1          ANY          NONE         disabled    130055   1481      0        
Allow    Egress      0          ANY          NONE         disabled    19026    208       0        


Endpoint ID: 3246
Path: /sys/fs/bpf/tc/globals/cilium_policy_03246

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    381808   4466      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


