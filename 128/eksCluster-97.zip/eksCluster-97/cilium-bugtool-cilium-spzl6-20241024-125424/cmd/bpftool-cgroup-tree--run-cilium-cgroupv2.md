CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc656f56_4f6a_4969_8c03_9d42c1cfadd4.slice/cri-containerd-e58675c1837c81c17507643561e391d724779c9c8b742b1408ff08a282786e23.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc656f56_4f6a_4969_8c03_9d42c1cfadd4.slice/cri-containerd-444844fb51bce2e7d020efdf8f4e6864354ccb0437d5e2375cbf5703e6e91ee6.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd1de4c02_fd22_469d_bfde_197786027177.slice/cri-containerd-819a2f8ea5688c2e350f2d52522f701b9065d60fc8532e3caf1432ea1bd09a00.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd1de4c02_fd22_469d_bfde_197786027177.slice/cri-containerd-15949524c97a51d693c42399c93a564ba1d8f8fbf5f385a8288bb75de099529f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6b50775_7af5_4ca4_ac18_72b08fd407f7.slice/cri-containerd-cd804414eb6114e078715bee9f38dd0c87c1252d1c9ad0d624bc7f046e2b3c12.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6b50775_7af5_4ca4_ac18_72b08fd407f7.slice/cri-containerd-eb4abaf9fac234874b7475958de79d4c46d21031f0338a58ee7da0fd523ddf37.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod738aab76_01ae_4729_9941_f179536462b9.slice/cri-containerd-3f7162e73e4d620402b6a635519b20cbe8921a72d72c7cd90a642bdfe756a6fc.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod738aab76_01ae_4729_9941_f179536462b9.slice/cri-containerd-4dea6d652d45190cfac68b955d501818281d73a2d4c7478cbd8f3fea4b5f69d4.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cc8bef7_dabb_4379_bc7d_4bcc07824892.slice/cri-containerd-96f797c1934d11eab072b6008ecfdcd65edf01764e105d79d82f7daadb8ed5fa.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cc8bef7_dabb_4379_bc7d_4bcc07824892.slice/cri-containerd-55705f7d92b5195ff18052f3eb27d59c986a47bab42f234353e1a7d70837d290.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cc8bef7_dabb_4379_bc7d_4bcc07824892.slice/cri-containerd-fdb200da63cfd5f3440092b854283b0acb081b79bce3d356cdf3b68437cf689a.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5ffe13b_da3e_44f7_8f50_a361b9418dae.slice/cri-containerd-e5131aebad94a987f7ee93d7726614524e9ab44a9ab7a6e1660a156a3ce92b39.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5ffe13b_da3e_44f7_8f50_a361b9418dae.slice/cri-containerd-c93f106a5631dba0a518dac0c51fc8985bcc5311ba66750661f1e28a361cbd5f.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbe1b952c_d01c_4b48_946b_b9a79f5d7c66.slice/cri-containerd-9b4906a34789d30828098a9303a081bb055c4a269c35b97aabec4a919676e970.scope
    687      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbe1b952c_d01c_4b48_946b_b9a79f5d7c66.slice/cri-containerd-4030ac8e1cecd9dfe0df23784f0e6e4818fa8200fed699c0ad89f63f896394f2.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65a98655_6ca3_40a7_817b_21bd5ac96ad4.slice/cri-containerd-dfc3aa0ec941a0d0f921d3606c7e71c1888f9df6b79a20e134eecd6a610b9c28.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65a98655_6ca3_40a7_817b_21bd5ac96ad4.slice/cri-containerd-0725166440efd2e65bd9477fda7b697fca941f6dbf963a3b7696a56d9ed29e5b.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7735530_e915_4263_a9c3_56a424ed3e99.slice/cri-containerd-73855256767abbcfad26054344d50a4a208f0be71148222daac57a415af76ecd.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7735530_e915_4263_a9c3_56a424ed3e99.slice/cri-containerd-6337a953811ed189863bfc16e20cc8a32fdf633ed005aa29cb2bfe2eb11ad083.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb652965c_1cc2_4a1b_b102_ecc7938fc07f.slice/cri-containerd-6d0397fa5974e5572df8dc6c28d80a5d3f8e8d96510ccff768a299856275e04e.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb652965c_1cc2_4a1b_b102_ecc7938fc07f.slice/cri-containerd-454f2269d85f36eca21fc3445c8d4d272cc371037ff4d9c125bf5af1a30b5242.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb652965c_1cc2_4a1b_b102_ecc7938fc07f.slice/cri-containerd-9db1fe0849a84b014ffb116c3323d20bc434ab3409b2339592b107530831c4fd.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb652965c_1cc2_4a1b_b102_ecc7938fc07f.slice/cri-containerd-d168cce86ba3c925881b545d3ea2b84f84b0f72265052c88c4ae59720b8a6b2b.scope
    641      cgroup_device   multi                                          
