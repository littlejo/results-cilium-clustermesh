markdown output at /tmp/cilium-bugtool-20241024-125426.492+0000-UTC-818221164/cmd/cilium-debuginfo-20241024-125457.421+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125426.492+0000-UTC-818221164/cmd/cilium-debuginfo-20241024-125457.421+0000-UTC.json
