1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:96:be:97:56:21 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.206.223/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3514sec preferred_lft 3514sec
    inet6 fe80::896:beff:fe97:5621/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:35:10:61:80:e3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.252.188/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::835:10ff:fe61:80e3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:95:eb:e7:c5:1e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::895:ebff:fee7:c51e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:34:68:2d:8d:ad brd ff:ff:ff:ff:ff:ff
    inet 10.97.0.160/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2834:68ff:fe2d:8dad/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a2:b4:1c:2f:64:11 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a0b4:1cff:fe2f:6411/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:fb:82:59:43:ee brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3cfb:82ff:fe59:43ee/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6179a95ad9f8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:9b:6c:89:3c:e9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6c9b:6cff:fe89:3ce9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxccabbbcd18b2a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:fa:64:9a:bb:94 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::cfa:64ff:fe9a:bb94/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf344a4f63cfc@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:2c:de:b9:04:92 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::102c:deff:feb9:492/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc50348422f85d@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:ed:5c:a0:80:3b brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::b0ed:5cff:fea0:803b/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc9f2fc690b5cc@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:58:c5:17:27:27 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::3c58:c5ff:fe17:2727/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc5a65624b99aa@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:0c:57:b4:5f:ec brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::6c0c:57ff:feb4:5fec/64 scope link 
       valid_lft forever preferred_lft forever
