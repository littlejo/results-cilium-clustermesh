Node 0, zone      DMA    223    166     26     46     10     13     10      5      4      3     36 
Node 0, zone   Normal      2      4     12     29     20      7      3      6      3      2      7 
