xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 578
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 560
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 532
lxc6179a95ad9f8(12) clsact/ingress cil_from_container-lxc6179a95ad9f8 id 541
lxccabbbcd18b2a(14) clsact/ingress cil_from_container-lxccabbbcd18b2a id 509
lxcf344a4f63cfc(18) clsact/ingress cil_from_container-lxcf344a4f63cfc id 627
lxc50348422f85d(20) clsact/ingress cil_from_container-lxc50348422f85d id 3362
lxc9f2fc690b5cc(22) clsact/ingress cil_from_container-lxc9f2fc690b5cc id 3369
lxc5a65624b99aa(24) clsact/ingress cil_from_container-lxc5a65624b99aa id 3298

flow_dissector:

netfilter:

