USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3244  2.0  0.4 1240432 16232 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3260  0.0  0.0   6408  1640 ?        R    12:54   0:00  \_ ps auxfw
root        3221  2.0  0.3 1229640 15648 ?       Ssl  12:54   0:00 /bin/gops stack 1
root           1  5.0  7.3 1539060 290044 ?      Ssl  12:31   1:09 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.3  0.2 1229744 10112 ?       Sl   12:31   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
