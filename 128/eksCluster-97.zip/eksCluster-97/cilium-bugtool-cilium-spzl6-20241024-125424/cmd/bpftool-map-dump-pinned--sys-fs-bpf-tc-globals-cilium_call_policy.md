key: 6a 00 00 00  value: 17 02 00 00
key: 96 00 00 00  value: 74 02 00 00
key: 57 01 00 00  value: 2a 0d 00 00
key: 2a 03 00 00  value: 07 02 00 00
key: 80 05 00 00  value: 23 0d 00 00
key: bb 05 00 00  value: fc 01 00 00
key: ae 0c 00 00  value: f1 0c 00 00
Found 7 elements
