USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3250  0.0  0.4 1240176 16252 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3264  0.0  0.0   6408  1640 ?        R    12:54   0:00  \_ ps auxfw
root        3265  0.0  0.0      0     0 ?        R    12:54   0:00  \_ [hostname]
root        3225  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3215  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3207  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3205  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.9  7.3 1539060 288196 ?      Ssl  12:31   1:07 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.3  0.2 1229744 9068 ?        Sl   12:31   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
