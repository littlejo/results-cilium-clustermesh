CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode196b88e_f21f_42da_b6ac_354864afcd2a.slice/cri-containerd-f50595eeb0c710c882467e1d811e5f7da36ba349d7f530ca0ff9f3216528baa3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode196b88e_f21f_42da_b6ac_354864afcd2a.slice/cri-containerd-0a467ec002c8b9e9564feddff21f39a465493fe2ad16a1ab24276fea96cafbf8.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb68a48c7_b835_4b7b_a32e_5648a2d8cf07.slice/cri-containerd-d8fef02bcd2d16a31fa225466f57b127c7942270cb965fd00953e6b15cd7bd90.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb68a48c7_b835_4b7b_a32e_5648a2d8cf07.slice/cri-containerd-c4fd83afebab33f66b5fd970d7b4ff7ed3c03bf60d4bfd1106015e4fd8327ff4.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae58db7c_cf90_4672_b6ff_0ba6a8280b50.slice/cri-containerd-9e6a60cdcab4c8d768c1f946827ae1ce8df11cba221abd6b9f8dc7a6543632d5.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae58db7c_cf90_4672_b6ff_0ba6a8280b50.slice/cri-containerd-6a4ba93ac7f30393924a9943b88b37bb691b0f3367b6c32197318972dde94967.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod096cc5b0_1e24_4253_9cf6_f5e33fbefcc5.slice/cri-containerd-d49635c836c86293e059b8f30bdabed34c6e61240eea9e17a7190b9c416a0139.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod096cc5b0_1e24_4253_9cf6_f5e33fbefcc5.slice/cri-containerd-cc6c86ff55b87cfb746e74b3b5d2bb1f6fc3f6fdd7009b5fed9ee833b315bd56.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod952a5adb_c60c_4951_8330_74b0e951de96.slice/cri-containerd-8e1109af656c121007db0fa1cd82834171a740eaa2d97525ef972f82a59228f2.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod952a5adb_c60c_4951_8330_74b0e951de96.slice/cri-containerd-3c2327fc9c005fed4e49ee84d0cef1227a9535165c4e739b4dfd7f111f703432.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod952a5adb_c60c_4951_8330_74b0e951de96.slice/cri-containerd-0ec41d2ac2c76700a6e82f74677bc91fcbc669248f29e7bc8e05a3dd2f70d257.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode19b8b3e_2413_4803_8227_16f0c26d2b18.slice/cri-containerd-6951090f6d1ce095d2b62bac2d2b514ea9496e5bf007e71406d6aba047956c4e.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode19b8b3e_2413_4803_8227_16f0c26d2b18.slice/cri-containerd-f97200ac2c5cb926be20aa36ed11427b192381e637b70566eb90741f52882aba.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9791917d_2a40_43dc_90a7_d351ed51f4eb.slice/cri-containerd-4c3059e84c308ab562087061aa1acf26d4d47c4ec1a39ec60a0835c2e333cb83.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9791917d_2a40_43dc_90a7_d351ed51f4eb.slice/cri-containerd-dda9211a1260439ca88736c1a3d6cd62a64dafaaa430286a428dcf718b3dd2ed.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0438fdb2_97c9_478d_bd0c_5f1adeb883de.slice/cri-containerd-af5c771ea2f87fe0e48416dedc22ff9b35cb095f11a55020b86b18eb548d5ffa.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0438fdb2_97c9_478d_bd0c_5f1adeb883de.slice/cri-containerd-c1925d9611435016d812370baec1ac725c8b1571794b863e8e8940709d4f0821.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d1b1d1_b562_47ac_aa02_cd4ec5b65db1.slice/cri-containerd-08818d87a7dba9407c42e190c8b549896b4938c4e215dfebca68c3f07aa51592.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d1b1d1_b562_47ac_aa02_cd4ec5b65db1.slice/cri-containerd-3aed513a34ca29f15b04cb3ef98c4a0c00a8b01caaf6619d84643e82895b5dea.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82df20a6_f2e5_4cf7_972b_a5ce2dca6f56.slice/cri-containerd-6b55c2c7ae1c5a37a779747b169b4db69b5d686fc59f1bb958c5e473acdf0b11.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82df20a6_f2e5_4cf7_972b_a5ce2dca6f56.slice/cri-containerd-96201418804634234af396e22f25d094e0bbd767ba0ce671eb68ab63f87cbdea.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82df20a6_f2e5_4cf7_972b_a5ce2dca6f56.slice/cri-containerd-f26b658ebb8148df3cc72cbf6846a871baf67dee468cba1817bdf5b259c149f9.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82df20a6_f2e5_4cf7_972b_a5ce2dca6f56.slice/cri-containerd-72d30d95bc25f356056036e14adee2a33324d570184a168a0920d819ceb9acbf.scope
    660      cgroup_device   multi                                          
