xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 579
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 564
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 518
lxcbd8ceab74f57(12) clsact/ingress cil_from_container-lxcbd8ceab74f57 id 528
lxc744a2fcf2d7a(14) clsact/ingress cil_from_container-lxc744a2fcf2d7a id 538
lxcbb1cc58b8e14(18) clsact/ingress cil_from_container-lxcbb1cc58b8e14 id 634
lxc5720e1952432(20) clsact/ingress cil_from_container-lxc5720e1952432 id 3331
lxc9d18a2e0ee13(22) clsact/ingress cil_from_container-lxc9d18a2e0ee13 id 3322
lxcaa1692ef11e5(24) clsact/ingress cil_from_container-lxcaa1692ef11e5 id 3280

flow_dissector:

netfilter:

