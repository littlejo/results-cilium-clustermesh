[
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode19b8b3e_2413_4803_8227_16f0c26d2b18.slice/cri-containerd-6951090f6d1ce095d2b62bac2d2b514ea9496e5bf007e71406d6aba047956c4e.scope"
      }
    ],
    "ips": [
      "10.99.0.117"
    ],
    "name": "client-974f6c69d-jgwfr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9791917d_2a40_43dc_90a7_d351ed51f4eb.slice/cri-containerd-4c3059e84c308ab562087061aa1acf26d4d47c4ec1a39ec60a0835c2e333cb83.scope"
      }
    ],
    "ips": [
      "10.99.0.247"
    ],
    "name": "client2-57cf4468f-m9bh6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82df20a6_f2e5_4cf7_972b_a5ce2dca6f56.slice/cri-containerd-72d30d95bc25f356056036e14adee2a33324d570184a168a0920d819ceb9acbf.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82df20a6_f2e5_4cf7_972b_a5ce2dca6f56.slice/cri-containerd-96201418804634234af396e22f25d094e0bbd767ba0ce671eb68ab63f87cbdea.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82df20a6_f2e5_4cf7_972b_a5ce2dca6f56.slice/cri-containerd-6b55c2c7ae1c5a37a779747b169b4db69b5d686fc59f1bb958c5e473acdf0b11.scope"
      }
    ],
    "ips": [
      "10.99.0.151"
    ],
    "name": "clustermesh-apiserver-64bbf975-mrq2z",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod096cc5b0_1e24_4253_9cf6_f5e33fbefcc5.slice/cri-containerd-d49635c836c86293e059b8f30bdabed34c6e61240eea9e17a7190b9c416a0139.scope"
      }
    ],
    "ips": [
      "10.99.0.212"
    ],
    "name": "coredns-cc6ccd49c-nn6fk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod952a5adb_c60c_4951_8330_74b0e951de96.slice/cri-containerd-8e1109af656c121007db0fa1cd82834171a740eaa2d97525ef972f82a59228f2.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod952a5adb_c60c_4951_8330_74b0e951de96.slice/cri-containerd-0ec41d2ac2c76700a6e82f74677bc91fcbc669248f29e7bc8e05a3dd2f70d257.scope"
      }
    ],
    "ips": [
      "10.99.0.33"
    ],
    "name": "echo-same-node-86d9cc975c-bsx74",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb68a48c7_b835_4b7b_a32e_5648a2d8cf07.slice/cri-containerd-d8fef02bcd2d16a31fa225466f57b127c7942270cb965fd00953e6b15cd7bd90.scope"
      }
    ],
    "ips": [
      "10.99.0.250"
    ],
    "name": "coredns-cc6ccd49c-99gx6",
    "namespace": "kube-system"
  }
]

