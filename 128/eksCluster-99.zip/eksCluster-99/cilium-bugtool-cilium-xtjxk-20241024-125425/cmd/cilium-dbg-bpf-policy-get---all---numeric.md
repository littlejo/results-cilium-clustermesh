Endpoint ID: 72
Path: /sys/fs/bpf/tc/globals/cilium_policy_00072

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 118
Path: /sys/fs/bpf/tc/globals/cilium_policy_00118

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6240455   77295     0        
Allow    Ingress     1          ANY          NONE         disabled    63764     775       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 427
Path: /sys/fs/bpf/tc/globals/cilium_policy_00427

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    211539   1915      0        
Allow    Ingress     1          ANY          NONE         disabled    132621   1527      0        
Allow    Egress      0          ANY          NONE         disabled    66478    658       0        


Endpoint ID: 475
Path: /sys/fs/bpf/tc/globals/cilium_policy_00475

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6193032   61887     0        
Allow    Ingress     1          ANY          NONE         disabled    5228647   55068     0        
Allow    Egress      0          ANY          NONE         disabled    6338559   63272     0        


Endpoint ID: 531
Path: /sys/fs/bpf/tc/globals/cilium_policy_00531

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1003
Path: /sys/fs/bpf/tc/globals/cilium_policy_01003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382291   4463      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2065
Path: /sys/fs/bpf/tc/globals/cilium_policy_02065

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    213571   1923      0        
Allow    Ingress     1          ANY          NONE         disabled    132555   1526      0        
Allow    Egress      0          ANY          NONE         disabled    64444    633       0        


Endpoint ID: 3302
Path: /sys/fs/bpf/tc/globals/cilium_policy_03302

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


