KEY             VALUE
AgentLiveness   1922632550062
UTimeOffset     3378462060546875
