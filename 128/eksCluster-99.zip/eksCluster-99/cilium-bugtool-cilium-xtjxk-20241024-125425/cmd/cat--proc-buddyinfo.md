Node 0, zone      DMA    533    179     48     23     12     40     26      8      6      5     34 
Node 0, zone   Normal    454     50     38      2      8      7      1      3      2      3      7 
