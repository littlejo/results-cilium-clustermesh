key: 48 00 00 00  value: 05 0d 00 00
key: 76 00 00 00  value: 08 02 00 00
key: ab 01 00 00  value: 26 02 00 00
key: db 01 00 00  value: 74 02 00 00
key: eb 03 00 00  value: d4 0c 00 00
key: 11 08 00 00  value: 09 02 00 00
key: e6 0c 00 00  value: 04 0d 00 00
Found 7 elements
