alloc: 91.04MB (95465248 bytes)
total-alloc: 3.10GB (3328474888 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75471773
frees: 74824769
heap-alloc: 91.04MB (95465248 bytes)
heap-sys: 176.92MB (185516032 bytes)
heap-idle: 43.20MB (45293568 bytes)
heap-in-use: 133.73MB (140222464 bytes)
heap-released: 7.44MB (7798784 bytes)
heap-objects: 647004
stack-in-use: 35.03MB (36732928 bytes)
stack-sys: 35.03MB (36732928 bytes)
stack-mspan-inuse: 2.09MB (2190080 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 964.09KB (987225 bytes)
gc-sys: 5.56MB (5827824 bytes)
next-gc: when heap-alloc >= 150.81MB (158137752 bytes)
last-gc: 2024-10-24 12:54:53.50228095 +0000 UTC
gc-pause-total: 12.068892ms
gc-pause: 73493
gc-pause-end: 1729774493502280950
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006375429739506831
enable-gc: true
debug-gc: false
