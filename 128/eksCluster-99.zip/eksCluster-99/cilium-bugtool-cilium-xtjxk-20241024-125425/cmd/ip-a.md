1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:fd:1d:0c:18:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.222.193/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3519sec preferred_lft 3519sec
    inet6 fe80::8fd:1dff:fe0c:18d3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1c:7a:a7:31:89 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.242.93/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::81c:7aff:fea7:3189/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:f8:b1:bc:c8:5d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::98f8:b1ff:febc:c85d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:28:8d:8c:91:5f brd ff:ff:ff:ff:ff:ff
    inet 10.99.0.46/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2828:8dff:fe8c:915f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d2:e0:f0:0e:fa:f5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d0e0:f0ff:fe0e:faf5/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:cd:b8:f7:b3:37 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1ccd:b8ff:fef7:b337/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcbd8ceab74f57@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:5c:b3:ca:84:2f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::245c:b3ff:feca:842f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc744a2fcf2d7a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:a6:59:47:c1:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::20a6:59ff:fe47:c1c7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcbb1cc58b8e14@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:d2:4f:c0:cd:d2 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::98d2:4fff:fec0:cdd2/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc5720e1952432@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:54:65:ff:44:c3 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f854:65ff:feff:44c3/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc9d18a2e0ee13@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:48:70:b5:13:46 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::7048:70ff:feb5:1346/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcaa1692ef11e5@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:23:5f:e1:d5:87 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::f023:5fff:fee1:d587/64 scope link 
       valid_lft forever preferred_lft forever
