{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.232Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.252Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.914Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.919Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.973Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.984Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.010Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.262Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.265Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.341Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.348Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.387Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.005Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.021Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.062Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.105Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.137Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.335Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.342Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.408Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.452Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.456Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.044Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.077Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.102Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.120Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.161Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.163Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.398Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.407Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.446Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.500Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.517Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.117Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.121Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.160Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.161Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.205Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.207Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.240Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.544Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.551Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.623Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.627Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.666Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.990Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.048Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.048Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.092Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.107Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.134Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.350Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.361Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.412Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.420Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.453Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.915Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.921Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.973Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.979Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.013Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.238Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.256Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.347Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.397Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.414Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.824Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.837Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.883Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.897Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.929Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.180Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.188Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.248Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.257Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.296Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.676Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.706Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.715Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.748Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.781Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.801Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.098Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.103Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.158Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.173Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.207Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.585Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.669Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.680Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.739Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.739Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.751Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.958Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.974Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.022Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.059Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.071Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.402Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.414Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.454Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.497Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.512Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.741Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.744Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.795Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.799Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.845Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.130Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.161Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.172Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.217Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.218Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.239Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.546Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.564Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.615Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.634Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.640Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.343Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.346Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.379Z",
  "value": "id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.409Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.424Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.733Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.736Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.415Z",
  "value": "id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.426Z",
  "value": "id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3"
}

