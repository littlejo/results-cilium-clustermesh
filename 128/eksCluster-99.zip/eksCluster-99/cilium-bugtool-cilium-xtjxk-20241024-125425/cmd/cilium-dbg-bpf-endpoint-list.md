IP ADDRESS         LOCAL ENDPOINT INFO
10.99.0.33:0       id=1003  sec_id=6571872 flags=0x0000 ifindex=24  mac=DE:50:88:33:48:10 nodemac=F2:23:5F:E1:D5:87   
10.99.0.46:0       (localhost)                                                                                        
10.99.0.117:0      id=72    sec_id=6554925 flags=0x0000 ifindex=20  mac=EA:A0:54:35:16:F6 nodemac=FA:54:65:FF:44:C3   
10.99.0.247:0      id=3302  sec_id=6590228 flags=0x0000 ifindex=22  mac=C6:DB:DF:B4:75:79 nodemac=72:48:70:B5:13:46   
10.99.0.20:0       id=118   sec_id=4     flags=0x0000 ifindex=10  mac=DE:33:19:2C:15:EF nodemac=1E:CD:B8:F7:B3:37     
172.31.242.93:0    (localhost)                                                                                        
172.31.222.193:0   (localhost)                                                                                        
10.99.0.212:0      id=2065  sec_id=6556600 flags=0x0000 ifindex=12  mac=82:07:A9:80:16:D4 nodemac=26:5C:B3:CA:84:2F   
10.99.0.250:0      id=427   sec_id=6556600 flags=0x0000 ifindex=14  mac=6E:9D:86:D4:97:22 nodemac=22:A6:59:47:C1:C7   
10.99.0.151:0      id=475   sec_id=6616550 flags=0x0000 ifindex=18  mac=EE:DF:29:1D:AB:37 nodemac=9A:D2:4F:C0:CD:D2   
