USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3318  1.0  0.3 1240432 15564 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3340  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3342  0.0  0.0   3720   484 ?        R    12:54   0:00  \_ bash -c hostname
root           1  4.1  7.4 1539060 294064 ?      Ssl  12:27   1:07 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 9940 ?        Sl   12:27   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
