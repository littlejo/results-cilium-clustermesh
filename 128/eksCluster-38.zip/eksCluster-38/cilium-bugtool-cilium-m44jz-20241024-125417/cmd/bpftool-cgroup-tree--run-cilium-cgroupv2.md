CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39e45ea0_780a_4cfe_a699_69aceca68dbc.slice/cri-containerd-6b50266ba6ce6a36a7664a3bddc3892c0dcf78c6bb7c083f558f2283bf155276.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39e45ea0_780a_4cfe_a699_69aceca68dbc.slice/cri-containerd-89b34a761fff6bc4e6b2ea5f314247d7b19b57a9202ac78d2c3c3d8c6330fa7d.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8a8e59f_4400_4b25_bb52_ddc2bc46c3d8.slice/cri-containerd-a60912f7e3c30202cc7558b018783639a1162169473f18d0c076c79fa17639e4.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8a8e59f_4400_4b25_bb52_ddc2bc46c3d8.slice/cri-containerd-862874891d8608bd9ee4c40a1cfce701120f6184c3b5292b032eba0e7361478e.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36c3fbfe_7040_4d30_ab8c_7323d07421b5.slice/cri-containerd-deaf72e601201c3184c481d7b9668f01da4be43468adfde58b1b6b0970741aa0.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36c3fbfe_7040_4d30_ab8c_7323d07421b5.slice/cri-containerd-8ffeb0be59c5841e50cfe4471f66e9cb092927c057bea57fdad4868e45af2ba8.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd3a51194_45e5_436d_8b36_158f1a6085d3.slice/cri-containerd-7f58034ed888bc2307cfb598f067320af1d92db4106ff7e3b4fc898a6419e361.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd3a51194_45e5_436d_8b36_158f1a6085d3.slice/cri-containerd-2b65a8bf9b7f2b92186d53dfd13b2e7882a05610276ff750d15e926445cb15eb.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f12d5c5_1198_42fb_b7e4_1284c9dfcb02.slice/cri-containerd-d2f37b177ee8d8b97aa8f018ba4d61368e681c43e0da14a38b5ccc876ac54e53.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f12d5c5_1198_42fb_b7e4_1284c9dfcb02.slice/cri-containerd-9cb03b9a97d12842a0b821a1b34a5943c9ae8c69cc695a07283870ee1be2ae70.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72755b54_0e18_4a8a_85a3_dd6aed7802a6.slice/cri-containerd-ee6659b548907aaafadb93bb483f4ecb901c683006777d60a0fbb455b63a76fb.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72755b54_0e18_4a8a_85a3_dd6aed7802a6.slice/cri-containerd-93c08384f297e77a8df5121d8587c9b456f7d8062dbc5f45bb47d12f4741d914.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0a5aa0a_1302_4b76_b502_59b16786981c.slice/cri-containerd-2900a900a52211c8ae0cac15e4656c5db538927d25374b1c8a52cc2b03542122.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0a5aa0a_1302_4b76_b502_59b16786981c.slice/cri-containerd-a91ac7575620d137f6abc81efcbefe99ed2f29a3ee757dc552d961b4d1758186.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58c8f56c_84f4_45f1_9b25_b1295caee1e9.slice/cri-containerd-3886808f067d6f6b5349616d5fe671d2de7413b4353fc28901607d3f60282dff.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58c8f56c_84f4_45f1_9b25_b1295caee1e9.slice/cri-containerd-9905b5d9b56c81d73ba471133c1efe95437ea08dfab699cd0855bf7ae22a5eff.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58c8f56c_84f4_45f1_9b25_b1295caee1e9.slice/cri-containerd-31065d09033535ecbc605d5aca5d8ab800dda4955203c2261e714eabad0ad9ae.scope
    712      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61fa403f_1beb_4b5e_b723_2a2aea7604ae.slice/cri-containerd-dddfb8f056df5a110a7226017f647db45277a256b9f787b7471c08afa9e9757b.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61fa403f_1beb_4b5e_b723_2a2aea7604ae.slice/cri-containerd-9d983e0265204245d97ba0633aebd1e7274715082484ada491115ee32c8d777b.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61fa403f_1beb_4b5e_b723_2a2aea7604ae.slice/cri-containerd-824e9883ee84859caeb9ed8c99acc24e417212c754323f09856205437e5c7c66.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61fa403f_1beb_4b5e_b723_2a2aea7604ae.slice/cri-containerd-63aa8834bd9b2c6f3e5c1c88df6e7ded053c37e134f969bde5fb1a8205f9a403.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa0f5aa0_61c7_497d_802d_078882313227.slice/cri-containerd-83ed619e9a50a6fcb6ada9c1925b332786d49a09c3958bc3fdb865554277509c.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa0f5aa0_61c7_497d_802d_078882313227.slice/cri-containerd-74d19d074ee489feccb02f258aa154254c7c8be71eace3daf89c11f2eb6596cb.scope
    724      cgroup_device   multi                                          
