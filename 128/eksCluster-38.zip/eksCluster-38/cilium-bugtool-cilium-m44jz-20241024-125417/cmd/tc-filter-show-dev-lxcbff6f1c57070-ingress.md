filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbff6f1c57070 direct-action not_in_hw id 541 tag 78c4080976795cac jited 
