1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b0:c8:5b:e3:a3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.144.72/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3429sec preferred_lft 3429sec
    inet6 fe80::4b0:c8ff:fe5b:e3a3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b3:3c:33:0f:c1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.156.201/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4b3:3cff:fe33:fc1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:5f:41:7c:c8:fb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c5f:41ff:fe7c:c8fb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:38:77:83:6d:c9 brd ff:ff:ff:ff:ff:ff
    inet 10.38.0.136/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8838:77ff:fe83:6dc9/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ee:d1:95:a9:7c:4c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ecd1:95ff:fea9:7c4c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:a6:79:7c:f2:8d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f8a6:79ff:fe7c:f28d/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf6ac40b7a74a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:f2:fd:5a:ff:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a4f2:fdff:fe5a:ffa4/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcbff6f1c57070@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:ba:89:67:8f:3c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::d8ba:89ff:fe67:8f3c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2fa5d5a33fc9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:df:33:40:98:34 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::20df:33ff:fe40:9834/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc7249c5ab89bd@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:2b:b7:0d:af:b7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::e42b:b7ff:fe0d:afb7/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc2b7162fcf162@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:04:02:8c:ff:dd brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::3004:2ff:fe8c:ffdd/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc50d895ab7c47@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:80:d4:01:64:1a brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::2c80:d4ff:fe01:641a/64 scope link 
       valid_lft forever preferred_lft forever
