Node 0, zone      DMA      2      1      2      0      5      7      5      3      4      4     43 
Node 0, zone   Normal     26     32     37      1     22     17     10      4      7      3      5 
