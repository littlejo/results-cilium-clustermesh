alloc: 74.11MB (77708032 bytes)
total-alloc: 3.11GB (3337210568 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75377171
frees: 74843186
heap-alloc: 74.11MB (77708032 bytes)
heap-sys: 177.13MB (185737216 bytes)
heap-idle: 51.27MB (53755904 bytes)
heap-in-use: 125.87MB (131981312 bytes)
heap-released: 9.12MB (9568256 bytes)
heap-objects: 533985
stack-in-use: 34.84MB (36536320 bytes)
stack-sys: 34.84MB (36536320 bytes)
stack-mspan-inuse: 2.13MB (2228320 bytes)
stack-mspan-sys: 2.82MB (2953920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 939.02KB (961553 bytes)
gc-sys: 5.51MB (5774432 bytes)
next-gc: when heap-alloc >= 150.01MB (157298152 bytes)
last-gc: 2024-10-24 12:54:18.971916221 +0000 UTC
gc-pause-total: 18.057489ms
gc-pause: 3930260
gc-pause-end: 1729774458971916221
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005917913385897324
enable-gc: true
debug-gc: false
