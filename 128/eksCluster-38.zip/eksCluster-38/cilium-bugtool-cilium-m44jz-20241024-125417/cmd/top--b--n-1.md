top - 12:54:19 up 33 min,  0 users,  load average: 1.13, 0.73, 0.38
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 30.0 us, 33.3 sy,  0.0 ni, 36.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    283.8 free,   1054.6 used,   2497.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2600.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 296032  79300 S  33.3   7.5   1:07.59 cilium-+
   3318 root      20   0 1240432  15564  10576 S  13.3   0.4   0:00.03 cilium-+
    394 root      20   0 1229744   9940   3836 S   0.0   0.3   0:04.26 cilium-+
   3352 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3376 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
