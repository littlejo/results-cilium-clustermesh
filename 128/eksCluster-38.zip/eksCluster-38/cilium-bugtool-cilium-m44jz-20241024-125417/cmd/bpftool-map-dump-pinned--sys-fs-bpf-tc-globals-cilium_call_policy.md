key: 91 00 00 00  value: 16 0d 00 00
key: b3 00 00 00  value: e0 0c 00 00
key: 49 01 00 00  value: 3f 02 00 00
key: a1 01 00 00  value: 1c 02 00 00
key: c3 01 00 00  value: 12 02 00 00
key: 7d 04 00 00  value: 84 02 00 00
key: 40 06 00 00  value: 1b 0d 00 00
Found 7 elements
