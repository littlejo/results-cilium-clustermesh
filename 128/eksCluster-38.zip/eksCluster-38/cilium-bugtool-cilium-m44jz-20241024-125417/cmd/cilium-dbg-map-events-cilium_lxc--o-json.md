{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.559Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.588Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.628Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.645Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.704Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.916Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.921Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.983Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.011Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.026Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.627Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.652Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.691Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.714Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.736Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.958Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.983Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.036Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.062Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.091Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.664Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.668Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.710Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.720Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.765Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.780Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.802Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.049Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.058Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.178Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.197Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.230Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.844Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.845Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.900Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.916Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.954Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.958Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.988Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.204Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.206Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.260Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.294Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.318Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.730Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.738Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.784Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.797Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.826Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.036Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.039Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.089Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.096Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.138Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.504Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.570Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.607Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.657Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.657Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.665Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.867Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.869Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.921Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.933Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.959Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.339Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.376Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.381Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.434Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.435Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.471Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.697Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.709Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.741Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.774Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.800Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.357Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.361Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.397Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.446Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.498Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.510Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.532Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.867Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.922Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.970Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.025Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.028Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.398Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.439Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.443Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.487Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.510Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.530Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.749Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.754Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.806Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.828Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.848Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.121Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.150Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.165Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.212Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.224Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.455Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.483Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.517Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.538Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.559Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.872Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.900Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.920Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.991Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.003Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.054Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.266Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.283Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.290Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.322Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.037Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.039Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.073Z",
  "value": "id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.106Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.118Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.419Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.421Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.085Z",
  "value": "id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.091Z",
  "value": "id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A"
}

