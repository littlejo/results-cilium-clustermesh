Endpoint ID: 8
Path: /sys/fs/bpf/tc/globals/cilium_policy_00008

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 145
Path: /sys/fs/bpf/tc/globals/cilium_policy_00145

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 179
Path: /sys/fs/bpf/tc/globals/cilium_policy_00179

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    351351   4097      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 329
Path: /sys/fs/bpf/tc/globals/cilium_policy_00329

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6193862   76551     0        
Allow    Ingress     1          ANY          NONE         disabled    67628     813       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 417
Path: /sys/fs/bpf/tc/globals/cilium_policy_00417

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2766     26        0        
Allow    Ingress     1          ANY          NONE         disabled    154761   1777      0        
Allow    Egress      0          ANY          NONE         disabled    19435    217       0        


Endpoint ID: 451
Path: /sys/fs/bpf/tc/globals/cilium_policy_00451

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3130     34        0        
Allow    Ingress     1          ANY          NONE         disabled    153705   1761      0        
Allow    Egress      0          ANY          NONE         disabled    20385    227       0        


Endpoint ID: 1149
Path: /sys/fs/bpf/tc/globals/cilium_policy_01149

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5447858   56691     0        
Allow    Ingress     1          ANY          NONE         disabled    5150459   54173     0        
Allow    Egress      0          ANY          NONE         disabled    6433646   64937     0        


Endpoint ID: 1600
Path: /sys/fs/bpf/tc/globals/cilium_policy_01600

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


