filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2b7162fcf162 direct-action not_in_hw id 3290 tag e350e4f2bc4169d6 jited 
