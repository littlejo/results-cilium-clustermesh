[
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61fa403f_1beb_4b5e_b723_2a2aea7604ae.slice/cri-containerd-63aa8834bd9b2c6f3e5c1c88df6e7ded053c37e134f969bde5fb1a8205f9a403.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61fa403f_1beb_4b5e_b723_2a2aea7604ae.slice/cri-containerd-824e9883ee84859caeb9ed8c99acc24e417212c754323f09856205437e5c7c66.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61fa403f_1beb_4b5e_b723_2a2aea7604ae.slice/cri-containerd-dddfb8f056df5a110a7226017f647db45277a256b9f787b7471c08afa9e9757b.scope"
      }
    ],
    "ips": [
      "10.38.0.186"
    ],
    "name": "clustermesh-apiserver-cd984fcb7-4rq6b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8a8e59f_4400_4b25_bb52_ddc2bc46c3d8.slice/cri-containerd-862874891d8608bd9ee4c40a1cfce701120f6184c3b5292b032eba0e7361478e.scope"
      }
    ],
    "ips": [
      "10.38.0.117"
    ],
    "name": "coredns-cc6ccd49c-6b264",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39e45ea0_780a_4cfe_a699_69aceca68dbc.slice/cri-containerd-6b50266ba6ce6a36a7664a3bddc3892c0dcf78c6bb7c083f558f2283bf155276.scope"
      }
    ],
    "ips": [
      "10.38.0.113"
    ],
    "name": "coredns-cc6ccd49c-64dr6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa0f5aa0_61c7_497d_802d_078882313227.slice/cri-containerd-74d19d074ee489feccb02f258aa154254c7c8be71eace3daf89c11f2eb6596cb.scope"
      }
    ],
    "ips": [
      "10.38.0.119"
    ],
    "name": "client-974f6c69d-7qfxm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72755b54_0e18_4a8a_85a3_dd6aed7802a6.slice/cri-containerd-93c08384f297e77a8df5121d8587c9b456f7d8062dbc5f45bb47d12f4741d914.scope"
      }
    ],
    "ips": [
      "10.38.0.246"
    ],
    "name": "client2-57cf4468f-lrhkz",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58c8f56c_84f4_45f1_9b25_b1295caee1e9.slice/cri-containerd-3886808f067d6f6b5349616d5fe671d2de7413b4353fc28901607d3f60282dff.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58c8f56c_84f4_45f1_9b25_b1295caee1e9.slice/cri-containerd-9905b5d9b56c81d73ba471133c1efe95437ea08dfab699cd0855bf7ae22a5eff.scope"
      }
    ],
    "ips": [
      "10.38.0.114"
    ],
    "name": "echo-same-node-86d9cc975c-d25tl",
    "namespace": "cilium-test-1"
  }
]

