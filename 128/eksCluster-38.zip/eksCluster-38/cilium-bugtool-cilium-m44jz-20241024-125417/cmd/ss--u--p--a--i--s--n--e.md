Total: 572
TCP:   4232 (estab 296, closed 3917, orphaned 0, timewait 3446)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  315       308       7        
INET	  325       314       11       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.144.72%ens5:68         0.0.0.0:*    uid:192 ino:92903 sk:eab cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:30426 sk:eac cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15109 sk:ead cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:43883      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:30769 sk:eae fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:30425 sk:eaf cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15110 sk:eb0 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::4b0:c8ff:fe5b:e3a3]%ens5:546           [::]:*    uid:192 ino:15713 sk:eb1 cgroup:unreachable:bd0 v6only:1 <->                   
