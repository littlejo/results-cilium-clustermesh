IP ADDRESS         LOCAL ENDPOINT INFO
10.38.0.186:0      id=1149  sec_id=2560088 flags=0x0000 ifindex=18  mac=4A:7C:7F:6C:8B:70 nodemac=22:DF:33:40:98:34   
10.38.0.220:0      id=329   sec_id=4     flags=0x0000 ifindex=10  mac=1E:2E:B3:E4:D8:5D nodemac=FA:A6:79:7C:F2:8D     
10.38.0.117:0      id=417   sec_id=2562857 flags=0x0000 ifindex=14  mac=FE:05:05:A7:0C:BC nodemac=DA:BA:89:67:8F:3C   
10.38.0.119:0      id=1600  sec_id=2572239 flags=0x0000 ifindex=20  mac=52:99:A2:A6:92:FE nodemac=E6:2B:B7:0D:AF:B7   
10.38.0.136:0      (localhost)                                                                                        
10.38.0.246:0      id=145   sec_id=2562520 flags=0x0000 ifindex=24  mac=AE:E1:6B:DB:8F:EA nodemac=2E:80:D4:01:64:1A   
172.31.144.72:0    (localhost)                                                                                        
172.31.156.201:0   (localhost)                                                                                        
10.38.0.114:0      id=179   sec_id=2566722 flags=0x0000 ifindex=22  mac=DE:72:9A:15:59:C3 nodemac=32:04:02:8C:FF:DD   
10.38.0.113:0      id=451   sec_id=2562857 flags=0x0000 ifindex=12  mac=86:C6:62:A6:88:BD nodemac=A6:F2:FD:5A:FF:A4   
