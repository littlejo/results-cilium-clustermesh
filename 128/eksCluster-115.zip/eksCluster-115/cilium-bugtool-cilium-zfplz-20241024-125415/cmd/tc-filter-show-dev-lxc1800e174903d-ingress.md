filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc1800e174903d direct-action not_in_hw id 3350 tag 2f57cde664527666 jited 
