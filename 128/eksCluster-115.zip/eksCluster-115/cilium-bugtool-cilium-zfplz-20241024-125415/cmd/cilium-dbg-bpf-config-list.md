KEY             VALUE
AgentLiveness   1886985185732
UTimeOffset     3378462111328125
