key: 66 00 00 00  value: 8b 02 00 00
key: 96 00 00 00  value: 44 02 00 00
key: 9b 00 00 00  value: 2b 0d 00 00
key: a8 01 00 00  value: 3c 02 00 00
key: a1 03 00 00  value: 19 0d 00 00
key: 71 04 00 00  value: f2 0c 00 00
key: ac 08 00 00  value: 18 02 00 00
Found 7 elements
