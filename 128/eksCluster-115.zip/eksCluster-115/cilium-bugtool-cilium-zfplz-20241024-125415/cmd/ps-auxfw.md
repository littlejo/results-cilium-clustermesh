USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3231  0.0  0.3 1240176 15596 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3250  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3253  0.0  0.0   3852  1292 ?        R    12:54   0:00  \_ ip a
root        3225  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3216  0.0  0.0 1228744 3712 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3205  0.0  0.0 1228744 3604 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  5.1  7.2 1539060 286604 ?      Ssl  12:33   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         407  0.3  0.2 1229744 10092 ?       Sl   12:33   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
