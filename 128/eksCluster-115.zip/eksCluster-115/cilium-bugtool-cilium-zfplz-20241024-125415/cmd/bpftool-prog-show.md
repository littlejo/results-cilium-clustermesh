35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:25+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:26+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:27+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:27+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:27+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:27+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:31+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:33:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:33:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:33:13+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag c9d0bc5f08f1712f  gpl
	loaded_at 2024-10-24T12:33:13+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:33:13+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:33:13+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
519: sched_cls  name tail_handle_arp  tag d5d6be816e7be796  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 165
521: sched_cls  name tail_ipv4_ct_egress  tag 02e7ef3b663232ec  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 168
523: sched_cls  name tail_ipv4_ct_ingress  tag 922bbeccebb88da2  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 169
524: sched_cls  name tail_handle_ipv4  tag a544d95741e95325  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 171
526: sched_cls  name cil_from_container  tag 65816e4eb57c8e86  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 172
530: sched_cls  name tail_ipv4_to_endpoint  tag 8c56a9eb10d364f4  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 174
531: sched_cls  name __send_drop_notify  tag d80b0490d9e625f9  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
534: sched_cls  name tail_handle_arp  tag 6ba749e607b68223  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 182
535: sched_cls  name __send_drop_notify  tag bcaa16c8e825b7d8  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 183
536: sched_cls  name handle_policy  tag 497c96c3ca7d64c1  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 179
537: sched_cls  name tail_ipv4_ct_ingress  tag f516c36f1268fb1e  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 184
539: sched_cls  name tail_handle_ipv4_cont  tag 55a85a75b2aca9d6  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 187
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 188
541: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 190
542: sched_cls  name tail_ipv4_to_endpoint  tag 67c85aadd188e887  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 186
543: sched_cls  name tail_handle_ipv4_from_host  tag 991fbf3e875e086f  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 191
544: sched_cls  name cil_from_container  tag f7418a913a50ef7a  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 192
545: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 193
547: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 195
548: sched_cls  name __send_drop_notify  tag a3e86332f9edadaf  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 196
550: sched_cls  name tail_handle_ipv4  tag deb2ba95525f78e9  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 198
551: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
552: sched_cls  name __send_drop_notify  tag a3e86332f9edadaf  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
555: sched_cls  name tail_handle_ipv4_from_host  tag 991fbf3e875e086f  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 205
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 206
558: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 209
561: sched_cls  name __send_drop_notify  tag a3e86332f9edadaf  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
562: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 213
564: sched_cls  name tail_handle_ipv4_from_host  tag 991fbf3e875e086f  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 215
565: sched_cls  name tail_handle_ipv4_from_host  tag 991fbf3e875e086f  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 217
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 218
569: sched_cls  name __send_drop_notify  tag a3e86332f9edadaf  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 221
570: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 222
572: sched_cls  name handle_policy  tag ee53360fef0090c3  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 204
574: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 225
575: sched_cls  name tail_ipv4_ct_egress  tag 02e7ef3b663232ec  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 226
576: sched_cls  name __send_drop_notify  tag 3e0060a564eb92d8  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 229
577: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 230
578: sched_cls  name tail_handle_ipv4_cont  tag e0672b803f3d16cc  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 227
579: sched_cls  name tail_handle_ipv4_cont  tag d806b362efd6a1fc  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 231
580: sched_cls  name handle_policy  tag 065fd5ab36a30225  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 232
581: sched_cls  name tail_handle_ipv4  tag feaf5dc73d45162e  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 233
583: sched_cls  name tail_handle_arp  tag 67ae27d777436115  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 235
584: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 236
585: sched_cls  name tail_ipv4_ct_ingress  tag 72fa77f6f1a30fa6  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 237
586: sched_cls  name tail_ipv4_to_endpoint  tag c2e66f142c34b683  gpl
	loaded_at 2024-10-24T12:33:15+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 238
587: sched_cls  name cil_from_container  tag 5dcb5dd84d08e316  gpl
	loaded_at 2024-10-24T12:33:16+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 239
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:33:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:33:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:33:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:33:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:33:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:33:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:33:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:33:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name tail_ipv4_ct_egress  tag d4613e36f0911c4f  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 253
644: sched_cls  name cil_from_container  tag 2600ee0c3566f09d  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 254
645: sched_cls  name tail_handle_ipv4  tag d1e83ac8acb3f297  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 255
646: sched_cls  name tail_ipv4_to_endpoint  tag 47c27db5d0088076  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 256
648: sched_cls  name __send_drop_notify  tag 19faabc475289e07  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 258
649: sched_cls  name tail_ipv4_ct_ingress  tag fcb8fd5838c0851a  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 259
650: sched_cls  name tail_handle_arp  tag 06f08cd92c2d6773  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 260
651: sched_cls  name handle_policy  tag 09d40803a4be0790  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 261
652: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 262
653: sched_cls  name tail_handle_ipv4_cont  tag bbdd78784d96f4d6  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
723: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
726: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
727: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
730: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
731: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
734: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
735: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
738: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
739: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
742: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3296: sched_cls  name tail_handle_ipv4  tag 18b76909855c5574  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,631
	btf_id 3086
3298: sched_cls  name cil_from_container  tag 2630fa2b64fdf68e  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 631,76
	btf_id 3089
3300: sched_cls  name tail_ipv4_ct_egress  tag 0493ffdc6b5403c8  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,631,82,83,632,84
	btf_id 3091
3303: sched_cls  name tail_handle_ipv4_cont  tag 52f11c3c3452025f  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,632,41,154,82,83,39,76,74,77,631,40,37,38,81
	btf_id 3093
3306: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,631
	btf_id 3097
3311: sched_cls  name tail_ipv4_ct_ingress  tag 4302e6963117f9a3  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,631,82,83,632,84
	btf_id 3099
3312: sched_cls  name __send_drop_notify  tag a6a673f4fa548ac9  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3104
3314: sched_cls  name handle_policy  tag 5e9ce202af5356bd  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,631,82,83,632,41,80,154,39,84,75,40,37,38
	btf_id 3105
3316: sched_cls  name tail_ipv4_to_endpoint  tag 5be75cca38918408  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,632,41,82,83,80,154,39,631,40,37,38
	btf_id 3108
3318: sched_cls  name tail_handle_arp  tag da1be87f0d9a9c2c  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,631
	btf_id 3111
3350: sched_cls  name cil_from_container  tag 2f57cde664527666  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 642,76
	btf_id 3145
3351: sched_cls  name tail_ipv4_to_endpoint  tag 0eeeb03ffac0d81d  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,641,41,82,83,80,157,39,642,40,37,38
	btf_id 3147
3353: sched_cls  name handle_policy  tag 8b21e82bec6ecaec  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,643,82,83,644,41,80,151,39,84,75,40,37,38
	btf_id 3148
3354: sched_cls  name tail_handle_ipv4_cont  tag 0f1066245ce67341  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,641,41,157,82,83,39,76,74,77,642,40,37,38,81
	btf_id 3150
3355: sched_cls  name tail_ipv4_ct_egress  tag faac97d45f3d3230  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3151
3356: sched_cls  name cil_from_container  tag 3380ac753d79ed15  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 643,76
	btf_id 3153
3357: sched_cls  name __send_drop_notify  tag abaec010159f7359  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3154
3358: sched_cls  name tail_ipv4_ct_ingress  tag 207de6a6980918b0  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3152
3359: sched_cls  name tail_handle_arp  tag e17e888c23855f4b  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,642
	btf_id 3156
3360: sched_cls  name __send_drop_notify  tag c0238d3872028563  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3157
3361: sched_cls  name tail_ipv4_ct_ingress  tag fa11658992ee136c  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3155
3362: sched_cls  name tail_ipv4_ct_egress  tag b65a876c24a3e696  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3158
3363: sched_cls  name tail_handle_ipv4_cont  tag 2de540a5026d66f1  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,644,41,151,82,83,39,76,74,77,643,40,37,38,81
	btf_id 3159
3364: sched_cls  name tail_ipv4_to_endpoint  tag de8e8043330e0f43  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,644,41,82,83,80,151,39,643,40,37,38
	btf_id 3161
3365: sched_cls  name tail_handle_ipv4  tag 6401298651a28f9d  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,642
	btf_id 3160
3366: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,642
	btf_id 3163
3367: sched_cls  name tail_handle_ipv4  tag 913831c8ff0d40fd  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,643
	btf_id 3162
3368: sched_cls  name tail_handle_arp  tag a92f07fe4173d476  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,643
	btf_id 3165
3370: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,643
	btf_id 3167
3371: sched_cls  name handle_policy  tag 099e9fdbad754bf1  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,642,82,83,641,41,80,157,39,84,75,40,37,38
	btf_id 3164
