REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     132258    10715145    677    bpf_overlay.c
Interface                   INGRESS     665262    246293585   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      132078    10699819    53     encap.h
Success                     EGRESS      146752    19556590    1308   bpf_lxc.c
Success                     EGRESS      55752     4519101     1694   bpf_host.c
Success                     EGRESS      596       156337      86     l3.h
Success                     INGRESS     170390    19557883    86     l3.h
Success                     INGRESS     248123    25952734    235    trace.h
Unsupported L3 protocol     EGRESS      71        5354        1492   bpf_lxc.c
