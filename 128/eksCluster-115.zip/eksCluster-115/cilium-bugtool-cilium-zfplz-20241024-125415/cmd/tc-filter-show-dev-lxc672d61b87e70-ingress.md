filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc672d61b87e70 direct-action not_in_hw id 3356 tag 3380ac753d79ed15 jited 
