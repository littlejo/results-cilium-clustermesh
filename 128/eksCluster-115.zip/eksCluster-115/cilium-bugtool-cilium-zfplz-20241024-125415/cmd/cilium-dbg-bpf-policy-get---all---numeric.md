Endpoint ID: 102
Path: /sys/fs/bpf/tc/globals/cilium_policy_00102

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6098863   61136     0        
Allow    Ingress     1          ANY          NONE         disabled    5178653   54530     0        
Allow    Egress      0          ANY          NONE         disabled    6678341   66107     0        


Endpoint ID: 150
Path: /sys/fs/bpf/tc/globals/cilium_policy_00150

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6240222   77159     0        
Allow    Ingress     1          ANY          NONE         disabled    60786     737       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 155
Path: /sys/fs/bpf/tc/globals/cilium_policy_00155

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 424
Path: /sys/fs/bpf/tc/globals/cilium_policy_00424

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3682     37        0        
Allow    Ingress     1          ANY          NONE         disabled    123367   1415      0        
Allow    Egress      0          ANY          NONE         disabled    17981    197       0        


Endpoint ID: 890
Path: /sys/fs/bpf/tc/globals/cilium_policy_00890

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 929
Path: /sys/fs/bpf/tc/globals/cilium_policy_00929

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1137
Path: /sys/fs/bpf/tc/globals/cilium_policy_01137

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378359   4408      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2220
Path: /sys/fs/bpf/tc/globals/cilium_policy_02220

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2214     23        0        
Allow    Ingress     1          ANY          NONE         disabled    123235   1413      0        
Allow    Egress      0          ANY          NONE         disabled    18587    205       0        


