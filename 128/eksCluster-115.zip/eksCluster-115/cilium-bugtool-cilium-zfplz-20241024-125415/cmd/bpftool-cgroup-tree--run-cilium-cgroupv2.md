CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbeb08c1b_6e88_4c99_a5a7_29dd87d7399d.slice/cri-containerd-4d8306031a20bf784d5e5369e7b5ca88e7776713b544e6a0bc7687c828341168.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbeb08c1b_6e88_4c99_a5a7_29dd87d7399d.slice/cri-containerd-8afa07399a0ac3da856e989fcfadfb40a2ffa958ba98d7090ef3b1e654d43a63.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d38683d_2b05_431b_9cee_82761229a4db.slice/cri-containerd-b09532ea8d5ed816c0532c909691ec5fc8b4e7acfd38879f2d8a9ae617a6cfed.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d38683d_2b05_431b_9cee_82761229a4db.slice/cri-containerd-115874b34c8347cb7d752738ce618ca722ea01319780f806992b505ee83e07aa.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod666a165f_4576_44d4_8f16_4e339bfe796f.slice/cri-containerd-5c42d7c474612e12d64f6729e7145203e3e77d81d52128b82e01d0e130f597db.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod666a165f_4576_44d4_8f16_4e339bfe796f.slice/cri-containerd-f45a509c6ee3c392ac37decc39405502d2cb4d68f38cca5245e23b723ab84b75.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda985ea49_e471_4610_8616_1febdfb85443.slice/cri-containerd-8e3ecc0655f3fe41ad817f5083551b0d059e2e6d07fc92d79a8c33f81a52671e.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda985ea49_e471_4610_8616_1febdfb85443.slice/cri-containerd-e59352c9a265d18aabe89f2f6763534540e978b6be83ff6663ac8ac88b5b5f21.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f4e818b_e9ba_4f12_9a93_0edbe8ab6cd6.slice/cri-containerd-ec2be6e33b7d279c5053baf54be3e23009451e7a84ab312554e17672cb57d612.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f4e818b_e9ba_4f12_9a93_0edbe8ab6cd6.slice/cri-containerd-47fea5d16cbfcce7aefb0d3402c0dc9dea087adc313236dcac412cc5af893543.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf74b076_a830_4cf7_8529_e052c0aee71d.slice/cri-containerd-c804e81a23d3cf363b1cdbe6407622d5dea9d78b79a69bae65d62c8c258ce2d5.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf74b076_a830_4cf7_8529_e052c0aee71d.slice/cri-containerd-ff9e175d2f3a7dcabc3a5f661298540cd6a7d9a93eb965eab431624bd5cf70b8.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3bd38445_6852_49d6_978e_7cea68664d4b.slice/cri-containerd-cde0f6815aa84d1c56b2db35b98ad1f62092276a7c96ea6cf2878a45dd0d5919.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3bd38445_6852_49d6_978e_7cea68664d4b.slice/cri-containerd-40ebd2a1280406b38977a148ceb7c30f412368a9a8e43dbcab00df40314f70e9.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39ee150f_d6b3_4df2_bcfc_905a714cd7f6.slice/cri-containerd-5a00fe7cb6bdc6168b7f5f3afb600626076eebf29ebb1bdf4b5ca2d4ece56e1b.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39ee150f_d6b3_4df2_bcfc_905a714cd7f6.slice/cri-containerd-9307c335636790af87df1a37348aa96a8b76cfb5f64150d121cad2b64b4eb452.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a55872e_b61d_47dd_ab24_8cbe5947cb47.slice/cri-containerd-cf42d450de50b1764c005c2c6dcee1572c7860bf67f61e60c4ff7e8f12ad14a6.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a55872e_b61d_47dd_ab24_8cbe5947cb47.slice/cri-containerd-b75f5201e2e7439db2f2e7095ad69c18a50a18d916fffe11e94ba77bb10953c7.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a55872e_b61d_47dd_ab24_8cbe5947cb47.slice/cri-containerd-2157aacd93f530337c9f59dd4cddc9803fee151435cf90af3eec74b777593a41.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a55872e_b61d_47dd_ab24_8cbe5947cb47.slice/cri-containerd-db01358904316293b74b5d94f4d95d2f8587c62f5b2ffd37f5acaf5ed65dac7d.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcddc43e_6a35_43cf_8cfb_4c5265959159.slice/cri-containerd-fff4e9a55bb38bfa2595561c8093161dd89f9d27676db63cc2383b5b9f89cdf1.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcddc43e_6a35_43cf_8cfb_4c5265959159.slice/cri-containerd-4d3a574049036e108c56dfd4fcf852ee3f84eb947281e80ac5a989e1ab3d5f23.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcddc43e_6a35_43cf_8cfb_4c5265959159.slice/cri-containerd-a4f0f3d318744eb9e77a3203610328e5787ffb84174187e59ea09a5f512fd11c.scope
    738      cgroup_device   multi                                          
