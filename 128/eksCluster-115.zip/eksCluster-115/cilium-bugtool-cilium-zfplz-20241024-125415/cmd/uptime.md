 12:54:16 up 30 min,  0 users,  load average: 1.01, 0.95, 0.52
