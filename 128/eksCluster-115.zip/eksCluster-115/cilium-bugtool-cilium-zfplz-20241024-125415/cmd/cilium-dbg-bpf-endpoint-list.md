IP ADDRESS         LOCAL ENDPOINT INFO
10.115.0.140:0     id=155   sec_id=7635488 flags=0x0000 ifindex=24  mac=2A:F2:92:0E:F4:F8 nodemac=AA:A4:A6:79:1B:10   
10.115.0.159:0     id=424   sec_id=7605683 flags=0x0000 ifindex=14  mac=12:59:94:08:71:49 nodemac=A6:FE:85:23:67:A1   
10.115.0.142:0     id=1137  sec_id=7605396 flags=0x0000 ifindex=22  mac=66:63:A9:E2:25:3F nodemac=3A:0B:99:55:CA:0D   
10.115.0.48:0      id=150   sec_id=4     flags=0x0000 ifindex=10  mac=EA:D1:51:4B:35:F3 nodemac=DA:3F:B3:0D:D4:63     
172.31.192.109:0   (localhost)                                                                                        
10.115.0.250:0     id=2220  sec_id=7605683 flags=0x0000 ifindex=12  mac=1A:00:95:3D:02:12 nodemac=8A:10:3D:D3:50:89   
10.115.0.37:0      id=102   sec_id=7634097 flags=0x0000 ifindex=18  mac=1A:8A:7D:BC:EA:42 nodemac=6A:50:A6:15:CA:6A   
172.31.250.53:0    (localhost)                                                                                        
10.115.0.135:0     (localhost)                                                                                        
10.115.0.238:0     id=929   sec_id=7643823 flags=0x0000 ifindex=20  mac=FA:E4:DF:20:33:1A nodemac=1A:4F:47:15:C3:3F   
