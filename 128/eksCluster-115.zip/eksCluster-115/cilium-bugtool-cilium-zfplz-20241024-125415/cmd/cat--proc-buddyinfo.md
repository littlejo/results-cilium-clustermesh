Node 0, zone      DMA      6     44     36      8      1      4      4      0      2      4     39 
Node 0, zone   Normal    201      7     14      2      3     10      5      2      3      1      8 
