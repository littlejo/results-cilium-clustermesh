1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5b:78:fc:ca:d5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.250.53/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3557sec preferred_lft 3557sec
    inet6 fe80::85b:78ff:fefc:cad5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ba:a1:b2:af:3b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.192.109/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8ba:a1ff:feb2:af3b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:2b:b3:43:f7:eb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::202b:b3ff:fe43:f7eb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:25:c0:57:1d:2f brd ff:ff:ff:ff:ff:ff
    inet 10.115.0.135/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b425:c0ff:fe57:1d2f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 26:07:20:d3:d2:6a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2407:20ff:fed3:d26a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:3f:b3:0d:d4:63 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d83f:b3ff:fe0d:d463/64 scope link 
       valid_lft forever preferred_lft forever
12: lxceb9b27f6925e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:10:3d:d3:50:89 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::8810:3dff:fed3:5089/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcacf27bba7090@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:fe:85:23:67:a1 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::a4fe:85ff:fe23:67a1/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2821f4cbf127@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:50:a6:15:ca:6a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6850:a6ff:fe15:ca6a/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc672d61b87e70@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:4f:47:15:c3:3f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::184f:47ff:fe15:c33f/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcf3c525164cac@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:0b:99:55:ca:0d brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::380b:99ff:fe55:ca0d/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc1800e174903d@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:a4:a6:79:1b:10 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::a8a4:a6ff:fe79:1b10/64 scope link 
       valid_lft forever preferred_lft forever
