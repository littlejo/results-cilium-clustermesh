xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 562
ens6(5) clsact/ingress cil_from_netdev-ens6 id 570
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 551
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 547
cilium_host(7) clsact/egress cil_from_host-cilium_host id 541
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 587
lxceb9b27f6925e(12) clsact/ingress cil_from_container-lxceb9b27f6925e id 526
lxcacf27bba7090(14) clsact/ingress cil_from_container-lxcacf27bba7090 id 544
lxc2821f4cbf127(18) clsact/ingress cil_from_container-lxc2821f4cbf127 id 644
lxc672d61b87e70(20) clsact/ingress cil_from_container-lxc672d61b87e70 id 3356
lxcf3c525164cac(22) clsact/ingress cil_from_container-lxcf3c525164cac id 3298
lxc1800e174903d(24) clsact/ingress cil_from_container-lxc1800e174903d id 3350

flow_dissector:

netfilter:

