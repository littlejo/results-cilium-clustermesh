alloc: 103.20MB (108212984 bytes)
total-alloc: 3.05GB (3279901416 bytes)
sys: 215.32MB (225781076 bytes)
lookups: 0
mallocs: 74704887
frees: 73828159
heap-alloc: 103.20MB (108212984 bytes)
heap-sys: 168.58MB (176766976 bytes)
heap-idle: 33.26MB (34873344 bytes)
heap-in-use: 135.32MB (141893632 bytes)
heap-released: 1.74MB (1826816 bytes)
heap-objects: 876728
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.09MB (2187040 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 996.07KB (1019977 bytes)
gc-sys: 5.50MB (5772312 bytes)
next-gc: when heap-alloc >= 150.94MB (158273112 bytes)
last-gc: 2024-10-24 12:54:27.650344637 +0000 UTC
gc-pause-total: 11.758124ms
gc-pause: 95779
gc-pause-end: 1729774467650344637
num-gc: 97
num-forced-gc: 0
gc-cpu-fraction: 0.0006168962245847271
enable-gc: true
debug-gc: false
