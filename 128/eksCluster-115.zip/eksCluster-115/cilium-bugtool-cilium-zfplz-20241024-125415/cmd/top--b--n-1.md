top - 12:54:17 up 30 min,  0 users,  load average: 1.01, 0.95, 0.52
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 32.1 us, 32.1 sy,  0.0 ni, 35.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    287.1 free,   1050.3 used,   2498.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2604.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 286604  78980 S  13.3   7.3   1:05.47 cilium-+
   3231 root      20   0 1240432  15912  10896 S   6.7   0.4   0:00.03 cilium-+
    407 root      20   0 1229744  10092   3900 S   0.0   0.3   0:04.50 cilium-+
   3205 root      20   0 1228744   3604   2912 S   0.0   0.1   0:00.00 gops
   3216 root      20   0 1228744   3712   3040 S   0.0   0.1   0:00.00 gops
   3225 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3262 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3275 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3288 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3293 root      20   0 1243764  18428  13056 S   0.0   0.5   0:00.00 hubble
