[
  {
    "containers": [
      {
        "cgroup-id": 7709,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d38683d_2b05_431b_9cee_82761229a4db.slice/cri-containerd-b09532ea8d5ed816c0532c909691ec5fc8b4e7acfd38879f2d8a9ae617a6cfed.scope"
      }
    ],
    "ips": [
      "10.115.0.250"
    ],
    "name": "coredns-cc6ccd49c-xrc5v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcddc43e_6a35_43cf_8cfb_4c5265959159.slice/cri-containerd-4d3a574049036e108c56dfd4fcf852ee3f84eb947281e80ac5a989e1ab3d5f23.scope"
      },
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcddc43e_6a35_43cf_8cfb_4c5265959159.slice/cri-containerd-a4f0f3d318744eb9e77a3203610328e5787ffb84174187e59ea09a5f512fd11c.scope"
      }
    ],
    "ips": [
      "10.115.0.142"
    ],
    "name": "echo-same-node-86d9cc975c-tvgqq",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39ee150f_d6b3_4df2_bcfc_905a714cd7f6.slice/cri-containerd-9307c335636790af87df1a37348aa96a8b76cfb5f64150d121cad2b64b4eb452.scope"
      }
    ],
    "ips": [
      "10.115.0.140"
    ],
    "name": "client2-57cf4468f-5zsbz",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3bd38445_6852_49d6_978e_7cea68664d4b.slice/cri-containerd-cde0f6815aa84d1c56b2db35b98ad1f62092276a7c96ea6cf2878a45dd0d5919.scope"
      }
    ],
    "ips": [
      "10.115.0.238"
    ],
    "name": "client-974f6c69d-nh72m",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a55872e_b61d_47dd_ab24_8cbe5947cb47.slice/cri-containerd-cf42d450de50b1764c005c2c6dcee1572c7860bf67f61e60c4ff7e8f12ad14a6.scope"
      },
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a55872e_b61d_47dd_ab24_8cbe5947cb47.slice/cri-containerd-db01358904316293b74b5d94f4d95d2f8587c62f5b2ffd37f5acaf5ed65dac7d.scope"
      },
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a55872e_b61d_47dd_ab24_8cbe5947cb47.slice/cri-containerd-2157aacd93f530337c9f59dd4cddc9803fee151435cf90af3eec74b777593a41.scope"
      }
    ],
    "ips": [
      "10.115.0.37"
    ],
    "name": "clustermesh-apiserver-c88945ffb-6g9m4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7625,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbeb08c1b_6e88_4c99_a5a7_29dd87d7399d.slice/cri-containerd-4d8306031a20bf784d5e5369e7b5ca88e7776713b544e6a0bc7687c828341168.scope"
      }
    ],
    "ips": [
      "10.115.0.159"
    ],
    "name": "coredns-cc6ccd49c-jjrwt",
    "namespace": "kube-system"
  }
]

