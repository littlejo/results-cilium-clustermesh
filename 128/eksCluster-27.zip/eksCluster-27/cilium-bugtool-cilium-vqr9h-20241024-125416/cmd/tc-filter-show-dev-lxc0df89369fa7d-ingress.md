filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc0df89369fa7d direct-action not_in_hw id 3350 tag e543961a6a62f822 jited 
