 12:54:17 up 33 min,  0 users,  load average: 1.56, 0.87, 0.42
