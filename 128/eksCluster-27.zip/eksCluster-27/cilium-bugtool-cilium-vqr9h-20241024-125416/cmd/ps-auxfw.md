USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3301  0.0  0.4 1240176 16328 ?       Dsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3324  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3326  0.0  0.4 1240176 16328 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  3.4  7.3 1539060 289288 ?      Ssl  12:26   0:57 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.2  0.2 1229744 9832 ?        Sl   12:26   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
