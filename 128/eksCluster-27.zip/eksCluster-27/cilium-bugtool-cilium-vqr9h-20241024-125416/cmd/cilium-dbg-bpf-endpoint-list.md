IP ADDRESS         LOCAL ENDPOINT INFO
10.27.0.71:0       id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08   
10.27.0.244:0      id=1434  sec_id=1835026 flags=0x0000 ifindex=18  mac=2E:3F:E9:65:26:82 nodemac=2A:11:EF:94:29:08   
10.27.0.55:0       id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6   
172.31.229.65:0    (localhost)                                                                                        
10.27.0.24:0       id=3461  sec_id=1864520 flags=0x0000 ifindex=12  mac=66:64:2F:15:C8:08 nodemac=02:C8:91:23:FC:A3   
10.27.0.211:0      id=2510  sec_id=1864520 flags=0x0000 ifindex=14  mac=D2:9C:87:25:98:E2 nodemac=1A:07:29:31:79:05   
10.27.0.70:0       id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC   
10.27.0.98:0       id=982   sec_id=4     flags=0x0000 ifindex=10  mac=06:05:3E:F6:B0:03 nodemac=1E:77:EF:29:AE:CC     
172.31.203.123:0   (localhost)                                                                                        
10.27.0.137:0      (localhost)                                                                                        
