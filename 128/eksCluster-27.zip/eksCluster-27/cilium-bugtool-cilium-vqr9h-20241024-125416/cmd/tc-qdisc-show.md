qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc23f033ffba0e root refcnt 2 
qdisc clsact ffff: dev lxc23f033ffba0e parent ffff:fff1 
qdisc noqueue 0: dev lxc31feb1375481 root refcnt 2 
qdisc clsact ffff: dev lxc31feb1375481 parent ffff:fff1 
qdisc noqueue 0: dev lxc7751fc7888c0 root refcnt 2 
qdisc clsact ffff: dev lxc7751fc7888c0 parent ffff:fff1 
qdisc noqueue 0: dev lxc3fcb11f17f74 root refcnt 2 
qdisc clsact ffff: dev lxc3fcb11f17f74 parent ffff:fff1 
qdisc noqueue 0: dev lxcc978767007fb root refcnt 2 
qdisc clsact ffff: dev lxcc978767007fb parent ffff:fff1 
qdisc noqueue 0: dev lxc0df89369fa7d root refcnt 2 
qdisc clsact ffff: dev lxc0df89369fa7d parent ffff:fff1 
