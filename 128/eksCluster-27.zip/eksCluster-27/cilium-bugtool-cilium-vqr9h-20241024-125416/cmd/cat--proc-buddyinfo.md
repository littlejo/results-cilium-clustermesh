Node 0, zone      DMA    206    154     17      9      6      7      3      3      1      2     41 
Node 0, zone   Normal    132      5      1      5     17      9      2      3      3      1      8 
