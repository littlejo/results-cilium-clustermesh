xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 587
ens6(5) clsact/ingress cil_from_netdev-ens6 id 588
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 575
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 570
cilium_host(7) clsact/egress cil_from_host-cilium_host id 571
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 503
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 500
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 547
lxc23f033ffba0e(12) clsact/ingress cil_from_container-lxc23f033ffba0e id 530
lxc31feb1375481(14) clsact/ingress cil_from_container-lxc31feb1375481 id 558
lxc7751fc7888c0(18) clsact/ingress cil_from_container-lxc7751fc7888c0 id 635
lxc3fcb11f17f74(20) clsact/ingress cil_from_container-lxc3fcb11f17f74 id 3286
lxcc978767007fb(22) clsact/ingress cil_from_container-lxcc978767007fb id 3331
lxc0df89369fa7d(24) clsact/ingress cil_from_container-lxc0df89369fa7d id 3350

flow_dissector:

netfilter:

