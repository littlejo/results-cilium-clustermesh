1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:64:c1:db:43:25 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.229.65/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3418sec preferred_lft 3418sec
    inet6 fe80::864:c1ff:fedb:4325/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9f:24:85:f2:7f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.203.123/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::89f:24ff:fe85:f27f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:8d:76:67:0d:4f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fc8d:76ff:fe67:d4f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:51:07:4c:c8:f6 brd ff:ff:ff:ff:ff:ff
    inet 10.27.0.137/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9051:7ff:fe4c:c8f6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7a:c7:d4:62:1b:e6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::78c7:d4ff:fe62:1be6/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:77:ef:29:ae:cc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1c77:efff:fe29:aecc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc23f033ffba0e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:c8:91:23:fc:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c8:91ff:fe23:fca3/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc31feb1375481@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:07:29:31:79:05 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1807:29ff:fe31:7905/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7751fc7888c0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:11:ef:94:29:08 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2811:efff:fe94:2908/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc3fcb11f17f74@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:f7:e6:12:e0:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::60f7:e6ff:fe12:e0b6/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcc978767007fb@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:ae:1d:2f:bf:08 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::a0ae:1dff:fe2f:bf08/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc0df89369fa7d@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:82:6a:84:35:dc brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::bc82:6aff:fe84:35dc/64 scope link 
       valid_lft forever preferred_lft forever
