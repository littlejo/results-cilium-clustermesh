[
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1cabc53_4e0f_4f11_b450_a5108f3ee3bd.slice/cri-containerd-ccdc5e6b1a97ada1cdf3b83b1326d48c0832ccf7540f75b0cb49567eabe154c6.scope"
      }
    ],
    "ips": [
      "10.27.0.70"
    ],
    "name": "client2-57cf4468f-q8pkh",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7493,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cdf9898_c7a4_4ee5_8271_11377489d57e.slice/cri-containerd-e9921b09dd85bb1d8c98922c0f6d57e63ca5893da2ac6d4414d51748789926d7.scope"
      }
    ],
    "ips": [
      "10.27.0.24"
    ],
    "name": "coredns-cc6ccd49c-zhcdn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62a5aee6_5f97_4d8f_b900_b17c08c27991.slice/cri-containerd-fc953648be4ba623fed7bb682ff049647d6d3b960e6e68f3adff4e728491803d.scope"
      }
    ],
    "ips": [
      "10.27.0.71"
    ],
    "name": "client-974f6c69d-96dt6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ac318c0_330a_4880_b0bf_92b666f0d9f1.slice/cri-containerd-5cd61ebb790d9a8130f8c1dc519167fd446cb3557d62215f85dc3066830b42eb.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ac318c0_330a_4880_b0bf_92b666f0d9f1.slice/cri-containerd-ac59ffe91dc0eac80d61c8f0d38bbc7e4b1cd7f1e7295cdf670dfbcc8657e4db.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ac318c0_330a_4880_b0bf_92b666f0d9f1.slice/cri-containerd-7393370723ce31185b024028af9ece9f2cac81d675f7fa7215bc536551291caa.scope"
      }
    ],
    "ips": [
      "10.27.0.244"
    ],
    "name": "clustermesh-apiserver-69f4f57477-5n8q2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef172f9_d7f4_4480_94b4_769c87c7b5cf.slice/cri-containerd-b52fcdaf61a02d9619fa118dc5e4e63e587fbf62cb8f1842c4dfa7e889d0f3c5.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef172f9_d7f4_4480_94b4_769c87c7b5cf.slice/cri-containerd-e09a10b8fbdfcf18a9a45093d53b6b04522d46bc99a01a71976fa18baf8bd516.scope"
      }
    ],
    "ips": [
      "10.27.0.55"
    ],
    "name": "echo-same-node-86d9cc975c-qhw99",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod572321c3_93f2_4b7b_82ba_e8469e36d35e.slice/cri-containerd-54ea45a2489671d26658e59acabb05c8cfabf05af5d7e234506e4b967b36c463.scope"
      }
    ],
    "ips": [
      "10.27.0.211"
    ],
    "name": "coredns-cc6ccd49c-kzwt6",
    "namespace": "kube-system"
  }
]

