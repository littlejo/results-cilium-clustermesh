filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc978767007fb direct-action not_in_hw id 3331 tag 26340095d5858fef jited 
