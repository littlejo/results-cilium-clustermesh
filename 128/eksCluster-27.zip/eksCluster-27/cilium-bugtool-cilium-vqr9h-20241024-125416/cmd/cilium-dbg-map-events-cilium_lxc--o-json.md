{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.376Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.915Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.919Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.958Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.996Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.018Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.248Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.251Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.307Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.314Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.358Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.917Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.920Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.962Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.972Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.007Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.028Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.045Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.288Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.293Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.359Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.364Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.398Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.955Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.957Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.078Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.081Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.114Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.316Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.320Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.370Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.376Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.418Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.969Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.976Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.998Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.027Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.051Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.072Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.099Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.321Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.327Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.369Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.390Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.406Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.873Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.879Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.918Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.937Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.959Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.226Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.235Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.282Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.296Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.324Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.722Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.771Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.784Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.819Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.830Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.858Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.066Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.075Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.122Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.127Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.174Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.565Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.600Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.603Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.645Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.651Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.680Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.963Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.977Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.065Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.065Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.081Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.471Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.495Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.516Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.552Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.552Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.554Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.802Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.821Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.867Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.880Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.903Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.293Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.338Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.343Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.388Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.390Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.421Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.662Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.691Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.734Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.741Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.777Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.020Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.123Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.124Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.211Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.215Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.246Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.457Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.468Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.522Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.545Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.566Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.884Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.888Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.937Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.942Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.972Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.230Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.230Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.250Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.292Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.942Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.945Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.974Z",
  "value": "id=26    sec_id=1892300 flags=0x0000 ifindex=20  mac=6A:A6:E5:7A:D8:30 nodemac=62:F7:E6:12:E0:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.989Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.011Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.288Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.291Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.941Z",
  "value": "id=2444  sec_id=1893430 flags=0x0000 ifindex=22  mac=D6:D1:5B:FB:54:C8 nodemac=A2:AE:1D:2F:BF:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.950Z",
  "value": "id=2398  sec_id=1846590 flags=0x0000 ifindex=24  mac=BA:8A:C2:6E:2B:48 nodemac=BE:82:6A:84:35:DC"
}

