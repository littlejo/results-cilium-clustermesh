markdown output at /tmp/cilium-bugtool-20241024-125417.719+0000-UTC-579562138/cmd/cilium-debuginfo-20241024-125448.683+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.719+0000-UTC-579562138/cmd/cilium-debuginfo-20241024-125448.683+0000-UTC.json
