filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc23f033ffba0e direct-action not_in_hw id 530 tag 8d0731526fb75c9e jited 
