CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod572321c3_93f2_4b7b_82ba_e8469e36d35e.slice/cri-containerd-54ea45a2489671d26658e59acabb05c8cfabf05af5d7e234506e4b967b36c463.scope
    566      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod572321c3_93f2_4b7b_82ba_e8469e36d35e.slice/cri-containerd-69ba00d07100b441162ecab1fd94f0ed37a4d1a71af41fcf9023eecc6548a63e.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6595cf5e_afc3_4a53_a3e4_fe2e3d7a421e.slice/cri-containerd-32954a0cffccae565327f6ecaf9a44cd50e427b8d86edfd33669154541339e71.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6595cf5e_afc3_4a53_a3e4_fe2e3d7a421e.slice/cri-containerd-05ddbaee97cb66e62880b53900edc88737aac085f3fcfdf5d69ea30094e1bb0b.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcaed0f70_f7b8_492a_ae4f_60cf9726116f.slice/cri-containerd-83c5fbb213d2d8c9200c160687e07fa1f089c938432c521cf1f4aa1202586121.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcaed0f70_f7b8_492a_ae4f_60cf9726116f.slice/cri-containerd-10c855a2aa8393526904bba332701932d2641b615a8e0e94f58c5acd04300441.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cdf9898_c7a4_4ee5_8271_11377489d57e.slice/cri-containerd-bba1e7e90c2d4695cf5671a5381ba5e87162bba6372baafb3d8c96527eddeef4.scope
    495      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cdf9898_c7a4_4ee5_8271_11377489d57e.slice/cri-containerd-e9921b09dd85bb1d8c98922c0f6d57e63ca5893da2ac6d4414d51748789926d7.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ac318c0_330a_4880_b0bf_92b666f0d9f1.slice/cri-containerd-81f23adea400bd8fdeddb6f4b0972e232ed3313ec519b96b1a800c8f7e3b7f33.scope
    648      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ac318c0_330a_4880_b0bf_92b666f0d9f1.slice/cri-containerd-7393370723ce31185b024028af9ece9f2cac81d675f7fa7215bc536551291caa.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ac318c0_330a_4880_b0bf_92b666f0d9f1.slice/cri-containerd-ac59ffe91dc0eac80d61c8f0d38bbc7e4b1cd7f1e7295cdf670dfbcc8657e4db.scope
    672      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ac318c0_330a_4880_b0bf_92b666f0d9f1.slice/cri-containerd-5cd61ebb790d9a8130f8c1dc519167fd446cb3557d62215f85dc3066830b42eb.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1cabc53_4e0f_4f11_b450_a5108f3ee3bd.slice/cri-containerd-ccdc5e6b1a97ada1cdf3b83b1326d48c0832ccf7540f75b0cb49567eabe154c6.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1cabc53_4e0f_4f11_b450_a5108f3ee3bd.slice/cri-containerd-ac4c951036f277bc4cbb6075b9d5ecd96eba9da11dec28cee39213de669d0753.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c1256cb_8454_4690_87fe_aa41b85a997f.slice/cri-containerd-e6143c699f52571197916103d77610bc34d28d17ecf59763f79e0bbae0cdc32d.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c1256cb_8454_4690_87fe_aa41b85a997f.slice/cri-containerd-4f14083cead872f3afdab1f120b463fee63897a62f8585dad95ae9e8abea1077.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod158b3d05_020f_4899_92fb_9b871746ca46.slice/cri-containerd-94151600790ce68ee5d68bf13c28ffc7d010d12d55062afb145a5ea98123e5db.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod158b3d05_020f_4899_92fb_9b871746ca46.slice/cri-containerd-f48fe7d3b3a8779efd123f977edcbe005d7e33e0ecbe225994f6774686f9056e.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62a5aee6_5f97_4d8f_b900_b17c08c27991.slice/cri-containerd-a368ed6bd0b95435bcd6087cc652ea5d4192ddb8c5319166fd4c4be91441e871.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62a5aee6_5f97_4d8f_b900_b17c08c27991.slice/cri-containerd-fc953648be4ba623fed7bb682ff049647d6d3b960e6e68f3adff4e728491803d.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef172f9_d7f4_4480_94b4_769c87c7b5cf.slice/cri-containerd-b52fcdaf61a02d9619fa118dc5e4e63e587fbf62cb8f1842c4dfa7e889d0f3c5.scope
    729      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef172f9_d7f4_4480_94b4_769c87c7b5cf.slice/cri-containerd-e09a10b8fbdfcf18a9a45093d53b6b04522d46bc99a01a71976fa18baf8bd516.scope
    733      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef172f9_d7f4_4480_94b4_769c87c7b5cf.slice/cri-containerd-cdb53fd228aace70726ee5e09222b974a85091ddc1d0408ab49f82455bfa0b86.scope
    698      cgroup_device   multi                                          
