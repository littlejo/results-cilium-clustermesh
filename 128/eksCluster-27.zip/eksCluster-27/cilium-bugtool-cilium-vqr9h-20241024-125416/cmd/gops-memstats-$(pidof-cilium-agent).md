alloc: 97.85MB (102606136 bytes)
total-alloc: 3.14GB (3370611328 bytes)
sys: 215.32MB (225781076 bytes)
lookups: 0
mallocs: 75975367
frees: 75006124
heap-alloc: 97.85MB (102606136 bytes)
heap-sys: 168.51MB (176693248 bytes)
heap-idle: 43.72MB (45842432 bytes)
heap-in-use: 124.79MB (130850816 bytes)
heap-released: 3.98MB (4169728 bytes)
heap-objects: 969243
stack-in-use: 35.47MB (37191680 bytes)
stack-sys: 35.47MB (37191680 bytes)
stack-mspan-inuse: 2.08MB (2176160 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1009.88KB (1034113 bytes)
gc-sys: 5.50MB (5766240 bytes)
next-gc: when heap-alloc >= 151.29MB (158636216 bytes)
last-gc: 2024-10-24 12:54:26.671422718 +0000 UTC
gc-pause-total: 17.70234ms
gc-pause: 63039
gc-pause-end: 1729774466671422718
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.000537766013097836
enable-gc: true
debug-gc: false
