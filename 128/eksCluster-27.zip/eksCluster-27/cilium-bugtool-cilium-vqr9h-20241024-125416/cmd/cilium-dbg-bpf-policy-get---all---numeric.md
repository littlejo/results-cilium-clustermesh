Endpoint ID: 26
Path: /sys/fs/bpf/tc/globals/cilium_policy_00026

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376676   4402      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 982
Path: /sys/fs/bpf/tc/globals/cilium_policy_00982

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6215052   76958     0        
Allow    Ingress     1          ANY          NONE         disabled    70530     854       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1434
Path: /sys/fs/bpf/tc/globals/cilium_policy_01434

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6134694   61381     0        
Allow    Ingress     1          ANY          NONE         disabled    5063528   53194     0        
Allow    Egress      0          ANY          NONE         disabled    6420816   63908     0        


Endpoint ID: 2152
Path: /sys/fs/bpf/tc/globals/cilium_policy_02152

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2398
Path: /sys/fs/bpf/tc/globals/cilium_policy_02398

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2444
Path: /sys/fs/bpf/tc/globals/cilium_policy_02444

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2510
Path: /sys/fs/bpf/tc/globals/cilium_policy_02510

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2330     26        0        
Allow    Ingress     1          ANY          NONE         disabled    162016   1862      0        
Allow    Egress      0          ANY          NONE         disabled    21279    238       0        


Endpoint ID: 3461
Path: /sys/fs/bpf/tc/globals/cilium_policy_03461

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3566     34        0        
Allow    Ingress     1          ANY          NONE         disabled    162285   1871      0        
Allow    Egress      0          ANY          NONE         disabled    20601    230       0        


