key: 1a 00 00 00  value: d5 0c 00 00
key: d6 03 00 00  value: 20 02 00 00
key: 9a 05 00 00  value: 83 02 00 00
key: 5e 09 00 00  value: 06 0d 00 00
key: 8c 09 00 00  value: 08 0d 00 00
key: ce 09 00 00  value: 29 02 00 00
key: 85 0d 00 00  value: 10 02 00 00
Found 7 elements
