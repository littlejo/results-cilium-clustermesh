top - 12:54:17 up 33 min,  0 users,  load average: 1.56, 0.87, 0.42
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.8 us, 38.7 sy,  0.0 ni, 35.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    299.2 free,   1038.4 used,   2498.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2616.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 292204  80636 S   0.0   7.4   0:57.67 cilium-+
    396 root      20   0 1229744   9832   3836 S   0.0   0.3   0:03.64 cilium-+
   3301 root      20   0 1240432  16768  11612 S   0.0   0.4   0:00.02 cilium-+
   3342 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3343 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3344 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3396 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
