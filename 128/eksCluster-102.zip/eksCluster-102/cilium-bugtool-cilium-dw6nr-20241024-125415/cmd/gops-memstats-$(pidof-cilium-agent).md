alloc: 120.94MB (126813424 bytes)
total-alloc: 3.15GB (3385534880 bytes)
sys: 219.07MB (229713236 bytes)
lookups: 0
mallocs: 76263132
frees: 75064402
heap-alloc: 120.94MB (126813424 bytes)
heap-sys: 172.64MB (181026816 bytes)
heap-idle: 27.50MB (28835840 bytes)
heap-in-use: 145.14MB (152190976 bytes)
heap-released: 4.15MB (4349952 bytes)
heap-objects: 1198730
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.26MB (2374880 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 745.53KB (763425 bytes)
gc-sys: 5.54MB (5809296 bytes)
next-gc: when heap-alloc >= 149.86MB (157141896 bytes)
last-gc: 2024-10-24 12:54:17.623438206 +0000 UTC
gc-pause-total: 14.659532ms
gc-pause: 95420
gc-pause-end: 1729774457623438206
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006651040152755529
enable-gc: true
debug-gc: false
