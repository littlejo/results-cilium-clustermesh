Endpoint ID: 111
Path: /sys/fs/bpf/tc/globals/cilium_policy_00111

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 670
Path: /sys/fs/bpf/tc/globals/cilium_policy_00670

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1216
Path: /sys/fs/bpf/tc/globals/cilium_policy_01216

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3722     37        0        
Allow    Ingress     1          ANY          NONE         disabled    129976   1490      0        
Allow    Egress      0          ANY          NONE         disabled    19433    214       0        


Endpoint ID: 1858
Path: /sys/fs/bpf/tc/globals/cilium_policy_01858

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2248
Path: /sys/fs/bpf/tc/globals/cilium_policy_02248

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6029617   61171     0        
Allow    Ingress     1          ANY          NONE         disabled    5949324   63123     0        
Allow    Egress      0          ANY          NONE         disabled    7651550   74748     0        


Endpoint ID: 2593
Path: /sys/fs/bpf/tc/globals/cilium_policy_02593

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2174     23        0        
Allow    Ingress     1          ANY          NONE         disabled    130237   1498      0        
Allow    Egress      0          ANY          NONE         disabled    18233    200       0        


Endpoint ID: 3022
Path: /sys/fs/bpf/tc/globals/cilium_policy_03022

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376973   4387      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3295
Path: /sys/fs/bpf/tc/globals/cilium_policy_03295

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6246690   77096     0        
Allow    Ingress     1          ANY          NONE         disabled    64565     782       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


