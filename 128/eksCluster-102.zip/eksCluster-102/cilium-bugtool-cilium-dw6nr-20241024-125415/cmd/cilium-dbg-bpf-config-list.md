KEY             VALUE
AgentLiveness   1904242190262
UTimeOffset     3378462076171875
