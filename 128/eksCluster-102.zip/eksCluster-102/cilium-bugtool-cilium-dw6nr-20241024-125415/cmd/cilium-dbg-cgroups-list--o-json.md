[
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4336fcb_f2c0_4ddd_98c8_99c903d859ad.slice/cri-containerd-784380b52547b5fbc035ed633ca3accb1df987462329fba2143718b72011da76.scope"
      }
    ],
    "ips": [
      "10.102.0.10"
    ],
    "name": "client2-57cf4468f-c7x9z",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bd7a1d1_06f5_4d7c_9db0_d4b6ec794867.slice/cri-containerd-8714ff6c6543031b69f1e48af56f1c5a3b66f48d970427ccac3e6535e9bd46d3.scope"
      },
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bd7a1d1_06f5_4d7c_9db0_d4b6ec794867.slice/cri-containerd-9d962ead4c5651d0b49c3446248a5c03a444dbdc7cbe220e4185e199d46a6f9b.scope"
      }
    ],
    "ips": [
      "10.102.0.169"
    ],
    "name": "echo-same-node-86d9cc975c-n9hmd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb86af7f4_e33a_46d1_be6f_4567d77b9380.slice/cri-containerd-3b9222507c1feb0c3206b59437bd8071d6618f22fc3d3699803cff1e8bbac84c.scope"
      }
    ],
    "ips": [
      "10.102.0.192"
    ],
    "name": "coredns-cc6ccd49c-z8q5k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ef1604f_7666_4f4f_a417_6f2f2d37c2b6.slice/cri-containerd-a75c70451bfb9c3489f578b96bd7a8e70e12c7e71fe1ccdd0f61c2483a5360dd.scope"
      }
    ],
    "ips": [
      "10.102.0.193"
    ],
    "name": "client-974f6c69d-zdpxw",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41540214_37f0_4c17_92f4_ac7a1fd00e10.slice/cri-containerd-065be5fd424830f78b1866b0a32fd9d1f0cfabcafe482e895d8d52b8f5fb2cd2.scope"
      },
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41540214_37f0_4c17_92f4_ac7a1fd00e10.slice/cri-containerd-df8a0fabf21caea44518785e5fdd358bfc83a5214a3e3a51ab7f23c91d96fb0c.scope"
      },
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41540214_37f0_4c17_92f4_ac7a1fd00e10.slice/cri-containerd-62c82ebacb839627a02205638d370f0197417e0a66a219601e4c67675f1b3865.scope"
      }
    ],
    "ips": [
      "10.102.0.201"
    ],
    "name": "clustermesh-apiserver-d9b9d544d-5btfj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d84c22c_02ed_48f1_9419_6e392f5e5c07.slice/cri-containerd-d80bf116b193b70e960633ac0a9b2d51029aabf9f0a7d1482b8c3eb4881b8d48.scope"
      }
    ],
    "ips": [
      "10.102.0.21"
    ],
    "name": "coredns-cc6ccd49c-qdv66",
    "namespace": "kube-system"
  }
]

