Node 0, zone      DMA    141    107      3     26      8      4      4      5      1      2     37 
Node 0, zone   Normal    214     23      2      2      2      2      2      6      3      3      7 
