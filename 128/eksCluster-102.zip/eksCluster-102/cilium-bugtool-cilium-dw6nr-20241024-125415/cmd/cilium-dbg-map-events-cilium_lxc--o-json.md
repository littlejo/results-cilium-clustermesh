{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.858Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.885Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.428Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.433Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.483Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.492Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.533Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.755Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.764Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.875Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.878Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.964Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.384Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.387Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.428Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.442Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.474Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.498Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.512Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.748Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.749Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.809Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.867Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.880Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.457Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.469Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.514Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.523Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.553Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.778Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.803Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.858Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.866Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.898Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.451Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.484Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.524Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.558Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.594Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.620Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.809Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.814Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.861Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.871Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.911Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.334Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.339Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.384Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.423Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.433Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.680Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.698Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.749Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.754Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.788Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.171Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.226Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.271Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.333Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.359Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.382Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.600Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.617Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.647Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.679Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.702Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.094Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.152Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.160Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.209Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.216Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.258Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.464Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.484Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.531Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.554Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.577Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.947Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.975Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.994Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.033Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.048Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.079Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.348Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.353Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.397Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.444Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.446Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.839Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.874Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.878Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.931Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.938Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.973Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.193Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.201Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.251Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.264Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.311Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.627Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.637Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.686Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.705Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.728Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.980Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.994Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.093Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.106Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.140Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.361Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.413Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.425Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.468Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.474Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.503Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.733Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.755Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.760Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.787Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.464Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.467Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.496Z",
  "value": "id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.539Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.545Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.822Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.833Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.501Z",
  "value": "id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.506Z",
  "value": "id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC"
}

