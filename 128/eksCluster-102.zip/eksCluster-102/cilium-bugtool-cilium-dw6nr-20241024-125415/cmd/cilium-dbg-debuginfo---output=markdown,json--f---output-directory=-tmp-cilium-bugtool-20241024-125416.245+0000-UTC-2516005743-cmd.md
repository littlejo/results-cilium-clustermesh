markdown output at /tmp/cilium-bugtool-20241024-125416.245+0000-UTC-2516005743/cmd/cilium-debuginfo-20241024-125446.982+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.245+0000-UTC-2516005743/cmd/cilium-debuginfo-20241024-125446.982+0000-UTC.json
