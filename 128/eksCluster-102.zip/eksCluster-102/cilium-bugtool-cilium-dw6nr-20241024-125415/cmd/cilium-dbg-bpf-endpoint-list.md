IP ADDRESS        LOCAL ENDPOINT INFO
172.31.176.47:0   (localhost)                                                                                        
10.102.0.193:0    id=670   sec_id=6810250 flags=0x0000 ifindex=20  mac=7E:11:A3:1E:0A:65 nodemac=B2:5F:06:08:51:73   
10.102.0.53:0     (localhost)                                                                                        
10.102.0.10:0     id=1858  sec_id=6791911 flags=0x0000 ifindex=22  mac=3A:C6:CF:80:6B:70 nodemac=F6:00:9F:8F:4C:CC   
10.102.0.192:0    id=1216  sec_id=6751093 flags=0x0000 ifindex=12  mac=22:54:79:67:BA:A7 nodemac=62:1E:42:75:F2:4B   
10.102.0.21:0     id=2593  sec_id=6751093 flags=0x0000 ifindex=14  mac=32:0C:DE:A5:12:B4 nodemac=CA:AC:FC:42:3C:6E   
10.102.0.201:0    id=2248  sec_id=6775552 flags=0x0000 ifindex=18  mac=1E:8C:CD:6A:D5:3E nodemac=46:5E:7A:BA:27:5D   
10.102.0.170:0    id=3295  sec_id=4     flags=0x0000 ifindex=10  mac=FA:CB:E9:82:6F:2A nodemac=82:97:45:6C:B1:AB     
10.102.0.169:0    id=3022  sec_id=6760200 flags=0x0000 ifindex=24  mac=6A:BB:E8:51:5E:7D nodemac=16:D0:0F:FA:67:6F   
172.31.144.47:0   (localhost)                                                                                        
