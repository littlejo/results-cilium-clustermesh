xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 507
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 497
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 488
cilium_host(7) clsact/egress cil_from_host-cilium_host id 489
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 555
lxc1c2b7beb47cd(12) clsact/ingress cil_from_container-lxc1c2b7beb47cd id 523
lxc076ae76f9546(14) clsact/ingress cil_from_container-lxc076ae76f9546 id 559
lxc44e232316f3a(18) clsact/ingress cil_from_container-lxc44e232316f3a id 616
lxc26068b8d6cd4(20) clsact/ingress cil_from_container-lxc26068b8d6cd4 id 3342
lxc5a2b91a8f000(22) clsact/ingress cil_from_container-lxc5a2b91a8f000 id 3349
lxc9e2bd774a859(24) clsact/ingress cil_from_container-lxc9e2bd774a859 id 3278

flow_dissector:

netfilter:

