USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3291  0.0  0.4 1240176 16036 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3305  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3308  0.0  0.0   3852  1292 ?        R    12:54   0:00  \_ bash -c ip a
root        3253  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3252  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3250  0.0  0.0 1228744 3716 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3249  0.0  0.0 1228744 3660 ?        Ssl  12:54   0:00 /bin/gops stats 1
root           1  4.9  7.2 1538804 286652 ?      Ssl  12:31   1:06 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.3  0.2 1229744 9912 ?        Sl   12:31   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
