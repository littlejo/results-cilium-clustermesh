top - 12:54:16 up 31 min,  0 users,  load average: 0.32, 0.47, 0.27
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.7 us, 24.1 sy,  0.0 ni, 55.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    288.3 free,   1049.9 used,   2498.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2605.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 286652  78208 S   6.7   7.3   1:06.97 cilium-+
    395 root      20   0 1229744   9912   3840 S   0.0   0.3   0:04.40 cilium-+
   3249 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3250 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
   3252 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3253 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3291 root      20   0 1240432  16036  11292 S   0.0   0.4   0:00.02 cilium-+
   3317 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3335 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
