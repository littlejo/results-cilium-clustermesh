key: 9e 02 00 00  value: 16 0d 00 00
key: c0 04 00 00  value: 13 02 00 00
key: 42 07 00 00  value: 17 0d 00 00
key: c8 08 00 00  value: 6d 02 00 00
key: 21 0a 00 00  value: 1f 02 00 00
key: ce 0b 00 00  value: d9 0c 00 00
key: df 0c 00 00  value: 20 02 00 00
Found 7 elements
