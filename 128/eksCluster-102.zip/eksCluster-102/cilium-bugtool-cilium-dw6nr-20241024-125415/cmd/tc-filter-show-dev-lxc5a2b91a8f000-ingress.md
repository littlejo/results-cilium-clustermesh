filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5a2b91a8f000 direct-action not_in_hw id 3349 tag 4536e27c2b9cb27d jited 
