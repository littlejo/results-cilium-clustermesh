CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb86af7f4_e33a_46d1_be6f_4567d77b9380.slice/cri-containerd-608e5f0485eb813dd02bbff6f5f24c47c1a9223c52fb6569318789cfa170bdda.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb86af7f4_e33a_46d1_be6f_4567d77b9380.slice/cri-containerd-3b9222507c1feb0c3206b59437bd8071d6618f22fc3d3699803cff1e8bbac84c.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99e7b944_f078_4720_abdd_bd8cad01c27a.slice/cri-containerd-0c0447ac50742beed83c3c6e0c8cc0984149904650bc7012ff55c39dee523bd9.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99e7b944_f078_4720_abdd_bd8cad01c27a.slice/cri-containerd-9ca4be03533355a4ced944c621eea508e0d8eee20e7f798b549291c5008cd4c8.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod987da59d_e596_455f_8754_b5320b54fc8a.slice/cri-containerd-1607d8fbf4f184ea2c77040731aff2aaf1a64e72ffa3ad5bf060511bac8ae6e8.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod987da59d_e596_455f_8754_b5320b54fc8a.slice/cri-containerd-30f16f7491ec025e31b064de2326bf45e6e70e36ee2b1c23abb0fc1f95103fa7.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d84c22c_02ed_48f1_9419_6e392f5e5c07.slice/cri-containerd-d80bf116b193b70e960633ac0a9b2d51029aabf9f0a7d1482b8c3eb4881b8d48.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d84c22c_02ed_48f1_9419_6e392f5e5c07.slice/cri-containerd-f3902b57a8d7efd7a7d4f9e345f8a5e35465b03b6db12b65c9148408bf41bead.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cbf8659_29dc_4e6a_b731_3868739a6b3f.slice/cri-containerd-8da7643a19292f582ab1229a49cdbe45938b769d728148135d81f7ff1bd23767.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cbf8659_29dc_4e6a_b731_3868739a6b3f.slice/cri-containerd-d3ba1187ac08edae783971e0537f67046c3cb25afc14c3e17ebc3bc28b1fd3a1.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4336fcb_f2c0_4ddd_98c8_99c903d859ad.slice/cri-containerd-cbf62f93be114e73ed3231f8dd2332bc1a3252d62980e022646bf1ce5f38b1d6.scope
    683      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4336fcb_f2c0_4ddd_98c8_99c903d859ad.slice/cri-containerd-784380b52547b5fbc035ed633ca3accb1df987462329fba2143718b72011da76.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bd7a1d1_06f5_4d7c_9db0_d4b6ec794867.slice/cri-containerd-9d962ead4c5651d0b49c3446248a5c03a444dbdc7cbe220e4185e199d46a6f9b.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bd7a1d1_06f5_4d7c_9db0_d4b6ec794867.slice/cri-containerd-8714ff6c6543031b69f1e48af56f1c5a3b66f48d970427ccac3e6535e9bd46d3.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bd7a1d1_06f5_4d7c_9db0_d4b6ec794867.slice/cri-containerd-80f41427dbc6d7a567c5e3dd3b2138e9ab99fd063eebd4ae3e12c3384eed30e0.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c6b7da9_c72b_4f65_963d_ec5306deaa96.slice/cri-containerd-a52e9d026e93758191f806ecd18a373d5c7aa52cf855356c2cb8a5d599f6d582.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c6b7da9_c72b_4f65_963d_ec5306deaa96.slice/cri-containerd-f345a818c13d70cc6b2078574f2c8d22d90fa541bdf3c8fea5ec93b405003d61.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41540214_37f0_4c17_92f4_ac7a1fd00e10.slice/cri-containerd-2f98b0f3ad14a0729e0d74224e5c17ce170b3e86267c3da5cf480c872714d8a4.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41540214_37f0_4c17_92f4_ac7a1fd00e10.slice/cri-containerd-62c82ebacb839627a02205638d370f0197417e0a66a219601e4c67675f1b3865.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41540214_37f0_4c17_92f4_ac7a1fd00e10.slice/cri-containerd-065be5fd424830f78b1866b0a32fd9d1f0cfabcafe482e895d8d52b8f5fb2cd2.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41540214_37f0_4c17_92f4_ac7a1fd00e10.slice/cri-containerd-df8a0fabf21caea44518785e5fdd358bfc83a5214a3e3a51ab7f23c91d96fb0c.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ef1604f_7666_4f4f_a417_6f2f2d37c2b6.slice/cri-containerd-a75c70451bfb9c3489f578b96bd7a8e70e12c7e71fe1ccdd0f61c2483a5360dd.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ef1604f_7666_4f4f_a417_6f2f2d37c2b6.slice/cri-containerd-737f9ebbcdb17d1046b2ec7129a7fc0052cda14d5fcc3346ca538fffe8222bf4.scope
    679      cgroup_device   multi                                          
