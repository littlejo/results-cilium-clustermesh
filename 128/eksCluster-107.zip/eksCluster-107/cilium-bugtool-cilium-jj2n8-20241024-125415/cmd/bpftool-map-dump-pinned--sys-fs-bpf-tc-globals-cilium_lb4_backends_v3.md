key: 0c 00 00 00  value: 0a 6b 00 d8 1f 90 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 6b 00 2e 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 6b 00 f2 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 6b 00 2e 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f da c6 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 6b 00 eb 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d9 02 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 6b 00 f2 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b2 b8 01 bb 00 00  00 00 00 00
Found 9 elements
