CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef9c56e0_74c3_49c7_95bd_28574120ed1c.slice/cri-containerd-bba8acf9c757dc48a93f3125f269b69a74b91f38fd2b8981d9cd1c943d3c1b3b.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef9c56e0_74c3_49c7_95bd_28574120ed1c.slice/cri-containerd-62132e536d731be8387d8ad657c279742a1680b3b389b1fa825c7c73e2f44127.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc13b5b93_f792_493f_bce3_5b613881eb46.slice/cri-containerd-8d656fe762676b8d308c635c7cf0998d4548994c396ba387355cc97bb3765bd5.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc13b5b93_f792_493f_bce3_5b613881eb46.slice/cri-containerd-17b6f0bebacc3dec62f7b9ca5e5b47443e0bfdf371f5ad480a1c1627e4f5d190.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03ceadc4_21a8_4e8f_aa73_d3bd735ba001.slice/cri-containerd-b73cfe414df58dab273717b6b2ca33f6987292f796e4b543950df32167c662ab.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03ceadc4_21a8_4e8f_aa73_d3bd735ba001.slice/cri-containerd-5e3739654a1d5eef7ccbdcafc4856287e085514de0af04b7fe94e063fc59ffdb.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod77737177_61f9_4f6e_9e85_43dc77f4d0b3.slice/cri-containerd-98d3e9fd5a4ae831b0fa14ba93caa84432b780d4dd2f8491202b793b5e18c470.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod77737177_61f9_4f6e_9e85_43dc77f4d0b3.slice/cri-containerd-5f8340bfa103e55266a36c070f7f4f9c703b504a3b61e3fd5885f09db1934498.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd20e6c86_70cc_4b2b_bbef_f75f04c5d973.slice/cri-containerd-6f73f923f5f6e1b78cd064fda7f8a82fe74a1451ae645abdf2502aebe442fc78.scope
    696      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd20e6c86_70cc_4b2b_bbef_f75f04c5d973.slice/cri-containerd-be63d8dbdc82ae503c5eac8ce6678eb246cfe73f02497eac28b97e51b571e116.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4fe449dd_5701_488e_a1b6_a4b242b6e284.slice/cri-containerd-f894ba1241d7250a1afa55b9aa5347f894e3a64037c6830d96e8ade6a3ddc1f5.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4fe449dd_5701_488e_a1b6_a4b242b6e284.slice/cri-containerd-be1f19be7ca50a133b83fb89f16b9d6757a106c6ee2e2ee5abc548d85edfbda4.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4fe449dd_5701_488e_a1b6_a4b242b6e284.slice/cri-containerd-d0156af61b933da475f9c74a31f982fee02b2de68bcbd5c4478982e84e212c0f.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod393f9bca_e56d_4c78_9f16_e377845f85ce.slice/cri-containerd-0f710a316310218c9ae00bcd575ca7a6a036943bbc09c21888846fdc33649036.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod393f9bca_e56d_4c78_9f16_e377845f85ce.slice/cri-containerd-4f49c819955a89740eee9ebfc8114872551c452df1cbb8d8432d6389a1cc37b5.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9590b0fc_4eaa_487f_b99d_22e47503a2bd.slice/cri-containerd-894f97b62a50135805dd2137fa70829c2fc8c88d8b11b9c42d2ea5f5714c9b32.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9590b0fc_4eaa_487f_b99d_22e47503a2bd.slice/cri-containerd-c9d4d07b3ddfdc0e330ad7bf067008cda55cccc45db6fd1ab161968345a14f97.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57d02e7e_5cfd_4e00_9db8_6ce87bc1d18f.slice/cri-containerd-a2072b7d30183da4594ce0cdb41b09afe5b825524ec8e04f0fce8f4b878ad944.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57d02e7e_5cfd_4e00_9db8_6ce87bc1d18f.slice/cri-containerd-b03771f161a572ec79db1a3f2c5c1ff371648d65987ddd0e7b2d02359e1e2db8.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57d02e7e_5cfd_4e00_9db8_6ce87bc1d18f.slice/cri-containerd-2bd563af6d30f4424e13b84642693c01b5ba0a31c6dd5890b0273635951efaa4.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57d02e7e_5cfd_4e00_9db8_6ce87bc1d18f.slice/cri-containerd-89b02b4946ec408e97100d1c01a77c8de82ef9a945fc4159aecef9fd337115b5.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc446cac1_5e10_4e9a_86b2_85c053bdb976.slice/cri-containerd-a7209fc7c74dcbab05ddde57249b66d0c4b20192a1be9672cfe2919ea8fb962b.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc446cac1_5e10_4e9a_86b2_85c053bdb976.slice/cri-containerd-4e0f90275f34051fcd99842ae89482617a51379b500c48890e7a5ec77f0aa575.scope
    101      cgroup_device   multi                                          
