xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 554
ens6(5) clsact/ingress cil_from_netdev-ens6 id 569
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 542
cilium_host(7) clsact/egress cil_from_host-cilium_host id 545
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 584
lxcb6d9870a9dcb(12) clsact/ingress cil_from_container-lxcb6d9870a9dcb id 523
lxceb9de36f26ac(14) clsact/ingress cil_from_container-lxceb9de36f26ac id 563
lxc69e6943b0b9d(18) clsact/ingress cil_from_container-lxc69e6943b0b9d id 652
lxc45cb4a16963e(20) clsact/ingress cil_from_container-lxc45cb4a16963e id 3393
lxc7784b394f665(22) clsact/ingress cil_from_container-lxc7784b394f665 id 3402
lxc20a38ec2ec11(24) clsact/ingress cil_from_container-lxc20a38ec2ec11 id 3336

flow_dissector:

netfilter:

