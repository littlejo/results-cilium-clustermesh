alloc: 83.02MB (87055624 bytes)
total-alloc: 3.04GB (3266857216 bytes)
sys: 227.07MB (238101844 bytes)
lookups: 0
mallocs: 74440871
frees: 73719481
heap-alloc: 83.02MB (87055624 bytes)
heap-sys: 180.73MB (189505536 bytes)
heap-idle: 59.27MB (62144512 bytes)
heap-in-use: 121.46MB (127361024 bytes)
heap-released: 15.91MB (16687104 bytes)
heap-objects: 721390
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.05MB (2148000 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 764.13KB (782465 bytes)
gc-sys: 5.51MB (5780624 bytes)
next-gc: when heap-alloc >= 150.50MB (157810072 bytes)
last-gc: 2024-10-24 12:54:33.21255516 +0000 UTC
gc-pause-total: 23.532697ms
gc-pause: 68848
gc-pause-end: 1729774473212555160
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006651686921370076
enable-gc: true
debug-gc: false
