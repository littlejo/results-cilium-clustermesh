top - 12:54:16 up 31 min,  0 users,  load average: 0.24, 0.47, 0.29
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 24.1 us, 34.5 sy,  0.0 ni, 37.9 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    296.2 free,   1041.8 used,   2498.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2613.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 290000  77692 S  13.3   7.4   1:05.34 cilium-+
   3218 root      20   0 1240432  16440  11356 S   6.7   0.4   0:00.04 cilium-+
    392 root      20   0 1229744   9860   3836 S   0.0   0.3   0:04.47 cilium-+
   3243 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3250 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3274 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
