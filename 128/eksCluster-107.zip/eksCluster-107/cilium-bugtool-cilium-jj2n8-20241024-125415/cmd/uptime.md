 12:54:16 up 31 min,  0 users,  load average: 0.24, 0.47, 0.29
