{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.114Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.164Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.170Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.212Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.226Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.251Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.473Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.484Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.544Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.579Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.603Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.225Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.227Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.274Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.288Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.309Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.549Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.561Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.604Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.630Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.668Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.232Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.240Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.262Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.294Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.392Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.415Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.436Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.650Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.654Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.709Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.726Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.762Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.359Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.366Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.394Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.413Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.440Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.472Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.483Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.725Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.731Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.784Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.796Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.835Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.272Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.279Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.328Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.332Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.364Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.665Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.671Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.737Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.833Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.835Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.252Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.257Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.311Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.319Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.347Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.641Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.643Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.695Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.708Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.744Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.281Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.316Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.322Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.361Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.370Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.416Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.423Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.674Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.678Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.728Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.739Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.774Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.273Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.287Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.383Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.389Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.421Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.628Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.649Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.684Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.715Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.729Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.080Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.113Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.135Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.159Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.175Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.204Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.495Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.499Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.544Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.548Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.585Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.925Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.978Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.984Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.029Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.032Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.067Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.374Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.381Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.463Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.501Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.531Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.848Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.848Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.889Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.910Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.938Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.948Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.220Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.243Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.250Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.275Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.007Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.011Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.042Z",
  "value": "id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.062Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.088Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.403Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.410Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.149Z",
  "value": "id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.152Z",
  "value": "id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63"
}

