1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:26:0e:aa:fe:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.218.198/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3543sec preferred_lft 3543sec
    inet6 fe80::826:eff:feaa:fe3d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c5:57:a8:7d:4f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.226.204/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8c5:57ff:fea8:7d4f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:5e:5f:ec:51:ed brd ff:ff:ff:ff:ff:ff
    inet6 fe80::905e:5fff:feec:51ed/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:b8:11:a3:7e:3c brd ff:ff:ff:ff:ff:ff
    inet 10.107.0.109/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::34b8:11ff:fea3:7e3c/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 56:8f:7e:71:00:a4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::548f:7eff:fe71:a4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:74:10:80:07:8c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::fc74:10ff:fe80:78c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb6d9870a9dcb@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:07:74:c3:37:35 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3c07:74ff:fec3:3735/64 scope link 
       valid_lft forever preferred_lft forever
14: lxceb9de36f26ac@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:b3:4c:c3:e0:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::10b3:4cff:fec3:e0b9/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc69e6943b0b9d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:d2:97:2d:c6:be brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d0d2:97ff:fe2d:c6be/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc45cb4a16963e@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:52:0d:e1:5c:4c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::1852:dff:fee1:5c4c/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc7784b394f665@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:56:c9:c2:06:63 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::c56:c9ff:fec2:663/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc20a38ec2ec11@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:df:8b:3d:19:38 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::1cdf:8bff:fe3d:1938/64 scope link 
       valid_lft forever preferred_lft forever
