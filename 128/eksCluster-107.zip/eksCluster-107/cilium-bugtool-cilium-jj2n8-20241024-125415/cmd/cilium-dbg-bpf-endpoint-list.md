IP ADDRESS         LOCAL ENDPOINT INFO
10.107.0.46:0      id=2681  sec_id=7107300 flags=0x0000 ifindex=12  mac=92:5A:1B:63:05:8C nodemac=3E:07:74:C3:37:35   
10.107.0.235:0     id=609   sec_id=7081383 flags=0x0000 ifindex=18  mac=C6:9A:4F:37:DE:16 nodemac=D2:D2:97:2D:C6:BE   
10.107.0.109:0     (localhost)                                                                                        
10.107.0.242:0     id=3777  sec_id=7107300 flags=0x0000 ifindex=14  mac=AE:58:0B:91:1C:33 nodemac=12:B3:4C:C3:E0:B9   
172.31.218.198:0   (localhost)                                                                                        
172.31.226.204:0   (localhost)                                                                                        
10.107.0.215:0     id=563   sec_id=4     flags=0x0000 ifindex=10  mac=CE:C2:2A:D2:14:7B nodemac=FE:74:10:80:07:8C     
10.107.0.201:0     id=1915  sec_id=7107118 flags=0x0000 ifindex=22  mac=4A:4F:30:6F:45:70 nodemac=0E:56:C9:C2:06:63   
10.107.0.5:0       id=1304  sec_id=7078397 flags=0x0000 ifindex=20  mac=F2:F7:D4:F5:10:98 nodemac=1A:52:0D:E1:5C:4C   
10.107.0.216:0     id=3446  sec_id=7079186 flags=0x0000 ifindex=24  mac=86:70:63:42:F7:AE nodemac=1E:DF:8B:3D:19:38   
