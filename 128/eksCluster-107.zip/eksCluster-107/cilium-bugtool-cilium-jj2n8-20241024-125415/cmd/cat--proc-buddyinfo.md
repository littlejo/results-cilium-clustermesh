Node 0, zone      DMA    175     84      3      4      5      1      6      2      0      3     45 
Node 0, zone   Normal    582     57     16     15     16      9      3      5      3      3      6 
