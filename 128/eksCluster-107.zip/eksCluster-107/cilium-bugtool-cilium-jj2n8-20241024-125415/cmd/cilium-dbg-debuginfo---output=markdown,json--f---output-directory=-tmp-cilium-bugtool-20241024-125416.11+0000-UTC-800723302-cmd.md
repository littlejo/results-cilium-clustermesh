markdown output at /tmp/cilium-bugtool-20241024-125416.11+0000-UTC-800723302/cmd/cilium-debuginfo-20241024-125447.097+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.11+0000-UTC-800723302/cmd/cilium-debuginfo-20241024-125447.097+0000-UTC.json
