USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3218  0.0  0.3 1240432 15584 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3233  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3234  0.0  0.0   3728   488 ?        R    12:54   0:00  \_ bash -c hostname
root        3204  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3182  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.9  7.2 1538804 284984 ?      Ssl  12:32   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.3  0.2 1229744 9860 ?        Sl   12:32   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
