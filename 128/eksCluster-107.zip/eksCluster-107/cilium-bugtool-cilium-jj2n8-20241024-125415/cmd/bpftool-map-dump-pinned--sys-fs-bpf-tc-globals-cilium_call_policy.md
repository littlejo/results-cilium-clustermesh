key: 33 02 00 00  value: 43 02 00 00
key: 61 02 00 00  value: 83 02 00 00
key: 18 05 00 00  value: 3d 0d 00 00
key: 7b 07 00 00  value: 47 0d 00 00
key: 79 0a 00 00  value: 17 02 00 00
key: 76 0d 00 00  value: 05 0d 00 00
key: c1 0e 00 00  value: 1d 02 00 00
Found 7 elements
