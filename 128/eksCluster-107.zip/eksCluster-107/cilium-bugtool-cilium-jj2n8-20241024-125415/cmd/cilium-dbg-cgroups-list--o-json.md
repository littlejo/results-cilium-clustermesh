[
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9590b0fc_4eaa_487f_b99d_22e47503a2bd.slice/cri-containerd-c9d4d07b3ddfdc0e330ad7bf067008cda55cccc45db6fd1ab161968345a14f97.scope"
      }
    ],
    "ips": [
      "10.107.0.201"
    ],
    "name": "client2-57cf4468f-zbfj4",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57d02e7e_5cfd_4e00_9db8_6ce87bc1d18f.slice/cri-containerd-89b02b4946ec408e97100d1c01a77c8de82ef9a945fc4159aecef9fd337115b5.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57d02e7e_5cfd_4e00_9db8_6ce87bc1d18f.slice/cri-containerd-b03771f161a572ec79db1a3f2c5c1ff371648d65987ddd0e7b2d02359e1e2db8.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57d02e7e_5cfd_4e00_9db8_6ce87bc1d18f.slice/cri-containerd-a2072b7d30183da4594ce0cdb41b09afe5b825524ec8e04f0fce8f4b878ad944.scope"
      }
    ],
    "ips": [
      "10.107.0.235"
    ],
    "name": "clustermesh-apiserver-556bd98d8f-57z8j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc13b5b93_f792_493f_bce3_5b613881eb46.slice/cri-containerd-17b6f0bebacc3dec62f7b9ca5e5b47443e0bfdf371f5ad480a1c1627e4f5d190.scope"
      }
    ],
    "ips": [
      "10.107.0.242"
    ],
    "name": "coredns-cc6ccd49c-hqms9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd20e6c86_70cc_4b2b_bbef_f75f04c5d973.slice/cri-containerd-be63d8dbdc82ae503c5eac8ce6678eb246cfe73f02497eac28b97e51b571e116.scope"
      }
    ],
    "ips": [
      "10.107.0.5"
    ],
    "name": "client-974f6c69d-c5vnf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4fe449dd_5701_488e_a1b6_a4b242b6e284.slice/cri-containerd-be1f19be7ca50a133b83fb89f16b9d6757a106c6ee2e2ee5abc548d85edfbda4.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4fe449dd_5701_488e_a1b6_a4b242b6e284.slice/cri-containerd-d0156af61b933da475f9c74a31f982fee02b2de68bcbd5c4478982e84e212c0f.scope"
      }
    ],
    "ips": [
      "10.107.0.216"
    ],
    "name": "echo-same-node-86d9cc975c-rlrmr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod77737177_61f9_4f6e_9e85_43dc77f4d0b3.slice/cri-containerd-98d3e9fd5a4ae831b0fa14ba93caa84432b780d4dd2f8491202b793b5e18c470.scope"
      }
    ],
    "ips": [
      "10.107.0.46"
    ],
    "name": "coredns-cc6ccd49c-clhxv",
    "namespace": "kube-system"
  }
]

