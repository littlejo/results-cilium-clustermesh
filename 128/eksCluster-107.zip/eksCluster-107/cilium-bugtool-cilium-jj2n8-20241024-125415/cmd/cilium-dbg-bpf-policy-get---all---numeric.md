Endpoint ID: 563
Path: /sys/fs/bpf/tc/globals/cilium_policy_00563

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6236261   76936     0        
Allow    Ingress     1          ANY          NONE         disabled    62765     763       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 609
Path: /sys/fs/bpf/tc/globals/cilium_policy_00609

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6148550   61161     0        
Allow    Ingress     1          ANY          NONE         disabled    5004553   52637     0        
Allow    Egress      0          ANY          NONE         disabled    6213146   61902     0        


Endpoint ID: 996
Path: /sys/fs/bpf/tc/globals/cilium_policy_00996

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1304
Path: /sys/fs/bpf/tc/globals/cilium_policy_01304

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1915
Path: /sys/fs/bpf/tc/globals/cilium_policy_01915

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2681
Path: /sys/fs/bpf/tc/globals/cilium_policy_02681

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2452     26        0        
Allow    Ingress     1          ANY          NONE         disabled    125572   1438      0        
Allow    Egress      0          ANY          NONE         disabled    18791    206       0        


Endpoint ID: 3446
Path: /sys/fs/bpf/tc/globals/cilium_policy_03446

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377817   4398      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3777
Path: /sys/fs/bpf/tc/globals/cilium_policy_03777

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3444     34        0        
Allow    Ingress     1          ANY          NONE         disabled    125371   1431      0        
Allow    Egress      0          ANY          NONE         disabled    18069    197       0        


