Node 0, zone      DMA     21     41     38     55     25     10      6      0      5      5     41 
Node 0, zone   Normal    350     40     12      2     24     10      5      2      3      2      7 
