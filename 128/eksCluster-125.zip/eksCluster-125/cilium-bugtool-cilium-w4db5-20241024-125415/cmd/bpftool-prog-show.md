32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:49+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:51+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:51+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:51+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:51+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:56+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
107: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
110: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:35:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
482: sched_cls  name tail_handle_ipv4  tag fb77745e98a5fd04  gpl
	loaded_at 2024-10-24T12:35:56+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
483: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:35:56+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:35:56+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
507: sched_cls  name cil_from_container  tag 9f77e73b32227cd8  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 153
508: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 154
509: sched_cls  name tail_handle_ipv4_cont  tag eba1ad42baeccba0  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 155
510: sched_cls  name tail_ipv4_to_endpoint  tag 4837515f01f194ff  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 156
511: sched_cls  name tail_ipv4_ct_egress  tag d264a7abb5949b74  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 157
512: sched_cls  name __send_drop_notify  tag e632fc5cd9d4c51a  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 158
513: sched_cls  name tail_handle_ipv4  tag 533ea47dd55cad35  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 159
514: sched_cls  name handle_policy  tag 2b85cf68f2a767f0  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 160
515: sched_cls  name tail_ipv4_ct_ingress  tag d5945597282158b7  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 161
516: sched_cls  name tail_handle_arp  tag 397a18eb13282d96  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 162
518: sched_cls  name tail_ipv4_ct_ingress  tag 5926dc269976e2bb  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 165
519: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 166
520: sched_cls  name cil_from_container  tag f85a0735605fb487  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 109,76
	btf_id 167
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
524: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
525: sched_cls  name handle_policy  tag 2f46073f1f98834d  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,109,82,83,110,41,80,101,39,84,75,40,37,38
	btf_id 168
526: sched_cls  name tail_handle_ipv4_cont  tag b22ed1045c49be20  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,110,41,101,82,83,39,76,74,77,109,40,37,38,81
	btf_id 169
528: sched_cls  name tail_handle_ipv4  tag b116b11b2ecde14e  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 171
529: sched_cls  name tail_handle_arp  tag cebe6693cfff4116  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 172
530: sched_cls  name tail_ipv4_to_endpoint  tag 3ac6de78576f8a23  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,110,41,82,83,80,101,39,109,40,37,38
	btf_id 173
531: sched_cls  name __send_drop_notify  tag 41b4ffa2ebd0bef6  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
532: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 175
533: sched_cls  name tail_handle_ipv4_cont  tag f22711f3785f82b2  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,100,82,83,39,76,74,77,113,40,37,38,81
	btf_id 177
534: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
537: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
538: sched_cls  name handle_policy  tag 382eaec05aa0dd64  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,100,39,84,75,40,37,38
	btf_id 178
539: sched_cls  name __send_drop_notify  tag 6cbc6eb06cbe7cfc  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 180
541: sched_cls  name tail_handle_arp  tag 06f8851ed22105e2  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 181
542: sched_cls  name tail_ipv4_ct_egress  tag d264a7abb5949b74  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 182
543: sched_cls  name tail_ipv4_ct_ingress  tag 3469d19072f63ef7  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 183
544: sched_cls  name cil_from_container  tag 6bb9746f23120fbb  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 184
545: sched_cls  name tail_handle_ipv4  tag ce9369d2fe1c0cf0  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 185
547: sched_cls  name tail_ipv4_to_endpoint  tag 733cb1a1c46c8b51  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,100,39,113,40,37,38
	btf_id 187
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:35:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
557: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 190
559: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
560: sched_cls  name tail_handle_ipv4_from_host  tag 52ac8fc23d256f74  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 193
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 194
562: sched_cls  name __send_drop_notify  tag 848f540a6315d098  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
566: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
567: sched_cls  name tail_handle_ipv4_from_host  tag 52ac8fc23d256f74  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 201
568: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 202
569: sched_cls  name __send_drop_notify  tag 848f540a6315d098  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
570: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 205
574: sched_cls  name tail_handle_ipv4_from_host  tag 52ac8fc23d256f74  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
575: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
576: sched_cls  name __send_drop_notify  tag 848f540a6315d098  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
577: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 213
581: sched_cls  name tail_handle_ipv4_from_host  tag 52ac8fc23d256f74  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 217
582: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 218
583: sched_cls  name __send_drop_notify  tag 848f540a6315d098  gpl
	loaded_at 2024-10-24T12:36:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
623: sched_cls  name __send_drop_notify  tag 5d69bfe40d18e563  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
624: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 234
625: sched_cls  name tail_handle_ipv4  tag e90edd74a4a7522c  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 235
627: sched_cls  name cil_from_container  tag 3d27003a55ff5ef3  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 237
628: sched_cls  name tail_ipv4_to_endpoint  tag 3928bbd8a368ab5d  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 238
629: sched_cls  name tail_handle_arp  tag 48c6aa034674546b  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 239
630: sched_cls  name tail_handle_ipv4_cont  tag 25957ac1240d16cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 240
631: sched_cls  name tail_ipv4_ct_egress  tag ffed7dea95e50881  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 241
632: sched_cls  name handle_policy  tag 8ec3700e58dfbf99  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 242
633: sched_cls  name tail_ipv4_ct_ingress  tag 6082568eb16159a0  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 243
634: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
637: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
684: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
687: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
688: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
691: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3264: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,623
	btf_id 3053
3267: sched_cls  name tail_handle_ipv4  tag cf91d7f576d91482  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,623
	btf_id 3054
3268: sched_cls  name __send_drop_notify  tag b09697307ee79d60  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3059
3270: sched_cls  name tail_ipv4_ct_ingress  tag 4555301fbf5d894e  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,623,82,83,624,84
	btf_id 3061
3271: sched_cls  name tail_handle_arp  tag 19bae7b150d9ef42  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,623
	btf_id 3062
3275: sched_cls  name handle_policy  tag 2f10fd3fba95ab5b  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,623,82,83,624,41,80,145,39,84,75,40,37,38
	btf_id 3063
3276: sched_cls  name cil_from_container  tag a0c4a32672e5de32  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 623,76
	btf_id 3067
3277: sched_cls  name tail_ipv4_ct_egress  tag 154c5f4ec046d437  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,623,82,83,624,84
	btf_id 3068
3284: sched_cls  name tail_ipv4_to_endpoint  tag 6d282a0d9fe3f88d  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,624,41,82,83,80,145,39,623,40,37,38
	btf_id 3070
3285: sched_cls  name tail_handle_ipv4_cont  tag 7b7476ac21d9be5f  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,624,41,145,82,83,39,76,74,77,623,40,37,38,81
	btf_id 3077
3320: sched_cls  name __send_drop_notify  tag 0f8ea8f8e3453e54  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3116
3321: sched_cls  name tail_ipv4_ct_ingress  tag 312445f173713bde  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3114
3322: sched_cls  name tail_ipv4_ct_egress  tag 7082e79016996b80  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3117
3323: sched_cls  name tail_ipv4_ct_egress  tag 0cf75731fcc6ba9a  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3118
3324: sched_cls  name tail_ipv4_ct_ingress  tag 749ff0ee6fcf6f89  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3119
3325: sched_cls  name tail_handle_arp  tag 9f06aff51700c534  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,635
	btf_id 3121
3326: sched_cls  name tail_handle_ipv4_cont  tag 1b44f5f06c9d9c6e  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,636,41,153,82,83,39,76,74,77,635,40,37,38,81
	btf_id 3122
3327: sched_cls  name tail_ipv4_to_endpoint  tag 9c440194787a83d8  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,633,41,82,83,80,148,39,634,40,37,38
	btf_id 3120
3328: sched_cls  name __send_drop_notify  tag c5d3b9f5a48fd792  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3124
3329: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,634
	btf_id 3125
3330: sched_cls  name tail_handle_arp  tag e91a521f71824d58  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,634
	btf_id 3126
3331: sched_cls  name handle_policy  tag 950bd57b0fe5716f  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,635,82,83,636,41,80,153,39,84,75,40,37,38
	btf_id 3123
3332: sched_cls  name tail_handle_ipv4  tag 729844c2b44e44fa  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,634
	btf_id 3127
3333: sched_cls  name tail_handle_ipv4  tag ececc4db6ea6a3db  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,635
	btf_id 3128
3334: sched_cls  name handle_policy  tag bf6a256359a7c4e0  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,634,82,83,633,41,80,148,39,84,75,40,37,38
	btf_id 3129
3335: sched_cls  name tail_handle_ipv4_cont  tag 632d38081402328a  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,633,41,148,82,83,39,76,74,77,634,40,37,38,81
	btf_id 3131
3337: sched_cls  name cil_from_container  tag b22f7320e91465b3  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,76
	btf_id 3133
3338: sched_cls  name tail_ipv4_to_endpoint  tag 0b7a5c9f7ef7cd12  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,636,41,82,83,80,153,39,635,40,37,38
	btf_id 3130
3339: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,635
	btf_id 3134
3340: sched_cls  name cil_from_container  tag 106570dc39f9c0a6  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 635,76
	btf_id 3135
