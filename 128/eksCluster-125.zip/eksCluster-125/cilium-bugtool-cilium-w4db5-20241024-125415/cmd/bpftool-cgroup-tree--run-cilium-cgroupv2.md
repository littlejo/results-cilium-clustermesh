CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bd38281_576b_46a9_89cc_5badfcc0fdde.slice/cri-containerd-f1172095d2477f8552a3fe797656ecd3951e61b6d1c2b9f30b3f5e52fb0cafa6.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bd38281_576b_46a9_89cc_5badfcc0fdde.slice/cri-containerd-5887cf1e208c382f80e5aac7efca3d9e26ff046c88ba1c0bc059b6b81275d45c.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab77bcd8_9125_46ca_87e8_ce6584c240c1.slice/cri-containerd-9a4ce11406b825776e3233a876dfdceae733dd3e248a78ab5ca66b8666d1e564.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab77bcd8_9125_46ca_87e8_ce6584c240c1.slice/cri-containerd-e9ff24ccfb21053be5148a751ae0a24c274192a088a1ad69531c648353a3ebf0.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d8ae179_ac42_475c_bf3e_aebfd6ba6224.slice/cri-containerd-5bfa531c65ffe3ade7fe4496eb83712d9fd8a92dc0fbcca392fd5f5d1fe2ecc9.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d8ae179_ac42_475c_bf3e_aebfd6ba6224.slice/cri-containerd-fe5b041f594f603a90be741dbc24359bc6495aa7c559f2da079ad22b993865e3.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb187ce8_4d7a_49b0_a44b_996db8a1fdbc.slice/cri-containerd-ad8b2659c0438c0a280a3d5faf4f938e1e7b8e4f01ac7df884030121cd9821ea.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb187ce8_4d7a_49b0_a44b_996db8a1fdbc.slice/cri-containerd-de22307ca53e95fe74c4d818f38c171a63ac3b76c7bd17253792f4abfdd89fa4.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podac4c0e71_4b34_4706_8590_7056b5ec1e58.slice/cri-containerd-385df4ee6748af9a12fd87e9c18c11576370125decad6867540b69e96121edf4.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podac4c0e71_4b34_4706_8590_7056b5ec1e58.slice/cri-containerd-ac5ccdc9ff846ef42d6f252635e03db130ae97431f6b08c679db53d221c533b0.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf13d2deb_8151_416c_9043_df3969da408f.slice/cri-containerd-920bb499756d549d6b90ee833cc41ed7fc0f2b6b3334da106cba8bfd4a00c4c7.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf13d2deb_8151_416c_9043_df3969da408f.slice/cri-containerd-887bce4a233bae69574cb6fc936259d3ec01dc3f04c312e89818c4657413bb37.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e6431e9_047d_44f0_ba48_fd4e427d2f42.slice/cri-containerd-0f7cf0cf6b3bf6ab70de646ce57b7ca74ebc2f09967d4c6d895fa910382122e6.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e6431e9_047d_44f0_ba48_fd4e427d2f42.slice/cri-containerd-024acbf6c6d76e1f68f8afd19306f48bfe8a050eb417ba6667943588069892f9.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e6431e9_047d_44f0_ba48_fd4e427d2f42.slice/cri-containerd-f15f0bbe37151fa46bb177caec4986f0bdaee28c20160476aa17bd44f2a2b40f.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e6431e9_047d_44f0_ba48_fd4e427d2f42.slice/cri-containerd-fc7eed092111a054953c5454d52423f34836d63a6d738dfba9d6eb9bd0c144e0.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod394bdab3_c9b6_444f_9b53_7e39ceee08e5.slice/cri-containerd-98faddedf0070fdeef3e9fb51bf4407ea456e29a4c67f8c1c451058db5da4f3a.scope
    687      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod394bdab3_c9b6_444f_9b53_7e39ceee08e5.slice/cri-containerd-12f1dbf0089f8ded68b1e4365972b164db6304447dc7a9b7e84765870623881c.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod394bdab3_c9b6_444f_9b53_7e39ceee08e5.slice/cri-containerd-6b9b77a5f78a488a66f92268aac809371e81eb6ad037743ae713a42e7cc6491a.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc57b1a6_38b1_444d_b894_9e6dc8f3387b.slice/cri-containerd-e07e793f9550163b821466708bf7b22f9a5d8e695f52370af8779d287672aeaa.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc57b1a6_38b1_444d_b894_9e6dc8f3387b.slice/cri-containerd-dc938821348c7e6fc351c8381915448ad5f44dd4a46df2979b300c17a9678627.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65ade73c_d926_4d39_883d_4e8a1fa73568.slice/cri-containerd-24fbb5af6c5396e0f613d419ee616ab1ada32a9c178ffd47cd1fc3986d3b19e5.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65ade73c_d926_4d39_883d_4e8a1fa73568.slice/cri-containerd-00c0a1adf2c8bffb634b0a1e085d5cf8095e9866de8be3ac9d484dd2a7c34cef.scope
    706      cgroup_device   multi                                          
