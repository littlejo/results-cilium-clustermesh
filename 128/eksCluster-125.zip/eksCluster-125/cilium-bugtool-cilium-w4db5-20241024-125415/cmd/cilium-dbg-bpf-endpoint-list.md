IP ADDRESS        LOCAL ENDPOINT INFO
10.125.0.144:0    id=330   sec_id=8268603 flags=0x0000 ifindex=20  mac=02:38:17:EA:AD:41 nodemac=96:E1:99:7D:A3:2C   
172.31.251.94:0   (localhost)                                                                                        
10.125.0.193:0    id=886   sec_id=8287917 flags=0x0000 ifindex=22  mac=3A:AD:20:4E:03:29 nodemac=02:27:1B:F5:44:38   
10.125.0.61:0     id=13    sec_id=4     flags=0x0000 ifindex=10  mac=AE:C0:97:8A:58:06 nodemac=AA:12:F3:5E:03:2F     
10.125.0.203:0    id=575   sec_id=8278356 flags=0x0000 ifindex=24  mac=7A:D3:0E:32:3A:6E nodemac=96:05:66:0E:C7:0C   
172.31.194.46:0   (localhost)                                                                                        
10.125.0.119:0    id=2104  sec_id=8312071 flags=0x0000 ifindex=14  mac=36:F1:34:D8:A8:28 nodemac=1E:78:D2:A6:CB:7E   
10.125.0.133:0    id=1113  sec_id=8312071 flags=0x0000 ifindex=12  mac=DE:5B:68:82:33:93 nodemac=5A:98:C4:28:A8:15   
10.125.0.49:0     (localhost)                                                                                        
10.125.0.112:0    id=3146  sec_id=8260588 flags=0x0000 ifindex=18  mac=2E:34:F5:76:6A:2D nodemac=EA:D2:B5:9C:01:87   
