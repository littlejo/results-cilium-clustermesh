top - 12:54:17 up 30 min,  0 users,  load average: 0.23, 0.48, 0.33
Tasks:   9 total,   3 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 43.3 us, 40.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 16.7 si,  0.0 st
MiB Mem :   3836.2 total,    271.7 free,   1064.6 used,   2499.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2590.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3271 root      20   0 1244596  23112  14460 S  46.7   0.6   0:00.07 hubble
      1 root      20   0 1539060 297444  79104 S   6.7   7.6   1:07.55 cilium-+
    415 root      20   0 1229744   9080   2924 S   0.0   0.2   0:04.51 cilium-+
   3203 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
   3235 root      20   0 1240432  16460  11292 S   0.0   0.4   0:00.02 cilium-+
   3265 root      20   0    2208    788    708 S   0.0   0.0   0:00.00 timeout
   3276 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
   3296 root      20   0    3416    992    864 R   0.0   0.0   0:00.00 iptable+
   3297 root      20   0 1240432  16460  11292 R   0.0   0.4   0:00.00 cilium-+
