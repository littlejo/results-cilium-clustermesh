xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 570
ens6(5) clsact/ingress cil_from_netdev-ens6 id 577
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 559
cilium_host(7) clsact/egress cil_from_host-cilium_host id 557
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 520
lxc73c0fb741803(12) clsact/ingress cil_from_container-lxc73c0fb741803 id 544
lxcf6d177d7818b(14) clsact/ingress cil_from_container-lxcf6d177d7818b id 507
lxcf3dae2f1deaa(18) clsact/ingress cil_from_container-lxcf3dae2f1deaa id 627
lxc798196271f22(20) clsact/ingress cil_from_container-lxc798196271f22 id 3276
lxcc6800f3d5308(22) clsact/ingress cil_from_container-lxcc6800f3d5308 id 3337
lxcf560e492c1a7(24) clsact/ingress cil_from_container-lxcf560e492c1a7 id 3340

flow_dissector:

netfilter:

