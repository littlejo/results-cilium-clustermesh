filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc6800f3d5308 direct-action not_in_hw id 3337 tag b22f7320e91465b3 jited 
