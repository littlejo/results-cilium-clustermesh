USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3235  0.0  0.4 1240432 16460 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3249  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3203  0.0  0.1 1228744 4044 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  6.0  7.5 1539060 297444 ?      Ssl  12:35   1:07 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.4  0.2 1229744 9080 ?        Sl   12:35   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
