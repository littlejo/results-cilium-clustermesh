alloc: 123.37MB (129363864 bytes)
total-alloc: 3.10GB (3330786992 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75557471
frees: 74327125
heap-alloc: 123.37MB (129363864 bytes)
heap-sys: 172.61MB (180994048 bytes)
heap-idle: 27.28MB (28606464 bytes)
heap-in-use: 145.33MB (152387584 bytes)
heap-released: 2.48MB (2605056 bytes)
heap-objects: 1230346
stack-in-use: 35.34MB (37060608 bytes)
stack-sys: 35.34MB (37060608 bytes)
stack-mspan-inuse: 2.26MB (2368160 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 981.19KB (1004737 bytes)
gc-sys: 5.53MB (5803152 bytes)
next-gc: when heap-alloc >= 153.96MB (161433736 bytes)
last-gc: 2024-10-24 12:54:17.004023584 +0000 UTC
gc-pause-total: 19.984264ms
gc-pause: 2625249
gc-pause-end: 1729774457004023584
num-gc: 97
num-forced-gc: 0
gc-cpu-fraction: 0.0008302301735273662
enable-gc: true
debug-gc: false
