1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:47:20:fa:33:59 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.251.94/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3581sec preferred_lft 3581sec
    inet6 fe80::847:20ff:fefa:3359/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:8e:a0:af:23:31 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.194.46/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::88e:a0ff:feaf:2331/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:66:e7:27:0e:61 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9866:e7ff:fe27:e61/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:0e:38:34:59:be brd ff:ff:ff:ff:ff:ff
    inet 10.125.0.49/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c40e:38ff:fe34:59be/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fa:3d:5f:e6:26:13 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f83d:5fff:fee6:2613/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:12:f3:5e:03:2f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a812:f3ff:fe5e:32f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc73c0fb741803@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:98:c4:28:a8:15 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5898:c4ff:fe28:a815/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf6d177d7818b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:78:d2:a6:cb:7e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1c78:d2ff:fea6:cb7e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf3dae2f1deaa@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:d2:b5:9c:01:87 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e8d2:b5ff:fe9c:187/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc798196271f22@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:e1:99:7d:a3:2c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::94e1:99ff:fe7d:a32c/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcc6800f3d5308@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:27:1b:f5:44:38 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::27:1bff:fef5:4438/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcf560e492c1a7@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:05:66:0e:c7:0c brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::9405:66ff:fe0e:c70c/64 scope link 
       valid_lft forever preferred_lft forever
