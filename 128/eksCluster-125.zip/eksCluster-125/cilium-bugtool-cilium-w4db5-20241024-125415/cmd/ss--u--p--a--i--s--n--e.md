Total: 595
TCP:   4734 (estab 314, closed 4401, orphaned 0, timewait 3923)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  333       323       10       
INET	  343       329       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.251.94%ens5:68         0.0.0.0:*    uid:192 ino:164569 sk:7b5 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:38513 sk:7b6 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14789 sk:7b7 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:35725      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:38326 sk:7b8 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:38512 sk:7b9 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14790 sk:7ba cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::847:20ff:fefa:3359]%ens5:546           [::]:*    uid:192 ino:16087 sk:7bb cgroup:unreachable:bd0 v6only:1 <->                   
