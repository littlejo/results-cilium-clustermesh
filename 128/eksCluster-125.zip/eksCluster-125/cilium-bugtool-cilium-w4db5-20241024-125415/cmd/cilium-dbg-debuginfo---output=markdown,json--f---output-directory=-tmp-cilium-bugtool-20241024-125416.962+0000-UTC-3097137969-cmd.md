markdown output at /tmp/cilium-bugtool-20241024-125416.962+0000-UTC-3097137969/cmd/cilium-debuginfo-20241024-125447.679+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.962+0000-UTC-3097137969/cmd/cilium-debuginfo-20241024-125447.679+0000-UTC.json
