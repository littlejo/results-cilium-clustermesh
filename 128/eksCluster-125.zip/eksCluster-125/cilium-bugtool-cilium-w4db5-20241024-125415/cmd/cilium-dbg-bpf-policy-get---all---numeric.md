Endpoint ID: 13
Path: /sys/fs/bpf/tc/globals/cilium_policy_00013

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6236344   77100     0        
Allow    Ingress     1          ANY          NONE         disabled    58042     706       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 330
Path: /sys/fs/bpf/tc/globals/cilium_policy_00330

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378590   4408      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 575
Path: /sys/fs/bpf/tc/globals/cilium_policy_00575

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 886
Path: /sys/fs/bpf/tc/globals/cilium_policy_00886

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1113
Path: /sys/fs/bpf/tc/globals/cilium_policy_01113

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    259691   2347      0        
Allow    Ingress     1          ANY          NONE         disabled    106375   1215      0        
Allow    Egress      0          ANY          NONE         disabled    67294    654       0        


Endpoint ID: 2104
Path: /sys/fs/bpf/tc/globals/cilium_policy_02104

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    277687   2503      0        
Allow    Ingress     1          ANY          NONE         disabled    107893   1238      0        
Allow    Egress      0          ANY          NONE         disabled    66755    649       0        


Endpoint ID: 3146
Path: /sys/fs/bpf/tc/globals/cilium_policy_03146

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6095468   61399     0        
Allow    Ingress     1          ANY          NONE         disabled    5553020   58689     0        
Allow    Egress      0          ANY          NONE         disabled    7160257   70464     0        


Endpoint ID: 3349
Path: /sys/fs/bpf/tc/globals/cilium_policy_03349

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


