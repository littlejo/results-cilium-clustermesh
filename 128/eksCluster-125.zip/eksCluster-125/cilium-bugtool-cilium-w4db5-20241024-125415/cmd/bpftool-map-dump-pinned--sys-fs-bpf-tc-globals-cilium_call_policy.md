key: 0d 00 00 00  value: 0d 02 00 00
key: 4a 01 00 00  value: cb 0c 00 00
key: 3f 02 00 00  value: 03 0d 00 00
key: 76 03 00 00  value: 06 0d 00 00
key: 59 04 00 00  value: 1a 02 00 00
key: 38 08 00 00  value: 02 02 00 00
key: 4a 0c 00 00  value: 78 02 00 00
Found 7 elements
