[
  {
    "containers": [
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e6431e9_047d_44f0_ba48_fd4e427d2f42.slice/cri-containerd-0f7cf0cf6b3bf6ab70de646ce57b7ca74ebc2f09967d4c6d895fa910382122e6.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e6431e9_047d_44f0_ba48_fd4e427d2f42.slice/cri-containerd-024acbf6c6d76e1f68f8afd19306f48bfe8a050eb417ba6667943588069892f9.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e6431e9_047d_44f0_ba48_fd4e427d2f42.slice/cri-containerd-fc7eed092111a054953c5454d52423f34836d63a6d738dfba9d6eb9bd0c144e0.scope"
      }
    ],
    "ips": [
      "10.125.0.112"
    ],
    "name": "clustermesh-apiserver-bf899c4dc-tfqzj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod394bdab3_c9b6_444f_9b53_7e39ceee08e5.slice/cri-containerd-6b9b77a5f78a488a66f92268aac809371e81eb6ad037743ae713a42e7cc6491a.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod394bdab3_c9b6_444f_9b53_7e39ceee08e5.slice/cri-containerd-12f1dbf0089f8ded68b1e4365972b164db6304447dc7a9b7e84765870623881c.scope"
      }
    ],
    "ips": [
      "10.125.0.144"
    ],
    "name": "echo-same-node-86d9cc975c-5hr4g",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65ade73c_d926_4d39_883d_4e8a1fa73568.slice/cri-containerd-24fbb5af6c5396e0f613d419ee616ab1ada32a9c178ffd47cd1fc3986d3b19e5.scope"
      }
    ],
    "ips": [
      "10.125.0.203"
    ],
    "name": "client2-57cf4468f-vf4zx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podac4c0e71_4b34_4706_8590_7056b5ec1e58.slice/cri-containerd-385df4ee6748af9a12fd87e9c18c11576370125decad6867540b69e96121edf4.scope"
      }
    ],
    "ips": [
      "10.125.0.193"
    ],
    "name": "client-974f6c69d-jpgj4",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bd38281_576b_46a9_89cc_5badfcc0fdde.slice/cri-containerd-f1172095d2477f8552a3fe797656ecd3951e61b6d1c2b9f30b3f5e52fb0cafa6.scope"
      }
    ],
    "ips": [
      "10.125.0.119"
    ],
    "name": "coredns-cc6ccd49c-ngmhp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab77bcd8_9125_46ca_87e8_ce6584c240c1.slice/cri-containerd-9a4ce11406b825776e3233a876dfdceae733dd3e248a78ab5ca66b8666d1e564.scope"
      }
    ],
    "ips": [
      "10.125.0.133"
    ],
    "name": "coredns-cc6ccd49c-wz7jx",
    "namespace": "kube-system"
  }
]

