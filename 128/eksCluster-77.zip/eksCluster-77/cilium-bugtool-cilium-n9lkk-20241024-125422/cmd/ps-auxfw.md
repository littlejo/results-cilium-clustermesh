USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3176  0.0  0.2 1616008 8664 ?        Rsl  12:54   0:00 /usr/sbin/runc init
root        3155  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3149  0.0  0.4 1240176 16428 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3183  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3186  0.0  0.4 1240176 16428 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3144  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3131  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3119  0.0  0.0      0     0 ?        Rs   12:54   0:00 [gops]
root           1  4.9  7.4 1539060 294556 ?      Ssl  12:30   1:11 cilium-agent --config-dir=/tmp/cilium/config-map
root         406  0.3  0.2 1229744 9884 ?        Sl   12:30   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
