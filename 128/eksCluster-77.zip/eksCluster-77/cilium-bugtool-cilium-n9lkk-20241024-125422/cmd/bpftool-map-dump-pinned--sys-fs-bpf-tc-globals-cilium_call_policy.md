key: b0 00 00 00  value: 6f 02 00 00
key: d0 01 00 00  value: 0c 02 00 00
key: c6 03 00 00  value: 16 0d 00 00
key: 5b 05 00 00  value: e6 0c 00 00
key: d7 05 00 00  value: fd 01 00 00
key: 38 09 00 00  value: 18 02 00 00
key: f7 0b 00 00  value: 17 0d 00 00
Found 7 elements
