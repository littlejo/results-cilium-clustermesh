KEY             VALUE
AgentLiveness   1954515974810
UTimeOffset     3378461994140625
