Node 0, zone      DMA    182     64     14     41    120     83     23      8      6      5     37 
Node 0, zone   Normal    348     71     32     23     19      6      5      7      6      3      5 
