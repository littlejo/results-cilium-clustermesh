filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc37b82e601651 direct-action not_in_hw id 3344 tag 81155746afae3219 jited 
