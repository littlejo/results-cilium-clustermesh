Endpoint ID: 176
Path: /sys/fs/bpf/tc/globals/cilium_policy_00176

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6131297   61860     0        
Allow    Ingress     1          ANY          NONE         disabled    5699511   60424     0        
Allow    Egress      0          ANY          NONE         disabled    7198516   70796     0        


Endpoint ID: 464
Path: /sys/fs/bpf/tc/globals/cilium_policy_00464

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6222056   76861     0        
Allow    Ingress     1          ANY          NONE         disabled    60414     729       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 966
Path: /sys/fs/bpf/tc/globals/cilium_policy_00966

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1371
Path: /sys/fs/bpf/tc/globals/cilium_policy_01371

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    383053   4468      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1495
Path: /sys/fs/bpf/tc/globals/cilium_policy_01495

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1860     19        0        
Allow    Ingress     1          ANY          NONE         disabled    139133   1598      0        
Allow    Egress      0          ANY          NONE         disabled    18736    207       0        


Endpoint ID: 1532
Path: /sys/fs/bpf/tc/globals/cilium_policy_01532

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2360
Path: /sys/fs/bpf/tc/globals/cilium_policy_02360

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4036     41        0        
Allow    Ingress     1          ANY          NONE         disabled    140940   1621      0        
Allow    Egress      0          ANY          NONE         disabled    17853    197       0        


Endpoint ID: 3063
Path: /sys/fs/bpf/tc/globals/cilium_policy_03063

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


