Total: 585
TCP:   2839 (estab 308, closed 2512, orphaned 0, timewait 2052)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  327       315       12       
INET	  337       321       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:38977      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32450 sk:174 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.230.165%ens5:68         0.0.0.0:*    uid:192 ino:123842 sk:175 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32610 sk:176 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15429 sk:177 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32609 sk:178 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15430 sk:179 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::84f:94ff:fe76:ed2f]%ens5:546           [::]:*    uid:192 ino:16463 sk:17a cgroup:unreachable:bd0 v6only:1 <->                   
