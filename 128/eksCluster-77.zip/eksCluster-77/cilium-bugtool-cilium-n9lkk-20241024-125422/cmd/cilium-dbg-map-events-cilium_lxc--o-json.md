{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.381Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.950Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.007Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.012Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.052Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.065Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.096Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.376Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.379Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.460Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.478Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.549Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.287Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.312Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.394Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.401Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.431Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.600Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.605Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.673Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.696Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.722Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.294Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.312Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.372Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.374Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.416Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.430Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.691Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.700Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.761Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.774Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.818Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.422Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.428Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.454Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.499Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.537Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.611Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.641Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.862Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.890Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.925Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.934Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.980Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.435Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.491Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.496Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.549Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.557Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.586Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.845Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.848Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.919Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.919Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.963Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.413Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.422Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.483Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.484Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.525Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.844Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.848Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.906Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.932Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.958Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.213Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.274Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.314Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.339Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.359Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.385Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.631Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.636Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.690Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.698Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.741Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.173Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.222Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.264Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.281Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.333Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.342Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.554Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.554Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.622Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.665Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.750Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.167Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.175Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.235Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.237Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.272Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.483Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.515Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.549Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.579Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.606Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.924Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.929Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.969Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.017Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.023Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.293Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.303Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.347Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.374Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.393Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.693Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.734Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.739Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.789Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.795Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.826Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.087Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.088Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.095Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.102Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.125Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.818Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.821Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.856Z",
  "value": "id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.889Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.909Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.186Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.188Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.953Z",
  "value": "id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.971Z",
  "value": "id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6"
}

