filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc0e4072577361 direct-action not_in_hw id 3362 tag 7d58818223132945 jited 
