alloc: 110.86MB (116250064 bytes)
total-alloc: 3.09GB (3322902576 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75391487
frees: 74240554
heap-alloc: 110.86MB (116250064 bytes)
heap-sys: 176.61MB (185188352 bytes)
heap-idle: 42.27MB (44326912 bytes)
heap-in-use: 134.34MB (140861440 bytes)
heap-released: 7.92MB (8306688 bytes)
heap-objects: 1150933
stack-in-use: 35.34MB (37060608 bytes)
stack-sys: 35.34MB (37060608 bytes)
stack-mspan-inuse: 2.18MB (2288480 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 991.77KB (1015569 bytes)
gc-sys: 5.53MB (5801128 bytes)
next-gc: when heap-alloc >= 152.73MB (160147000 bytes)
last-gc: 2024-10-24 12:54:27.532005403 +0000 UTC
gc-pause-total: 16.363299ms
gc-pause: 72106
gc-pause-end: 1729774467532005403
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006998185213359708
enable-gc: true
debug-gc: false
