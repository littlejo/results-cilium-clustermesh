[
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76b6e329_302c_45c2_8ab2_55b576840e86.slice/cri-containerd-168e7fd919c8495dc69d4dea16a1aa24ea213ba411d5afa8d583b68f9dfb49d0.scope"
      }
    ],
    "ips": [
      "10.77.0.80"
    ],
    "name": "coredns-cc6ccd49c-2w9rb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f470eb1_f484_43df_8d24_8a9bf8bdd5a6.slice/cri-containerd-9c064f3578eeb5ccccbb60bab25b96c252b78c5c08d08cab48afd09963eac4f8.scope"
      }
    ],
    "ips": [
      "10.77.0.236"
    ],
    "name": "client-974f6c69d-q2rct",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a8966fe_e954_45fc_8bcf_220067f5327d.slice/cri-containerd-a4b28d6236925c95965da45c8a5bd0ffb87b2c225c6bb5906180a66caa6a75d6.scope"
      }
    ],
    "ips": [
      "10.77.0.222"
    ],
    "name": "client2-57cf4468f-48krg",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod524c00b2_ccd5_41ea_ad0d_de4ea119c4df.slice/cri-containerd-2a52e1295ce19e34db64622a21a8ed6459144b9c04f68f72a254df56ef4d359b.scope"
      },
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod524c00b2_ccd5_41ea_ad0d_de4ea119c4df.slice/cri-containerd-d0fef0462860833e179170cf23340fed1b9ba00c7558a19fc4f01108482daa06.scope"
      }
    ],
    "ips": [
      "10.77.0.184"
    ],
    "name": "echo-same-node-86d9cc975c-4nsvr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70e61426_f109_471f_bc5c_11581eab0fca.slice/cri-containerd-9bb59bac52066a4ed5bbf1c3761d04c32183964c3d503c8f5e79b268e32c727b.scope"
      },
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70e61426_f109_471f_bc5c_11581eab0fca.slice/cri-containerd-19ba4329283292b91b81483d882dcebd923ce0df70fef32024ed536b5044dadf.scope"
      },
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70e61426_f109_471f_bc5c_11581eab0fca.slice/cri-containerd-3a51b5dba07156593eee41c74ce79422c44c1ff3175a6fb6676f5eecd5153a06.scope"
      }
    ],
    "ips": [
      "10.77.0.102"
    ],
    "name": "clustermesh-apiserver-785454fd6c-qtnj5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8fdbd34_5418_4dc1_90b4_a4593fadda16.slice/cri-containerd-aa414de65d6410a771e42cfeb811a47f9b496071aec7b322a1a27b01b85d446b.scope"
      }
    ],
    "ips": [
      "10.77.0.178"
    ],
    "name": "coredns-cc6ccd49c-k8tvp",
    "namespace": "kube-system"
  }
]

