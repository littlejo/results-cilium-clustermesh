1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:4f:94:76:ed:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.230.165/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3489sec preferred_lft 3489sec
    inet6 fe80::84f:94ff:fe76:ed2f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c3:e4:1a:97:01 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.236.188/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8c3:e4ff:fe1a:9701/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:9b:f3:e5:cc:80 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::889b:f3ff:fee5:cc80/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:fc:d3:0a:61:f9 brd ff:ff:ff:ff:ff:ff
    inet 10.77.0.43/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ecfc:d3ff:fe0a:61f9/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3a:2a:e9:cf:1b:ce brd ff:ff:ff:ff:ff:ff
    inet6 fe80::382a:e9ff:fecf:1bce/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:53:54:d5:49:73 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6453:54ff:fed5:4973/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc954999e82fc1@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:5b:d1:e8:ea:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::745b:d1ff:fee8:eab3/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0fdef81742e0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:cf:35:47:4d:aa brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::84cf:35ff:fe47:4daa/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8148cb72f6f5@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:39:3f:4e:7d:77 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b439:3fff:fe4e:7d77/64 scope link 
       valid_lft forever preferred_lft forever
20: lxceb8b84acd817@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:ce:55:24:80:ad brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::24ce:55ff:fe24:80ad/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc37b82e601651@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:8d:1b:72:42:8e brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::c08d:1bff:fe72:428e/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc0e4072577361@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:2e:b5:a5:4c:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::42e:b5ff:fea5:4cb6/64 scope link 
       valid_lft forever preferred_lft forever
