IP ADDRESS         LOCAL ENDPOINT INFO
10.77.0.222:0      id=3063  sec_id=5118000 flags=0x0000 ifindex=24  mac=5E:91:5A:88:93:97 nodemac=06:2E:B5:A5:4C:B6   
172.31.236.188:0   (localhost)                                                                                        
10.77.0.43:0       (localhost)                                                                                        
10.77.0.184:0      id=1371  sec_id=5128669 flags=0x0000 ifindex=20  mac=32:FB:F2:4B:8E:DA nodemac=26:CE:55:24:80:AD   
10.77.0.178:0      id=2360  sec_id=5125331 flags=0x0000 ifindex=12  mac=92:11:99:39:00:7F nodemac=76:5B:D1:E8:EA:B3   
10.77.0.189:0      id=464   sec_id=4     flags=0x0000 ifindex=10  mac=3E:75:CD:FB:8F:64 nodemac=66:53:54:D5:49:73     
10.77.0.80:0       id=1495  sec_id=5125331 flags=0x0000 ifindex=14  mac=FA:46:86:4B:E3:CE nodemac=86:CF:35:47:4D:AA   
10.77.0.236:0      id=966   sec_id=5121843 flags=0x0000 ifindex=22  mac=A6:54:C3:18:11:31 nodemac=C2:8D:1B:72:42:8E   
10.77.0.102:0      id=176   sec_id=5143304 flags=0x0000 ifindex=18  mac=CE:5B:CD:CD:D1:93 nodemac=B6:39:3F:4E:7D:77   
172.31.230.165:0   (localhost)                                                                                        
