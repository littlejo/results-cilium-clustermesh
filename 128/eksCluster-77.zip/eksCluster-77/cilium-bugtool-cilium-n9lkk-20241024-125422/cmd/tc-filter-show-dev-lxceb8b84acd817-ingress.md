filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxceb8b84acd817 direct-action not_in_hw id 3286 tag bbcaf0dd3774fcfb jited 
