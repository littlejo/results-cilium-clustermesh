CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8fdbd34_5418_4dc1_90b4_a4593fadda16.slice/cri-containerd-a5137f947702b546b03fba391b0170c01a972223d016165af1bc88d998d40dec.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8fdbd34_5418_4dc1_90b4_a4593fadda16.slice/cri-containerd-aa414de65d6410a771e42cfeb811a47f9b496071aec7b322a1a27b01b85d446b.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76b6e329_302c_45c2_8ab2_55b576840e86.slice/cri-containerd-01d68e0212efa8c5322845a466d43e92f79a99d033f89e53eb34796494c62ec6.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76b6e329_302c_45c2_8ab2_55b576840e86.slice/cri-containerd-168e7fd919c8495dc69d4dea16a1aa24ea213ba411d5afa8d583b68f9dfb49d0.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e267cac_5f0d_4366_a1cd_e6ad60d6eea0.slice/cri-containerd-2b5957af8d7704c94a588a34744aa5868cf327ef60895217141b8f954bd05c71.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e267cac_5f0d_4366_a1cd_e6ad60d6eea0.slice/cri-containerd-4f9d188904036769825caa12fe7f2c9644d7022d99d50b6138fd0e0c5ca8ef11.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11c532f2_03dc_4245_91e8_781314768aab.slice/cri-containerd-14253a9dbc05a5197a91869d3477607b93643e0f929aa6ded877adfc0115f399.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11c532f2_03dc_4245_91e8_781314768aab.slice/cri-containerd-cc6db5f8b3e9ed1ed69174d0259778e89d587e562ed48904e37d508a0b586a5b.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70e61426_f109_471f_bc5c_11581eab0fca.slice/cri-containerd-19ba4329283292b91b81483d882dcebd923ce0df70fef32024ed536b5044dadf.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70e61426_f109_471f_bc5c_11581eab0fca.slice/cri-containerd-788fb463cefe35b838a6c4e0bfd9304cad09c648e067c39a554a575c1163dd63.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70e61426_f109_471f_bc5c_11581eab0fca.slice/cri-containerd-9bb59bac52066a4ed5bbf1c3761d04c32183964c3d503c8f5e79b268e32c727b.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70e61426_f109_471f_bc5c_11581eab0fca.slice/cri-containerd-3a51b5dba07156593eee41c74ce79422c44c1ff3175a6fb6676f5eecd5153a06.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f470eb1_f484_43df_8d24_8a9bf8bdd5a6.slice/cri-containerd-9c064f3578eeb5ccccbb60bab25b96c252b78c5c08d08cab48afd09963eac4f8.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f470eb1_f484_43df_8d24_8a9bf8bdd5a6.slice/cri-containerd-298659c4cc54df01cf96d5fe4d2aac4d1cf74a86643507fd5d116c78b56cac73.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a8966fe_e954_45fc_8bcf_220067f5327d.slice/cri-containerd-a4b28d6236925c95965da45c8a5bd0ffb87b2c225c6bb5906180a66caa6a75d6.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a8966fe_e954_45fc_8bcf_220067f5327d.slice/cri-containerd-ca7f74317c076a782e209aa2b235a0ff0642c10696fbafa0d58358cdc831a494.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod524c00b2_ccd5_41ea_ad0d_de4ea119c4df.slice/cri-containerd-d0fef0462860833e179170cf23340fed1b9ba00c7558a19fc4f01108482daa06.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod524c00b2_ccd5_41ea_ad0d_de4ea119c4df.slice/cri-containerd-549ac9455c2ce5e149e9d63c8832fd61a6ce80b0a4b93eb5f4c2227936be09f3.scope
    687      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod524c00b2_ccd5_41ea_ad0d_de4ea119c4df.slice/cri-containerd-2a52e1295ce19e34db64622a21a8ed6459144b9c04f68f72a254df56ef4d359b.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1fab0429_62a1_476b_97e5_7ec886a6f4bb.slice/cri-containerd-4fed3b4f8cd08ae8ffd0687ed857a57a3c107d46e31397fec2ee06b2134a6d8d.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1fab0429_62a1_476b_97e5_7ec886a6f4bb.slice/cri-containerd-0e3897711cee9522ee03cbb5eb75337d4a05402d66c1e52f308114a41a53cd8a.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4ab942a_7d64_42f9_bc4d_47e07fadffea.slice/cri-containerd-f12278199d95bf9b9aa042c0d8fc78eb564093a89fc3c7817d456c9c6606d234.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4ab942a_7d64_42f9_bc4d_47e07fadffea.slice/cri-containerd-19498c65f06f1ea91b7c7a01ec84117eec866e9ad3faefd4f2f6c5f719048618.scope
    106      cgroup_device   multi                                          
