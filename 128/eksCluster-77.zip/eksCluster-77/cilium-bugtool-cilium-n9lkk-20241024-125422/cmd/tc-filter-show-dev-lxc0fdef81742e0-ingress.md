filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc0fdef81742e0 direct-action not_in_hw id 507 tag d17ceeea0adbf8c2 jited 
