 12:54:24 up 32 min,  0 users,  load average: 0.57, 0.63, 0.35
