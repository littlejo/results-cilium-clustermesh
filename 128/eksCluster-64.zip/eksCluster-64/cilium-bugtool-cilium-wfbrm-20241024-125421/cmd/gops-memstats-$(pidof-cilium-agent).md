alloc: 126.44MB (132584712 bytes)
total-alloc: 3.10GB (3324743360 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75336410
frees: 74102997
heap-alloc: 126.44MB (132584712 bytes)
heap-sys: 176.70MB (185286656 bytes)
heap-idle: 29.51MB (30941184 bytes)
heap-in-use: 147.20MB (154345472 bytes)
heap-released: 7.98MB (8372224 bytes)
heap-objects: 1233413
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.26MB (2372640 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 998.06KB (1022009 bytes)
gc-sys: 5.55MB (5815440 bytes)
next-gc: when heap-alloc >= 161.17MB (169003128 bytes)
last-gc: 2024-10-24 12:54:22.790786273 +0000 UTC
gc-pause-total: 20.530565ms
gc-pause: 83472
gc-pause-end: 1729774462790786273
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006019881339691611
enable-gc: true
debug-gc: false
