top - 12:54:22 up 32 min,  0 users,  load average: 0.47, 0.48, 0.27
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.8 us, 27.6 sy,  0.0 ni, 58.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    300.1 free,   1041.1 used,   2495.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2614.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 287340  78848 S   0.0   7.3   1:04.75 cilium-+
    395 root      20   0 1229744   8872   2864 S   0.0   0.2   0:04.27 cilium-+
   3189 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3195 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3197 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3215 root      20   0 1240176  16336  11356 S   0.0   0.4   0:00.02 cilium-+
   3261 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3279 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
