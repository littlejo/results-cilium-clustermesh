Total: 562
TCP:   3884 (estab 301, closed 3564, orphaned 0, timewait 3103)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  320       310       10       
INET	  330       316       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:34469      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31505 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.185.56%ens5:68         0.0.0.0:*    uid:192 ino:114819 sk:1002 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32222 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15470 sk:1004 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32221 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15471 sk:1006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::4d3:44ff:fe0e:7a1f]%ens5:546           [::]:*    uid:192 ino:15268 sk:1007 cgroup:unreachable:bd0 v6only:1 <->                   
