IP ADDRESS         LOCAL ENDPOINT INFO
10.64.0.251:0      id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E   
10.64.0.145:0      id=995   sec_id=4     flags=0x0000 ifindex=10  mac=E2:06:58:74:7B:82 nodemac=82:45:7C:BC:60:2F     
10.64.0.98:0       (localhost)                                                                                        
10.64.0.231:0      id=313   sec_id=4272643 flags=0x0000 ifindex=14  mac=5A:C5:DC:CE:F6:B5 nodemac=72:31:CD:27:C1:71   
10.64.0.113:0      id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C   
10.64.0.17:0       id=1325  sec_id=4269890 flags=0x0000 ifindex=18  mac=06:40:36:FA:BC:1C nodemac=36:DF:17:0E:58:D0   
172.31.163.188:0   (localhost)                                                                                        
172.31.185.56:0    (localhost)                                                                                        
10.64.0.169:0      id=2507  sec_id=4272643 flags=0x0000 ifindex=12  mac=4A:50:6E:D3:20:4A nodemac=DA:48:8E:37:69:19   
10.64.0.138:0      id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82   
