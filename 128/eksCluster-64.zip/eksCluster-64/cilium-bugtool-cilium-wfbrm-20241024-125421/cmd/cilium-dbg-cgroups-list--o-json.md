[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc5d77db_7059_4eb2_b051_d225846fae54.slice/cri-containerd-494df949601f5c430ff2391985af7e9295e481a65e04e9d32ea7af52bbb112d9.scope"
      }
    ],
    "ips": [
      "10.64.0.231"
    ],
    "name": "coredns-cc6ccd49c-ktj6c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc1d29991_8020_4922_8e72_8890d7726f43.slice/cri-containerd-0969dcecaf1fe8e7670a38d5fa84c6b02e22b793533c49f2504f5f84bddc0c84.scope"
      }
    ],
    "ips": [
      "10.64.0.169"
    ],
    "name": "coredns-cc6ccd49c-rb9bm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39e2109a_d3c8_45db_8869_9ab8abf8fb21.slice/cri-containerd-f5fc8ca52aeb326272d99aacad6bf5e6a8bb6b5199a8645975204d7d9130c628.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39e2109a_d3c8_45db_8869_9ab8abf8fb21.slice/cri-containerd-128137d62de048816cd5a085fe499bf5c29f5e2b2cc4c96e1cad5c53948e4565.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39e2109a_d3c8_45db_8869_9ab8abf8fb21.slice/cri-containerd-d7a050c2fb724d0e1db4ee4f6636ea550ae62931f89a5c33e1c95876d932c6f5.scope"
      }
    ],
    "ips": [
      "10.64.0.17"
    ],
    "name": "clustermesh-apiserver-85dc9cb995-7rpmr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e06fea2_c27f_47b6_9631_396cd75f5f67.slice/cri-containerd-21c13b3f4cf8e744c41e38bad2444f0beeb91e3cef52be2094407506143b3056.scope"
      }
    ],
    "ips": [
      "10.64.0.138"
    ],
    "name": "client2-57cf4468f-mnxcq",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf032999f_1baf_462b_ba4b_d49f86dcba6b.slice/cri-containerd-81a8bcdab4222847828b44074a4e9b56f62ae144793c68c7d6ef7f258d2dca2f.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf032999f_1baf_462b_ba4b_d49f86dcba6b.slice/cri-containerd-cc676636b135747a5260bf9a7691c9ff76be6bbe54505955bbb9d578b3cb824a.scope"
      }
    ],
    "ips": [
      "10.64.0.113"
    ],
    "name": "echo-same-node-86d9cc975c-5vbcs",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode170f184_285a_4dc2_a3a9_93b214fa429c.slice/cri-containerd-59d5d2bfdfa9a80f3a85372f5b33ac10b22d21e4d681627b42adbba4be5f4b77.scope"
      }
    ],
    "ips": [
      "10.64.0.251"
    ],
    "name": "client-974f6c69d-6p4b7",
    "namespace": "cilium-test-1"
  }
]

