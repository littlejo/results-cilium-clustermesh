1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d3:44:0e:7a:1f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.185.56/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3472sec preferred_lft 3472sec
    inet6 fe80::4d3:44ff:fe0e:7a1f/64 scope link 
       valid_lft forever preferred_lft forever
4: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:9d:1f:3a:a5:c9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.163.188/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::49d:1fff:fe3a:a5c9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:84:55:f7:e7:a1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8484:55ff:fef7:e7a1/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:8b:d0:ed:f0:06 brd ff:ff:ff:ff:ff:ff
    inet 10.64.0.98/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d48b:d0ff:feed:f006/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 46:a6:ee:7e:98:83 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::44a6:eeff:fe7e:9883/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:45:7c:bc:60:2f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8045:7cff:febc:602f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc72b950f15adc@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:48:8e:37:69:19 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d848:8eff:fe37:6919/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3510d5b58c19@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:31:cd:27:c1:71 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::7031:cdff:fe27:c171/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb5640209170e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:df:17:0e:58:d0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::34df:17ff:fe0e:58d0/64 scope link 
       valid_lft forever preferred_lft forever
20: lxca338cee68f35@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:ca:43:bd:b0:9e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d8ca:43ff:febd:b09e/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc8d189a57c89a@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:97:b6:a0:ad:9c brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::1097:b6ff:fea0:ad9c/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcf4f9c5614f92@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:39:db:0b:e7:82 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::a039:dbff:fe0b:e782/64 scope link 
       valid_lft forever preferred_lft forever
