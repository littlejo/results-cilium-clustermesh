key: 23 00 00 00  value: 14 0d 00 00
key: 39 01 00 00  value: 43 02 00 00
key: 94 01 00 00  value: 0e 0d 00 00
key: e3 03 00 00  value: 45 02 00 00
key: 2d 05 00 00  value: 82 02 00 00
key: 42 07 00 00  value: ce 0c 00 00
key: cb 09 00 00  value: 0c 02 00 00
Found 7 elements
