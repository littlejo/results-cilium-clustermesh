KEY             VALUE
AgentLiveness   1968993366569
UTimeOffset     3378461960937500
