xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(4) clsact/ingress cil_from_netdev-ens6 id 562
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 542
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 531
cilium_host(7) clsact/egress cil_from_host-cilium_host id 530
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 569
lxc72b950f15adc(12) clsact/ingress cil_from_container-lxc72b950f15adc id 518
lxc3510d5b58c19(14) clsact/ingress cil_from_container-lxc3510d5b58c19 id 536
lxcb5640209170e(18) clsact/ingress cil_from_container-lxcb5640209170e id 646
lxca338cee68f35(20) clsact/ingress cil_from_container-lxca338cee68f35 id 3350
lxc8d189a57c89a(22) clsact/ingress cil_from_container-lxc8d189a57c89a id 3286
lxcf4f9c5614f92(24) clsact/ingress cil_from_container-lxcf4f9c5614f92 id 3338

flow_dissector:

netfilter:

