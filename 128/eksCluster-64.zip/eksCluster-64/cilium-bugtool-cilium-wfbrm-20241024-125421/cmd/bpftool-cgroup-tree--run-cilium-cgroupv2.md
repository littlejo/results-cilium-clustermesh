CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podce3617d0_4531_4aeb_887a_9a6ef15c272d.slice/cri-containerd-a34a9864ccba7de0af7b9816b695ef20afeff6bcd331a45af422e2d3179b379a.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podce3617d0_4531_4aeb_887a_9a6ef15c272d.slice/cri-containerd-6d250a9d65ec0e0a7e2a567025d12f25f3fafa6b405ef28b16007fa7fdee2bd0.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc1d29991_8020_4922_8e72_8890d7726f43.slice/cri-containerd-0969dcecaf1fe8e7670a38d5fa84c6b02e22b793533c49f2504f5f84bddc0c84.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc1d29991_8020_4922_8e72_8890d7726f43.slice/cri-containerd-7735ddc9ec2f1893e99f2ab47073cbe87ed6d6daeae6a632e974201a1ae2533d.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc5d77db_7059_4eb2_b051_d225846fae54.slice/cri-containerd-c6df04c4f4f9b207254dd4c016fdaa65be868dd32b04ce5dc1a7063ffaa861e6.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc5d77db_7059_4eb2_b051_d225846fae54.slice/cri-containerd-494df949601f5c430ff2391985af7e9295e481a65e04e9d32ea7af52bbb112d9.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0390a8db_e31f_4284_ba5e_9b09d5d4aa15.slice/cri-containerd-b370949e8c0458bc39d81cd0719361cae8730a08f2e17a6ac2bb8609a8e58303.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0390a8db_e31f_4284_ba5e_9b09d5d4aa15.slice/cri-containerd-2ceef765d7dd20e1cb9388209f8b72d09104113d0ea647a02b9a44e4791e91ae.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode170f184_285a_4dc2_a3a9_93b214fa429c.slice/cri-containerd-4bc3831bdbcaa5a9b3b444bc98160bea778f7890c5aba8d7f808c2a174369e3f.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode170f184_285a_4dc2_a3a9_93b214fa429c.slice/cri-containerd-59d5d2bfdfa9a80f3a85372f5b33ac10b22d21e4d681627b42adbba4be5f4b77.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e06fea2_c27f_47b6_9631_396cd75f5f67.slice/cri-containerd-21c13b3f4cf8e744c41e38bad2444f0beeb91e3cef52be2094407506143b3056.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e06fea2_c27f_47b6_9631_396cd75f5f67.slice/cri-containerd-4cbeea7c57434db341b3567132b56f48deab5d38457a3cf230c92da8d45925ee.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf032999f_1baf_462b_ba4b_d49f86dcba6b.slice/cri-containerd-a5830063def8052536fcc5bf024d3041e6502f25e854839b5eba78ec89cd4e44.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf032999f_1baf_462b_ba4b_d49f86dcba6b.slice/cri-containerd-81a8bcdab4222847828b44074a4e9b56f62ae144793c68c7d6ef7f258d2dca2f.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf032999f_1baf_462b_ba4b_d49f86dcba6b.slice/cri-containerd-cc676636b135747a5260bf9a7691c9ff76be6bbe54505955bbb9d578b3cb824a.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ddf0f1e_3baf_4950_bb6f_6f14738e8b41.slice/cri-containerd-7f7c24b209a6bfee82ee790cd5a8ccbc1be1c283f16195365263e55b27d11f3d.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ddf0f1e_3baf_4950_bb6f_6f14738e8b41.slice/cri-containerd-69738ef4149ef2aa700c06571858d2f5c4e06aac1a29e9fbdc5eff6b13ec8914.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39e2109a_d3c8_45db_8869_9ab8abf8fb21.slice/cri-containerd-d7a050c2fb724d0e1db4ee4f6636ea550ae62931f89a5c33e1c95876d932c6f5.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39e2109a_d3c8_45db_8869_9ab8abf8fb21.slice/cri-containerd-128137d62de048816cd5a085fe499bf5c29f5e2b2cc4c96e1cad5c53948e4565.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39e2109a_d3c8_45db_8869_9ab8abf8fb21.slice/cri-containerd-f5fc8ca52aeb326272d99aacad6bf5e6a8bb6b5199a8645975204d7d9130c628.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod39e2109a_d3c8_45db_8869_9ab8abf8fb21.slice/cri-containerd-0fb37859c6da712b835546cfbbabb61dcd9edbe66d71b9f3d112f1d9a49ee588.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd75f86e1_1052_4e40_8dac_8cf0a0b408c3.slice/cri-containerd-68959a4c3093d50b51b148d2fa9e838f18db20b1175ad0c3307f6c23d12fea26.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd75f86e1_1052_4e40_8dac_8cf0a0b408c3.slice/cri-containerd-4866b1c9c8696c3b798d204f2bcf7ae760805ae10c4e2769d3494c212b3223b5.scope
    99       cgroup_device   multi                                          
