{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.124Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.156Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.181Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.389Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.391Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.466Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.495Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.509Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.050Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.064Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.133Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.180Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.232Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.419Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.440Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.478Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.530Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.537Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.174Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.181Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.209Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.226Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.265Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.288Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.314Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.553Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.561Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.612Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.617Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.660Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.271Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.278Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.311Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.313Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.368Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.375Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.404Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.666Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.746Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.849Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.854Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.887Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.219Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.269Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.281Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.316Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.326Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.353Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.559Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.570Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.584Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.630Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.643Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.643Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.670Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.110Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.141Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.156Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.203Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.203Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.218Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.475Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.487Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.523Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.580Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.593Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.973Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.043Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.060Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.127Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.166Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.178Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.349Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.389Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.408Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.452Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.476Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.839Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.874Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.895Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.937Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.938Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.957Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.264Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.265Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.324Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.333Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.361Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.787Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.799Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.841Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.846Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.875Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.186Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.197Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.253Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.298Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.308Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.580Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.628Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.644Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.673Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.688Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.717Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.945Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.964Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.014Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.027Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.056Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.311Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.339Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.354Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.404Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.409Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.438Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.636Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.639Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.670Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.689Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.358Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.360Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.389Z",
  "value": "id=1858  sec_id=4308730 flags=0x0000 ifindex=22  mac=D2:39:4C:F8:D0:4E nodemac=12:97:B6:A0:AD:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.423Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.432Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.731Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.744Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.428Z",
  "value": "id=35    sec_id=4303089 flags=0x0000 ifindex=24  mac=9A:7D:EF:06:B4:10 nodemac=A2:39:DB:0B:E7:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.429Z",
  "value": "id=404   sec_id=4283516 flags=0x0000 ifindex=20  mac=12:9B:23:FC:0B:0B nodemac=DA:CA:43:BD:B0:9E"
}

