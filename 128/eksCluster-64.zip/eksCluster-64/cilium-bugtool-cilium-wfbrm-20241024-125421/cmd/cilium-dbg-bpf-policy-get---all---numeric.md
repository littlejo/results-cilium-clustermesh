Endpoint ID: 35
Path: /sys/fs/bpf/tc/globals/cilium_policy_00035

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 166
Path: /sys/fs/bpf/tc/globals/cilium_policy_00166

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 313
Path: /sys/fs/bpf/tc/globals/cilium_policy_00313

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2884     28        0        
Allow    Ingress     1          ANY          NONE         disabled    147799   1700      0        
Allow    Egress      0          ANY          NONE         disabled    20508    228       0        


Endpoint ID: 404
Path: /sys/fs/bpf/tc/globals/cilium_policy_00404

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 995
Path: /sys/fs/bpf/tc/globals/cilium_policy_00995

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6238190   77114     0        
Allow    Ingress     1          ANY          NONE         disabled    63600     768       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1325
Path: /sys/fs/bpf/tc/globals/cilium_policy_01325

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6119474   61237     0        
Allow    Ingress     1          ANY          NONE         disabled    5443892   57495     0        
Allow    Egress      0          ANY          NONE         disabled    6493541   64492     0        


Endpoint ID: 1858
Path: /sys/fs/bpf/tc/globals/cilium_policy_01858

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382637   4460      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2507
Path: /sys/fs/bpf/tc/globals/cilium_policy_02507

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3012     32        0        
Allow    Ingress     1          ANY          NONE         disabled    147139   1690      0        
Allow    Egress      0          ANY          NONE         disabled    20397    228       0        


