Node 0, zone      DMA    100    122     36     40     18     10      5     10      5      2     38 
Node 0, zone   Normal    137     15      8      2     13      6      2      2      2      2      8 
