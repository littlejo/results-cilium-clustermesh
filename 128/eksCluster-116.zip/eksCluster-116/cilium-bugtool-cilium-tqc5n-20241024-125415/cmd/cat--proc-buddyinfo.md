Node 0, zone      DMA    148     87     32     41     17      4      5      1      2      4     41 
Node 0, zone   Normal    466     85     15     10      5      3      3      3      6      3      6 
