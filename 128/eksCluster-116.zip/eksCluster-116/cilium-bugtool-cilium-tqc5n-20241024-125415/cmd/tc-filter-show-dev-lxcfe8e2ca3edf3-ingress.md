filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcfe8e2ca3edf3 direct-action not_in_hw id 536 tag 088514cf8bc93b20 jited 
