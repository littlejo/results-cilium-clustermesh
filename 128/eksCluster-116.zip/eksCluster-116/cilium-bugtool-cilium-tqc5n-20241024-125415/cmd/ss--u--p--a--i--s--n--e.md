Total: 577
TCP:   4675 (estab 298, closed 4358, orphaned 0, timewait 3893)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  317       308       9        
INET	  327       314       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                  172.31.173.250%ens5:68         0.0.0.0:*    uid:192 ino:158049 sk:2001 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36209 sk:2002 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:39201      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:34929 sk:2003 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15029 sk:2004 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36208 sk:2005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15030 sk:2006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::423:42ff:fe46:5bcf]%ens5:546           [::]:*    uid:192 ino:15279 sk:2007 cgroup:unreachable:bd0 v6only:1 <->                   
