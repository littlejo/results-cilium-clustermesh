IP ADDRESS         LOCAL ENDPOINT INFO
10.116.0.18:0      (localhost)                                                                                        
10.116.0.19:0      id=2335  sec_id=4     flags=0x0000 ifindex=10  mac=92:7A:74:20:73:C7 nodemac=86:18:3B:BB:00:19     
10.116.0.241:0     id=1751  sec_id=7672356 flags=0x0000 ifindex=12  mac=EE:75:1A:A0:88:4A nodemac=A6:98:22:BB:96:3B   
10.116.0.127:0     id=757   sec_id=7672356 flags=0x0000 ifindex=14  mac=C6:94:ED:0D:F7:A3 nodemac=DE:40:01:5F:57:BD   
10.116.0.222:0     id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09   
10.116.0.82:0      id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47   
10.116.0.122:0     id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD   
172.31.173.250:0   (localhost)                                                                                        
10.116.0.20:0      id=1697  sec_id=7680303 flags=0x0000 ifindex=18  mac=DA:7C:A5:18:46:81 nodemac=76:90:A4:61:57:93   
172.31.172.31:0    (localhost)                                                                                        
