top - 12:54:17 up 30 min,  0 users,  load average: 1.03, 0.64, 0.34
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 45.2 us, 48.4 sy,  0.0 ni,  6.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    271.1 free,   1068.4 used,   2496.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2586.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3311 root      20   0 1244340  20320  13120 S  18.8   0.5   0:00.03 hubble
      1 root      20   0 1538804 294268  80220 S   6.2   7.5   1:05.65 cilium-+
   3252 root      20   0 1240432  16208  11228 S   6.2   0.4   0:00.03 cilium-+
    392 root      20   0 1229744   8824   2864 S   0.0   0.2   0:04.32 cilium-+
   3242 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3284 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3290 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3325 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
