CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f913a27_b710_4649_890e_423989e0260c.slice/cri-containerd-31688fa25965b37f4c184a2f697f0926864b8797d74a34af1a043379949718b7.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f913a27_b710_4649_890e_423989e0260c.slice/cri-containerd-99642ec2ac49f3e2e7b5b8456e254c665349aca2e9ff7019878a006ff81a213e.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7061ff4e_bcd7_4f86_bf80_a5aaf3d312e9.slice/cri-containerd-e10e0eb92f70e122d349c49737eedc4e8cb5c9b0a02932f85505b2d34698cc4f.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7061ff4e_bcd7_4f86_bf80_a5aaf3d312e9.slice/cri-containerd-cc50c03bb0388401e64f68d9b214cc064a108939fc96d1880c319ea5674e35aa.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a8864c2_544a_45bc_9687_dff330accaa2.slice/cri-containerd-15cb507f9a687d0db3acb7be5f1f0bd2fcdc912e79c49a01928da37b707d6db2.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a8864c2_544a_45bc_9687_dff330accaa2.slice/cri-containerd-1428b46dea194dcedeb1b45fe98ad134ce94deeb57cd7d4bd8991bd6dcc830d4.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9010090_7235_43e0_a48c_0b895a497af5.slice/cri-containerd-c0bba33104aff0c02c3b8fed448f1d6b86d4adbae1d7f23e3504faceb5f8e9ef.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9010090_7235_43e0_a48c_0b895a497af5.slice/cri-containerd-dafd730fec20195f53312bd7804a62cdc21f76830b6edbfd50f63ba6e8022ae4.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6931c383_ab9a_4a11_ab9a_26ba35e3d5a8.slice/cri-containerd-d8ec4752cbc9c4540c827e57f276bf76ef718b7a164eb473dc37089a28063fef.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6931c383_ab9a_4a11_ab9a_26ba35e3d5a8.slice/cri-containerd-91383f41a7c78e948fee42b921ea4dd9f8f9085567eda0b3ebbcfa9df66fea64.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6931c383_ab9a_4a11_ab9a_26ba35e3d5a8.slice/cri-containerd-93b72f6addd41dc0792ea26303bfed55bf99e7022d5d80f034e8fd3ca141a6ae.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabcc4c68_15f6_4121_b4ca_83ad62b5a277.slice/cri-containerd-c8cf41bdda571ec4ab61049a8ca8cd61ea9c3d046b04dfb878d0caafb0ab00e8.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabcc4c68_15f6_4121_b4ca_83ad62b5a277.slice/cri-containerd-9145cbf1767eb00bb221ad5e8b04dd3a7a5998ab28837832422714185b5a9e6b.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod196e0a90_68f3_4dc5_8990_796e0be72c3d.slice/cri-containerd-8c675a0809b18af48d24da4bef4c815b35fba9e73a09e49bb52af965a54b28b0.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod196e0a90_68f3_4dc5_8990_796e0be72c3d.slice/cri-containerd-2f7728d9997b16ac35248e64c1de75506c36f825d00752decb237bbd7e4fe605.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod196e0a90_68f3_4dc5_8990_796e0be72c3d.slice/cri-containerd-debcd6ed68211fcf97428b2895cece45406204edc59cc5c62b2e40d3da9793d4.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod196e0a90_68f3_4dc5_8990_796e0be72c3d.slice/cri-containerd-f6783702bb158a1adde61e3566301205b941fcda73db614d67d89b6bab0460df.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaeb52237_3986_4db3_b668_1eb0dbd36fd5.slice/cri-containerd-fff86062eeb0f40b89731a6e40216f254ee750f83d49656ecd2e5fc1d886e7b8.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaeb52237_3986_4db3_b668_1eb0dbd36fd5.slice/cri-containerd-a6c418807627ed4cf29b7100f19f1a813675d1dde57474b5f5c96848fce53af6.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23f85126_06e4_4b55_881f_5ccf36b65ef2.slice/cri-containerd-d6cf8741e3380b59ba3fdf6365a23caeece950c4d8d66e1faddcc28ff434afa3.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23f85126_06e4_4b55_881f_5ccf36b65ef2.slice/cri-containerd-91aad7467005d0c1019d177cef0af54c63b617206fc8d528a9d2279074d5f0b5.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66054057_0d3c_47ea_9dee_a13cfe26069b.slice/cri-containerd-17960215e6921d9b984176e229eb02b39bb50237b023996f860f4a175dec0cf6.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66054057_0d3c_47ea_9dee_a13cfe26069b.slice/cri-containerd-3f01060585c3e0fbac31a13ce2206b24d20dd35c0c68a8f76f2280803db2a8c3.scope
    101      cgroup_device   multi                                          
