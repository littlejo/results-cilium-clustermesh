filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc428d333610d1 direct-action not_in_hw id 644 tag 7d2a2ab2e7a6be9b jited 
