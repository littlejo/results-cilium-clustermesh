[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9010090_7235_43e0_a48c_0b895a497af5.slice/cri-containerd-c0bba33104aff0c02c3b8fed448f1d6b86d4adbae1d7f23e3504faceb5f8e9ef.scope"
      }
    ],
    "ips": [
      "10.116.0.127"
    ],
    "name": "coredns-cc6ccd49c-64jrg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23f85126_06e4_4b55_881f_5ccf36b65ef2.slice/cri-containerd-91aad7467005d0c1019d177cef0af54c63b617206fc8d528a9d2279074d5f0b5.scope"
      }
    ],
    "ips": [
      "10.116.0.82"
    ],
    "name": "client-974f6c69d-47prs",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6931c383_ab9a_4a11_ab9a_26ba35e3d5a8.slice/cri-containerd-d8ec4752cbc9c4540c827e57f276bf76ef718b7a164eb473dc37089a28063fef.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6931c383_ab9a_4a11_ab9a_26ba35e3d5a8.slice/cri-containerd-91383f41a7c78e948fee42b921ea4dd9f8f9085567eda0b3ebbcfa9df66fea64.scope"
      }
    ],
    "ips": [
      "10.116.0.222"
    ],
    "name": "echo-same-node-86d9cc975c-92fzm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod196e0a90_68f3_4dc5_8990_796e0be72c3d.slice/cri-containerd-debcd6ed68211fcf97428b2895cece45406204edc59cc5c62b2e40d3da9793d4.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod196e0a90_68f3_4dc5_8990_796e0be72c3d.slice/cri-containerd-8c675a0809b18af48d24da4bef4c815b35fba9e73a09e49bb52af965a54b28b0.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod196e0a90_68f3_4dc5_8990_796e0be72c3d.slice/cri-containerd-2f7728d9997b16ac35248e64c1de75506c36f825d00752decb237bbd7e4fe605.scope"
      }
    ],
    "ips": [
      "10.116.0.20"
    ],
    "name": "clustermesh-apiserver-c58668b98-vh8hc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f913a27_b710_4649_890e_423989e0260c.slice/cri-containerd-31688fa25965b37f4c184a2f697f0926864b8797d74a34af1a043379949718b7.scope"
      }
    ],
    "ips": [
      "10.116.0.241"
    ],
    "name": "coredns-cc6ccd49c-w9sqj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabcc4c68_15f6_4121_b4ca_83ad62b5a277.slice/cri-containerd-c8cf41bdda571ec4ab61049a8ca8cd61ea9c3d046b04dfb878d0caafb0ab00e8.scope"
      }
    ],
    "ips": [
      "10.116.0.122"
    ],
    "name": "client2-57cf4468f-l86qd",
    "namespace": "cilium-test-1"
  }
]

