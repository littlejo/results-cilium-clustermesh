Endpoint ID: 757
Path: /sys/fs/bpf/tc/globals/cilium_policy_00757

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4174     41        0        
Allow    Ingress     1          ANY          NONE         disabled    125056   1437      0        
Allow    Egress      0          ANY          NONE         disabled    18898    208       0        


Endpoint ID: 1338
Path: /sys/fs/bpf/tc/globals/cilium_policy_01338

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1350
Path: /sys/fs/bpf/tc/globals/cilium_policy_01350

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377817   4398      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1697
Path: /sys/fs/bpf/tc/globals/cilium_policy_01697

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6007068   60940     0        
Allow    Ingress     1          ANY          NONE         disabled    5735081   60770     0        
Allow    Egress      0          ANY          NONE         disabled    7659235   74706     0        


Endpoint ID: 1751
Path: /sys/fs/bpf/tc/globals/cilium_policy_01751

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1722     19        0        
Allow    Ingress     1          ANY          NONE         disabled    124528   1429      0        
Allow    Egress      0          ANY          NONE         disabled    17928    197       0        


Endpoint ID: 1924
Path: /sys/fs/bpf/tc/globals/cilium_policy_01924

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2110
Path: /sys/fs/bpf/tc/globals/cilium_policy_02110

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2335
Path: /sys/fs/bpf/tc/globals/cilium_policy_02335

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6209566   76708     0        
Allow    Ingress     1          ANY          NONE         disabled    61024     738       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


