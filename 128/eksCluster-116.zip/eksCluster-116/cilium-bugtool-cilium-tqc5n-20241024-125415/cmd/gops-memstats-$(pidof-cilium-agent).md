alloc: 118.39MB (124145440 bytes)
total-alloc: 3.11GB (3343892912 bytes)
sys: 219.07MB (229713236 bytes)
lookups: 0
mallocs: 75642655
frees: 74406853
heap-alloc: 118.39MB (124145440 bytes)
heap-sys: 172.55MB (180928512 bytes)
heap-idle: 31.80MB (33341440 bytes)
heap-in-use: 140.75MB (147587072 bytes)
heap-released: 4.13MB (4333568 bytes)
heap-objects: 1235802
stack-in-use: 35.41MB (37126144 bytes)
stack-sys: 35.41MB (37126144 bytes)
stack-mspan-inuse: 2.29MB (2405120 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 719.37KB (736633 bytes)
gc-sys: 5.55MB (5817512 bytes)
next-gc: when heap-alloc >= 158.76MB (166470280 bytes)
last-gc: 2024-10-24 12:54:16.705552928 +0000 UTC
gc-pause-total: 17.156539ms
gc-pause: 3951808
gc-pause-end: 1729774456705552928
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0007690819632053391
enable-gc: true
debug-gc: false
