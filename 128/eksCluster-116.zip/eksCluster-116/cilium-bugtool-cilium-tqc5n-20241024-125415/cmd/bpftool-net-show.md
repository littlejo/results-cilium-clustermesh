xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 557
ens6(5) clsact/ingress cil_from_netdev-ens6 id 565
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 540
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 572
lxcfe8e2ca3edf3(12) clsact/ingress cil_from_container-lxcfe8e2ca3edf3 id 536
lxcd4eebf328345(14) clsact/ingress cil_from_container-lxcd4eebf328345 id 568
lxc428d333610d1(18) clsact/ingress cil_from_container-lxc428d333610d1 id 644
lxced0d55d8a2b7(20) clsact/ingress cil_from_container-lxced0d55d8a2b7 id 3361
lxc21712d325bf0(22) clsact/ingress cil_from_container-lxc21712d325bf0 id 3376
lxc5fbc419dc1ee(24) clsact/ingress cil_from_container-lxc5fbc419dc1ee id 3332

flow_dissector:

netfilter:

