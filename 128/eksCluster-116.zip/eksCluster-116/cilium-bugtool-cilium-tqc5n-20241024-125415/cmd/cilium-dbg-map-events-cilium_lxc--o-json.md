{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.279Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.280Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.333Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.343Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.373Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.605Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.615Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.670Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.675Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.747Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.208Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.229Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.267Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.270Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.308Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.564Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.607Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.657Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.667Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.709Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.188Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.196Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.245Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.253Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.293Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.308Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.344Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.558Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.561Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.613Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.625Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.665Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.199Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.203Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.237Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.266Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.291Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.378Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.389Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.592Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.597Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.651Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.663Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.705Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.128Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.149Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.183Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.193Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.220Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.524Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.545Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.573Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.617Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.644Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.044Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.075Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.107Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.175Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.198Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.199Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.439Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.456Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.501Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.516Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.545Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.879Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.915Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.934Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.966Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.987Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.006Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.248Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.272Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.304Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.347Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.348Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.821Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.842Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.897Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.962Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.976Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.194Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.203Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.258Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.299Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.308Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.621Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.659Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.674Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.724Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.738Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.761Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.970Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.997Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.024Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.050Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.073Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.429Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.448Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.505Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.550Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.586Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.768Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.774Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.804Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.849Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.855Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.899Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.177Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.215Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.221Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.265Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.282Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.301Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.532Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.542Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.549Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.556Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.571Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.274Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.278Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.334Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.352Z",
  "value": "id=1350  sec_id=7699116 flags=0x0000 ifindex=24  mac=06:DF:54:63:B9:12 nodemac=F6:BD:35:6E:4A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.406Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.616Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.616Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.319Z",
  "value": "id=2110  sec_id=7707804 flags=0x0000 ifindex=20  mac=A6:46:1F:E6:C2:5B nodemac=02:13:25:0E:DF:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.322Z",
  "value": "id=1338  sec_id=7704195 flags=0x0000 ifindex=22  mac=DE:A3:78:D6:A2:C8 nodemac=FA:B0:6F:30:A5:FD"
}

