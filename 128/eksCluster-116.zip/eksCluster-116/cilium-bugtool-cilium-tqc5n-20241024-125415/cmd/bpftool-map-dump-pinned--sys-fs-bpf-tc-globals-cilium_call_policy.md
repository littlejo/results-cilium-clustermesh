key: f5 02 00 00  value: 37 02 00 00
key: 3a 05 00 00  value: 29 0d 00 00
key: 46 05 00 00  value: f7 0c 00 00
key: a1 06 00 00  value: 83 02 00 00
key: d7 06 00 00  value: 17 02 00 00
key: 3e 08 00 00  value: 2b 0d 00 00
key: 1f 09 00 00  value: 3b 02 00 00
Found 7 elements
