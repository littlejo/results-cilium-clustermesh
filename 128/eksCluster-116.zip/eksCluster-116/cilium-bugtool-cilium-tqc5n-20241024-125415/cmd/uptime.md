 12:54:16 up 30 min,  0 users,  load average: 1.03, 0.64, 0.34
