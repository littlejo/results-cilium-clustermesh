filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd4eebf328345 direct-action not_in_hw id 568 tag f80bef8249a986a9 jited 
