Total: 581
TCP:   1207 (estab 299, closed 889, orphaned 0, timewait 424)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  318       309       9        
INET	  328       315       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                  172.31.199.247%ens5:68         0.0.0.0:*    uid:192 ino:97876 sk:1001 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32935 sk:1002 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15598 sk:1003 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:38067      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=40)) ino:31316 sk:1004 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32934 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15599 sk:1006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::8a2:52ff:fe5f:f2ed]%ens5:546           [::]:*    uid:192 ino:15759 sk:1007 cgroup:unreachable:bd0 v6only:1 <->                   
