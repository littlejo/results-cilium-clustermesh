Endpoint ID: 93
Path: /sys/fs/bpf/tc/globals/cilium_policy_00093

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6211388   76888     0        
Allow    Ingress     1          ANY          NONE         disabled    32810     389       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 423
Path: /sys/fs/bpf/tc/globals/cilium_policy_00423

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5526512   56921     0        
Allow    Ingress     1          ANY          NONE         disabled    5028911   52828     0        
Allow    Egress      0          ANY          NONE         disabled    5940656   60591     0        


Endpoint ID: 806
Path: /sys/fs/bpf/tc/globals/cilium_policy_00806

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 958
Path: /sys/fs/bpf/tc/globals/cilium_policy_00958

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6880     74        0        
Allow    Ingress     1          ANY          NONE         disabled    150521   1727      0        
Allow    Egress      0          ANY          NONE         disabled    20234    224       0        


Endpoint ID: 1428
Path: /sys/fs/bpf/tc/globals/cilium_policy_01428

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1616
Path: /sys/fs/bpf/tc/globals/cilium_policy_01616

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4623     36        0        
Allow    Ingress     1          ANY          NONE         disabled    350249   4082      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1769
Path: /sys/fs/bpf/tc/globals/cilium_policy_01769

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4004     44        0        
Allow    Ingress     1          ANY          NONE         disabled    150870   1737      0        
Allow    Egress      0          ANY          NONE         disabled    21669    242       0        


Endpoint ID: 3475
Path: /sys/fs/bpf/tc/globals/cilium_policy_03475

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


