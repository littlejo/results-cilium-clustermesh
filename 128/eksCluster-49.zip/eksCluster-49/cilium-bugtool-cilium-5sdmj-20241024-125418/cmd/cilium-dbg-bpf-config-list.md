KEY             VALUE
AgentLiveness   1971022299375
UTimeOffset     3378461896484375
