[
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda908d3a0_77f3_4196_8bd0_e8e8973ae037.slice/cri-containerd-6f8b96a1fe9d00a42c044447e61c9c7279cf537e540d6d5c3fc2878c591cd9a9.scope"
      }
    ],
    "ips": [
      "10.49.0.124"
    ],
    "name": "client-974f6c69d-dznwk",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00985550_68f6_4ad2_b987_1124bc78debc.slice/cri-containerd-dd5dcf24f4f3c0201ce856290cf387b8fb9ab369530deb6570f8073ab9cd061c.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00985550_68f6_4ad2_b987_1124bc78debc.slice/cri-containerd-d1a346319012527630b1ad57c1618de358b780e8426b8e609fe78a871bb80dc3.scope"
      }
    ],
    "ips": [
      "10.49.0.170"
    ],
    "name": "echo-same-node-86d9cc975c-jtp4d",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b6f9b2f_e3f5_457f_9509_e5724be0cbc2.slice/cri-containerd-71e6d3c84b5844d5587710e6ba9a0423d2ff5664c8b9279e83c7dc277488b1fd.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b6f9b2f_e3f5_457f_9509_e5724be0cbc2.slice/cri-containerd-00c24ad0425cee8c19cd947931abfd8bfa4c7942ad1d7a296432925e033c3a3a.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b6f9b2f_e3f5_457f_9509_e5724be0cbc2.slice/cri-containerd-897fd45067b274de779a7ebc87e94e64b93ce4b4bcb416ab8768e57f87219007.scope"
      }
    ],
    "ips": [
      "10.49.0.191"
    ],
    "name": "clustermesh-apiserver-57b4b4d8fd-ssxh5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f427242_964b_4560_b01a_1ffde56707ee.slice/cri-containerd-40b9a83776f37fdd9d6bb229dccc3292692c331a7664879789177ba8afa3acd2.scope"
      }
    ],
    "ips": [
      "10.49.0.25"
    ],
    "name": "coredns-cc6ccd49c-jht27",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0cb52ff_10cc_4eb2_a0f7_8a63a9db6e24.slice/cri-containerd-9f0163dcb603c23a1611bc8f403be326cd0a814eb5e750a1ccd276acf4310d03.scope"
      }
    ],
    "ips": [
      "10.49.0.158"
    ],
    "name": "coredns-cc6ccd49c-scvmq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5624470_4d2c_41c6_b046_bd02e1613e9a.slice/cri-containerd-3a590f22623d9a7f71481d24c163f1422e4290522b261961c691323d9158f6a7.scope"
      }
    ],
    "ips": [
      "10.49.0.26"
    ],
    "name": "client2-57cf4468f-n7vpl",
    "namespace": "cilium-test-1"
  }
]

