REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     520730    232086277   1132   bpf_host.c
Interface                   INGRESS     96771     7805218     677    bpf_overlay.c
Policy denied               EGRESS      131       9694        1325   bpf_lxc.c
Policy denied               INGRESS     27        2070        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      137678    18012648    1308   bpf_lxc.c
Success                     EGRESS      20573     1641056     1694   bpf_host.c
Success                     EGRESS      702       169455      86     l3.h
Success                     EGRESS      82360     6661698     53     encap.h
Success                     INGRESS     160504    18064125    86     l3.h
Success                     INGRESS     237929    24427056    235    trace.h
Unsupported L3 protocol     EGRESS      73        5510        1492   bpf_lxc.c
