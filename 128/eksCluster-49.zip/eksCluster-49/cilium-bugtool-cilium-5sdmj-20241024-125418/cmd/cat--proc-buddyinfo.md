Node 0, zone      DMA    132     39      3      7      2      2      4      2      3      3     49 
Node 0, zone   Normal      2     38     17      2     31     23      8      3      3      3      6 
