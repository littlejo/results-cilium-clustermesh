alloc: 72.06MB (75559936 bytes)
total-alloc: 2.70GB (2903995904 bytes)
sys: 211.32MB (221586772 bytes)
lookups: 0
mallocs: 68862314
frees: 68276210
heap-alloc: 72.06MB (75559936 bytes)
heap-sys: 164.75MB (172752896 bytes)
heap-idle: 46.80MB (49070080 bytes)
heap-in-use: 117.95MB (123682816 bytes)
heap-released: 5.12MB (5373952 bytes)
heap-objects: 586104
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.04MB (2138400 bytes)
stack-mspan-sys: 2.71MB (2839680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1057953 bytes)
gc-sys: 5.49MB (5760144 bytes)
next-gc: when heap-alloc >= 147.89MB (155071544 bytes)
last-gc: 2024-10-24 12:54:14.986504032 +0000 UTC
gc-pause-total: 12.848303ms
gc-pause: 59650
gc-pause-end: 1729774454986504032
num-gc: 96
num-forced-gc: 0
gc-cpu-fraction: 0.0005327853059164451
enable-gc: true
debug-gc: false
