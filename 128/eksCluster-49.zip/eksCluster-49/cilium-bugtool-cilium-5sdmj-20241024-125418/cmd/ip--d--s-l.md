1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00 promiscuity 0 minmtu 0 maxmtu 0 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       6569392   52530      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       6569392   52530      0       0       0       0 
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 0a:a2:52:5f:f2:ed brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 128 maxmtu 9216 addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:05.0 
    RX:  bytes packets errors dropped  missed   mcast           
     708663927  731999      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      39163599  313330      0       0       0       0 
    altname enp0s5
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 0a:c0:76:68:83:19 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 128 maxmtu 9216 addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:06.0 
    RX:  bytes packets errors dropped  missed   mcast           
           868      31      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          2448      46      0       0       0       0 
    altname enp0s6
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 1a:1c:d0:d6:59:e4 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         43990     649      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       1598000   19935      0       0       0       0 
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 2a:fa:19:37:f3:a3 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1598000   19935      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         43990     649      0       0       0       0 
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/ether aa:a3:e7:9a:e2:15 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    vxlan external id 0 srcport 0 0 dstport 8472 nolearning ttl auto ageing 300 udpcsum noudp6zerocsumtx noudp6zerocsumrx addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       6446714   96711      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       5505780   82313      0       0       0       0 
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 2a:98:da:75:f9:7a brd ff:ff:ff:ff:ff:ff link-netnsid 1 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       4509622   55511      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       6237922   77201      0       0       0       0 
12: lxc204735149967@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 0e:98:55:15:51:31 brd ff:ff:ff:ff:ff:ff link-netnsid 0 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        171383    1713      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        229531    2011      0       0       0       0 
14: lxca9874c80f4b3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ae:91:a6:6e:61:2f brd ff:ff:ff:ff:ff:ff link-netnsid 2 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        167119    1694      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        228014    2000      0       0       0       0 
18: lxc9c11f269d6b1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ce:b3:d5:a5:ae:cf brd ff:ff:ff:ff:ff:ff link-netnsid 4 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      15631738  125869      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      16257471  146254      0       0       0       0 
20: lxc318c19e9a655@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 1a:bc:88:f2:be:fc brd ff:ff:ff:ff:ff:ff link-netnsid 3 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         47419     504      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        180452     327      0       0       0       0 
22: lxc3bf8f52f4206@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether de:a4:e1:fa:21:1e brd ff:ff:ff:ff:ff:ff link-netnsid 5 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1226885    3208      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        375185    4365      0       0       0       0 
24: lxc6b90e67228a1@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether da:27:d0:72:ab:2f brd ff:ff:ff:ff:ff:ff link-netnsid 6 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         54612     585      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        213342     391      0       0       0       0 
