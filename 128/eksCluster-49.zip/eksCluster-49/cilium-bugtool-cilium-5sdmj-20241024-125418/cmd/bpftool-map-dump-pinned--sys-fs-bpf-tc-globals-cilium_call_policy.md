key: 5d 00 00 00  value: 42 02 00 00
key: a7 01 00 00  value: 86 02 00 00
key: be 03 00 00  value: 19 02 00 00
key: 94 05 00 00  value: 96 0e 00 00
key: 50 06 00 00  value: 61 0d 00 00
key: e9 06 00 00  value: 23 02 00 00
key: 93 0d 00 00  value: 92 0e 00 00
Found 7 elements
