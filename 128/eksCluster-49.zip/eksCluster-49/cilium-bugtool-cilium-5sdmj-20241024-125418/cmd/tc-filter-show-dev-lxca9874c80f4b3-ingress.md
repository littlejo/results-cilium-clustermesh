filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca9874c80f4b3 direct-action not_in_hw id 576 tag 2c24cbc48ed88e56 jited 
