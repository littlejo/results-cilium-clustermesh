USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        2910  0.0  0.4 1240432 16192 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        2935  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        2936  0.0  0.0   2068   224 ?        R    12:54   0:00  \_ hostname
root           1  4.0  7.2 1539060 284888 ?      Ssl  12:27   1:03 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.2  0.2 1229744 10204 ?       Sl   12:27   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
