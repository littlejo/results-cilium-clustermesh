1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a2:52:5f:f2:ed brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.199.247/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3442sec preferred_lft 3442sec
    inet6 fe80::8a2:52ff:fe5f:f2ed/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c0:76:68:83:19 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.226.91/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8c0:76ff:fe68:8319/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:1c:d0:d6:59:e4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::181c:d0ff:fed6:59e4/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:fa:19:37:f3:a3 brd ff:ff:ff:ff:ff:ff
    inet 10.49.0.117/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::28fa:19ff:fe37:f3a3/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether aa:a3:e7:9a:e2:15 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a8a3:e7ff:fe9a:e215/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:98:da:75:f9:7a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2898:daff:fe75:f97a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc204735149967@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:98:55:15:51:31 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c98:55ff:fe15:5131/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca9874c80f4b3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:91:a6:6e:61:2f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ac91:a6ff:fe6e:612f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc9c11f269d6b1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:b3:d5:a5:ae:cf brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ccb3:d5ff:fea5:aecf/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc318c19e9a655@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:bc:88:f2:be:fc brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::18bc:88ff:fef2:befc/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc3bf8f52f4206@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:a4:e1:fa:21:1e brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::dca4:e1ff:fefa:211e/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc6b90e67228a1@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:27:d0:72:ab:2f brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::d827:d0ff:fe72:ab2f/64 scope link 
       valid_lft forever preferred_lft forever
