xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 558
ens6(5) clsact/ingress cil_from_netdev-ens6 id 568
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 552
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 545
cilium_host(7) clsact/egress cil_from_host-cilium_host id 544
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 587
lxc204735149967(12) clsact/ingress cil_from_container-lxc204735149967 id 530
lxca9874c80f4b3(14) clsact/ingress cil_from_container-lxca9874c80f4b3 id 576
lxc9c11f269d6b1(18) clsact/ingress cil_from_container-lxc9c11f269d6b1 id 651
lxc318c19e9a655(20) clsact/ingress cil_from_container-lxc318c19e9a655 id 3720
lxc3bf8f52f4206(22) clsact/ingress cil_from_container-lxc3bf8f52f4206 id 3416
lxc6b90e67228a1(24) clsact/ingress cil_from_container-lxc6b90e67228a1 id 3713

flow_dissector:

netfilter:

