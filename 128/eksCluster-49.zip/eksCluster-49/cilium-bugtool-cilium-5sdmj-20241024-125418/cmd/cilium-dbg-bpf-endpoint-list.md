IP ADDRESS         LOCAL ENDPOINT INFO
10.49.0.191:0      id=423   sec_id=3290959 flags=0x0000 ifindex=18  mac=D6:9E:4E:94:6C:6A nodemac=CE:B3:D5:A5:AE:CF   
10.49.0.170:0      id=1616  sec_id=3282945 flags=0x0000 ifindex=22  mac=46:D7:A0:B2:B6:31 nodemac=DE:A4:E1:FA:21:1E   
172.31.226.91:0    (localhost)                                                                                        
10.49.0.26:0       id=1428  sec_id=3284969 flags=0x0000 ifindex=24  mac=86:46:71:8C:C0:BF nodemac=DA:27:D0:72:AB:2F   
10.49.0.70:0       id=93    sec_id=4     flags=0x0000 ifindex=10  mac=EA:39:17:B5:B0:03 nodemac=2A:98:DA:75:F9:7A     
172.31.199.247:0   (localhost)                                                                                        
10.49.0.117:0      (localhost)                                                                                        
10.49.0.25:0       id=1769  sec_id=3293253 flags=0x0000 ifindex=14  mac=8E:3A:D8:51:EF:10 nodemac=AE:91:A6:6E:61:2F   
10.49.0.158:0      id=958   sec_id=3293253 flags=0x0000 ifindex=12  mac=32:6E:05:6F:EF:AB nodemac=0E:98:55:15:51:31   
10.49.0.124:0      id=3475  sec_id=3312826 flags=0x0000 ifindex=20  mac=0E:F4:83:5A:3E:CC nodemac=1A:BC:88:F2:BE:FC   
