CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48652ff6_9ee2_4c44_b0e1_ee00bc4dce82.slice/cri-containerd-a8c1cec983cf54acea904d2862f00f5a908a2cfcbcb93b6bc389c75791e5e7dd.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48652ff6_9ee2_4c44_b0e1_ee00bc4dce82.slice/cri-containerd-9749c74a1d7788398eb16a7601e77387cdafde880af9d3cbdbf4c465b76ec3e7.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f427242_964b_4560_b01a_1ffde56707ee.slice/cri-containerd-40b9a83776f37fdd9d6bb229dccc3292692c331a7664879789177ba8afa3acd2.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f427242_964b_4560_b01a_1ffde56707ee.slice/cri-containerd-19dada39eaadf320f903ec2b95927649507feda11cc1b5264519ace88b59eed8.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod61736bf4_6db5_434a_a451_da49d285375e.slice/cri-containerd-7f40ea95d008d40a1cc70320f340a927e351fe7bc2bff977fc62f5d5388ff474.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod61736bf4_6db5_434a_a451_da49d285375e.slice/cri-containerd-d49850ec18f2eaebb26dff79768fc36236dcaa320602ddbb0fb6079526c26520.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0cb52ff_10cc_4eb2_a0f7_8a63a9db6e24.slice/cri-containerd-9f0163dcb603c23a1611bc8f403be326cd0a814eb5e750a1ccd276acf4310d03.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0cb52ff_10cc_4eb2_a0f7_8a63a9db6e24.slice/cri-containerd-ab98d7d4dd590b75defb0d3c9abac965fbd4746e54f7f30418f2afa89ff3006e.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca936016_700b_4e97_82e6_ad98425aef3a.slice/cri-containerd-d2c8d41192551745596241a3bc108ca50705857a73bd76a2359a233197daafaa.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca936016_700b_4e97_82e6_ad98425aef3a.slice/cri-containerd-90261383e1cb8ca47547a85888073d75d232d050d8582a5e71df08b8e8311ec0.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00985550_68f6_4ad2_b987_1124bc78debc.slice/cri-containerd-dd5dcf24f4f3c0201ce856290cf387b8fb9ab369530deb6570f8073ab9cd061c.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00985550_68f6_4ad2_b987_1124bc78debc.slice/cri-containerd-d1a346319012527630b1ad57c1618de358b780e8426b8e609fe78a871bb80dc3.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00985550_68f6_4ad2_b987_1124bc78debc.slice/cri-containerd-e07678b0e65e6cb8c1571da42bd797233cab1ac98c2185b2fc6b06cc044782ff.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b6f9b2f_e3f5_457f_9509_e5724be0cbc2.slice/cri-containerd-31c7efa16e739fdbe7ab5a4a48dc35d0d6ccd9e2e2c51de8372ebe1c1582c5fa.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b6f9b2f_e3f5_457f_9509_e5724be0cbc2.slice/cri-containerd-897fd45067b274de779a7ebc87e94e64b93ce4b4bcb416ab8768e57f87219007.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b6f9b2f_e3f5_457f_9509_e5724be0cbc2.slice/cri-containerd-00c24ad0425cee8c19cd947931abfd8bfa4c7942ad1d7a296432925e033c3a3a.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b6f9b2f_e3f5_457f_9509_e5724be0cbc2.slice/cri-containerd-71e6d3c84b5844d5587710e6ba9a0423d2ff5664c8b9279e83c7dc277488b1fd.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda908d3a0_77f3_4196_8bd0_e8e8973ae037.slice/cri-containerd-dc2c768fe17f5bb87997dd07ac43dbde3e59558e5d216c5a9e3822275d1bbe57.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda908d3a0_77f3_4196_8bd0_e8e8973ae037.slice/cri-containerd-6f8b96a1fe9d00a42c044447e61c9c7279cf537e540d6d5c3fc2878c591cd9a9.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5624470_4d2c_41c6_b046_bd02e1613e9a.slice/cri-containerd-3a590f22623d9a7f71481d24c163f1422e4290522b261961c691323d9158f6a7.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5624470_4d2c_41c6_b046_bd02e1613e9a.slice/cri-containerd-7f62d683237388f62d7d2aba5b7f4a8a69f6267a3c873e3c6b58168b1e56dc0e.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d698ab3_e4da_4b5c_b9b5_e9e209d6327e.slice/cri-containerd-6855c8bff579891a780da2e4a87786757153c87f6cb1012a480f60a3c9212c61.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d698ab3_e4da_4b5c_b9b5_e9e209d6327e.slice/cri-containerd-d6e742615ef13071729b06ff506d2041f73eec4eab8ef221ff2693f76f32d5ea.scope
    101      cgroup_device   multi                                          
