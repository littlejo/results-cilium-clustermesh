35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:34+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:34+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:35+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:35+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:35+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:35+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:27:58+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:27:58+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:27:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag f8f23421c6a234c5  gpl
	loaded_at 2024-10-24T12:27:58+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
518: sched_cls  name tail_handle_ipv4_cont  tag ab024a3c9f95b954  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 163
521: sched_cls  name tail_ipv4_ct_ingress  tag 6633d78f9a8473bb  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 166
524: sched_cls  name tail_handle_ipv4  tag edf0d906b4eb77d7  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 170
525: sched_cls  name __send_drop_notify  tag bc2a11fca6f247e4  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 172
527: sched_cls  name tail_ipv4_ct_egress  tag 1cb6108fd9d34d6d  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 173
529: sched_cls  name tail_ipv4_to_endpoint  tag a50f3c17bae8b44e  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 175
530: sched_cls  name cil_from_container  tag 22ce5b6cfe1b2454  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 177
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 183
537: sched_cls  name handle_policy  tag ef460342b3b40e3b  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 178
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 186
539: sched_cls  name tail_handle_arp  tag 5ab24651005015f5  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 187
542: sched_cls  name tail_handle_ipv4_from_host  tag 7b1c1ff17fd1e3aa  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 191
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 192
544: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 193
545: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 194
546: sched_cls  name __send_drop_notify  tag 448a584ab404d33b  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
547: sched_cls  name handle_policy  tag 3ad27fc1ae5858d1  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 185
549: sched_cls  name tail_handle_ipv4_from_host  tag 7b1c1ff17fd1e3aa  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 199
550: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 200
552: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
553: sched_cls  name tail_ipv4_ct_egress  tag 1cb6108fd9d34d6d  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 196
554: sched_cls  name __send_drop_notify  tag 448a584ab404d33b  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
557: sched_cls  name __send_drop_notify  tag 448a584ab404d33b  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 208
558: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 209
560: sched_cls  name tail_handle_ipv4_from_host  tag 7b1c1ff17fd1e3aa  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 211
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 212
563: sched_cls  name tail_handle_ipv4_from_host  tag 7b1c1ff17fd1e3aa  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 215
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 216
567: sched_cls  name __send_drop_notify  tag 448a584ab404d33b  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
568: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 220
570: sched_cls  name tail_handle_ipv4  tag fd44d04a81a7eb01  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 204
571: sched_cls  name tail_handle_arp  tag e79ea3329f3bf34d  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 224
572: sched_cls  name __send_drop_notify  tag 444a6baaaf2a893f  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 225
573: sched_cls  name tail_handle_ipv4_cont  tag 4319206942af6dc1  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 226
574: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 223
575: sched_cls  name tail_ipv4_ct_ingress  tag ac27b26d3ca7711d  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 227
576: sched_cls  name cil_from_container  tag 2c24cbc48ed88e56  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 229
577: sched_cls  name tail_ipv4_to_endpoint  tag 511deab29008b321  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 230
578: sched_cls  name handle_policy  tag 9804e6a1016ac688  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 228
579: sched_cls  name tail_ipv4_to_endpoint  tag 18164452a15a8418  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 231
580: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 232
581: sched_cls  name tail_handle_ipv4_cont  tag 69520264fa3a2384  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 233
582: sched_cls  name tail_handle_ipv4  tag 60f65e5a48ef096a  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 234
583: sched_cls  name __send_drop_notify  tag a7586061cfa50f91  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
584: sched_cls  name tail_ipv4_ct_ingress  tag cb0138ee54e4e7ba  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 236
586: sched_cls  name tail_handle_arp  tag 0166b2cef6895177  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 238
587: sched_cls  name cil_from_container  tag bb2212d8ec84a3ea  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 239
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name __send_drop_notify  tag 54fcfbc2caa43cf7  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 253
644: sched_cls  name tail_handle_ipv4_cont  tag 960dfd236b4ba79d  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 254
645: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 255
646: sched_cls  name handle_policy  tag d4a937c162722ead  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 256
647: sched_cls  name tail_ipv4_ct_ingress  tag ce2b4326249234b9  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 257
648: sched_cls  name tail_ipv4_to_endpoint  tag 3d5aa4d26e2dc318  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 258
649: sched_cls  name tail_ipv4_ct_egress  tag a278abdac971beb3  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 259
650: sched_cls  name tail_handle_ipv4  tag 1d1f4a475853671a  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 260
651: sched_cls  name cil_from_container  tag b8ad6118488d36ad  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 261
653: sched_cls  name tail_handle_arp  tag 3f80e42160fed3de  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
723: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
726: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
727: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
730: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
731: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
734: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
735: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
738: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
739: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
742: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3416: sched_cls  name cil_from_container  tag d5727546097bed39  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 653,76
	btf_id 3217
3417: sched_cls  name tail_handle_ipv4_cont  tag 9dc90b421ad78732  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,654,41,154,82,83,39,76,74,77,653,40,37,38,81
	btf_id 3218
3418: sched_cls  name tail_handle_arp  tag dfeb65c9f9432904  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,653
	btf_id 3219
3419: sched_cls  name tail_ipv4_ct_ingress  tag a1424629a24302b6  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,653,82,83,654,84
	btf_id 3220
3420: sched_cls  name __send_drop_notify  tag 056ebb9077cd212c  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3221
3421: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,653
	btf_id 3222
3422: sched_cls  name tail_handle_ipv4  tag 809dcbecddb169db  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,653
	btf_id 3223
3424: sched_cls  name tail_ipv4_to_endpoint  tag 9c5c3032b942daef  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,654,41,82,83,80,154,39,653,40,37,38
	btf_id 3225
3425: sched_cls  name handle_policy  tag 69fb6dd527137dc6  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,653,82,83,654,41,80,154,39,84,75,40,37,38
	btf_id 3226
3426: sched_cls  name tail_ipv4_ct_egress  tag 03e0e6ad35e6d1fa  gpl
	loaded_at 2024-10-24T12:52:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,653,82,83,654,84
	btf_id 3227
3713: sched_cls  name cil_from_container  tag 5f02126f1d105eea  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 708,76
	btf_id 3541
3714: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,708
	btf_id 3544
3715: sched_cls  name tail_ipv4_ct_egress  tag f8f4e660369e5c69  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,710,82,83,709,84
	btf_id 3543
3716: sched_cls  name tail_handle_ipv4_cont  tag 2ed53f00008cfbbe  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,707,41,155,82,83,39,76,74,77,708,40,37,38,81
	btf_id 3545
3717: sched_cls  name tail_handle_arp  tag 2059b2ecac7a18de  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,708
	btf_id 3547
3718: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,710
	btf_id 3546
3719: sched_cls  name tail_ipv4_ct_ingress  tag 015d227700a1b216  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,710,82,83,709,84
	btf_id 3549
3720: sched_cls  name cil_from_container  tag a0a0403204ac2175  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 710,76
	btf_id 3550
3721: sched_cls  name __send_drop_notify  tag 09b38df73c6291c8  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3551
3722: sched_cls  name tail_handle_ipv4  tag 9153dc9f33311186  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,708
	btf_id 3548
3723: sched_cls  name __send_drop_notify  tag 56dfa07b97858329  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3553
3724: sched_cls  name tail_ipv4_to_endpoint  tag 11cea7104b547338  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,707,41,82,83,80,155,39,708,40,37,38
	btf_id 3554
3725: sched_cls  name tail_ipv4_to_endpoint  tag 004108e11f6f4e5a  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,709,41,82,83,80,151,39,710,40,37,38
	btf_id 3552
3727: sched_cls  name tail_ipv4_ct_egress  tag 137e4029ae79c705  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,708,82,83,707,84
	btf_id 3556
3728: sched_cls  name tail_ipv4_ct_ingress  tag 8475104d93e1d871  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,708,82,83,707,84
	btf_id 3558
3730: sched_cls  name handle_policy  tag 9bca3e81fbcc6322  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,710,82,83,709,41,80,151,39,84,75,40,37,38
	btf_id 3557
3731: sched_cls  name tail_handle_ipv4  tag 6ce974a5047e122e  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,710
	btf_id 3561
3732: sched_cls  name tail_handle_ipv4_cont  tag f6617cb847c8f0f4  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,709,41,151,82,83,39,76,74,77,710,40,37,38,81
	btf_id 3562
3733: sched_cls  name tail_handle_arp  tag b8e68771a6e0c14a  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,710
	btf_id 3563
3734: sched_cls  name handle_policy  tag 7941c1ec095e308d  gpl
	loaded_at 2024-10-24T12:53:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,708,82,83,707,41,80,155,39,84,75,40,37,38
	btf_id 3560
