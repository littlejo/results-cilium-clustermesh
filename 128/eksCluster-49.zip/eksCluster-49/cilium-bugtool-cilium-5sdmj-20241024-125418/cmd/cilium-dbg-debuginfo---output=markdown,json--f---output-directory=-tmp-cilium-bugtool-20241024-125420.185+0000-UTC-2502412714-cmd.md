markdown output at /tmp/cilium-bugtool-20241024-125420.185+0000-UTC-2502412714/cmd/cilium-debuginfo-20241024-125421.169+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125420.185+0000-UTC-2502412714/cmd/cilium-debuginfo-20241024-125421.169+0000-UTC.json
