top - 12:54:20 up 32 min,  0 users,  load average: 0.47, 0.61, 0.35
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 32.1 us, 25.0 sy,  0.0 ni, 42.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    305.7 free,   1036.3 used,   2494.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2618.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 287552  79356 S  33.3   7.3   1:03.85 cilium-+
    415 root      20   0 1229744  10204   4028 S   0.0   0.3   0:04.51 cilium-+
   2910 root      20   0 1240432  16192  11164 S   0.0   0.4   0:00.02 cilium-+
   2946 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   2970 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
