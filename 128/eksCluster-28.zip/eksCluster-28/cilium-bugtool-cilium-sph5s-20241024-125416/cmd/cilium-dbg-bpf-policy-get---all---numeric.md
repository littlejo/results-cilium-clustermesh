Endpoint ID: 371
Path: /sys/fs/bpf/tc/globals/cilium_policy_00371

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1234
Path: /sys/fs/bpf/tc/globals/cilium_policy_01234

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1274
Path: /sys/fs/bpf/tc/globals/cilium_policy_01274

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2934     30        0        
Allow    Ingress     1          ANY          NONE         disabled    162808   1874      0        
Allow    Egress      0          ANY          NONE         disabled    20357    228       0        


Endpoint ID: 1755
Path: /sys/fs/bpf/tc/globals/cilium_policy_01755

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378278   4413      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2071
Path: /sys/fs/bpf/tc/globals/cilium_policy_02071

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2159
Path: /sys/fs/bpf/tc/globals/cilium_policy_02159

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2962     30        0        
Allow    Ingress     1          ANY          NONE         disabled    160165   1839      0        
Allow    Egress      0          ANY          NONE         disabled    21050    234       0        


Endpoint ID: 2924
Path: /sys/fs/bpf/tc/globals/cilium_policy_02924

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6065338   61325     0        
Allow    Ingress     1          ANY          NONE         disabled    5369076   56746     0        
Allow    Egress      0          ANY          NONE         disabled    7186294   70542     0        


Endpoint ID: 3492
Path: /sys/fs/bpf/tc/globals/cilium_policy_03492

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6218961   77002     0        
Allow    Ingress     1          ANY          NONE         disabled    64842     783       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


