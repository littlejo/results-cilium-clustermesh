markdown output at /tmp/cilium-bugtool-20241024-125417.941+0000-UTC-1174918418/cmd/cilium-debuginfo-20241024-125448.84+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.941+0000-UTC-1174918418/cmd/cilium-debuginfo-20241024-125448.84+0000-UTC.json
