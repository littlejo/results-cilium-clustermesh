filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc11c76c6170f3 direct-action not_in_hw id 3281 tag 8f3ff6aacdbd59b5 jited 
