{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.041Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.076Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.110Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.118Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.144Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.300Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.300Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.364Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.367Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.417Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.010Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.056Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.069Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.109Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.116Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.339Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.346Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.396Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.432Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.436Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.984Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.985Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.041Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.041Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.118Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.192Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.203Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.409Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.414Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.472Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.480Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.521Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.129Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.136Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.169Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.177Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.237Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.247Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.270Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.523Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.548Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.581Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.596Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.625Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.066Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.079Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.124Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.137Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.163Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.394Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.458Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.523Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.583Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.588Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.986Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.016Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.025Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.077Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.083Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.111Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.335Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.354Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.397Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.415Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.440Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.825Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.852Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.867Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.916Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.928Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.953Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.212Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.248Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.266Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.313Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.322Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.776Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.826Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.890Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.901Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.950Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.166Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.184Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.234Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.240Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.272Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.639Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.679Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.681Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.729Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.735Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.762Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.991Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.003Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.024Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.061Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.090Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.090Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.112Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.415Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.416Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.469Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.472Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.507Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.736Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.817Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.835Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.904Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.907Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.118Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.152Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.159Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.205Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.224Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.238Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.449Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.474Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.479Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.509Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.167Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.168Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.218Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.222Z",
  "value": "id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.253Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.530Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.534Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:39.223Z",
  "value": "id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:39.224Z",
  "value": "id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C"
}

