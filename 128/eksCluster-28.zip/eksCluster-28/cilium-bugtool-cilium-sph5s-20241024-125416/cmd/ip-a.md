1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2e:a4:14:88:2d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.133.133/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3415sec preferred_lft 3415sec
    inet6 fe80::42e:a4ff:fe14:882d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:55:ef:ec:74:39 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.148.253/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::455:efff:feec:7439/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:e2:99:95:ab:e6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c0e2:99ff:fe95:abe6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:9b:7f:23:62:e0 brd ff:ff:ff:ff:ff:ff
    inet 10.28.0.64/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5c9b:7fff:fe23:62e0/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:ec:2c:41:71:3a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::94ec:2cff:fe41:713a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:3e:4c:ca:98:97 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b03e:4cff:feca:9897/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc880c0a25e569@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:6a:26:36:c8:2e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::586a:26ff:fe36:c82e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc82758187a16b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:c3:96:93:8b:2c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::ccc3:96ff:fe93:8b2c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4a5d38b02c05@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:c4:2b:ec:2d:1f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9cc4:2bff:feec:2d1f/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc122e7f182f72@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:0e:d2:e5:3e:7c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3c0e:d2ff:fee5:3e7c/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc918e9b66346a@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:2f:bc:ce:ec:9f brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::b02f:bcff:fece:ec9f/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc11c76c6170f3@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:0b:88:e7:03:44 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::300b:88ff:fee7:344/64 scope link 
       valid_lft forever preferred_lft forever
