 12:54:18 up 33 min,  0 users,  load average: 0.40, 0.68, 0.42
