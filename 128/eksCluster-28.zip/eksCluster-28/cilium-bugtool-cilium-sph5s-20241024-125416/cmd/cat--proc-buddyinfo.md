Node 0, zone      DMA      2      1     13     14      7     10      8      3      0      1     41 
Node 0, zone   Normal   1385    378     57      4      6      4      1      1      5      1      6 
