top - 12:54:18 up 33 min,  0 users,  load average: 0.40, 0.68, 0.42
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.0 us, 23.3 sy,  0.0 ni, 36.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    282.8 free,   1056.3 used,   2497.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2598.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 294892  79084 S  26.7   7.5   1:05.38 cilium-+
    406 root      20   0 1229744   9948   3900 S   0.0   0.3   0:04.17 cilium-+
   3200 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3204 root      20   0 1240432  15656  10640 S   0.0   0.4   0:00.03 cilium-+
   3212 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3222 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3264 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3277 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3293 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
