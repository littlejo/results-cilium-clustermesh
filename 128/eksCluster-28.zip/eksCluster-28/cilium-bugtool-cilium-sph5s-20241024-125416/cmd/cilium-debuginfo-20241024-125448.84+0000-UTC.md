# Cilium debug information

#### Policy get

```
:
 []
Revision: 129

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=11) "10.28.0.179": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-5j5mh",
  (string) (len=10) "10.28.0.64": (string) (len=6) "router",
  (string) (len=10) "10.28.0.79": (string) (len=6) "health",
  (string) (len=11) "10.28.0.252": (string) (len=35) "kube-system/coredns-cc6ccd49c-q4zrg",
  (string) (len=10) "10.28.0.63": (string) (len=35) "kube-system/coredns-cc6ccd49c-h976j",
  (string) (len=11) "10.28.0.101": (string) (len=36) "cilium-test-1/client-974f6c69d-pr25w",
  (string) (len=11) "10.28.0.104": (string) (len=50) "kube-system/clustermesh-apiserver-6464c7d796-cvmtw",
  (string) (len=11) "10.28.0.140": (string) (len=37) "cilium-test-1/client2-57cf4468f-ks4cd"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.133.133": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4002219290)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40002471a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40002471a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40021c6fd0)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40036280b0)(frontends:[]/ports=[kvmesh-metrics etcd-metrics apiserv-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4003628160)(frontends:[10.100.78.87]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x4009aefb80)(frontends:[10.100.8.232]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40021c6e70)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40021c6f20)(frontends:[10.100.12.132]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40011307c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40016e7450)(172.31.191.56:443/TCP,172.31.216.181:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40011307d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-d595f": (*k8s.Endpoints)(0x4000f7b5f0)(172.31.133.133:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40011307d8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-nvhkj": (*k8s.Endpoints)(0x4003a94a90)(10.28.0.252:53/TCP[eu-west-3a],10.28.0.252:53/UDP[eu-west-3a],10.28.0.252:9153/TCP[eu-west-3a],10.28.0.63:53/TCP[eu-west-3a],10.28.0.63:53/UDP[eu-west-3a],10.28.0.63:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000838510)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-n6b8h": (*k8s.Endpoints)(0x4003a94f70)(10.28.0.104:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x4000f5fc68)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-2lt4k": (*k8s.Endpoints)(0x4003e42ea0)(10.28.0.179:8080/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400028f340)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000c4ca50)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400aebe9a8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4000a412c0,
  gcExited: (chan struct {}) 0x4000a41320,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x400011b180)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015a2928)({
      MetricVec: (*prometheus.MetricVec)(0x400100e960)({
       metricMap: (*prometheus.metricMap)(0x400100e990)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177f1a0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x400011b200)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015a2930)({
      MetricVec: (*prometheus.MetricVec)(0x400100e9f0)({
       metricMap: (*prometheus.metricMap)(0x400100ea20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177f200)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x400011b280)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015a2948)({
      MetricVec: (*prometheus.MetricVec)(0x400100ea80)({
       metricMap: (*prometheus.metricMap)(0x400100eab0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177f260)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x400011b300)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015a2950)({
      MetricVec: (*prometheus.MetricVec)(0x400100eb10)({
       metricMap: (*prometheus.metricMap)(0x400100eb40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177f2c0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x400011b380)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015a2968)({
      MetricVec: (*prometheus.MetricVec)(0x400100eba0)({
       metricMap: (*prometheus.metricMap)(0x400100ebd0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177f320)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x400011b400)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015a2970)({
      MetricVec: (*prometheus.MetricVec)(0x400100ec30)({
       metricMap: (*prometheus.metricMap)(0x400100ec60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177f380)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x400011b480)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015a2978)({
      MetricVec: (*prometheus.MetricVec)(0x400100ecc0)({
       metricMap: (*prometheus.metricMap)(0x400100ecf0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177f3e0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x400011b500)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015a2980)({
      MetricVec: (*prometheus.MetricVec)(0x400100ed50)({
       metricMap: (*prometheus.metricMap)(0x400100ed80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177f440)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x400011b580)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015a2988)({
      MetricVec: (*prometheus.MetricVec)(0x400100ee10)({
       metricMap: (*prometheus.metricMap)(0x400100ee40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177f4a0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400028f340)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40006d01c0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001b1aab0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 451ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.28.0.0/24, 
Allocated addresses:
  10.28.0.101 (cilium-test-1/client-974f6c69d-pr25w)
  10.28.0.104 (kube-system/clustermesh-apiserver-6464c7d796-cvmtw)
  10.28.0.140 (cilium-test-1/client2-57cf4468f-ks4cd)
  10.28.0.179 (cilium-test-1/echo-same-node-86d9cc975c-5j5mh)
  10.28.0.252 (kube-system/coredns-cc6ccd49c-q4zrg)
  10.28.0.63 (kube-system/coredns-cc6ccd49c-h976j)
  10.28.0.64 (router)
  10.28.0.79 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f5954b12be75403
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      177/177 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    14s ago        never        0       no error   
  ct-map-pressure                                                     17s ago        never        0       no error   
  daemon-validate-config                                              50s ago        never        0       no error   
  dns-garbage-collector-job                                           19s ago        never        0       no error   
  endpoint-1234-regeneration-recovery                                 never          never        0       no error   
  endpoint-1274-regeneration-recovery                                 never          never        0       no error   
  endpoint-1755-regeneration-recovery                                 never          never        0       no error   
  endpoint-2071-regeneration-recovery                                 never          never        0       no error   
  endpoint-2159-regeneration-recovery                                 never          never        0       no error   
  endpoint-2924-regeneration-recovery                                 never          never        0       no error   
  endpoint-3492-regeneration-recovery                                 never          never        0       no error   
  endpoint-371-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         3m19s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                17s ago        never        0       no error   
  ipcache-inject-labels                                               17s ago        never        0       no error   
  k8s-heartbeat                                                       19s ago        never        0       no error   
  link-cache                                                          1s ago         never        0       no error   
  local-identity-checkpoint                                           2m53s ago      never        0       no error   
  node-neighbor-link-updater                                          7s ago         never        0       no error   
  remote-etcd-cmesh1                                                  12m16s ago     never        0       no error   
  remote-etcd-cmesh10                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh100                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh101                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh102                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh103                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh104                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh105                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh106                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh107                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh108                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh109                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh11                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh110                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh111                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh112                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh113                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh114                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh115                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh116                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh117                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh118                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh119                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh12                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh120                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh121                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh122                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh123                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh124                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh125                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh126                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh127                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh128                                                12m16s ago     never        0       no error   
  remote-etcd-cmesh13                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh14                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh15                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh16                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh17                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh18                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh19                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh2                                                  12m16s ago     never        0       no error   
  remote-etcd-cmesh20                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh21                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh22                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh23                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh24                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh25                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh26                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh27                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh28                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh3                                                  12m16s ago     never        0       no error   
  remote-etcd-cmesh30                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh31                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh32                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh33                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh34                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh35                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh36                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh37                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh38                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh39                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh4                                                  12m16s ago     never        0       no error   
  remote-etcd-cmesh40                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh41                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh42                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh43                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh44                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh45                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh46                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh47                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh48                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh49                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh5                                                  12m16s ago     never        0       no error   
  remote-etcd-cmesh50                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh51                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh52                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh53                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh54                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh55                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh56                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh57                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh58                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh59                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh6                                                  12m16s ago     never        0       no error   
  remote-etcd-cmesh60                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh61                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh62                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh63                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh64                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh65                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh66                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh67                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh68                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh69                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh7                                                  12m16s ago     never        0       no error   
  remote-etcd-cmesh70                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh71                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh72                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh73                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh74                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh75                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh76                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh77                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh78                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh79                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh8                                                  12m16s ago     never        0       no error   
  remote-etcd-cmesh80                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh81                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh82                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh83                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh84                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh85                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh86                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh87                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh88                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh89                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh9                                                  12m16s ago     never        0       no error   
  remote-etcd-cmesh90                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh91                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh92                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh93                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh94                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh95                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh96                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh97                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh98                                                 12m16s ago     never        0       no error   
  remote-etcd-cmesh99                                                 12m16s ago     never        0       no error   
  resolve-identity-1234                                               1m28s ago      never        0       no error   
  resolve-identity-1274                                               3m16s ago      never        0       no error   
  resolve-identity-1755                                               1m28s ago      never        0       no error   
  resolve-identity-2071                                               1m28s ago      never        0       no error   
  resolve-identity-2159                                               3m16s ago      never        0       no error   
  resolve-identity-2924                                               3m21s ago      never        0       no error   
  resolve-identity-3492                                               3m16s ago      never        0       no error   
  resolve-identity-371                                                3m17s ago      never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-pr25w                 6m28s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-ks4cd                6m28s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-5j5mh        6m28s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6464c7d796-cvmtw   13m21s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-h976j                  28m16s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-q4zrg                  28m16s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      28m17s ago     never        0       no error   
  sync-policymap-1234                                                 6m28s ago      never        0       no error   
  sync-policymap-1274                                                 13m12s ago     never        0       no error   
  sync-policymap-1755                                                 6m28s ago      never        0       no error   
  sync-policymap-2071                                                 6m28s ago      never        0       no error   
  sync-policymap-2159                                                 13m12s ago     never        0       no error   
  sync-policymap-2924                                                 13m21s ago     never        0       no error   
  sync-policymap-3492                                                 13m12s ago     never        0       no error   
  sync-policymap-371                                                  13m15s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1234)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1274)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1755)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2071)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2159)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2924)                                   11s ago        never        0       no error   
  sync-utime                                                          17s ago        never        0       no error   
  write-cni-file                                                      28m19s ago     never        0       no error   
Proxy Status:            OK, ip 10.28.0.64, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 1900544, max 1966079
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 163.30   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
agent-labels:
procfs:/host/proc
enable-mke:false
http-normalize-path:true
pprof-address:localhost
annotate-k8s-node:false
enable-ipv6-masquerade:true
enable-svc-source-range-check:true
pprof-port:6060
cluster-pool-ipv4-cidr:10.28.0.0/16
mtu:0
enable-route-mtu-for-cni-chaining:false
operator-prometheus-serve-addr::9963
k8s-client-qps:10
install-no-conntrack-iptables-rules:false
enable-ipv4-big-tcp:false
route-metric:0
dnsproxy-lock-count:131
enable-l7-proxy:true
tunnel-protocol:vxlan
tofqdns-proxy-response-max-delay:100ms
tofqdns-enable-dns-compression:true
nat-map-stats-entries:32
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
clustermesh-config:/var/lib/cilium/clustermesh/
identity-allocation-mode:crd
mesh-auth-enabled:true
k8s-kubeconfig-path:
read-cni-conf:
enable-l2-announcements:false
mke-cgroup-mount:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
tofqdns-proxy-port:0
egress-masquerade-interfaces:ens+
enable-ip-masq-agent:false
enable-ipv4:true
enable-ipv6-big-tcp:false
enable-k8s-endpoint-slice:true
enable-srv6:false
monitor-queue-size:0
k8s-sync-timeout:3m0s
dns-policy-unload-on-shutdown:false
devices:
bpf-lb-affinity-map-max:0
crd-wait-timeout:5m0s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
mesh-auth-signal-backoff-duration:1s
hubble-drop-events-reasons:auth_required,policy_denied
http-retry-count:3
hubble-export-file-max-size-mb:10
enable-stale-cilium-endpoint-cleanup:true
enable-policy:default
enable-envoy-config:false
dnsproxy-lock-timeout:500ms
local-router-ipv6:
bpf-lb-sock:false
hubble-export-fieldmask:
enable-node-selector-labels:false
set-cilium-node-taints:true
bpf-lb-external-clusterip:false
bpf-lb-service-backend-map-max:0
enable-sctp:false
datapath-mode:veth
bpf-root:/sys/fs/bpf
enable-recorder:false
enable-l2-neigh-discovery:true
kube-proxy-replacement:false
use-cilium-internal-ip-for-ipsec:false
enable-metrics:true
bpf-lb-sock-hostns-only:false
enable-active-connection-tracking:false
enable-node-port:false
gateway-api-secrets-namespace:
tofqdns-endpoint-max-ip-per-hostname:50
vlan-bpf-bypass:
local-router-ipv4:
http-retry-timeout:0
enable-gateway-api:false
bpf-auth-map-max:524288
enable-local-redirect-policy:false
hubble-redact-http-headers-deny:
k8s-require-ipv6-pod-cidr:false
egress-multi-home-ip-rule-compat:false
proxy-xff-num-trusted-hops-ingress:0
static-cnp-path:
hubble-export-denylist:
cni-chaining-target:
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-lb-maglev-table-size:16381
hubble-skip-unknown-cgroup-ids:true
conntrack-gc-max-interval:0s
ipv6-service-range:auto
vtep-endpoint:
bpf-ct-global-tcp-max:524288
enable-ipsec-encrypted-overlay:false
exclude-local-address:
kvstore-connectivity-timeout:2m0s
proxy-prometheus-port:0
bpf-node-map-max:16384
disable-envoy-version-check:false
prepend-iptables-chains:true
hubble-export-file-max-backups:5
hubble-redact-kafka-apikey:false
ipsec-key-rotation-duration:5m0s
k8s-client-connection-keep-alive:30s
fqdn-regex-compile-lru-size:1024
tunnel-port:0
node-port-range:
identity-change-grace-period:5s
max-controller-interval:0
egress-gateway-policy-map-max:16384
dnsproxy-socket-linger-timeout:10
hubble-listen-address::4244
proxy-max-connection-duration-seconds:0
cni-chaining-mode:none
enable-health-check-nodeport:true
enable-ipv6:false
monitor-aggregation-interval:5s
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
identity-gc-interval:15m0s
enable-ipsec:false
ipam-default-ip-pool:default
bpf-fragments-map-max:8192
enable-encryption-strict-mode:false
enable-high-scale-ipcache:false
state-dir:/var/run/cilium
ipam-multi-pool-pre-allocation:
enable-cilium-api-server-access:
mesh-auth-queue-size:1024
ipv4-service-loopback-address:169.254.42.1
mesh-auth-mutual-listener-port:0
disable-iptables-feeder-rules:
hubble-redact-http-headers-allow:
trace-payloadlen:128
policy-trigger-interval:1s
k8s-heartbeat-timeout:30s
ipv6-mcast-device:
proxy-xff-num-trusted-hops-egress:0
bpf-lb-rev-nat-map-max:0
bpf-lb-map-max:65536
proxy-max-requests-per-connection:0
hubble-metrics:
set-cilium-is-up-condition:true
service-no-backend-response:reject
metrics:
clustermesh-enable-endpoint-sync:false
proxy-connect-timeout:2
kube-proxy-replacement-healthz-bind-address:
policy-audit-mode:false
hubble-export-file-path:
max-connected-clusters:255
proxy-gid:1337
config-dir:/tmp/cilium/config-map
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-xdp-prefilter:false
k8s-api-server:
hubble-monitor-events:
bpf-lb-rss-ipv6-src-cidr:
hubble-export-allowlist:
bpf-ct-timeout-service-tcp:2h13m20s
bpf-lb-algorithm:random
hubble-redact-http-urlquery:false
tofqdns-max-deferred-connection-deletes:10000
enable-external-ips:false
enable-tcx:true
enable-health-checking:true
monitor-aggregation-flags:all
bpf-ct-timeout-regular-tcp-syn:1m0s
wireguard-persistent-keepalive:0s
cflags:
bpf-policy-map-max:16384
config-sources:config-map:kube-system/cilium-config
allow-icmp-frag-needed:true
preallocate-bpf-maps:false
nat-map-stats-interval:30s
http-max-grpc-timeout:0
l2-pod-announcements-interface:
hubble-drop-events:false
cluster-id:29
dns-max-ips-per-restored-rule:1000
k8s-client-burst:20
log-system-load:false
label-prefix-file:
enable-vtep:false
l2-announcements-lease-duration:15s
k8s-namespace:kube-system
bpf-lb-sock-terminate-pod-connections:false
prometheus-serve-addr:
ingress-secrets-namespace:
node-port-bind-protection:true
identity-heartbeat-timeout:30m0s
proxy-portrange-max:20000
restore:true
envoy-secrets-namespace:
labels:
enable-endpoint-health-checking:true
enable-nat46x64-gateway:false
bpf-lb-acceleration:disabled
cluster-health-port:4240
bpf-lb-mode:snat
bgp-announce-lb-ip:false
ipv4-native-routing-cidr:
ipam:cluster-pool
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
node-port-acceleration:disabled
enable-host-port:false
bpf-ct-global-any-max:262144
kvstore:
ipv4-pod-subnets:
envoy-base-id:0
bpf-filter-priority:1
enable-ipsec-key-watcher:true
config:
mesh-auth-spire-admin-socket:
mesh-auth-gc-interval:5m0s
dnsproxy-enable-transparent-mode:true
pprof:false
enable-auto-protect-node-port-range:true
bpf-ct-timeout-regular-tcp:2h13m20s
enable-k8s-api-discovery:false
bpf-nat-global-max:524288
container-ip-local-reserved-ports:auto
api-rate-limit:
enable-bandwidth-manager:false
trace-sock:true
hubble-recorder-sink-queue-size:1024
encryption-strict-mode-allow-remote-node-identities:false
k8s-require-ipv4-pod-cidr:false
enable-ipv4-fragment-tracking:true
bpf-map-event-buffers:
enable-ingress-controller:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
iptables-lock-timeout:5s
bgp-announce-pod-cidr:false
vtep-mac:
proxy-portrange-min:10000
ipv6-native-routing-cidr:
k8s-service-cache-size:128
ipam-cilium-node-update-rate:15s
clustermesh-enable-mcs-api:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
hubble-flowlogs-config-path:
ipv4-range:auto
enable-k8s-terminating-endpoint:true
bpf-lb-dsr-l4-xlate:frontend
bpf-lb-maglev-map-max:0
disable-external-ip-mitigation:false
enable-bbr:false
iptables-random-fully:false
identity-restore-grace-period:30s
enable-l2-pod-announcements:false
enable-hubble-recorder-api:true
vtep-mask:
enable-bpf-masquerade:false
vtep-cidr:
cni-exclusive:true
enable-host-firewall:false
k8s-client-connection-timeout:30s
enable-wireguard:false
policy-queue-size:100
unmanaged-pod-watcher-interval:15
enable-well-known-identities:false
egress-gateway-reconciliation-trigger-interval:1s
endpoint-bpf-prog-watchdog-interval:30s
dnsproxy-insecure-skip-transparent-mode-check:false
custom-cni-conf:false
conntrack-gc-interval:0s
enable-cilium-health-api-server-access:
enable-service-topology:false
force-device-detection:false
debug-verbose:
controller-group-metrics:
multicast-enabled:false
debug:false
arping-refresh-period:30s
enable-local-node-route:true
enable-identity-mark:true
ipv4-node:auto
remove-cilium-node-taints:true
cmdref:
auto-create-cilium-node-resource:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-ipv6-ndp:false
policy-cidr-match-mode:
use-full-tls-context:false
ipv6-range:auto
node-port-algorithm:random
enable-endpoint-routes:false
encrypt-interface:
join-cluster:false
node-port-mode:snat
enable-ipv4-egress-gateway:false
direct-routing-skip-unreachable:false
hubble-export-file-compress:false
exclude-node-label-patterns:
bpf-lb-source-range-map-max:0
hubble-event-buffer-capacity:4095
hubble-metrics-server:
kvstore-opt:
bpf-map-dynamic-size-ratio:0.0025
enable-bpf-clock-probe:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-host-legacy-routing:false
tofqdns-dns-reject-response-code:refused
bpf-events-trace-enabled:true
agent-liveness-update-interval:1s
version:false
hubble-prefer-ipv6:false
bpf-policy-map-full-reconciliation-interval:15m0s
bpf-events-drop-enabled:true
http-request-timeout:3600
envoy-keep-cap-netbindservice:false
lib-dir:/var/lib/cilium
ipv6-pod-subnets:
envoy-config-timeout:2m0s
enable-cilium-endpoint-slice:false
enable-xt-socket-fallback:true
proxy-admin-port:0
encrypt-node:false
enable-health-check-loadbalancer-ip:false
nodes-gc-interval:5m0s
l2-announcements-renew-deadline:5s
bpf-sock-rev-map-max:262144
envoy-config-retry-interval:15s
routing-mode:tunnel
allocator-list-timeout:3m0s
auto-direct-node-routes:false
mesh-auth-mutual-connect-timeout:5s
hubble-socket-path:/var/run/cilium/hubble.sock
kvstore-periodic-sync:5m0s
enable-hubble:true
bypass-ip-availability-upon-restore:false
gops-port:9890
monitor-aggregation:medium
enable-custom-calls:false
enable-icmp-rules:true
ipv6-node:auto
synchronize-k8s-nodes:true
keep-config:false
enable-bgp-control-plane:false
bpf-lb-service-map-max:0
srv6-encap-mode:reduced
ipsec-key-file:
enable-k8s-networkpolicy:true
cilium-endpoint-gc-interval:5m0s
policy-accounting:true
hubble-redact-enabled:false
tofqdns-min-ttl:0
log-opt:
enable-runtime-device-detection:true
k8s-service-proxy-name:
disable-endpoint-crd:false
tofqdns-idle-connection-grace-period:0s
http-idle-timeout:0
enable-tracing:false
enable-ipsec-xfrm-state-caching:true
hubble-drop-events-interval:2m0s
clustermesh-sync-timeout:1m0s
certificates-directory:/var/run/cilium/certs
agent-health-port:9879
bpf-events-policy-verdict-enabled:true
proxy-idle-timeout-seconds:60
node-labels:
cluster-pool-ipv4-mask-size:24
kvstore-lease-ttl:15m0s
bpf-neigh-global-max:524288
bpf-ct-timeout-service-any:1m0s
envoy-log:
ipv6-cluster-alloc-cidr:f00d::/64
hubble-disable-tls:false
enable-session-affinity:false
ipv4-service-range:auto
encryption-strict-mode-cidr:
tofqdns-pre-cache:
hubble-redact-http-userinfo:true
enable-unreachable-routes:false
enable-ipv4-masquerade:true
endpoint-queue-size:25
mesh-auth-rotated-identities-queue-size:1024
enable-monitor:true
enable-k8s:true
max-internal-timer-delay:0s
dnsproxy-concurrency-limit:0
enable-bpf-tproxy:false
derive-masq-ip-addr-from-device:
cni-log-file:/var/run/cilium/cilium-cni.log
direct-routing-device:
local-max-addr-scope:252
external-envoy-proxy:true
bpf-lb-dsr-dispatch:opt
cni-external-routing:false
enable-wireguard-userspace-fallback:false
log-driver:
enable-ipip-termination:false
bpf-ct-timeout-regular-any:1m0s
endpoint-gc-interval:5m0s
dnsproxy-concurrency-processing-grace-period:0s
l2-announcements-retry-period:2s
mesh-auth-spiffe-trust-domain:spiffe.cilium
kvstore-max-consecutive-quorum-errors:2
install-iptables-rules:true
hubble-event-queue-size:0
fixed-identity-mapping:
bpf-ct-timeout-regular-tcp-fin:10s
cgroup-root:/run/cilium/cgroupv2
nodeport-addresses:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-lb-rss-ipv4-src-cidr:
allow-localhost:auto
cluster-name:cmesh29
enable-pmtu-discovery:false
clustermesh-ip-identities-sync-timeout:1m0s
operator-api-serve-addr:127.0.0.1:9234
socket-path:/var/run/cilium/cilium.sock
enable-masquerade-to-route-source:false
```


#### Service list

```
ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.191.56:443 (active)     
                                        2 => 172.31.216.181:443 (active)    
2    10.100.12.132:443   ClusterIP      1 => 172.31.133.133:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.28.0.252:53 (active)        
                                        2 => 10.28.0.63:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.28.0.252:9153 (active)      
                                        2 => 10.28.0.63:9153 (active)       
5    10.100.78.87:2379   ClusterIP      1 => 10.28.0.104:2379 (active)      
6    10.100.8.232:8080   ClusterIP      1 => 10.28.0.179:8080 (active)      
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                      
371        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                     ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                       
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                 
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                  
                                                           reserved:host                                                                                               
1234       Disabled           Disabled          1916851    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.28.0.101   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh29                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                              
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client                                                                                             
1274       Disabled           Disabled          1901834    k8s:eks.amazonaws.com/component=coredns                                               10.28.0.252   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh29                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
1755       Disabled           Disabled          1915548    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.28.0.179   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh29                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                      
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=echo                                                                                               
                                                           k8s:name=echo-same-node                                                                                     
                                                           k8s:other=echo                                                                                              
2071       Disabled           Disabled          1931818    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.28.0.140   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh29                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client2                                                                                            
                                                           k8s:other=client                                                                                            
2159       Disabled           Disabled          1901834    k8s:eks.amazonaws.com/component=coredns                                               10.28.0.63    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh29                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
2924       Disabled           Disabled          1920381    k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.28.0.104   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh29                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                               
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=clustermesh-apiserver                                                                           
3492       Disabled           Disabled          4          reserved:health                                                                       10.28.0.79    ready   
```

#### BPF Policy Get 371

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 371

```
Invalid argument: unknown type 371
```


#### Endpoint Get 371

```
[
  {
    "id": 371,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-371-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d1a969f2-767d-4279-a722-eca14d3eab4b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-371",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:31.718Z",
            "success-count": 6
          },
          "uuid": "09977e55-8d91-4888-9634-bedb0040706b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-371",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:32.844Z",
            "success-count": 2
          },
          "uuid": "76db351f-cc87-4276-bf4c-43e135a40cb5"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "5e:9b:7f:23:62:e0",
        "interface-name": "cilium_host",
        "mac": "5e:9b:7f:23:62:e0"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 371

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 371

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:34:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:34:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:34:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:34:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:34:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:34:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:34:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:34:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:26:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:26:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:26:33Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:26:33Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:26:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:26:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:26:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:26:31Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:26:31Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1234

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1234

```
Invalid argument: unknown type 1234
```


#### Endpoint Get 1234

```
[
  {
    "id": 1234,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1234-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "930ac3b1-a181-4f64-9ce8-2ed487773e20"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1234",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:20.139Z",
            "success-count": 2
          },
          "uuid": "02c3902d-e14d-4a1a-8f7d-da3cbc1f2fc9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-pr25w",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.138Z",
            "success-count": 1
          },
          "uuid": "72342eae-8f22-4b7f-8f56-fa6b19bfe47c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1234",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.339Z",
            "success-count": 1
          },
          "uuid": "b2ae6695-3e47-47b8-875f-6c32a6254196"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1234)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.179Z",
            "success-count": 40
          },
          "uuid": "b83ad76d-0b89-475b-876f-04f696e15aa0"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d619351cdbbad7e5d481cec0ed704b5ad13fe6ac0a8f8735e5bb8307b2dacd76:eth0",
        "container-id": "d619351cdbbad7e5d481cec0ed704b5ad13fe6ac0a8f8735e5bb8307b2dacd76",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-pr25w",
        "pod-name": "cilium-test-1/client-974f6c69d-pr25w"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1916851,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:39Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.101",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3e:0e:d2:e5:3e:7c",
        "interface-index": 20,
        "interface-name": "lxc122e7f182f72",
        "mac": "46:87:a3:90:d7:75"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1916851,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1916851,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1234

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1234

```
Timestamp              Status   State                   Message
2024-10-24T12:51:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 1916851

```
ID        LABELS
1916851   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh29
          k8s:io.cilium.k8s.policy.serviceaccount=client
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client

```


#### BPF Policy Get 1274

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2934     30        0        
Allow    Ingress     1          ANY          NONE         disabled    162808   1874      0        
Allow    Egress      0          ANY          NONE         disabled    20357    228       0        

```


#### BPF CT List 1274

```
Invalid argument: unknown type 1274
```


#### Endpoint Get 1274

```
[
  {
    "id": 1274,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1274-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "33cca650-ab5b-4de1-9717-8749626721ff"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1274",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:32.611Z",
            "success-count": 6
          },
          "uuid": "edfd8323-b0c7-431f-bb0d-1360dbf55c86"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-q4zrg",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:26:32.608Z",
            "success-count": 1
          },
          "uuid": "a5d10448-aa30-4457-a383-a40b9f88df81"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1274",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:35.978Z",
            "success-count": 2
          },
          "uuid": "67fb8408-0b94-4fb7-8ce8-72397371dccc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1274)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:42.740Z",
            "success-count": 171
          },
          "uuid": "8dbd822b-dca6-4812-a82a-676b8fee9cd7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "80cb96c2b31e60beb0eeb6c70033d4d8e0a96590b8b90d0bbf92c40841710caa:eth0",
        "container-id": "80cb96c2b31e60beb0eeb6c70033d4d8e0a96590b8b90d0bbf92c40841710caa",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-q4zrg",
        "pod-name": "kube-system/coredns-cc6ccd49c-q4zrg"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1901834,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.252",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "5a:6a:26:36:c8:2e",
        "interface-index": 12,
        "interface-name": "lxc880c0a25e569",
        "mac": "5a:eb:a4:24:bd:92"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1901834,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1901834,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1274

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1274

```
Timestamp              Status    State                   Message
2024-10-24T12:48:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:42:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:34:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:34:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:34:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:34:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:34:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:34:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:34:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:34:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:36Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:26:36Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:26:36Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:26:35Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:26:33Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:26:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:32Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:26:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:26:32Z   OK        ready                   Set identity for this endpoint
2024-10-24T12:26:32Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:32Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 1901834

```
ID        LABELS
1901834   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh29
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1755

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377257   4401      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1755

```
Invalid argument: unknown type 1755
```


#### Endpoint Get 1755

```
[
  {
    "id": 1755,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1755-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e04b4f0e-13fe-43b9-9476-91a0009f341c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1755",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:20.353Z",
            "success-count": 2
          },
          "uuid": "6e89a7d0-8511-4c4b-b6c8-d7cd6ef963d2"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-5j5mh",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.349Z",
            "success-count": 1
          },
          "uuid": "7ac36594-ab25-4d57-a4bd-1e350e193b73"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1755",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.405Z",
            "success-count": 1
          },
          "uuid": "fb364d9c-6e81-47f1-ba9a-6700439321c6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1755)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.398Z",
            "success-count": 40
          },
          "uuid": "decff91f-0449-462f-8a91-ea9eac530746"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "948fed4b214b392f829b2230a75df94a28e8b919b34c0762640afee0e47d2c97:eth0",
        "container-id": "948fed4b214b392f829b2230a75df94a28e8b919b34c0762640afee0e47d2c97",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-5j5mh",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-5j5mh"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1915548,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.179",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "32:0b:88:e7:03:44",
        "interface-index": 24,
        "interface-name": "lxc11c76c6170f3",
        "mac": "8a:ca:79:f1:6f:10"
      },
      "policy": {
        "proxy-policy-revision": 126,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1915548,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 126,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1915548,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 126
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1755

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1755

```
Timestamp              Status   State                   Message
2024-10-24T12:51:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:57Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added

```


#### Identity get 1915548

```
ID        LABELS
1915548   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh29
          k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=echo
          k8s:name=echo-same-node
          k8s:other=echo

```


#### BPF Policy Get 2071

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2071

```
Invalid argument: unknown type 2071
```


#### Endpoint Get 2071

```
[
  {
    "id": 2071,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2071-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5bf5dfdf-30aa-48ba-bf50-7381e37e36ac"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2071",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:20.291Z",
            "success-count": 2
          },
          "uuid": "60f14739-dc02-4552-9e3b-4a5e010e1ac8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-ks4cd",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.291Z",
            "success-count": 1
          },
          "uuid": "4f295519-9d8a-4b45-b3a5-c8dadafa7ea8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2071",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.347Z",
            "success-count": 1
          },
          "uuid": "74105c5f-49f8-4e2e-aedb-398c1429e6d1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2071)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.339Z",
            "success-count": 40
          },
          "uuid": "cf5a1d67-cb7c-4f61-88ef-71589a92bd61"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "1613b435db2fca22fa49ea18d6d65eb9b6afad9eedfad8cffdfa1d185b73a507:eth0",
        "container-id": "1613b435db2fca22fa49ea18d6d65eb9b6afad9eedfad8cffdfa1d185b73a507",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-ks4cd",
        "pod-name": "cilium-test-1/client2-57cf4468f-ks4cd"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1931818,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:39Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.140",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "b2:2f:bc:ce:ec:9f",
        "interface-index": 22,
        "interface-name": "lxc918e9b66346a",
        "mac": "ea:53:da:14:5f:5a"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1931818,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1931818,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2071

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2071

```
Timestamp              Status   State                   Message
2024-10-24T12:51:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 1931818

```
ID        LABELS
1931818   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh29
          k8s:io.cilium.k8s.policy.serviceaccount=client2
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client2
          k8s:other=client

```


#### BPF Policy Get 2159

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2962     30        0        
Allow    Ingress     1          ANY          NONE         disabled    160165   1839      0        
Allow    Egress      0          ANY          NONE         disabled    21050    234       0        

```


#### BPF CT List 2159

```
Invalid argument: unknown type 2159
```


#### Endpoint Get 2159

```
[
  {
    "id": 2159,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2159-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3f16c237-15b1-4bf1-a413-4f4f63bc581b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2159",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:32.680Z",
            "success-count": 6
          },
          "uuid": "8a47b807-af25-4b4f-bd0a-ced09b305779"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-h976j",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:26:32.677Z",
            "success-count": 1
          },
          "uuid": "91dacdc7-ef32-4f02-83ea-5fd4e0bcadb6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2159",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:35.979Z",
            "success-count": 2
          },
          "uuid": "4af2220c-1ec2-4f07-a590-3195fb301196"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2159)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:42.804Z",
            "success-count": 171
          },
          "uuid": "15f0157a-ffa4-4df1-8497-7d62545dc361"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "95292dfdf650f84040d8cac298be327ea27908817a2b03129963610ec831cb69:eth0",
        "container-id": "95292dfdf650f84040d8cac298be327ea27908817a2b03129963610ec831cb69",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-h976j",
        "pod-name": "kube-system/coredns-cc6ccd49c-h976j"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1901834,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.63",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ce:c3:96:93:8b:2c",
        "interface-index": 14,
        "interface-name": "lxc82758187a16b",
        "mac": "ba:f9:e0:b6:0f:eb"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1901834,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1901834,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2159

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2159

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:34:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:34:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:34:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:34:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:34:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:34:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:34:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:34:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:26:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:26:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:26:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:26:33Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:26:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:32Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:26:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:26:32Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:26:32Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1901834

```
ID        LABELS
1901834   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh29
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2924

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6065338   61325     0        
Allow    Ingress     1          ANY          NONE         disabled    5369076   56746     0        
Allow    Egress      0          ANY          NONE         disabled    7187710   70557     0        

```


#### BPF CT List 2924

```
Invalid argument: unknown type 2924
```


#### Endpoint Get 2924

```
[
  {
    "id": 2924,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2924-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ea721902-b64e-4db8-aef9-420b1d713614"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2924",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:27.179Z",
            "success-count": 3
          },
          "uuid": "dbf4884e-1665-4c7d-9dfb-c2f80f378a86"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6464c7d796-cvmtw",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:27.177Z",
            "success-count": 1
          },
          "uuid": "e7275fd4-37f0-4276-907d-7837f8bc66c8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2924",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:27.211Z",
            "success-count": 1
          },
          "uuid": "d29a7fb5-9944-40f4-8f8c-330586901e2d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2924)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:47.240Z",
            "success-count": 82
          },
          "uuid": "57406084-de4a-47ed-bfd0-92f6d9727ab6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "862339c0593edb42a0d71a40d64994cc0481af15a3bb64f1fc0e9b8abc78865c:eth0",
        "container-id": "862339c0593edb42a0d71a40d64994cc0481af15a3bb64f1fc0e9b8abc78865c",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6464c7d796-cvmtw",
        "pod-name": "kube-system/clustermesh-apiserver-6464c7d796-cvmtw"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1920381,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6464c7d796"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.104",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "9e:c4:2b:ec:2d:1f",
        "interface-index": 18,
        "interface-name": "lxc4a5d38b02c05",
        "mac": "2a:79:a0:98:4b:6e"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1920381,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1920381,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2924

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2924

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:41:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:41:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:41:27Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:41:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1920381

```
ID        LABELS
1920381   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh29
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 3492

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6219912   77015     0        
Allow    Ingress     1          ANY          NONE         disabled    64842     783       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 3492

```
Invalid argument: unknown type 3492
```


#### Endpoint Get 3492

```
[
  {
    "id": 3492,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3492-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3e264a56-e7fc-407d-98ef-8d5135914d21"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3492",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:32.781Z",
            "success-count": 6
          },
          "uuid": "1b567cdb-0e1b-4205-86da-1b8546d8913d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3492",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:36.053Z",
            "success-count": 2
          },
          "uuid": "5ac1d1fe-ef10-47e9-aa52-2207f3fab17c"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.79",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "b2:3e:4c:ca:98:97",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "56:ae:46:3e:05:1f"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3492

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3492

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:34:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:34:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:34:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:34:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:34:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:34:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:34:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:34:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:26:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:26:35Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:26:33Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:26:33Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:26:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:26:32Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:26:31Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33838806                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33838806                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33838806                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d400000 rw-p 00000000 00:00 0 
400d400000-4010000000 ---p 00000000 00:00 0 
ffff4d371000-ffff4d637000 rw-p 00000000 00:00 0 
ffff4d63f000-ffff4d760000 rw-p 00000000 00:00 0 
ffff4d760000-ffff4d7a1000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4d7a1000-ffff4d7e2000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4d7e2000-ffff4d822000 rw-p 00000000 00:00 0 
ffff4d822000-ffff4d824000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4d824000-ffff4d826000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4d826000-ffff4dddd000 rw-p 00000000 00:00 0 
ffff4dddd000-ffff4dedd000 rw-p 00000000 00:00 0 
ffff4dedd000-ffff4deee000 rw-p 00000000 00:00 0 
ffff4deee000-ffff4feee000 rw-p 00000000 00:00 0 
ffff4feee000-ffff4ff6e000 ---p 00000000 00:00 0 
ffff4ff6e000-ffff4ff6f000 rw-p 00000000 00:00 0 
ffff4ff6f000-ffff6ff6e000 ---p 00000000 00:00 0 
ffff6ff6e000-ffff6ff6f000 rw-p 00000000 00:00 0 
ffff6ff6f000-ffff8fefe000 ---p 00000000 00:00 0 
ffff8fefe000-ffff8feff000 rw-p 00000000 00:00 0 
ffff8feff000-ffff93ef0000 ---p 00000000 00:00 0 
ffff93ef0000-ffff93ef1000 rw-p 00000000 00:00 0 
ffff93ef1000-ffff946ee000 ---p 00000000 00:00 0 
ffff946ee000-ffff946ef000 rw-p 00000000 00:00 0 
ffff946ef000-ffff947ee000 ---p 00000000 00:00 0 
ffff947ee000-ffff9484e000 rw-p 00000000 00:00 0 
ffff9484e000-ffff94850000 r--p 00000000 00:00 0                          [vvar]
ffff94850000-ffff94851000 r-xp 00000000 00:00 0                          [vdso]
fffffd0ef000-fffffd110000 rw-p 00000000 00:00 0                          [stack]

```

