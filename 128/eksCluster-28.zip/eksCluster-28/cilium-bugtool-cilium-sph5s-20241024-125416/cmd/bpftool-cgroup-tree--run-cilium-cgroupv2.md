CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f6f9638_935b_4fac_a5a8_43ef1e318705.slice/cri-containerd-80cb96c2b31e60beb0eeb6c70033d4d8e0a96590b8b90d0bbf92c40841710caa.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f6f9638_935b_4fac_a5a8_43ef1e318705.slice/cri-containerd-585216185c8c512e13af7be2231ad0b4128226c3f61f11ebac46a3af4857a10b.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb306ad7b_6a62_4ef4_8839_8f5c098dbcd2.slice/cri-containerd-1888c3abbe6c0c7a4cf153132babe9fb224c24839a2f00a0c86a8eeee881a08f.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb306ad7b_6a62_4ef4_8839_8f5c098dbcd2.slice/cri-containerd-6a2a6f2d3d8bec9b762cfacf1549a845bfec601345f446819c3c69bcd5cefa4c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode38628ac_6877_4e1d_a0e8_7e6c2f74389f.slice/cri-containerd-3f02ceed32c062ee68f163f8f3eb191bf6a71c90fdf590ae6be300894d1c697f.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode38628ac_6877_4e1d_a0e8_7e6c2f74389f.slice/cri-containerd-72f66079f6150a2e5ce60566649f94d68d4bdf19367306550632d6ecedca3141.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc45d5d8_1802_4fac_9eb2_777e50a40a22.slice/cri-containerd-95292dfdf650f84040d8cac298be327ea27908817a2b03129963610ec831cb69.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc45d5d8_1802_4fac_9eb2_777e50a40a22.slice/cri-containerd-02665b6268a8dfa5d2f4df225038e1632c36e75dc2e5d8a95b674fc7a54efdc9.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75563f94_ace0_4a97_834d_956d5e8d3a06.slice/cri-containerd-d619351cdbbad7e5d481cec0ed704b5ad13fe6ac0a8f8735e5bb8307b2dacd76.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75563f94_ace0_4a97_834d_956d5e8d3a06.slice/cri-containerd-d0eb1176133fe0a4031e5df465c3d4c8cc2d3458e9dc75fac0f08e25eb8e8201.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda778d79e_951b_401c_9d5f_63e552503190.slice/cri-containerd-ed0746c3c75a55a4a701e04566d6996cc04727b4ae1884ee6eed195cebdc79b1.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda778d79e_951b_401c_9d5f_63e552503190.slice/cri-containerd-9544a03fc2a4ed9d68bf5ed5a2d7db8c08d38e1040cdd804cd8cddeea7282a6c.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod000d89f0_7933_41a6_a5e8_0e52fec64358.slice/cri-containerd-3c0382bca0d88c661df80bcd053e0553d2ac52517d5c3b00c224e6a212c8fdbc.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod000d89f0_7933_41a6_a5e8_0e52fec64358.slice/cri-containerd-5930a7f0d52a75e11b2b1ec0f08aeeece8578b2924fddf371ade4cf788f78c95.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3291de64_9a2b_4c4a_9f7c_15ebb903f5a3.slice/cri-containerd-a23f045cdff5bf1ccb0bd1bdafd1a8fa31c20a63f2b4b760f5478a9d5d0ee8a1.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3291de64_9a2b_4c4a_9f7c_15ebb903f5a3.slice/cri-containerd-948fed4b214b392f829b2230a75df94a28e8b919b34c0762640afee0e47d2c97.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3291de64_9a2b_4c4a_9f7c_15ebb903f5a3.slice/cri-containerd-2564cdbc7bb599491349ae4f32da58ff0493ed933f243623782a6589da737aa8.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ce42375_1789_490e_b00a_e6c183dae03f.slice/cri-containerd-df7a00275de5b5a9144e455414cf37112de518e95528ce7981419d9fc6e126b0.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ce42375_1789_490e_b00a_e6c183dae03f.slice/cri-containerd-1613b435db2fca22fa49ea18d6d65eb9b6afad9eedfad8cffdfa1d185b73a507.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab2af255_eb83_4517_a16f_f4f5152d65dd.slice/cri-containerd-7d77ffce1f2f86b204f063f9b4d5ed86329003650519fe25b5693ff876bf3309.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab2af255_eb83_4517_a16f_f4f5152d65dd.slice/cri-containerd-53ce96cfa2af05fd229a5b2839170d8935abe93cbd68b0a383318d3bbaabb483.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab2af255_eb83_4517_a16f_f4f5152d65dd.slice/cri-containerd-862339c0593edb42a0d71a40d64994cc0481af15a3bb64f1fc0e9b8abc78865c.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab2af255_eb83_4517_a16f_f4f5152d65dd.slice/cri-containerd-77545e7df3920be8d366e46c21e1e210acfab1a288498daf25cce7e02d18ff86.scope
    653      cgroup_device   multi                                          
