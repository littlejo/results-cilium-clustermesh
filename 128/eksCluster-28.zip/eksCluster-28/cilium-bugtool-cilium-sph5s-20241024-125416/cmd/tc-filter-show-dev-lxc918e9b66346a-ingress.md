filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc918e9b66346a direct-action not_in_hw id 3345 tag 9244e304e5e69205 jited 
