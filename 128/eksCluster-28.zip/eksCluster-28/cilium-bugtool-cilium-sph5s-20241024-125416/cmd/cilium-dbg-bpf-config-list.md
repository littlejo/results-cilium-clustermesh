KEY             VALUE
AgentLiveness   2026111797001
UTimeOffset     3378461841796875
