key: d2 04 00 00  value: 16 0d 00 00
key: fa 04 00 00  value: 23 02 00 00
key: db 06 00 00  value: da 0c 00 00
key: 17 08 00 00  value: 08 0d 00 00
key: 6f 08 00 00  value: 0e 02 00 00
key: 6c 0b 00 00  value: 76 02 00 00
key: a4 0d 00 00  value: 02 02 00 00
Found 7 elements
