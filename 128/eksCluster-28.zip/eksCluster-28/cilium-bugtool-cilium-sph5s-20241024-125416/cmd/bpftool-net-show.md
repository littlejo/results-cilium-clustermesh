xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 578
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 558
cilium_host(7) clsact/egress cil_from_host-cilium_host id 562
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 515
lxc880c0a25e569(12) clsact/ingress cil_from_container-lxc880c0a25e569 id 545
lxc82758187a16b(14) clsact/ingress cil_from_container-lxc82758187a16b id 519
lxc4a5d38b02c05(18) clsact/ingress cil_from_container-lxc4a5d38b02c05 id 629
lxc122e7f182f72(20) clsact/ingress cil_from_container-lxc122e7f182f72 id 3338
lxc918e9b66346a(22) clsact/ingress cil_from_container-lxc918e9b66346a id 3345
lxc11c76c6170f3(24) clsact/ingress cil_from_container-lxc11c76c6170f3 id 3281

flow_dissector:

netfilter:

