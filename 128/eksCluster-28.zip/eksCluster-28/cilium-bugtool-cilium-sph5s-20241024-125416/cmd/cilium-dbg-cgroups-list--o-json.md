[
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f6f9638_935b_4fac_a5a8_43ef1e318705.slice/cri-containerd-585216185c8c512e13af7be2231ad0b4128226c3f61f11ebac46a3af4857a10b.scope"
      }
    ],
    "ips": [
      "10.28.0.252"
    ],
    "name": "coredns-cc6ccd49c-q4zrg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc45d5d8_1802_4fac_9eb2_777e50a40a22.slice/cri-containerd-02665b6268a8dfa5d2f4df225038e1632c36e75dc2e5d8a95b674fc7a54efdc9.scope"
      }
    ],
    "ips": [
      "10.28.0.63"
    ],
    "name": "coredns-cc6ccd49c-h976j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75563f94_ace0_4a97_834d_956d5e8d3a06.slice/cri-containerd-d0eb1176133fe0a4031e5df465c3d4c8cc2d3458e9dc75fac0f08e25eb8e8201.scope"
      }
    ],
    "ips": [
      "10.28.0.101"
    ],
    "name": "client-974f6c69d-pr25w",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3291de64_9a2b_4c4a_9f7c_15ebb903f5a3.slice/cri-containerd-a23f045cdff5bf1ccb0bd1bdafd1a8fa31c20a63f2b4b760f5478a9d5d0ee8a1.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3291de64_9a2b_4c4a_9f7c_15ebb903f5a3.slice/cri-containerd-2564cdbc7bb599491349ae4f32da58ff0493ed933f243623782a6589da737aa8.scope"
      }
    ],
    "ips": [
      "10.28.0.179"
    ],
    "name": "echo-same-node-86d9cc975c-5j5mh",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ce42375_1789_490e_b00a_e6c183dae03f.slice/cri-containerd-df7a00275de5b5a9144e455414cf37112de518e95528ce7981419d9fc6e126b0.scope"
      }
    ],
    "ips": [
      "10.28.0.140"
    ],
    "name": "client2-57cf4468f-ks4cd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab2af255_eb83_4517_a16f_f4f5152d65dd.slice/cri-containerd-7d77ffce1f2f86b204f063f9b4d5ed86329003650519fe25b5693ff876bf3309.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab2af255_eb83_4517_a16f_f4f5152d65dd.slice/cri-containerd-77545e7df3920be8d366e46c21e1e210acfab1a288498daf25cce7e02d18ff86.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab2af255_eb83_4517_a16f_f4f5152d65dd.slice/cri-containerd-53ce96cfa2af05fd229a5b2839170d8935abe93cbd68b0a383318d3bbaabb483.scope"
      }
    ],
    "ips": [
      "10.28.0.104"
    ],
    "name": "clustermesh-apiserver-6464c7d796-cvmtw",
    "namespace": "kube-system"
  }
]

