IP ADDRESS         LOCAL ENDPOINT INFO
10.28.0.79:0       id=3492  sec_id=4     flags=0x0000 ifindex=10  mac=56:AE:46:3E:05:1F nodemac=B2:3E:4C:CA:98:97     
10.28.0.179:0      id=1755  sec_id=1915548 flags=0x0000 ifindex=24  mac=8A:CA:79:F1:6F:10 nodemac=32:0B:88:E7:03:44   
10.28.0.140:0      id=2071  sec_id=1931818 flags=0x0000 ifindex=22  mac=EA:53:DA:14:5F:5A nodemac=B2:2F:BC:CE:EC:9F   
10.28.0.64:0       (localhost)                                                                                        
172.31.148.253:0   (localhost)                                                                                        
10.28.0.63:0       id=2159  sec_id=1901834 flags=0x0000 ifindex=14  mac=BA:F9:E0:B6:0F:EB nodemac=CE:C3:96:93:8B:2C   
172.31.133.133:0   (localhost)                                                                                        
10.28.0.104:0      id=2924  sec_id=1920381 flags=0x0000 ifindex=18  mac=2A:79:A0:98:4B:6E nodemac=9E:C4:2B:EC:2D:1F   
10.28.0.252:0      id=1274  sec_id=1901834 flags=0x0000 ifindex=12  mac=5A:EB:A4:24:BD:92 nodemac=5A:6A:26:36:C8:2E   
10.28.0.101:0      id=1234  sec_id=1916851 flags=0x0000 ifindex=20  mac=46:87:A3:90:D7:75 nodemac=3E:0E:D2:E5:3E:7C   
