xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 500
ens6(5) clsact/ingress cil_from_netdev-ens6 id 511
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 496
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 486
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 536
lxca50e2e3d76d2(12) clsact/ingress cil_from_container-lxca50e2e3d76d2 id 517
lxc7d5d9929950a(14) clsact/ingress cil_from_container-lxc7d5d9929950a id 546
lxcea9f1f87e673(18) clsact/ingress cil_from_container-lxcea9f1f87e673 id 621
lxc93bc7c77219f(20) clsact/ingress cil_from_container-lxc93bc7c77219f id 3327
lxcb8e5ff40cb16(22) clsact/ingress cil_from_container-lxcb8e5ff40cb16 id 3289
lxcbbc40bbababe(24) clsact/ingress cil_from_container-lxcbbc40bbababe id 3331

flow_dissector:

netfilter:

