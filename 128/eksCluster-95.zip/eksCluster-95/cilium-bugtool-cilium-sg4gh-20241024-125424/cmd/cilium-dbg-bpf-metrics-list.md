REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     132183    10712341    677    bpf_overlay.c
Interface                   INGRESS     669742    247266813   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      132015    10697074    53     encap.h
Success                     EGRESS      150787    19909849    1308   bpf_lxc.c
Success                     EGRESS      55710     4516353     1694   bpf_host.c
Success                     EGRESS      596       156261      86     l3.h
Success                     INGRESS     174767    20055202    86     l3.h
Success                     INGRESS     252467    26449921    235    trace.h
Unsupported L3 protocol     EGRESS      75        5690        1492   bpf_lxc.c
