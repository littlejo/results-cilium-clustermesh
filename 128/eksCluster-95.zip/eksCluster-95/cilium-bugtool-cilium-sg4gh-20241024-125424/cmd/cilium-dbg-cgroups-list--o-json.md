[
  {
    "containers": [
      {
        "cgroup-id": 7704,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b141e2e_6e65_4611_8519_fabcd986b84f.slice/cri-containerd-ce300215528a05668efde0424a0f41b7186c24c403623c8adbad7970f1472056.scope"
      }
    ],
    "ips": [
      "10.95.0.134"
    ],
    "name": "coredns-cc6ccd49c-mn4jt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod44264c8d_dd58_42eb_98cd_54ce35adfbd1.slice/cri-containerd-8d67c2476556e13ac51d11d494221409e70eb957ac7ecb3debc40ab891a619e9.scope"
      }
    ],
    "ips": [
      "10.95.0.201"
    ],
    "name": "client-974f6c69d-56gbc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7620,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab0ca37d_a1b6_4510_824a_3014425a3c14.slice/cri-containerd-b9e2ba006fad9ea8d69fadf02b848483f492bc26f18fd1198a2456a66cf00231.scope"
      }
    ],
    "ips": [
      "10.95.0.79"
    ],
    "name": "coredns-cc6ccd49c-wzxcn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a822eb7_f5d0_459d_bac4_b8578e059e33.slice/cri-containerd-c0cbfdf7e7db96b2549236be007b4781433e8945c7da5ae5949165b8474fb8d3.scope"
      }
    ],
    "ips": [
      "10.95.0.149"
    ],
    "name": "client2-57cf4468f-72ffx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94e9a786_7415_458b_b165_fb6bdd2c88b7.slice/cri-containerd-a44609e334e5b54a3c09f5eef2d33be14473186dafa0349538e2706bc8909d52.scope"
      },
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94e9a786_7415_458b_b165_fb6bdd2c88b7.slice/cri-containerd-2b83d8cee084e23c9db4c689ff375c259f1f6e98a6bbb2d1fea0be5ef269a690.scope"
      },
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94e9a786_7415_458b_b165_fb6bdd2c88b7.slice/cri-containerd-5b14a71a746190da0687423a362bc190d0f2b291a94222ddf26a60e6755c0f28.scope"
      }
    ],
    "ips": [
      "10.95.0.125"
    ],
    "name": "clustermesh-apiserver-57c6dcc584-zn5sf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c6901_7a4f_46ee_85b9_a3c8491ed287.slice/cri-containerd-7b7ee339cf3137b882cbc12372482b26d4fa4500c2f831c9ab9390b684e863ad.scope"
      },
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c6901_7a4f_46ee_85b9_a3c8491ed287.slice/cri-containerd-b81cf536c4896fa9f2bddc7cac319b6d00672ed499aecc80a675efa28447fd5b.scope"
      }
    ],
    "ips": [
      "10.95.0.19"
    ],
    "name": "echo-same-node-86d9cc975c-tncjt",
    "namespace": "cilium-test-1"
  }
]

