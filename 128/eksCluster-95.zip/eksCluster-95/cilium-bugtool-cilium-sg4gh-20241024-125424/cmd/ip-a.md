1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:05:18:78:d0:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.229.144/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3512sec preferred_lft 3512sec
    inet6 fe80::805:18ff:fe78:d0cb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f0:75:2d:26:4f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.209.239/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8f0:75ff:fe2d:264f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:de:a0:43:0c:c2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e8de:a0ff:fe43:cc2/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:04:60:63:51:08 brd ff:ff:ff:ff:ff:ff
    inet 10.95.0.179/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8404:60ff:fe63:5108/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 12:a4:a3:8c:27:15 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::10a4:a3ff:fe8c:2715/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:a5:0b:f9:40:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::68a5:bff:fef9:40d6/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca50e2e3d76d2@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:58:85:51:08:dc brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2c58:85ff:fe51:8dc/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7d5d9929950a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:e9:4e:48:33:06 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d0e9:4eff:fe48:3306/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcea9f1f87e673@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:83:91:03:2e:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7883:91ff:fe03:2eb1/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc93bc7c77219f@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:c6:c8:6a:bb:9e brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::88c6:c8ff:fe6a:bb9e/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcb8e5ff40cb16@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:c1:5b:ec:20:ec brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::dcc1:5bff:feec:20ec/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcbbc40bbababe@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:65:73:38:da:71 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::9865:73ff:fe38:da71/64 scope link 
       valid_lft forever preferred_lft forever
