KEY             VALUE
AgentLiveness   1929326807866
UTimeOffset     3378462046875000
