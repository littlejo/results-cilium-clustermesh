Node 0, zone      DMA      0     15      9     29     19     10      4      1      3      4     40 
Node 0, zone   Normal   1065    212     74     54     42     21      6      7      3      2      4 
