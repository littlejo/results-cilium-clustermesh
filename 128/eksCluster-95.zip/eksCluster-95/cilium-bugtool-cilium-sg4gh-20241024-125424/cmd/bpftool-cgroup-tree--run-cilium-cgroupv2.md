CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9668bd83_a2b1_4fcd_ab55_f18f26360a39.slice/cri-containerd-4dcca7df8aa72d3b865f82036fd3603a15fc0427be47b2032dc69e641e31b87b.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9668bd83_a2b1_4fcd_ab55_f18f26360a39.slice/cri-containerd-693ce74fbce78fd11e2f7cbe2fc3ed9040639468aa312e1713b5c54ffe82e7f9.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b141e2e_6e65_4611_8519_fabcd986b84f.slice/cri-containerd-18495cf2e6c0b47f27f1b60b6d8bc7fa02d3634774633f3adf68fdd30d35e01d.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b141e2e_6e65_4611_8519_fabcd986b84f.slice/cri-containerd-ce300215528a05668efde0424a0f41b7186c24c403623c8adbad7970f1472056.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63d2329a_05d2_48d3_a4bf_a69c78583f3e.slice/cri-containerd-77d0329c4d4f45542768307dec4f9a1373a532006439b43b987a637a767243cb.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63d2329a_05d2_48d3_a4bf_a69c78583f3e.slice/cri-containerd-9e180a9ed3fff51b44e3663b1f9e0d5c046985bf6c575f19fd2ed9565156ebf9.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab0ca37d_a1b6_4510_824a_3014425a3c14.slice/cri-containerd-21341b4186f0aa2cd03e5788e8e4dd02ebbdce695eab1d73164cdbe55495c156.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab0ca37d_a1b6_4510_824a_3014425a3c14.slice/cri-containerd-b9e2ba006fad9ea8d69fadf02b848483f492bc26f18fd1198a2456a66cf00231.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod44264c8d_dd58_42eb_98cd_54ce35adfbd1.slice/cri-containerd-8d67c2476556e13ac51d11d494221409e70eb957ac7ecb3debc40ab891a619e9.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod44264c8d_dd58_42eb_98cd_54ce35adfbd1.slice/cri-containerd-4ab72372b28a0e11394124f101180f043b226cb740dc785b246e5e23fc2dd3f0.scope
    665      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94e9a786_7415_458b_b165_fb6bdd2c88b7.slice/cri-containerd-2b83d8cee084e23c9db4c689ff375c259f1f6e98a6bbb2d1fea0be5ef269a690.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94e9a786_7415_458b_b165_fb6bdd2c88b7.slice/cri-containerd-a44609e334e5b54a3c09f5eef2d33be14473186dafa0349538e2706bc8909d52.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94e9a786_7415_458b_b165_fb6bdd2c88b7.slice/cri-containerd-b0715e89cd3179fff97ee05dd8f7cffc2d2f98c7bc0d20b8ab96275d28fa1ff8.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94e9a786_7415_458b_b165_fb6bdd2c88b7.slice/cri-containerd-5b14a71a746190da0687423a362bc190d0f2b291a94222ddf26a60e6755c0f28.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c6901_7a4f_46ee_85b9_a3c8491ed287.slice/cri-containerd-b81cf536c4896fa9f2bddc7cac319b6d00672ed499aecc80a675efa28447fd5b.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c6901_7a4f_46ee_85b9_a3c8491ed287.slice/cri-containerd-7b7ee339cf3137b882cbc12372482b26d4fa4500c2f831c9ab9390b684e863ad.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode08c6901_7a4f_46ee_85b9_a3c8491ed287.slice/cri-containerd-0155951b8fb571ecc1c8a184bc9d097e8ffe32fff2b13409c1c3a68d24460dd5.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a822eb7_f5d0_459d_bac4_b8578e059e33.slice/cri-containerd-c0cbfdf7e7db96b2549236be007b4781433e8945c7da5ae5949165b8474fb8d3.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a822eb7_f5d0_459d_bac4_b8578e059e33.slice/cri-containerd-5eff805d225acd30d23f47a13e8212dfdf6804d2276f516b30633267677f082d.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf46e5ebe_4662_4436_aefe_af95ae8eb7d3.slice/cri-containerd-46355d7f8b94d1ed24f164caa4b3c2ab46df2d8f7c9b312c40a1437036b70ffd.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf46e5ebe_4662_4436_aefe_af95ae8eb7d3.slice/cri-containerd-acaa659fde19c2adbeb1505cb6dbcea45d3eb135b7fedce6be26b1dd92fdc1fa.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbf38cb5_8c6e_490d_8072_c221cd6b5a36.slice/cri-containerd-997eea29e27000b8013b8ab3dbba8c72f6ae76856f7fdf872c25b135eba0a6f7.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbf38cb5_8c6e_490d_8072_c221cd6b5a36.slice/cri-containerd-fb6489fdfae67a417aed781334863d8496dbcde21a0699bd4eea023d7ee75468.scope
    98       cgroup_device   multi                                          
