{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.820Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.841Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.421Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.464Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.479Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.523Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.530Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.562Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.823Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.833Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.889Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.940Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.959Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.586Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.619Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.641Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.679Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.687Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.914Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.929Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.986Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.023Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.100Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.675Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.679Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.745Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.749Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.782Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.042Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.047Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.100Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.118Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.151Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.760Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.770Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.772Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.775Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.797Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.858Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.865Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.896Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.189Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.216Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.263Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.288Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.309Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.321Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.783Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.803Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.836Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.849Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.878Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.107Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.132Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.184Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.187Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.196Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.617Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.670Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.677Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.725Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.731Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.764Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.991Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.002Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.044Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.058Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.091Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.533Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.639Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.649Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.686Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.721Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.730Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.956Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.964Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.024Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.034Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.072Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.442Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.479Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.498Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.536Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.537Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.551Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.785Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.791Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.850Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.853Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.902Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.331Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.334Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.386Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.391Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.423Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.780Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.849Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.922Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.934Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.972Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.291Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.297Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.337Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.353Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.377Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.654Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.659Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.721Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.768Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.772Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.096Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.102Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.147Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.149Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.186Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.471Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.488Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.494Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.521Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.318Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.320Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.443Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.446Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.516Z",
  "value": "id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.734Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.738Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.430Z",
  "value": "id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.443Z",
  "value": "id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71"
}

