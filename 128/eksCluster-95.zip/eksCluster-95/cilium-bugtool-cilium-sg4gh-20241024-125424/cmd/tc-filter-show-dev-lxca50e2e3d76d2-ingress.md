filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca50e2e3d76d2 direct-action not_in_hw id 517 tag 124b31ccb63ff8f0 jited 
