filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc93bc7c77219f direct-action not_in_hw id 3327 tag 04f339c21fcdf5c3 jited 
