top - 12:54:27 up 31 min,  0 users,  load average: 1.21, 0.71, 0.41
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 33.3 us, 60.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,    285.6 free,   1053.6 used,   2496.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2601.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3238 root      20   0 1244596  22012  14144 S  66.7   0.6   0:00.29 hubble
      1 root      20   0 1539060 287384  80648 S  13.3   7.3   1:07.39 cilium-+
    420 root      20   0 1229488   8856   2924 S   0.0   0.2   0:04.46 cilium-+
   3226 root      20   0    2208    780    700 S   0.0   0.0   0:00.00 timeout
   3250 root      20   0 1240176  16588  11356 S   0.0   0.4   0:00.02 cilium-+
   3251 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3277 root      20   0 1228744   3652   2976 S   0.0   0.1   0:00.00 gops
   3284 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
   3320 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3327 root      20   0    4280   2360   1928 R   0.0   0.1   0:00.00 iptable+
