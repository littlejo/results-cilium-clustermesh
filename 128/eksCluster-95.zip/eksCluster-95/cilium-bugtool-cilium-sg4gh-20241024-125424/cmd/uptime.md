 12:54:27 up 31 min,  0 users,  load average: 0.45, 0.55, 0.36
