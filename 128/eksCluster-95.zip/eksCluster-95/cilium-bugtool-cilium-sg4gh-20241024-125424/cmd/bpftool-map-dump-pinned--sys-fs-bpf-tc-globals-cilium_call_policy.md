key: 2b 00 00 00  value: 14 02 00 00
key: 34 01 00 00  value: df 0c 00 00
key: 94 03 00 00  value: 6e 02 00 00
key: 5b 05 00 00  value: 06 0d 00 00
key: 54 08 00 00  value: 1d 02 00 00
key: 61 08 00 00  value: 02 0d 00 00
key: 4e 09 00 00  value: 1e 02 00 00
Found 7 elements
