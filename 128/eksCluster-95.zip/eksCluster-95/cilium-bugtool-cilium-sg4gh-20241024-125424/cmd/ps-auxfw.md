USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3284  0.0  0.0 1228744 3656 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3277  0.0  0.0 1228744 3652 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3251  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3250  0.0  0.4 1240176 16588 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3303  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3226  0.0  0.0   2208   780 ?        Ss   12:54   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root        3238  0.0  0.5 1244596 22200 ?       Sl   12:54   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root           1  4.8  7.3 1539060 287384 ?      Ssl  12:31   1:07 cilium-agent --config-dir=/tmp/cilium/config-map
root         420  0.3  0.2 1229488 8856 ?        Sl   12:31   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
