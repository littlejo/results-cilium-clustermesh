IP ADDRESS         LOCAL ENDPOINT INFO
10.95.0.125:0      id=916   sec_id=6343771 flags=0x0000 ifindex=18  mac=EE:C2:98:CC:BB:1F nodemac=7A:83:91:03:2E:B1   
10.95.0.149:0      id=2145  sec_id=6345479 flags=0x0000 ifindex=24  mac=FA:2E:EA:5C:9F:C6 nodemac=9A:65:73:38:DA:71   
10.95.0.19:0       id=308   sec_id=6328369 flags=0x0000 ifindex=22  mac=26:DD:1C:CE:89:71 nodemac=DE:C1:5B:EC:20:EC   
172.31.229.144:0   (localhost)                                                                                        
10.95.0.201:0      id=1371  sec_id=6314108 flags=0x0000 ifindex=20  mac=5E:0A:CA:EC:1C:0A nodemac=8A:C6:C8:6A:BB:9E   
10.95.0.193:0      id=2382  sec_id=4     flags=0x0000 ifindex=10  mac=5E:F4:0B:24:2D:57 nodemac=6A:A5:0B:F9:40:D6     
10.95.0.179:0      (localhost)                                                                                        
10.95.0.79:0       id=43    sec_id=6324142 flags=0x0000 ifindex=12  mac=52:B1:6B:A2:58:42 nodemac=2E:58:85:51:08:DC   
10.95.0.134:0      id=2132  sec_id=6324142 flags=0x0000 ifindex=14  mac=DE:66:AC:1B:A1:F9 nodemac=D2:E9:4E:48:33:06   
172.31.209.239:0   (localhost)                                                                                        
