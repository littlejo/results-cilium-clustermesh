markdown output at /tmp/cilium-bugtool-20241024-125426.976+0000-UTC-1045945158/cmd/cilium-debuginfo-20241024-125457.867+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125426.976+0000-UTC-1045945158/cmd/cilium-debuginfo-20241024-125457.867+0000-UTC.json
