alloc: 122.99MB (128967832 bytes)
total-alloc: 3.08GB (3307666904 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75104179
frees: 73815240
heap-alloc: 122.99MB (128967832 bytes)
heap-sys: 176.85MB (185442304 bytes)
heap-idle: 32.77MB (34357248 bytes)
heap-in-use: 144.09MB (151085056 bytes)
heap-released: 9.62MB (10084352 bytes)
heap-objects: 1288939
stack-in-use: 35.12MB (36831232 bytes)
stack-sys: 35.12MB (36831232 bytes)
stack-mspan-inuse: 2.30MB (2407040 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 995.78KB (1019681 bytes)
gc-sys: 5.51MB (5776528 bytes)
next-gc: when heap-alloc >= 150.55MB (157858248 bytes)
last-gc: 2024-10-24 12:54:27.654265214 +0000 UTC
gc-pause-total: 13.937636ms
gc-pause: 82099
gc-pause-end: 1729774467654265214
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006769584870634158
enable-gc: true
debug-gc: false
