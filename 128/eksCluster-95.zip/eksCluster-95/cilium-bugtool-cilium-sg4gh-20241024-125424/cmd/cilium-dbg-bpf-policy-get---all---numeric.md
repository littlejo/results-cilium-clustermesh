Endpoint ID: 43
Path: /sys/fs/bpf/tc/globals/cilium_policy_00043

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2974     29        0        
Allow    Ingress     1          ANY          NONE         disabled    131100   1501      0        
Allow    Egress      0          ANY          NONE         disabled    19496    217       0        


Endpoint ID: 308
Path: /sys/fs/bpf/tc/globals/cilium_policy_00308

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    380179   4443      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 905
Path: /sys/fs/bpf/tc/globals/cilium_policy_00905

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 916
Path: /sys/fs/bpf/tc/globals/cilium_policy_00916

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6162411   62040     0        
Allow    Ingress     1          ANY          NONE         disabled    5416325   57185     0        
Allow    Egress      0          ANY          NONE         disabled    6929234   68437     0        


Endpoint ID: 1371
Path: /sys/fs/bpf/tc/globals/cilium_policy_01371

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2132
Path: /sys/fs/bpf/tc/globals/cilium_policy_02132

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2922     31        0        
Allow    Ingress     1          ANY          NONE         disabled    130847   1493      0        
Allow    Egress      0          ANY          NONE         disabled    19823    220       0        


Endpoint ID: 2145
Path: /sys/fs/bpf/tc/globals/cilium_policy_02145

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2382
Path: /sys/fs/bpf/tc/globals/cilium_policy_02382

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6242208   77151     0        
Allow    Ingress     1          ANY          NONE         disabled    62754     761       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


