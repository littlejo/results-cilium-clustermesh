key: 07 00 00 00  value: 0a 5f 00 86 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 5f 00 4f 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 5f 00 7d 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f cd 35 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 5f 00 86 00 35 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 5f 00 13 1f 90 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b2 0d 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 5f 00 4f 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f e5 90 10 94 00 00  00 00 00 00
Found 9 elements
