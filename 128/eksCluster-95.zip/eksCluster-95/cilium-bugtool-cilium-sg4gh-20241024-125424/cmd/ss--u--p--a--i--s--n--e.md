Total: 573
TCP:   2603 (estab 313, closed 2271, orphaned 0, timewait 1804)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  332       320       12       
INET	  342       326       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.229.144%ens5:68         0.0.0.0:*    uid:192 ino:137625 sk:84c cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34062 sk:84d cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15369 sk:84e cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:43945      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:33922 sk:84f fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34061 sk:850 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15370 sk:851 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::805:18ff:fe78:d0cb]%ens5:546           [::]:*    uid:192 ino:15450 sk:852 cgroup:unreachable:bd0 v6only:1 <->                   
