Node 0, zone      DMA    132     74     32     20     20      5      8      3      3      4     42 
Node 0, zone   Normal    431     41     17      3     21      7      6      8      4      2      6 
