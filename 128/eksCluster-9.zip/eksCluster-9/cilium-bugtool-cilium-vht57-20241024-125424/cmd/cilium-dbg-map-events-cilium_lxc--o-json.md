{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.856Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.391Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.440Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.443Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.489Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.505Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.539Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.747Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.754Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.823Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.836Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.875Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.562Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.574Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.614Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.625Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.653Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.934Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.940Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.983Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.031Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.046Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.570Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.574Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.609Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.613Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.649Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.689Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.695Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.940Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.945Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.002Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.019Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.056Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.668Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.688Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.722Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.734Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.762Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.028Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.047Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.156Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.163Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.195Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.540Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.540Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.598Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.610Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.633Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.876Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.883Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.934Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.955Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.972Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.363Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.393Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.403Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.461Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.466Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.496Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.743Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.747Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.797Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.822Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.841Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.281Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.311Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.318Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.353Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.380Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.388Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.653Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.663Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.705Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.732Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.753Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.179Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.205Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.220Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.257Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.258Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.271Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.519Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.522Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.573Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.590Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.622Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.005Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.116Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.128Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.161Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.161Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.184Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.391Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.399Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.449Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.457Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.501Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.762Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.821Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.822Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.869Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.889Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.902Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.144Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.150Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.204Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.232Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.245Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.547Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.562Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.604Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.618Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.644Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.929Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.934Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.961Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.967Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.010Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.661Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.665Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.696Z",
  "value": "id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.709Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.729Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.041Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.049Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.694Z",
  "value": "id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.702Z",
  "value": "id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D"
}

