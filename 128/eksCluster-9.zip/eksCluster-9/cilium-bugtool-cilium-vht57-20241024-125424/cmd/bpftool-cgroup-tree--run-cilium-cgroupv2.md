CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod669152e8_8f27_45d4_aaa2_2b59068811bf.slice/cri-containerd-1bda7365353c0b89f09ae4c05174b7f6d0f890c14cd09659e3ddd78c09a00991.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod669152e8_8f27_45d4_aaa2_2b59068811bf.slice/cri-containerd-9d6fffb4a8907938904e7c37c8dad05db637c0c2078012ef357936cdb0123d3c.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22fef4fd_6b17_4ad3_b0eb_63a6d1c3a4b2.slice/cri-containerd-a0e361c877cce6e50199193ee0eae7359f94fe7f3ca19053b59be00f8e2b1365.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22fef4fd_6b17_4ad3_b0eb_63a6d1c3a4b2.slice/cri-containerd-c82582945b17777d6ece6395d7caadb0b35f91c134cdafea422e36276d2f56be.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1625e9b0_e31d_4f71_9de9_c70b2a3e111b.slice/cri-containerd-8359186dfc3405a61c9eab576fbbafce2d4d3104db486493b9bc1db0f54c895e.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1625e9b0_e31d_4f71_9de9_c70b2a3e111b.slice/cri-containerd-6d02e7122081d41e86ffbdc9dcf39a72bd6a0b71df144d2660e37a5b9e15027a.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4c04c38_c91b_4625_b805_42c865b1daec.slice/cri-containerd-d24b4ff1f0efca9c263f0720a67f69907a3006901fc8da1f67106e842aef2910.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4c04c38_c91b_4625_b805_42c865b1daec.slice/cri-containerd-5dbbb7b3ed88af6b8216b1d00c6dbf467f7fc42193e833cddf140a1e9d5d038c.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e726f07_7bdc_4b80_bbb2_1a61c5feb143.slice/cri-containerd-7f6bcd804943fd2b06567de1a15e6f8651f90af09419e274a337facb2309d669.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e726f07_7bdc_4b80_bbb2_1a61c5feb143.slice/cri-containerd-d7965421f21fb15937fc448d7d0804e437994c7578d60d7be5e46f78ce53fab8.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36dfe672_ddfb_4b16_85b4_d2d1cbcbc012.slice/cri-containerd-2cf7c25d4b581b0392d5f3fec6d12eb65ea52a5cdf289a79e574e6a5e2a2564a.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36dfe672_ddfb_4b16_85b4_d2d1cbcbc012.slice/cri-containerd-4fb71acfd69427e4094a75ed738cd5a2a1a91f3fa933d03ee5df24f183e64ad2.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36dfe672_ddfb_4b16_85b4_d2d1cbcbc012.slice/cri-containerd-1d4d1efcaae6cb3923c679c7462d41662b02669efedcf088032219b15d0061a8.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6b61767_72a5_4e8f_b497_903955ed39dd.slice/cri-containerd-5a9b837ce77b2646b961f1b97aa8ba974b3b6b1ba08256b7c479ab5e35e36803.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6b61767_72a5_4e8f_b497_903955ed39dd.slice/cri-containerd-5e8939a544b56ed58f02b167eb45ddce55c74428781d85ff4d4797e4eaabd113.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6b61767_72a5_4e8f_b497_903955ed39dd.slice/cri-containerd-287935ca25e21d4739221f2c990aab60dd937aba46247dda1b3af5c76120e168.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6b61767_72a5_4e8f_b497_903955ed39dd.slice/cri-containerd-e0b681df605fed8feff8183e2b7a9f3bce72dca83057302b0181fc96cc1016dc.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0610145_f3ab_4f02_85ac_6b770ddb1955.slice/cri-containerd-e03558548ed4e5b63d8cf5f1ba7e9f06fca27696e5555c4de167121b67a02c31.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0610145_f3ab_4f02_85ac_6b770ddb1955.slice/cri-containerd-cbf1c80f3991ba06bed66e911b1008f64d1f34e8e121ed681ad6ec511de34b31.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0c1dea1_05dc_489e_8181_c46df34fba80.slice/cri-containerd-c634c6d3eb64976717ec6f0eab90f1619534059434f131993655c752cd3e2129.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0c1dea1_05dc_489e_8181_c46df34fba80.slice/cri-containerd-ebfacfa7f8984f0a22475ac056bcd55a76669f86e8432397750f6d1e7e62d593.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99d9cb34_7950_4520_b9f2_cb11081fef64.slice/cri-containerd-c4fb9ef68378eb419a606aec3a06280a72d8a4e63a0a1f4408e810a238304080.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99d9cb34_7950_4520_b9f2_cb11081fef64.slice/cri-containerd-d6914423842d673fc565930e7f2f8db0c688d37ae2b00e99f99ea10b61baace0.scope
    93       cgroup_device   multi                                          
