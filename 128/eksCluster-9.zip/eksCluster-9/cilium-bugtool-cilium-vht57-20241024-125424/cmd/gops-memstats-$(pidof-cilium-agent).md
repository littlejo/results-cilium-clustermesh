alloc: 92.38MB (96864696 bytes)
total-alloc: 3.10GB (3323704576 bytes)
sys: 223.39MB (234243412 bytes)
lookups: 0
mallocs: 75153739
frees: 74368817
heap-alloc: 92.38MB (96864696 bytes)
heap-sys: 176.58MB (185155584 bytes)
heap-idle: 45.57MB (47783936 bytes)
heap-in-use: 131.01MB (137371648 bytes)
heap-released: 3.83MB (4014080 bytes)
heap-objects: 784922
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.14MB (2239840 bytes)
stack-mspan-sys: 2.83MB (2970240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 994.20KB (1018065 bytes)
gc-sys: 5.54MB (5807224 bytes)
next-gc: when heap-alloc >= 152.00MB (159381048 bytes)
last-gc: 2024-10-24 12:54:35.3360277 +0000 UTC
gc-pause-total: 18.817307ms
gc-pause: 70776
gc-pause-end: 1729774475336027700
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.0004944933432847073
enable-gc: true
debug-gc: false
