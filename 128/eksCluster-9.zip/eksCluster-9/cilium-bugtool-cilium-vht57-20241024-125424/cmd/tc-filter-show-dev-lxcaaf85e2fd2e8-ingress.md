filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcaaf85e2fd2e8 direct-action not_in_hw id 647 tag f837a6d1cbe9d215 jited 
