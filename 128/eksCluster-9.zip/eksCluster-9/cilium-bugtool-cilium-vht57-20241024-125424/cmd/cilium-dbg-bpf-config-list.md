KEY             VALUE
AgentLiveness   2060405191056
UTimeOffset     3378461789062500
