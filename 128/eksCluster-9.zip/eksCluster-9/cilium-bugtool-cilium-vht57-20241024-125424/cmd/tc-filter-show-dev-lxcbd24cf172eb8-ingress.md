filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbd24cf172eb8 direct-action not_in_hw id 3346 tag bb484d0cb8fa6f67 jited 
