1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c1:b3:4e:ac:ff brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.244.235/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3382sec preferred_lft 3382sec
    inet6 fe80::8c1:b3ff:fe4e:acff/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:81:34:16:c5:97 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.200.175/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::881:34ff:fe16:c597/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:c2:47:68:43:11 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e0c2:47ff:fe68:4311/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:3f:00:83:95:03 brd ff:ff:ff:ff:ff:ff
    inet 10.9.0.250/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::903f:ff:fe83:9503/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 72:7f:ec:33:cb:54 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::707f:ecff:fe33:cb54/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:dc:ee:f2:3e:8f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e0dc:eeff:fef2:3e8f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7c5b5c57469c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:9b:54:33:f3:4b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::89b:54ff:fe33:f34b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce814fa42dccb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:ea:1e:d9:ea:1e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f8ea:1eff:fed9:ea1e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcaaf85e2fd2e8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:94:db:6c:ad:98 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4094:dbff:fe6c:ad98/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc732ca2ed1a59@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:23:8f:5c:ef:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::d023:8fff:fe5c:efc6/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcc4e246237170@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:ff:6c:66:1b:2c brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::1cff:6cff:fe66:1b2c/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcbd24cf172eb8@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:5d:63:91:34:0d brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::1c5d:63ff:fe91:340d/64 scope link 
       valid_lft forever preferred_lft forever
