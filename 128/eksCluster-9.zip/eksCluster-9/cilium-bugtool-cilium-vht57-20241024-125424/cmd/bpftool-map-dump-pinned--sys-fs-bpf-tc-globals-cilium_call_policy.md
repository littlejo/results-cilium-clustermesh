key: 5f 00 00 00  value: 83 02 00 00
key: 81 04 00 00  value: d4 0c 00 00
key: 26 05 00 00  value: 11 0d 00 00
key: 50 08 00 00  value: 0e 02 00 00
key: de 08 00 00  value: 46 02 00 00
key: cb 0e 00 00  value: 1b 02 00 00
key: d8 0e 00 00  value: 0e 0d 00 00
Found 7 elements
