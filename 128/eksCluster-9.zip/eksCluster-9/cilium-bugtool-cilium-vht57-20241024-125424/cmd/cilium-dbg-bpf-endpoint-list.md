IP ADDRESS         LOCAL ENDPOINT INFO
10.9.0.63:0        id=95    sec_id=658762 flags=0x0000 ifindex=18  mac=A6:00:CD:89:05:08 nodemac=42:94:DB:6C:AD:98   
10.9.0.205:0       id=2270  sec_id=4     flags=0x0000 ifindex=10  mac=5E:C4:12:D5:0D:58 nodemac=E2:DC:EE:F2:3E:8F    
10.9.0.250:0       (localhost)                                                                                       
172.31.244.235:0   (localhost)                                                                                       
10.9.0.158:0       id=1153  sec_id=703247 flags=0x0000 ifindex=22  mac=2E:8E:79:B1:F4:9B nodemac=1E:FF:6C:66:1B:2C   
172.31.200.175:0   (localhost)                                                                                       
10.9.0.22:0        id=2128  sec_id=679433 flags=0x0000 ifindex=12  mac=DA:EA:C7:7C:28:14 nodemac=0A:9B:54:33:F3:4B   
10.9.0.41:0        id=3800  sec_id=682232 flags=0x0000 ifindex=20  mac=4E:C8:A2:5E:E1:2C nodemac=D2:23:8F:5C:EF:C6   
10.9.0.173:0       id=1318  sec_id=671800 flags=0x0000 ifindex=24  mac=E6:DB:38:E2:64:F0 nodemac=1E:5D:63:91:34:0D   
10.9.0.236:0       id=3787  sec_id=679433 flags=0x0000 ifindex=14  mac=32:54:11:13:9C:52 nodemac=FA:EA:1E:D9:EA:1E   
