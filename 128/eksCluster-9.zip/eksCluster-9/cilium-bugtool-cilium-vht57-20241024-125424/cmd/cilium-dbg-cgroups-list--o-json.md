[
  {
    "containers": [
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36dfe672_ddfb_4b16_85b4_d2d1cbcbc012.slice/cri-containerd-2cf7c25d4b581b0392d5f3fec6d12eb65ea52a5cdf289a79e574e6a5e2a2564a.scope"
      },
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36dfe672_ddfb_4b16_85b4_d2d1cbcbc012.slice/cri-containerd-1d4d1efcaae6cb3923c679c7462d41662b02669efedcf088032219b15d0061a8.scope"
      }
    ],
    "ips": [
      "10.9.0.158"
    ],
    "name": "echo-same-node-86d9cc975c-klwpf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1625e9b0_e31d_4f71_9de9_c70b2a3e111b.slice/cri-containerd-8359186dfc3405a61c9eab576fbbafce2d4d3104db486493b9bc1db0f54c895e.scope"
      }
    ],
    "ips": [
      "10.9.0.22"
    ],
    "name": "coredns-cc6ccd49c-vkxqx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod669152e8_8f27_45d4_aaa2_2b59068811bf.slice/cri-containerd-9d6fffb4a8907938904e7c37c8dad05db637c0c2078012ef357936cdb0123d3c.scope"
      }
    ],
    "ips": [
      "10.9.0.236"
    ],
    "name": "coredns-cc6ccd49c-vgz7g",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0c1dea1_05dc_489e_8181_c46df34fba80.slice/cri-containerd-c634c6d3eb64976717ec6f0eab90f1619534059434f131993655c752cd3e2129.scope"
      }
    ],
    "ips": [
      "10.9.0.173"
    ],
    "name": "client2-57cf4468f-75t6w",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e726f07_7bdc_4b80_bbb2_1a61c5feb143.slice/cri-containerd-d7965421f21fb15937fc448d7d0804e437994c7578d60d7be5e46f78ce53fab8.scope"
      }
    ],
    "ips": [
      "10.9.0.41"
    ],
    "name": "client-974f6c69d-g692m",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6b61767_72a5_4e8f_b497_903955ed39dd.slice/cri-containerd-5e8939a544b56ed58f02b167eb45ddce55c74428781d85ff4d4797e4eaabd113.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6b61767_72a5_4e8f_b497_903955ed39dd.slice/cri-containerd-287935ca25e21d4739221f2c990aab60dd937aba46247dda1b3af5c76120e168.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6b61767_72a5_4e8f_b497_903955ed39dd.slice/cri-containerd-e0b681df605fed8feff8183e2b7a9f3bce72dca83057302b0181fc96cc1016dc.scope"
      }
    ],
    "ips": [
      "10.9.0.63"
    ],
    "name": "clustermesh-apiserver-774dcc7646-m7nf9",
    "namespace": "kube-system"
  }
]

