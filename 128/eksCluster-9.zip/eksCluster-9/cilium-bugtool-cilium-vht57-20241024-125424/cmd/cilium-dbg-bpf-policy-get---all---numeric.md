Endpoint ID: 95
Path: /sys/fs/bpf/tc/globals/cilium_policy_00095

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6108794   60307     0        
Allow    Ingress     1          ANY          NONE         disabled    5038553   52970     0        
Allow    Egress      0          ANY          NONE         disabled    5734849   57871     0        


Endpoint ID: 138
Path: /sys/fs/bpf/tc/globals/cilium_policy_00138

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1153
Path: /sys/fs/bpf/tc/globals/cilium_policy_01153

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    381198   4455      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1318
Path: /sys/fs/bpf/tc/globals/cilium_policy_01318

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2128
Path: /sys/fs/bpf/tc/globals/cilium_policy_02128

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2782     30        0        
Allow    Ingress     1          ANY          NONE         disabled    169270   1954      0        
Allow    Egress      0          ANY          NONE         disabled    20730    233       0        


Endpoint ID: 2270
Path: /sys/fs/bpf/tc/globals/cilium_policy_02270

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6239791   77289     0        
Allow    Ingress     1          ANY          NONE         disabled    67148     809       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3787
Path: /sys/fs/bpf/tc/globals/cilium_policy_03787

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3114     30        0        
Allow    Ingress     1          ANY          NONE         disabled    169421   1951      0        
Allow    Egress      0          ANY          NONE         disabled    21359    238       0        


Endpoint ID: 3800
Path: /sys/fs/bpf/tc/globals/cilium_policy_03800

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


