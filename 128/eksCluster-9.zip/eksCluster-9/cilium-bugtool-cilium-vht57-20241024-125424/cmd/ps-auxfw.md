USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3280  0.0  0.4 1240176 15736 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3296  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3297  0.0  0.0    132     4 ?        R    12:54   0:00  \_ [hostname]
root        3265  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3259  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3249  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  3.7  7.6 1539132 298824 ?      Ssl  12:25   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         401  0.2  0.2 1229744 9716 ?        Sl   12:25   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
