markdown output at /tmp/cilium-bugtool-20241024-125425.93+0000-UTC-1793637172/cmd/cilium-debuginfo-20241024-125456.538+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125425.93+0000-UTC-1793637172/cmd/cilium-debuginfo-20241024-125456.538+0000-UTC.json
