[
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e0c16d_2929_4d56_b043_de15cecdc5b3.slice/cri-containerd-e0be0cd1a55d7e0939967c14a76c1e8433c1cd57cbc65e66daa1b8d3a0e11140.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e0c16d_2929_4d56_b043_de15cecdc5b3.slice/cri-containerd-66780aa290037799415123183ad13bde9b0293dd7ebbdb175fc8d19a7bd418f7.scope"
      }
    ],
    "ips": [
      "10.0.0.157"
    ],
    "name": "echo-same-node-86d9cc975c-ljgcl",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8124,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf35787de_12bb_4ecb_b51d_48228309f66c.slice/cri-containerd-5cc54a20f69cf1fdfc04bd9ce7a7bc2bcfed345fd40b90ff3670126f3fb41121.scope"
      },
      {
        "cgroup-id": 8208,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf35787de_12bb_4ecb_b51d_48228309f66c.slice/cri-containerd-c50928a8cb5a4ee7354d88b2ef4212ad471da6f914227896c6c56176edce01bd.scope"
      },
      {
        "cgroup-id": 8292,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf35787de_12bb_4ecb_b51d_48228309f66c.slice/cri-containerd-249792f7fbb5c0f95371373537f7f0a2faefe2d3303a95b7b402dfc4f5e70216.scope"
      }
    ],
    "ips": [
      "10.0.0.23"
    ],
    "name": "clustermesh-apiserver-68f5786f77-jb544",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6732,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d2e09a0_b648_43e7_a747_e87bbd606858.slice/cri-containerd-1183cbbd3627a61070c62210b4463a1b15330c36eccec12b36678041be79d1d4.scope"
      }
    ],
    "ips": [
      "10.0.0.21"
    ],
    "name": "coredns-cc6ccd49c-bjksk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8880,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0823fd4e_4505_4f08_81c6_b564f3d4b389.slice/cri-containerd-bf969636bade785167010e4846703658b357319abb33c6ea58df749fc7c1d4bf.scope"
      }
    ],
    "ips": [
      "10.0.0.37"
    ],
    "name": "client-974f6c69d-t5cjw",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 6648,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod49c4f8c5_010f_496b_80a7_b5c49d20353a.slice/cri-containerd-0c7127d250e0fb50e0191d7692f0b6d6c5c7e59f50bbf893f066bb6537196f92.scope"
      }
    ],
    "ips": [
      "10.0.0.103"
    ],
    "name": "coredns-cc6ccd49c-fnx6j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8964,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd97829b4_8dc8_41b6_bdab_3fa9224ea3be.slice/cri-containerd-543e199e1afa5bf81d9aab6f59b5cec12ef2d1075b8a751908c5052606c0dde0.scope"
      }
    ],
    "ips": [
      "10.0.0.246"
    ],
    "name": "client2-57cf4468f-z4dcv",
    "namespace": "cilium-test-1"
  }
]

