CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod49c4f8c5_010f_496b_80a7_b5c49d20353a.slice/cri-containerd-0c7127d250e0fb50e0191d7692f0b6d6c5c7e59f50bbf893f066bb6537196f92.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod49c4f8c5_010f_496b_80a7_b5c49d20353a.slice/cri-containerd-927afb7082320feb09e9a8e1f32fa974a2f45f21280df43528eeb9fdcbfcba1e.scope
    491      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84677ee9_7230_4c19_81a3_cc46df978f1d.slice/cri-containerd-b2c9a61c0d02690e2bab0dfbce7d162b1010ef322e6f74e0d2be24ad5ac1c0ab.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84677ee9_7230_4c19_81a3_cc46df978f1d.slice/cri-containerd-2165bed23095c3e7a8aa1979fec7350676e1470de090d474576222d4ce813ac0.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d2e09a0_b648_43e7_a747_e87bbd606858.slice/cri-containerd-b42ecb1bc3b42654290658c12de5d041df064de2cf045e94537ffc5dbcf22467.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d2e09a0_b648_43e7_a747_e87bbd606858.slice/cri-containerd-1183cbbd3627a61070c62210b4463a1b15330c36eccec12b36678041be79d1d4.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b744b9c_5ff0_4732_bd9f_0a1f92e54900.slice/cri-containerd-0e6db314378619baf6ea53a1d3137401d87eafeeccca8a3b77069956edfacdc4.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b744b9c_5ff0_4732_bd9f_0a1f92e54900.slice/cri-containerd-5d5ce1957afb00fe120da59a058894de0543ae4175160b5614bdbd06fde60fe2.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2cd70e3_4533_41de_92ee_f80fa1b87a99.slice/cri-containerd-12cf156df55d24af81835299ef8531f9c095c7541d4ffd167745acf93c87b174.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2cd70e3_4533_41de_92ee_f80fa1b87a99.slice/cri-containerd-585728653e8868382762902b756fb0ca1dcc71130af7924246f2f925948986cd.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd97829b4_8dc8_41b6_bdab_3fa9224ea3be.slice/cri-containerd-543e199e1afa5bf81d9aab6f59b5cec12ef2d1075b8a751908c5052606c0dde0.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd97829b4_8dc8_41b6_bdab_3fa9224ea3be.slice/cri-containerd-4ed073f90f7542de6e282eb594460e6451c2a594a78940a34c404d56671c12a0.scope
    659      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e0c16d_2929_4d56_b043_de15cecdc5b3.slice/cri-containerd-66780aa290037799415123183ad13bde9b0293dd7ebbdb175fc8d19a7bd418f7.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e0c16d_2929_4d56_b043_de15cecdc5b3.slice/cri-containerd-e0be0cd1a55d7e0939967c14a76c1e8433c1cd57cbc65e66daa1b8d3a0e11140.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e0c16d_2929_4d56_b043_de15cecdc5b3.slice/cri-containerd-062d18335fd62b0e11ef6422b2d59ad461feada37859cd77d24b99270208a0e5.scope
    655      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0823fd4e_4505_4f08_81c6_b564f3d4b389.slice/cri-containerd-bf969636bade785167010e4846703658b357319abb33c6ea58df749fc7c1d4bf.scope
    663      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0823fd4e_4505_4f08_81c6_b564f3d4b389.slice/cri-containerd-e203b2628c8d5a6d4a93097f11cb39e9be4d608f1498c51dca6d7a64699f42ce.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf35787de_12bb_4ecb_b51d_48228309f66c.slice/cri-containerd-5cc54a20f69cf1fdfc04bd9ce7a7bc2bcfed345fd40b90ff3670126f3fb41121.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf35787de_12bb_4ecb_b51d_48228309f66c.slice/cri-containerd-249792f7fbb5c0f95371373537f7f0a2faefe2d3303a95b7b402dfc4f5e70216.scope
    614      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf35787de_12bb_4ecb_b51d_48228309f66c.slice/cri-containerd-42866ac1168cb9e86417403be363610fd6d8caf3ae20479c20ea64e8872f77c3.scope
    590      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf35787de_12bb_4ecb_b51d_48228309f66c.slice/cri-containerd-c50928a8cb5a4ee7354d88b2ef4212ad471da6f914227896c6c56176edce01bd.scope
    610      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5c5e03f_f54f_4f75_8f92_53f6b633ffe2.slice/cri-containerd-d47e277dbdc468f6d32f18224456631a82ede10c8d983c766b69a852b5502da5.scope
    58       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5c5e03f_f54f_4f75_8f92_53f6b633ffe2.slice/cri-containerd-22f9da76d6081ebeeb4e4f648b8c3eef35e7af2c74f39d4bb048f5deb78e1238.scope
    69       cgroup_device   multi                                          
