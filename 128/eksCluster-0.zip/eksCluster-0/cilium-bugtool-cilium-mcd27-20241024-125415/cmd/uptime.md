 12:54:16 up 56 min,  0 users,  load average: 0.51, 0.51, 0.26
