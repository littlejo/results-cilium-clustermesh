xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 523
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 521
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 508
cilium_host(4) clsact/egress cil_from_host-cilium_host id 511
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 444
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 441
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 480
lxcaa088868aa70(9) clsact/ingress cil_from_container-lxcaa088868aa70 id 502
lxc58fced1c2384(11) clsact/ingress cil_from_container-lxc58fced1c2384 id 470
lxcaaa5f80d1ac1(15) clsact/ingress cil_from_container-lxcaaa5f80d1ac1 id 581
lxc513843fe4e2a(17) clsact/ingress cil_from_container-lxc513843fe4e2a id 3308
lxc8293473ab8f8(19) clsact/ingress cil_from_container-lxc8293473ab8f8 id 3250
lxc6a035b4df485(21) clsact/ingress cil_from_container-lxc6a035b4df485 id 3296

flow_dissector:

netfilter:

