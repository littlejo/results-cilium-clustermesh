IP ADDRESS         LOCAL ENDPOINT INFO
10.0.0.103:0       id=343   sec_id=94108 flags=0x0000 ifindex=9   mac=0A:B7:E4:1D:B3:24 nodemac=2E:54:60:63:2B:FE   
10.0.0.21:0        id=762   sec_id=94108 flags=0x0000 ifindex=11  mac=92:54:31:F1:67:45 nodemac=FA:6B:31:F8:FB:0C   
172.31.177.192:0   (localhost)                                                                                      
10.0.0.23:0        id=2465  sec_id=91897 flags=0x0000 ifindex=15  mac=8E:68:52:49:54:44 nodemac=26:DC:FA:2E:B3:BA   
10.0.0.37:0        id=3995  sec_id=86574 flags=0x0000 ifindex=17  mac=AE:2C:CB:44:DD:F7 nodemac=3A:F3:FD:3D:EC:92   
10.0.0.246:0       id=805   sec_id=67909 flags=0x0000 ifindex=21  mac=26:31:01:07:C5:C6 nodemac=5E:02:EB:7B:EF:04   
10.0.0.109:0       (localhost)                                                                                      
10.0.0.157:0       id=3151  sec_id=94443 flags=0x0000 ifindex=19  mac=0E:75:9A:B9:2B:5D nodemac=86:26:05:39:52:91   
10.0.0.122:0       id=53    sec_id=4     flags=0x0000 ifindex=7   mac=36:41:8D:10:43:AE nodemac=66:2F:34:72:84:1D   
