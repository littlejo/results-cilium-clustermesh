REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     135992    11015862    677    bpf_overlay.c
Interface                   INGRESS     711183    268976672   1132   bpf_host.c
Policy denied               EGRESS      61        4514        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      137689    11158649    53     encap.h
Success                     EGRESS      160294    20678415    1308   bpf_lxc.c
Success                     EGRESS      596       156261      86     l3.h
Success                     EGRESS      59771     4850899     1694   bpf_host.c
Success                     INGRESS     184901    21197636    86     l3.h
Success                     INGRESS     262351    27561470    235    trace.h
Unsupported L3 protocol     EGRESS      74        5560        1492   bpf_lxc.c
