1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:95:b7:94:67:f7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.177.192/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1998sec preferred_lft 1998sec
    inet6 fe80::495:b7ff:fe94:67f7/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:68:8e:dc:6e:f1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b468:8eff:fedc:6ef1/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:bf:8c:53:64:84 brd ff:ff:ff:ff:ff:ff
    inet 10.0.0.109/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::78bf:8cff:fe53:6484/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6e:ef:9f:52:97:62 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6cef:9fff:fe52:9762/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:2f:34:72:84:1d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::642f:34ff:fe72:841d/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcaa088868aa70@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:54:60:63:2b:fe brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2c54:60ff:fe63:2bfe/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc58fced1c2384@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:6b:31:f8:fb:0c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f86b:31ff:fef8:fb0c/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcaaa5f80d1ac1@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:dc:fa:2e:b3:ba brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::24dc:faff:fe2e:b3ba/64 scope link 
       valid_lft forever preferred_lft forever
17: lxc513843fe4e2a@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:f3:fd:3d:ec:92 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::38f3:fdff:fe3d:ec92/64 scope link 
       valid_lft forever preferred_lft forever
19: lxc8293473ab8f8@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:26:05:39:52:91 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::8426:5ff:fe39:5291/64 scope link 
       valid_lft forever preferred_lft forever
21: lxc6a035b4df485@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:02:eb:7b:ef:04 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::5c02:ebff:fe7b:ef04/64 scope link 
       valid_lft forever preferred_lft forever
