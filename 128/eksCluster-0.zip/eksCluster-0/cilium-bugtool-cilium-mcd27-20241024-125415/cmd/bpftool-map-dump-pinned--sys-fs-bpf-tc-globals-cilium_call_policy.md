key: 35 00 00 00  value: e3 01 00 00
key: 57 01 00 00  value: fb 01 00 00
key: fa 02 00 00  value: d9 01 00 00
key: 25 03 00 00  value: f0 0c 00 00
key: a1 09 00 00  value: 4a 02 00 00
key: 4f 0c 00 00  value: b8 0c 00 00
key: 9b 0f 00 00  value: f1 0c 00 00
Found 7 elements
