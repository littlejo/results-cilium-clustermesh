filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcaaa5f80d1ac1 direct-action not_in_hw id 581 tag b7be5372cbd217a0 jited 
