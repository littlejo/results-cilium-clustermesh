alloc: 120.59MB (126452600 bytes)
total-alloc: 3.35GB (3597289360 bytes)
sys: 231.32MB (242558292 bytes)
lookups: 0
mallocs: 78656532
frees: 77406497
heap-alloc: 120.59MB (126452600 bytes)
heap-sys: 184.52MB (193478656 bytes)
heap-idle: 39.09MB (40984576 bytes)
heap-in-use: 145.43MB (152494080 bytes)
heap-released: 15.37MB (16113664 bytes)
heap-objects: 1250035
stack-in-use: 35.44MB (37158912 bytes)
stack-sys: 35.44MB (37158912 bytes)
stack-mspan-inuse: 2.36MB (2473280 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 978.80KB (1002289 bytes)
gc-sys: 5.53MB (5794912 bytes)
next-gc: when heap-alloc >= 157.44MB (165089912 bytes)
last-gc: 2024-10-24 12:54:16.698135147 +0000 UTC
gc-pause-total: 30.0621ms
gc-pause: 63436
gc-pause-end: 1729774456698135147
num-gc: 115
num-forced-gc: 0
gc-cpu-fraction: 0.0003457851583105803
enable-gc: true
debug-gc: false
