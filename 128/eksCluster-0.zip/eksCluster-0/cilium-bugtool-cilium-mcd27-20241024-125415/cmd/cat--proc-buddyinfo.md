Node 0, zone      DMA     93     15      2     15     17     11     26     28     13      6    129 
Node 0, zone   Normal     78     85    145     90     69     25     10      4      2      1      5 
