filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6a035b4df485 direct-action not_in_hw id 3296 tag c8e5d40440f470fa jited 
