filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8293473ab8f8 direct-action not_in_hw id 3250 tag 3de57c5d4e944119 jited 
