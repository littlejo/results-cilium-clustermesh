Endpoint ID: 53
Path: /sys/fs/bpf/tc/globals/cilium_policy_00053

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6209281   76876     0        
Allow    Ingress     1          ANY          NONE         disabled    91476     1092      0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 343
Path: /sys/fs/bpf/tc/globals/cilium_policy_00343

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1836     19        0        
Allow    Ingress     1          ANY          NONE         disabled    325571   3745      0        
Allow    Egress      0          ANY          NONE         disabled    37193    411       0        


Endpoint ID: 762
Path: /sys/fs/bpf/tc/globals/cilium_policy_00762

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4060     41        0        
Allow    Ingress     1          ANY          NONE         disabled    323710   3727      0        
Allow    Egress      0          ANY          NONE         disabled    36038    399       0        


Endpoint ID: 805
Path: /sys/fs/bpf/tc/globals/cilium_policy_00805

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2444
Path: /sys/fs/bpf/tc/globals/cilium_policy_02444

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2465
Path: /sys/fs/bpf/tc/globals/cilium_policy_02465

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6000728   61177     0        
Allow    Ingress     1          ANY          NONE         disabled    5761231   60937     0        
Allow    Egress      0          ANY          NONE         disabled    7732829   75459     0        


Endpoint ID: 3151
Path: /sys/fs/bpf/tc/globals/cilium_policy_03151

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377093   4410      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3995
Path: /sys/fs/bpf/tc/globals/cilium_policy_03995

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


