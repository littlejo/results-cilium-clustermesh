{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:28.028Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:28.032Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:28.087Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:28.114Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:28.133Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.724Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.738Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.788Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.803Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.876Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.038Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.047Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.111Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.117Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.152Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.638Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.639Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.683Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.710Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.740Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.769Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.778Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.979Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.987Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.024Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.051Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.080Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.706Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.709Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.748Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.758Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.784Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.074Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.098Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.153Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.169Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.206Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.725Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.755Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.773Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.820Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.828Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.858Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.097Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.098Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.153Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.157Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.193Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.697Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.702Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.756Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.757Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.798Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.043Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.050Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.136Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.142Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.203Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.690Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.691Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.738Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.744Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.776Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.975Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.977Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.037Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.050Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.077Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.490Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.504Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.541Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.542Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.582Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.791Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.811Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.839Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.881Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.883Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.304Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.311Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.359Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.359Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.416Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.615Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.625Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.670Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.701Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.711Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.109Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.150Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.155Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.201Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.205Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.250Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.516Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.533Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.569Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.624Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.650Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.078Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.106Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.145Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.157Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.182Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.396Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.413Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.446Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.463Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.495Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.781Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.819Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.824Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.867Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.875Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.905Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.133Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.142Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.158Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.192Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.853Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.959Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.969Z",
  "value": "id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.970Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.992Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.242Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.254Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.900Z",
  "value": "id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.902Z",
  "value": "id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67"
}

