filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4ae3ebf71985 direct-action not_in_hw id 629 tag b24db1753d9e8db0 jited 
