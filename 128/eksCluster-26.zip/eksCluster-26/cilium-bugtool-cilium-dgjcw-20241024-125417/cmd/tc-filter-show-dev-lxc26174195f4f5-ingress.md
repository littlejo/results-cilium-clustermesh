filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc26174195f4f5 direct-action not_in_hw id 3290 tag f9964ef43ab71b2c jited 
