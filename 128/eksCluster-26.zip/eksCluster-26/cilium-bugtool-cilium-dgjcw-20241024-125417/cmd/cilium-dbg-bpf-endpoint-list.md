IP ADDRESS         LOCAL ENDPOINT INFO
10.26.0.198:0      id=2673  sec_id=1788688 flags=0x0000 ifindex=14  mac=B2:D9:09:EE:4A:98 nodemac=1A:DA:84:9D:2A:36   
10.26.0.236:0      (localhost)                                                                                        
10.26.0.89:0       id=2020  sec_id=1816636 flags=0x0000 ifindex=20  mac=42:12:F1:9E:99:A0 nodemac=26:2C:7C:AE:42:BF   
172.31.172.234:0   (localhost)                                                                                        
172.31.130.77:0    (localhost)                                                                                        
10.26.0.136:0      id=206   sec_id=1825473 flags=0x0000 ifindex=24  mac=72:A7:BA:95:76:38 nodemac=32:4B:D9:1D:C3:94   
10.26.0.207:0      id=2606  sec_id=4     flags=0x0000 ifindex=10  mac=86:A1:39:52:F1:1E nodemac=BA:59:91:44:9D:D7     
10.26.0.216:0      id=611   sec_id=1817786 flags=0x0000 ifindex=18  mac=4E:87:A3:A4:A8:10 nodemac=9E:24:77:10:BA:F1   
10.26.0.142:0      id=42    sec_id=1807419 flags=0x0000 ifindex=22  mac=12:7C:0F:8E:27:BF nodemac=62:12:14:AB:65:67   
10.26.0.250:0      id=74    sec_id=1788688 flags=0x0000 ifindex=12  mac=8A:93:E6:95:0F:83 nodemac=BE:6B:5C:1C:F0:76   
