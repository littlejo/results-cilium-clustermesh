alloc: 133.71MB (140200896 bytes)
total-alloc: 3.15GB (3384122856 bytes)
sys: 215.07MB (225518932 bytes)
lookups: 0
mallocs: 76009221
frees: 74662111
heap-alloc: 133.71MB (140200896 bytes)
heap-sys: 168.55MB (176734208 bytes)
heap-idle: 17.61MB (18464768 bytes)
heap-in-use: 150.94MB (158269440 bytes)
heap-released: 1.87MB (1957888 bytes)
heap-objects: 1347110
stack-in-use: 35.41MB (37126144 bytes)
stack-sys: 35.41MB (37126144 bytes)
stack-mspan-inuse: 2.34MB (2454720 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 755.13KB (773257 bytes)
gc-sys: 5.52MB (5790792 bytes)
next-gc: when heap-alloc >= 146.30MB (153405016 bytes)
last-gc: 2024-10-24 12:54:16.917236158 +0000 UTC
gc-pause-total: 22.035582ms
gc-pause: 101474
gc-pause-end: 1729774456917236158
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005440942978032503
enable-gc: true
debug-gc: false
