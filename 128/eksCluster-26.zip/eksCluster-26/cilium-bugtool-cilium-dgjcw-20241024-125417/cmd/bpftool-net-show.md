xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 576
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 558
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 508
lxcff89f46c75d4(12) clsact/ingress cil_from_container-lxcff89f46c75d4 id 533
lxc69b1411d8043(14) clsact/ingress cil_from_container-lxc69b1411d8043 id 522
lxc4ae3ebf71985(18) clsact/ingress cil_from_container-lxc4ae3ebf71985 id 629
lxc26174195f4f5(20) clsact/ingress cil_from_container-lxc26174195f4f5 id 3290
lxc279652cc5971(22) clsact/ingress cil_from_container-lxc279652cc5971 id 3356
lxc843923ca31d0(24) clsact/ingress cil_from_container-lxc843923ca31d0 id 3359

flow_dissector:

netfilter:

