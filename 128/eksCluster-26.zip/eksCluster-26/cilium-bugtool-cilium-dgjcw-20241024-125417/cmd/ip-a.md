1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:00:c8:fe:dd:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.172.234/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3413sec preferred_lft 3413sec
    inet6 fe80::400:c8ff:fefe:ddfd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:bf:4e:65:81:4b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.130.77/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4bf:4eff:fe65:814b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:37:e4:a9:4c:66 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9c37:e4ff:fea9:4c66/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:9d:e3:3d:82:2e brd ff:ff:ff:ff:ff:ff
    inet 10.26.0.236/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2c9d:e3ff:fe3d:822e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3a:78:d0:7e:64:fa brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3878:d0ff:fe7e:64fa/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:59:91:44:9d:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b859:91ff:fe44:9dd7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcff89f46c75d4@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:6b:5c:1c:f0:76 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::bc6b:5cff:fe1c:f076/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc69b1411d8043@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:da:84:9d:2a:36 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::18da:84ff:fe9d:2a36/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4ae3ebf71985@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:24:77:10:ba:f1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9c24:77ff:fe10:baf1/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc26174195f4f5@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:2c:7c:ae:42:bf brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::242c:7cff:feae:42bf/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc279652cc5971@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:12:14:ab:65:67 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::6012:14ff:feab:6567/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc843923ca31d0@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:4b:d9:1d:c3:94 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::304b:d9ff:fe1d:c394/64 scope link 
       valid_lft forever preferred_lft forever
