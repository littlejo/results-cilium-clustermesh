Node 0, zone      DMA    235     87     14     16     22     12      5      4      2      3     42 
Node 0, zone   Normal    313     10     16      3      9     11      3      3      2      3      7 
