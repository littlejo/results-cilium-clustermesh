CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod852fc9eb_2f7f_4cf8_aedc_09cb98dffaaf.slice/cri-containerd-1679af911b9cf6ea4dbae654fa373dbd797c5accca763bd5a97d442253440dd4.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod852fc9eb_2f7f_4cf8_aedc_09cb98dffaaf.slice/cri-containerd-0004fe226165ada6abeec7c110a197479cefc5c6fd9c0b088c537450ec5a0633.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60da1b5c_7353_4fcd_a0c2_e35206b35cda.slice/cri-containerd-2db1fc1ffde88bf304261bf054e1020a028d214cc451d3f7bfdf72b34f44ad40.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60da1b5c_7353_4fcd_a0c2_e35206b35cda.slice/cri-containerd-b16b999ab8a3c4baeacbfb0e11b8cc29e2863e023c84c73e5d5946876a118833.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode70a8237_8ba9_418c_a56b_c3f5cfb86141.slice/cri-containerd-73cebd8b7ad6280d8928854e31fbfe141ffed0e68447ec1ed7fe512ee1eb4891.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode70a8237_8ba9_418c_a56b_c3f5cfb86141.slice/cri-containerd-6f4b879d8293df8262a658303fe07f1bca29b21b060d0e39cebb0ce6b24df309.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b870760_3df0_447e_a6d7_fe9ad1ea9829.slice/cri-containerd-4b84556c4445105309426f9e62ccfc6b0012286a64a2010c9a1130946b28bf43.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b870760_3df0_447e_a6d7_fe9ad1ea9829.slice/cri-containerd-01ebd3bb91cb1826947bcc44836fac23ecfa4654286a851db6ad9c7cbbfdcca3.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec309ac1_5090_4b71_a80e_48b7e268b400.slice/cri-containerd-9e2795a9a537a2d6b6a79c55354c44bb31bb9b34be50eb689620d86009702db8.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec309ac1_5090_4b71_a80e_48b7e268b400.slice/cri-containerd-35d9de16b9111b739b26bd4b16404431d562f4dac7cee661079e23d846c2fcfb.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec309ac1_5090_4b71_a80e_48b7e268b400.slice/cri-containerd-ca687ca2e9a1e26d28122c5cb3a660fbcb3f9b25b08aa1238d9c0658831b01c2.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9b9e8d5_6866_442a_a988_7491564b5546.slice/cri-containerd-25f1e2a0536e991dfae4aa40f4f25265b33a4c7ce5faac7228f7754ead4beb0d.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9b9e8d5_6866_442a_a988_7491564b5546.slice/cri-containerd-ff7b8e1627d80db718802b11df22d8c187a3b14499d7e73d89acfaaf4f4f19d1.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83c501d7_f9dc_4d46_93e4_08fe01c71412.slice/cri-containerd-9cc9103fc35012f9ca1528ae0a2522b2054ddf428bac74eae8af2a1f2ef15747.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83c501d7_f9dc_4d46_93e4_08fe01c71412.slice/cri-containerd-ef4c6b50ea305203ffee56be8d1b87d001ba7cf3b515579434606e13cf04b9d2.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc268a880_eb9f_47c0_8a20_110a3e03d679.slice/cri-containerd-c09ef634033d27a4308954676d00fe8bda4564d7a9839dc8f1a75d05934b7bb6.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc268a880_eb9f_47c0_8a20_110a3e03d679.slice/cri-containerd-f179d22305c9b1f27405795b16a822d523ea73ac3f254dc21b6f421592eae38e.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod521da16f_5880_4205_a776_8471a6ebb0ea.slice/cri-containerd-9845b76ffd79351bd8ee9edc34ae64dd545a772ef0c06c3fbf4d14f0dd23ef2a.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod521da16f_5880_4205_a776_8471a6ebb0ea.slice/cri-containerd-5bf52351a1535891ae3d686dfe8bac74b77e64ac1f0c06d7972d2d6de56dd131.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd28d8c7a_0446_42c7_9682_7ffe14942bb1.slice/cri-containerd-0b0ad3b7da6c90304f9d848ffb21dee8f69fb8534283ff7c0485af7b3aa44cbf.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd28d8c7a_0446_42c7_9682_7ffe14942bb1.slice/cri-containerd-05d23a4b73cb0742454d0221ed1889457e79c45c339d442569b8e364cce9b335.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd28d8c7a_0446_42c7_9682_7ffe14942bb1.slice/cri-containerd-0f46d9c012292b9cef64662df5ccee32ed3ff208ffa0e72d3cbc07e850a64994.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd28d8c7a_0446_42c7_9682_7ffe14942bb1.slice/cri-containerd-40fb479d7457a4d08f0f8b2664262bda59cf0e7c3543421fce32c62793349f30.scope
    661      cgroup_device   multi                                          
