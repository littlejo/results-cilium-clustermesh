Endpoint ID: 42
Path: /sys/fs/bpf/tc/globals/cilium_policy_00042

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 74
Path: /sys/fs/bpf/tc/globals/cilium_policy_00074

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2170     23        0        
Allow    Ingress     1          ANY          NONE         disabled    161195   1846      0        
Allow    Egress      0          ANY          NONE         disabled    21576    240       0        


Endpoint ID: 206
Path: /sys/fs/bpf/tc/globals/cilium_policy_00206

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 611
Path: /sys/fs/bpf/tc/globals/cilium_policy_00611

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6043379   59629     0        
Allow    Ingress     1          ANY          NONE         disabled    5043566   53113     0        
Allow    Egress      0          ANY          NONE         disabled    5847712   58771     0        


Endpoint ID: 1624
Path: /sys/fs/bpf/tc/globals/cilium_policy_01624

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2020
Path: /sys/fs/bpf/tc/globals/cilium_policy_02020

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379044   4431      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2606
Path: /sys/fs/bpf/tc/globals/cilium_policy_02606

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6216860   76821     0        
Allow    Ingress     1          ANY          NONE         disabled    70398     847       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2673
Path: /sys/fs/bpf/tc/globals/cilium_policy_02673

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3726     37        0        
Allow    Ingress     1          ANY          NONE         disabled    161063   1844      0        
Allow    Egress      0          ANY          NONE         disabled    21170    236       0        


