KEY             VALUE
AgentLiveness   2027578497240
UTimeOffset     3378461839843750
