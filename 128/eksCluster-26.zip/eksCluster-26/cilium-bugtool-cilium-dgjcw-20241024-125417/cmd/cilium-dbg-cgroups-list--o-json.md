[
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod852fc9eb_2f7f_4cf8_aedc_09cb98dffaaf.slice/cri-containerd-1679af911b9cf6ea4dbae654fa373dbd797c5accca763bd5a97d442253440dd4.scope"
      }
    ],
    "ips": [
      "10.26.0.198"
    ],
    "name": "coredns-cc6ccd49c-hn7cm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83c501d7_f9dc_4d46_93e4_08fe01c71412.slice/cri-containerd-ef4c6b50ea305203ffee56be8d1b87d001ba7cf3b515579434606e13cf04b9d2.scope"
      }
    ],
    "ips": [
      "10.26.0.136"
    ],
    "name": "client-974f6c69d-mn7vp",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd28d8c7a_0446_42c7_9682_7ffe14942bb1.slice/cri-containerd-0f46d9c012292b9cef64662df5ccee32ed3ff208ffa0e72d3cbc07e850a64994.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd28d8c7a_0446_42c7_9682_7ffe14942bb1.slice/cri-containerd-0b0ad3b7da6c90304f9d848ffb21dee8f69fb8534283ff7c0485af7b3aa44cbf.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd28d8c7a_0446_42c7_9682_7ffe14942bb1.slice/cri-containerd-40fb479d7457a4d08f0f8b2664262bda59cf0e7c3543421fce32c62793349f30.scope"
      }
    ],
    "ips": [
      "10.26.0.216"
    ],
    "name": "clustermesh-apiserver-74b758c79-p4v58",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec309ac1_5090_4b71_a80e_48b7e268b400.slice/cri-containerd-ca687ca2e9a1e26d28122c5cb3a660fbcb3f9b25b08aa1238d9c0658831b01c2.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec309ac1_5090_4b71_a80e_48b7e268b400.slice/cri-containerd-35d9de16b9111b739b26bd4b16404431d562f4dac7cee661079e23d846c2fcfb.scope"
      }
    ],
    "ips": [
      "10.26.0.89"
    ],
    "name": "echo-same-node-86d9cc975c-bj65m",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60da1b5c_7353_4fcd_a0c2_e35206b35cda.slice/cri-containerd-2db1fc1ffde88bf304261bf054e1020a028d214cc451d3f7bfdf72b34f44ad40.scope"
      }
    ],
    "ips": [
      "10.26.0.250"
    ],
    "name": "coredns-cc6ccd49c-8vfrf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc268a880_eb9f_47c0_8a20_110a3e03d679.slice/cri-containerd-c09ef634033d27a4308954676d00fe8bda4564d7a9839dc8f1a75d05934b7bb6.scope"
      }
    ],
    "ips": [
      "10.26.0.142"
    ],
    "name": "client2-57cf4468f-2pwbj",
    "namespace": "cilium-test-1"
  }
]

