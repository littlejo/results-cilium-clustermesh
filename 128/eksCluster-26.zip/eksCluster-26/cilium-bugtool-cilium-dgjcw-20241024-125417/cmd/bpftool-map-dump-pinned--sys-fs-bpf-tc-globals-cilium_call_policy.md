key: 2a 00 00 00  value: 20 0d 00 00
key: 4a 00 00 00  value: 1d 02 00 00
key: ce 00 00 00  value: 16 0d 00 00
key: 63 02 00 00  value: 79 02 00 00
key: e4 07 00 00  value: e2 0c 00 00
key: 2e 0a 00 00  value: 05 02 00 00
key: 71 0a 00 00  value: 14 02 00 00
Found 7 elements
