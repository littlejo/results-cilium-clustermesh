{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.277Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.288Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.321Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.811Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.828Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.862Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.869Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.895Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.128Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.142Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.204Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.207Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.297Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.881Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.901Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.931Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.959Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.968Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.204Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.209Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.261Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.275Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.311Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.932Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.939Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.967Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.992Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.015Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.052Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.053Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.316Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.332Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.378Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.409Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.426Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.985Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.017Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.123Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.145Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.229Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.233Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.436Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.441Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.500Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.524Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.539Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.956Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.968Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.011Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.014Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.047Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.293Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.298Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.362Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.366Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.410Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.771Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.790Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.815Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.859Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.862Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.181Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.245Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.282Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.286Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.313Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.678Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.721Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.725Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.764Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.791Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.803Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.042Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.043Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.095Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.104Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.152Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.548Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.556Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.593Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.610Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.630Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.871Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.876Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.930Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.940Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.973Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.386Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.420Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.437Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.469Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.490Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.515Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.722Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.749Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.784Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.805Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.831Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.124Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.138Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.175Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.191Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.215Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.439Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.447Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.502Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.505Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.543Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.873Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.909Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.913Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.963Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.970Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.004Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.235Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.256Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.263Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.270Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.286Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.959Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.962Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.000Z",
  "value": "id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.023Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.039Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.382Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.383Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.072Z",
  "value": "id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.074Z",
  "value": "id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2"
}

