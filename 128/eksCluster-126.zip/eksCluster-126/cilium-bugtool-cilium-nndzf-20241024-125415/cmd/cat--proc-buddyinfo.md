Node 0, zone      DMA    128    146     25     42     20     11      6      3      2      4     41 
Node 0, zone   Normal    276      3     10     23     13     11      3      2      2      3      7 
