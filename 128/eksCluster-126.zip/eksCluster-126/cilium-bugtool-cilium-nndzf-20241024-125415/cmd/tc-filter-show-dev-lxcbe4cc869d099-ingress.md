filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbe4cc869d099 direct-action not_in_hw id 3258 tag 4b239ce2c8f592e2 jited 
