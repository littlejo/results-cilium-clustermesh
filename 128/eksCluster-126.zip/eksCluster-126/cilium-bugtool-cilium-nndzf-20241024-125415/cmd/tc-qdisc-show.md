qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc4f7b226f4699 root refcnt 2 
qdisc clsact ffff: dev lxc4f7b226f4699 parent ffff:fff1 
qdisc noqueue 0: dev lxcad52ef5a3577 root refcnt 2 
qdisc clsact ffff: dev lxcad52ef5a3577 parent ffff:fff1 
qdisc noqueue 0: dev lxc05a8c9e5ef3e root refcnt 2 
qdisc clsact ffff: dev lxc05a8c9e5ef3e parent ffff:fff1 
qdisc noqueue 0: dev lxcd5c520fb102a root refcnt 2 
qdisc clsact ffff: dev lxcd5c520fb102a parent ffff:fff1 
qdisc noqueue 0: dev lxc1859a36e60db root refcnt 2 
qdisc clsact ffff: dev lxc1859a36e60db parent ffff:fff1 
qdisc noqueue 0: dev lxcbe4cc869d099 root refcnt 2 
qdisc clsact ffff: dev lxcbe4cc869d099 parent ffff:fff1 
