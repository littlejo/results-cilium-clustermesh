IP ADDRESS        LOCAL ENDPOINT INFO
172.31.145.88:0   (localhost)                                                                                        
172.31.163.49:0   (localhost)                                                                                        
10.126.0.169:0    id=2441  sec_id=4     flags=0x0000 ifindex=10  mac=F6:36:67:64:2A:89 nodemac=6A:71:F7:60:AC:ED     
10.126.0.76:0     id=80    sec_id=8381234 flags=0x0000 ifindex=18  mac=32:62:FD:5C:59:82 nodemac=E2:4A:95:D8:67:F8   
10.126.0.78:0     (localhost)                                                                                        
10.126.0.114:0    id=273   sec_id=8372285 flags=0x0000 ifindex=14  mac=6A:B9:D8:42:87:A4 nodemac=66:B1:D5:49:11:F2   
10.126.0.213:0    id=485   sec_id=8363982 flags=0x0000 ifindex=20  mac=0A:6F:74:CA:EE:56 nodemac=5A:75:33:69:D0:9E   
10.126.0.171:0    id=4029  sec_id=8325387 flags=0x0000 ifindex=22  mac=C6:E5:0B:4F:23:C5 nodemac=6A:36:70:96:71:D2   
10.126.0.199:0    id=2069  sec_id=8352912 flags=0x0000 ifindex=24  mac=7E:D9:E9:48:0D:95 nodemac=F6:F7:DE:C2:3E:85   
10.126.0.145:0    id=1060  sec_id=8372285 flags=0x0000 ifindex=12  mac=CE:90:6E:16:A1:FB nodemac=22:C1:59:C3:7A:4F   
