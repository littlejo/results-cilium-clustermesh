CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbdeb2fb2_2379_4c49_9eef_1a74a12f3bf1.slice/cri-containerd-b23b3e802f03577ebe9b6a598cf96b10e39395b1e40fe5a28343cb60451968a1.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbdeb2fb2_2379_4c49_9eef_1a74a12f3bf1.slice/cri-containerd-d9856b2ec3640b6bce906a7ad14c37eeca97e1e6887a816dfcfb370ad86324fa.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod957e598b_1802_4ddf_bcf4_9ac3a0c329a0.slice/cri-containerd-14a660f6393d0fd6be03ca35dda562ebd0a1ef66606c0b8ed97e0b99b76c3dac.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod957e598b_1802_4ddf_bcf4_9ac3a0c329a0.slice/cri-containerd-63238d81ec28ed98612cb883fd9001915c7fc5c47c75a13706da417e8601ad9a.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f1132be_21f1_43bc_b9a5_655c68295461.slice/cri-containerd-8f6682a10557249d994a43ccf89ec6b95e0157db348d926ac2eaecb223cdbe5f.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f1132be_21f1_43bc_b9a5_655c68295461.slice/cri-containerd-251ed14cc52cf98d0e88027ec04bc3ce85deed0032829a5416ca4c9f97a2387e.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03c6ba46_af74_423e_9609_f99022543f9d.slice/cri-containerd-23451f72548cfa529cf268bd161765594411ba4297a04921695f2a72c4886272.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03c6ba46_af74_423e_9609_f99022543f9d.slice/cri-containerd-4636251cda67e84b2a5bb4aeffa64f9fa2e4f8cbe3b16e3f0f1051176e6927a4.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd35d5fb9_c5f3_4015_8b17_5eb14f22c2df.slice/cri-containerd-f19825b3b3d92afa6087430203ba7bd7ec538d6be09bc56dd3454efd63f11e67.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd35d5fb9_c5f3_4015_8b17_5eb14f22c2df.slice/cri-containerd-a64ea537f9111b7187f3aae5f753a1d1d6e22fafca1268b5d039254ef12b3cc8.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3550f02b_2312_43a1_9a73_6ef894ff5fea.slice/cri-containerd-6b70a00cc5c2ad45155e41bea3562e9885360f185a34f9bf449579327ab57254.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3550f02b_2312_43a1_9a73_6ef894ff5fea.slice/cri-containerd-1389567f8232454cb983b668c7342018314e0d19ab0d95b44a4065a28feeb299.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3550f02b_2312_43a1_9a73_6ef894ff5fea.slice/cri-containerd-3475c9bedbf9e19af58e19134abc2894ab31081a9e7a4f1d48814a5672552aa0.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab9ecf6_dc45_4626_8db1_fd74926b5b7f.slice/cri-containerd-5544af04f98b3b67167103dcdff8b92e699f32343bf1b54b586a5397a2f12434.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab9ecf6_dc45_4626_8db1_fd74926b5b7f.slice/cri-containerd-256056e82c0eca980f9bad2ace25b6efa905b335449ed4af706d3660db05f410.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab9ecf6_dc45_4626_8db1_fd74926b5b7f.slice/cri-containerd-9a9fdf66c6ea1667f6ff7ec6e3b7542d48b27c04a6febf86d5e3e690fd4a29c5.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab9ecf6_dc45_4626_8db1_fd74926b5b7f.slice/cri-containerd-7dfc3bc6001eb49442db6ca65090427a3e1e5f7e475378195eebb0c9faaa381d.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3a35ccf_ede4_4dbe_ac6e_9ad49cabfee1.slice/cri-containerd-03cc99f1c76903f4171b43863e610574c968bf05319d204105ff1d5cd6bfcd77.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3a35ccf_ede4_4dbe_ac6e_9ad49cabfee1.slice/cri-containerd-d0e4d783b23638c9f2686e02a1080131960a0ce6b4c66b7eb372deb0bf0efe8a.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec628962_4e90_4a96_885f_186ca94711b6.slice/cri-containerd-e85a672a88437e513802add5dd6a76c1bfeafb2838db415ccb01327c78c480ac.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec628962_4e90_4a96_885f_186ca94711b6.slice/cri-containerd-db57109d711c4044e60883b31236a7b25f66ab08163e1a990fec52f4e0b8be40.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda67a9b28_44b5_4b80_9aee_d889d3c35cd0.slice/cri-containerd-80079aab0235b01c1cdcce7991aeacd51b940ed382a23dc83f90c5144a419995.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda67a9b28_44b5_4b80_9aee_d889d3c35cd0.slice/cri-containerd-db4a7536763768b0162ff151cf9792efc4c8cf75c5079bbfa8610f4c71cbb805.scope
    707      cgroup_device   multi                                          
