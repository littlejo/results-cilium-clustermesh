xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 577
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 560
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 554
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 528
lxc4f7b226f4699(12) clsact/ingress cil_from_container-lxc4f7b226f4699 id 540
lxcad52ef5a3577(14) clsact/ingress cil_from_container-lxcad52ef5a3577 id 512
lxc05a8c9e5ef3e(18) clsact/ingress cil_from_container-lxc05a8c9e5ef3e id 623
lxcd5c520fb102a(20) clsact/ingress cil_from_container-lxcd5c520fb102a id 3323
lxc1859a36e60db(22) clsact/ingress cil_from_container-lxc1859a36e60db id 3305
lxcbe4cc869d099(24) clsact/ingress cil_from_container-lxcbe4cc869d099 id 3258

flow_dissector:

netfilter:

