Endpoint ID: 80
Path: /sys/fs/bpf/tc/globals/cilium_policy_00080

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6069337   60002     0        
Allow    Ingress     1          ANY          NONE         disabled    4830089   50631     0        
Allow    Egress      0          ANY          NONE         disabled    5932706   59508     0        


Endpoint ID: 273
Path: /sys/fs/bpf/tc/globals/cilium_policy_00273

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2584     26        0        
Allow    Ingress     1          ANY          NONE         disabled    112405   1292      0        
Allow    Egress      0          ANY          NONE         disabled    17060    186       0        


Endpoint ID: 485
Path: /sys/fs/bpf/tc/globals/cilium_policy_00485

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 820
Path: /sys/fs/bpf/tc/globals/cilium_policy_00820

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1060
Path: /sys/fs/bpf/tc/globals/cilium_policy_01060

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3312     34        0        
Allow    Ingress     1          ANY          NONE         disabled    111151   1273      0        
Allow    Egress      0          ANY          NONE         disabled    16863    183       0        


Endpoint ID: 2069
Path: /sys/fs/bpf/tc/globals/cilium_policy_02069

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378609   4403      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2441
Path: /sys/fs/bpf/tc/globals/cilium_policy_02441

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6235149   76922     0        
Allow    Ingress     1          ANY          NONE         disabled    62931     763       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 4029
Path: /sys/fs/bpf/tc/globals/cilium_policy_04029

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


