filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc1859a36e60db direct-action not_in_hw id 3305 tag 3b49775da5c73e44 jited 
