KEY             VALUE
AgentLiveness   1868612825590
UTimeOffset     3378462146484375
