top - 12:54:17 up 30 min,  0 users,  load average: 0.34, 0.36, 0.23
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 27.6 us, 62.1 sy,  0.0 ni, 10.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    306.8 free,   1033.5 used,   2495.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2621.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3257 root      20   0 1240432  16748  11484 S   6.7   0.4   0:00.02 cilium-+
      1 root      20   0 1538804 282732  78848 S   0.0   7.2   1:02.32 cilium-+
    394 root      20   0 1229744   9060   2924 S   0.0   0.2   0:04.33 cilium-+
   3238 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3299 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3304 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3318 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3354 root      20   0    3728    488    436 R   0.0   0.0   0:00.00 bash
