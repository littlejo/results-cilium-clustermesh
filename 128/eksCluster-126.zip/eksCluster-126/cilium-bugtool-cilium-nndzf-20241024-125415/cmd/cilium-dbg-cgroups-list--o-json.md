[
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbdeb2fb2_2379_4c49_9eef_1a74a12f3bf1.slice/cri-containerd-d9856b2ec3640b6bce906a7ad14c37eeca97e1e6887a816dfcfb370ad86324fa.scope"
      }
    ],
    "ips": [
      "10.126.0.145"
    ],
    "name": "coredns-cc6ccd49c-tzfm6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3550f02b_2312_43a1_9a73_6ef894ff5fea.slice/cri-containerd-6b70a00cc5c2ad45155e41bea3562e9885360f185a34f9bf449579327ab57254.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3550f02b_2312_43a1_9a73_6ef894ff5fea.slice/cri-containerd-1389567f8232454cb983b668c7342018314e0d19ab0d95b44a4065a28feeb299.scope"
      }
    ],
    "ips": [
      "10.126.0.199"
    ],
    "name": "echo-same-node-86d9cc975c-b8rk9",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab9ecf6_dc45_4626_8db1_fd74926b5b7f.slice/cri-containerd-5544af04f98b3b67167103dcdff8b92e699f32343bf1b54b586a5397a2f12434.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab9ecf6_dc45_4626_8db1_fd74926b5b7f.slice/cri-containerd-256056e82c0eca980f9bad2ace25b6efa905b335449ed4af706d3660db05f410.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab9ecf6_dc45_4626_8db1_fd74926b5b7f.slice/cri-containerd-7dfc3bc6001eb49442db6ca65090427a3e1e5f7e475378195eebb0c9faaa381d.scope"
      }
    ],
    "ips": [
      "10.126.0.76"
    ],
    "name": "clustermesh-apiserver-66c6bbc5d8-nvgd8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod957e598b_1802_4ddf_bcf4_9ac3a0c329a0.slice/cri-containerd-63238d81ec28ed98612cb883fd9001915c7fc5c47c75a13706da417e8601ad9a.scope"
      }
    ],
    "ips": [
      "10.126.0.114"
    ],
    "name": "coredns-cc6ccd49c-mbgzk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3a35ccf_ede4_4dbe_ac6e_9ad49cabfee1.slice/cri-containerd-03cc99f1c76903f4171b43863e610574c968bf05319d204105ff1d5cd6bfcd77.scope"
      }
    ],
    "ips": [
      "10.126.0.171"
    ],
    "name": "client2-57cf4468f-qnfbb",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda67a9b28_44b5_4b80_9aee_d889d3c35cd0.slice/cri-containerd-db4a7536763768b0162ff151cf9792efc4c8cf75c5079bbfa8610f4c71cbb805.scope"
      }
    ],
    "ips": [
      "10.126.0.213"
    ],
    "name": "client-974f6c69d-wvql5",
    "namespace": "cilium-test-1"
  }
]

