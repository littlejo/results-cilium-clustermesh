 12:54:16 up 30 min,  0 users,  load average: 0.34, 0.36, 0.23
