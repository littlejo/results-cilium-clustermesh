1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:04:0d:a6:68:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.163.49/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3571sec preferred_lft 3571sec
    inet6 fe80::404:dff:fea6:68d9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ac:98:d4:5d:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.145.88/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ac:98ff:fed4:5d2f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:28:19:48:5d:2e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9028:19ff:fe48:5d2e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:af:06:b6:33:43 brd ff:ff:ff:ff:ff:ff
    inet 10.126.0.78/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a8af:6ff:feb6:3343/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 46:d3:df:6d:6d:34 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::44d3:dfff:fe6d:6d34/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:71:f7:60:ac:ed brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6871:f7ff:fe60:aced/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4f7b226f4699@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:c1:59:c3:7a:4f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::20c1:59ff:fec3:7a4f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcad52ef5a3577@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:b1:d5:49:11:f2 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::64b1:d5ff:fe49:11f2/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc05a8c9e5ef3e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:4a:95:d8:67:f8 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e04a:95ff:fed8:67f8/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcd5c520fb102a@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:75:33:69:d0:9e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5875:33ff:fe69:d09e/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc1859a36e60db@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:36:70:96:71:d2 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::6836:70ff:fe96:71d2/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcbe4cc869d099@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:f7:de:c2:3e:85 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::f4f7:deff:fec2:3e85/64 scope link 
       valid_lft forever preferred_lft forever
