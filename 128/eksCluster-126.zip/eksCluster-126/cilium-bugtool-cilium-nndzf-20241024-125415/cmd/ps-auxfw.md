USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3257  0.0  0.4 1240176 16332 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3281  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3284  0.0  0.0   4212  1396 ?        R    12:54   0:00  \_ ip a
root        3238  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  5.4  7.1 1538804 282732 ?      Ssl  12:35   1:02 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.3  0.2 1229744 9060 ?        Sl   12:35   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
