key: 50 00 00 00  value: 74 02 00 00
key: 11 01 00 00  value: fc 01 00 00
key: e5 01 00 00  value: f8 0c 00 00
key: 24 04 00 00  value: 1a 02 00 00
key: 15 08 00 00  value: bf 0c 00 00
key: 89 09 00 00  value: 04 02 00 00
key: bd 0f 00 00  value: f6 0c 00 00
Found 7 elements
