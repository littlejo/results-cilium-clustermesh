alloc: 130.22MB (136545576 bytes)
total-alloc: 3.05GB (3275992816 bytes)
sys: 219.07MB (229713236 bytes)
lookups: 0
mallocs: 74632888
frees: 73326545
heap-alloc: 130.22MB (136545576 bytes)
heap-sys: 172.70MB (181092352 bytes)
heap-idle: 23.31MB (24444928 bytes)
heap-in-use: 149.39MB (156647424 bytes)
heap-released: 7.49MB (7856128 bytes)
heap-objects: 1306343
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.32MB (2437760 bytes)
stack-mspan-sys: 2.74MB (2872320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 806.02KB (825361 bytes)
gc-sys: 5.52MB (5790816 bytes)
next-gc: when heap-alloc >= 147.10MB (154240568 bytes)
last-gc: 2024-10-24 12:54:15.881584438 +0000 UTC
gc-pause-total: 15.727787ms
gc-pause: 102033
gc-pause-end: 1729774455881584438
num-gc: 97
num-forced-gc: 0
gc-cpu-fraction: 0.0007702762550174519
enable-gc: true
debug-gc: false
