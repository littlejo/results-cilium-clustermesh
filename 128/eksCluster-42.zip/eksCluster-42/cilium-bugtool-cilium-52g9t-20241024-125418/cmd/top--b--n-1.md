top - 12:54:20 up 32 min,  0 users,  load average: 0.22, 0.35, 0.20
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 32.3 us, 22.6 sy,  0.0 ni, 45.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    294.0 free,   1045.0 used,   2497.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2610.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 289568  78972 S  26.7   7.4   1:03.05 cilium-+
   3252 root      20   0 1240432  16440  11356 S  13.3   0.4   0:00.03 cilium-+
    418 root      20   0 1229744  10224   3836 S   0.0   0.3   0:04.09 cilium-+
   3291 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
   3314 root      20   0 1228744   4032   3392 S   0.0   0.1   0:00.00 gops
