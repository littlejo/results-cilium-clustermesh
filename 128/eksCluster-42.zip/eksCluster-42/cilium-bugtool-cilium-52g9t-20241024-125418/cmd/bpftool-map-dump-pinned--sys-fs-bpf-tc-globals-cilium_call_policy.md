key: c6 00 00 00  value: 78 02 00 00
key: c9 01 00 00  value: f8 0c 00 00
key: ce 02 00 00  value: 0a 02 00 00
key: 80 05 00 00  value: 1c 02 00 00
key: b9 06 00 00  value: 05 0d 00 00
key: 92 0b 00 00  value: d6 0c 00 00
key: 3a 0e 00 00  value: 03 02 00 00
Found 7 elements
