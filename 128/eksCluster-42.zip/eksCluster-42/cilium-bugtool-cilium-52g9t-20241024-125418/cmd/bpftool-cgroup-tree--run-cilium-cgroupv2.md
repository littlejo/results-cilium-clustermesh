CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae53fe0d_419a_460e_9ace_ec9e67e7e7aa.slice/cri-containerd-d1dd1bdae0fad6eefe8247be3e93d86e890b676348e0c1b2ea1ac5df33d1f55c.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae53fe0d_419a_460e_9ace_ec9e67e7e7aa.slice/cri-containerd-d6534711d7fe3c96272a172622191350ffc1a60ee370364fd9721428daeaa476.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3844cbf_c7ef_4565_aace_5af2bd094f5e.slice/cri-containerd-77821d9ba9817c2b53976a3d648b045213dab5de8f703448bb2d8ba1ae718d95.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3844cbf_c7ef_4565_aace_5af2bd094f5e.slice/cri-containerd-cad93af2a2a5ef482a53c9829ec6b90a529f2deb10b89cee151f7f4c26bf15e8.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode84ea99b_5b1e_4d5a_8f95_f1055a9c95c9.slice/cri-containerd-8561cac56ea79aa8791bc2bb476221dc5d0861fafde979ee864994630aca7930.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode84ea99b_5b1e_4d5a_8f95_f1055a9c95c9.slice/cri-containerd-e5014459045b29dc21dc2be79ec208e034568faf5826007b102aa851ef8e4f1b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe9a93fb_4a24_4a8b_9598_22c5862c4605.slice/cri-containerd-70836df2bee1be4b890282ad22e98ae26571dc68aa6a628f6f6e558fe67009f0.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe9a93fb_4a24_4a8b_9598_22c5862c4605.slice/cri-containerd-d5b77daec12ff14f91396fcd11a01c97818db9aee72a3e27601261af5cac8be6.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc08bc5d_d436_46f8_8ecf_da07a2c3f5d7.slice/cri-containerd-dcbef0cffcb088d2829b2caece5fafaacda3a60b5b922986b644bd279cfac00e.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc08bc5d_d436_46f8_8ecf_da07a2c3f5d7.slice/cri-containerd-8ff034d4477d81bd508cca0c8d76bba73f61f5a7734a5bf20aa5fe5fdaacbe1c.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a21d314_418f_4aa8_b524_2f64b73f6dae.slice/cri-containerd-75d59af6ae6eb9bc11d17483cc784d5051c047eda76f14221cf32c8ada0f7a2e.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a21d314_418f_4aa8_b524_2f64b73f6dae.slice/cri-containerd-68e2b8c6e75b4e032a2622e9a60401fc8a0f916df975a7f129c9b5ae6f554e41.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58995133_fce3_43fa_beaa_1fb1f8db3907.slice/cri-containerd-9553055cf473e6c7bcb3148a55d7adb71679f6e4f348e6dd39f26dc6222650ff.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58995133_fce3_43fa_beaa_1fb1f8db3907.slice/cri-containerd-246dc8c8ae026d4fb37e24379270c9cd39bcce455e9cbf29576dcb8cb401081f.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9256a9ac_6e96_4b73_ae75_f166042b5c50.slice/cri-containerd-4213dbd9163003136ac52b7fcca499007a1f98f98e3a3de9295cff34b13030af.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9256a9ac_6e96_4b73_ae75_f166042b5c50.slice/cri-containerd-367ca9e310a16e35fcdf202188695a3e410ec4c585cd5411169f0f8c31ea555b.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9256a9ac_6e96_4b73_ae75_f166042b5c50.slice/cri-containerd-581c0b3b25041f07c495e9726391e5cbcdcebe9c6bb6deed70f3e9dde5339dbe.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9256a9ac_6e96_4b73_ae75_f166042b5c50.slice/cri-containerd-37693d063882e91120074a4410b6115a0030d0e33f36c4ad4d17703086169e06.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod975d9601_dbd7_4b42_a619_26abc3e322c3.slice/cri-containerd-ec0746195cf19cb75c9541d31deced27e37083cd3e45e216f216f8434825d28a.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod975d9601_dbd7_4b42_a619_26abc3e322c3.slice/cri-containerd-b8b96c15091324edaf48341a2db831a741a74b2e3a989eba683ff619d80a3776.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod08e5c73c_e661_48f8_be97_80c50d233a32.slice/cri-containerd-25bb7bc749cf7e0f9bd1203a16be0b26097712cd1cf35aaa646c84c74b2235b4.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod08e5c73c_e661_48f8_be97_80c50d233a32.slice/cri-containerd-055f1cd16bbb8fe86bb956b2de8314343350705e7d49fa2ace208b5b9fb95c55.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod08e5c73c_e661_48f8_be97_80c50d233a32.slice/cri-containerd-83da2f539e2d02bc8bb130d64611d0bb0492a973cdd60e1d10e04037fb13ecd5.scope
    722      cgroup_device   multi                                          
