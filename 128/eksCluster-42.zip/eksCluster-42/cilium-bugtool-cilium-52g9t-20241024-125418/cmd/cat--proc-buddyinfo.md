Node 0, zone      DMA     43    111     18     18     12      5      7      2      0      2     44 
Node 0, zone   Normal    434     58      2     18     28      6      1      7      5      2      6 
