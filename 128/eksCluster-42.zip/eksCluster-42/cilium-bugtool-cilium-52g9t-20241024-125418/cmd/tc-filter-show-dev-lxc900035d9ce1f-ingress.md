filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc900035d9ce1f direct-action not_in_hw id 633 tag a5757b2af4be82e1 jited 
