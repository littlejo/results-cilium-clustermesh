markdown output at /tmp/cilium-bugtool-20241024-125419.874+0000-UTC-3095248864/cmd/cilium-debuginfo-20241024-125421.037+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125419.874+0000-UTC-3095248864/cmd/cilium-debuginfo-20241024-125421.037+0000-UTC.json
