xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 559
cilium_host(7) clsact/egress cil_from_host-cilium_host id 560
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 511
lxcdd42776992da(12) clsact/ingress cil_from_container-lxcdd42776992da id 547
lxcfad7af016bb0(14) clsact/ingress cil_from_container-lxcfad7af016bb0 id 526
lxc900035d9ce1f(18) clsact/ingress cil_from_container-lxc900035d9ce1f id 633
lxc1ab67cb9dfba(20) clsact/ingress cil_from_container-lxc1ab67cb9dfba id 3323
lxc03dad8b366d3(22) clsact/ingress cil_from_container-lxc03dad8b366d3 id 3270
lxc642cea839cb4(24) clsact/ingress cil_from_container-lxc642cea839cb4 id 3340

flow_dissector:

netfilter:

