alloc: 123.86MB (129873048 bytes)
total-alloc: 3.02GB (3246533480 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74189866
frees: 72743209
heap-alloc: 123.86MB (129873048 bytes)
heap-sys: 172.84MB (181239808 bytes)
heap-idle: 30.79MB (32284672 bytes)
heap-in-use: 142.05MB (148955136 bytes)
heap-released: 11.37MB (11919360 bytes)
heap-objects: 1446657
stack-in-use: 35.16MB (36864000 bytes)
stack-sys: 35.16MB (36864000 bytes)
stack-mspan-inuse: 2.42MB (2535360 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1004.00KB (1028097 bytes)
gc-sys: 5.45MB (5719040 bytes)
next-gc: when heap-alloc >= 145.79MB (152876584 bytes)
last-gc: 2024-10-24 12:53:33.123451452 +0000 UTC
gc-pause-total: 8.735549ms
gc-pause: 117171
gc-pause-end: 1729774413123451452
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.00052413393156827
enable-gc: true
debug-gc: false
