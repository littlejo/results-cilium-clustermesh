IP ADDRESS        LOCAL ENDPOINT INFO
10.42.0.122:0     id=198   sec_id=2818993 flags=0x0000 ifindex=18  mac=06:A3:30:89:8B:09 nodemac=86:1F:86:EE:12:BB   
172.31.184.21:0   (localhost)                                                                                        
10.42.0.63:0      id=3642  sec_id=4     flags=0x0000 ifindex=10  mac=6A:86:F9:D3:D8:AA nodemac=A2:BE:5D:4F:36:00     
10.42.0.128:0     (localhost)                                                                                        
10.42.0.252:0     id=718   sec_id=2833644 flags=0x0000 ifindex=14  mac=BA:24:DA:20:56:4E nodemac=12:70:07:3A:61:68   
172.31.146.47:0   (localhost)                                                                                        
10.42.0.185:0     id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3   
10.42.0.129:0     id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48   
10.42.0.184:0     id=1408  sec_id=2833644 flags=0x0000 ifindex=12  mac=62:5B:A6:11:AD:54 nodemac=DE:3B:37:7C:B0:27   
10.42.0.58:0      id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89   
