[
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod08e5c73c_e661_48f8_be97_80c50d233a32.slice/cri-containerd-83da2f539e2d02bc8bb130d64611d0bb0492a973cdd60e1d10e04037fb13ecd5.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod08e5c73c_e661_48f8_be97_80c50d233a32.slice/cri-containerd-25bb7bc749cf7e0f9bd1203a16be0b26097712cd1cf35aaa646c84c74b2235b4.scope"
      }
    ],
    "ips": [
      "10.42.0.185"
    ],
    "name": "echo-same-node-86d9cc975c-vw8pm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9256a9ac_6e96_4b73_ae75_f166042b5c50.slice/cri-containerd-581c0b3b25041f07c495e9726391e5cbcdcebe9c6bb6deed70f3e9dde5339dbe.scope"
      },
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9256a9ac_6e96_4b73_ae75_f166042b5c50.slice/cri-containerd-4213dbd9163003136ac52b7fcca499007a1f98f98e3a3de9295cff34b13030af.scope"
      },
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9256a9ac_6e96_4b73_ae75_f166042b5c50.slice/cri-containerd-367ca9e310a16e35fcdf202188695a3e410ec4c585cd5411169f0f8c31ea555b.scope"
      }
    ],
    "ips": [
      "10.42.0.122"
    ],
    "name": "clustermesh-apiserver-7794f654b8-dkjzv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod975d9601_dbd7_4b42_a619_26abc3e322c3.slice/cri-containerd-ec0746195cf19cb75c9541d31deced27e37083cd3e45e216f216f8434825d28a.scope"
      }
    ],
    "ips": [
      "10.42.0.58"
    ],
    "name": "client-974f6c69d-zsl8q",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7704,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe9a93fb_4a24_4a8b_9598_22c5862c4605.slice/cri-containerd-70836df2bee1be4b890282ad22e98ae26571dc68aa6a628f6f6e558fe67009f0.scope"
      }
    ],
    "ips": [
      "10.42.0.252"
    ],
    "name": "coredns-cc6ccd49c-dnj6j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc08bc5d_d436_46f8_8ecf_da07a2c3f5d7.slice/cri-containerd-8ff034d4477d81bd508cca0c8d76bba73f61f5a7734a5bf20aa5fe5fdaacbe1c.scope"
      }
    ],
    "ips": [
      "10.42.0.129"
    ],
    "name": "client2-57cf4468f-b4snm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7620,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae53fe0d_419a_460e_9ace_ec9e67e7e7aa.slice/cri-containerd-d1dd1bdae0fad6eefe8247be3e93d86e890b676348e0c1b2ea1ac5df33d1f55c.scope"
      }
    ],
    "ips": [
      "10.42.0.184"
    ],
    "name": "coredns-cc6ccd49c-5m6gb",
    "namespace": "kube-system"
  }
]

