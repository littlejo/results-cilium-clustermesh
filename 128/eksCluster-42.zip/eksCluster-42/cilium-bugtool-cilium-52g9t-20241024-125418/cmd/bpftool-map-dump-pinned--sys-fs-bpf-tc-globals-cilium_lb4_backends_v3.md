key: 0c 00 00 00  value: 0a 2a 00 b9 1f 90 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 99 37 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 2a 00 fc 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 2a 00 b8 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f b8 15 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 2a 00 7a 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 2a 00 b8 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f df 14 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 2a 00 fc 23 c1 00 00  00 00 00 00
Found 9 elements
