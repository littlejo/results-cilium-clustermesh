Endpoint ID: 198
Path: /sys/fs/bpf/tc/globals/cilium_policy_00198

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5511034   56448     0        
Allow    Ingress     1          ANY          NONE         disabled    4858636   50942     0        
Allow    Egress      0          ANY          NONE         disabled    5490068   56682     0        


Endpoint ID: 457
Path: /sys/fs/bpf/tc/globals/cilium_policy_00457

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 718
Path: /sys/fs/bpf/tc/globals/cilium_policy_00718

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2616     25        0        
Allow    Ingress     1          ANY          NONE         disabled    152546   1747      0        
Allow    Egress      0          ANY          NONE         disabled    19607    219       0        


Endpoint ID: 1408
Path: /sys/fs/bpf/tc/globals/cilium_policy_01408

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3280     35        0        
Allow    Ingress     1          ANY          NONE         disabled    152612   1748      0        
Allow    Egress      0          ANY          NONE         disabled    20757    231       0        


Endpoint ID: 1721
Path: /sys/fs/bpf/tc/globals/cilium_policy_01721

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2962
Path: /sys/fs/bpf/tc/globals/cilium_policy_02962

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    351285   4096      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3642
Path: /sys/fs/bpf/tc/globals/cilium_policy_03642

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6185872   76595     0        
Allow    Ingress     1          ANY          NONE         disabled    63381     763       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3915
Path: /sys/fs/bpf/tc/globals/cilium_policy_03915

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


