 12:54:19 up 32 min,  0 users,  load average: 0.22, 0.35, 0.20
