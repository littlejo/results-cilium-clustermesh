{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.328Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.338Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.355Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.813Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.869Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.877Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.911Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.930Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.948Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.184Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.187Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.257Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.258Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.296Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.889Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.910Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.944Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.945Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.977Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.274Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.285Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.322Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.373Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.381Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.892Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.899Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.944Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.949Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.983Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.190Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.195Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.247Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.257Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.297Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.798Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.800Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.849Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.865Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.895Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.932Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.946Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.138Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.148Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.233Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.275Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.313Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.672Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.683Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.728Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.729Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.766Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.984Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.992Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.050Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.050Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.087Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.419Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.453Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.464Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.501Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.561Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.571Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.770Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.785Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.857Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.873Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.902Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.219Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.267Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.287Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.383Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.393Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.419Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.602Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.603Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.663Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.682Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.707Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.123Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.153Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.175Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.187Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.216Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.464Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.468Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.513Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.522Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.526Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.957Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.964Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.013Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.015Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.056Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.255Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.262Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.383Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.416Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.438Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.704Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.733Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.745Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.778Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.779Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.805Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.023Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.029Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.079Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.093Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.118Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.409Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.414Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.447Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.452Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.496Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.498Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.750Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.772Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.777Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.808Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.523Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.526Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.599Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.608Z",
  "value": "id=2962  sec_id=2841515 flags=0x0000 ifindex=22  mac=4E:B2:66:6E:B7:5A nodemac=7A:25:F5:CF:BD:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.648Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.900Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.912Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.559Z",
  "value": "id=457   sec_id=2821607 flags=0x0000 ifindex=20  mac=B2:3E:72:BE:41:A6 nodemac=DE:A6:86:7C:5F:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.585Z",
  "value": "id=1721  sec_id=2819786 flags=0x0000 ifindex=24  mac=5A:F1:B7:B0:F3:E9 nodemac=AE:DA:26:C6:07:48"
}

