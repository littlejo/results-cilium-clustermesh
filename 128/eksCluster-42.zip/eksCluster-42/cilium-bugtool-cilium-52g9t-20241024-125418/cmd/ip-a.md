1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a9:b7:ff:c3:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.184.21/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3437sec preferred_lft 3437sec
    inet6 fe80::4a9:b7ff:feff:c33d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2b:9e:ab:ed:a3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.146.47/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::42b:9eff:feab:eda3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:49:b5:9b:31:80 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c49:b5ff:fe9b:3180/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:f8:d8:1b:04:45 brd ff:ff:ff:ff:ff:ff
    inet 10.42.0.128/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d8f8:d8ff:fe1b:445/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 32:71:de:a3:8d:4e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3071:deff:fea3:8d4e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:be:5d:4f:36:00 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a0be:5dff:fe4f:3600/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcdd42776992da@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:3b:37:7c:b0:27 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::dc3b:37ff:fe7c:b027/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfad7af016bb0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:70:07:3a:61:68 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::1070:7ff:fe3a:6168/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc900035d9ce1f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:1f:86:ee:12:bb brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::841f:86ff:feee:12bb/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc1ab67cb9dfba@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:a6:86:7c:5f:89 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::dca6:86ff:fe7c:5f89/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc03dad8b366d3@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:25:f5:cf:bd:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::7825:f5ff:fecf:bda3/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc642cea839cb4@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:da:26:c6:07:48 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::acda:26ff:fec6:748/64 scope link 
       valid_lft forever preferred_lft forever
