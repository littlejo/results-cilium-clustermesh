KEY             VALUE
AgentLiveness   1974454456872
UTimeOffset     3378461888671875
