filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc642cea839cb4 direct-action not_in_hw id 3340 tag 1f35645e159a97e6 jited 
