REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     130870    10595044    677    bpf_overlay.c
Interface                   INGRESS     669700    247224073   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      130297    10557169    53     encap.h
Success                     EGRESS      154328    20153193    1308   bpf_lxc.c
Success                     EGRESS      54197     4396997     1694   bpf_host.c
Success                     EGRESS      596       156261      86     l3.h
Success                     INGRESS     177996    20499201    86     l3.h
Success                     INGRESS     255769    26886581    235    trace.h
Unsupported L3 protocol     EGRESS      71        5350        1492   bpf_lxc.c
