Total: 569
TCP:   3060 (estab 313, closed 2728, orphaned 0, timewait 2264)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  332       319       13       
INET	  342       325       17       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33876 sk:a1a cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:45337      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32868 sk:a1b fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14111 sk:a1c cgroup:unreachable:e8e <->                                    
UNCONN 0      0                   172.31.210.91%ens5:68         0.0.0.0:*    uid:192 ino:126080 sk:a1d cgroup:unreachable:bd0 <->                           
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33875 sk:a1e cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14112 sk:a1f cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::8f9:56ff:feba:75e7]%ens5:546           [::]:*    uid:192 ino:15656 sk:a20 cgroup:unreachable:bd0 v6only:1 <->                   
