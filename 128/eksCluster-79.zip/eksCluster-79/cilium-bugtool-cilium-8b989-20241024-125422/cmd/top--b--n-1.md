top - 12:54:24 up 31 min,  0 users,  load average: 0.64, 0.75, 0.43
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 23.3 us, 30.0 sy,  0.0 ni, 40.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,    293.1 free,   1046.2 used,   2496.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2608.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 288092  79420 S   0.0   7.3   1:17.63 cilium-+
    394 root      20   0 1229744  10044   3836 S   0.0   0.3   0:04.62 cilium-+
   3102 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3135 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3154 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3186 root      20   0 1240432  15988  11100 S   0.0   0.4   0:00.02 cilium-+
   3200 root      20   0 1229000   4040   3392 S   0.0   0.1   0:00.00 gops
   3226 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3244 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
