filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb467c8da62bd direct-action not_in_hw id 584 tag 87039db47c3cbb3d jited 
