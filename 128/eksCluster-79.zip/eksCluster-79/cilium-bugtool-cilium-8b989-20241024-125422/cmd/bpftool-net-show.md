xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 579
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 553
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 490
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 491
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 541
lxcb467c8da62bd(12) clsact/ingress cil_from_container-lxcb467c8da62bd id 584
lxc4b6069529698(14) clsact/ingress cil_from_container-lxc4b6069529698 id 536
lxcf16ac2fb7fda(18) clsact/ingress cil_from_container-lxcf16ac2fb7fda id 658
lxcd5a7101a415d(20) clsact/ingress cil_from_container-lxcd5a7101a415d id 3354
lxc9757aa154d99(22) clsact/ingress cil_from_container-lxc9757aa154d99 id 3351
lxc18bbf928f917(24) clsact/ingress cil_from_container-lxc18bbf928f917 id 3297

flow_dissector:

netfilter:

