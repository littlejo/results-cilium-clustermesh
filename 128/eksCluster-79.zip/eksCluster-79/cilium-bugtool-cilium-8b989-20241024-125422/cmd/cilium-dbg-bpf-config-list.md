KEY             VALUE
AgentLiveness   1948768820787
UTimeOffset     3378462003906250
