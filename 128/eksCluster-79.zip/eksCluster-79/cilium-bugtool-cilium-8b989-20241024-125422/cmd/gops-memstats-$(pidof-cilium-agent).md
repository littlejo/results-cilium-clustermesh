alloc: 76.04MB (79730016 bytes)
total-alloc: 3.10GB (3330582032 bytes)
sys: 219.07MB (229713236 bytes)
lookups: 0
mallocs: 75526933
frees: 75025865
heap-alloc: 76.04MB (79730016 bytes)
heap-sys: 174.79MB (183279616 bytes)
heap-idle: 47.09MB (49373184 bytes)
heap-in-use: 127.70MB (133906432 bytes)
heap-released: 4.00MB (4194304 bytes)
heap-objects: 501068
stack-in-use: 33.19MB (34799616 bytes)
stack-sys: 33.19MB (34799616 bytes)
stack-mspan-inuse: 2.07MB (2171360 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 725.72KB (743137 bytes)
gc-sys: 5.50MB (5768264 bytes)
next-gc: when heap-alloc >= 148.88MB (156117224 bytes)
last-gc: 2024-10-24 12:54:53.497578638 +0000 UTC
gc-pause-total: 20.119162ms
gc-pause: 89048
gc-pause-end: 1729774493497578638
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0006909761919542407
enable-gc: true
debug-gc: false
