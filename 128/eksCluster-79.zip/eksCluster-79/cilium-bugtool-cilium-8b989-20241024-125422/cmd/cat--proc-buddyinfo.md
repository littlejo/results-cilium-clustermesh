Node 0, zone      DMA     43     92      8     31     14     12      5      5      4      2     44 
Node 0, zone   Normal    207     42      1      7     15      4      2      3      3      3      7 
