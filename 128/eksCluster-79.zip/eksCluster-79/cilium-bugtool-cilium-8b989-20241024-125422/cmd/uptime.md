 12:54:24 up 31 min,  0 users,  load average: 0.64, 0.75, 0.43
