IP ADDRESS        LOCAL ENDPOINT INFO
10.79.0.254:0     id=314   sec_id=5248139 flags=0x0000 ifindex=12  mac=F2:C7:06:39:B0:15 nodemac=92:15:A8:0D:A6:86   
10.79.0.227:0     id=293   sec_id=5259984 flags=0x0000 ifindex=18  mac=1E:F5:1C:81:6D:AD nodemac=B6:48:12:1C:2A:28   
10.79.0.65:0      id=1899  sec_id=5274605 flags=0x0000 ifindex=24  mac=3A:9E:8C:07:5A:25 nodemac=4E:BC:BA:FF:29:93   
10.79.0.161:0     (localhost)                                                                                        
10.79.0.36:0      id=1110  sec_id=5253654 flags=0x0000 ifindex=20  mac=EE:07:A0:B3:E3:FC nodemac=32:DC:A8:F5:FE:2C   
172.31.210.91:0   (localhost)                                                                                        
172.31.224.93:0   (localhost)                                                                                        
10.79.0.64:0      id=614   sec_id=5251565 flags=0x0000 ifindex=22  mac=5E:42:C3:BD:8F:4E nodemac=92:6B:5E:CB:9A:56   
10.79.0.73:0      id=780   sec_id=5248139 flags=0x0000 ifindex=14  mac=5E:96:15:7A:9E:EA nodemac=02:FC:C6:E7:AB:64   
10.79.0.28:0      id=70    sec_id=4     flags=0x0000 ifindex=10  mac=DE:42:2A:A6:8A:4D nodemac=3E:DA:D1:D1:2B:7B     
