[
  {
    "containers": [
      {
        "cgroup-id": 7709,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c23f32f_1584_42d9_8fe8_5e8c5650d7cd.slice/cri-containerd-be802012428200359fb95eca47e9b45f14d1e8c07aa1c791233c27a4e11c03dc.scope"
      }
    ],
    "ips": [
      "10.79.0.73"
    ],
    "name": "coredns-cc6ccd49c-wg2gs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb42770bb_14ec_488c_8efc_d03fcd5626fe.slice/cri-containerd-7808aed9c22017be7c16bc640ba2447507a529bf95fedd85eac2ffc6f8184404.scope"
      },
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb42770bb_14ec_488c_8efc_d03fcd5626fe.slice/cri-containerd-18d8e714c8e07b1b9c3c8bc9a235e9eb69ad13953046f74bf17e18a2c86ed084.scope"
      }
    ],
    "ips": [
      "10.79.0.65"
    ],
    "name": "echo-same-node-86d9cc975c-9mctx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2678b828_2988_4736_8c82_02f69bb48b6b.slice/cri-containerd-2962454c48c909dc6f6654c47c2c5f0ca9dc8e311189f439574c4de8944893c9.scope"
      },
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2678b828_2988_4736_8c82_02f69bb48b6b.slice/cri-containerd-e8e071d17743fdd1f0873e0c8c54ea9d838db39b2e16ee46809c66ee59d9106d.scope"
      },
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2678b828_2988_4736_8c82_02f69bb48b6b.slice/cri-containerd-5220915d4a887fe18b7cbf76f8291b7c6e26cec124f0710d5cd2d888e7849930.scope"
      }
    ],
    "ips": [
      "10.79.0.227"
    ],
    "name": "clustermesh-apiserver-6fd6c58c8b-llhr2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7625,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod91128bac_47db_4123_bf1d_9a1648b4759c.slice/cri-containerd-36d7351ca46799ef6b92a4c66a03aa19f4b9cf8821230fdadbba227a4a3911e7.scope"
      }
    ],
    "ips": [
      "10.79.0.254"
    ],
    "name": "coredns-cc6ccd49c-4lhns",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2efdbf4_4856_4669_93f1_8bc665eadbde.slice/cri-containerd-0c4fb05c540b78fe59a62c64bfe4ae9afcb2dc63209fc9606a6b40492985d4c8.scope"
      }
    ],
    "ips": [
      "10.79.0.64"
    ],
    "name": "client2-57cf4468f-v7b5n",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e38d70_a345_4f52_969a_9c7019654cc8.slice/cri-containerd-17f1240a72aba054cc14ec3322c8e5d27ab21badb1e8beeb3a9086de5b63ea62.scope"
      }
    ],
    "ips": [
      "10.79.0.36"
    ],
    "name": "client-974f6c69d-sss8q",
    "namespace": "cilium-test-1"
  }
]

