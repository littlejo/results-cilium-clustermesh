filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd5a7101a415d direct-action not_in_hw id 3354 tag 35fcd7207503e5fd jited 
