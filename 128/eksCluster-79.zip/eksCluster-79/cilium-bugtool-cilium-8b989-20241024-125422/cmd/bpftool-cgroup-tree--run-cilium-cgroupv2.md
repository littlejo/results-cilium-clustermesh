CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4cbfb448_6de5_4908_a1e6_b6674d1a8d2b.slice/cri-containerd-3cd6c8542af7129b7ad6f19820b3abb3276fd444d62252e135522abf4f40c2a7.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4cbfb448_6de5_4908_a1e6_b6674d1a8d2b.slice/cri-containerd-dd2f48bbf02ba83c1e25d70c2f18444e58d158c930e8391dc95da0eff8e332f2.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ff7799a_7d60_49a2_a541_92ffd4aeef50.slice/cri-containerd-e863d363f21968cd46e9420f1455ad51903bd666bccf9e4119b5c19094759c75.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ff7799a_7d60_49a2_a541_92ffd4aeef50.slice/cri-containerd-9f4732419adc311b896e7438771acec1dd30232d52e41140314a14b6b8d0545e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c23f32f_1584_42d9_8fe8_5e8c5650d7cd.slice/cri-containerd-be802012428200359fb95eca47e9b45f14d1e8c07aa1c791233c27a4e11c03dc.scope
    608      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c23f32f_1584_42d9_8fe8_5e8c5650d7cd.slice/cri-containerd-342076f3f4e66fd0b2ebdfc8bb12626e665c0a1e8228ec260a0434c8cbb8a351.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod91128bac_47db_4123_bf1d_9a1648b4759c.slice/cri-containerd-a094842b938d500888585d1aff544287a1f9aad65e311f4620d7ce34ee50a97c.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod91128bac_47db_4123_bf1d_9a1648b4759c.slice/cri-containerd-36d7351ca46799ef6b92a4c66a03aa19f4b9cf8821230fdadbba227a4a3911e7.scope
    604      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2efdbf4_4856_4669_93f1_8bc665eadbde.slice/cri-containerd-0c4fb05c540b78fe59a62c64bfe4ae9afcb2dc63209fc9606a6b40492985d4c8.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2efdbf4_4856_4669_93f1_8bc665eadbde.slice/cri-containerd-aa5fab5ff77f30f51ea57e04c19f75386679319d8013fac59d75430acd52ff99.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfda77f58_3de3_4bb1_b2ae_fa910da7657e.slice/cri-containerd-e500fa936dbe4c924e698a5df114c6ef3352a7558061abe55c944dc040c8efe1.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfda77f58_3de3_4bb1_b2ae_fa910da7657e.slice/cri-containerd-6a63683484dc75a129dac16b388b9bc8853301db4e7e2ecb23844084cba167bb.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3469a19_0550_4d3f_a23f_82b47ffc4e7a.slice/cri-containerd-df9c5eee30fbad2daf05ef907d1dd91acca09ecd636c03250ab023ee6ea14e22.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3469a19_0550_4d3f_a23f_82b47ffc4e7a.slice/cri-containerd-e07c316d273b52e8f1f2d1c44536e554371cb00dc3c9238aacf0af3cc408c51a.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e38d70_a345_4f52_969a_9c7019654cc8.slice/cri-containerd-17f1240a72aba054cc14ec3322c8e5d27ab21badb1e8beeb3a9086de5b63ea62.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e38d70_a345_4f52_969a_9c7019654cc8.slice/cri-containerd-c865223baac426fab041da4f1114e9100e8a2f0f789eeb544906b73cc8c74afe.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2678b828_2988_4736_8c82_02f69bb48b6b.slice/cri-containerd-098493c4663788582da34a00d8beb875fb272b673201725f6bf47ac73694eb4b.scope
    662      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2678b828_2988_4736_8c82_02f69bb48b6b.slice/cri-containerd-5220915d4a887fe18b7cbf76f8291b7c6e26cec124f0710d5cd2d888e7849930.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2678b828_2988_4736_8c82_02f69bb48b6b.slice/cri-containerd-e8e071d17743fdd1f0873e0c8c54ea9d838db39b2e16ee46809c66ee59d9106d.scope
    682      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2678b828_2988_4736_8c82_02f69bb48b6b.slice/cri-containerd-2962454c48c909dc6f6654c47c2c5f0ca9dc8e311189f439574c4de8944893c9.scope
    686      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb42770bb_14ec_488c_8efc_d03fcd5626fe.slice/cri-containerd-099bf9352c90eaf5a9273ac492e60cd7cd6a8fe4fa1108a2cad084a2aa881e11.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb42770bb_14ec_488c_8efc_d03fcd5626fe.slice/cri-containerd-18d8e714c8e07b1b9c3c8bc9a235e9eb69ad13953046f74bf17e18a2c86ed084.scope
    743      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb42770bb_14ec_488c_8efc_d03fcd5626fe.slice/cri-containerd-7808aed9c22017be7c16bc640ba2447507a529bf95fedd85eac2ffc6f8184404.scope
    747      cgroup_device   multi                                          
