1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f9:56:ba:75:e7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.210.91/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3494sec preferred_lft 3494sec
    inet6 fe80::8f9:56ff:feba:75e7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1a:f8:13:23:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.224.93/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::81a:f8ff:fe13:23cd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:82:f7:24:51:d6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c82:f7ff:fe24:51d6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:4d:12:c4:3f:eb brd ff:ff:ff:ff:ff:ff
    inet 10.79.0.161/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::404d:12ff:fec4:3feb/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether be:e7:27:7d:7d:8a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bce7:27ff:fe7d:7d8a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:da:d1:d1:2b:7b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3cda:d1ff:fed1:2b7b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb467c8da62bd@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:15:a8:0d:a6:86 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9015:a8ff:fe0d:a686/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc4b6069529698@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:fc:c6:e7:ab:64 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fc:c6ff:fee7:ab64/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf16ac2fb7fda@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:48:12:1c:2a:28 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b448:12ff:fe1c:2a28/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcd5a7101a415d@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:dc:a8:f5:fe:2c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::30dc:a8ff:fef5:fe2c/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc9757aa154d99@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:6b:5e:cb:9a:56 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::906b:5eff:fecb:9a56/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc18bbf928f917@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:bc:ba:ff:29:93 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::4cbc:baff:feff:2993/64 scope link 
       valid_lft forever preferred_lft forever
