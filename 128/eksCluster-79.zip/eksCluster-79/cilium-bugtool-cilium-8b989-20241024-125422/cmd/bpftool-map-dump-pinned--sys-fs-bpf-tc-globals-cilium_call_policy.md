key: 46 00 00 00  value: 1f 02 00 00
key: 25 01 00 00  value: 8d 02 00 00
key: 3a 01 00 00  value: 4c 02 00 00
key: 66 02 00 00  value: 24 0d 00 00
key: 0c 03 00 00  value: 23 02 00 00
key: 56 04 00 00  value: 12 0d 00 00
key: 6b 07 00 00  value: db 0c 00 00
Found 7 elements
