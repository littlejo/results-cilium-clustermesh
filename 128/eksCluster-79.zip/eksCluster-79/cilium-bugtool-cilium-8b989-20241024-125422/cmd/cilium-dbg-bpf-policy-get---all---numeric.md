Endpoint ID: 70
Path: /sys/fs/bpf/tc/globals/cilium_policy_00070

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6235335   77231     0        
Allow    Ingress     1          ANY          NONE         disabled    61270     741       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 293
Path: /sys/fs/bpf/tc/globals/cilium_policy_00293

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6048291   61131     0        
Allow    Ingress     1          ANY          NONE         disabled    5703406   60444     0        
Allow    Egress      0          ANY          NONE         disabled    7432563   72916     0        


Endpoint ID: 306
Path: /sys/fs/bpf/tc/globals/cilium_policy_00306

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 314
Path: /sys/fs/bpf/tc/globals/cilium_policy_00314

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3216     33        0        
Allow    Ingress     1          ANY          NONE         disabled    139158   1594      0        
Allow    Egress      0          ANY          NONE         disabled    20323    225       0        


Endpoint ID: 614
Path: /sys/fs/bpf/tc/globals/cilium_policy_00614

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 780
Path: /sys/fs/bpf/tc/globals/cilium_policy_00780

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2680     27        0        
Allow    Ingress     1          ANY          NONE         disabled    138737   1592      0        
Allow    Egress      0          ANY          NONE         disabled    19261    212       0        


Endpoint ID: 1110
Path: /sys/fs/bpf/tc/globals/cilium_policy_01110

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1899
Path: /sys/fs/bpf/tc/globals/cilium_policy_01899

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377349   4407      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


