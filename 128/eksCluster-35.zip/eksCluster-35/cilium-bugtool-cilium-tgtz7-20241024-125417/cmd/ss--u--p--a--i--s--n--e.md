Total: 568
TCP:   4073 (estab 292, closed 3762, orphaned 0, timewait 3315)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  311       300       11       
INET	  321       306       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                 172.31.215.246%ens5:68         0.0.0.0:*    uid:192 ino:64990 sk:e20 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                           127.0.0.1:45245      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:60739 sk:e21 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:59898 sk:e22 cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15644 sk:e23 cgroup:unreachable:e8e <->                                    
UNCONN 0      0      [fe80::8a6:59ff:fe0d:bc7]%ens5:546           [::]:*    uid:192 ino:15865 sk:e24 cgroup:unreachable:bd0 v6only:1 <->                   
UNCONN 0      0                                [::]:8472          [::]:*    ino:59897 sk:e25 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15645 sk:e26 cgroup:unreachable:e8e v6only:1 <->                           
