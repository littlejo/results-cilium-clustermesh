xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 496
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 491
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 555
lxc79932c9c4a26(12) clsact/ingress cil_from_container-lxc79932c9c4a26 id 551
lxc6e3d362582a1(14) clsact/ingress cil_from_container-lxc6e3d362582a1 id 533
lxc7b28de4c0005(18) clsact/ingress cil_from_container-lxc7b28de4c0005 id 616
lxc18cb6b46457b(20) clsact/ingress cil_from_container-lxc18cb6b46457b id 3320
lxc6f17fc6d27fe(22) clsact/ingress cil_from_container-lxc6f17fc6d27fe id 3279
lxcbb3692957500(24) clsact/ingress cil_from_container-lxcbb3692957500 id 3333

flow_dissector:

netfilter:

