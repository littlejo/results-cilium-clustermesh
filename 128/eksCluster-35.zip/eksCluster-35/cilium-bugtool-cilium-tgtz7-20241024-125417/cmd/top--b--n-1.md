top - 12:54:18 up 56 min,  0 users,  load average: 0.57, 0.44, 0.28
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.7 us, 25.0 sy,  0.0 ni, 64.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    291.7 free,   1046.6 used,   2497.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2608.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 290844  78832 S   6.7   7.4   1:16.25 cilium-+
   3142 root      20   0 1240432  16152  11100 S   6.7   0.4   0:00.03 cilium-+
    397 root      20   0 1229744   8812   2924 S   0.0   0.2   0:04.64 cilium-+
   3114 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3124 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3125 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3126 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3179 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3198 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
