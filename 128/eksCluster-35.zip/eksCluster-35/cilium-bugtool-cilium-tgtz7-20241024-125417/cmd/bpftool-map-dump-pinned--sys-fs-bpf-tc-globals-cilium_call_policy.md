key: 26 02 00 00  value: 04 0d 00 00
key: cb 02 00 00  value: 69 02 00 00
key: 1a 07 00 00  value: cb 0c 00 00
key: 05 09 00 00  value: 05 02 00 00
key: 8f 0c 00 00  value: 01 0d 00 00
key: 3d 0d 00 00  value: 28 02 00 00
key: 68 0f 00 00  value: 1e 02 00 00
Found 7 elements
