filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbb3692957500 direct-action not_in_hw id 3333 tag dc0519619be98c71 jited 
