{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.840Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.868Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.881Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.933Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.935Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.195Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.220Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.254Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.388Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.396Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.935Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.937Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.998Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.016Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.049Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.069Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.113Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.371Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.382Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.448Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.462Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.493Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.087Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.095Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.118Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.170Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.178Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.217Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.232Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.456Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.461Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.520Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.547Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.562Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.202Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.204Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.325Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.344Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.387Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.420Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.439Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.639Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.645Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.712Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.746Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.769Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.245Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.251Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.295Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.317Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.339Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.626Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.644Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.716Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.733Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.771Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.191Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.205Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.250Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.287Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.311Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.570Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.574Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.617Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.635Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.677Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.126Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.173Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.222Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.291Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.306Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.341Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.567Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.600Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.621Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.669Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.686Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.053Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.092Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.116Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.142Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.143Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.157Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.474Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.525Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.603Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.634Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.643Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.016Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.096Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.103Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.166Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.170Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.404Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.422Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.465Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.479Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.506Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.815Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.870Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.878Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.938Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.954Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.977Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.218Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.228Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.278Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.289Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.330Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.757Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.795Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.865Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.878Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.900Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.090Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.107Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.114Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.122Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.144Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.918Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.921Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.955Z",
  "value": "id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.986Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.007Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.292Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.326Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:37.110Z",
  "value": "id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:37.112Z",
  "value": "id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93"
}

