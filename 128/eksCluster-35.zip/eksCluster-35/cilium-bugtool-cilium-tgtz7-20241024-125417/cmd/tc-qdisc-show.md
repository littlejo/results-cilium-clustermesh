qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc79932c9c4a26 root refcnt 2 
qdisc clsact ffff: dev lxc79932c9c4a26 parent ffff:fff1 
qdisc noqueue 0: dev lxc6e3d362582a1 root refcnt 2 
qdisc clsact ffff: dev lxc6e3d362582a1 parent ffff:fff1 
qdisc noqueue 0: dev lxc7b28de4c0005 root refcnt 2 
qdisc clsact ffff: dev lxc7b28de4c0005 parent ffff:fff1 
qdisc noqueue 0: dev lxc18cb6b46457b root refcnt 2 
qdisc clsact ffff: dev lxc18cb6b46457b parent ffff:fff1 
qdisc noqueue 0: dev lxc6f17fc6d27fe root refcnt 2 
qdisc clsact ffff: dev lxc6f17fc6d27fe parent ffff:fff1 
qdisc noqueue 0: dev lxcbb3692957500 root refcnt 2 
qdisc clsact ffff: dev lxcbb3692957500 parent ffff:fff1 
