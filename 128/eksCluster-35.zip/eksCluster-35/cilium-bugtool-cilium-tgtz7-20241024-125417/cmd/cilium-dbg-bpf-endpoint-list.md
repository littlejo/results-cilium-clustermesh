IP ADDRESS         LOCAL ENDPOINT INFO
10.35.0.13:0       id=3215  sec_id=2392726 flags=0x0000 ifindex=20  mac=D2:04:39:B9:3B:99 nodemac=06:89:9D:F7:16:30   
10.35.0.188:0      (localhost)                                                                                        
10.35.0.179:0      id=3389  sec_id=4     flags=0x0000 ifindex=10  mac=5A:3E:2E:2B:0A:89 nodemac=42:4C:7C:A7:09:53     
10.35.0.103:0      id=2309  sec_id=2364469 flags=0x0000 ifindex=14  mac=0E:6E:2D:63:C9:B1 nodemac=12:5F:59:48:02:D9   
172.31.205.30:0    (localhost)                                                                                        
172.31.215.246:0   (localhost)                                                                                        
10.35.0.210:0      id=3944  sec_id=2364469 flags=0x0000 ifindex=12  mac=5E:FF:60:52:0D:E2 nodemac=AE:FF:EA:1D:AD:4E   
10.35.0.52:0       id=715   sec_id=2413895 flags=0x0000 ifindex=18  mac=0E:0F:6F:2E:AD:C2 nodemac=B6:AD:EC:6A:27:60   
10.35.0.212:0      id=550   sec_id=2360224 flags=0x0000 ifindex=24  mac=12:B6:41:99:E9:CF nodemac=86:03:81:01:A8:93   
10.35.0.224:0      id=1818  sec_id=2376118 flags=0x0000 ifindex=22  mac=36:7D:E7:9B:39:41 nodemac=DE:F6:C0:B9:2E:50   
