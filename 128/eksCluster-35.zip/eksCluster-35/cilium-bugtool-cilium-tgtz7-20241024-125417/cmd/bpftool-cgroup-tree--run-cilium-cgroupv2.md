CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod01562252_818e_4ae1_8d8a_9ef722089a0b.slice/cri-containerd-23b59b7a29d3f7808a69707105851f28c89bd03c8d90fa1fefdae232579d998e.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod01562252_818e_4ae1_8d8a_9ef722089a0b.slice/cri-containerd-331e0d67548d7445791211693e74c5ca908eef91e8308c9f230c73537b889203.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14980259_f6d0_4785_94c4_b857069528f6.slice/cri-containerd-8346ecf76ab63c1b08d8093cbce0095a46dc0685e6ef6c41129873557be732b2.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14980259_f6d0_4785_94c4_b857069528f6.slice/cri-containerd-6373ce6964332a570bc12bb13527b834c2e8f89bfe295838040b061647219b85.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34ae9c0e_5c14_415d_9f58_04f468e8d136.slice/cri-containerd-37d222ee048af777886c691e7e4bb19ba7d9aa83b11db4c6e478217ff382bb42.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34ae9c0e_5c14_415d_9f58_04f468e8d136.slice/cri-containerd-be83d30667f6b6b018d100c006f16c1863abb96ec67cefa8c3fdd654a345acad.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08b283c7_9dbd_4648_8253_f70ab0945360.slice/cri-containerd-008d4f11ea5faad0b006a167c72988ce7e7fa7fc97064e705b990978a397f323.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08b283c7_9dbd_4648_8253_f70ab0945360.slice/cri-containerd-6295e4304b120c64b4ecd251e5ad69c95434484746ec90d2d07838e147873142.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d6c9613_1863_44c6_8ec6_dc5537bd7b33.slice/cri-containerd-71858b62cae53cc6cb7dd37fc71028c6deaf86698725bafd7ff0c89e01da97a9.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d6c9613_1863_44c6_8ec6_dc5537bd7b33.slice/cri-containerd-9d1ae1d88a3f5bed9456f74ba4d72ed0ee4fc5c92d1b20a5dd80ae8aeb1e6fea.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod731faef8_3463_478f_859a_a9aaeff61582.slice/cri-containerd-26dada08c9bb44ec573ca2e8fe2867d5a1b8c0f1925f3f9fe934554c4f6d8e27.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod731faef8_3463_478f_859a_a9aaeff61582.slice/cri-containerd-b25516cb3694b12105a235f67b6e5e07d870cd7352ddd205b9791325465a9136.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod731faef8_3463_478f_859a_a9aaeff61582.slice/cri-containerd-462a0d5e89921c784110b495efb844c1787687c0b97b32fc44ea83b700a21859.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f66a710_8295_42a6_90db_e83527071c26.slice/cri-containerd-ea480e151d093c506a615d78da14ca5b0d183854ea96e223b633980e66c55eec.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f66a710_8295_42a6_90db_e83527071c26.slice/cri-containerd-780915d731d4bb46f8f74d804781fb4799db60b68057fa42eca6f3a322a7d85c.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f66a710_8295_42a6_90db_e83527071c26.slice/cri-containerd-3c5f4a4e44d8ce4b1c1a3a00f4cf27313f8e013c5ab96d758184d223f101270d.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f66a710_8295_42a6_90db_e83527071c26.slice/cri-containerd-754fc0f675d78a740cbc43b166b1a957b2f0fbfffae05351830c11c8cc2babeb.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeba2eb1c_bc87_46db_b906_da3eaa75ae76.slice/cri-containerd-d54b5d53a750f25745dcd1f88f3029ef923c37f1914b5fa9cfcf3343bc468848.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeba2eb1c_bc87_46db_b906_da3eaa75ae76.slice/cri-containerd-1a133ff70f14be9190d419d5d82d1e2a25b623fc060a704ec789f23cf22a81bf.scope
    687      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod76b5145d_d90f_424c_abbb_c3d0ffb45ec9.slice/cri-containerd-0a9a25de513c2b30fbb1246c0724fbaf17e23faf7c8b43bf8597e3eb96d2226b.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod76b5145d_d90f_424c_abbb_c3d0ffb45ec9.slice/cri-containerd-7ae54b5120127a35b83d066628b62611a56f0603c1c5c2d468a105d44093d993.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8376bc57_0af8_4e30_8d84_941840f340c1.slice/cri-containerd-316cd289c1ad3c5aaeae28443c0e669144b7f3987e076cb1e6a5472b3f081039.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8376bc57_0af8_4e30_8d84_941840f340c1.slice/cri-containerd-116defba2ea12eb5b280d0b20c71b63056b8201e081ce3ac98dcfcec1e8bbc31.scope
    106      cgroup_device   multi                                          
