KEY             VALUE
AgentLiveness   3400459469270
UTimeOffset     3378459158203125
