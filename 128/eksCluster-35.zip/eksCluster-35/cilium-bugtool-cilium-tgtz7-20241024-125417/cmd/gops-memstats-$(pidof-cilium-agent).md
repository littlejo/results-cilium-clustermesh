alloc: 116.22MB (121869488 bytes)
total-alloc: 3.06GB (3282663928 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74544994
frees: 73309378
heap-alloc: 116.22MB (121869488 bytes)
heap-sys: 172.73MB (181125120 bytes)
heap-idle: 36.91MB (38699008 bytes)
heap-in-use: 135.83MB (142426112 bytes)
heap-released: 5.62MB (5890048 bytes)
heap-objects: 1235616
stack-in-use: 35.22MB (36929536 bytes)
stack-sys: 35.22MB (36929536 bytes)
stack-mspan-inuse: 2.22MB (2332320 bytes)
stack-mspan-sys: 2.74MB (2872320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1009.59KB (1033825 bytes)
gc-sys: 5.54MB (5805200 bytes)
next-gc: when heap-alloc >= 150.31MB (157607064 bytes)
last-gc: 2024-10-24 12:54:21.474787185 +0000 UTC
gc-pause-total: 15.688601ms
gc-pause: 286041
gc-pause-end: 1729774461474787185
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005975429497655944
enable-gc: true
debug-gc: false
