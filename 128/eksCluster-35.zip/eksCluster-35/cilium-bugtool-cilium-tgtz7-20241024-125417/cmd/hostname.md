ip-172-31-215-246.eu-west-3.compute.internal
