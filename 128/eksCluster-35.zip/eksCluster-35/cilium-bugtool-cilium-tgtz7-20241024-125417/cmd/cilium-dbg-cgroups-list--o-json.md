[
  {
    "containers": [
      {
        "cgroup-id": 7704,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod01562252_818e_4ae1_8d8a_9ef722089a0b.slice/cri-containerd-23b59b7a29d3f7808a69707105851f28c89bd03c8d90fa1fefdae232579d998e.scope"
      }
    ],
    "ips": [
      "10.35.0.210"
    ],
    "name": "coredns-cc6ccd49c-ct884",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d6c9613_1863_44c6_8ec6_dc5537bd7b33.slice/cri-containerd-71858b62cae53cc6cb7dd37fc71028c6deaf86698725bafd7ff0c89e01da97a9.scope"
      }
    ],
    "ips": [
      "10.35.0.212"
    ],
    "name": "client-974f6c69d-xl8zg",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeba2eb1c_bc87_46db_b906_da3eaa75ae76.slice/cri-containerd-d54b5d53a750f25745dcd1f88f3029ef923c37f1914b5fa9cfcf3343bc468848.scope"
      }
    ],
    "ips": [
      "10.35.0.13"
    ],
    "name": "client2-57cf4468f-jjvvq",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f66a710_8295_42a6_90db_e83527071c26.slice/cri-containerd-780915d731d4bb46f8f74d804781fb4799db60b68057fa42eca6f3a322a7d85c.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f66a710_8295_42a6_90db_e83527071c26.slice/cri-containerd-ea480e151d093c506a615d78da14ca5b0d183854ea96e223b633980e66c55eec.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f66a710_8295_42a6_90db_e83527071c26.slice/cri-containerd-3c5f4a4e44d8ce4b1c1a3a00f4cf27313f8e013c5ab96d758184d223f101270d.scope"
      }
    ],
    "ips": [
      "10.35.0.52"
    ],
    "name": "clustermesh-apiserver-7f54b89fd4-dlcmk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod731faef8_3463_478f_859a_a9aaeff61582.slice/cri-containerd-26dada08c9bb44ec573ca2e8fe2867d5a1b8c0f1925f3f9fe934554c4f6d8e27.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod731faef8_3463_478f_859a_a9aaeff61582.slice/cri-containerd-b25516cb3694b12105a235f67b6e5e07d870cd7352ddd205b9791325465a9136.scope"
      }
    ],
    "ips": [
      "10.35.0.224"
    ],
    "name": "echo-same-node-86d9cc975c-ggsn7",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7620,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14980259_f6d0_4785_94c4_b857069528f6.slice/cri-containerd-8346ecf76ab63c1b08d8093cbce0095a46dc0685e6ef6c41129873557be732b2.scope"
      }
    ],
    "ips": [
      "10.35.0.103"
    ],
    "name": "coredns-cc6ccd49c-cqxxk",
    "namespace": "kube-system"
  }
]

