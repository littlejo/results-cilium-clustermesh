32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:58:11+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T11:58:12+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T11:58:17+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:58:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:58:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T11:58:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:26:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
482: sched_cls  name tail_handle_ipv4  tag d79c1e10ff0ff051  gpl
	loaded_at 2024-10-24T12:26:32+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
483: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:26:32+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:26:32+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
486: sched_cls  name __send_drop_notify  tag d95b43e3559f2598  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 130
487: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 131
489: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 133
490: sched_cls  name tail_handle_ipv4_from_host  tag 3a044e5e30d8ef62  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 134
491: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,102
	btf_id 135
493: sched_cls  name __send_drop_notify  tag d95b43e3559f2598  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 138
494: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 139
496: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 141
497: sched_cls  name tail_handle_ipv4_from_host  tag 3a044e5e30d8ef62  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 142
499: sched_cls  name __send_drop_notify  tag d95b43e3559f2598  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 145
500: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 146
501: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 147
503: sched_cls  name tail_handle_ipv4_from_host  tag 3a044e5e30d8ef62  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 149
506: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 153
508: sched_cls  name tail_handle_ipv4_from_host  tag 3a044e5e30d8ef62  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 155
511: sched_cls  name __send_drop_notify  tag d95b43e3559f2598  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 158
512: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 159
517: sched_cls  name handle_policy  tag 702db92c279a6bf8  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 163
519: sched_cls  name tail_handle_ipv4  tag bb485862cd4f6be7  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 168
523: sched_cls  name tail_ipv4_to_endpoint  tag a1da74a194040bfa  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 170
525: sched_cls  name tail_handle_ipv4_cont  tag 9b02a5dfbb9cbe42  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 174
526: sched_cls  name __send_drop_notify  tag 51e4b7f4919ef822  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 175
528: sched_cls  name tail_ipv4_ct_ingress  tag 71e446205251d7d6  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 177
529: sched_cls  name tail_handle_arp  tag c37813a8c4c249a5  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 178
530: sched_cls  name tail_ipv4_ct_egress  tag 190f43e377e1c813  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 180
532: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 181
533: sched_cls  name cil_from_container  tag 399b3d4f7ac8bf23  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 182
536: sched_cls  name tail_ipv4_ct_egress  tag 190f43e377e1c813  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 185
537: sched_cls  name tail_ipv4_ct_ingress  tag b0b268beda8fa7b5  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 188
538: sched_cls  name tail_handle_arp  tag f1ec9a69dbc5b73d  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 189
539: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 190
540: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 191
541: sched_cls  name tail_ipv4_to_endpoint  tag 0c9cebd049d6ebbd  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 193
542: sched_cls  name handle_policy  tag 2e8f7916af8880e6  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 192
543: sched_cls  name tail_ipv4_ct_ingress  tag ab9b6ef284bda37a  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 194
544: sched_cls  name tail_handle_arp  tag ebeb803d571133ac  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 195
545: sched_cls  name tail_handle_ipv4  tag 15d712a5a7528a0d  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 196
546: sched_cls  name __send_drop_notify  tag 1146bd57ed86218b  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
547: sched_cls  name tail_handle_ipv4_cont  tag 61ccb2ecf3df5728  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 199
548: sched_cls  name tail_handle_ipv4  tag 58ac7fdca8fbe9b8  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 197
549: sched_cls  name tail_ipv4_to_endpoint  tag c7d15a4f20e63973  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 200
551: sched_cls  name cil_from_container  tag 95df4695f92f9692  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 203
552: sched_cls  name handle_policy  tag e2dd4fdff01950c4  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 201
553: sched_cls  name __send_drop_notify  tag dcb76f079bce898b  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 204
554: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 205
555: sched_cls  name cil_from_container  tag 4da0f860ecf56af7  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 206
556: sched_cls  name tail_handle_ipv4_cont  tag a01d0f23243c1d6e  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 207
557: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
560: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
561: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
564: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
565: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
568: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
569: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
572: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
612: sched_cls  name tail_handle_ipv4_cont  tag 6768a91cdf55edb5  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 221
613: sched_cls  name tail_ipv4_ct_egress  tag d7b374f9778eb9bc  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 222
614: sched_cls  name tail_ipv4_to_endpoint  tag 87941de2401fbdde  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 223
615: sched_cls  name tail_handle_arp  tag 982dee6a066b28f8  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 224
616: sched_cls  name cil_from_container  tag 3e86e5f6de6f4364  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 225
617: sched_cls  name handle_policy  tag 1d755690b06a6fec  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 226
618: sched_cls  name tail_handle_ipv4  tag 07ac1969917068df  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 227
620: sched_cls  name __send_drop_notify  tag 82f61d4080be8c43  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 229
621: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 230
622: sched_cls  name tail_ipv4_ct_ingress  tag c2b69cfd5b4b7dbe  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 231
623: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
626: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
639: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
642: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
646: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
684: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
687: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
688: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
691: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
692: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
695: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
696: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
699: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
700: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
703: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3264: sched_cls  name tail_handle_ipv4_cont  tag 8213b29ab4fe5c86  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,623,41,146,82,83,39,76,74,77,624,40,37,38,81
	btf_id 3053
3267: sched_cls  name tail_ipv4_to_endpoint  tag a30f24d2df456686  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,623,41,82,83,80,146,39,624,40,37,38
	btf_id 3054
3268: sched_cls  name tail_handle_arp  tag adfe4b1e2dc606f0  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,624
	btf_id 3059
3269: sched_cls  name __send_drop_notify  tag c6698ac1fe9db5d9  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3060
3270: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,624
	btf_id 3061
3271: sched_cls  name tail_ipv4_ct_egress  tag cbb57094d7c950b8  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,624,82,83,623,84
	btf_id 3062
3274: sched_cls  name tail_handle_ipv4  tag 99406552fd25f99b  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,624
	btf_id 3064
3275: sched_cls  name handle_policy  tag 79bab0346d4c4ce0  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,624,82,83,623,41,80,146,39,84,75,40,37,38
	btf_id 3066
3278: sched_cls  name tail_ipv4_ct_ingress  tag fd4f568f7514d601  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,624,82,83,623,84
	btf_id 3067
3279: sched_cls  name cil_from_container  tag 9584a7b062a940fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 624,76
	btf_id 3070
3320: sched_cls  name cil_from_container  tag ecf8d1c0cd63416c  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3116
3321: sched_cls  name tail_handle_ipv4_cont  tag efb88c16ec418049  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,143,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3117
3322: sched_cls  name tail_ipv4_to_endpoint  tag 4f8e6e63a10bab4f  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,147,39,633,40,37,38
	btf_id 3113
3323: sched_cls  name tail_ipv4_ct_egress  tag f0f8dd341d14e8f9  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3118
3324: sched_cls  name tail_handle_ipv4_cont  tag 7ee496410c2a3310  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,147,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3119
3325: sched_cls  name tail_handle_arp  tag be52d7abd4e3a394  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3121
3327: sched_cls  name __send_drop_notify  tag df6ac366a9a0724f  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3123
3328: sched_cls  name tail_ipv4_ct_ingress  tag 6407bb4b7aa18609  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3124
3329: sched_cls  name handle_policy  tag 14073b6d43c0efb6  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,143,39,84,75,40,37,38
	btf_id 3120
3330: sched_cls  name tail_handle_arp  tag ba3311b2ab3fc5b5  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3126
3331: sched_cls  name tail_handle_ipv4  tag 5bf7cc1b7c2bfc21  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3127
3332: sched_cls  name handle_policy  tag 2bc20e5dbc3e7ece  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,147,39,84,75,40,37,38
	btf_id 3125
3333: sched_cls  name cil_from_container  tag dc0519619be98c71  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3129
3334: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3130
3335: sched_cls  name tail_ipv4_to_endpoint  tag 0700353e2679436d  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,143,39,636,40,37,38
	btf_id 3128
3336: sched_cls  name tail_handle_ipv4  tag cf286d071f49f017  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3131
3337: sched_cls  name __send_drop_notify  tag c4263903f89c13fe  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3133
3338: sched_cls  name tail_ipv4_ct_ingress  tag e9ae7a0ac72bb6b2  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3134
3339: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3135
3340: sched_cls  name tail_ipv4_ct_egress  tag 6fc7af4fa0225a33  gpl
	loaded_at 2024-10-24T12:51:37+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3132
