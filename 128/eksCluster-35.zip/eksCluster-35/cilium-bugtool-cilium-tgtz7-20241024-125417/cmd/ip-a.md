1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a6:59:0d:0b:c7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.215.246/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2041sec preferred_lft 2041sec
    inet6 fe80::8a6:59ff:fe0d:bc7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:91:5f:3f:33:e5 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.205.30/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::891:5fff:fe3f:33e5/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:90:dc:ad:74:12 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1090:dcff:fead:7412/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:a3:5d:c3:74:85 brd ff:ff:ff:ff:ff:ff
    inet 10.35.0.188/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b4a3:5dff:fec3:7485/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 16:a0:eb:7a:ba:f5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::14a0:ebff:fe7a:baf5/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:4c:7c:a7:09:53 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::404c:7cff:fea7:953/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc79932c9c4a26@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:ff:ea:1d:ad:4e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::acff:eaff:fe1d:ad4e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6e3d362582a1@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:5f:59:48:02:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::105f:59ff:fe48:2d9/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7b28de4c0005@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:ad:ec:6a:27:60 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b4ad:ecff:fe6a:2760/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc18cb6b46457b@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:89:9d:f7:16:30 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::489:9dff:fef7:1630/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc6f17fc6d27fe@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:f6:c0:b9:2e:50 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::dcf6:c0ff:feb9:2e50/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcbb3692957500@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:03:81:01:a8:93 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::8403:81ff:fe01:a893/64 scope link 
       valid_lft forever preferred_lft forever
