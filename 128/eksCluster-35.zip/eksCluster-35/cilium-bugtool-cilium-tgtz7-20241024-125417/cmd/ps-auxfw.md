USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3142  0.0  0.4 1240432 16152 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3168  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3169  0.0  0.0   3728   488 ?        R    12:54   0:00  \_ bash -c hostname
root        3126  0.0  0.0 1228744 3660 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3125  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3124  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3114  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.5  7.4 1539060 290844 ?      Ssl  12:26   1:16 cilium-agent --config-dir=/tmp/cilium/config-map
root         397  0.2  0.2 1229744 8812 ?        Sl   12:26   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
