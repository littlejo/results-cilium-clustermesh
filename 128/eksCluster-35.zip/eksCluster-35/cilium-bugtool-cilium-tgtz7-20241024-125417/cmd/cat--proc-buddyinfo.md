Node 0, zone      DMA     66    127     42     27      3      9     10      2      2      2     40 
Node 0, zone   Normal    155      2      1      1     10      5      4      8      1      3      7 
