Endpoint ID: 550
Path: /sys/fs/bpf/tc/globals/cilium_policy_00550

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 715
Path: /sys/fs/bpf/tc/globals/cilium_policy_00715

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6098808   60362     0        
Allow    Ingress     1          ANY          NONE         disabled    5090182   53614     0        
Allow    Egress      0          ANY          NONE         disabled    5917825   59328     0        


Endpoint ID: 1818
Path: /sys/fs/bpf/tc/globals/cilium_policy_01818

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    380564   4439      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2309
Path: /sys/fs/bpf/tc/globals/cilium_policy_02309

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2918     28        0        
Allow    Ingress     1          ANY          NONE         disabled    161290   1851      0        
Allow    Egress      0          ANY          NONE         disabled    20353    227       0        


Endpoint ID: 3192
Path: /sys/fs/bpf/tc/globals/cilium_policy_03192

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3215
Path: /sys/fs/bpf/tc/globals/cilium_policy_03215

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3389
Path: /sys/fs/bpf/tc/globals/cilium_policy_03389

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6227586   76955     0        
Allow    Ingress     1          ANY          NONE         disabled    63640     766       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3944
Path: /sys/fs/bpf/tc/globals/cilium_policy_03944

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2978     32        0        
Allow    Ingress     1          ANY          NONE         disabled    161488   1854      0        
Allow    Egress      0          ANY          NONE         disabled    21736    245       0        


