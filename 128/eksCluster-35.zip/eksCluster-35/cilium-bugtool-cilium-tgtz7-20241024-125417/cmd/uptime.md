 12:54:18 up 56 min,  0 users,  load average: 0.57, 0.44, 0.28
