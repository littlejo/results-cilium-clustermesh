KEY             VALUE
AgentLiveness   1923944609644
UTimeOffset     3378462056640625
