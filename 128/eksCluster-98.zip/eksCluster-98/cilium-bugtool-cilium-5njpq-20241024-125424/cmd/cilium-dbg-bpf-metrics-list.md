REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     134590    10908439    677    bpf_overlay.c
Interface                   INGRESS     665150    246210583   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      135289    10965026    53     encap.h
Success                     EGRESS      142996    19351994    1308   bpf_lxc.c
Success                     EGRESS      58009     4705907     1694   bpf_host.c
Success                     EGRESS      596       156261      86     l3.h
Success                     INGRESS     166359    18919680    86     l3.h
Success                     INGRESS     244167    25320943    235    trace.h
Unsupported L3 protocol     EGRESS      71        5338        1492   bpf_lxc.c
