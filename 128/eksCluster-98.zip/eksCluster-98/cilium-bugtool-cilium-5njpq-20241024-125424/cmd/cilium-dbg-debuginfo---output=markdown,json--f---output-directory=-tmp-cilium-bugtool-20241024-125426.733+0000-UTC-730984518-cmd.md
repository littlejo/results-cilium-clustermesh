markdown output at /tmp/cilium-bugtool-20241024-125426.733+0000-UTC-730984518/cmd/cilium-debuginfo-20241024-125457.3+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125426.733+0000-UTC-730984518/cmd/cilium-debuginfo-20241024-125457.3+0000-UTC.json
