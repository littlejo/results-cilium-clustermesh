Endpoint ID: 146
Path: /sys/fs/bpf/tc/globals/cilium_policy_00146

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 323
Path: /sys/fs/bpf/tc/globals/cilium_policy_00323

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6083267   59980     0        
Allow    Ingress     1          ANY          NONE         disabled    4963710   52122     0        
Allow    Egress      0          ANY          NONE         disabled    5767422   58164     0        


Endpoint ID: 799
Path: /sys/fs/bpf/tc/globals/cilium_policy_00799

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    381206   4450      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 820
Path: /sys/fs/bpf/tc/globals/cilium_policy_00820

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1055
Path: /sys/fs/bpf/tc/globals/cilium_policy_01055

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1497
Path: /sys/fs/bpf/tc/globals/cilium_policy_01497

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2962     30        0        
Allow    Ingress     1          ANY          NONE         disabled    131771   1507      0        
Allow    Egress      0          ANY          NONE         disabled    18161    199       0        


Endpoint ID: 1876
Path: /sys/fs/bpf/tc/globals/cilium_policy_01876

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6250196   77276     0        
Allow    Ingress     1          ANY          NONE         disabled    64502     780       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3228
Path: /sys/fs/bpf/tc/globals/cilium_policy_03228

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2934     30        0        
Allow    Ingress     1          ANY          NONE         disabled    132222   1518      0        
Allow    Egress      0          ANY          NONE         disabled    19067    211       0        


