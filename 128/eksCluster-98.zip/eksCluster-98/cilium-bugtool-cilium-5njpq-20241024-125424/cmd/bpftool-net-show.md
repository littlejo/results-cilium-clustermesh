xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 550
ens6(5) clsact/ingress cil_from_netdev-ens6 id 561
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 537
cilium_host(7) clsact/egress cil_from_host-cilium_host id 542
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 565
lxc98b8bb3d1260(12) clsact/ingress cil_from_container-lxc98b8bb3d1260 id 524
lxcbde9955eb3b5(14) clsact/ingress cil_from_container-lxcbde9955eb3b5 id 581
lxcaae2c2d160be(18) clsact/ingress cil_from_container-lxcaae2c2d160be id 640
lxc01f2899fc8a5(20) clsact/ingress cil_from_container-lxc01f2899fc8a5 id 3363
lxc2d46409e1d51(22) clsact/ingress cil_from_container-lxc2d46409e1d51 id 3305
lxc611e89d2fc5e(24) clsact/ingress cil_from_container-lxc611e89d2fc5e id 3368

flow_dissector:

netfilter:

