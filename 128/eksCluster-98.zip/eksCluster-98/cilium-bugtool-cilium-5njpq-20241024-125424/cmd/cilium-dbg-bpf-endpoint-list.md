IP ADDRESS         LOCAL ENDPOINT INFO
10.98.0.176:0      id=323   sec_id=6513120 flags=0x0000 ifindex=18  mac=22:BC:A1:A2:55:6C nodemac=EE:E3:49:A0:2A:27   
172.31.181.219:0   (localhost)                                                                                        
172.31.148.120:0   (localhost)                                                                                        
10.98.0.13:0       id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48   
10.98.0.73:0       (localhost)                                                                                        
10.98.0.222:0      id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08   
10.98.0.183:0      id=1497  sec_id=6504850 flags=0x0000 ifindex=12  mac=96:89:35:3B:AD:37 nodemac=26:C0:70:72:8E:0A   
10.98.0.155:0      id=1876  sec_id=4     flags=0x0000 ifindex=10  mac=26:61:F9:DD:A4:9F nodemac=3A:26:28:91:6E:2F     
10.98.0.91:0       id=3228  sec_id=6504850 flags=0x0000 ifindex=14  mac=52:4F:19:01:F9:23 nodemac=BA:CA:7C:C5:FC:B0   
10.98.0.235:0      id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C   
