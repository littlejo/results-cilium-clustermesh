Node 0, zone      DMA      7    109     51     44     18      8     27      9      4      4     40 
Node 0, zone   Normal     41      8      8      3     14     10      1      8      5      3      6 
