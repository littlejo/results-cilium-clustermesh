key: 92 00 00 00  value: 24 0d 00 00
key: 43 01 00 00  value: 89 02 00 00
key: 1f 03 00 00  value: e8 0c 00 00
key: 34 03 00 00  value: 19 0d 00 00
key: d9 05 00 00  value: 16 02 00 00
key: 54 07 00 00  value: 3d 02 00 00
key: 9c 0c 00 00  value: 44 02 00 00
Found 7 elements
