32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:56+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:56+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:57+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:57+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:57+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:57+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:00+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
482: sched_cls  name tail_handle_ipv4  tag 981e91a105ce9fdc  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
483: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
513: sched_cls  name tail_ipv4_ct_ingress  tag 18e04f6cfcbef0c8  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 163
514: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 164
521: sched_cls  name tail_ipv4_to_endpoint  tag 5328cee69e7e3995  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 167
522: sched_cls  name tail_ipv4_ct_egress  tag 890eb39817d8a207  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 172
523: sched_cls  name tail_handle_ipv4  tag 44e0be5665f05c9c  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 173
524: sched_cls  name cil_from_container  tag 35b44e9be103cd49  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 174
525: sched_cls  name tail_handle_arp  tag 33c6f9869b203ba0  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 175
528: sched_cls  name tail_handle_ipv4_cont  tag 7f57a3fe11c5d28c  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 177
529: sched_cls  name __send_drop_notify  tag d2beb2e0f075a7be  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
534: sched_cls  name handle_policy  tag 4a2819969a1ab4fa  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 180
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 185
537: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 188
538: sched_cls  name __send_drop_notify  tag a061d0c31f94456c  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
539: sched_cls  name tail_handle_ipv4_from_host  tag 4ac6885d71e122e4  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 190
540: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 191
542: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 193
543: sched_cls  name __send_drop_notify  tag a061d0c31f94456c  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
544: sched_cls  name tail_handle_ipv4_from_host  tag 4ac6885d71e122e4  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 196
545: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 198
549: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
550: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 204
554: sched_cls  name __send_drop_notify  tag a061d0c31f94456c  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 208
555: sched_cls  name tail_handle_ipv4_from_host  tag 4ac6885d71e122e4  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
557: sched_cls  name tail_handle_ipv4_cont  tag a7c5c9a777f0ef9b  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 197
558: sched_cls  name __send_drop_notify  tag a061d0c31f94456c  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
559: sched_cls  name tail_handle_ipv4_from_host  tag 4ac6885d71e122e4  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 213
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 214
561: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 215
565: sched_cls  name cil_from_container  tag d3949ea11d4d1b24  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 221
566: sched_cls  name tail_ipv4_ct_egress  tag 890eb39817d8a207  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 217
568: sched_cls  name tail_handle_ipv4  tag 64ee39b6e046f2e7  gpl
	loaded_at 2024-10-24T12:31:37+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 222
569: sched_cls  name tail_handle_arp  tag cb3d74fb98701ae9  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 224
570: sched_cls  name tail_ipv4_to_endpoint  tag 7b5fe1bb51375b32  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 225
571: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 227
572: sched_cls  name tail_handle_ipv4  tag 485f555f0badee64  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 226
573: sched_cls  name handle_policy  tag 8ad3d50563a2f6db  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 228
574: sched_cls  name tail_handle_arp  tag a3e4fea38ad486d1  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 229
575: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 230
576: sched_cls  name __send_drop_notify  tag f95babdb8f5ce14c  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 231
577: sched_cls  name tail_handle_ipv4_cont  tag fda5b04ddc92c671  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 232
579: sched_cls  name tail_ipv4_ct_ingress  tag 44cdbe8c5e1d2ea0  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 235
580: sched_cls  name handle_policy  tag 97113a09ade96c2e  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 233
581: sched_cls  name cil_from_container  tag 5bedc1972fce271f  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 236
582: sched_cls  name tail_ipv4_to_endpoint  tag 9ccc6cb8f2ad07ec  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 237
583: sched_cls  name tail_ipv4_ct_ingress  tag 732f6521d19edfea  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 238
584: sched_cls  name __send_drop_notify  tag 03003ff455c73340  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name cil_from_container  tag a04f3d752dfac2bf  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 253
641: sched_cls  name tail_handle_ipv4  tag f62047d2d85ccd74  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 254
642: sched_cls  name tail_ipv4_to_endpoint  tag 63f0c5ae5f5c4a75  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 255
643: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 256
645: sched_cls  name tail_ipv4_ct_egress  tag 8fad0b2930c53f66  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 258
646: sched_cls  name tail_ipv4_ct_ingress  tag 8c5809c4182a2c6d  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 259
647: sched_cls  name __send_drop_notify  tag 933bf8c93489e4dd  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 260
648: sched_cls  name tail_handle_ipv4_cont  tag e2f2d6da7a43a51a  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 261
649: sched_cls  name handle_policy  tag 49807aa38cfff366  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 262
650: sched_cls  name tail_handle_arp  tag d7eb1498c9ac4a00  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
712: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
715: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
720: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
723: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
724: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
727: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
728: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
731: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
732: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
735: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
736: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
739: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3292: sched_cls  name __send_drop_notify  tag 9c4a16bcaa7b7558  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3085
3293: sched_cls  name tail_handle_arp  tag d254a58086083c11  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,632
	btf_id 3086
3294: sched_cls  name tail_handle_ipv4_cont  tag f61a993f60d7fd31  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,631,41,154,82,83,39,76,74,77,632,40,37,38,81
	btf_id 3087
3297: sched_cls  name tail_ipv4_to_endpoint  tag 6981e2c4aeaae717  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,631,41,82,83,80,154,39,632,40,37,38
	btf_id 3089
3298: sched_cls  name tail_ipv4_ct_egress  tag 56bfe978e738810f  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3093
3300: sched_cls  name tail_ipv4_ct_ingress  tag 342863192771fc79  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3094
3304: sched_cls  name handle_policy  tag 06668f84554d88a1  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,632,82,83,631,41,80,154,39,84,75,40,37,38
	btf_id 3096
3305: sched_cls  name cil_from_container  tag c15bec8937286708  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 632,76
	btf_id 3100
3306: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,632
	btf_id 3101
3310: sched_cls  name tail_handle_ipv4  tag 1323cf7b7ea8d788  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,632
	btf_id 3102
3347: sched_cls  name __send_drop_notify  tag 275bdce8b8ce5a89  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3145
3348: sched_cls  name tail_handle_arp  tag a9c23d217a8ad793  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,644
	btf_id 3147
3350: sched_cls  name tail_handle_arp  tag 17a8facf31a48414  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,642
	btf_id 3149
3351: sched_cls  name tail_handle_ipv4_cont  tag f7c1fd6950f29275  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,641,41,157,82,83,39,76,74,77,642,40,37,38,81
	btf_id 3151
3352: sched_cls  name tail_ipv4_ct_ingress  tag d11fd23dfbee88f5  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3152
3353: sched_cls  name handle_policy  tag ce78adfb153ebf14  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,644,82,83,643,41,80,151,39,84,75,40,37,38
	btf_id 3150
3354: sched_cls  name tail_handle_ipv4  tag 2a702fe6d21fabd9  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,642
	btf_id 3153
3355: sched_cls  name tail_ipv4_ct_ingress  tag 583d7483f28e998b  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3154
3356: sched_cls  name tail_ipv4_ct_egress  tag ace69f3fdeb3ab0d  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3155
3357: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,644
	btf_id 3156
3358: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,642
	btf_id 3157
3359: sched_cls  name __send_drop_notify  tag 3dc3550a05cb0007  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3158
3360: sched_cls  name tail_handle_ipv4_cont  tag 82f8abdabe9a65ea  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,643,41,151,82,83,39,76,74,77,644,40,37,38,81
	btf_id 3160
3361: sched_cls  name tail_ipv4_ct_egress  tag aa4dd02c2bc4b44d  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3161
3363: sched_cls  name cil_from_container  tag df55b93b722439e2  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 644,76
	btf_id 3163
3364: sched_cls  name handle_policy  tag e79fa8a56e1c13d7  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,642,82,83,641,41,80,157,39,84,75,40,37,38
	btf_id 3159
3365: sched_cls  name tail_ipv4_to_endpoint  tag 10769f3ccfe030c0  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,643,41,82,83,80,151,39,644,40,37,38
	btf_id 3164
3366: sched_cls  name tail_handle_ipv4  tag cd5cef93a3a23c83  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,644
	btf_id 3166
3367: sched_cls  name tail_ipv4_to_endpoint  tag e9e59b7c81a92d45  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,641,41,82,83,80,157,39,642,40,37,38
	btf_id 3165
3368: sched_cls  name cil_from_container  tag d5cd4a50ae7d9885  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 642,76
	btf_id 3167
