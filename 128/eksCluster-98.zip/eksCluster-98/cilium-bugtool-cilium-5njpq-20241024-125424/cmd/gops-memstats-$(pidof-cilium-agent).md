alloc: 97.77MB (102524056 bytes)
total-alloc: 3.08GB (3303012288 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74935853
frees: 73985589
heap-alloc: 97.77MB (102524056 bytes)
heap-sys: 172.88MB (181280768 bytes)
heap-idle: 45.41MB (47611904 bytes)
heap-in-use: 127.48MB (133668864 bytes)
heap-released: 5.58MB (5849088 bytes)
heap-objects: 950264
stack-in-use: 35.09MB (36798464 bytes)
stack-sys: 35.09MB (36798464 bytes)
stack-mspan-inuse: 2.13MB (2230400 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 940.50KB (963073 bytes)
gc-sys: 5.53MB (5799128 bytes)
next-gc: when heap-alloc >= 152.04MB (159425816 bytes)
last-gc: 2024-10-24 12:54:32.676540652 +0000 UTC
gc-pause-total: 11.988061ms
gc-pause: 1527589
gc-pause-end: 1729774472676540652
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0005852494198062767
enable-gc: true
debug-gc: false
