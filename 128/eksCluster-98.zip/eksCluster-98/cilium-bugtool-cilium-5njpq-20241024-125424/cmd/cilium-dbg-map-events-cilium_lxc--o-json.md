{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.439Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.699Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.725Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.768Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.769Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.815Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.400Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.404Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.450Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.465Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.485Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.710Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.738Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.779Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.810Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.824Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.413Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.418Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.523Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.529Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.570Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.740Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.747Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.799Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.841Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.856Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.468Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.484Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.531Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.533Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.570Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.787Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.795Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.849Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.865Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.904Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.478Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.485Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.514Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.541Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.562Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.584Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.599Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.894Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.902Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.959Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.982Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.998Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.411Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.413Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.461Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.475Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.499Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.719Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.733Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.798Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.820Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.847Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.232Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.234Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.283Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.290Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.319Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.561Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.566Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.626Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.629Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.694Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.079Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.080Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.131Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.141Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.167Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.432Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.435Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.494Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.513Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.537Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.941Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.971Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.996Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.017Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.041Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.059Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.288Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.298Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.347Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.385Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.408Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.776Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.813Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.825Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.866Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.866Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.874Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.149Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.178Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.195Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.234Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.244Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.621Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.622Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.671Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.673Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.708Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.946Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.954Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.002Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.035Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.068Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.442Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.449Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.506Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.523Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.545Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.719Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.727Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.745Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.777Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.540Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.542Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.574Z",
  "value": "id=799   sec_id=6498448 flags=0x0000 ifindex=22  mac=06:8E:C1:02:BE:59 nodemac=6E:D2:E0:E5:0E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.590Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.613Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.906Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.919Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.644Z",
  "value": "id=820   sec_id=6502847 flags=0x0000 ifindex=20  mac=66:31:21:31:08:38 nodemac=1A:89:4F:8F:2C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.649Z",
  "value": "id=146   sec_id=6493899 flags=0x0000 ifindex=24  mac=A6:0C:C3:C5:48:FE nodemac=62:E4:3B:03:B3:08"
}

