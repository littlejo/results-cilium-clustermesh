CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod017cbf89_54c1_4208_a8fa_95875fa2486b.slice/cri-containerd-a2e3bcfcbc03a37de3b4e999a7a5b11c632f2842e112dc854da24c0ddca79fac.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod017cbf89_54c1_4208_a8fa_95875fa2486b.slice/cri-containerd-e9a66fe33505712565f8052ad5fe3fe00bc13b1445ad6a2a6f81a41585dba9b1.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod970faaa8_e050_4645_b2ff_6bffa335d943.slice/cri-containerd-24089b5a86c3e6768e84124e0b166ca640afab2de6dad42b568a11eee5236d22.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod970faaa8_e050_4645_b2ff_6bffa335d943.slice/cri-containerd-8c1d43ae0cecb425e2ad766f98cd61f4c9b3f597ec526235438d0a9f3b871cf5.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfea73e14_e96c_41c7_849b_90f52bd52480.slice/cri-containerd-1932956a5041292d7940b4e09d5880cc3767127649528cd31f579e76f1c69ecb.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfea73e14_e96c_41c7_849b_90f52bd52480.slice/cri-containerd-d26d7a50f84027375645bbd1ac2d4ffb6358df692845e605eef5d58365fa0580.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda55836c5_c7f4_48fd_8fa9_c77feac87f58.slice/cri-containerd-bf75e46b34c4e5d16088ed24c733d4b594e0c903a8b0f77122127ff42f2e1685.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda55836c5_c7f4_48fd_8fa9_c77feac87f58.slice/cri-containerd-114599f2e55a5637d1a29be85be80bc16617f934aee304765f19d09a61233010.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1678f016_fa82_47ea_9e99_16e3db7d64ef.slice/cri-containerd-c1acc6bc07101325af6b1e5f385e759e1242c557ed98aaed91afdedbb1636ae2.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1678f016_fa82_47ea_9e99_16e3db7d64ef.slice/cri-containerd-dd956a20d243e10cf184a3a67ad5889d02e097b1978f012bdfd650cdf8c503ef.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ae618a1_2917_446c_9f33_ab0a95490a2b.slice/cri-containerd-a2dba338a5822d571a17a6651982badab9e22fa016b3b629f7b30e84825dd41c.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ae618a1_2917_446c_9f33_ab0a95490a2b.slice/cri-containerd-89b02b43700e193f0a3654c2be8b0d2a0e08da9a24b67e0c201641a7b4d654df.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ae618a1_2917_446c_9f33_ab0a95490a2b.slice/cri-containerd-b76da720a96d4892f18bc3ae54c4679d3bcea6bd1380e07dcb53ddf0844e941e.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa08ee60_caf2_454f_8021_b0834a16175a.slice/cri-containerd-1238b16c6c747d0c5af39f6cfd4e340215afd5e4485e0a1f9fdba0687f6a7c2a.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa08ee60_caf2_454f_8021_b0834a16175a.slice/cri-containerd-68bfb19e5ee0c1657e003f9ced7e8bbab0e1d29681e2fe775aa585cfef29d730.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4fbd9275_914d_4aa4_89cc_70d3cde34e8b.slice/cri-containerd-4daba0ded47c44f37a279113f9d54869f06baa0946c9f1dd3d3d7ffd554a8240.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4fbd9275_914d_4aa4_89cc_70d3cde34e8b.slice/cri-containerd-1e08a88e90fb694928fc2262f206fc70f507fdd01cdee29fe33e457f2594a77b.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb467eef_d185_4c06_be86_c29b4ec81dcd.slice/cri-containerd-a7ec6c97d29e5f0d29b774bf8a33b163f61db1c60662c12a08809eefb4bb36d9.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb467eef_d185_4c06_be86_c29b4ec81dcd.slice/cri-containerd-3368e5fa236a4338db7ba288888c29f2778a6cd2e612c278eb929b56d705fa9f.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb467eef_d185_4c06_be86_c29b4ec81dcd.slice/cri-containerd-24a1af8a261e7ead8dcf9b50ee5a160d4310d94d162349e2b7d99144312251e1.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb467eef_d185_4c06_be86_c29b4ec81dcd.slice/cri-containerd-6ddbffdca13466b67910936ca4133d86a641df92f24f938063fe17df64abbc48.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17f3d284_2ad6_43f7_afa6_3a966ec4bb07.slice/cri-containerd-1d4d9ad099a4bdcbaaf1f15f3079f7c14279a37f83a88af795c68e1fdf41788b.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17f3d284_2ad6_43f7_afa6_3a966ec4bb07.slice/cri-containerd-a3527d78d3b182221b3f550067f7302d422d31bb52c8649b702d13b5f124896d.scope
    94       cgroup_device   multi                                          
