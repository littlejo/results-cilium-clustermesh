[
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa08ee60_caf2_454f_8021_b0834a16175a.slice/cri-containerd-68bfb19e5ee0c1657e003f9ced7e8bbab0e1d29681e2fe775aa585cfef29d730.scope"
      }
    ],
    "ips": [
      "10.98.0.222"
    ],
    "name": "client2-57cf4468f-knmn9",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda55836c5_c7f4_48fd_8fa9_c77feac87f58.slice/cri-containerd-114599f2e55a5637d1a29be85be80bc16617f934aee304765f19d09a61233010.scope"
      }
    ],
    "ips": [
      "10.98.0.91"
    ],
    "name": "coredns-cc6ccd49c-mq248",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4fbd9275_914d_4aa4_89cc_70d3cde34e8b.slice/cri-containerd-1e08a88e90fb694928fc2262f206fc70f507fdd01cdee29fe33e457f2594a77b.scope"
      }
    ],
    "ips": [
      "10.98.0.235"
    ],
    "name": "client-974f6c69d-z7kmb",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ae618a1_2917_446c_9f33_ab0a95490a2b.slice/cri-containerd-89b02b43700e193f0a3654c2be8b0d2a0e08da9a24b67e0c201641a7b4d654df.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ae618a1_2917_446c_9f33_ab0a95490a2b.slice/cri-containerd-a2dba338a5822d571a17a6651982badab9e22fa016b3b629f7b30e84825dd41c.scope"
      }
    ],
    "ips": [
      "10.98.0.13"
    ],
    "name": "echo-same-node-86d9cc975c-zx9l6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb467eef_d185_4c06_be86_c29b4ec81dcd.slice/cri-containerd-a7ec6c97d29e5f0d29b774bf8a33b163f61db1c60662c12a08809eefb4bb36d9.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb467eef_d185_4c06_be86_c29b4ec81dcd.slice/cri-containerd-6ddbffdca13466b67910936ca4133d86a641df92f24f938063fe17df64abbc48.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb467eef_d185_4c06_be86_c29b4ec81dcd.slice/cri-containerd-3368e5fa236a4338db7ba288888c29f2778a6cd2e612c278eb929b56d705fa9f.scope"
      }
    ],
    "ips": [
      "10.98.0.176"
    ],
    "name": "clustermesh-apiserver-57c86cfd65-66lqb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod017cbf89_54c1_4208_a8fa_95875fa2486b.slice/cri-containerd-a2e3bcfcbc03a37de3b4e999a7a5b11c632f2842e112dc854da24c0ddca79fac.scope"
      }
    ],
    "ips": [
      "10.98.0.183"
    ],
    "name": "coredns-cc6ccd49c-kmzfl",
    "namespace": "kube-system"
  }
]

