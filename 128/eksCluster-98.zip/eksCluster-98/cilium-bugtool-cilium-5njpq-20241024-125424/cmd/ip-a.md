1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b1:9f:42:c5:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.148.120/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3515sec preferred_lft 3515sec
    inet6 fe80::4b1:9fff:fe42:c57b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c5:00:c8:f2:df brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.181.219/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4c5:ff:fec8:f2df/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:da:f0:d0:7e:7a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::88da:f0ff:fed0:7e7a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:e5:fd:88:ff:00 brd ff:ff:ff:ff:ff:ff
    inet 10.98.0.73/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8ce5:fdff:fe88:ff00/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ca:b3:08:8f:85:f6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c8b3:8ff:fe8f:85f6/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:26:28:91:6e:2f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3826:28ff:fe91:6e2f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc98b8bb3d1260@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:c0:70:72:8e:0a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::24c0:70ff:fe72:8e0a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcbde9955eb3b5@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:ca:7c:c5:fc:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b8ca:7cff:fec5:fcb0/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcaae2c2d160be@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:e3:49:a0:2a:27 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ece3:49ff:fea0:2a27/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc01f2899fc8a5@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:89:4f:8f:2c:4c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::1889:4fff:fe8f:2c4c/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc2d46409e1d51@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:d2:e0:e5:0e:48 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::6cd2:e0ff:fee5:e48/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc611e89d2fc5e@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:e4:3b:03:b3:08 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::60e4:3bff:fe03:b308/64 scope link 
       valid_lft forever preferred_lft forever
