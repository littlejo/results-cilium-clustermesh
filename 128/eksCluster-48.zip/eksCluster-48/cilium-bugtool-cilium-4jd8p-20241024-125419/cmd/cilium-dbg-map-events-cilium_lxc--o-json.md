{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.206Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.753Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.773Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.803Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.821Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.852Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.070Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.073Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.130Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.150Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.186Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.771Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.788Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.836Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.845Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.876Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.086Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.113Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.223Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.254Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.296Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.795Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.797Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.877Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.880Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.926Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.934Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.979Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.165Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.183Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.221Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.250Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.276Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.875Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.882Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.905Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.925Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.959Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.989Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.999Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.271Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.291Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.363Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.374Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.405Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.728Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.771Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.771Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.828Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.841Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.874Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.082Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.086Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.151Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.162Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.196Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.584Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.616Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.623Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.666Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.673Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.703Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.950Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.951Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.049Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.051Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.132Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.491Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.534Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.540Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.582Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.584Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.618Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.839Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.844Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.899Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.918Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.955Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.306Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.341Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.342Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.390Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.414Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.427Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.630Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.663Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.700Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.739Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.747Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.170Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.207Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.241Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.275Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.295Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.478Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.516Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.540Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.574Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.588Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.902Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.906Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.953Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.963Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.993Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.214Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.220Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.261Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.286Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.321Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.646Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.646Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.693Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.708Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.733Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.966Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.969Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.983Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.989Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.019Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.673Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.677Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.719Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.730Z",
  "value": "id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.758Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.017Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.021Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.727Z",
  "value": "id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.735Z",
  "value": "id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89"
}

