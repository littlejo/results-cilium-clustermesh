IP ADDRESS        LOCAL ENDPOINT INFO
10.48.0.226:0     id=3051  sec_id=3235721 flags=0x0000 ifindex=24  mac=9E:F6:F5:2A:78:F9 nodemac=86:A9:04:D1:CC:9D   
10.48.0.23:0      id=463   sec_id=3214228 flags=0x0000 ifindex=20  mac=0E:B1:53:EA:0F:F1 nodemac=82:2E:BC:E6:85:9B   
10.48.0.218:0     id=466   sec_id=3259750 flags=0x0000 ifindex=14  mac=7A:8A:8C:AA:3F:90 nodemac=96:C7:C3:4B:51:73   
10.48.0.27:0      id=319   sec_id=4     flags=0x0000 ifindex=10  mac=62:CA:61:D7:73:11 nodemac=D6:95:4B:EF:14:17     
172.31.155.95:0   (localhost)                                                                                        
10.48.0.115:0     (localhost)                                                                                        
10.48.0.141:0     id=3712  sec_id=3259750 flags=0x0000 ifindex=12  mac=B2:C2:F6:8A:4C:31 nodemac=6A:1B:C8:34:8A:3D   
10.48.0.13:0      id=1018  sec_id=3264841 flags=0x0000 ifindex=18  mac=4A:29:33:6A:1B:84 nodemac=D2:BA:12:F1:3B:B0   
10.48.0.167:0     id=2682  sec_id=3238271 flags=0x0000 ifindex=22  mac=72:67:81:6D:3D:06 nodemac=FA:E5:76:6E:22:89   
172.31.162.33:0   (localhost)                                                                                        
