29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:38+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:38+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:39+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:43+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
115: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
118: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
123: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
126: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:27:53+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
479: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:27:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
480: sched_cls  name tail_handle_ipv4  tag 1b1f8586f40ed9d1  gpl
	loaded_at 2024-10-24T12:27:53+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:27:53+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
504: sched_cls  name tail_handle_ipv4_cont  tag 28b5cc8da5a99a44  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,106,41,101,82,83,39,76,74,77,107,40,37,38,81
	btf_id 153
505: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,106,84
	btf_id 154
506: sched_cls  name cil_from_container  tag 29a335e58d758404  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,76
	btf_id 155
507: sched_cls  name __send_drop_notify  tag d18a5724a89b0833  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 156
508: sched_cls  name tail_ipv4_ct_ingress  tag b14851f9f1af66c1  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,106,84
	btf_id 157
510: sched_cls  name handle_policy  tag 696b4073240aabe2  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,107,82,83,106,41,80,101,39,84,75,40,37,38
	btf_id 159
511: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 160
512: sched_cls  name tail_handle_ipv4  tag af232a4644a5e204  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 161
513: sched_cls  name tail_ipv4_to_endpoint  tag 2a16ab4cbdf7b0f9  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,106,41,82,83,80,101,39,107,40,37,38
	btf_id 162
514: sched_cls  name tail_handle_arp  tag ab230601fe2763ca  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 163
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 166
517: sched_cls  name tail_ipv4_ct_egress  tag 54598b26f076449c  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,108,84
	btf_id 167
518: sched_cls  name tail_handle_ipv4  tag 235f7f4568e33793  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 168
519: sched_cls  name tail_ipv4_to_endpoint  tag 3adbd0a32ea99b55  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,100,39,109,40,37,38
	btf_id 169
520: sched_cls  name tail_handle_arp  tag 47ffc328ecf8632e  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 170
521: sched_cls  name handle_policy  tag 0dedb28b317a2bd7  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,108,41,80,100,39,84,75,40,37,38
	btf_id 171
522: sched_cls  name tail_ipv4_ct_ingress  tag 2df3945250010d09  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,108,84
	btf_id 172
523: sched_cls  name cil_from_container  tag 424c80ec702bfd7e  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 173
524: sched_cls  name __send_drop_notify  tag 1f49e91a28ae116e  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
525: sched_cls  name tail_handle_ipv4_cont  tag 8e59ceebdd3a8c46  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 175
526: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
529: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
530: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
533: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
534: sched_cls  name tail_handle_ipv4_from_host  tag 9b348e69919e2786  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,112
	btf_id 177
535: sched_cls  name __send_drop_notify  tag 755f161dd679ddcf  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
536: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,112
	btf_id 179
538: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,112
	btf_id 181
540: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 183
543: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 187
544: sched_cls  name tail_handle_ipv4_from_host  tag 9b348e69919e2786  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,115
	btf_id 188
545: sched_cls  name __send_drop_notify  tag 755f161dd679ddcf  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
546: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,115
	btf_id 190
550: sched_cls  name tail_handle_ipv4_from_host  tag 9b348e69919e2786  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,116
	btf_id 195
551: sched_cls  name __send_drop_notify  tag 755f161dd679ddcf  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 196
552: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,116
	btf_id 197
553: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,116,75
	btf_id 198
558: sched_cls  name tail_handle_ipv4_from_host  tag 9b348e69919e2786  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 204
559: sched_cls  name __send_drop_notify  tag 755f161dd679ddcf  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 206
561: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,118,75
	btf_id 207
562: sched_cls  name cil_from_container  tag db9f894f6885efd2  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 122,76
	btf_id 209
563: sched_cls  name tail_ipv4_to_endpoint  tag 96db872e8eccf7fe  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,121,41,82,83,80,120,39,122,40,37,38
	btf_id 210
564: sched_cls  name __send_drop_notify  tag 85eb77e4bfe1404f  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
565: sched_cls  name tail_handle_ipv4  tag f7cb251a87994174  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,122
	btf_id 212
566: sched_cls  name tail_handle_ipv4_cont  tag 5818949bde8da544  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,121,41,120,82,83,39,76,74,77,122,40,37,38,81
	btf_id 213
567: sched_cls  name handle_policy  tag 8a1fb0064db4247a  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,122,82,83,121,41,80,120,39,84,75,40,37,38
	btf_id 214
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,122
	btf_id 216
570: sched_cls  name tail_ipv4_ct_ingress  tag 47bea0e8e455b4d6  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,122,82,83,121,84
	btf_id 217
571: sched_cls  name tail_handle_arp  tag 4df3213581a3081c  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,122
	btf_id 218
572: sched_cls  name tail_ipv4_ct_egress  tag 54598b26f076449c  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,122,82,83,121,84
	btf_id 219
573: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
576: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
577: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
580: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: sched_cls  name tail_handle_ipv4_cont  tag 6d7356188a1c8e89  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 233
621: sched_cls  name tail_ipv4_to_endpoint  tag 5f28e310e774eec7  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 234
622: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 235
623: sched_cls  name tail_handle_arp  tag 858a6f3ab334527b  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 236
624: sched_cls  name handle_policy  tag d058cacb2ee20733  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 237
625: sched_cls  name tail_ipv4_ct_egress  tag 664b57a9508597f2  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 238
626: sched_cls  name tail_handle_ipv4  tag f4a14019471a70cc  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 239
627: sched_cls  name cil_from_container  tag afe8f3a0ffaa9ce4  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 240
628: sched_cls  name tail_ipv4_ct_ingress  tag dbc54e2e7d8bb52f  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 241
630: sched_cls  name __send_drop_notify  tag 44a8b2c37e5baa1e  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 243
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
681: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
684: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
685: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
688: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
700: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
703: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
712: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
715: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3283: sched_cls  name tail_handle_arp  tag a103e48a68977570  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3077
3284: sched_cls  name tail_ipv4_to_endpoint  tag 813939b3328687d4  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,145,39,627,40,37,38
	btf_id 3078
3285: sched_cls  name __send_drop_notify  tag 5c90a89f83923288  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3079
3286: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3080
3294: sched_cls  name tail_handle_ipv4  tag c854386b5e8c48bc  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3084
3295: sched_cls  name cil_from_container  tag 39878b18ba082d9e  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3091
3299: sched_cls  name handle_policy  tag e3258910a7225641  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,145,39,84,75,40,37,38
	btf_id 3092
3301: sched_cls  name tail_ipv4_ct_ingress  tag ec955ae986b64772  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3095
3303: sched_cls  name tail_ipv4_ct_egress  tag 1259e0a91684ba31  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3098
3304: sched_cls  name tail_handle_ipv4_cont  tag 56582a31da9cfd6d  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,145,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3101
3338: sched_cls  name tail_handle_arp  tag 53b060f7f462152c  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3138
3339: sched_cls  name tail_ipv4_ct_egress  tag 5fbe912492776128  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3140
3340: sched_cls  name tail_handle_ipv4  tag d0c0fd2f48feb57b  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,638
	btf_id 3139
3341: sched_cls  name tail_ipv4_ct_ingress  tag 3e6444e6c4b6ebab  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3141
3342: sched_cls  name tail_handle_ipv4_cont  tag bc3cd9dbdbd26c47  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,637,41,148,82,83,39,76,74,77,638,40,37,38,81
	btf_id 3142
3344: sched_cls  name tail_ipv4_to_endpoint  tag 9d219f5fd8c77a37  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,637,41,82,83,80,148,39,638,40,37,38
	btf_id 3144
3345: sched_cls  name tail_ipv4_to_endpoint  tag c2732b700a8bc857  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,153,39,640,40,37,38
	btf_id 3145
3346: sched_cls  name __send_drop_notify  tag f6759cc130bc7c5d  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3146
3347: sched_cls  name __send_drop_notify  tag 5f05b42afb4ec513  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3147
3348: sched_cls  name cil_from_container  tag fb2ce6b54e916d92  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,76
	btf_id 3148
3349: sched_cls  name cil_from_container  tag 7d4ae37092e66639  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3149
3350: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3150
3351: sched_cls  name handle_policy  tag ba3aaeb6df232081  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,638,82,83,637,41,80,148,39,84,75,40,37,38
	btf_id 3151
3352: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,638
	btf_id 3153
3353: sched_cls  name handle_policy  tag 929e68766ddbd46a  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,639,41,80,153,39,84,75,40,37,38
	btf_id 3152
3355: sched_cls  name tail_handle_ipv4  tag 56e87cbf4777f422  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3156
3356: sched_cls  name tail_handle_ipv4_cont  tag a510089f04b3969a  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,153,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3157
3357: sched_cls  name tail_ipv4_ct_ingress  tag e6b0e09ade69fa1d  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3155
3358: sched_cls  name tail_handle_arp  tag d831659250a3cb60  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,638
	btf_id 3158
3359: sched_cls  name tail_ipv4_ct_egress  tag 7010266829b2870e  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3159
