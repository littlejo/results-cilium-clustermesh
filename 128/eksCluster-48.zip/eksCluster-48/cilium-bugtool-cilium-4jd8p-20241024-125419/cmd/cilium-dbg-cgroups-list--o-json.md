[
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4189cf36_9c30_4411_ab4d_16eab6800d0a.slice/cri-containerd-244d42b46b6a6d57619cd8895a861d9758a2f6b6c605716500dba100e4c0a3ec.scope"
      }
    ],
    "ips": [
      "10.48.0.167"
    ],
    "name": "client-974f6c69d-n9hmm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8796e76_5072_481b_8767_dfc76bdaaba7.slice/cri-containerd-0acefe8f27212c714ce144872dad4eada0c7add5b8cc15f483c05648a1e4f8c0.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8796e76_5072_481b_8767_dfc76bdaaba7.slice/cri-containerd-02d975a2a19df3a61f908cca1c014ae7d0916d7308cb11c9c1666e48d41f5a96.scope"
      }
    ],
    "ips": [
      "10.48.0.23"
    ],
    "name": "echo-same-node-86d9cc975c-f58vm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7404,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod20995f77_fe8e_4cab_a8c4_89a6815acfba.slice/cri-containerd-4d60247262fdec50ab5e9350350eca8773b93c4af82a607c9c06b0bb2b233ac6.scope"
      }
    ],
    "ips": [
      "10.48.0.141"
    ],
    "name": "coredns-cc6ccd49c-kzvsn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50a8c657_e64e_499f_ad8f_acd0b7638b99.slice/cri-containerd-b787df4727afc4dedbd9c0ce6e7c2596e46c5720249f8e544f944b059b68fea3.scope"
      }
    ],
    "ips": [
      "10.48.0.218"
    ],
    "name": "coredns-cc6ccd49c-f7rrh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8972117f_ad6f_4607_848b_7934c7dade6c.slice/cri-containerd-24c3ec7d9ad03ba0428cf477f628ee9a6a7cd62c0c22454c6afeb2a58a5e0782.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8972117f_ad6f_4607_848b_7934c7dade6c.slice/cri-containerd-92e776b41f4522cb9daaa2ebe88b859cdc271339c2802adc8636e8812f6b7d84.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8972117f_ad6f_4607_848b_7934c7dade6c.slice/cri-containerd-5dffddb39659124f88ac78e20ecc250fba8003cc1d060865d2303220c1b12f0e.scope"
      }
    ],
    "ips": [
      "10.48.0.13"
    ],
    "name": "clustermesh-apiserver-56db46799c-rr9pz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98ccc51b_644d_47c5_82c9_5e9048aecc7b.slice/cri-containerd-d46720af6f2b0bbe1154ff4646fb251fdb508bc8e98d964702b64a12d6d99744.scope"
      }
    ],
    "ips": [
      "10.48.0.226"
    ],
    "name": "client2-57cf4468f-nh494",
    "namespace": "cilium-test-1"
  }
]

