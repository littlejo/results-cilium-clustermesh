Node 0, zone      DMA    284     36     11     56     22     12      4      2      1      2     42 
Node 0, zone   Normal    131     12      4      2     20      4      2      6      6      3      6 
