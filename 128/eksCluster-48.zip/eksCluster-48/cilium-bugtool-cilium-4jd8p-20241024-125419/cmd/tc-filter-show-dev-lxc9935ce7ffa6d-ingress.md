filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc9935ce7ffa6d direct-action not_in_hw id 562 tag db9f894f6885efd2 jited 
