alloc: 100.20MB (105063832 bytes)
total-alloc: 3.11GB (3343508312 bytes)
sys: 219.07MB (229713236 bytes)
lookups: 0
mallocs: 75561136
frees: 74607114
heap-alloc: 100.20MB (105063832 bytes)
heap-sys: 172.55MB (180928512 bytes)
heap-idle: 42.81MB (44892160 bytes)
heap-in-use: 129.73MB (136036352 bytes)
heap-released: 5.02MB (5259264 bytes)
heap-objects: 954022
stack-in-use: 35.41MB (37126144 bytes)
stack-sys: 35.41MB (37126144 bytes)
stack-mspan-inuse: 2.11MB (2211360 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 759.87KB (778105 bytes)
gc-sys: 5.51MB (5774384 bytes)
next-gc: when heap-alloc >= 153.90MB (161379800 bytes)
last-gc: 2024-10-24 12:54:26.600873399 +0000 UTC
gc-pause-total: 12.467629ms
gc-pause: 103968
gc-pause-end: 1729774466600873399
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005831272773289709
enable-gc: true
debug-gc: false
