1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c4:c7:70:f7:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.162.33/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3443sec preferred_lft 3443sec
    inet6 fe80::4c4:c7ff:fe70:f7d1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a4:9b:bf:96:99 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.155.95/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a4:9bff:febf:9699/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:da:8e:42:85:8a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::acda:8eff:fe42:858a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:d5:09:99:0e:f1 brd ff:ff:ff:ff:ff:ff
    inet 10.48.0.115/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::48d5:9ff:fe99:ef1/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6e:74:f8:17:d1:4f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c74:f8ff:fe17:d14f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:95:4b:ef:14:17 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d495:4bff:feef:1417/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc55999e127940@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:1b:c8:34:8a:3d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::681b:c8ff:fe34:8a3d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9935ce7ffa6d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:c7:c3:4b:51:73 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::94c7:c3ff:fe4b:5173/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcac4aded19fdd@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:ba:12:f1:3b:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d0ba:12ff:fef1:3bb0/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcabfee34cca79@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:2e:bc:e6:85:9b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::802e:bcff:fee6:859b/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc62dae4cbc435@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:e5:76:6e:22:89 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::f8e5:76ff:fe6e:2289/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcac8f5729fa51@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:a9:04:d1:cc:9d brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::84a9:4ff:fed1:cc9d/64 scope link 
       valid_lft forever preferred_lft forever
