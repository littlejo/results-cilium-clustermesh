key: 0a 00 00 00  value: 0a 30 00 da 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f a2 21 10 94 00 00  00 00 00 00
key: 0d 00 00 00  value: 0a 30 00 0d 09 4b 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 30 00 da 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 30 00 8d 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 30 00 8d 23 c1 00 00  00 00 00 00
key: 0e 00 00 00  value: 0a 30 00 17 1f 90 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 82 4e 01 bb 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f dd 91 01 bb 00 00  00 00 00 00
Found 9 elements
