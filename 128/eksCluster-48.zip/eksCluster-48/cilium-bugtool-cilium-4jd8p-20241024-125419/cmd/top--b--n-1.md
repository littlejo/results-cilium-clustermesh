top - 12:54:21 up 32 min,  0 users,  load average: 0.31, 0.46, 0.25
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 60.7 us, 21.4 sy,  0.0 ni, 17.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    270.5 free,   1069.4 used,   2496.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2585.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 294544  79104 S   6.7   7.5   1:04.81 cilium-+
   3237 root      20   0 1240432  16056  10832 S   6.7   0.4   0:00.03 cilium-+
    405 root      20   0 1229744  10044   3836 S   0.0   0.3   0:04.11 cilium-+
   3227 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
   3243 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3274 root      20   0    6576   2412   2084 R   0.0   0.1   0:00.00 top
   3293 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
