key: 3f 01 00 00  value: fe 01 00 00
key: cf 01 00 00  value: e3 0c 00 00
key: d2 01 00 00  value: 37 02 00 00
key: fa 03 00 00  value: 70 02 00 00
key: 7a 0a 00 00  value: 17 0d 00 00
key: eb 0b 00 00  value: 19 0d 00 00
key: 80 0e 00 00  value: 09 02 00 00
Found 7 elements
