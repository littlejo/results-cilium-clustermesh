CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod20995f77_fe8e_4cab_a8c4_89a6815acfba.slice/cri-containerd-0be5a687b7f9dd146f28e2f85a16f4b73f1edb03202190937c8928aebe6610ce.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod20995f77_fe8e_4cab_a8c4_89a6815acfba.slice/cri-containerd-4d60247262fdec50ab5e9350350eca8773b93c4af82a607c9c06b0bb2b233ac6.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2b4876b_62aa_456c_a652_3cd94b4391b5.slice/cri-containerd-2e0e6167246f54505481d1f0ac2c6c1b7976b653738bc88259e477b9144b861d.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2b4876b_62aa_456c_a652_3cd94b4391b5.slice/cri-containerd-4a99f6f1bbf60a393d3cde9417ca9dc246bf87c9b5692001b402eb99535a8649.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode03b1265_de72_4e0d_b26a_4b79d25da9c8.slice/cri-containerd-ded54f0884a39357e5d5b8ad63cb37064dbe838804fdd700d7b9b93b2b51f2f6.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode03b1265_de72_4e0d_b26a_4b79d25da9c8.slice/cri-containerd-eed6882880589523d3932b82b5ca09d6882b94a662b7ed99c079e3303bc15c50.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50a8c657_e64e_499f_ad8f_acd0b7638b99.slice/cri-containerd-b787df4727afc4dedbd9c0ce6e7c2596e46c5720249f8e544f944b059b68fea3.scope
    580      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50a8c657_e64e_499f_ad8f_acd0b7638b99.slice/cri-containerd-bf9a7a92b9dfd81b79e6caf264a8acd7ce48b7b53ecf36d72fd4081acfb9ac55.scope
    576      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98ccc51b_644d_47c5_82c9_5e9048aecc7b.slice/cri-containerd-d46720af6f2b0bbe1154ff4646fb251fdb508bc8e98d964702b64a12d6d99744.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98ccc51b_644d_47c5_82c9_5e9048aecc7b.slice/cri-containerd-a719ef1c289e9edc4257830625087ed7982ee388bdd74f1c9a979e856669824d.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8972117f_ad6f_4607_848b_7934c7dade6c.slice/cri-containerd-92e776b41f4522cb9daaa2ebe88b859cdc271339c2802adc8636e8812f6b7d84.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8972117f_ad6f_4607_848b_7934c7dade6c.slice/cri-containerd-5dffddb39659124f88ac78e20ecc250fba8003cc1d060865d2303220c1b12f0e.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8972117f_ad6f_4607_848b_7934c7dade6c.slice/cri-containerd-d12a4a0e6d55d5edf1cc7f110a0feb0cf3338667277ff6d9558628b8fb781cbb.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8972117f_ad6f_4607_848b_7934c7dade6c.slice/cri-containerd-24c3ec7d9ad03ba0428cf477f628ee9a6a7cd62c0c22454c6afeb2a58a5e0782.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8796e76_5072_481b_8767_dfc76bdaaba7.slice/cri-containerd-0acefe8f27212c714ce144872dad4eada0c7add5b8cc15f483c05648a1e4f8c0.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8796e76_5072_481b_8767_dfc76bdaaba7.slice/cri-containerd-17fac2ccd0bf422dec427c0ef5e990d5ed707c0504a26785cc8272039e9ba41e.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8796e76_5072_481b_8767_dfc76bdaaba7.slice/cri-containerd-02d975a2a19df3a61f908cca1c014ae7d0916d7308cb11c9c1666e48d41f5a96.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4707fa5a_daa2_431d_bf26_22bbb47d7e89.slice/cri-containerd-d26ef15e372cc2328d32634f0b38ef0c17237e598fc5c2229d850be2e382f037.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4707fa5a_daa2_431d_bf26_22bbb47d7e89.slice/cri-containerd-cd81782f9ff4b416aacf55d46a323453edfbac11ec2ab4506f01106210d76347.scope
    118      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4189cf36_9c30_4411_ab4d_16eab6800d0a.slice/cri-containerd-244d42b46b6a6d57619cd8895a861d9758a2f6b6c605716500dba100e4c0a3ec.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4189cf36_9c30_4411_ab4d_16eab6800d0a.slice/cri-containerd-6371e5bb1cb984b39ef1d17e244de85a9c5d55be49afdd141f6102049970badb.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddde1f789_1654_4ed8_a904_1862b1030b6e.slice/cri-containerd-835b4dde6b979ff1622e85879a51ac58545d59defb0b0a7cb9a0743e92a47935.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddde1f789_1654_4ed8_a904_1862b1030b6e.slice/cri-containerd-ca094f0a7e0e8b738e2f55a0b90598e75510f1a2e928ee1ee2fa374339ee5d39.scope
    126      cgroup_device   multi                                          
