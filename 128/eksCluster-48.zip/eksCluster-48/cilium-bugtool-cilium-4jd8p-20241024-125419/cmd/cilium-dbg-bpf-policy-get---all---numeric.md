Endpoint ID: 219
Path: /sys/fs/bpf/tc/globals/cilium_policy_00219

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 319
Path: /sys/fs/bpf/tc/globals/cilium_policy_00319

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6227666   77126     0        
Allow    Ingress     1          ANY          NONE         disabled    62356     749       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 463
Path: /sys/fs/bpf/tc/globals/cilium_policy_00463

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    381214   4457      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 466
Path: /sys/fs/bpf/tc/globals/cilium_policy_00466

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3096     34        0        
Allow    Ingress     1          ANY          NONE         disabled    152018   1739      0        
Allow    Egress      0          ANY          NONE         disabled    21046    234       0        


Endpoint ID: 1018
Path: /sys/fs/bpf/tc/globals/cilium_policy_01018

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6022393   61009     0        
Allow    Ingress     1          ANY          NONE         disabled    5602695   59188     0        
Allow    Egress      0          ANY          NONE         disabled    7419402   72577     0        


Endpoint ID: 2682
Path: /sys/fs/bpf/tc/globals/cilium_policy_02682

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3051
Path: /sys/fs/bpf/tc/globals/cilium_policy_03051

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3712
Path: /sys/fs/bpf/tc/globals/cilium_policy_03712

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2800     26        0        
Allow    Ingress     1          ANY          NONE         disabled    155949   1795      0        
Allow    Egress      0          ANY          NONE         disabled    20699    231       0        


