{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.653Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.701Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.704Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.746Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.764Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.783Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.018Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.022Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.065Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.109Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.126Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.686Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.711Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.727Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.763Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.773Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.001Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.018Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.095Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.125Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.143Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.705Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.708Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.744Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.757Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.800Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.806Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.837Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.062Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.068Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.126Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.175Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.195Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.724Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.731Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.761Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.775Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.823Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.839Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.858Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.067Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.070Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.125Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.129Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.170Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.630Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.706Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.725Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.764Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.773Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.958Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.972Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.029Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.044Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.072Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.508Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.509Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.552Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.569Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.588Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.799Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.808Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.861Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.872Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.906Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.290Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.294Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.340Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.356Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.377Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.624Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.637Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.736Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.738Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.771Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.137Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.173Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.176Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.213Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.224Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.252Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.502Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.509Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.546Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.556Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.596Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.965Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.001Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.005Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.062Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.063Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.099Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.339Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.341Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.404Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.416Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.443Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.749Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.832Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.834Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.911Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.912Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.922Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.087Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.099Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.150Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.151Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.199Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.480Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.536Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.541Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.583Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.605Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.625Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.852Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.872Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.885Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.894Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.895Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.551Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.554Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.586Z",
  "value": "id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.603Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.633Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.958Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.959Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.610Z",
  "value": "id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.623Z",
  "value": "id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3"
}

