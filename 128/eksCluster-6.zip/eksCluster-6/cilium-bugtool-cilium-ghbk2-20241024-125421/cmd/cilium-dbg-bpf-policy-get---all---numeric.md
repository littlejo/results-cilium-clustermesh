Endpoint ID: 12
Path: /sys/fs/bpf/tc/globals/cilium_policy_00012

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3268     34        0        
Allow    Ingress     1          ANY          NONE         disabled    170116   1958      0        
Allow    Egress      0          ANY          NONE         disabled    22394    253       0        


Endpoint ID: 195
Path: /sys/fs/bpf/tc/globals/cilium_policy_00195

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 293
Path: /sys/fs/bpf/tc/globals/cilium_policy_00293

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6179760   76494     0        
Allow    Ingress     1          ANY          NONE         disabled    67750     818       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 653
Path: /sys/fs/bpf/tc/globals/cilium_policy_00653

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    356436   4171      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1046
Path: /sys/fs/bpf/tc/globals/cilium_policy_01046

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1265
Path: /sys/fs/bpf/tc/globals/cilium_policy_01265

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2628     26        0        
Allow    Ingress     1          ANY          NONE         disabled    169588   1950      0        
Allow    Egress      0          ANY          NONE         disabled    21483    242       0        


Endpoint ID: 1445
Path: /sys/fs/bpf/tc/globals/cilium_policy_01445

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5599729   57721     0        
Allow    Ingress     1          ANY          NONE         disabled    5387240   56807     0        
Allow    Egress      0          ANY          NONE         disabled    6910156   68143     0        


Endpoint ID: 3581
Path: /sys/fs/bpf/tc/globals/cilium_policy_03581

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


