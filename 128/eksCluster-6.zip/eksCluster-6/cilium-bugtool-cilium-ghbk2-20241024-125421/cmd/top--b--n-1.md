top - 12:54:22 up 33 min,  0 users,  load average: 0.52, 0.58, 0.32
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 39.3 us, 39.3 sy,  0.0 ni, 21.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    292.9 free,   1049.0 used,   2494.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2606.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 284488  78052 S  20.0   7.2   1:08.30 cilium-+
    393 root      20   0 1229488   9268   2864 S   6.7   0.2   0:04.15 cilium-+
   3258 root      20   0 1240432  16140  11164 S   0.0   0.4   0:00.02 cilium-+
   3286 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3292 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3316 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3317 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3326 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
