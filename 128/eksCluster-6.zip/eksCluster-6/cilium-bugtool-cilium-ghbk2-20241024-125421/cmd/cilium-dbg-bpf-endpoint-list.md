IP ADDRESS         LOCAL ENDPOINT INFO
10.6.0.210:0       (localhost)                                                                                       
10.6.0.8:0         id=1046  sec_id=471344 flags=0x0000 ifindex=20  mac=7A:34:07:2C:58:2A nodemac=32:4D:66:73:CB:B3   
10.6.0.105:0       id=1265  sec_id=480978 flags=0x0000 ifindex=12  mac=EE:59:A1:78:E6:57 nodemac=C2:14:98:67:C3:C1   
10.6.0.139:0       id=293   sec_id=4     flags=0x0000 ifindex=10  mac=7A:E0:F0:42:0B:F3 nodemac=96:89:CE:7B:15:08    
10.6.0.247:0       id=12    sec_id=480978 flags=0x0000 ifindex=14  mac=DE:FD:6E:D3:A5:76 nodemac=86:66:2C:D9:C2:4B   
10.6.0.22:0        id=3581  sec_id=483566 flags=0x0000 ifindex=24  mac=EE:69:A7:FF:34:9E nodemac=A6:17:3C:9D:F5:39   
172.31.153.241:0   (localhost)                                                                                       
10.6.0.95:0        id=1445  sec_id=509315 flags=0x0000 ifindex=18  mac=2E:84:73:55:BE:04 nodemac=72:86:61:CE:52:68   
10.6.0.192:0       id=653   sec_id=468343 flags=0x0000 ifindex=22  mac=2E:24:DF:0E:6F:99 nodemac=1E:4D:F9:93:D9:49   
172.31.190.124:0   (localhost)                                                                                       
