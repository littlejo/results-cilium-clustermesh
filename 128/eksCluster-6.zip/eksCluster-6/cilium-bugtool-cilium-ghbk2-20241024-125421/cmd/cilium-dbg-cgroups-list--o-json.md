[
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2798729_9075_4047_bb1f_83a92cda5f9e.slice/cri-containerd-b8a53ba223190e72ed060517233cba7cb623b8683df375e5ec13c170981bdd64.scope"
      }
    ],
    "ips": [
      "10.6.0.8"
    ],
    "name": "client-974f6c69d-7v95c",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae1cbc79_1d17_48b1_95a9_4a2a7d457310.slice/cri-containerd-e537e42935b1cd8fe216275e1bbacfd1dd98653f5954f5e241fdaa2400d97ff9.scope"
      }
    ],
    "ips": [
      "10.6.0.22"
    ],
    "name": "client2-57cf4468f-fgm2l",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b34e7ec_25f0_4ffe_9f99_df8983e615d0.slice/cri-containerd-df1cdd95cdf5a83158f97d30c97f334a09c94aff1f152aa42d67992129495df7.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b34e7ec_25f0_4ffe_9f99_df8983e615d0.slice/cri-containerd-89778bf9bdd4483ffabe86d6dc01d7de74598ce3563f88e569cfc4f7c4125a77.scope"
      }
    ],
    "ips": [
      "10.6.0.192"
    ],
    "name": "echo-same-node-86d9cc975c-lj2dv",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ace53df_c2f8_405f_b3f2_61cd1d8ceeec.slice/cri-containerd-084867cb71b9b97958ccfe27e1bbec7e6bbba078d422679f7867fa6fc6259f46.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ace53df_c2f8_405f_b3f2_61cd1d8ceeec.slice/cri-containerd-60caea31abfdb475fb02c7ab68306e6beaa188239234c30b139d905aa6e8b72e.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ace53df_c2f8_405f_b3f2_61cd1d8ceeec.slice/cri-containerd-2da700dbfd8cfabec09172b13b0db51b352538ee5075df3139a8f0f6c6992af6.scope"
      }
    ],
    "ips": [
      "10.6.0.95"
    ],
    "name": "clustermesh-apiserver-c49cf7b88-7jmlx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb41dd10f_cd52_4788_b358_98d1f38b1efe.slice/cri-containerd-25bf2b0c9016e52f8e90d306df7c758ceba7be53ce4f293f98e8fd88f37e3459.scope"
      }
    ],
    "ips": [
      "10.6.0.247"
    ],
    "name": "coredns-cc6ccd49c-dpjbk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc44e692f_2049_4184_b319_bda78833cce9.slice/cri-containerd-d30f8e86f3d5890756dd2bf485e3c78726aeee1cdeee8f8da36ea0ddf27c53dc.scope"
      }
    ],
    "ips": [
      "10.6.0.105"
    ],
    "name": "coredns-cc6ccd49c-qsk8n",
    "namespace": "kube-system"
  }
]

