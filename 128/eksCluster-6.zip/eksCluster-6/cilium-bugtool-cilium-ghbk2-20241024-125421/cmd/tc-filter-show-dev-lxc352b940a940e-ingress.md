filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc352b940a940e direct-action not_in_hw id 3360 tag 686b8b4b9b443b23 jited 
