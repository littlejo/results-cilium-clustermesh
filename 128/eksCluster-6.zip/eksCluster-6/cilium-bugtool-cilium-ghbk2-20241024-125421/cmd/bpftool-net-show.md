xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 557
ens6(4) clsact/ingress cil_from_netdev-ens6 id 565
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(7) clsact/egress cil_from_host-cilium_host id 541
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 577
lxc359435fbf937(12) clsact/ingress cil_from_container-lxc359435fbf937 id 527
lxc734d3683d6b0(14) clsact/ingress cil_from_container-lxc734d3683d6b0 id 563
lxccda8011c0735(18) clsact/ingress cil_from_container-lxccda8011c0735 id 650
lxc352b940a940e(20) clsact/ingress cil_from_container-lxc352b940a940e id 3360
lxcc4f21562c698(22) clsact/ingress cil_from_container-lxcc4f21562c698 id 3298
lxca40c43ca0ee4(24) clsact/ingress cil_from_container-lxca40c43ca0ee4 id 3348

flow_dissector:

netfilter:

