alloc: 121.08MB (126963232 bytes)
total-alloc: 3.09GB (3321413944 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75279669
frees: 73909999
heap-alloc: 121.08MB (126963232 bytes)
heap-sys: 172.59MB (180977664 bytes)
heap-idle: 34.37MB (36036608 bytes)
heap-in-use: 138.23MB (144941056 bytes)
heap-released: 11.94MB (12517376 bytes)
heap-objects: 1369670
stack-in-use: 35.41MB (37126144 bytes)
stack-sys: 35.41MB (37126144 bytes)
stack-mspan-inuse: 2.34MB (2451040 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1017.51KB (1041929 bytes)
gc-sys: 5.47MB (5739640 bytes)
next-gc: when heap-alloc >= 146.30MB (153405704 bytes)
last-gc: 2024-10-24 12:53:34.379689111 +0000 UTC
gc-pause-total: 10.503306ms
gc-pause: 176690
gc-pause-end: 1729774414379689111
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005122309963416642
enable-gc: true
debug-gc: false
