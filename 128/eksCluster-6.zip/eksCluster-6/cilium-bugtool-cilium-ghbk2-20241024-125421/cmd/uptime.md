 12:54:22 up 33 min,  0 users,  load average: 0.52, 0.58, 0.32
