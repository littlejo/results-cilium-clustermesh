markdown output at /tmp/cilium-bugtool-20241024-125422.49+0000-UTC-2541590902/cmd/cilium-debuginfo-20241024-125424.554+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125422.49+0000-UTC-2541590902/cmd/cilium-debuginfo-20241024-125424.554+0000-UTC.json
