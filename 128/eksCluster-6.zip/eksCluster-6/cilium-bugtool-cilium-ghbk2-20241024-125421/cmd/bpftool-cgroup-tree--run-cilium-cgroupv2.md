CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc44e692f_2049_4184_b319_bda78833cce9.slice/cri-containerd-28189bbe745232e84f4e6ff23a5e6a3d7e8e94b089282534a06d0102d6184c4d.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc44e692f_2049_4184_b319_bda78833cce9.slice/cri-containerd-d30f8e86f3d5890756dd2bf485e3c78726aeee1cdeee8f8da36ea0ddf27c53dc.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4a1cd92_1ba0_4987_beb6_dfe9b549432f.slice/cri-containerd-8c2e56906befda51eba752d5d353ef1c74267d540ead742eb4fbf70a8f5ba963.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4a1cd92_1ba0_4987_beb6_dfe9b549432f.slice/cri-containerd-bbbaf97c5a121e801cce68858c0906a2b94aa28bad9df51af8e215552b65668b.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c3c2745_d106_432e_af64_9e4f5625a6bd.slice/cri-containerd-3e83d9c17e2fb4ab5552332b059971ffa9af0129285d2f5527e92779fe5762e8.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c3c2745_d106_432e_af64_9e4f5625a6bd.slice/cri-containerd-c6552ffc0120708a7c5d65f3639d317a3b53f677d3e245bcead6c3f444f9f91f.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb41dd10f_cd52_4788_b358_98d1f38b1efe.slice/cri-containerd-25bf2b0c9016e52f8e90d306df7c758ceba7be53ce4f293f98e8fd88f37e3459.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb41dd10f_cd52_4788_b358_98d1f38b1efe.slice/cri-containerd-4c19c18df921bf50000c7c5315d323bfb6325b4093347c123f12a0b020e31973.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae1cbc79_1d17_48b1_95a9_4a2a7d457310.slice/cri-containerd-5e9c69b0e5623a0768816377ee0c72a91fcb2bfb636f20d113e27d13c8631187.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae1cbc79_1d17_48b1_95a9_4a2a7d457310.slice/cri-containerd-e537e42935b1cd8fe216275e1bbacfd1dd98653f5954f5e241fdaa2400d97ff9.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2798729_9075_4047_bb1f_83a92cda5f9e.slice/cri-containerd-f9f1382db125555bce280df34960b6925d6c6e1a221856e62a43d7ffa51fd1db.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2798729_9075_4047_bb1f_83a92cda5f9e.slice/cri-containerd-b8a53ba223190e72ed060517233cba7cb623b8683df375e5ec13c170981bdd64.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83a54763_6d4a_47fb_864b_9c0137f63ab8.slice/cri-containerd-e0aab9af9a940f0a158d8118f6cf989f548b0ebaa55a3b7a5d96a71a221e4a4a.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83a54763_6d4a_47fb_864b_9c0137f63ab8.slice/cri-containerd-94cf62c1627779a5e6c18b552ab05ce47b8a90730a92eae12757770e14d5b530.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b34e7ec_25f0_4ffe_9f99_df8983e615d0.slice/cri-containerd-df1cdd95cdf5a83158f97d30c97f334a09c94aff1f152aa42d67992129495df7.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b34e7ec_25f0_4ffe_9f99_df8983e615d0.slice/cri-containerd-89778bf9bdd4483ffabe86d6dc01d7de74598ce3563f88e569cfc4f7c4125a77.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b34e7ec_25f0_4ffe_9f99_df8983e615d0.slice/cri-containerd-19cd104187b00175019bc115acb60add93b54b4079687042dfa6a38e77e20996.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9b736cbc_ce9d_4762_a16e_12cd6724d590.slice/cri-containerd-a21cb9a080f930785f4fa077b21d0eddf31b9fa66973d6c88d3d5fb59e7dcbbe.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9b736cbc_ce9d_4762_a16e_12cd6724d590.slice/cri-containerd-66ea1ca23233570027ef3445c3ab78f04c837f055f65c0ce181dcf43614873ce.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ace53df_c2f8_405f_b3f2_61cd1d8ceeec.slice/cri-containerd-60caea31abfdb475fb02c7ab68306e6beaa188239234c30b139d905aa6e8b72e.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ace53df_c2f8_405f_b3f2_61cd1d8ceeec.slice/cri-containerd-084867cb71b9b97958ccfe27e1bbec7e6bbba078d422679f7867fa6fc6259f46.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ace53df_c2f8_405f_b3f2_61cd1d8ceeec.slice/cri-containerd-ba6c32423fc26fbd4bbd03effe1fd7bdb8b1945cc68937c95634611a3ef3a4e9.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ace53df_c2f8_405f_b3f2_61cd1d8ceeec.slice/cri-containerd-2da700dbfd8cfabec09172b13b0db51b352538ee5075df3139a8f0f6c6992af6.scope
    681      cgroup_device   multi                                          
