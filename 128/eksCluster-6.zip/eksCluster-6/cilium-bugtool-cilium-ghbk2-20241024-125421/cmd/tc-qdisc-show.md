qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc359435fbf937 root refcnt 2 
qdisc clsact ffff: dev lxc359435fbf937 parent ffff:fff1 
qdisc noqueue 0: dev lxc734d3683d6b0 root refcnt 2 
qdisc clsact ffff: dev lxc734d3683d6b0 parent ffff:fff1 
qdisc noqueue 0: dev lxccda8011c0735 root refcnt 2 
qdisc clsact ffff: dev lxccda8011c0735 parent ffff:fff1 
qdisc noqueue 0: dev lxc352b940a940e root refcnt 2 
qdisc clsact ffff: dev lxc352b940a940e parent ffff:fff1 
qdisc noqueue 0: dev lxcc4f21562c698 root refcnt 2 
qdisc clsact ffff: dev lxcc4f21562c698 parent ffff:fff1 
qdisc noqueue 0: dev lxca40c43ca0ee4 root refcnt 2 
qdisc clsact ffff: dev lxca40c43ca0ee4 parent ffff:fff1 
