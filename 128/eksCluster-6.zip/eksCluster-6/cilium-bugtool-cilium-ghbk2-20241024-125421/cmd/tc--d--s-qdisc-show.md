qdisc noqueue 0: dev lo root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc mq 0: dev ens5 root 
 Sent 56333489 bytes 421517 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 29568579 bytes 212231 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 1288 drop_overlimit 0 new_flow_count 336 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 26764910 bytes 209286 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 1389 drop_overlimit 0 new_flow_count 358 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc clsact ffff: dev ens5 parent ffff:fff1 
 Sent 213736606 bytes 513382 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc mq 0: dev ens6 root 
 Sent 2490 bytes 47 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 1146 bytes 15 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 0 drop_overlimit 0 new_flow_count 0 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 1344 bytes 32 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 0 drop_overlimit 0 new_flow_count 0 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc clsact ffff: dev ens6 parent ffff:fff1 
 Sent 812 bytes 29 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev cilium_net root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
 Sent 34484 bytes 643 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev cilium_host root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
 Sent 28890245 bytes 301486 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
 Sent 19701008 bytes 266171 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxc_health root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
 Sent 3734807 bytes 55540 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxc359435fbf937 root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxc359435fbf937 parent ffff:fff1 
 Sent 155765 bytes 1853 pkt (dropped 9, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxc734d3683d6b0 root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxc734d3683d6b0 parent ffff:fff1 
 Sent 157359 bytes 1868 pkt (dropped 8, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxccda8011c0735 root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxccda8011c0735 parent ffff:fff1 
 Sent 14472204 bytes 132111 pkt (dropped 12, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxc352b940a940e root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxc352b940a940e parent ffff:fff1 
 Sent 34753 bytes 417 pkt (dropped 80, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxcc4f21562c698 root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxcc4f21562c698 parent ffff:fff1 
 Sent 1173685 bytes 3141 pkt (dropped 11, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxca40c43ca0ee4 root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxca40c43ca0ee4 parent ffff:fff1 
 Sent 34909 bytes 415 pkt (dropped 62, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
