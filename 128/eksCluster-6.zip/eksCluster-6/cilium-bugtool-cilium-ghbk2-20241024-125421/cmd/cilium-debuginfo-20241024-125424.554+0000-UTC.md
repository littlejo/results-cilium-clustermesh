# Cilium debug information

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33616605                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33616605                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33616605                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400dc00000 rw-p 00000000 00:00 0 
400dc00000-4010000000 ---p 00000000 00:00 0 
ffff6733d000-ffff67643000 rw-p 00000000 00:00 0 
ffff6764b000-ffff6772c000 rw-p 00000000 00:00 0 
ffff6772c000-ffff6776d000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6776d000-ffff677ae000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff677ae000-ffff677ee000 rw-p 00000000 00:00 0 
ffff677ee000-ffff677f0000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff677f0000-ffff677f2000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff677f2000-ffff67da9000 rw-p 00000000 00:00 0 
ffff67da9000-ffff67ea9000 rw-p 00000000 00:00 0 
ffff67ea9000-ffff67eba000 rw-p 00000000 00:00 0 
ffff67eba000-ffff69eba000 rw-p 00000000 00:00 0 
ffff69eba000-ffff69f3a000 ---p 00000000 00:00 0 
ffff69f3a000-ffff69f3b000 rw-p 00000000 00:00 0 
ffff69f3b000-ffff89f3a000 ---p 00000000 00:00 0 
ffff89f3a000-ffff89f3b000 rw-p 00000000 00:00 0 
ffff89f3b000-ffffa9eca000 ---p 00000000 00:00 0 
ffffa9eca000-ffffa9ecb000 rw-p 00000000 00:00 0 
ffffa9ecb000-ffffadebc000 ---p 00000000 00:00 0 
ffffadebc000-ffffadebd000 rw-p 00000000 00:00 0 
ffffadebd000-ffffae6ba000 ---p 00000000 00:00 0 
ffffae6ba000-ffffae6bb000 rw-p 00000000 00:00 0 
ffffae6bb000-ffffae7ba000 ---p 00000000 00:00 0 
ffffae7ba000-ffffae81a000 rw-p 00000000 00:00 0 
ffffae81a000-ffffae81c000 r--p 00000000 00:00 0                          [vvar]
ffffae81c000-ffffae81d000 r-xp 00000000 00:00 0                          [vdso]
ffffd7bec000-ffffd7c0d000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.6.0.0/24, 
Allocated addresses:
  10.6.0.105 (kube-system/coredns-cc6ccd49c-qsk8n)
  10.6.0.139 (health)
  10.6.0.192 (cilium-test-1/echo-same-node-86d9cc975c-lj2dv)
  10.6.0.210 (router)
  10.6.0.22 (cilium-test-1/client2-57cf4468f-fgm2l)
  10.6.0.247 (kube-system/coredns-cc6ccd49c-dpjbk)
  10.6.0.8 (cilium-test-1/client-974f6c69d-7v95c)
  10.6.0.95 (kube-system/clustermesh-apiserver-c49cf7b88-7jmlx)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: efc1b5a376334cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      177/177 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   43s ago        never        0       no error   
  ct-map-pressure                                                    14s ago        never        0       no error   
  daemon-validate-config                                             15s ago        never        0       no error   
  dns-garbage-collector-job                                          46s ago        never        0       no error   
  endpoint-1046-regeneration-recovery                                never          never        0       no error   
  endpoint-12-regeneration-recovery                                  never          never        0       no error   
  endpoint-1265-regeneration-recovery                                never          never        0       no error   
  endpoint-1445-regeneration-recovery                                never          never        0       no error   
  endpoint-195-regeneration-recovery                                 never          never        0       no error   
  endpoint-293-regeneration-recovery                                 never          never        0       no error   
  endpoint-3581-regeneration-recovery                                never          never        0       no error   
  endpoint-653-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        4m47s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               14s ago        never        0       no error   
  ipcache-inject-labels                                              44s ago        never        0       no error   
  k8s-heartbeat                                                      17s ago        never        0       no error   
  link-cache                                                         14s ago        never        0       no error   
  local-identity-checkpoint                                          2m35s ago      never        0       no error   
  node-neighbor-link-updater                                         4s ago         never        0       no error   
  remote-etcd-cmesh1                                                 12m20s ago     never        0       no error   
  remote-etcd-cmesh10                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh100                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh101                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh102                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh103                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh104                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh105                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh106                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh107                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh108                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh109                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh11                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh110                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh111                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh112                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh113                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh114                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh115                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh116                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh117                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh118                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh119                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh12                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh120                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh121                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh122                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh123                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh124                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh125                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh126                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh127                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh128                                               12m20s ago     never        0       no error   
  remote-etcd-cmesh13                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh14                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh15                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh16                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh17                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh18                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh19                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh2                                                 12m20s ago     never        0       no error   
  remote-etcd-cmesh20                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh21                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh22                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh23                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh24                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh25                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh26                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh27                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh28                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh29                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh3                                                 12m20s ago     never        0       no error   
  remote-etcd-cmesh30                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh31                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh32                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh33                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh34                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh35                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh36                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh37                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh38                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh39                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh4                                                 12m20s ago     never        0       no error   
  remote-etcd-cmesh40                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh41                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh42                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh43                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh44                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh45                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh46                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh47                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh48                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh49                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh5                                                 12m20s ago     never        0       no error   
  remote-etcd-cmesh50                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh51                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh52                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh53                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh54                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh55                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh56                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh57                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh58                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh59                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh6                                                 12m20s ago     never        0       no error   
  remote-etcd-cmesh60                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh61                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh62                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh63                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh64                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh65                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh66                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh67                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh68                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh69                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh70                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh71                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh72                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh73                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh74                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh75                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh76                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh77                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh78                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh79                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh8                                                 12m20s ago     never        0       no error   
  remote-etcd-cmesh80                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh81                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh82                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh83                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh84                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh85                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh86                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh87                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh88                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh89                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh9                                                 12m20s ago     never        0       no error   
  remote-etcd-cmesh90                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh91                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh92                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh93                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh94                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh95                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh96                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh97                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh98                                                12m20s ago     never        0       no error   
  remote-etcd-cmesh99                                                12m20s ago     never        0       no error   
  resolve-identity-1046                                              1m2s ago       never        0       no error   
  resolve-identity-12                                                4m42s ago      never        0       no error   
  resolve-identity-1265                                              4m42s ago      never        0       no error   
  resolve-identity-1445                                              2m56s ago      never        0       no error   
  resolve-identity-195                                               4m44s ago      never        0       no error   
  resolve-identity-293                                               4m43s ago      never        0       no error   
  resolve-identity-3581                                              1m1s ago       never        0       no error   
  resolve-identity-653                                               1m2s ago       never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-7v95c                6m2s ago       never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-fgm2l               6m1s ago       never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-lj2dv       6m2s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-c49cf7b88-7jmlx   12m56s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-dpjbk                 29m42s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-qsk8n                 29m42s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     29m44s ago     never        0       no error   
  sync-policymap-1046                                                6m2s ago       never        0       no error   
  sync-policymap-12                                                  14m39s ago     never        0       no error   
  sync-policymap-1265                                                14m39s ago     never        0       no error   
  sync-policymap-1445                                                12m56s ago     never        0       no error   
  sync-policymap-195                                                 14m43s ago     never        0       no error   
  sync-policymap-293                                                 14m39s ago     never        0       no error   
  sync-policymap-3581                                                6m1s ago       never        0       no error   
  sync-policymap-653                                                 6m2s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (1046)                                  12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (12)                                    12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1265)                                  12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1445)                                  6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3581)                                  11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (653)                                   12s ago        never        0       no error   
  sync-utime                                                         44s ago        never        0       no error   
  write-cni-file                                                     29m47s ago     never        0       no error   
Proxy Status:            OK, ip 10.6.0.210, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 458752, max 524287
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 152.91   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
l2-announcements-retry-period:2s
nodeport-addresses:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
service-no-backend-response:reject
multicast-enabled:false
max-controller-interval:0
labels:
dnsproxy-lock-timeout:500ms
proxy-gid:1337
controller-group-metrics:
hubble-recorder-storage-path:/var/run/cilium/pcaps
http-request-timeout:3600
enable-host-legacy-routing:false
vtep-mask:
mesh-auth-queue-size:1024
k8s-kubeconfig-path:
enable-l2-pod-announcements:false
enable-node-selector-labels:false
use-cilium-internal-ip-for-ipsec:false
ipv6-range:auto
agent-health-port:9879
identity-heartbeat-timeout:30m0s
k8s-client-connection-keep-alive:30s
local-max-addr-scope:252
mesh-auth-mutual-listener-port:0
hubble-redact-http-headers-allow:
ipam-default-ip-pool:default
enable-local-redirect-policy:false
fqdn-regex-compile-lru-size:1024
mtu:0
tofqdns-dns-reject-response-code:refused
enable-health-check-nodeport:true
kvstore-connectivity-timeout:2m0s
max-connected-clusters:255
identity-gc-interval:15m0s
enable-k8s-api-discovery:false
ipv6-cluster-alloc-cidr:f00d::/64
enable-ipv6-big-tcp:false
bpf-lb-rev-nat-map-max:0
enable-ipv6-ndp:false
cluster-id:7
bpf-lb-dsr-l4-xlate:frontend
ipv6-pod-subnets:
node-port-acceleration:disabled
hubble-drop-events:false
enable-hubble-recorder-api:true
k8s-client-burst:20
enable-auto-protect-node-port-range:true
conntrack-gc-max-interval:0s
bpf-events-drop-enabled:true
exclude-local-address:
encryption-strict-mode-cidr:
enable-ipsec-xfrm-state-caching:true
allow-localhost:auto
ipam:cluster-pool
cni-chaining-target:
dnsproxy-lock-count:131
monitor-aggregation-flags:all
mesh-auth-enabled:true
node-port-algorithm:random
bpf-lb-source-range-map-max:0
enable-tcx:true
enable-srv6:false
hubble-listen-address::4244
bpf-ct-global-tcp-max:524288
enable-policy:default
hubble-redact-kafka-apikey:false
enable-endpoint-health-checking:true
bpf-events-trace-enabled:true
identity-restore-grace-period:30s
enable-k8s-networkpolicy:true
enable-mke:false
enable-tracing:false
vlan-bpf-bypass:
policy-trigger-interval:1s
cni-external-routing:false
envoy-config-retry-interval:15s
lib-dir:/var/lib/cilium
ipam-multi-pool-pre-allocation:
k8s-sync-timeout:3m0s
ipv6-mcast-device:
bpf-lb-external-clusterip:false
enable-ipsec:false
enable-host-firewall:false
endpoint-bpf-prog-watchdog-interval:30s
static-cnp-path:
bpf-sock-rev-map-max:262144
enable-runtime-device-detection:true
enable-ipv4-egress-gateway:false
proxy-admin-port:0
nat-map-stats-entries:32
ipv4-native-routing-cidr:
egress-gateway-policy-map-max:16384
enable-recorder:false
http-retry-count:3
bpf-lb-dsr-dispatch:opt
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
vtep-cidr:
ipv4-range:auto
ipam-cilium-node-update-rate:15s
proxy-prometheus-port:0
enable-l2-announcements:false
bpf-map-event-buffers:
enable-bpf-tproxy:false
tofqdns-enable-dns-compression:true
ipv6-native-routing-cidr:
hubble-export-denylist:
cluster-pool-ipv4-cidr:10.6.0.0/16
k8s-api-server:
k8s-require-ipv6-pod-cidr:false
bpf-ct-timeout-regular-tcp:2h13m20s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
clustermesh-ip-identities-sync-timeout:1m0s
enable-wireguard-userspace-fallback:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
envoy-log:
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-k8s-terminating-endpoint:true
bpf-lb-sock-terminate-pod-connections:false
kvstore-periodic-sync:5m0s
vtep-mac:
prometheus-serve-addr:
node-labels:
identity-allocation-mode:crd
bpf-neigh-global-max:524288
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-xt-socket-fallback:true
disable-iptables-feeder-rules:
hubble-export-file-max-backups:5
config:
cni-log-file:/var/run/cilium/cilium-cni.log
node-port-bind-protection:true
join-cluster:false
envoy-keep-cap-netbindservice:false
envoy-secrets-namespace:
enable-cilium-health-api-server-access:
enable-ipv6:false
dns-policy-unload-on-shutdown:false
ipv4-service-loopback-address:169.254.42.1
http-normalize-path:true
encryption-strict-mode-allow-remote-node-identities:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
hubble-export-file-compress:false
container-ip-local-reserved-ports:auto
clustermesh-enable-mcs-api:false
keep-config:false
clustermesh-enable-endpoint-sync:false
cilium-endpoint-gc-interval:5m0s
tunnel-protocol:vxlan
http-max-grpc-timeout:0
prepend-iptables-chains:true
bpf-lb-sock-hostns-only:false
tofqdns-pre-cache:
envoy-config-timeout:2m0s
tunnel-port:0
k8s-client-qps:10
bpf-root:/sys/fs/bpf
enable-host-port:false
hubble-export-file-max-size-mb:10
enable-ipip-termination:false
enable-xdp-prefilter:false
bpf-lb-maglev-map-max:0
proxy-portrange-min:10000
devices:
certificates-directory:/var/run/cilium/certs
allocator-list-timeout:3m0s
k8s-service-cache-size:128
proxy-connect-timeout:2
bpf-lb-service-backend-map-max:0
config-sources:config-map:kube-system/cilium-config
bpf-lb-acceleration:disabled
debug:false
hubble-recorder-sink-queue-size:1024
enable-health-check-loadbalancer-ip:false
proxy-max-requests-per-connection:0
k8s-require-ipv4-pod-cidr:false
log-opt:
bpf-ct-global-any-max:262144
enable-service-topology:false
kvstore:
fixed-identity-mapping:
hubble-redact-http-urlquery:false
tofqdns-proxy-port:0
egress-gateway-reconciliation-trigger-interval:1s
cgroup-root:/run/cilium/cgroupv2
routing-mode:tunnel
proxy-xff-num-trusted-hops-egress:0
enable-unreachable-routes:false
enable-bpf-masquerade:false
egress-masquerade-interfaces:ens+
hubble-event-buffer-capacity:4095
encrypt-node:false
local-router-ipv4:
dnsproxy-enable-transparent-mode:true
bpf-lb-sock:false
cmdref:
tofqdns-max-deferred-connection-deletes:10000
bpf-filter-priority:1
enable-svc-source-range-check:true
l2-pod-announcements-interface:
enable-icmp-rules:true
enable-stale-cilium-endpoint-cleanup:true
mesh-auth-mutual-connect-timeout:5s
bpf-lb-affinity-map-max:0
api-rate-limit:
enable-node-port:false
cluster-name:cmesh7
node-port-mode:snat
bgp-announce-pod-cidr:false
enable-sctp:false
ipsec-key-file:
operator-prometheus-serve-addr::9963
enable-l2-neigh-discovery:true
hubble-metrics-server:
bpf-map-dynamic-size-ratio:0.0025
procfs:/host/proc
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
arping-refresh-period:30s
enable-ipsec-key-watcher:true
hubble-disable-tls:false
bpf-lb-algorithm:random
kube-proxy-replacement-healthz-bind-address:
ipv4-service-range:auto
ipsec-key-rotation-duration:5m0s
local-router-ipv6:
hubble-metrics:
direct-routing-skip-unreachable:false
enable-monitor:true
enable-bgp-control-plane:false
bpf-policy-map-full-reconciliation-interval:15m0s
dnsproxy-concurrency-limit:0
bpf-ct-timeout-regular-any:1m0s
pprof-address:localhost
unmanaged-pod-watcher-interval:15
proxy-idle-timeout-seconds:60
enable-local-node-route:true
synchronize-k8s-nodes:true
identity-change-grace-period:5s
policy-cidr-match-mode:
enable-custom-calls:false
install-no-conntrack-iptables-rules:false
vtep-endpoint:
k8s-heartbeat-timeout:30s
hubble-drop-events-reasons:auth_required,policy_denied
set-cilium-node-taints:true
cluster-health-port:4240
enable-bbr:false
enable-ipsec-encrypted-overlay:false
ipv6-node:auto
dns-max-ips-per-restored-rule:1000
enable-bandwidth-manager:false
allow-icmp-frag-needed:true
enable-cilium-endpoint-slice:false
k8s-namespace:kube-system
ipv4-node:auto
enable-cilium-api-server-access:
proxy-portrange-max:20000
datapath-mode:veth
cni-exclusive:true
log-driver:
install-iptables-rules:true
hubble-redact-http-userinfo:true
max-internal-timer-delay:0s
wireguard-persistent-keepalive:0s
use-full-tls-context:false
bpf-policy-map-max:16384
bpf-ct-timeout-regular-tcp-fin:10s
read-cni-conf:
enable-ipv4:true
dnsproxy-insecure-skip-transparent-mode-check:false
hubble-drop-events-interval:2m0s
clustermesh-sync-timeout:1m0s
enable-wireguard:false
trace-sock:true
enable-ipv4-masquerade:true
agent-labels:
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
tofqdns-endpoint-max-ip-per-hostname:50
preallocate-bpf-maps:false
monitor-aggregation-interval:5s
dnsproxy-socket-linger-timeout:10
enable-bpf-clock-probe:false
enable-pmtu-discovery:false
enable-session-affinity:false
enable-nat46x64-gateway:false
exclude-node-label-patterns:
enable-route-mtu-for-cni-chaining:false
policy-audit-mode:false
hubble-flowlogs-config-path:
iptables-random-fully:false
enable-gateway-api:false
hubble-prefer-ipv6:false
cni-chaining-mode:none
kvstore-opt:
disable-endpoint-crd:false
enable-high-scale-ipcache:false
auto-create-cilium-node-resource:true
kube-proxy-replacement:false
bpf-ct-timeout-service-tcp:2h13m20s
gateway-api-secrets-namespace:
log-system-load:false
hubble-export-file-path:
policy-queue-size:100
enable-metrics:true
kvstore-max-consecutive-quorum-errors:2
bpf-fragments-map-max:8192
auto-direct-node-routes:false
disable-envoy-version-check:false
hubble-redact-enabled:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-health-checking:true
set-cilium-is-up-condition:true
bpf-lb-maglev-table-size:16381
enable-l7-proxy:true
enable-endpoint-routes:false
enable-ingress-controller:false
version:false
bpf-events-policy-verdict-enabled:true
nat-map-stats-interval:30s
encrypt-interface:
hubble-export-allowlist:
socket-path:/var/run/cilium/cilium.sock
enable-external-ips:false
bypass-ip-availability-upon-restore:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
mesh-auth-signal-backoff-duration:1s
hubble-skip-unknown-cgroup-ids:true
dnsproxy-concurrency-processing-grace-period:0s
kvstore-lease-ttl:15m0s
enable-ipv6-masquerade:true
proxy-max-connection-duration-seconds:0
enable-envoy-config:false
direct-routing-device:
external-envoy-proxy:true
bpf-node-map-max:16384
monitor-aggregation:medium
mesh-auth-gc-interval:5m0s
monitor-queue-size:0
enable-identity-mark:true
cflags:
conntrack-gc-interval:0s
l2-announcements-lease-duration:15s
enable-encryption-strict-mode:false
enable-k8s:true
l2-announcements-renew-deadline:5s
enable-ipv4-big-tcp:false
mesh-auth-spire-admin-socket:
clustermesh-config:/var/lib/cilium/clustermesh/
endpoint-queue-size:25
bpf-lb-map-max:65536
enable-ip-masq-agent:false
enable-k8s-endpoint-slice:true
k8s-service-proxy-name:
http-retry-timeout:0
http-idle-timeout:0
cluster-pool-ipv4-mask-size:24
hubble-redact-http-headers-deny:
debug-verbose:
enable-active-connection-tracking:false
srv6-encap-mode:reduced
tofqdns-min-ttl:0
bpf-lb-rss-ipv4-src-cidr:
bpf-ct-timeout-service-any:1m0s
disable-external-ip-mitigation:false
pprof-port:6060
bpf-ct-timeout-service-tcp-grace:1m0s
hubble-export-fieldmask:
iptables-lock-timeout:5s
custom-cni-conf:false
enable-masquerade-to-route-source:false
config-dir:/tmp/cilium/config-map
envoy-base-id:0
agent-liveness-update-interval:1s
metrics:
state-dir:/var/run/cilium
enable-well-known-identities:false
force-device-detection:false
label-prefix-file:
annotate-k8s-node:false
egress-multi-home-ip-rule-compat:false
derive-masq-ip-addr-from-device:
pprof:false
ingress-secrets-namespace:
remove-cilium-node-taints:true
gops-port:9890
tofqdns-proxy-response-max-delay:100ms
bgp-config-path:/var/lib/cilium/bgp/config.yaml
hubble-socket-path:/var/run/cilium/hubble.sock
enable-hubble:true
enable-vtep:false
tofqdns-idle-connection-grace-period:0s
hubble-monitor-events:
ipv4-pod-subnets:
enable-ipv4-fragment-tracking:true
bpf-lb-service-map-max:0
endpoint-gc-interval:5m0s
bgp-announce-lb-ip:false
crd-wait-timeout:5m0s
hubble-event-queue-size:0
bpf-nat-global-max:524288
trace-payloadlen:128
nodes-gc-interval:5m0s
operator-api-serve-addr:127.0.0.1:9234
ipv6-service-range:auto
bpf-auth-map-max:524288
route-metric:0
mesh-auth-rotated-identities-queue-size:1024
node-port-range:
k8s-client-connection-timeout:30s
proxy-xff-num-trusted-hops-ingress:0
policy-accounting:true
bpf-lb-rss-ipv6-src-cidr:
restore:true
bpf-lb-mode:snat
mke-cgroup-mount:
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
12         Disabled           Disabled          480978     k8s:eks.amazonaws.com/component=coredns                                               10.6.0.247   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh7                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
195        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                 
                                                           reserved:host                                                                                              
293        Disabled           Disabled          4          reserved:health                                                                       10.6.0.139   ready   
653        Disabled           Disabled          468343     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.6.0.192   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh7                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                     
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=echo                                                                                              
                                                           k8s:name=echo-same-node                                                                                    
                                                           k8s:other=echo                                                                                             
1046       Disabled           Disabled          471344     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.6.0.8     ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh7                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client                                                                                            
1265       Disabled           Disabled          480978     k8s:eks.amazonaws.com/component=coredns                                               10.6.0.105   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh7                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
1445       Disabled           Disabled          509315     k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.6.0.95    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh7                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
3581       Disabled           Disabled          483566     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.6.0.22    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh7                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                            
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client2                                                                                           
                                                           k8s:other=client                                                                                           
```

#### BPF Policy Get 12

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3268     34        0        
Allow    Ingress     1          ANY          NONE         disabled    170116   1958      0        
Allow    Egress      0          ANY          NONE         disabled    22328    252       0        

```


#### BPF CT List 12

```
Invalid argument: unknown type 12
```


#### Endpoint Get 12

```
[
  {
    "id": 12,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-12-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "26d48e9c-e8fb-466f-9063-c80a09348e41"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-12",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:49:41.859Z",
            "success-count": 6
          },
          "uuid": "7c26ea0d-2111-4e85-8eca-d6425823d0ba"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-dpjbk",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:24:41.856Z",
            "success-count": 1
          },
          "uuid": "46ed2c35-655a-43b9-b91a-6f18e77f003b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-12",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:39:44.634Z",
            "success-count": 2
          },
          "uuid": "b06afd9e-f5d6-437c-aa41-7774f2b626b6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (12)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:22.024Z",
            "success-count": 180
          },
          "uuid": "da4d9515-4b5b-4a43-9ce7-ab35e30e69e6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "4c19c18df921bf50000c7c5315d323bfb6325b4093347c123f12a0b020e31973:eth0",
        "container-id": "4c19c18df921bf50000c7c5315d323bfb6325b4093347c123f12a0b020e31973",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-dpjbk",
        "pod-name": "kube-system/coredns-cc6ccd49c-dpjbk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 480978,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.6.0.247",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "86:66:2c:d9:c2:4b",
        "interface-index": 14,
        "interface-name": "lxc734d3683d6b0",
        "mac": "de:fd:6e:d3:a5:76"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 480978,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 480978,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 12

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 12

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:06Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:04Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:24:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:24:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:24:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:24:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:24:41Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:24:41Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 480978

```
ID       LABELS
480978   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh7
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 195

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 195

```
Invalid argument: unknown type 195
```


#### Endpoint Get 195

```
[
  {
    "id": 195,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-195-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "708f2ff1-874e-462c-818c-141f23524b75"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-195",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:49:40.232Z",
            "success-count": 6
          },
          "uuid": "40f6dc61-10c5-4e81-a03a-93e6171cd08b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-195",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:39:41.286Z",
            "success-count": 2
          },
          "uuid": "1c3b4a27-eaa8-4a30-b84c-92b0620d2717"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "ba:df:23:48:e1:47",
        "interface-name": "cilium_host",
        "mac": "ba:df:23:48:e1:47"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 195

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 195

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:06Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:04Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T12:24:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:24:44Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T12:24:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:24:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:24:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T12:24:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:24:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:24:40Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:24:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:24:40Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:24:40Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 293

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6176033   76442     0        
Allow    Ingress     1          ANY          NONE         disabled    67750     818       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 293

```
Invalid argument: unknown type 293
```


#### Endpoint Get 293

```
[
  {
    "id": 293,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-293-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2921a2a0-ccf1-4559-a9ac-2cdbb62a59fe"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-293",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:49:41.281Z",
            "success-count": 6
          },
          "uuid": "a7799ea4-4e78-46f6-aa02-514a2a7e0904"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-293",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:39:44.582Z",
            "success-count": 2
          },
          "uuid": "a3c33907-e020-4cbc-b8be-f1d442e4441d"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.6.0.139",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "96:89:ce:7b:15:08",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "7a:e0:f0:42:0b:f3"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 293

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 293

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:06Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:04Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:24:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:24:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:24:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:24:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:24:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:41Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:24:41Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:24:40Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 653

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    352360   4123      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 653

```
Invalid argument: unknown type 653
```


#### Endpoint Get 653

```
[
  {
    "id": 653,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-653-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "bf5832f7-3758-4515-989d-8d3c22df5f37"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-653",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:21.860Z",
            "success-count": 2
          },
          "uuid": "1ccdc42f-5449-487f-9d4a-72a01711b887"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-lj2dv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.859Z",
            "success-count": 1
          },
          "uuid": "89a286bd-a1ab-4dbb-99b7-e65f796d616b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-653",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.921Z",
            "success-count": 1
          },
          "uuid": "0caca9bf-aec6-4cd8-abe8-2a4b1d7a4bcd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (653)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:21.907Z",
            "success-count": 38
          },
          "uuid": "83abd9ba-480c-4854-9128-f3b89968ec3b"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "19cd104187b00175019bc115acb60add93b54b4079687042dfa6a38e77e20996:eth0",
        "container-id": "19cd104187b00175019bc115acb60add93b54b4079687042dfa6a38e77e20996",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-lj2dv",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-lj2dv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 468343,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:23Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.6.0.192",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1e:4d:f9:93:d9:49",
        "interface-index": 22,
        "interface-name": "lxcc4f21562c698",
        "mac": "2e:24:df:0e:6f:99"
      },
      "policy": {
        "proxy-policy-revision": 126,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 468343,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 126,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 468343,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 126
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 653

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 653

```
Timestamp              Status   State                   Message
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:51Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 468343

```
ID       LABELS
468343   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh7
         k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=echo
         k8s:name=echo-same-node
         k8s:other=echo

```


#### BPF Policy Get 1046

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1046

```
Invalid argument: unknown type 1046
```


#### Endpoint Get 1046

```
[
  {
    "id": 1046,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1046-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4b0c0b04-48fc-456b-80ad-5f2b8a2c5e97"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1046",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:21.763Z",
            "success-count": 2
          },
          "uuid": "1442bf9a-bcbf-4832-9cf8-9185f31e4ea0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-7v95c",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.755Z",
            "success-count": 1
          },
          "uuid": "ed765efb-a916-4b21-904c-1775430e0467"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1046",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.842Z",
            "success-count": 1
          },
          "uuid": "a4fbbaed-71c6-4c45-a32e-2c16b8a7242f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1046)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:21.793Z",
            "success-count": 38
          },
          "uuid": "b138ea1c-0b5f-45dd-a69e-cd2e23662178"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f9f1382db125555bce280df34960b6925d6c6e1a221856e62a43d7ffa51fd1db:eth0",
        "container-id": "f9f1382db125555bce280df34960b6925d6c6e1a221856e62a43d7ffa51fd1db",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-7v95c",
        "pod-name": "cilium-test-1/client-974f6c69d-7v95c"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 471344,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:32Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.6.0.8",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "32:4d:66:73:cb:b3",
        "interface-index": 20,
        "interface-name": "lxc352b940a940e",
        "mac": "7a:34:07:2c:58:2a"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 471344,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 471344,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1046

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1046

```
Timestamp              Status   State                   Message
2024-10-24T12:51:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 471344

```
ID       LABELS
471344   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh7
         k8s:io.cilium.k8s.policy.serviceaccount=client
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client

```


#### BPF Policy Get 1265

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2628     26        0        
Allow    Ingress     1          ANY          NONE         disabled    169588   1950      0        
Allow    Egress      0          ANY          NONE         disabled    21417    241       0        

```


#### BPF CT List 1265

```
Invalid argument: unknown type 1265
```


#### Endpoint Get 1265

```
[
  {
    "id": 1265,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1265-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e9a44cc0-55b8-4fbc-9ac3-9b1e3fefca92"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1265",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:49:41.814Z",
            "success-count": 6
          },
          "uuid": "40c55766-5bd8-4462-9b55-d60e085d2335"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-qsk8n",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:24:41.811Z",
            "success-count": 1
          },
          "uuid": "c3de19e4-7a32-4d9e-8207-f0f0f22124a6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1265",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:39:44.579Z",
            "success-count": 2
          },
          "uuid": "114a8121-c106-4b7c-8e44-8c930b738e4f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1265)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:21.959Z",
            "success-count": 180
          },
          "uuid": "2df00fff-ad22-447b-a73a-03db8722ec76"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "28189bbe745232e84f4e6ff23a5e6a3d7e8e94b089282534a06d0102d6184c4d:eth0",
        "container-id": "28189bbe745232e84f4e6ff23a5e6a3d7e8e94b089282534a06d0102d6184c4d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-qsk8n",
        "pod-name": "kube-system/coredns-cc6ccd49c-qsk8n"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 480978,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.6.0.105",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "c2:14:98:67:c3:c1",
        "interface-index": 12,
        "interface-name": "lxc359435fbf937",
        "mac": "ee:59:a1:78:e6:57"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 480978,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 480978,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1265

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1265

```
Timestamp              Status    State                   Message
2024-10-24T12:48:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:06Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:06Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:06Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:42:06Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:05Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:05Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:05Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:05Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:04Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:04Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:04Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:04Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:37Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:24:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:24:43Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:24:42Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:24:42Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:24:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:24:41Z   OK        ready                   Set identity for this endpoint
2024-10-24T12:24:41Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:41Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 480978

```
ID       LABELS
480978   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh7
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1445

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5412417   56479     0        
Allow    Ingress     1          ANY          NONE         disabled    5386216   56795     0        
Allow    Egress      0          ANY          NONE         disabled    6701053   66835     0        

```


#### BPF CT List 1445

```
Invalid argument: unknown type 1445
```


#### Endpoint Get 1445

```
[
  {
    "id": 1445,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1445-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "269924c4-0377-42b6-96e5-c4dedb135548"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1445",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:28.261Z",
            "success-count": 3
          },
          "uuid": "2fe3f57c-eb43-4156-a2e0-c05c384b2788"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-c49cf7b88-7jmlx",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:28.258Z",
            "success-count": 1
          },
          "uuid": "346d7c7c-b253-4134-9582-9a1263d87ce4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1445",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:28.306Z",
            "success-count": 1
          },
          "uuid": "b5ad6eba-086b-40aa-acff-ab040303a73e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1445)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:18.336Z",
            "success-count": 79
          },
          "uuid": "18462a03-7435-4863-87b4-9062eb9c7620"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ba6c32423fc26fbd4bbd03effe1fd7bdb8b1945cc68937c95634611a3ef3a4e9:eth0",
        "container-id": "ba6c32423fc26fbd4bbd03effe1fd7bdb8b1945cc68937c95634611a3ef3a4e9",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-c49cf7b88-7jmlx",
        "pod-name": "kube-system/clustermesh-apiserver-c49cf7b88-7jmlx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 509315,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=c49cf7b88"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.6.0.95",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "72:86:61:ce:52:68",
        "interface-index": 18,
        "interface-name": "lxccda8011c0735",
        "mac": "2e:84:73:55:be:04"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 509315,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 509315,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1445

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1445

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:06Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:04Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:41:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:41:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:41:28Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:41:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 509315

```
ID       LABELS
509315   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh7
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 3581

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3581

```
Invalid argument: unknown type 3581
```


#### Endpoint Get 3581

```
[
  {
    "id": 3581,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3581-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d7826836-beb9-424b-bddb-f0239310820f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3581",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:23.269Z",
            "success-count": 2
          },
          "uuid": "2588e3f3-0028-46a9-b38a-f0f6c6cebb8f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-fgm2l",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:23.269Z",
            "success-count": 1
          },
          "uuid": "d27266c9-75f7-47a2-b0d3-968e100004e8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3581",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:23.315Z",
            "success-count": 1
          },
          "uuid": "00459b7b-31d9-46b9-b356-3db55abbfb1f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3581)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:23.308Z",
            "success-count": 38
          },
          "uuid": "44bb9811-54f6-450d-9ed2-6fad57fbf3cd"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "5e9c69b0e5623a0768816377ee0c72a91fcb2bfb636f20d113e27d13c8631187:eth0",
        "container-id": "5e9c69b0e5623a0768816377ee0c72a91fcb2bfb636f20d113e27d13c8631187",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-fgm2l",
        "pod-name": "cilium-test-1/client2-57cf4468f-fgm2l"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 483566,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh7",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:32Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.6.0.22",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a6:17:3c:9d:f5:39",
        "interface-index": 24,
        "interface-name": "lxca40c43ca0ee4",
        "mac": "ee:69:a7:ff:34:9e"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 483566,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 483566,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3581

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3581

```
Timestamp              Status   State                   Message
2024-10-24T12:51:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:02Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 483566

```
ID       LABELS
483566   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh7
         k8s:io.cilium.k8s.policy.serviceaccount=client2
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client2
         k8s:other=client

```


#### Policy get

```
:
 []
Revision: 129

```


#### Service list

```
ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.191.222:443 (active)    
                                        2 => 172.31.215.61:443 (active)     
2    10.100.4.81:443     ClusterIP      1 => 172.31.153.241:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.6.0.247:53 (active)         
                                        2 => 10.6.0.105:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.6.0.247:9153 (active)       
                                        2 => 10.6.0.105:9153 (active)       
5    10.100.247.3:2379   ClusterIP      1 => 10.6.0.95:2379 (active)        
6    10.100.97.90:8080   ClusterIP      1 => 10.6.0.192:8080 (active)       
```

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=10) "10.6.0.192": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-lj2dv",
  (string) (len=9) "10.6.0.22": (string) (len=37) "cilium-test-1/client2-57cf4468f-fgm2l",
  (string) (len=10) "10.6.0.210": (string) (len=6) "router",
  (string) (len=10) "10.6.0.139": (string) (len=6) "health",
  (string) (len=10) "10.6.0.105": (string) (len=35) "kube-system/coredns-cc6ccd49c-qsk8n",
  (string) (len=10) "10.6.0.247": (string) (len=35) "kube-system/coredns-cc6ccd49c-dpjbk",
  (string) (len=8) "10.6.0.8": (string) (len=36) "cilium-test-1/client-974f6c69d-7v95c",
  (string) (len=9) "10.6.0.95": (string) (len=49) "kube-system/clustermesh-apiserver-c49cf7b88-7jmlx"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.153.241": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40023e6160)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001ffe9c0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001ffe9c0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000c50d10)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4003846840)(frontends:[]/ports=[kvmesh-metrics etcd-metrics apiserv-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40038468f0)(frontends:[10.100.247.3]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x4008a90790)(frontends:[10.100.97.90]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000c50b00)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000c50bb0)(frontends:[10.100.4.81]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000f1ad08)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40018ed380)(172.31.191.222:443/TCP,172.31.215.61:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000f1ad10)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-8ng9j": (*k8s.Endpoints)(0x4002e6a410)(172.31.153.241:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000f1ad18)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-s9d79": (*k8s.Endpoints)(0x4003815380)(10.6.0.105:53/TCP[eu-west-3a],10.6.0.105:53/UDP[eu-west-3a],10.6.0.105:9153/TCP[eu-west-3a],10.6.0.247:53/TCP[eu-west-3a],10.6.0.247:53/UDP[eu-west-3a],10.6.0.247:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x400152d4b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-8m8xg": (*k8s.Endpoints)(0x40021ce8f0)(10.6.0.95:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x40012ac708)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-rtzq6": (*k8s.Endpoints)(0x4007a3a340)(10.6.0.192:8080/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001aceee0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002250f50)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400a619ef0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002262120,
  gcExited: (chan struct {}) 0x4002262180,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001d46900)({
     ObserverVec: (*prometheus.HistogramVec)(0x40017374c8)({
      MetricVec: (*prometheus.MetricVec)(0x4001eb1b00)({
       metricMap: (*prometheus.metricMap)(0x4001eb1b30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b4aa20)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001d46980)({
     ObserverVec: (*prometheus.HistogramVec)(0x40017374d0)({
      MetricVec: (*prometheus.MetricVec)(0x4001eb1b90)({
       metricMap: (*prometheus.metricMap)(0x4001eb1bc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b4aa80)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001d46a00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40017374d8)({
      MetricVec: (*prometheus.MetricVec)(0x4001eb1c20)({
       metricMap: (*prometheus.metricMap)(0x4001eb1c50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b4aae0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001d46a80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40017374e0)({
      MetricVec: (*prometheus.MetricVec)(0x4001eb1cb0)({
       metricMap: (*prometheus.metricMap)(0x4001eb1ce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b4ab40)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001d46b00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40017374e8)({
      MetricVec: (*prometheus.MetricVec)(0x4001eb1d40)({
       metricMap: (*prometheus.metricMap)(0x4001eb1d70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b4aba0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001d46b80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40017374f0)({
      MetricVec: (*prometheus.MetricVec)(0x4001eb1dd0)({
       metricMap: (*prometheus.metricMap)(0x4001eb1e00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b4ac00)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001d46c00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40017374f8)({
      MetricVec: (*prometheus.MetricVec)(0x4001eb1e60)({
       metricMap: (*prometheus.metricMap)(0x4001eb1e90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b4ac60)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001d46c80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001737500)({
      MetricVec: (*prometheus.MetricVec)(0x4001eb1ef0)({
       metricMap: (*prometheus.metricMap)(0x4001eb1f20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b4acc0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001d46d00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001737508)({
      MetricVec: (*prometheus.MetricVec)(0x4001ec2000)({
       metricMap: (*prometheus.metricMap)(0x4001ec2030)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b4ad20)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001aceee0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40023d41c0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40023b4948)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 361ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption


