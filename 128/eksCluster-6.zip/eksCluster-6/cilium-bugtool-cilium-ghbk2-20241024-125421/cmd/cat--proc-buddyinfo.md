Node 0, zone      DMA    991    513    237    192    120     63     54     35     26     20     14 
Node 0, zone   Normal   1368    357     84     12      3      2      1      2      2      2      8 
