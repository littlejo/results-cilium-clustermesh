key: 0c 00 00 00  value: 42 02 00 00
key: 25 01 00 00  value: 40 02 00 00
key: 8d 02 00 00  value: d4 0c 00 00
key: 16 04 00 00  value: 1f 0d 00 00
key: f1 04 00 00  value: 08 02 00 00
key: a5 05 00 00  value: 84 02 00 00
key: fd 0d 00 00  value: 1e 0d 00 00
Found 7 elements
