Node 0, zone      DMA     28     76     41     41     26      9      6      5      4      3     40 
Node 0, zone   Normal     54      3      2      3     20      2      8      8      4      3      6 
