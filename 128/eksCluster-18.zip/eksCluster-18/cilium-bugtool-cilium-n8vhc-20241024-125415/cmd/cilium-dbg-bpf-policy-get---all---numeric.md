Endpoint ID: 77
Path: /sys/fs/bpf/tc/globals/cilium_policy_00077

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377518   4413      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 468
Path: /sys/fs/bpf/tc/globals/cilium_policy_00468

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2462     26        0        
Allow    Ingress     1          ANY          NONE         disabled    163671   1878      0        
Allow    Egress      0          ANY          NONE         disabled    21927    245       0        


Endpoint ID: 489
Path: /sys/fs/bpf/tc/globals/cilium_policy_00489

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3434     34        0        
Allow    Ingress     1          ANY          NONE         disabled    163814   1875      0        
Allow    Egress      0          ANY          NONE         disabled    19847    222       0        


Endpoint ID: 1199
Path: /sys/fs/bpf/tc/globals/cilium_policy_01199

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6125694   61019     0        
Allow    Ingress     1          ANY          NONE         disabled    5081483   53475     0        
Allow    Egress      0          ANY          NONE         disabled    6186648   61662     0        


Endpoint ID: 1528
Path: /sys/fs/bpf/tc/globals/cilium_policy_01528

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1713
Path: /sys/fs/bpf/tc/globals/cilium_policy_01713

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6207387   76844     0        
Allow    Ingress     1          ANY          NONE         disabled    69241     836       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1742
Path: /sys/fs/bpf/tc/globals/cilium_policy_01742

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1801
Path: /sys/fs/bpf/tc/globals/cilium_policy_01801

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


