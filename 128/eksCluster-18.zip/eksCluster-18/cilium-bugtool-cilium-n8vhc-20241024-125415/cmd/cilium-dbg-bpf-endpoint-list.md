IP ADDRESS         LOCAL ENDPOINT INFO
172.31.181.251:0   (localhost)                                                                                        
10.18.0.108:0      id=489   sec_id=1270915 flags=0x0000 ifindex=14  mac=E2:DF:39:AC:EF:E8 nodemac=B2:9F:B3:91:91:D1   
10.18.0.163:0      (localhost)                                                                                        
10.18.0.89:0       id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52   
10.18.0.27:0       id=468   sec_id=1270915 flags=0x0000 ifindex=12  mac=F6:BA:20:C4:DC:8F nodemac=6A:B7:88:85:CA:8B   
10.18.0.190:0      id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49   
10.18.0.42:0       id=1713  sec_id=4     flags=0x0000 ifindex=10  mac=5A:25:D0:80:54:D4 nodemac=8E:21:E2:AC:DD:41     
10.18.0.162:0      id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C   
172.31.174.175:0   (localhost)                                                                                        
10.18.0.22:0       id=1199  sec_id=1286784 flags=0x0000 ifindex=18  mac=BA:83:40:E8:1E:9F nodemac=EA:E5:ED:8F:BF:0F   
