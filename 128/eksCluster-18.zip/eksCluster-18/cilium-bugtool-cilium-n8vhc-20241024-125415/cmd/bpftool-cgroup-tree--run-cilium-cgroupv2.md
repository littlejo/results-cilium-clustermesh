CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca2d722c_b6a6_4cf6_ad53_f83f1f54588d.slice/cri-containerd-a81ba7e6a0c18b93e73c3af84113ef22258a28a763c2d9465ff579363552c721.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca2d722c_b6a6_4cf6_ad53_f83f1f54588d.slice/cri-containerd-a7a94d840799b74ae5c704049dbc22669091cd7b1707d5d0c73a715ac14d645b.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb5a5f99_46ea_46f0_aa7e_5d8e6c8d37a4.slice/cri-containerd-96ad918c8df522f8b5ee19adfb62ee01259e46018787b9b1af16d9ba92bea729.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb5a5f99_46ea_46f0_aa7e_5d8e6c8d37a4.slice/cri-containerd-711fca36b53920dd1d22638b3d5608ac8bc878553eac53c928879e33ab5fd3ba.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b7f03ec_0305_49e9_af48_1c7ce827b804.slice/cri-containerd-a149a2ef1e67cc8fef2df0fc5c9b89d66c67d8ad4ff0f72020b30c41be727f60.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b7f03ec_0305_49e9_af48_1c7ce827b804.slice/cri-containerd-7ee24314710c57ab3e537b737ba4ac32fd584767f52ba1ac5290f8af415299eb.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod391be5c1_428c_42f2_9822_c6c70d136560.slice/cri-containerd-95a5a66f89bdd2fad5047f458a10ac0b68025b016baf7ed4459276a93e6fb03a.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod391be5c1_428c_42f2_9822_c6c70d136560.slice/cri-containerd-b47e77afe0410513286f0da0fe6f2d25de13689dc8e2ceb5d60dd55ea2f51f2d.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod879269a0_0376_417c_b0db_a94e28b6d657.slice/cri-containerd-d91157ba0e7fab3afb57075d1d5148729f1852756e459bf3e3137d53b026ec3c.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod879269a0_0376_417c_b0db_a94e28b6d657.slice/cri-containerd-849035d705366914baa4d7ceaa35c4353ac13ba00019adb9958a1558d2bb8cec.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod879269a0_0376_417c_b0db_a94e28b6d657.slice/cri-containerd-543645fb200a25f7a22b4622b5bdb057657d5480232469c4c750e2979a00610b.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod879269a0_0376_417c_b0db_a94e28b6d657.slice/cri-containerd-084352bf4540eb513b9d95fafe989195c359438be70155c6934b354b4af6b64e.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda60b859c_d27e_4926_b2f1_5032478ae4e3.slice/cri-containerd-f56c0a010433238149292b649e6cae84091d77b729ef42f66fb9eed04604523c.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda60b859c_d27e_4926_b2f1_5032478ae4e3.slice/cri-containerd-9d84fdd4a04297f21f899a1056c085d52d5276edc40d52ca48344b598cbd6cf0.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod306784f6_cfa9_4871_b9d0_2bd6785f1c82.slice/cri-containerd-5ea40bf69f3e0547a47abf26c282488cc8d5ae8cedcb33af787713c0aad66f2a.scope
    676      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod306784f6_cfa9_4871_b9d0_2bd6785f1c82.slice/cri-containerd-a7623e6d268fe1eb620e70b0dc31544325234d835edff583fec7428922dc395e.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64d6c8b3_8342_4a2e_b2f8_1e0b61aa6ede.slice/cri-containerd-22ed5131fa539d77146ad1af5529f607573c72bc54904df0ade44599b7255b2f.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64d6c8b3_8342_4a2e_b2f8_1e0b61aa6ede.slice/cri-containerd-cedefd9e7d14822d7007daa5e9f4ac4733043e00072a9c3780a6aec5c7d5e59e.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3decbc3e_7ac4_4542_847d_1c046bc267e4.slice/cri-containerd-57c843059f2c246f1533878918ae2e239ecfa190b99554c91005108690d40a05.scope
    680      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3decbc3e_7ac4_4542_847d_1c046bc267e4.slice/cri-containerd-4742d8883d2bce59d4247da19d3fa780306021f685903d5ae24ae3aa3443deff.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3decbc3e_7ac4_4542_847d_1c046bc267e4.slice/cri-containerd-86b64b6187c3c65a6a1c03989133ad29263cc590e05899c0db4d972cab7e4c24.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6bbe2e5a_9b44_4007_b957_62de3c91a913.slice/cri-containerd-310c2d7666acd07cac6110694de04bb21873a598b7ec203c8249fb523d68336a.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6bbe2e5a_9b44_4007_b957_62de3c91a913.slice/cri-containerd-ae6000f1404b0bc818cd54ca1130f734d68d0e70715825a52c41d476f888bfd7.scope
    102      cgroup_device   multi                                          
