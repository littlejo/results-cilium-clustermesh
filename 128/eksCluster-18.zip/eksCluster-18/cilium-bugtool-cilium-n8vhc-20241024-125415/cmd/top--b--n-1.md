top - 12:54:17 up 33 min,  0 users,  load average: 0.53, 0.52, 0.29
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 35.5 us, 35.5 sy,  0.0 ni, 29.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    281.0 free,   1058.4 used,   2496.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2596.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 297280  80828 S   6.7   7.6   1:07.68 cilium-+
    396 root      20   0 1229744   9288   2924 S   0.0   0.2   0:04.20 cilium-+
   3291 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3309 root      20   0 1240432  16048  11036 S   0.0   0.4   0:00.02 cilium-+
   3335 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3367 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
   3372 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3379 root      20   0    3852   1292   1136 R   0.0   0.0   0:00.00 bash
