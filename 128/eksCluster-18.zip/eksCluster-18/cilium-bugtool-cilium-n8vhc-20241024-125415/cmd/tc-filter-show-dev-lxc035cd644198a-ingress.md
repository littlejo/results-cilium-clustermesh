filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc035cd644198a direct-action not_in_hw id 3309 tag 098009a6013a973a jited 
