KEY             VALUE
AgentLiveness   2036815188668
UTimeOffset     3378461818359375
