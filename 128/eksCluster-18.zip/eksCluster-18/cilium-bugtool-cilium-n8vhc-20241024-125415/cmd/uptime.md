 12:54:17 up 33 min,  0 users,  load average: 0.53, 0.52, 0.29
