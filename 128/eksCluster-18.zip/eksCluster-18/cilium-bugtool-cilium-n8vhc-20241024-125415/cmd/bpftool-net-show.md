xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 500
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 496
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 485
cilium_host(7) clsact/egress cil_from_host-cilium_host id 489
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 554
lxc12126b3505b5(12) clsact/ingress cil_from_container-lxc12126b3505b5 id 538
lxc047fc9180b28(14) clsact/ingress cil_from_container-lxc047fc9180b28 id 535
lxcaba911be166d(18) clsact/ingress cil_from_container-lxcaba911be166d id 613
lxc035cd644198a(20) clsact/ingress cil_from_container-lxc035cd644198a id 3309
lxc17be4c373c59(22) clsact/ingress cil_from_container-lxc17be4c373c59 id 3245
lxc26abc31c93aa(24) clsact/ingress cil_from_container-lxc26abc31c93aa id 3312

flow_dissector:

netfilter:

