[
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3decbc3e_7ac4_4542_847d_1c046bc267e4.slice/cri-containerd-86b64b6187c3c65a6a1c03989133ad29263cc590e05899c0db4d972cab7e4c24.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3decbc3e_7ac4_4542_847d_1c046bc267e4.slice/cri-containerd-4742d8883d2bce59d4247da19d3fa780306021f685903d5ae24ae3aa3443deff.scope"
      }
    ],
    "ips": [
      "10.18.0.89"
    ],
    "name": "echo-same-node-86d9cc975c-pxjsf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca2d722c_b6a6_4cf6_ad53_f83f1f54588d.slice/cri-containerd-a81ba7e6a0c18b93e73c3af84113ef22258a28a763c2d9465ff579363552c721.scope"
      }
    ],
    "ips": [
      "10.18.0.27"
    ],
    "name": "coredns-cc6ccd49c-nwhm7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod391be5c1_428c_42f2_9822_c6c70d136560.slice/cri-containerd-b47e77afe0410513286f0da0fe6f2d25de13689dc8e2ceb5d60dd55ea2f51f2d.scope"
      }
    ],
    "ips": [
      "10.18.0.108"
    ],
    "name": "coredns-cc6ccd49c-csr9k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod879269a0_0376_417c_b0db_a94e28b6d657.slice/cri-containerd-543645fb200a25f7a22b4622b5bdb057657d5480232469c4c750e2979a00610b.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod879269a0_0376_417c_b0db_a94e28b6d657.slice/cri-containerd-d91157ba0e7fab3afb57075d1d5148729f1852756e459bf3e3137d53b026ec3c.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod879269a0_0376_417c_b0db_a94e28b6d657.slice/cri-containerd-084352bf4540eb513b9d95fafe989195c359438be70155c6934b354b4af6b64e.scope"
      }
    ],
    "ips": [
      "10.18.0.22"
    ],
    "name": "clustermesh-apiserver-84d66f64c9-qgd85",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64d6c8b3_8342_4a2e_b2f8_1e0b61aa6ede.slice/cri-containerd-22ed5131fa539d77146ad1af5529f607573c72bc54904df0ade44599b7255b2f.scope"
      }
    ],
    "ips": [
      "10.18.0.162"
    ],
    "name": "client2-57cf4468f-ks6nv",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod306784f6_cfa9_4871_b9d0_2bd6785f1c82.slice/cri-containerd-a7623e6d268fe1eb620e70b0dc31544325234d835edff583fec7428922dc395e.scope"
      }
    ],
    "ips": [
      "10.18.0.190"
    ],
    "name": "client-974f6c69d-94nxr",
    "namespace": "cilium-test-1"
  }
]

