key: 4d 00 00 00  value: bc 0c 00 00
key: d4 01 00 00  value: 20 02 00 00
key: e9 01 00 00  value: 07 02 00 00
key: af 04 00 00  value: 6b 02 00 00
key: b1 06 00 00  value: 21 02 00 00
key: ce 06 00 00  value: f4 0c 00 00
key: 09 07 00 00  value: f3 0c 00 00
Found 7 elements
