alloc: 103.29MB (108305376 bytes)
total-alloc: 3.12GB (3354579992 bytes)
sys: 227.32MB (238363988 bytes)
lookups: 0
mallocs: 75622763
frees: 74479513
heap-alloc: 103.29MB (108305376 bytes)
heap-sys: 180.79MB (189571072 bytes)
heap-idle: 54.38MB (57024512 bytes)
heap-in-use: 126.41MB (132546560 bytes)
heap-released: 10.77MB (11288576 bytes)
heap-objects: 1143250
stack-in-use: 35.19MB (36896768 bytes)
stack-sys: 35.19MB (36896768 bytes)
stack-mspan-inuse: 2.13MB (2230240 bytes)
stack-mspan-sys: 2.82MB (2953920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 947.88KB (970625 bytes)
gc-sys: 5.51MB (5780672 bytes)
next-gc: when heap-alloc >= 148.41MB (155621256 bytes)
last-gc: 2024-10-24 12:54:20.098465985 +0000 UTC
gc-pause-total: 14.698897ms
gc-pause: 62712
gc-pause-end: 1729774460098465985
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005353486275763847
enable-gc: true
debug-gc: false
