1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c5:cd:5f:34:8b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.181.251/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3405sec preferred_lft 3405sec
    inet6 fe80::4c5:cdff:fe5f:348b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:66:c5:57:2b:c1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.174.175/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::466:c5ff:fe57:2bc1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:2f:29:f5:25:ac brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c02f:29ff:fef5:25ac/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:41:37:29:da:50 brd ff:ff:ff:ff:ff:ff
    inet 10.18.0.163/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a841:37ff:fe29:da50/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 26:31:d1:e2:17:d9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2431:d1ff:fee2:17d9/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:21:e2:ac:dd:41 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8c21:e2ff:feac:dd41/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc12126b3505b5@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:b7:88:85:ca:8b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::68b7:88ff:fe85:ca8b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc047fc9180b28@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:9f:b3:91:91:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b09f:b3ff:fe91:91d1/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcaba911be166d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:e5:ed:8f:bf:0f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e8e5:edff:fe8f:bf0f/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc035cd644198a@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:ac:73:12:f1:49 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::acac:73ff:fe12:f149/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc17be4c373c59@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:70:fd:d0:69:52 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::70:fdff:fed0:6952/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc26abc31c93aa@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:c3:d0:8b:97:1c brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::d0c3:d0ff:fe8b:971c/64 scope link 
       valid_lft forever preferred_lft forever
