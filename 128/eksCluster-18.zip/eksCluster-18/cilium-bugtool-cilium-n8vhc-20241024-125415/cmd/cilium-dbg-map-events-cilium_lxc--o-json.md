{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.674Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.718Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.303Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.310Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.353Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.367Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.394Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.624Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.642Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.709Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.723Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.812Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.325Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.342Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.383Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.397Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.422Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.637Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.657Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.701Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.720Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.740Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.354Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.362Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.393Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.405Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.446Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.452Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.483Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.684Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.694Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.744Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.764Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.803Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.397Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.408Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.511Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.533Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.534Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.542Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.579Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.792Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.806Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.851Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.879Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.899Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.356Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.359Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.401Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.428Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.429Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.446Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.727Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.738Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.790Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.822Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.855Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.279Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.288Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.337Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.342Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.375Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.628Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.630Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.735Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.736Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.776Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.155Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.163Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.217Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.226Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.261Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.473Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.479Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.531Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.561Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.605Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.961Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.990Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.005Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.037Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.051Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.324Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.332Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.399Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.407Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.440Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.866Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.938Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.977Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.045Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.057Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.283Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.283Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.338Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.346Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.391Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.672Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.717Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.738Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.769Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.782Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.810Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.026Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.036Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.077Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.091Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.127Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.429Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.463Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.470Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.500Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.523Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.562Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.581Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.911Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.918Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.969Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.994Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.678Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.679Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.739Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.742Z",
  "value": "id=77    sec_id=1247705 flags=0x0000 ifindex=22  mac=AE:A8:8E:7A:60:AB nodemac=02:70:FD:D0:69:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.776Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.003Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.016Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.665Z",
  "value": "id=1801  sec_id=1246211 flags=0x0000 ifindex=20  mac=72:6C:07:71:C0:BF nodemac=AE:AC:73:12:F1:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.666Z",
  "value": "id=1742  sec_id=1251559 flags=0x0000 ifindex=24  mac=02:71:15:8C:45:0B nodemac=D2:C3:D0:8B:97:1C"
}

