filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc26abc31c93aa direct-action not_in_hw id 3312 tag 06e50ff264212efd jited 
