IP ADDRESS         LOCAL ENDPOINT INFO
10.124.0.233:0     id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2   
10.124.0.120:0     id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57   
10.124.0.190:0     id=2509  sec_id=8192195 flags=0x0000 ifindex=14  mac=8A:13:AA:4A:52:50 nodemac=5E:77:79:09:D0:13   
172.31.141.127:0   (localhost)                                                                                        
10.124.0.169:0     id=1742  sec_id=8192195 flags=0x0000 ifindex=12  mac=CE:36:08:ED:45:39 nodemac=7A:DB:73:D3:DD:7F   
10.124.0.238:0     id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B   
172.31.164.231:0   (localhost)                                                                                        
10.124.0.223:0     (localhost)                                                                                        
10.124.0.207:0     id=2246  sec_id=8205000 flags=0x0000 ifindex=18  mac=4A:9A:69:69:B4:46 nodemac=12:6A:5C:6F:33:6C   
10.124.0.214:0     id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=BE:81:18:8F:44:7D nodemac=6E:E4:7A:03:5F:AD     
