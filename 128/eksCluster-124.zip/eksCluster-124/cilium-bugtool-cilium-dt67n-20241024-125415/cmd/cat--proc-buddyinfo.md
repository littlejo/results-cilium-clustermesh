Node 0, zone      DMA    298    129     19     16      8     11      6      2      1      4     43 
Node 0, zone   Normal    213     17     23      2      6      9      4      0      4      1      8 
