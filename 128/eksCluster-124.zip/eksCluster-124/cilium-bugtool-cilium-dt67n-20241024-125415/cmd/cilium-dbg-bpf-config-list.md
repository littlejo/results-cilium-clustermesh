KEY             VALUE
AgentLiveness   1870713643006
UTimeOffset     3378462142578125
