key: eb 01 00 00  value: 09 0d 00 00
key: 15 05 00 00  value: 0d 0d 00 00
key: ce 06 00 00  value: 26 02 00 00
key: c6 08 00 00  value: 77 02 00 00
key: 50 09 00 00  value: 0a 02 00 00
key: cd 09 00 00  value: 06 02 00 00
key: 8b 0d 00 00  value: cf 0c 00 00
Found 7 elements
