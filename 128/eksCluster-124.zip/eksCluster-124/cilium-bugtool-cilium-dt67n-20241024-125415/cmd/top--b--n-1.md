top - 12:54:16 up 30 min,  0 users,  load average: 0.45, 0.40, 0.22
Tasks:   6 total,   2 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 54.8 us, 22.6 sy,  0.0 ni,  9.7 id,  0.0 wa,  0.0 hi, 12.9 si,  0.0 st
MiB Mem :   3836.2 total,    292.5 free,   1047.2 used,   2496.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2608.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 293548  79616 S  53.3   7.5   1:02.21 cilium-+
    398 root      20   0 1229744   8864   2864 S   0.0   0.2   0:04.36 cilium-+
   3256 root      20   0 1240432  16580  11356 S   0.0   0.4   0:00.02 cilium-+
   3276 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
   3310 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3329 root      20   0    3852   2868   2608 R   0.0   0.1   0:00.00 bash
