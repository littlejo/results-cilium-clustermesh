CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81b287d6_c571_4a47_b0dc_592fba541d9c.slice/cri-containerd-935f91fd0d9dec6fa8aca44c78a7043c628ad363f41a5e9c8476b2bceb513a8c.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81b287d6_c571_4a47_b0dc_592fba541d9c.slice/cri-containerd-ad790e54c116c6cf96b2d712c4ce57dc52747d776fa35bb28f8641e78499bfe9.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbd900b2_0cb9_4680_a5a7_3a15a7f7efd8.slice/cri-containerd-839fa1fc947d24429bc01f19244bb5869b3fa406a9e54d5f2d4263c8e2c0df7e.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbd900b2_0cb9_4680_a5a7_3a15a7f7efd8.slice/cri-containerd-74a70c89c86253cf185833af5762c24a4ac468656ed11194276cb8f8c03e8ce9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2017ac4_1e5f_4435_9945_dedfba4d73d0.slice/cri-containerd-0018926f61765e965fb7cdd19da9f76f93656931da2311ff9037d408cd3b1199.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2017ac4_1e5f_4435_9945_dedfba4d73d0.slice/cri-containerd-b0611361afe72889fd7c445686060a54fe07b2f12c4bdc50442a6328933f9ee7.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f5c2c2c_98a7_4950_87aa_75894d8f42a3.slice/cri-containerd-67043e6e5139f910532e4eead3e8e128d4fd47b59a5d097ab96b0ddce9baacf1.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f5c2c2c_98a7_4950_87aa_75894d8f42a3.slice/cri-containerd-ebea93eab3d8d6601cb4ffa035a9f8b4ebd4b5bf931b6e9fddd1f69860581b42.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod931621e5_e586_4e59_92d9_71f9e69fe0a9.slice/cri-containerd-458a2a1b51e1fa2456a712d2b97931a5d618322d5c2d5516a7df18753b94867c.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod931621e5_e586_4e59_92d9_71f9e69fe0a9.slice/cri-containerd-18fbab109f6a53b29da52bd2e7c62e13271f71d1d46282484216f6673c3fbbc7.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5fa80e28_46b0_47fb_9bc9_a22d168c38c5.slice/cri-containerd-37c2d99ca9f2aa2d24e7d9af3b93714ee51cbb156f9155fe8bf7a346e47c3ef6.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5fa80e28_46b0_47fb_9bc9_a22d168c38c5.slice/cri-containerd-17035db4e9f2506978f5481ff5be9cace2fc7675d52c53b37c1adf7f917b0eb0.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5608d7c7_d015_4061_9148_b5aefd943eea.slice/cri-containerd-67af5c378906431720b2383da53cb2383d75e1e6bf7b60f828aa46f34147f414.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5608d7c7_d015_4061_9148_b5aefd943eea.slice/cri-containerd-e6e864d7af78c59722102f6cc716ec6fb3462f3798251131cdcee94c4b63b9be.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5608d7c7_d015_4061_9148_b5aefd943eea.slice/cri-containerd-0f8e0a20de15c9c18c76d307c06a570db839fbdcac063e74db439630ef9c15be.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5608d7c7_d015_4061_9148_b5aefd943eea.slice/cri-containerd-1638a706f4e3200855aa9dfcaff089ae638720f550e443b716ff4aebaf7e72d0.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod246e0f90_0014_40c6_9bad_851960655493.slice/cri-containerd-2f03810e8fb8fd7d693b5d845fa2c161838f71d1c79590a12150fff2405ced26.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod246e0f90_0014_40c6_9bad_851960655493.slice/cri-containerd-b82db3579315d326522062584be6bc8cce2843bc8f40cab91d1bae258d026c28.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod246e0f90_0014_40c6_9bad_851960655493.slice/cri-containerd-047ea336918d15b20df691b5f5f6a1c3b3884fe9d066e2f54bbd6153a1a65b1e.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a64878b_72cf_4813_be45_47ef3653b6ce.slice/cri-containerd-015256d473b9ad968f4f953489ba10d9b35b67ed5a568566a4e976ea15576d59.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a64878b_72cf_4813_be45_47ef3653b6ce.slice/cri-containerd-320748299f05f66523062ee1170a76c04aaa3045242486e90397283e192c19f1.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod244444a9_b6c3_4bdf_b99f_59cbcf684c32.slice/cri-containerd-f01f4f3252a828db1e0629ddb249010d97700024e34f313c94f0473e95a8b820.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod244444a9_b6c3_4bdf_b99f_59cbcf684c32.slice/cri-containerd-da2a636f3b13e77102ed27176255603c2d3aca0ac5422392a00f9b8b0ec82801.scope
    713      cgroup_device   multi                                          
