[
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod246e0f90_0014_40c6_9bad_851960655493.slice/cri-containerd-2f03810e8fb8fd7d693b5d845fa2c161838f71d1c79590a12150fff2405ced26.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod246e0f90_0014_40c6_9bad_851960655493.slice/cri-containerd-b82db3579315d326522062584be6bc8cce2843bc8f40cab91d1bae258d026c28.scope"
      }
    ],
    "ips": [
      "10.124.0.238"
    ],
    "name": "echo-same-node-86d9cc975c-m4grr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2017ac4_1e5f_4435_9945_dedfba4d73d0.slice/cri-containerd-b0611361afe72889fd7c445686060a54fe07b2f12c4bdc50442a6328933f9ee7.scope"
      }
    ],
    "ips": [
      "10.124.0.169"
    ],
    "name": "coredns-cc6ccd49c-6drqr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5608d7c7_d015_4061_9148_b5aefd943eea.slice/cri-containerd-0f8e0a20de15c9c18c76d307c06a570db839fbdcac063e74db439630ef9c15be.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5608d7c7_d015_4061_9148_b5aefd943eea.slice/cri-containerd-67af5c378906431720b2383da53cb2383d75e1e6bf7b60f828aa46f34147f414.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5608d7c7_d015_4061_9148_b5aefd943eea.slice/cri-containerd-e6e864d7af78c59722102f6cc716ec6fb3462f3798251131cdcee94c4b63b9be.scope"
      }
    ],
    "ips": [
      "10.124.0.207"
    ],
    "name": "clustermesh-apiserver-74b4f4d654-wrqff",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81b287d6_c571_4a47_b0dc_592fba541d9c.slice/cri-containerd-ad790e54c116c6cf96b2d712c4ce57dc52747d776fa35bb28f8641e78499bfe9.scope"
      }
    ],
    "ips": [
      "10.124.0.190"
    ],
    "name": "coredns-cc6ccd49c-l42qc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod244444a9_b6c3_4bdf_b99f_59cbcf684c32.slice/cri-containerd-da2a636f3b13e77102ed27176255603c2d3aca0ac5422392a00f9b8b0ec82801.scope"
      }
    ],
    "ips": [
      "10.124.0.233"
    ],
    "name": "client-974f6c69d-95s2b",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod931621e5_e586_4e59_92d9_71f9e69fe0a9.slice/cri-containerd-458a2a1b51e1fa2456a712d2b97931a5d618322d5c2d5516a7df18753b94867c.scope"
      }
    ],
    "ips": [
      "10.124.0.120"
    ],
    "name": "client2-57cf4468f-wwgm8",
    "namespace": "cilium-test-1"
  }
]

