markdown output at /tmp/cilium-bugtool-20241024-125416.708+0000-UTC-2985838084/cmd/cilium-debuginfo-20241024-125447.638+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.708+0000-UTC-2985838084/cmd/cilium-debuginfo-20241024-125447.638+0000-UTC.json
