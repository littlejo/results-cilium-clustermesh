xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 563
cilium_host(7) clsact/egress cil_from_host-cilium_host id 565
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 521
lxc502184e3784a(12) clsact/ingress cil_from_container-lxc502184e3784a id 542
lxc293c21a62e21(14) clsact/ingress cil_from_container-lxc293c21a62e21 id 519
lxc0cd42c1c5dc7(18) clsact/ingress cil_from_container-lxc0cd42c1c5dc7 id 630
lxc6d82fe1e4aa3(20) clsact/ingress cil_from_container-lxc6d82fe1e4aa3 id 3325
lxc2545275b4646(22) clsact/ingress cil_from_container-lxc2545275b4646 id 3334
lxc84d84746634f(24) clsact/ingress cil_from_container-lxc84d84746634f id 3271

flow_dissector:

netfilter:

