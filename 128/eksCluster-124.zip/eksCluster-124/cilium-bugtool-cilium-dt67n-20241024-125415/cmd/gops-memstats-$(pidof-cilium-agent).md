alloc: 94.50MB (99086744 bytes)
total-alloc: 3.05GB (3277083872 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74617065
frees: 73708112
heap-alloc: 94.50MB (99086744 bytes)
heap-sys: 172.51MB (180887552 bytes)
heap-idle: 48.45MB (50798592 bytes)
heap-in-use: 124.06MB (130088960 bytes)
heap-released: 5.34MB (5603328 bytes)
heap-objects: 908953
stack-in-use: 35.47MB (37191680 bytes)
stack-sys: 35.47MB (37191680 bytes)
stack-mspan-inuse: 2.08MB (2177600 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 984.12KB (1007737 bytes)
gc-sys: 5.52MB (5788840 bytes)
next-gc: when heap-alloc >= 149.41MB (156662616 bytes)
last-gc: 2024-10-24 12:54:27.02186901 +0000 UTC
gc-pause-total: 17.210625ms
gc-pause: 72632
gc-pause-end: 1729774467021869010
num-gc: 97
num-forced-gc: 0
gc-cpu-fraction: 0.0007151579668641259
enable-gc: true
debug-gc: false
