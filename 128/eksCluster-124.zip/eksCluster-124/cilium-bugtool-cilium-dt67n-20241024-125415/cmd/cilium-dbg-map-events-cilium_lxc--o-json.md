{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.303Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.304Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.350Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.909Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.957Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.971Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.020Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.033Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.064Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.326Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.344Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.408Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.423Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.461Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.998Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.033Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.051Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.088Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.095Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.321Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.328Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.378Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.399Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.427Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.029Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.033Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.070Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.075Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.119Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.120Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.123Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.379Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.400Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.455Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.483Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.559Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.080Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.087Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.136Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.143Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.176Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.393Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.396Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.446Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.469Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.505Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.910Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.911Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.951Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.985Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.996Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.256Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.265Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.325Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.329Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.364Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.800Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.821Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.919Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.942Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.963Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.137Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.138Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.198Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.205Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.238Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.655Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.689Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.700Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.743Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.771Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.786Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.047Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.057Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.098Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.121Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.168Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.484Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.524Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.528Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.569Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.596Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.615Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.952Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.964Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.064Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.071Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.102Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.457Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.493Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.501Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.554Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.563Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.820Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.844Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.865Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.896Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.933Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.235Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.273Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.280Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.321Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.328Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.358Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.562Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.580Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.626Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.627Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.674Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.027Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.050Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.085Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.106Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.123Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.376Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.378Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.395Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.400Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.419Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.226Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.229Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.263Z",
  "value": "id=3467  sec_id=8193520 flags=0x0000 ifindex=24  mac=EA:E0:0E:2A:23:98 nodemac=B6:2E:82:B0:4F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.271Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.307Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.587Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.600Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.273Z",
  "value": "id=491   sec_id=8244869 flags=0x0000 ifindex=22  mac=FA:06:86:F1:EA:7F nodemac=3E:5A:8E:24:F0:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.285Z",
  "value": "id=1301  sec_id=8221036 flags=0x0000 ifindex=20  mac=0A:A9:43:88:92:37 nodemac=0A:0B:54:A6:28:A2"
}

