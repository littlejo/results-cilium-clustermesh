Endpoint ID: 39
Path: /sys/fs/bpf/tc/globals/cilium_policy_00039

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 491
Path: /sys/fs/bpf/tc/globals/cilium_policy_00491

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1301
Path: /sys/fs/bpf/tc/globals/cilium_policy_01301

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1742
Path: /sys/fs/bpf/tc/globals/cilium_policy_01742

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3444     34        0        
Allow    Ingress     1          ANY          NONE         disabled    115531   1325      0        
Allow    Egress      0          ANY          NONE         disabled    18186    199       0        


Endpoint ID: 2246
Path: /sys/fs/bpf/tc/globals/cilium_policy_02246

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6063926   60019     0        
Allow    Ingress     1          ANY          NONE         disabled    5029777   52845     0        
Allow    Egress      0          ANY          NONE         disabled    5916349   59270     0        


Endpoint ID: 2384
Path: /sys/fs/bpf/tc/globals/cilium_policy_02384

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6228197   76819     0        
Allow    Ingress     1          ANY          NONE         disabled    60853     735       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2509
Path: /sys/fs/bpf/tc/globals/cilium_policy_02509

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2452     26        0        
Allow    Ingress     1          ANY          NONE         disabled    114871   1315      0        
Allow    Egress      0          ANY          NONE         disabled    17886    195       0        


Endpoint ID: 3467
Path: /sys/fs/bpf/tc/globals/cilium_policy_03467

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378213   4404      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


