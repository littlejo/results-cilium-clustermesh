1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b5:ee:16:8f:7d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.164.231/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3570sec preferred_lft 3570sec
    inet6 fe80::4b5:eeff:fe16:8f7d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:0e:fe:ec:7f:e1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.141.127/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::40e:feff:feec:7fe1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:ff:22:9b:19:01 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::40ff:22ff:fe9b:1901/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:d4:e2:09:5c:aa brd ff:ff:ff:ff:ff:ff
    inet 10.124.0.223/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e4d4:e2ff:fe09:5caa/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f2:d7:7b:5b:52:57 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f0d7:7bff:fe5b:5257/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:e4:7a:03:5f:ad brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6ce4:7aff:fe03:5fad/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc502184e3784a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:db:73:d3:dd:7f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::78db:73ff:fed3:dd7f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc293c21a62e21@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:77:79:09:d0:13 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5c77:79ff:fe09:d013/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0cd42c1c5dc7@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:6a:5c:6f:33:6c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::106a:5cff:fe6f:336c/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc6d82fe1e4aa3@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:0b:54:a6:28:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::80b:54ff:fea6:28a2/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc2545275b4646@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:5a:8e:24:f0:57 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::3c5a:8eff:fe24:f057/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc84d84746634f@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:2e:82:b0:4f:5b brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::b42e:82ff:feb0:4f5b/64 scope link 
       valid_lft forever preferred_lft forever
