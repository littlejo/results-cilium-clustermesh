 12:54:16 up 30 min,  0 users,  load average: 0.45, 0.40, 0.22
