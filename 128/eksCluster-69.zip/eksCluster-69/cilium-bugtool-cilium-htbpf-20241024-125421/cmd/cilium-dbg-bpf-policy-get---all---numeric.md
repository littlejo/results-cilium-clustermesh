Endpoint ID: 343
Path: /sys/fs/bpf/tc/globals/cilium_policy_00343

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2628     28        0        
Allow    Ingress     1          ANY          NONE         disabled    145314   1674      0        
Allow    Egress      0          ANY          NONE         disabled    20147    222       0        


Endpoint ID: 750
Path: /sys/fs/bpf/tc/globals/cilium_policy_00750

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6092486   61696     0        
Allow    Ingress     1          ANY          NONE         disabled    5619989   59435     0        
Allow    Egress      0          ANY          NONE         disabled    7437104   72763     0        


Endpoint ID: 1379
Path: /sys/fs/bpf/tc/globals/cilium_policy_01379

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6230096   76988     0        
Allow    Ingress     1          ANY          NONE         disabled    62218     753       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1843
Path: /sys/fs/bpf/tc/globals/cilium_policy_01843

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2406
Path: /sys/fs/bpf/tc/globals/cilium_policy_02406

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382179   4460      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3167
Path: /sys/fs/bpf/tc/globals/cilium_policy_03167

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3268     32        0        
Allow    Ingress     1          ANY          NONE         disabled    145213   1677      0        
Allow    Egress      0          ANY          NONE         disabled    19736    218       0        


Endpoint ID: 3555
Path: /sys/fs/bpf/tc/globals/cilium_policy_03555

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3825
Path: /sys/fs/bpf/tc/globals/cilium_policy_03825

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


