top - 12:54:23 up 32 min,  0 users,  load average: 0.52, 0.65, 0.39
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.2 us, 40.6 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.1 si,  0.0 st
MiB Mem :   3836.2 total,    269.7 free,   1069.3 used,   2497.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2585.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3233 root      20   0 1244340  24116  14528 S  43.8   0.6   0:00.14 hubble
      1 root      20   0 1539060 291888  78580 S  12.5   7.4   1:08.16 cilium-+
    393 root      20   0 1229744  10252   3836 S   0.0   0.3   0:04.49 cilium-+
   3199 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3205 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3216 root      20   0 1240432  15512  10768 S   0.0   0.4   0:00.02 cilium-+
   3217 root      20   0    2208    792    712 S   0.0   0.0   0:00.00 timeout
   3258 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
   3264 root      20   0    3852   1296   1136 R   0.0   0.0   0:00.00 bash
   3265 root      20   0       4      4      0 R   0.0   0.0   0:00.00 bash
