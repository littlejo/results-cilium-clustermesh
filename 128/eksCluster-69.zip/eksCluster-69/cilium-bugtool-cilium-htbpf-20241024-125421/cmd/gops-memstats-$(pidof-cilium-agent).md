alloc: 122.39MB (128331296 bytes)
total-alloc: 3.09GB (3320601552 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75308293
frees: 74007476
heap-alloc: 122.39MB (128331296 bytes)
heap-sys: 172.42MB (180797440 bytes)
heap-idle: 28.98MB (30384128 bytes)
heap-in-use: 143.45MB (150413312 bytes)
heap-released: 6.91MB (7249920 bytes)
heap-objects: 1300817
stack-in-use: 35.53MB (37257216 bytes)
stack-sys: 35.53MB (37257216 bytes)
stack-mspan-inuse: 2.35MB (2468960 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 945.31KB (967993 bytes)
gc-sys: 5.52MB (5792864 bytes)
next-gc: when heap-alloc >= 151.20MB (158540792 bytes)
last-gc: 2024-10-24 12:54:24.136713414 +0000 UTC
gc-pause-total: 10.169491ms
gc-pause: 80394
gc-pause-end: 1729774464136713414
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.000603451186536396
enable-gc: true
debug-gc: false
