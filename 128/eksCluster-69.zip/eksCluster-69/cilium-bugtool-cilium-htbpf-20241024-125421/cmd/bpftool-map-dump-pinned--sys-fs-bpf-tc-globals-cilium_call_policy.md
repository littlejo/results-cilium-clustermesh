key: 57 01 00 00  value: 21 02 00 00
key: ee 02 00 00  value: 67 02 00 00
key: 63 05 00 00  value: 25 02 00 00
key: 66 09 00 00  value: ce 0c 00 00
key: 5f 0c 00 00  value: 0f 02 00 00
key: e3 0d 00 00  value: 11 0d 00 00
key: f1 0e 00 00  value: 14 0d 00 00
Found 7 elements
