USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3217  0.0  0.0   2208   792 ?        Ss   12:54   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root        3233  0.0  0.5 1244340 19984 ?       Sl   12:54   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root        3216  0.0  0.3 1240176 15308 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3247  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3248  0.0  0.3 1240176 15308 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3205  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3199  0.0  0.0 1228744 3780 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.5  7.4 1539060 291888 ?      Ssl  12:29   1:08 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.3  0.2 1229744 10252 ?       Sl   12:29   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
