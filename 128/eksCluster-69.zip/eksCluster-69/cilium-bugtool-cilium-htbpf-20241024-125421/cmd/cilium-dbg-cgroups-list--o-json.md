[
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0639c91_6346_46d3_af1b_cf761f56a25e.slice/cri-containerd-6c3bdb4c53fb6246e7b114678c99e815604305ff46bc4a01861440ff6ab1e50d.scope"
      }
    ],
    "ips": [
      "10.69.0.48"
    ],
    "name": "client2-57cf4468f-s9927",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod197d38d0_7dcc_41c4_a9da_c494951f554c.slice/cri-containerd-ad4e692fff4900fb080ddd273c16464d667fbc0eb5c3d9237d5afa81bf2eabbc.scope"
      }
    ],
    "ips": [
      "10.69.0.55"
    ],
    "name": "client-974f6c69d-kkkmq",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4335ae16_b246_4e07_9223_fa3c3610616b.slice/cri-containerd-778e3de433e5fe94471a9ba023b639172c2a91294ba75036546daebf13ba3f08.scope"
      }
    ],
    "ips": [
      "10.69.0.47"
    ],
    "name": "coredns-cc6ccd49c-t2mn9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff51ec_e59a_4d9f_beba_338563767231.slice/cri-containerd-99d988e941fe38dbbc8af7935de0e87f3762826767dd450ae0fc90439e4a32d4.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff51ec_e59a_4d9f_beba_338563767231.slice/cri-containerd-652ccfc7968427acfbf894c7fcd164494855ed1ca97551f51e33d4eb3456881c.scope"
      }
    ],
    "ips": [
      "10.69.0.180"
    ],
    "name": "echo-same-node-86d9cc975c-npwvg",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31a77a8f_fc3d_49ef_8f59_c451760ecd11.slice/cri-containerd-d9052dc33eeb85114e8543f4eb769853aded242d4f095070322cb34fd37bd5f2.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31a77a8f_fc3d_49ef_8f59_c451760ecd11.slice/cri-containerd-3e6e5ef0a927f4dc11cb76924063aacc4afc65cbecd5ba1ead5f5a2cf86107dc.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31a77a8f_fc3d_49ef_8f59_c451760ecd11.slice/cri-containerd-07863ed20d3abb2c720e07e496a80deba3b2eb24f8827038562ac1117f92ad57.scope"
      }
    ],
    "ips": [
      "10.69.0.197"
    ],
    "name": "clustermesh-apiserver-5cc7d59fb7-6g4g2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod899a9bce_7711_46e2_8d32_13f40aaaa40b.slice/cri-containerd-cca9672df0aadb9d0e05d67631ebf1c4288945f35e22e8e970edbcb43352bf7b.scope"
      }
    ],
    "ips": [
      "10.69.0.9"
    ],
    "name": "coredns-cc6ccd49c-z5w4q",
    "namespace": "kube-system"
  }
]

