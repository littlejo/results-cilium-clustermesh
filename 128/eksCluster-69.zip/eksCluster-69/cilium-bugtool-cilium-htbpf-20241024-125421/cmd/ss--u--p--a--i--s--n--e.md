Total: 565
TCP:   3521 (estab 305, closed 3197, orphaned 0, timewait 2730)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  324       314       10       
INET	  334       320       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                           127.0.0.1:43329      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31737 sk:685 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15751 sk:686 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                  172.31.223.68%ens5:68         0.0.0.0:*    uid:192 ino:115238 sk:687 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:32902 sk:688 cgroup:/ <->                                                  
UNCONN 0      0                               [::1]:323           [::]:*    ino:15752 sk:689 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::882:fff:fee4:4ded]%ens5:546           [::]:*    uid:192 ino:15145 sk:68a cgroup:unreachable:bd0 v6only:1 <->                   
UNCONN 0      0                                [::]:8472          [::]:*    ino:32901 sk:68b cgroup:/ v6only:1 <->                                         
