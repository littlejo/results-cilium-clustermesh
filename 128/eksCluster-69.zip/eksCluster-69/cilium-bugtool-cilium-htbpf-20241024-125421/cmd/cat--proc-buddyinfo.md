Node 0, zone      DMA      3      3     47     45     15      9      4      5      2      3     36 
Node 0, zone   Normal    419     63     20      1      4      2      2      3      3      3      7 
