 12:54:23 up 32 min,  0 users,  load average: 0.52, 0.65, 0.39
