IP ADDRESS         LOCAL ENDPOINT INFO
10.69.0.180:0      id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D   
172.31.239.159:0   (localhost)                                                                                        
10.69.0.125:0      id=1379  sec_id=4     flags=0x0000 ifindex=10  mac=FA:99:A0:A4:A2:57 nodemac=36:7D:43:33:30:00     
10.69.0.47:0       id=343   sec_id=4593916 flags=0x0000 ifindex=14  mac=4A:42:01:7C:6E:F3 nodemac=1A:D5:32:FA:D2:FE   
172.31.223.68:0    (localhost)                                                                                        
10.69.0.55:0       id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72   
10.69.0.197:0      id=750   sec_id=4594334 flags=0x0000 ifindex=18  mac=5A:41:BC:D5:95:D4 nodemac=DE:23:DF:76:7C:ED   
10.69.0.131:0      (localhost)                                                                                        
10.69.0.9:0        id=3167  sec_id=4593916 flags=0x0000 ifindex=12  mac=26:20:A8:EA:A8:7E nodemac=C6:90:B0:74:AE:F4   
10.69.0.48:0       id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5   
