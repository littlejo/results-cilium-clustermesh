1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:82:0f:e4:4d:ed brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.223.68/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3472sec preferred_lft 3472sec
    inet6 fe80::882:fff:fee4:4ded/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:be:92:be:bb:53 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.239.159/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8be:92ff:febe:bb53/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:6b:9a:d0:7b:56 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::286b:9aff:fed0:7b56/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:4e:3f:a4:34:ee brd ff:ff:ff:ff:ff:ff
    inet 10.69.0.131/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a84e:3fff:fea4:34ee/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f2:e4:53:59:04:3d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f0e4:53ff:fe59:43d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:7d:43:33:30:00 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::347d:43ff:fe33:3000/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8d8b3e4b123a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:90:b0:74:ae:f4 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c490:b0ff:fe74:aef4/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce056135bac62@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:d5:32:fa:d2:fe brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::18d5:32ff:fefa:d2fe/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc860a9c3f9d11@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:23:df:76:7c:ed brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::dc23:dfff:fe76:7ced/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcfcd0c83e1200@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:43:4c:0d:96:72 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::4c43:4cff:fe0d:9672/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc539949a7acb4@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:85:d7:3d:59:c5 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::1885:d7ff:fe3d:59c5/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc96b3580ddadc@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:dd:aa:94:3a:8d brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::c0dd:aaff:fe94:3a8d/64 scope link 
       valid_lft forever preferred_lft forever
