xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 499
ens6(5) clsact/ingress cil_from_netdev-ens6 id 503
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 491
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 482
cilium_host(7) clsact/egress cil_from_host-cilium_host id 483
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 539
lxc8d8b3e4b123a(12) clsact/ingress cil_from_container-lxc8d8b3e4b123a id 510
lxce056135bac62(14) clsact/ingress cil_from_container-lxce056135bac62 id 535
lxc860a9c3f9d11(18) clsact/ingress cil_from_container-lxc860a9c3f9d11 id 614
lxcfcd0c83e1200(20) clsact/ingress cil_from_container-lxcfcd0c83e1200 id 3347
lxc539949a7acb4(22) clsact/ingress cil_from_container-lxc539949a7acb4 id 3337
lxc96b3580ddadc(24) clsact/ingress cil_from_container-lxc96b3580ddadc id 3281

flow_dissector:

netfilter:

