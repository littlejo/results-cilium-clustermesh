REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     130430    10568251    677    bpf_overlay.c
Interface                   INGRESS     669129    247635208   1132   bpf_host.c
Policy denied               EGRESS      61        4514        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      129749    10508448    53     encap.h
Success                     EGRESS      153964    20177877    1308   bpf_lxc.c
Success                     EGRESS      54114     4383783     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     178325    20547697    86     l3.h
Success                     INGRESS     255868    26930934    235    trace.h
Unsupported L3 protocol     EGRESS      77        5854        1492   bpf_lxc.c
