filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc96b3580ddadc direct-action not_in_hw id 3281 tag 0535ea0016e0a7da jited 
