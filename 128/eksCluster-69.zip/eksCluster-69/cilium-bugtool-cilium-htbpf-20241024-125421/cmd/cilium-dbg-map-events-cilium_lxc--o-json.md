{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.191Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.825Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.853Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.875Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.917Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.920Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.127Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.141Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.195Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.215Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.266Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.854Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.856Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.906Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.909Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.953Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.980Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.989Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.357Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.379Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.422Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.435Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.459Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.991Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.995Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.029Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.037Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.083Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.086Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.119Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.361Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.383Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.439Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.452Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.491Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.072Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.081Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.111Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.133Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.151Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.199Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.199Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.521Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.532Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.585Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.618Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.642Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.010Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.046Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.060Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.085Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.105Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.335Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.349Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.380Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.416Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.447Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.886Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.903Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.933Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.959Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.974Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.272Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.326Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.351Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.376Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.407Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.781Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.817Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.841Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.882Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.891Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.919Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.118Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.138Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.181Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.211Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.223Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.591Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.625Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.642Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.680Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.690Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.719Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.947Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.988Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.031Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.119Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.143Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.517Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.565Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.571Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.614Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.629Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.660Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.880Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.888Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.944Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.966Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.988Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.333Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.353Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.386Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.413Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.440Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.649Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.658Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.712Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.720Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.757Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.102Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.110Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.155Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.171Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.215Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.440Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.465Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.470Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.505Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.197Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.200Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.234Z",
  "value": "id=2406  sec_id=4628227 flags=0x0000 ifindex=24  mac=42:7B:ED:6A:84:1A nodemac=C2:DD:AA:94:3A:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.257Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.287Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.555Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.563Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.249Z",
  "value": "id=3555  sec_id=4609198 flags=0x0000 ifindex=20  mac=DE:7C:A0:EA:8D:91 nodemac=4E:43:4C:0D:96:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.254Z",
  "value": "id=3825  sec_id=4603413 flags=0x0000 ifindex=22  mac=DA:69:F4:3E:DC:5D nodemac=1A:85:D7:3D:59:C5"
}

