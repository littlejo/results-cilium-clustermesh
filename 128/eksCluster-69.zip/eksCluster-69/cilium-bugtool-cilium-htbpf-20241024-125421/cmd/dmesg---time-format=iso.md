2024-10-24T12:22:06,000000+00:00 Booting Linux on physical CPU 0x0000000000 [0x413fd0c1]
2024-10-24T12:22:06,000000+00:00 Linux version 6.1.112-122.189.amzn2023.aarch64 (mockbuild@ip-10-0-39-248) (gcc (GCC) 11.4.1 20230605 (Red Hat 11.4.1-2), GNU ld version 2.39-6.amzn2023.0.10) #1 SMP Tue Oct  8 17:01:34 UTC 2024
2024-10-24T12:22:06,000000+00:00 efi: EFI v2.70 by EDK II
2024-10-24T12:22:06,000000+00:00 efi: SMBIOS=0x7bed0000 SMBIOS 3.0=0x7beb0000 ACPI=0x786e0000 ACPI 2.0=0x786e0014 MEMATTR=0x7aff0a98 RNG=0x74ca0018 MEMRESERVE=0x784d0d98 
2024-10-24T12:22:06,000000+00:00 random: crng init done
2024-10-24T12:22:06,000000+00:00 ACPI: Early table checksum verification disabled
2024-10-24T12:22:06,000000+00:00 ACPI: RSDP 0x00000000786E0014 000024 (v02 AMAZON)
2024-10-24T12:22:06,000000+00:00 ACPI: XSDT 0x00000000786D00E8 000064 (v01 AMAZON AMZNFACP 00000001      01000013)
2024-10-24T12:22:06,000000+00:00 ACPI: FACP 0x00000000786B0000 000114 (v06 AMAZON AMZNFACP 00000001 AMZN 00000001)
2024-10-24T12:22:06,000000+00:00 ACPI: DSDT 0x0000000078640000 00159D (v02 AMAZON AMZNDSDT 00000001 INTL 20160527)
2024-10-24T12:22:06,000000+00:00 ACPI: FACS 0x0000000078630000 000040
2024-10-24T12:22:06,000000+00:00 ACPI: APIC 0x00000000786C0000 000108 (v04 AMAZON AMZNAPIC 00000001 AMZN 00000001)
2024-10-24T12:22:06,000000+00:00 ACPI: SPCR 0x00000000786A0000 000050 (v02 AMAZON AMZNSPCR 00000001 AMZN 00000001)
2024-10-24T12:22:06,000000+00:00 ACPI: GTDT 0x0000000078690000 000060 (v02 AMAZON AMZNGTDT 00000001 AMZN 00000001)
2024-10-24T12:22:06,000000+00:00 ACPI: MCFG 0x0000000078680000 00003C (v02 AMAZON AMZNMCFG 00000001 AMZN 00000001)
2024-10-24T12:22:06,000000+00:00 ACPI: SLIT 0x0000000078670000 00002D (v01 AMAZON AMZNSLIT 00000001 AMZN 00000001)
2024-10-24T12:22:06,000000+00:00 ACPI: IORT 0x0000000078660000 000078 (v01 AMAZON AMZNIORT 00000001 AMZN 00000001)
2024-10-24T12:22:06,000000+00:00 ACPI: PPTT 0x0000000078650000 0000D4 (v02 AMAZON AMZNPPTT 00000001 AMZN 00000001)
2024-10-24T12:22:06,000000+00:00 ACPI: SPCR: console: uart,mmio,0x90a0000,115200
2024-10-24T12:22:06,000000+00:00 NUMA: Failed to initialise from firmware
2024-10-24T12:22:06,000000+00:00 NUMA: Faking a node at [mem 0x0000000040000000-0x00000004bb7fffff]
2024-10-24T12:22:06,000000+00:00 NUMA: NODE_DATA [mem 0x4bb01a7c0-0x4bb01cfff]
2024-10-24T12:22:06,000000+00:00 Zone ranges:
2024-10-24T12:22:06,000000+00:00   DMA      [mem 0x0000000040000000-0x00000000ffffffff]
2024-10-24T12:22:06,000000+00:00   DMA32    empty
2024-10-24T12:22:06,000000+00:00   Normal   [mem 0x0000000100000000-0x00000004bb7fffff]
2024-10-24T12:22:06,000000+00:00   Device   empty
2024-10-24T12:22:06,000000+00:00 Movable zone start for each node
2024-10-24T12:22:06,000000+00:00 Early memory node ranges
2024-10-24T12:22:06,000000+00:00   node   0: [mem 0x0000000040000000-0x000000007862ffff]
2024-10-24T12:22:06,000000+00:00   node   0: [mem 0x0000000078630000-0x000000007863ffff]
2024-10-24T12:22:06,000000+00:00   node   0: [mem 0x0000000078640000-0x00000000786effff]
2024-10-24T12:22:06,000000+00:00   node   0: [mem 0x00000000786f0000-0x000000007872ffff]
2024-10-24T12:22:06,000000+00:00   node   0: [mem 0x0000000078730000-0x000000007bbfffff]
2024-10-24T12:22:06,000000+00:00   node   0: [mem 0x000000007bc00000-0x000000007bfdffff]
2024-10-24T12:22:06,000000+00:00   node   0: [mem 0x000000007bfe0000-0x000000007fffffff]
2024-10-24T12:22:06,000000+00:00   node   0: [mem 0x0000000400000000-0x00000004bb7fffff]
2024-10-24T12:22:06,000000+00:00 Initmem setup node 0 [mem 0x0000000040000000-0x00000004bb7fffff]
2024-10-24T12:22:06,000000+00:00 On node 0, zone Normal: 18432 pages in unavailable ranges
2024-10-24T12:22:06,000000+00:00 cma: Reserved 64 MiB at 0x000000007c000000 on node -1
2024-10-24T12:22:06,000000+00:00 psci: probing for conduit method from ACPI.
2024-10-24T12:22:06,000000+00:00 psci: PSCIv1.0 detected in firmware.
2024-10-24T12:22:06,000000+00:00 psci: Using standard PSCI v0.2 function IDs
2024-10-24T12:22:06,000000+00:00 psci: Trusted OS migration not required
2024-10-24T12:22:06,000000+00:00 psci: SMC Calling Convention v1.1
2024-10-24T12:22:06,000000+00:00 percpu: Embedded 31 pages/cpu s86440 r8192 d32344 u126976
2024-10-24T12:22:06,000000+00:00 pcpu-alloc: s86440 r8192 d32344 u126976 alloc=31*4096
2024-10-24T12:22:06,000000+00:00 pcpu-alloc: [0] 0 [0] 1 
2024-10-24T12:22:06,000000+00:00 Detected PIPT I-cache on CPU0
2024-10-24T12:22:06,000000+00:00 CPU features: detected: GIC system register CPU interface
2024-10-24T12:22:06,000000+00:00 CPU features: detected: Hardware dirty bit management
2024-10-24T12:22:06,000000+00:00 CPU features: detected: Spectre-v4
2024-10-24T12:22:06,000000+00:00 CPU features: detected: Spectre-BHB
2024-10-24T12:22:06,000000+00:00 CPU features: detected: ARM erratum 1418040
2024-10-24T12:22:06,000000+00:00 CPU features: detected: ARM erratum 1542419 (kernel portion)
2024-10-24T12:22:06,000000+00:00 CPU features: detected: SSBS not fully self-synchronizing
2024-10-24T12:22:06,000000+00:00 alternatives: applying boot alternatives
2024-10-24T12:22:06,000000+00:00 Fallback order for Node 0: 0 
2024-10-24T12:22:06,000000+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 1014048
2024-10-24T12:22:06,000000+00:00 Policy zone: Normal
2024-10-24T12:22:06,000000+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64 root=UUID=b5c7fae5-1de8-4038-8408-06c720e69aff ro console=tty0 console=ttyS0,115200n8 nvme_core.io_timeout=4294967295 rd.emergency=poweroff rd.shell=0 selinux=1 security=selinux quiet numa_cma=1:64M
2024-10-24T12:22:06,000000+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64", will be passed to user space.
2024-10-24T12:22:06,000000+00:00 Dentry cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-10-24T12:22:06,000000+00:00 Inode-cache hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2024-10-24T12:22:06,000000+00:00 mem auto-init: stack:off, heap alloc:off, heap free:off
2024-10-24T12:22:06,000000+00:00 software IO TLB: area num 2.
2024-10-24T12:22:06,000000+00:00 software IO TLB: mapped [mem 0x000000006de00000-0x0000000071e00000] (64MB)
2024-10-24T12:22:06,000000+00:00 Memory: 3846296K/4120576K available (12096K kernel code, 8838K rwdata, 8416K rodata, 4480K init, 11359K bss, 208744K reserved, 65536K cma-reserved)
2024-10-24T12:22:06,000000+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-10-24T12:22:06,000000+00:00 ftrace: allocating 40237 entries in 158 pages
2024-10-24T12:22:06,000000+00:00 ftrace: allocated 158 pages with 5 groups
2024-10-24T12:22:06,000000+00:00 trace event string verifier disabled
2024-10-24T12:22:06,000000+00:00 rcu: Hierarchical RCU implementation.
2024-10-24T12:22:06,000000+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=4096 to nr_cpu_ids=2.
2024-10-24T12:22:06,000000+00:00 	Rude variant of Tasks RCU enabled.
2024-10-24T12:22:06,000000+00:00 	Tracing variant of Tasks RCU enabled.
2024-10-24T12:22:06,000000+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 10 jiffies.
2024-10-24T12:22:06,000000+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-10-24T12:22:06,000000+00:00 NR_IRQS: 64, nr_irqs: 64, preallocated irqs: 0
2024-10-24T12:22:06,000000+00:00 GICv3: 96 SPIs implemented
2024-10-24T12:22:06,000000+00:00 GICv3: 0 Extended SPIs implemented
2024-10-24T12:22:06,000000+00:00 Root IRQ handler: gic_handle_irq
2024-10-24T12:22:06,000000+00:00 GICv3: GICv3 features: 16 PPIs
2024-10-24T12:22:06,000000+00:00 GICv3: CPU0: found redistributor 0 region 0:0x0000000010200000
2024-10-24T12:22:06,000000+00:00 ITS [mem 0x10080000-0x1009ffff]
2024-10-24T12:22:06,000000+00:00 ITS@0x0000000010080000: allocated 8192 Devices @4001a0000 (indirect, esz 8, psz 64K, shr 1)
2024-10-24T12:22:06,000000+00:00 ITS@0x0000000010080000: allocated 8192 Interrupt Collections @4001b0000 (flat, esz 8, psz 64K, shr 1)
2024-10-24T12:22:06,000000+00:00 GICv3: using LPI property table @0x00000004001c0000
2024-10-24T12:22:06,000000+00:00 ITS: Using hypervisor restricted LPI range [128]
2024-10-24T12:22:06,000000+00:00 GICv3: CPU0: using allocated LPI pending table @0x00000004001d0000
2024-10-24T12:22:06,000000+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-10-24T12:22:06,000000+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-24T12:22:06,000000+00:00 arch_timer: cp15 timer(s) running at 121.87MHz (virt).
2024-10-24T12:22:06,000000+00:00 clocksource: arch_sys_counter: mask: 0x3ffffffffffffff max_cycles: 0x383759f8ff, max_idle_ns: 881590415659 ns
2024-10-24T12:22:06,000000+00:00 sched_clock: 58 bits at 122MHz, resolution 8ns, wraps every 4398046511103ns
2024-10-24T12:22:06,000017+00:00 arm-pv: using stolen time PV
2024-10-24T12:22:06,000075+00:00 Console: colour dummy device 80x25
2024-10-24T12:22:06,000091+00:00 printk: console [tty0] enabled
2024-10-24T12:22:06,000109+00:00 ACPI: Core revision 20220331
2024-10-24T12:22:06,000141+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 243.75 BogoMIPS (lpj=1218750)
2024-10-24T12:22:06,000143+00:00 pid_max: default: 32768 minimum: 301
2024-10-24T12:22:06,000164+00:00 LSM: Security Framework initializing
2024-10-24T12:22:06,000180+00:00 Yama: becoming mindful.
2024-10-24T12:22:06,000185+00:00 SELinux:  Initializing.
2024-10-24T12:22:06,000200+00:00 LSM support for eBPF active
2024-10-24T12:22:06,000217+00:00 Mount-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-10-24T12:22:06,000221+00:00 Mountpoint-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-10-24T12:22:06,000548+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-24T12:22:06,000550+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-24T12:22:06,000562+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-24T12:22:06,000563+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-24T12:22:06,000604+00:00 rcu: Hierarchical SRCU implementation.
2024-10-24T12:22:06,000605+00:00 rcu: 	Max phase no-delay instances is 1000.
2024-10-24T12:22:06,000795+00:00 Platform MSI: ITS@0x10080000 domain created
2024-10-24T12:22:06,000800+00:00 PCI/MSI: ITS@0x10080000 domain created
2024-10-24T12:22:06,000804+00:00 Remapping and enabling EFI services.
2024-10-24T12:22:06,000905+00:00 smp: Bringing up secondary CPUs ...
2024-10-24T12:22:06,001062+00:00 Detected PIPT I-cache on CPU1
2024-10-24T12:22:06,001091+00:00 GICv3: CPU1: found redistributor 1 region 0:0x0000000010220000
2024-10-24T12:22:06,001120+00:00 GICv3: CPU1: using allocated LPI pending table @0x00000004001e0000
2024-10-24T12:22:06,001134+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-24T12:22:06,001148+00:00 CPU1: Booted secondary processor 0x0000000001 [0x413fd0c1]
2024-10-24T12:22:06,001227+00:00 smp: Brought up 1 node, 2 CPUs
2024-10-24T12:22:06,001232+00:00 SMP: Total of 2 processors activated.
2024-10-24T12:22:06,001234+00:00 CPU features: detected: 32-bit EL0 Support
2024-10-24T12:22:06,001236+00:00 CPU features: detected: Instruction cache invalidation not required for I/D coherence
2024-10-24T12:22:06,001237+00:00 CPU features: detected: Data cache clean to the PoU not required for I/D coherence
2024-10-24T12:22:06,001238+00:00 CPU features: detected: Common not Private translations
2024-10-24T12:22:06,001239+00:00 CPU features: detected: CRC32 instructions
2024-10-24T12:22:06,001241+00:00 CPU features: detected: RCpc load-acquire (LDAPR)
2024-10-24T12:22:06,001242+00:00 CPU features: detected: LSE atomic instructions
2024-10-24T12:22:06,001243+00:00 CPU features: detected: Privileged Access Never
2024-10-24T12:22:06,001244+00:00 CPU features: detected: RAS Extension Support
2024-10-24T12:22:06,001246+00:00 CPU features: detected: Speculative Store Bypassing Safe (SSBS)
2024-10-24T12:22:06,001292+00:00 CPU: All CPU(s) started at EL1
2024-10-24T12:22:06,001295+00:00 alternatives: applying system-wide alternatives
2024-10-24T12:22:06,003470+00:00 devtmpfs: initialized
2024-10-24T12:22:06,003926+00:00 Registered cp15_barrier emulation handler
2024-10-24T12:22:06,003938+00:00 Registered setend emulation handler
2024-10-24T12:22:06,003973+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604462750000 ns
2024-10-24T12:22:06,003976+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-10-24T12:22:06,004193+00:00 pinctrl core: initialized pinctrl subsystem
2024-10-24T12:22:06,004236+00:00 SMBIOS 3.0.0 present.
2024-10-24T12:22:06,004239+00:00 DMI: Amazon EC2 t4g.medium/, BIOS 1.0 11/1/2018
2024-10-24T12:22:06,004338+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-10-24T12:22:06,004507+00:00 DMA: preallocated 512 KiB GFP_KERNEL pool for atomic allocations
2024-10-24T12:22:06,004530+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-10-24T12:22:06,004561+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-10-24T12:22:06,004570+00:00 audit: initializing netlink subsys (disabled)
2024-10-24T12:22:06,004622+00:00 audit: type=2000 audit(0.000:1): state=initialized audit_enabled=0 res=1
2024-10-24T12:22:06,004672+00:00 thermal_sys: Registered thermal governor 'fair_share'
2024-10-24T12:22:06,004674+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-10-24T12:22:06,004675+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-10-24T12:22:06,004683+00:00 cpuidle: using governor ladder
2024-10-24T12:22:06,004686+00:00 cpuidle: using governor menu
2024-10-24T12:22:06,004722+00:00 hw-breakpoint: found 6 breakpoint and 4 watchpoint registers.
2024-10-24T12:22:06,004755+00:00 ASID allocator initialised with 65536 entries
2024-10-24T12:22:06,004761+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-10-24T12:22:06,004773+00:00 Serial: AMBA PL011 UART driver
2024-10-24T12:22:06,010183+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2024-10-24T12:22:06,010184+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 1.00 GiB page
2024-10-24T12:22:06,010186+00:00 HugeTLB: registered 32.0 MiB page size, pre-allocated 0 pages
2024-10-24T12:22:06,010187+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 32.0 MiB page
2024-10-24T12:22:06,010188+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-10-24T12:22:06,010189+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 2.00 MiB page
2024-10-24T12:22:06,010190+00:00 HugeTLB: registered 64.0 KiB page size, pre-allocated 0 pages
2024-10-24T12:22:06,010191+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 64.0 KiB page
2024-10-24T12:22:06,010875+00:00 ACPI: Added _OSI(Module Device)
2024-10-24T12:22:06,010878+00:00 ACPI: Added _OSI(Processor Device)
2024-10-24T12:22:06,010879+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-10-24T12:22:06,010880+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-10-24T12:22:06,011457+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-10-24T12:22:06,011845+00:00 ACPI: Interpreter enabled
2024-10-24T12:22:06,011846+00:00 ACPI: Using GIC for interrupt routing
2024-10-24T12:22:06,011856+00:00 ACPI: MCFG table detected, 1 entries
2024-10-24T12:22:06,013365+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-0f])
2024-10-24T12:22:06,013373+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-10-24T12:22:06,013417+00:00 acpi PNP0A08:00: _OSC: platform does not support [SHPCHotplug LTR]
2024-10-24T12:22:06,013472+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug PME PCIeCapability]
2024-10-24T12:22:06,013552+00:00 acpi PNP0A08:00: ECAM area [mem 0x20000000-0x20ffffff] reserved by PNP0C02:00
2024-10-24T12:22:06,013558+00:00 acpi PNP0A08:00: ECAM at [mem 0x20000000-0x20ffffff] for [bus 00-0f]
2024-10-24T12:22:06,013575+00:00 ACPI: Remapped I/O 0x000000001fff0000 to [io  0x0000-0xffff window]
2024-10-24T12:22:06,013833+00:00 acpiphp: Slot [1] registered
2024-10-24T12:22:06,013843+00:00 acpiphp: Slot [2] registered
2024-10-24T12:22:06,013854+00:00 acpiphp: Slot [3] registered
2024-10-24T12:22:06,013863+00:00 acpiphp: Slot [4] registered
2024-10-24T12:22:06,013873+00:00 acpiphp: Slot [5] registered
2024-10-24T12:22:06,013882+00:00 acpiphp: Slot [6] registered
2024-10-24T12:22:06,013893+00:00 acpiphp: Slot [7] registered
2024-10-24T12:22:06,013902+00:00 acpiphp: Slot [8] registered
2024-10-24T12:22:06,013911+00:00 acpiphp: Slot [9] registered
2024-10-24T12:22:06,013920+00:00 acpiphp: Slot [10] registered
2024-10-24T12:22:06,013929+00:00 acpiphp: Slot [11] registered
2024-10-24T12:22:06,013938+00:00 acpiphp: Slot [12] registered
2024-10-24T12:22:06,013948+00:00 acpiphp: Slot [13] registered
2024-10-24T12:22:06,013958+00:00 acpiphp: Slot [14] registered
2024-10-24T12:22:06,013967+00:00 acpiphp: Slot [15] registered
2024-10-24T12:22:06,013976+00:00 acpiphp: Slot [16] registered
2024-10-24T12:22:06,013985+00:00 acpiphp: Slot [17] registered
2024-10-24T12:22:06,013994+00:00 acpiphp: Slot [18] registered
2024-10-24T12:22:06,014003+00:00 acpiphp: Slot [19] registered
2024-10-24T12:22:06,014012+00:00 acpiphp: Slot [20] registered
2024-10-24T12:22:06,014022+00:00 acpiphp: Slot [21] registered
2024-10-24T12:22:06,014031+00:00 acpiphp: Slot [22] registered
2024-10-24T12:22:06,014040+00:00 acpiphp: Slot [23] registered
2024-10-24T12:22:06,014049+00:00 acpiphp: Slot [24] registered
2024-10-24T12:22:06,014059+00:00 acpiphp: Slot [25] registered
2024-10-24T12:22:06,014069+00:00 acpiphp: Slot [26] registered
2024-10-24T12:22:06,014078+00:00 acpiphp: Slot [27] registered
2024-10-24T12:22:06,014087+00:00 acpiphp: Slot [28] registered
2024-10-24T12:22:06,014097+00:00 acpiphp: Slot [29] registered
2024-10-24T12:22:06,014105+00:00 acpiphp: Slot [30] registered
2024-10-24T12:22:06,014115+00:00 acpiphp: Slot [31] registered
2024-10-24T12:22:06,014131+00:00 PCI host bridge to bus 0000:00
2024-10-24T12:22:06,014132+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xffffffff window]
2024-10-24T12:22:06,014135+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0xffff window]
2024-10-24T12:22:06,014136+00:00 pci_bus 0000:00: root bus resource [mem 0x400000000000-0x407fffffffff window]
2024-10-24T12:22:06,014138+00:00 pci_bus 0000:00: root bus resource [bus 00-0f]
2024-10-24T12:22:06,014173+00:00 pci 0000:00:00.0: [1d0f:0200] type 00 class 0x060000
2024-10-24T12:22:06,014397+00:00 pci 0000:00:01.0: [1d0f:8250] type 00 class 0x070003
2024-10-24T12:22:06,014445+00:00 pci 0000:00:01.0: reg 0x10: [mem 0x80008000-0x80008fff]
2024-10-24T12:22:06,014632+00:00 pci 0000:00:04.0: [1d0f:8061] type 00 class 0x010802
2024-10-24T12:22:06,016005+00:00 pci 0000:00:04.0: reg 0x10: [mem 0x80004000-0x80007fff]
2024-10-24T12:22:06,021896+00:00 pci 0000:00:04.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T12:22:06,022079+00:00 pci 0000:00:05.0: [1d0f:ec20] type 00 class 0x020000
2024-10-24T12:22:06,022119+00:00 pci 0000:00:05.0: reg 0x10: [mem 0x80000000-0x80003fff]
2024-10-24T12:22:06,022310+00:00 pci 0000:00:05.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T12:22:06,022475+00:00 pci 0000:00:04.0: BAR 0: assigned [mem 0x80000000-0x80003fff]
2024-10-24T12:22:06,022996+00:00 pci 0000:00:05.0: BAR 0: assigned [mem 0x80004000-0x80007fff]
2024-10-24T12:22:06,023005+00:00 pci 0000:00:01.0: BAR 0: assigned [mem 0x80008000-0x80008fff]
2024-10-24T12:22:06,023013+00:00 pci_bus 0000:00: resource 4 [mem 0x80000000-0xffffffff window]
2024-10-24T12:22:06,023015+00:00 pci_bus 0000:00: resource 5 [io  0x0000-0xffff window]
2024-10-24T12:22:06,023017+00:00 pci_bus 0000:00: resource 6 [mem 0x400000000000-0x407fffffffff window]
2024-10-24T12:22:06,023055+00:00 ACPI: PCI: Interrupt link GSI0 configured for IRQ 35
2024-10-24T12:22:06,023061+00:00 ACPI: PCI: Interrupt link GSI1 configured for IRQ 36
2024-10-24T12:22:06,023067+00:00 ACPI: PCI: Interrupt link GSI2 configured for IRQ 37
2024-10-24T12:22:06,023072+00:00 ACPI: PCI: Interrupt link GSI3 configured for IRQ 38
2024-10-24T12:22:06,023439+00:00 iommu: Default domain type: Translated 
2024-10-24T12:22:06,023442+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2024-10-24T12:22:06,023477+00:00 pps_core: LinuxPPS API ver. 1 registered
2024-10-24T12:22:06,023478+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2024-10-24T12:22:06,023480+00:00 PTP clock support registered
2024-10-24T12:22:06,023510+00:00 EDAC MC: Ver: 3.0.0
2024-10-24T12:22:06,023683+00:00 Registered efivars operations
2024-10-24T12:22:06,023918+00:00 NetLabel: Initializing
2024-10-24T12:22:06,023920+00:00 NetLabel:  domain hash size = 128
2024-10-24T12:22:06,023921+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-10-24T12:22:06,023932+00:00 NetLabel:  unlabeled traffic allowed by default
2024-10-24T12:22:06,023970+00:00 vgaarb: loaded
2024-10-24T12:22:06,024102+00:00 clocksource: Switched to clocksource arch_sys_counter
2024-10-24T12:22:06,024175+00:00 VFS: Disk quotas dquot_6.6.0
2024-10-24T12:22:06,024184+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-10-24T12:22:06,024243+00:00 pnp: PnP ACPI init
2024-10-24T12:22:06,024319+00:00 system 00:00: [mem 0x20000000-0x2fffffff] could not be reserved
2024-10-24T12:22:06,024329+00:00 pnp: PnP ACPI: found 1 devices
2024-10-24T12:22:06,030990+00:00 NET: Registered PF_INET protocol family
2024-10-24T12:22:06,031025+00:00 IP idents hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-10-24T12:22:06,031819+00:00 tcp_listen_portaddr_hash hash table entries: 2048 (order: 3, 32768 bytes, linear)
2024-10-24T12:22:06,031833+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-10-24T12:22:06,031836+00:00 TCP established hash table entries: 32768 (order: 6, 262144 bytes, linear)
2024-10-24T12:22:06,031927+00:00 TCP bind hash table entries: 32768 (order: 8, 1048576 bytes, linear)
2024-10-24T12:22:06,032253+00:00 TCP: Hash tables configured (established 32768 bind 32768)
2024-10-24T12:22:06,032294+00:00 MPTCP token hash table entries: 4096 (order: 4, 98304 bytes, linear)
2024-10-24T12:22:06,032311+00:00 UDP hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-10-24T12:22:06,032342+00:00 UDP-Lite hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-10-24T12:22:06,032395+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-10-24T12:22:06,032404+00:00 NET: Registered PF_XDP protocol family
2024-10-24T12:22:06,032444+00:00 PCI: CLS 0 bytes, default 64
2024-10-24T12:22:06,032571+00:00 Trying to unpack rootfs image as initramfs...
2024-10-24T12:22:06,044548+00:00 hw perfevents: enabled with armv8_pmuv3_0 PMU driver, 3 counters available
2024-10-24T12:22:06,044570+00:00 kvm [1]: HYP mode not available
2024-10-24T12:22:06,044779+00:00 Initialise system trusted keyrings
2024-10-24T12:22:06,044785+00:00 Key type blacklist registered
2024-10-24T12:22:06,044973+00:00 workingset: timestamp_bits=44 max_order=20 bucket_order=0
2024-10-24T12:22:06,045958+00:00 zbud: loaded
2024-10-24T12:22:06,046106+00:00 SGI XFS with ACLs, security attributes, quota, no debug enabled
2024-10-24T12:22:06,046545+00:00 integrity: Platform Keyring initialized
2024-10-24T12:22:06,053561+00:00 Key type asymmetric registered
2024-10-24T12:22:06,053563+00:00 Asymmetric key parser 'x509' registered
2024-10-24T12:22:06,053579+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 248)
2024-10-24T12:22:06,053613+00:00 io scheduler mq-deadline registered
2024-10-24T12:22:06,053615+00:00 io scheduler kyber registered
2024-10-24T12:22:06,053636+00:00 io scheduler bfq registered
2024-10-24T12:22:06,055491+00:00 pl061_gpio ARMH0061:00: PL061 GPIO chip registered
2024-10-24T12:22:06,055536+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2024-10-24T12:22:06,056730+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing disabled
2024-10-24T12:22:06,057186+00:00 ACPI: \_SB_.PCI0.GSI2: Enabled at IRQ 37
2024-10-24T12:22:06,057211+00:00 serial 0000:00:01.0: enabling device (0010 -> 0012)
2024-10-24T12:22:06,057495+00:00 printk: console [ttyS0] disabled
2024-10-24T12:22:06,057635+00:00 0000:00:01.0: ttyS0 at MMIO 0x80008000 (irq = 14, base_baud = 115200) is a 16550A
2024-10-24T12:22:06,057734+00:00 printk: console [ttyS0] enabled
2024-10-24T12:22:06,058698+00:00 ACPI: \_SB_.PCI0.GSI0: Enabled at IRQ 35
2024-10-24T12:22:06,058769+00:00 nvme nvme0: pci function 0000:00:04.0
2024-10-24T12:22:06,059709+00:00 rtc-efi rtc-efi.0: registered as rtc0
2024-10-24T12:22:06,059755+00:00 rtc-efi rtc-efi.0: setting system clock to 2024-10-24T12:22:06 UTC (1729772526)
2024-10-24T12:22:06,059821+00:00 pstore: Registered efi as persistent store backend
2024-10-24T12:22:06,059840+00:00 hid: raw HID events driver (C) Jiri Kosina
2024-10-24T12:22:06,064523+00:00 nvme nvme0: 2/0/0 default/read/poll queues
2024-10-24T12:22:06,069816+00:00 NET: Registered PF_INET6 protocol family
2024-10-24T12:22:06,071998+00:00  nvme0n1: p1 p128
2024-10-24T12:22:06,144285+00:00 Freeing initrd memory: 11908K
2024-10-24T12:22:06,149858+00:00 Segment Routing with IPv6
2024-10-24T12:22:06,149871+00:00 In-situ OAM (IOAM) with IPv6
2024-10-24T12:22:06,149907+00:00 NET: Registered PF_PACKET protocol family
2024-10-24T12:22:06,150130+00:00 registered taskstats version 1
2024-10-24T12:22:06,150138+00:00 Loading compiled-in X.509 certificates
2024-10-24T12:22:06,161943+00:00 Loaded X.509 cert 'Amazon.com: Amazon Linux Kernel Signing Key: 3c3163dcb84c1049cf8b75ca4bcf01c5583dbccb'
2024-10-24T12:22:06,162083+00:00 zswap: loaded using pool lzo/zbud
2024-10-24T12:22:06,162228+00:00 Key type .fscrypt registered
2024-10-24T12:22:06,162230+00:00 Key type fscrypt-provisioning registered
2024-10-24T12:22:06,162421+00:00 pstore: Using crash dump compression: deflate
2024-10-24T12:22:06,162733+00:00 ima: secureboot mode disabled
2024-10-24T12:22:06,162736+00:00 ima: No TPM chip found, activating TPM-bypass!
2024-10-24T12:22:06,162743+00:00 ima: Allocated hash algorithm: sha256
2024-10-24T12:22:06,162753+00:00 ima: No architecture policies found
2024-10-24T12:22:06,307796+00:00 clk: Disabling unused clocks
2024-10-24T12:22:06,309079+00:00 Freeing unused kernel memory: 4480K
2024-10-24T12:22:06,309099+00:00 Run /init as init process
2024-10-24T12:22:06,309100+00:00   with arguments:
2024-10-24T12:22:06,309102+00:00     /init
2024-10-24T12:22:06,309103+00:00   with environment:
2024-10-24T12:22:06,309104+00:00     HOME=/
2024-10-24T12:22:06,309105+00:00     TERM=linux
2024-10-24T12:22:06,309106+00:00     BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64
2024-10-24T12:22:06,334856+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-24T12:22:06,334861+00:00 systemd[1]: Detected virtualization amazon.
2024-10-24T12:22:06,334864+00:00 systemd[1]: Detected architecture arm64.
2024-10-24T12:22:06,334866+00:00 systemd[1]: Running in initrd.
2024-10-24T12:22:06,334956+00:00 systemd[1]: No hostname configured, using default hostname.
2024-10-24T12:22:06,334996+00:00 systemd[1]: Hostname set to <localhost>.
2024-10-24T12:22:06,335063+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-24T12:22:06,418176+00:00 systemd[1]: Queued start job for default target initrd.target.
2024-10-24T12:22:06,464622+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-24T12:22:06,464677+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-b5c7fae5\x2d1de8\x2d4038\x2d8408\x2d06c720e69aff.device - /dev/disk/by-uuid/b5c7fae5-1de8-4038-8408-06c720e69aff...
2024-10-24T12:22:06,464708+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2024-10-24T12:22:06,464722+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2024-10-24T12:22:06,464734+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-24T12:22:06,464753+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-24T12:22:06,464764+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-24T12:22:06,464777+00:00 systemd[1]: Reached target timers.target - Timer Units.
2024-10-24T12:22:06,465081+00:00 systemd[1]: Listening on systemd-journald-audit.socket - Journal Audit Socket.
2024-10-24T12:22:06,465197+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2024-10-24T12:22:06,465276+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Socket.
2024-10-24T12:22:06,465364+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-24T12:22:06,465424+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-24T12:22:06,465440+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2024-10-24T12:22:06,465493+00:00 systemd[1]: kmod-static-nodes.service - Create List of Static Device Nodes was skipped because of an unmet condition check (ConditionFileNotEmpty=/lib/modules/6.1.112-122.189.amzn2023.aarch64/modules.devname).
2024-10-24T12:22:06,466387+00:00 systemd[1]: Started rngd.service - Hardware RNG Entropy Gatherer Daemon.
2024-10-24T12:22:06,467637+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-24T12:22:06,467757+00:00 systemd[1]: systemd-modules-load.service - Load Kernel Modules was skipped because no trigger condition checks were met.
2024-10-24T12:22:06,468454+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-24T12:22:06,469136+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2024-10-24T12:22:06,469848+00:00 systemd[1]: Starting systemd-vconsole-setup.service - Setup Virtual Console...
2024-10-24T12:22:06,481686+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2024-10-24T12:22:06,482095+00:00 systemd[1]: Finished systemd-vconsole-setup.service - Setup Virtual Console.
2024-10-24T12:22:06,482212+00:00 systemd[1]: dracut-cmdline-ask.service - dracut ask for additional cmdline parameters was skipped because no trigger condition checks were met.
2024-10-24T12:22:06,483106+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2024-10-24T12:22:06,496907+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-24T12:22:06,498387+00:00 audit: type=1130 audit(1729772526.929:2): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-journald comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:06,498393+00:00 audit: type=1130 audit(1729772526.929:3): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-sysctl comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:06,512037+00:00 audit: type=1130 audit(1729772526.939:4): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-tmpfiles-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:06,553582+00:00 audit: type=1130 audit(1729772526.979:5): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=dracut-cmdline comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:06,553589+00:00 audit: type=1334 audit(1729772526.979:6): prog-id=6 op=LOAD
2024-10-24T12:22:06,553591+00:00 audit: type=1334 audit(1729772526.979:7): prog-id=7 op=LOAD
2024-10-24T12:22:06,620892+00:00 audit: type=1130 audit(1729772527.049:8): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udevd comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:06,688672+00:00 audit: type=1130 audit(1729772527.119:9): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udev-trigger comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:06,926132+00:00 XFS (nvme0n1p1): Mounting V5 Filesystem
2024-10-24T12:22:07,024842+00:00 XFS (nvme0n1p1): Ending clean mount
2024-10-24T12:22:07,078722+00:00 audit: type=1130 audit(1729772527.509:10): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=initrd-parse-etc comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:07,375877+00:00 systemd-journald[324]: Received SIGTERM from PID 1 (systemd).
2024-10-24T12:22:07,689477+00:00 SELinux:  Class user_namespace not defined in policy.
2024-10-24T12:22:07,689482+00:00 SELinux: the above unknown classes and permissions will be allowed
2024-10-24T12:22:07,692555+00:00 SELinux:  policy capability network_peer_controls=1
2024-10-24T12:22:07,692559+00:00 SELinux:  policy capability open_perms=1
2024-10-24T12:22:07,692560+00:00 SELinux:  policy capability extended_socket_class=1
2024-10-24T12:22:07,692562+00:00 SELinux:  policy capability always_check_network=0
2024-10-24T12:22:07,692563+00:00 SELinux:  policy capability cgroup_seclabel=1
2024-10-24T12:22:07,692563+00:00 SELinux:  policy capability nnp_nosuid_transition=1
2024-10-24T12:22:07,692565+00:00 SELinux:  policy capability genfs_seclabel_symlinks=1
2024-10-24T12:22:07,692566+00:00 SELinux:  policy capability ioctl_skip_cloexec=0
2024-10-24T12:22:07,800683+00:00 systemd[1]: Successfully loaded SELinux policy in 163.586ms.
2024-10-24T12:22:07,928329+00:00 systemd[1]: Relabelled /dev, /dev/shm, /run, /sys/fs/cgroup in 23.945ms.
2024-10-24T12:22:07,944937+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-24T12:22:07,944943+00:00 systemd[1]: Detected virtualization amazon.
2024-10-24T12:22:07,944956+00:00 systemd[1]: Detected architecture arm64.
2024-10-24T12:22:07,948882+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-24T12:22:07,948962+00:00 systemd[1]: Installed transient /etc/machine-id file.
2024-10-24T12:22:08,043756+00:00 systemd[1]: bpf-lsm: Failed to link program; assuming BPF LSM is not available
2024-10-24T12:22:08,091902+00:00 zram_generator::config[821]: zram0: system has too much memory (3836MB), limit is 800MB, ignoring.
2024-10-24T12:22:08,230784+00:00 systemd[1]: /usr/lib/systemd/system/update-motd.service:40: Invalid CPU quota '25', ignoring.
2024-10-24T12:22:08,488042+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2024-10-24T12:22:08,488189+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2024-10-24T12:22:08,488736+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2024-10-24T12:22:08,489194+00:00 systemd[1]: Created slice system-getty.slice - Slice /system/getty.
2024-10-24T12:22:08,489563+00:00 systemd[1]: Created slice system-modprobe.slice - Slice /system/modprobe.
2024-10-24T12:22:08,489926+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2024-10-24T12:22:08,490268+00:00 systemd[1]: Created slice system-sshd\x2dkeygen.slice - Slice /system/sshd-keygen.
2024-10-24T12:22:08,490604+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2024-10-24T12:22:08,490746+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-24T12:22:08,490837+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2024-10-24T12:22:08,491281+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2024-10-24T12:22:08,491304+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2024-10-24T12:22:08,491331+00:00 systemd[1]: Reached target cryptsetup.target - Local Encrypted Volumes.
2024-10-24T12:22:08,491361+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2024-10-24T12:22:08,491376+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2024-10-24T12:22:08,491385+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2024-10-24T12:22:08,491396+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2024-10-24T12:22:08,491437+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-24T12:22:08,491465+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-24T12:22:08,491483+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-24T12:22:08,491501+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2024-10-24T12:22:08,491970+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2024-10-24T12:22:08,493691+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2024-10-24T12:22:08,495817+00:00 systemd[1]: Listening on systemd-coredump.socket - Process Core Dump Socket.
2024-10-24T12:22:08,495958+00:00 systemd[1]: Listening on systemd-initctl.socket - initctl Compatibility Named Pipe.
2024-10-24T12:22:08,496240+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Service Netlink Socket.
2024-10-24T12:22:08,497588+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-24T12:22:08,497970+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-24T12:22:08,498316+00:00 systemd[1]: Listening on systemd-userdbd.socket - User Database Manager Socket.
2024-10-24T12:22:08,499736+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2024-10-24T12:22:08,500994+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2024-10-24T12:22:08,502302+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2024-10-24T12:22:08,504583+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2024-10-24T12:22:08,507625+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2024-10-24T12:22:08,507705+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS was skipped because of an unmet condition check (ConditionPathExists=/etc/krb5.keytab).
2024-10-24T12:22:08,508999+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2024-10-24T12:22:08,510139+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2024-10-24T12:22:08,511316+00:00 systemd[1]: Starting modprobe@configfs.service - Load Kernel Module configfs...
2024-10-24T12:22:08,512536+00:00 systemd[1]: Starting modprobe@dm_mod.service - Load Kernel Module dm_mod...
2024-10-24T12:22:08,513697+00:00 systemd[1]: Starting modprobe@drm.service - Load Kernel Module drm...
2024-10-24T12:22:08,518149+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2024-10-24T12:22:08,519405+00:00 systemd[1]: Starting modprobe@fuse.service - Load Kernel Module fuse...
2024-10-24T12:22:08,520640+00:00 systemd[1]: Starting modprobe@loop.service - Load Kernel Module loop...
2024-10-24T12:22:08,521910+00:00 systemd[1]: Starting nfs-convert.service - Preprocess NFS configuration convertion...
2024-10-24T12:22:08,523261+00:00 systemd[1]: Starting systemd-fsck-root.service - File System Check on Root Device...
2024-10-24T12:22:08,523342+00:00 systemd[1]: Stopped systemd-journald.service - Journal Service.
2024-10-24T12:22:08,526585+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-24T12:22:08,534360+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2024-10-24T12:22:08,535725+00:00 systemd[1]: Starting systemd-network-generator.service - Generate network units from Kernel command line...
2024-10-24T12:22:08,537123+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2024-10-24T12:22:08,539064+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2024-10-24T12:22:08,539184+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2024-10-24T12:22:08,539272+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2024-10-24T12:22:08,539360+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2024-10-24T12:22:08,539447+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2024-10-24T12:22:08,539934+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2024-10-24T12:22:08,540259+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-10-24T12:22:08,540412+00:00 systemd[1]: Finished modprobe@drm.service - Load Kernel Module drm.
2024-10-24T12:22:08,540707+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-10-24T12:22:08,540847+00:00 systemd[1]: Finished modprobe@efi_pstore.service - Load Kernel Module efi_pstore.
2024-10-24T12:22:08,541312+00:00 systemd[1]: nfs-convert.service: Deactivated successfully.
2024-10-24T12:22:08,541467+00:00 systemd[1]: Finished nfs-convert.service - Preprocess NFS configuration convertion.
2024-10-24T12:22:08,541782+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2024-10-24T12:22:08,543349+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-24T12:22:08,547029+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-10-24T12:22:08,547180+00:00 systemd[1]: Finished modprobe@configfs.service - Load Kernel Module configfs.
2024-10-24T12:22:08,548811+00:00 systemd[1]: Mounting sys-kernel-config.mount - Kernel Configuration File System...
2024-10-24T12:22:08,551924+00:00 systemd[1]: Mounted sys-kernel-config.mount - Kernel Configuration File System.
2024-10-24T12:22:08,560859+00:00 systemd[1]: Finished systemd-network-generator.service - Generate network units from Kernel command line.
2024-10-24T12:22:08,567413+00:00 fuse: init (API version 7.38)
2024-10-24T12:22:08,569063+00:00 systemd[1]: modprobe@fuse.service: Deactivated successfully.
2024-10-24T12:22:08,569221+00:00 systemd[1]: Finished modprobe@fuse.service - Load Kernel Module fuse.
2024-10-24T12:22:08,571539+00:00 systemd[1]: Mounting sys-fs-fuse-connections.mount - FUSE Control File System...
2024-10-24T12:22:08,571791+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-24T12:22:08,578955+00:00 loop: module loaded
2024-10-24T12:22:08,593819+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2024-10-24T12:22:08,594796+00:00 device-mapper: uevent: version 1.0.3
2024-10-24T12:22:08,595529+00:00 device-mapper: ioctl: 4.47.0-ioctl (2022-07-28) initialised: dm-devel@redhat.com
2024-10-24T12:22:08,646596+00:00 systemd-journald[843]: Received client request to flush runtime journal.
2024-10-24T12:22:08,923571+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input0
2024-10-24T12:22:08,925958+00:00 ACPI: button: Power Button [PWRB]
2024-10-24T12:22:08,926355+00:00 input: Sleep Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0E:00/input/input1
2024-10-24T12:22:08,929283+00:00 ACPI: button: Sleep Button [SLPB]
2024-10-24T12:22:08,944745+00:00 ACPI: \_SB_.PCI0.GSI1: Enabled at IRQ 36
2024-10-24T12:22:08,945165+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) v2.13.0g
2024-10-24T12:22:08,945686+00:00 ena 0000:00:05.0: enabling device (0010 -> 0012)
2024-10-24T12:22:08,964135+00:00 ena 0000:00:05.0: ENA device version: 0.10
2024-10-24T12:22:08,964571+00:00 ena 0000:00:05.0: ENA controller version: 0.0.1 implementation version 1
2024-10-24T12:22:09,044136+00:00 ena 0000:00:05.0: LLQ is not supported Fallback to host mode policy.
2024-10-24T12:22:09,055617+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) found at mem 80004000, mac addr 0a:82:0f:e4:4d:ed
2024-10-24T12:22:09,124364+00:00 ena 0000:00:05.0 ens5: renamed from eth0
2024-10-24T12:22:09,613566+00:00 RPC: Registered named UNIX socket transport module.
2024-10-24T12:22:09,614057+00:00 RPC: Registered udp transport module.
2024-10-24T12:22:09,614482+00:00 RPC: Registered tcp transport module.
2024-10-24T12:22:09,614848+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2024-10-24T12:22:09,897753+00:00 ena 0000:00:05.0 ens5: Local page cache is disabled for less than 16 channels
2024-10-24T12:22:41,594110+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:22:42,526527+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:22:42,602098+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): enie25e19d3d81: link becomes ready
2024-10-24T12:22:48,152775+00:00 pci 0000:00:06.0: [1d0f:ec20] type 00 class 0x020000
2024-10-24T12:22:48,153349+00:00 pci 0000:00:06.0: reg 0x10: [mem 0x00000000-0x00003fff]
2024-10-24T12:22:48,154029+00:00 pci 0000:00:06.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T12:22:48,154693+00:00 pci 0000:00:06.0: BAR 0: assigned [mem 0x8000c000-0x8000ffff]
2024-10-24T12:22:48,155362+00:00 ena 0000:00:06.0: enabling device (0000 -> 0002)
2024-10-24T12:22:48,167423+00:00 ena 0000:00:06.0: ENA device version: 0.10
2024-10-24T12:22:48,167836+00:00 ena 0000:00:06.0: ENA controller version: 0.0.1 implementation version 1
2024-10-24T12:22:48,242116+00:00 ena 0000:00:06.0: LLQ is not supported Fallback to host mode policy.
2024-10-24T12:22:48,253213+00:00 ena 0000:00:06.0: Elastic Network Adapter (ENA) found at mem 8000c000, mac addr 0a:be:92:be:bb:53
2024-10-24T12:22:48,282285+00:00 ena 0000:00:06.0 ens6: renamed from eth0
2024-10-24T12:22:48,681969+00:00 ena 0000:00:06.0 ens6: Local page cache is disabled for less than 16 channels
2024-10-24T12:29:27,828475+00:00 Initializing XFRM netlink socket
2024-10-24T12:29:28,239022+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2024-10-24T12:29:29,193705+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2024-10-24T12:29:30,396062+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-10-24T12:29:33,334433+00:00 eth0: renamed from tmpb23ab
2024-10-24T12:29:33,384723+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:29:33,385311+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc8d8b3e4b123a: link becomes ready
2024-10-24T12:29:33,425613+00:00 eth0: renamed from tmp02f98
2024-10-24T12:29:33,477705+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxce056135bac62: link becomes ready
2024-10-24T12:37:13,336158+00:00 eth0: renamed from tmp137a0
2024-10-24T12:37:13,375539+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:37:13,376078+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc7ae36d15aff0: link becomes ready
2024-10-24T12:41:11,596307+00:00 eth0: renamed from tmpa5410
2024-10-24T12:41:11,646300+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:41:11,646842+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc860a9c3f9d11: link becomes ready
2024-10-24T12:48:21,917647+00:00 eth0: renamed from tmp3efd4
2024-10-24T12:48:21,968314+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:48:21,968869+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcfcd0c83e1200: link becomes ready
2024-10-24T12:48:22,018042+00:00 eth0: renamed from tmp4d571
2024-10-24T12:48:22,084114+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc539949a7acb4: link becomes ready
2024-10-24T12:48:23,768050+00:00 eth0: renamed from tmp4ea2c
2024-10-24T12:48:23,808366+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:48:23,808927+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc96b3580ddadc: link becomes ready
2024-10-24T12:54:23,118463+00:00 printk: dmesg (16167): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
