CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4335ae16_b246_4e07_9223_fa3c3610616b.slice/cri-containerd-778e3de433e5fe94471a9ba023b639172c2a91294ba75036546daebf13ba3f08.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4335ae16_b246_4e07_9223_fa3c3610616b.slice/cri-containerd-02f98f991442e2eeda6a1bd6deb800d3e4ae38fe6f3683a9c0db452955840475.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf71880e5_5cca_49fc_be4e_88da6eb31aad.slice/cri-containerd-3b8eb8c67e2efecf254eaa4d0f8c6c2ca89421228a63688d7bd9ef16637874b4.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf71880e5_5cca_49fc_be4e_88da6eb31aad.slice/cri-containerd-8c94c214d3bf17897125556bdc8d0c003ea4100e857f33d2a7b32a35fab369b3.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb09baaa8_0207_48ea_bb9b_579ba205a771.slice/cri-containerd-c545ff4bda4964975bd3a69fdc5d19fb6bca75dbb6189665a846fd400b26efad.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb09baaa8_0207_48ea_bb9b_579ba205a771.slice/cri-containerd-3be3452a28d3df222b4e096c99541ceb2dfd70218606c7a6f9ba2ebe767ec2d3.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod899a9bce_7711_46e2_8d32_13f40aaaa40b.slice/cri-containerd-b23abc5a430892262db7981103dd627bbfe4531e807719e85f191d647b047dfc.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod899a9bce_7711_46e2_8d32_13f40aaaa40b.slice/cri-containerd-cca9672df0aadb9d0e05d67631ebf1c4288945f35e22e8e970edbcb43352bf7b.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff51ec_e59a_4d9f_beba_338563767231.slice/cri-containerd-652ccfc7968427acfbf894c7fcd164494855ed1ca97551f51e33d4eb3456881c.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff51ec_e59a_4d9f_beba_338563767231.slice/cri-containerd-4ea2c1a499198496cc8b3b3a9137face9126c8d0ff5079752bc550f1513ebc99.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff51ec_e59a_4d9f_beba_338563767231.slice/cri-containerd-99d988e941fe38dbbc8af7935de0e87f3762826767dd450ae0fc90439e4a32d4.scope
    708      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ea77538_c651_4f47_a5e0_da3f1e2ba7db.slice/cri-containerd-a5f51729fd1eb37a4a5bde5cacb582878cc0cb41f81a7411edd8a6b71051039a.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ea77538_c651_4f47_a5e0_da3f1e2ba7db.slice/cri-containerd-46f1b5a14347e3589dfef1957febc01361626e5afe84dc7073e73179f56d1aa6.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31a77a8f_fc3d_49ef_8f59_c451760ecd11.slice/cri-containerd-a54109f811e843b86203213156fbed92c89aff15d7519aa95544fd6c2adff647.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31a77a8f_fc3d_49ef_8f59_c451760ecd11.slice/cri-containerd-07863ed20d3abb2c720e07e496a80deba3b2eb24f8827038562ac1117f92ad57.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31a77a8f_fc3d_49ef_8f59_c451760ecd11.slice/cri-containerd-3e6e5ef0a927f4dc11cb76924063aacc4afc65cbecd5ba1ead5f5a2cf86107dc.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31a77a8f_fc3d_49ef_8f59_c451760ecd11.slice/cri-containerd-d9052dc33eeb85114e8543f4eb769853aded242d4f095070322cb34fd37bd5f2.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0639c91_6346_46d3_af1b_cf761f56a25e.slice/cri-containerd-6c3bdb4c53fb6246e7b114678c99e815604305ff46bc4a01861440ff6ab1e50d.scope
    696      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0639c91_6346_46d3_af1b_cf761f56a25e.slice/cri-containerd-4d571783e3dd42c431304259b5fd38ea4578778cfd0bccb4c77541232940066d.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6d52bbbb_9336_45d1_9c19_23e677b18940.slice/cri-containerd-f911095c5f1f4ca3a13d871ff668070a8bcb383032cbe284e0a81795c3867aa9.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6d52bbbb_9336_45d1_9c19_23e677b18940.slice/cri-containerd-8e3da263be4f16001cf85ce056da7d7fe667716142f0ce6385a41c637f112f8f.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod197d38d0_7dcc_41c4_a9da_c494951f554c.slice/cri-containerd-ad4e692fff4900fb080ddd273c16464d667fbc0eb5c3d9237d5afa81bf2eabbc.scope
    700      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod197d38d0_7dcc_41c4_a9da_c494951f554c.slice/cri-containerd-3efd464e45b6344e11b3f775a4d9235c6b36d7ba373c9483419d81ab13bf1025.scope
    673      cgroup_device   multi                                          
