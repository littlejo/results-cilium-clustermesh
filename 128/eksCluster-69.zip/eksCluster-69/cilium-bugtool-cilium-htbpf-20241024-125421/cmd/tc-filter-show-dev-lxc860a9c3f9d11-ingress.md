filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc860a9c3f9d11 direct-action not_in_hw id 614 tag 9339397896fd2c02 jited 
