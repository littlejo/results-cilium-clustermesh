KEY             VALUE
AgentLiveness   1968288078708
UTimeOffset     3378461964843750
