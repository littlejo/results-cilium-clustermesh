markdown output at /tmp/cilium-bugtool-20241024-125423.485+0000-UTC-4025897991/cmd/cilium-debuginfo-20241024-125454.062+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125423.485+0000-UTC-4025897991/cmd/cilium-debuginfo-20241024-125454.062+0000-UTC.json
