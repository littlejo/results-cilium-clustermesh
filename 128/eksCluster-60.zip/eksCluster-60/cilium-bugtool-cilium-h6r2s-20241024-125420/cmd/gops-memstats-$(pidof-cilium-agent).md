alloc: 126.85MB (133012656 bytes)
total-alloc: 3.16GB (3394396176 bytes)
sys: 231.32MB (242558292 bytes)
lookups: 0
mallocs: 76486102
frees: 75242570
heap-alloc: 126.85MB (133012656 bytes)
heap-sys: 184.61MB (193576960 bytes)
heap-idle: 33.16MB (34775040 bytes)
heap-in-use: 151.45MB (158801920 bytes)
heap-released: 15.52MB (16269312 bytes)
heap-objects: 1243532
stack-in-use: 35.34MB (37060608 bytes)
stack-sys: 35.34MB (37060608 bytes)
stack-mspan-inuse: 2.34MB (2453280 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 957.22KB (980193 bytes)
gc-sys: 5.53MB (5794936 bytes)
next-gc: when heap-alloc >= 153.25MB (160697208 bytes)
last-gc: 2024-10-24 12:54:23.29757432 +0000 UTC
gc-pause-total: 17.037178ms
gc-pause: 74659
gc-pause-end: 1729774463297574320
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005958179667736133
enable-gc: true
debug-gc: false
