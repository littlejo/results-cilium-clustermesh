top - 12:54:22 up 32 min,  0 users,  load average: 0.41, 0.43, 0.26
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.5 us, 32.3 sy,  0.0 ni, 61.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    289.9 free,   1049.1 used,   2497.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2606.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 289088  78400 S   6.7   7.4   1:07.69 cilium-+
   3257 root      20   0 1240432  16420  11356 S   6.7   0.4   0:00.03 cilium-+
    394 root      20   0 1229744  10076   3836 S   0.0   0.3   0:04.30 cilium-+
   3193 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3212 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3225 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3246 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3283 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3301 root      20   0 1228744   3976   3328 S   0.0   0.1   0:00.00 gops
