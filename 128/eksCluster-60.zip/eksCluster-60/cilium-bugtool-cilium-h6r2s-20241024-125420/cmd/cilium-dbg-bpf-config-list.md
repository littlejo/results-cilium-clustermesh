KEY             VALUE
AgentLiveness   1973303686391
UTimeOffset     3378461951171875
