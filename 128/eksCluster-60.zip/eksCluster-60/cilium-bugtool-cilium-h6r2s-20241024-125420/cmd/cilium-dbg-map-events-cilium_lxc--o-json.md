{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.078Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.586Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.590Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.645Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.653Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.685Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.892Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.892Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.959Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.983Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.013Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.626Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.650Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.694Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.694Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.734Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.938Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.946Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.001Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.033Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.053Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.615Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.621Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.735Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.763Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.807Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.821Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.840Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.008Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.022Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.104Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.115Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.148Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.713Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.717Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.753Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.776Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.801Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.812Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.834Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.063Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.067Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.120Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.125Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.160Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.591Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.623Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.653Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.685Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.748Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.970Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.975Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.033Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.045Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.081Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.482Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.517Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.524Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.569Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.570Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.571Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.824Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.825Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.884Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.900Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.939Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.294Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.320Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.337Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.380Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.401Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.416Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.702Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.708Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.790Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.800Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.830Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.182Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.218Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.231Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.272Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.275Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.307Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.538Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.544Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.597Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.602Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.636Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.076Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.084Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.116Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.141Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.158Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.408Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.408Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.465Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.476Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.502Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.804Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.895Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.914Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.926Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.992Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.004Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.191Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.213Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.261Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.294Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.315Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.645Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.660Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.713Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.740Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.752Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.945Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.974Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.990Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.997Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.003Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.691Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.695Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.728Z",
  "value": "id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.748Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.771Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.043Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.047Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.721Z",
  "value": "id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.730Z",
  "value": "id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08"
}

