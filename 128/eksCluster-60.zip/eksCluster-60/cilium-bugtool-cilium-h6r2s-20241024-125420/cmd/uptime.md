 12:54:22 up 32 min,  0 users,  load average: 0.41, 0.43, 0.26
