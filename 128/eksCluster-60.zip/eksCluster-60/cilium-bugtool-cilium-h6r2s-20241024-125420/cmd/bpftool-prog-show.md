35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:03+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:03+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:03+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:03+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:07+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
121: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
124: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:28:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag 06c6d85b43454577  gpl
	loaded_at 2024-10-24T12:28:56+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:28:56+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:28:56+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
510: sched_cls  name tail_ipv4_ct_egress  tag 2202981e81a1af1c  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 153
511: sched_cls  name tail_handle_ipv4  tag 0c75e68360516a23  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 154
513: sched_cls  name handle_policy  tag 1b88f15e050b0da3  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 156
514: sched_cls  name tail_ipv4_to_endpoint  tag f40d86dadc1713f3  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 157
515: sched_cls  name tail_handle_ipv4_cont  tag aedf4588c3f09012  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 158
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 159
517: sched_cls  name tail_handle_arp  tag 4d248d81a918cbc5  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 160
518: sched_cls  name cil_from_container  tag 15aed0c893033db9  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 161
519: sched_cls  name tail_ipv4_ct_ingress  tag 68ef4eb1befa98f3  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 162
520: sched_cls  name __send_drop_notify  tag 741fe187a34ff867  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 163
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
524: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
525: sched_cls  name tail_handle_arp  tag 9eb4174b8190d0bb  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 165
526: sched_cls  name tail_handle_ipv4  tag 16502befabd83eb6  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 166
527: sched_cls  name tail_handle_ipv4_cont  tag cb014e2a86b77d38  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,110,41,101,82,83,39,76,74,77,109,40,37,38,81
	btf_id 167
528: sched_cls  name tail_ipv4_to_endpoint  tag 62d4f79ff5bb9817  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,110,41,82,83,80,101,39,109,40,37,38
	btf_id 168
529: sched_cls  name tail_ipv4_ct_egress  tag 2202981e81a1af1c  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 169
530: sched_cls  name cil_from_container  tag 8e482eacbd7c0739  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 170
531: sched_cls  name handle_policy  tag 20baff066dc7dad8  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,110,41,80,101,39,84,75,40,37,38
	btf_id 171
532: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 172
533: sched_cls  name tail_ipv4_ct_ingress  tag 263fd3ed472539eb  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 173
534: sched_cls  name __send_drop_notify  tag c71270b3d0e283bc  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
536: sched_cls  name tail_handle_ipv4_cont  tag 7245bcfb49d7e552  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,113,41,100,82,83,39,76,74,77,112,40,37,38,81
	btf_id 177
537: sched_cls  name tail_ipv4_to_endpoint  tag e5739f6bd2fd6023  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,113,41,82,83,80,100,39,112,40,37,38
	btf_id 178
539: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 180
540: sched_cls  name __send_drop_notify  tag b1af966fe0018aa6  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 181
541: sched_cls  name cil_from_container  tag 0e00b43e9dae1481  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,76
	btf_id 182
542: sched_cls  name tail_handle_arp  tag ada03e108758bde6  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 183
543: sched_cls  name tail_ipv4_ct_ingress  tag f7a8b04b2cd3ea59  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 184
544: sched_cls  name handle_policy  tag 6e61b6b90cac6383  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,112,82,83,113,41,80,100,39,84,75,40,37,38
	btf_id 185
545: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 186
546: sched_cls  name tail_handle_ipv4  tag f629fba80a157086  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 187
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name __send_drop_notify  tag 590729142779cb0b  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
560: sched_cls  name tail_handle_ipv4_from_host  tag 8c681254a41df95c  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 190
561: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 191
563: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 194
566: sched_cls  name tail_handle_ipv4_from_host  tag 8c681254a41df95c  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 197
569: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 201
572: sched_cls  name __send_drop_notify  tag 590729142779cb0b  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
573: sched_cls  name tail_handle_ipv4_from_host  tag 8c681254a41df95c  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 205
577: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 209
578: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 210
579: sched_cls  name __send_drop_notify  tag 590729142779cb0b  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
582: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 215
583: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 216
584: sched_cls  name __send_drop_notify  tag 590729142779cb0b  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 217
585: sched_cls  name tail_handle_ipv4_from_host  tag 8c681254a41df95c  gpl
	loaded_at 2024-10-24T12:28:59+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 218
626: sched_cls  name tail_handle_ipv4  tag de7ee5dfca422124  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 233
627: sched_cls  name tail_ipv4_to_endpoint  tag 57867a13555b2b57  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 234
628: sched_cls  name handle_policy  tag da9ecbf83fcb1a46  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 235
629: sched_cls  name tail_handle_arp  tag 4b532954f2bd6752  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 236
630: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 237
632: sched_cls  name __send_drop_notify  tag 2a1b14d0ae492156  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
633: sched_cls  name cil_from_container  tag b5c1085ca73b94b4  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 240
634: sched_cls  name tail_handle_ipv4_cont  tag 2de6c4ca363050b7  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 241
635: sched_cls  name tail_ipv4_ct_egress  tag 727571de63ecbe20  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 242
636: sched_cls  name tail_ipv4_ct_ingress  tag 7770dc3eac0d84ea  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 243
641: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
644: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
676: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
679: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3267: sched_cls  name tail_handle_ipv4  tag 8309a5e2b0916119  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,623
	btf_id 3053
3268: sched_cls  name __send_drop_notify  tag 9762fa9987f8c9c4  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3054
3269: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,623
	btf_id 3055
3270: sched_cls  name cil_from_container  tag fb3928ed0166f8f4  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 623,76
	btf_id 3056
3271: sched_cls  name handle_policy  tag 97f49848693ae113  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,623,82,83,624,41,80,149,39,84,75,40,37,38
	btf_id 3057
3272: sched_cls  name tail_ipv4_ct_egress  tag ffa43f311b738b37  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,623,82,83,624,84
	btf_id 3060
3276: sched_cls  name tail_ipv4_to_endpoint  tag 2be74c5589363535  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,624,41,82,83,80,149,39,623,40,37,38
	btf_id 3061
3279: sched_cls  name tail_handle_ipv4_cont  tag 8aa4917d875b96a8  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,624,41,149,82,83,39,76,74,77,623,40,37,38,81
	btf_id 3065
3283: sched_cls  name tail_handle_arp  tag 384f77778a938eaf  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,623
	btf_id 3070
3284: sched_cls  name tail_ipv4_ct_ingress  tag 2ad1560ff82f48d4  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,623,82,83,624,84
	btf_id 3072
3322: sched_cls  name tail_handle_ipv4_cont  tag ce2343aebbcec79a  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,152,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3113
3323: sched_cls  name tail_handle_ipv4  tag d4aa8d5ea2782ad3  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3115
3324: sched_cls  name __send_drop_notify  tag 35aebdaf8d4de99d  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3117
3325: sched_cls  name tail_ipv4_ct_egress  tag cb6cf0ff4c9a7ab8  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3118
3326: sched_cls  name tail_ipv4_to_endpoint  tag 3dcdc4361df8d5b0  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,152,39,633,40,37,38
	btf_id 3116
3327: sched_cls  name tail_handle_ipv4_cont  tag 8d2f8511b9dd93d4  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,145,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3119
3328: sched_cls  name tail_ipv4_ct_ingress  tag b43ced89e1806759  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3120
3329: sched_cls  name tail_ipv4_ct_egress  tag a03204818b7f1aff  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3122
3330: sched_cls  name cil_from_container  tag 0da014f8bced327e  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3123
3331: sched_cls  name __send_drop_notify  tag d498c6b9a198c4ff  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3124
3332: sched_cls  name tail_handle_arp  tag a6a0bdc672db353c  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3125
3333: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3126
3334: sched_cls  name handle_policy  tag 29ca760620b28902  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,145,39,84,75,40,37,38
	btf_id 3121
3335: sched_cls  name tail_handle_ipv4  tag 91664bb03cbe9cff  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3127
3336: sched_cls  name tail_ipv4_to_endpoint  tag 9d9658f1580c79b1  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,145,39,636,40,37,38
	btf_id 3128
3338: sched_cls  name tail_ipv4_ct_ingress  tag d98c6a94588a4158  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3131
3339: sched_cls  name tail_handle_arp  tag f78d7bbcc2aa8742  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3132
3340: sched_cls  name cil_from_container  tag d8cc14a62432dec1  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3133
3341: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3134
3342: sched_cls  name handle_policy  tag ee28b7ddf220c69d  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,152,39,84,75,40,37,38
	btf_id 3130
