key: c5 02 00 00  value: 01 02 00 00
key: f9 02 00 00  value: 0e 0d 00 00
key: a6 03 00 00  value: 06 0d 00 00
key: ff 04 00 00  value: 74 02 00 00
key: e5 09 00 00  value: c7 0c 00 00
key: 8b 0a 00 00  value: 13 02 00 00
key: c1 0e 00 00  value: 20 02 00 00
Found 7 elements
