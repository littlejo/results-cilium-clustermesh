IP ADDRESS         LOCAL ENDPOINT INFO
10.60.0.242:0      id=709   sec_id=4059187 flags=0x0000 ifindex=14  mac=76:A5:41:6D:70:10 nodemac=5A:0C:84:DD:1D:AB   
10.60.0.240:0      id=1279  sec_id=4016672 flags=0x0000 ifindex=18  mac=E2:9A:48:8E:0E:F3 nodemac=02:C2:45:85:1E:50   
10.60.0.191:0      id=2699  sec_id=4059187 flags=0x0000 ifindex=12  mac=A2:F7:C1:9A:96:08 nodemac=FE:C8:61:DF:99:E2   
10.60.0.238:0      id=761   sec_id=4027136 flags=0x0000 ifindex=24  mac=AA:90:D1:77:54:0F nodemac=A6:3B:2C:86:24:08   
172.31.181.22:0    (localhost)                                                                                        
172.31.146.139:0   (localhost)                                                                                        
10.60.0.215:0      id=3777  sec_id=4     flags=0x0000 ifindex=10  mac=3E:77:22:64:B1:E0 nodemac=36:7F:42:C4:B4:6D     
10.60.0.8:0        id=934   sec_id=4016992 flags=0x0000 ifindex=20  mac=32:F1:3C:DE:AE:04 nodemac=92:9C:E8:23:F9:E0   
10.60.0.134:0      (localhost)                                                                                        
10.60.0.168:0      id=2533  sec_id=4002541 flags=0x0000 ifindex=22  mac=82:92:EB:F7:EE:01 nodemac=DA:64:0C:29:63:C3   
