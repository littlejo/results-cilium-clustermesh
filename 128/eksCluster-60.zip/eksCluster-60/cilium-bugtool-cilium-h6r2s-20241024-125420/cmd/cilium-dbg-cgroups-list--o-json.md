[
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod056c46db_eaf7_467c_ad51_79f64b6bb466.slice/cri-containerd-854bbd4530f06114c292e092dbd77c112f1cccdcfce9aab7bbb424508e89722f.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod056c46db_eaf7_467c_ad51_79f64b6bb466.slice/cri-containerd-c1a770d1b6017619cc8404850534c87aa6ba5b5f3fb6d9132afc22d6ed3d5af3.scope"
      }
    ],
    "ips": [
      "10.60.0.168"
    ],
    "name": "echo-same-node-86d9cc975c-h5jvp",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0df6de4d_d3b0_4323_9b6c_4470541ff921.slice/cri-containerd-9fcdec8a039493d191686e91bd20632b3df047eae629caddd25a9c139d8618b8.scope"
      }
    ],
    "ips": [
      "10.60.0.191"
    ],
    "name": "coredns-cc6ccd49c-xw427",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7452aec5_afc2_4ab8_803b_82fa27351293.slice/cri-containerd-d4431b587dac8fbe466ccbf2fb631579f9d948ef199999ba4c5ebc23a9bc875f.scope"
      }
    ],
    "ips": [
      "10.60.0.242"
    ],
    "name": "coredns-cc6ccd49c-vnm5b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb999546_9509_4de6_9537_b9bd7d38bd33.slice/cri-containerd-4ab333ae0ac0e3c862890c7c2c5c1436875ec14c2504aa0498f9d63965ceb901.scope"
      }
    ],
    "ips": [
      "10.60.0.8"
    ],
    "name": "client-974f6c69d-t4fb4",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eadfdcb_5128_49e7_8157_1c610bc69542.slice/cri-containerd-45d28fea8f8cf421f44cc77ac52c740aa594c94290ada6cbc8a68deda41ea576.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eadfdcb_5128_49e7_8157_1c610bc69542.slice/cri-containerd-fe7ab17bfb617074cc342caf101ac02dbc73dcd592a13d5b58b501284a6b7ae8.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eadfdcb_5128_49e7_8157_1c610bc69542.slice/cri-containerd-9c73f6bcbe862055bc9c8c7a9cd3480854efbe2bce1e78eecd865a86d9f1eb08.scope"
      }
    ],
    "ips": [
      "10.60.0.240"
    ],
    "name": "clustermesh-apiserver-57b8565fb-w7bkx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod380f2ce9_70a9_44c8_8efe_3e1ca295d73e.slice/cri-containerd-aeb21cf31cb2aa2cc4385b94187964d2c0b6317d5863f99f20b51bd271dc2e52.scope"
      }
    ],
    "ips": [
      "10.60.0.238"
    ],
    "name": "client2-57cf4468f-2mw54",
    "namespace": "cilium-test-1"
  }
]

