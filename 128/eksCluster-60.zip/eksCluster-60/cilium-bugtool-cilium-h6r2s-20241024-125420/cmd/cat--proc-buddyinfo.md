Node 0, zone      DMA    529    155     26     39     11      5      7      2      4      5     34 
Node 0, zone   Normal    608     51     20      5     14     12      5      2      4      1      7 
