xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 578
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 563
cilium_host(7) clsact/egress cil_from_host-cilium_host id 561
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 541
lxc11fa3eb0a174(12) clsact/ingress cil_from_container-lxc11fa3eb0a174 id 530
lxc88a449de51e4(14) clsact/ingress cil_from_container-lxc88a449de51e4 id 518
lxca2c69157e43a(18) clsact/ingress cil_from_container-lxca2c69157e43a id 633
lxc1fa8fcdf4bea(20) clsact/ingress cil_from_container-lxc1fa8fcdf4bea id 3340
lxc66020b86ec7f(22) clsact/ingress cil_from_container-lxc66020b86ec7f id 3270
lxcedfcc0b86452(24) clsact/ingress cil_from_container-lxcedfcc0b86452 id 3330

flow_dissector:

netfilter:

