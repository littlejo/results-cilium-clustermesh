Total: 595
TCP:   4010 (estab 302, closed 3689, orphaned 0, timewait 3232)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  321       310       11       
INET	  331       316       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                   172.31.181.22%ens5:68         0.0.0.0:*    uid:192 ino:116432 sk:1634 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31407 sk:1635 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15692 sk:1636 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:41829      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31313 sk:1637 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31406 sk:1638 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15693 sk:1639 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::42f:9fff:fe2c:e183]%ens5:546           [::]:*    uid:192 ino:15185 sk:163a cgroup:unreachable:bd0 v6only:1 <->                   
