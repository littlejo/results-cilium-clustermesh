USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3257  0.0  0.4 1240176 16420 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3272  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3246  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3225  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3212  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3193  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.4  7.3 1539060 289088 ?      Ssl  12:28   1:07 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 10076 ?       Sl   12:28   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
