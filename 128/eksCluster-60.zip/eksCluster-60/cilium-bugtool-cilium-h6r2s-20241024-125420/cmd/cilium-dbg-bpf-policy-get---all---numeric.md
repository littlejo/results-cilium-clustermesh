Endpoint ID: 709
Path: /sys/fs/bpf/tc/globals/cilium_policy_00709

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    241591   2179      0        
Allow    Ingress     1          ANY          NONE         disabled    147506   1692      0        
Allow    Egress      0          ANY          NONE         disabled    69882    691       0        


Endpoint ID: 761
Path: /sys/fs/bpf/tc/globals/cilium_policy_00761

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 934
Path: /sys/fs/bpf/tc/globals/cilium_policy_00934

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1279
Path: /sys/fs/bpf/tc/globals/cilium_policy_01279

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6091126   61437     0        
Allow    Ingress     1          ANY          NONE         disabled    5506895   58153     0        
Allow    Egress      0          ANY          NONE         disabled    7166001   70510     0        


Endpoint ID: 1858
Path: /sys/fs/bpf/tc/globals/cilium_policy_01858

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2533
Path: /sys/fs/bpf/tc/globals/cilium_policy_02533

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    380960   4445      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2699
Path: /sys/fs/bpf/tc/globals/cilium_policy_02699

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    220571   1993      0        
Allow    Ingress     1          ANY          NONE         disabled    146912   1683      0        
Allow    Egress      0          ANY          NONE         disabled    66564    660       0        


Endpoint ID: 3777
Path: /sys/fs/bpf/tc/globals/cilium_policy_03777

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6231250   77019     0        
Allow    Ingress     1          ANY          NONE         disabled    65114     785       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


