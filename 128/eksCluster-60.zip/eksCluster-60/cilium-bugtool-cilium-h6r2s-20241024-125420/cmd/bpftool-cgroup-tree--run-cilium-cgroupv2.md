CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdcb57d6_aeea_4cf7_9c98_318399abf535.slice/cri-containerd-b03a8dbad05daf0aa752decd56c3e653e4640adb5812c126cbe61a3bdb5b8d14.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdcb57d6_aeea_4cf7_9c98_318399abf535.slice/cri-containerd-16c051cc9f3c67e2daf03ac9b48e12c7a53200ad4aa3cb9d0168c88048a26c11.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7452aec5_afc2_4ab8_803b_82fa27351293.slice/cri-containerd-89342a0383e4c598cbc1d69c9edf6a9e9e4796a19bd662b77d24971ff54c9756.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7452aec5_afc2_4ab8_803b_82fa27351293.slice/cri-containerd-d4431b587dac8fbe466ccbf2fb631579f9d948ef199999ba4c5ebc23a9bc875f.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0df6de4d_d3b0_4323_9b6c_4470541ff921.slice/cri-containerd-74fb8dea1aea6a763a7df28ce9277795a17e4a2bb6e2baa9a40ccfa039383ba0.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0df6de4d_d3b0_4323_9b6c_4470541ff921.slice/cri-containerd-9fcdec8a039493d191686e91bd20632b3df047eae629caddd25a9c139d8618b8.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a6ff584_5c83_43b4_8c3c_4e3a840d2bee.slice/cri-containerd-7640c165dbeda6ee038e914cde28214e883cbb45372f9d71e7ca90899a2a7f64.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a6ff584_5c83_43b4_8c3c_4e3a840d2bee.slice/cri-containerd-4a860cf7618ff24f3b6f6407c8559bc1556df1cb318a8993d77710e1394cf2fc.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod380f2ce9_70a9_44c8_8efe_3e1ca295d73e.slice/cri-containerd-a5977f0463f2f45b8cc1038176d96a1ed5364975ef7b0cd25851779fc5c48e80.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod380f2ce9_70a9_44c8_8efe_3e1ca295d73e.slice/cri-containerd-aeb21cf31cb2aa2cc4385b94187964d2c0b6317d5863f99f20b51bd271dc2e52.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eadfdcb_5128_49e7_8157_1c610bc69542.slice/cri-containerd-9c73f6bcbe862055bc9c8c7a9cd3480854efbe2bce1e78eecd865a86d9f1eb08.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eadfdcb_5128_49e7_8157_1c610bc69542.slice/cri-containerd-0e663b8b5976f5022c05bd33038e8ee9815778d12e6f0b859eba2fd93be22ed4.scope
    644      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eadfdcb_5128_49e7_8157_1c610bc69542.slice/cri-containerd-fe7ab17bfb617074cc342caf101ac02dbc73dcd592a13d5b58b501284a6b7ae8.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eadfdcb_5128_49e7_8157_1c610bc69542.slice/cri-containerd-45d28fea8f8cf421f44cc77ac52c740aa594c94290ada6cbc8a68deda41ea576.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb999546_9509_4de6_9537_b9bd7d38bd33.slice/cri-containerd-6970b03174973a9394b24e4aaa9671749a7b81981f910655516fb09c473eafb2.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb999546_9509_4de6_9537_b9bd7d38bd33.slice/cri-containerd-4ab333ae0ac0e3c862890c7c2c5c1436875ec14c2504aa0498f9d63965ceb901.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93f5ccb6_01b4_4ba2_91cd_a9efeb254ae1.slice/cri-containerd-7ce3d2c2c162eb98d03d62ccc04cf78deafd46fdaef298981f8e5762c44b5c0b.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93f5ccb6_01b4_4ba2_91cd_a9efeb254ae1.slice/cri-containerd-9252187be1a85e255830acbe46c189bad311e26554706ec7887582e9d920496d.scope
    124      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc460751e_85dc_46b2_93f6_27c08fd6260f.slice/cri-containerd-b656bd2d7a3949b9a712f9dfe19e67abf2f5dfda824aae2f65915f8c7c00b544.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc460751e_85dc_46b2_93f6_27c08fd6260f.slice/cri-containerd-d7dc00bfe124b3377efd5c7bda11b661d6631a39a7f921743737e936e8d254b3.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod056c46db_eaf7_467c_ad51_79f64b6bb466.slice/cri-containerd-854bbd4530f06114c292e092dbd77c112f1cccdcfce9aab7bbb424508e89722f.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod056c46db_eaf7_467c_ad51_79f64b6bb466.slice/cri-containerd-7dfbe1cfc94b22c2616b981dab52ba51c9f7d03eea9d2b2d9ef5a5a64afd103c.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod056c46db_eaf7_467c_ad51_79f64b6bb466.slice/cri-containerd-c1a770d1b6017619cc8404850534c87aa6ba5b5f3fb6d9132afc22d6ed3d5af3.scope
    725      cgroup_device   multi                                          
