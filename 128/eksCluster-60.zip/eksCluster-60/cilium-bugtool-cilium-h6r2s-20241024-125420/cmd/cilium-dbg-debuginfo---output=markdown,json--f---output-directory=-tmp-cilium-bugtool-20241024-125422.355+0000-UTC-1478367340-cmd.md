markdown output at /tmp/cilium-bugtool-20241024-125422.355+0000-UTC-1478367340/cmd/cilium-debuginfo-20241024-125452.818+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125422.355+0000-UTC-1478367340/cmd/cilium-debuginfo-20241024-125452.818+0000-UTC.json
