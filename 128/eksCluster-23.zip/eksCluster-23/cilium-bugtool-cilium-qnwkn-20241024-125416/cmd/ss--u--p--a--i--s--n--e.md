Total: 589
TCP:   3935 (estab 313, closed 3603, orphaned 0, timewait 3140)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  332       320       12       
INET	  342       326       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:34405      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:28662 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.212.95%ens5:68         0.0.0.0:*    uid:192 ino:89396 sk:2 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:29488 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14292 sk:4 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:29487 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14293 sk:6 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::826:28ff:fe6d:e25d]%ens5:546           [::]:*    uid:192 ino:16474 sk:7 cgroup:unreachable:bd0 v6only:1 <->                   
