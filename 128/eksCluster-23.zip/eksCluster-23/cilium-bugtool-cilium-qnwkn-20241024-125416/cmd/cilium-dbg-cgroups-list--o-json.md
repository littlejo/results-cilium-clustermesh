[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c572ef4_251d_486c_9cd9_492390bc3ce1.slice/cri-containerd-9a21027f860a0ec94e31594a6971ea1a798819da8a53545dad73ff8b5e92410d.scope"
      }
    ],
    "ips": [
      "10.23.0.240"
    ],
    "name": "coredns-cc6ccd49c-lqfbn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod812342a4_c463_4a43_93c8_fa3fc79a1d3b.slice/cri-containerd-3df292598eba6655770c8e4e17c5adf21d8ef3389661d013f40ef82deddc9808.scope"
      }
    ],
    "ips": [
      "10.23.0.206"
    ],
    "name": "client2-57cf4468f-n8pfd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb7ddc4_faef_4ce8_8550_56810ac04687.slice/cri-containerd-61bbf3d05b8cbe890a724420fe61f42395c1ab4d9b79889bae016f1ecb348542.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb7ddc4_faef_4ce8_8550_56810ac04687.slice/cri-containerd-e5f244ecd1943f55f6be08bc7a0bf1fea65757ae799f6ea16d4e2966285d591f.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb7ddc4_faef_4ce8_8550_56810ac04687.slice/cri-containerd-d9f2c9940ba697d5b388b33878a95b14adff129f728697c5a69c1d49e46df1a4.scope"
      }
    ],
    "ips": [
      "10.23.0.24"
    ],
    "name": "clustermesh-apiserver-6478bf7658-rqss2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd106c7b3_c81a_4555_814a_219cb2e72fbf.slice/cri-containerd-659a27118314e924c2eddfde0db0ad9e68cdee5369b29a3c9322066bac1003d6.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd106c7b3_c81a_4555_814a_219cb2e72fbf.slice/cri-containerd-9625e3dc966579d563557ee8b40e8316148b6546ddfa9e20ecc0a0fb1f69a499.scope"
      }
    ],
    "ips": [
      "10.23.0.179"
    ],
    "name": "echo-same-node-86d9cc975c-8pgj5",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbee77e42_114f_4886_b9b0_6852a6605157.slice/cri-containerd-a06b32910a750b150fd20bea1affae8ffb4c4bfe5c65092ba4d6672211b68ef5.scope"
      }
    ],
    "ips": [
      "10.23.0.236"
    ],
    "name": "coredns-cc6ccd49c-q9pxc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29bc04e2_9649_46ae_b215_c02fc413506e.slice/cri-containerd-c6942958945bc186c2f76556edb6d678edc5961a923468376b13511272cef68e.scope"
      }
    ],
    "ips": [
      "10.23.0.186"
    ],
    "name": "client-974f6c69d-cdhnt",
    "namespace": "cilium-test-1"
  }
]

