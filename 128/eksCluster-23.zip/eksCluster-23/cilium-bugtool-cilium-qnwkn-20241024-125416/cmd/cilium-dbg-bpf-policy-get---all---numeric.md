Endpoint ID: 69
Path: /sys/fs/bpf/tc/globals/cilium_policy_00069

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376663   4392      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 956
Path: /sys/fs/bpf/tc/globals/cilium_policy_00956

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1019
Path: /sys/fs/bpf/tc/globals/cilium_policy_01019

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3212     33        0        
Allow    Ingress     1          ANY          NONE         disabled    163571   1882      0        
Allow    Egress      0          ANY          NONE         disabled    21193    237       0        


Endpoint ID: 1101
Path: /sys/fs/bpf/tc/globals/cilium_policy_01101

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6230790   77007     0        
Allow    Ingress     1          ANY          NONE         disabled    64402     776       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2054
Path: /sys/fs/bpf/tc/globals/cilium_policy_02054

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3012
Path: /sys/fs/bpf/tc/globals/cilium_policy_03012

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2684     27        0        
Allow    Ingress     1          ANY          NONE         disabled    161921   1857      0        
Allow    Egress      0          ANY          NONE         disabled    19979    224       0        


Endpoint ID: 3123
Path: /sys/fs/bpf/tc/globals/cilium_policy_03123

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3882
Path: /sys/fs/bpf/tc/globals/cilium_policy_03882

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6074281   60779     0        
Allow    Ingress     1          ANY          NONE         disabled    5141521   54137     0        
Allow    Egress      0          ANY          NONE         disabled    6481266   64450     0        


