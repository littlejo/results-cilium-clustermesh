1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:26:28:6d:e2:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.212.95/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3417sec preferred_lft 3417sec
    inet6 fe80::826:28ff:fe6d:e25d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1a:0b:83:09:b7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.221.136/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::81a:bff:fe83:9b7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:a1:c5:a6:c4:fe brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8a1:c5ff:fea6:c4fe/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:6d:50:eb:f2:fb brd ff:ff:ff:ff:ff:ff
    inet 10.23.0.148/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7c6d:50ff:feeb:f2fb/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d2:2f:a7:db:1d:b2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d02f:a7ff:fedb:1db2/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:85:99:5d:bf:9e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::85:99ff:fe5d:bf9e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc142c3b4c562d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:0d:28:c1:76:a6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e00d:28ff:fec1:76a6/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc46d3d9bf47c0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:22:7e:df:d8:9b brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::ac22:7eff:fedf:d89b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8dcc53808ff1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:3f:eb:24:33:7f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::dc3f:ebff:fe24:337f/64 scope link 
       valid_lft forever preferred_lft forever
20: lxce16f4e1f439a@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:e1:e9:f2:dd:f8 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4ce1:e9ff:fef2:ddf8/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcd24ce014e864@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:09:1d:9d:51:1b brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::7809:1dff:fe9d:511b/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc9130418254a4@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:bc:65:52:f4:ec brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::3cbc:65ff:fe52:f4ec/64 scope link 
       valid_lft forever preferred_lft forever
