alloc: 139.34MB (146108544 bytes)
total-alloc: 3.07GB (3298474848 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 74796097
frees: 73370151
heap-alloc: 139.34MB (146108544 bytes)
heap-sys: 176.77MB (185352192 bytes)
heap-idle: 20.11MB (21086208 bytes)
heap-in-use: 156.66MB (164265984 bytes)
heap-released: 6.59MB (6905856 bytes)
heap-objects: 1425946
stack-in-use: 35.19MB (36896768 bytes)
stack-sys: 35.19MB (36896768 bytes)
stack-mspan-inuse: 2.43MB (2548480 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 981.33KB (1004881 bytes)
gc-sys: 5.53MB (5803176 bytes)
next-gc: when heap-alloc >= 148.67MB (155888328 bytes)
last-gc: 2024-10-24 12:54:12.522021792 +0000 UTC
gc-pause-total: 12.578272ms
gc-pause: 137124
gc-pause-end: 1729774452522021792
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005264226637932897
enable-gc: true
debug-gc: false
