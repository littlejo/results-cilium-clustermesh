Node 0, zone      DMA    122     65     31     34     20      6      7      6      5      5     36 
Node 0, zone   Normal     27    109      3     10     11      4      4      3      1      2      8 
