xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 560
ens6(5) clsact/ingress cil_from_netdev-ens6 id 565
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 532
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 576
lxc142c3b4c562d(12) clsact/ingress cil_from_container-lxc142c3b4c562d id 520
lxc46d3d9bf47c0(14) clsact/ingress cil_from_container-lxc46d3d9bf47c0 id 546
lxc8dcc53808ff1(18) clsact/ingress cil_from_container-lxc8dcc53808ff1 id 641
lxce16f4e1f439a(20) clsact/ingress cil_from_container-lxce16f4e1f439a id 3362
lxcd24ce014e864(22) clsact/ingress cil_from_container-lxcd24ce014e864 id 3344
lxc9130418254a4(24) clsact/ingress cil_from_container-lxc9130418254a4 id 3294

flow_dissector:

netfilter:

