markdown output at /tmp/cilium-bugtool-20241024-125417.996+0000-UTC-3105727928/cmd/cilium-debuginfo-20241024-125448.781+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.996+0000-UTC-3105727928/cmd/cilium-debuginfo-20241024-125448.781+0000-UTC.json
