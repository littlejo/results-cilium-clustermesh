key: 45 00 00 00  value: e4 0c 00 00
key: bc 03 00 00  value: 1a 0d 00 00
key: fb 03 00 00  value: 0f 02 00 00
key: 4d 04 00 00  value: 43 02 00 00
key: 06 08 00 00  value: 17 0d 00 00
key: c4 0b 00 00  value: 32 02 00 00
key: 2a 0f 00 00  value: 80 02 00 00
Found 7 elements
