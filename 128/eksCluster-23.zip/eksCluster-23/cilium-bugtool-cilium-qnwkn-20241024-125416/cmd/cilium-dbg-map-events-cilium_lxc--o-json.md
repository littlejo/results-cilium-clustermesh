{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.396Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.445Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.041Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.096Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.111Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.153Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.164Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.192Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.413Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.419Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.475Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.501Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.540Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.085Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.088Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.123Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.137Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.176Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.189Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.213Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.487Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.489Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.549Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.585Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.597Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.193Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.199Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.242Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.263Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.280Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.492Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.495Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.561Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.586Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.613Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.122Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.129Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.153Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.173Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.201Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.226Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.247Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.457Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.473Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.513Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.552Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.556Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.073Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.077Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.142Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.182Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.188Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.397Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.415Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.473Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.497Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.527Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.932Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.943Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.999Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.007Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.037Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.280Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.287Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.356Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.361Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.396Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.790Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.820Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.834Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.879Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.882Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.913Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.173Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.224Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.298Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.330Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.370Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.743Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.752Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.792Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.800Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.836Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.065Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.083Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.122Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.154Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.166Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.561Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.590Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.615Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.644Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.645Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.660Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.897Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.897Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.946Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.983Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.007Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.294Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.341Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.379Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.438Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.448Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.672Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.672Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.737Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.746Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.781Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.059Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.100Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.107Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.151Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.152Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.187Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.442Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.443Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.462Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.493Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.263Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.267Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.303Z",
  "value": "id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.341Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.346Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.644Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.662Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.323Z",
  "value": "id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.338Z",
  "value": "id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B"
}

