top - 12:54:18 up 33 min,  0 users,  load average: 0.48, 0.77, 0.42
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 12.9 us, 29.0 sy,  0.0 ni, 58.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    285.8 free,   1052.8 used,   2497.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2602.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3176 root      20   0 1240432  16224  11228 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1539060 287848  78652 S   0.0   7.3   1:06.36 cilium-+
    393 root      20   0 1229744  10108   3900 S   0.0   0.3   0:04.51 cilium-+
   3133 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3134 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3145 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
   3146 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
   3177 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
   3212 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
   3230 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
