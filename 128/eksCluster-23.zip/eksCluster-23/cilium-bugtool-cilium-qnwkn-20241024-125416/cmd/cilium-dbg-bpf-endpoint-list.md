IP ADDRESS         LOCAL ENDPOINT INFO
10.23.0.206:0      id=956   sec_id=1594930 flags=0x0000 ifindex=20  mac=16:37:D3:4C:B9:AF nodemac=4E:E1:E9:F2:DD:F8   
172.31.212.95:0    (localhost)                                                                                        
10.23.0.179:0      id=69    sec_id=1606263 flags=0x0000 ifindex=24  mac=72:39:74:74:0F:55 nodemac=3E:BC:65:52:F4:EC   
10.23.0.148:0      (localhost)                                                                                        
172.31.221.136:0   (localhost)                                                                                        
10.23.0.236:0      id=1019  sec_id=1590586 flags=0x0000 ifindex=12  mac=A6:38:04:DC:66:CB nodemac=E2:0D:28:C1:76:A6   
10.23.0.190:0      id=1101  sec_id=4     flags=0x0000 ifindex=10  mac=02:D3:B9:42:89:23 nodemac=02:85:99:5D:BF:9E     
10.23.0.24:0       id=3882  sec_id=1590479 flags=0x0000 ifindex=18  mac=8E:4F:B0:02:26:76 nodemac=DE:3F:EB:24:33:7F   
10.23.0.186:0      id=2054  sec_id=1579534 flags=0x0000 ifindex=22  mac=4A:BD:2F:42:87:C2 nodemac=7A:09:1D:9D:51:1B   
10.23.0.240:0      id=3012  sec_id=1590586 flags=0x0000 ifindex=14  mac=AA:C5:E5:E1:7C:2A nodemac=AE:22:7E:DF:D8:9B   
