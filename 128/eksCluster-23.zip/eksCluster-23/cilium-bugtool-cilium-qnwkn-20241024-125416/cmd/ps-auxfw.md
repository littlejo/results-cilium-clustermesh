USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3177  0.0  0.0 1228744 3656 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3176  0.0  0.4 1240176 16224 ?       Dsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3201  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3146  0.0  0.0 1228744 3656 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3145  0.0  0.0 1228744 3776 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3134  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3133  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  3.9  7.3 1539060 287848 ?      Ssl  12:26   1:06 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.2  0.2 1229744 10108 ?       Sl   12:26   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
