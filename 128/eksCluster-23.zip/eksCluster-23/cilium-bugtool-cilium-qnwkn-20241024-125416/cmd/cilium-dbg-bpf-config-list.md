KEY             VALUE
AgentLiveness   2026634643341
UTimeOffset     3378461839843750
