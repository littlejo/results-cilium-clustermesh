CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0d146b52_7172_4fde_814c_e2cece27ed90.slice/cri-containerd-d30882ac5a9fe438066342ad6420def43ee2585ab68e9782e5a9f11bdbc3eb1d.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0d146b52_7172_4fde_814c_e2cece27ed90.slice/cri-containerd-2765de12a1674ec3309ab3adedf0ca688ccb0d0b50965e52fee63d5d4a5a0bbb.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbee77e42_114f_4886_b9b0_6852a6605157.slice/cri-containerd-a06b32910a750b150fd20bea1affae8ffb4c4bfe5c65092ba4d6672211b68ef5.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbee77e42_114f_4886_b9b0_6852a6605157.slice/cri-containerd-ab8fb7cf7efe5b4a81f90a053d077003c8096c5573983fb03ce60b7ebd2c9a42.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c572ef4_251d_486c_9cd9_492390bc3ce1.slice/cri-containerd-314251c161b7c85c84a4a5a3f7c686fd4307b71e1546684e440c319c4f255699.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c572ef4_251d_486c_9cd9_492390bc3ce1.slice/cri-containerd-9a21027f860a0ec94e31594a6971ea1a798819da8a53545dad73ff8b5e92410d.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf19f42af_04c6_4d26_b4c9_98dffa35f13f.slice/cri-containerd-b9f375f50080bce1059190e4642d803d8f4c50822b4028661d4334961d4cf6de.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf19f42af_04c6_4d26_b4c9_98dffa35f13f.slice/cri-containerd-20140a5aa74a50e584a27006c6be75bcbabd15cd1bde00659dce694ba601d73a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87dbf8da_b8f5_481f_8016_9df8688d1cec.slice/cri-containerd-49d53b31429a21cec8a97200e6f5d7ad269bed98608baae79e3c5e2b1a3b3f49.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87dbf8da_b8f5_481f_8016_9df8688d1cec.slice/cri-containerd-426e2445aa65dbcd67568e8f60583ddbb7543766e9f8a5dd11131012a06e1506.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29bc04e2_9649_46ae_b215_c02fc413506e.slice/cri-containerd-ec67959926c41efc1ecb7adf54e93065953688a0779a1c5e543edb03237c5f76.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29bc04e2_9649_46ae_b215_c02fc413506e.slice/cri-containerd-c6942958945bc186c2f76556edb6d678edc5961a923468376b13511272cef68e.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd106c7b3_c81a_4555_814a_219cb2e72fbf.slice/cri-containerd-659a27118314e924c2eddfde0db0ad9e68cdee5369b29a3c9322066bac1003d6.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd106c7b3_c81a_4555_814a_219cb2e72fbf.slice/cri-containerd-9625e3dc966579d563557ee8b40e8316148b6546ddfa9e20ecc0a0fb1f69a499.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd106c7b3_c81a_4555_814a_219cb2e72fbf.slice/cri-containerd-088ea42d3ed7770d19655c3dc8029aadefca6f482e35249be35dd2529c79f874.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6cb4476a_1094_4c40_9dc5_265010e93dc4.slice/cri-containerd-cf86e4acbb0d852d81d4a8b22158d358e7d5529939d746561b193cd22ab2df86.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6cb4476a_1094_4c40_9dc5_265010e93dc4.slice/cri-containerd-15f1d4e8ecdf868f826b84a13831bd5f8647dce83fcd60156ee37a8bc9be9993.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb7ddc4_faef_4ce8_8550_56810ac04687.slice/cri-containerd-d9f2c9940ba697d5b388b33878a95b14adff129f728697c5a69c1d49e46df1a4.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb7ddc4_faef_4ce8_8550_56810ac04687.slice/cri-containerd-61bbf3d05b8cbe890a724420fe61f42395c1ab4d9b79889bae016f1ecb348542.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb7ddc4_faef_4ce8_8550_56810ac04687.slice/cri-containerd-6f1ea8d505d7f5284d7e999b355b4fff117ca0095afdae89c7ba151b5a220f7d.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb7ddc4_faef_4ce8_8550_56810ac04687.slice/cri-containerd-e5f244ecd1943f55f6be08bc7a0bf1fea65757ae799f6ea16d4e2966285d591f.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod812342a4_c463_4a43_93c8_fa3fc79a1d3b.slice/cri-containerd-3df292598eba6655770c8e4e17c5adf21d8ef3389661d013f40ef82deddc9808.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod812342a4_c463_4a43_93c8_fa3fc79a1d3b.slice/cri-containerd-50efc96aa4e14495aa4e7ba13e7304155e583030fbfcc326d56e410ae241790c.scope
    712      cgroup_device   multi                                          
