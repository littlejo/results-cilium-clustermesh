USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3202  1.0  0.4 1240176 16048 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3228  0.0  0.0   6408  1640 ?        R    12:54   0:00  \_ ps auxfw
root        3229  0.0  0.0      0     0 ?        Z    12:54   0:00  \_ [hostname] <defunct>
root           1  4.6  7.2 1539060 285808 ?      Ssl  12:30   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.2  0.2 1229744 10404 ?       Sl   12:30   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
