KEY             VALUE
AgentLiveness   1909044053095
UTimeOffset     3378462027343750
