CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f3be70c_64af_44e1_8855_d6da2b290989.slice/cri-containerd-f78589ae3b8c82e0aa97973520601b15639609f414eedc886c760e42866f0360.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f3be70c_64af_44e1_8855_d6da2b290989.slice/cri-containerd-ce98140e0f5cde5fca085c0123660f3769f99739c30e5d6fb5a30f153bb8b6ec.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podce529932_5391_4797_9173_274318e190ee.slice/cri-containerd-f3b8915d1b2f8569a87bb2e2a296aefaabe929e0d095aaaa29e6d0cec5748f80.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podce529932_5391_4797_9173_274318e190ee.slice/cri-containerd-40169228f43774fda26d12082c492ecb86de36b59e3aecf5d18938825413bf87.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27dcb2a6_2346_457e_9b9c_85374a09c880.slice/cri-containerd-859018630a726a85aa685e77d2c722187abb03d198e303cf404917d0f9de6543.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27dcb2a6_2346_457e_9b9c_85374a09c880.slice/cri-containerd-69cd991de4d615f20deab47e1ac7dec007f26ec7c5b5e979df1692e5835cfa2c.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8c8553d_e2a6_4b95_ace4_103f5e865170.slice/cri-containerd-33a17caa82c511ad2a3935922f0608a512125c9b18737d7089609892ed791d38.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8c8553d_e2a6_4b95_ace4_103f5e865170.slice/cri-containerd-67a38e96fda49a5d896a6591a10cd85096ae25bae73d224e64bb2fd64b34e191.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb0e3087b_3a89_40ad_9828_af57d31b1b87.slice/cri-containerd-75a98a15e29f16b44252249b005f2e677d334909d7094e47684b7649f1c459b2.scope
    700      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb0e3087b_3a89_40ad_9828_af57d31b1b87.slice/cri-containerd-ab2b1f9f99adb778e807f007ace6220fe25b9b927df561fb16c3fff19d868187.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd51b781_4c62_48b6_84b0_a3f5722c9221.slice/cri-containerd-5aa6817e6837587dc14b237d077e0c90f764042cea0bec629530a402ba39b6ab.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd51b781_4c62_48b6_84b0_a3f5722c9221.slice/cri-containerd-b9a9154cd4a7add26cc7444dd5c60a1192f9827989e47d4f22d19852bd605905.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd51b781_4c62_48b6_84b0_a3f5722c9221.slice/cri-containerd-dd13a18256e06e66db80a945e5b332d60fad139a3fa63ec1be91ab0cc347ac86.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd51b781_4c62_48b6_84b0_a3f5722c9221.slice/cri-containerd-9c523ba1b58c6ee29fa9021ab023f06496c00c908ac1b50314fb8088383601de.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddfcbaa94_16d7_4f72_b6e0_7395f0007e7d.slice/cri-containerd-30f81c18e7dccb9ccb5d327049ab472260e71fdee43dfc2563f9824f9e101688.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddfcbaa94_16d7_4f72_b6e0_7395f0007e7d.slice/cri-containerd-e8a4708453c79fb0ccf775c821bd3d557c616c5d006c9c49c6e3917b06d4fbbd.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dd6534d_fd7c_43b3_b756_bc6de98117e4.slice/cri-containerd-426a724545f032d46aac12ea6e789eb660f7b724fefe5e79613e3aa892c09bf7.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dd6534d_fd7c_43b3_b756_bc6de98117e4.slice/cri-containerd-d73a83750dd891945407c87cdf3b51be96093f31add33dcf9c8d5738e708c4c1.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7d44ad5_c4d1_4dc6_89f4_b18696fd05fe.slice/cri-containerd-81e71696ffadaf2fad5911bca31ec866aada4361e6852f1fea2cb257297b4687.scope
    662      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7d44ad5_c4d1_4dc6_89f4_b18696fd05fe.slice/cri-containerd-5eb2e6a27672e692bd7934382051d3e0b1f89dea717a11d80e4d26bda2ec7498.scope
    696      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod350ae185_35ba_4e50_b7d7_8fd22a9cf7b8.slice/cri-containerd-7bc659efde9763fd281babaf4a3cf56917cc81690f4b8616db45b025c037302c.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod350ae185_35ba_4e50_b7d7_8fd22a9cf7b8.slice/cri-containerd-70e76c6da54246863ddd27d39fc1c23ea13388c99aa2a8d7b10eb75399cc984c.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod350ae185_35ba_4e50_b7d7_8fd22a9cf7b8.slice/cri-containerd-fb836150c0f30e45872a22ac42c716b8ae70401f32c20ba8cc7b591f4024f471.scope
    708      cgroup_device   multi                                          
