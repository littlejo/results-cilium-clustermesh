key: 92 04 00 00  value: 07 02 00 00
key: cf 04 00 00  value: 06 0d 00 00
key: 44 06 00 00  value: 23 02 00 00
key: d3 06 00 00  value: cc 0c 00 00
key: 3c 07 00 00  value: 6b 02 00 00
key: 39 0a 00 00  value: 04 0d 00 00
key: a4 0c 00 00  value: 21 02 00 00
Found 7 elements
