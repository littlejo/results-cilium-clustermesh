alloc: 87.24MB (91476304 bytes)
total-alloc: 3.04GB (3269156504 bytes)
sys: 215.32MB (225781076 bytes)
lookups: 0
mallocs: 74670861
frees: 73828040
heap-alloc: 87.24MB (91476304 bytes)
heap-sys: 168.69MB (176881664 bytes)
heap-idle: 44.27MB (46424064 bytes)
heap-in-use: 124.41MB (130457600 bytes)
heap-released: 8.20MB (8593408 bytes)
heap-objects: 842821
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.12MB (2226400 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 968.30KB (991537 bytes)
gc-sys: 5.48MB (5741664 bytes)
next-gc: when heap-alloc >= 145.78MB (152857384 bytes)
last-gc: 2024-10-24 12:53:59.904491866 +0000 UTC
gc-pause-total: 15.600805ms
gc-pause: 115347
gc-pause-end: 1729774439904491866
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006063089000411779
enable-gc: true
debug-gc: false
