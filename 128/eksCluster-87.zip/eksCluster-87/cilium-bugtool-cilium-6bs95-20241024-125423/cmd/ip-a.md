1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:05:a6:f7:46:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.210.124/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3506sec preferred_lft 3506sec
    inet6 fe80::805:a6ff:fef7:46d3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e8:e4:5a:d5:af brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.206.154/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8e8:e4ff:fe5a:d5af/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:47:63:da:e6:ad brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c047:63ff:feda:e6ad/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:d3:fd:28:5d:5a brd ff:ff:ff:ff:ff:ff
    inet 10.87.0.111/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4cd3:fdff:fe28:5d5a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a2:3b:1b:a0:9a:03 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a03b:1bff:fea0:9a03/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:68:c4:1d:2c:1c brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7c68:c4ff:fe1d:2c1c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9a435765229d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:6c:0d:b9:13:46 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::406c:dff:feb9:1346/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce3962679cb22@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:38:2b:8a:86:9b brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c38:2bff:fe8a:869b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc660d70bc78bd@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:d0:1d:b9:1e:ca brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::64d0:1dff:feb9:1eca/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc26f797829f98@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:38:f9:81:6d:e6 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::cc38:f9ff:fe81:6de6/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc232a7cfe239a@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:e2:04:71:84:29 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::1ce2:4ff:fe71:8429/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcd162e0a9b9f8@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:04:c2:de:8f:35 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::9004:c2ff:fede:8f35/64 scope link 
       valid_lft forever preferred_lft forever
