Endpoint ID: 645
Path: /sys/fs/bpf/tc/globals/cilium_policy_00645

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1170
Path: /sys/fs/bpf/tc/globals/cilium_policy_01170

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2640     30        0        
Allow    Ingress     1          ANY          NONE         disabled    132798   1519      0        
Allow    Egress      0          ANY          NONE         disabled    19303    212       0        


Endpoint ID: 1231
Path: /sys/fs/bpf/tc/globals/cilium_policy_01231

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1604
Path: /sys/fs/bpf/tc/globals/cilium_policy_01604

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6186716   76427     0        
Allow    Ingress     1          ANY          NONE         disabled    61990     748       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1747
Path: /sys/fs/bpf/tc/globals/cilium_policy_01747

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    351056   4096      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1852
Path: /sys/fs/bpf/tc/globals/cilium_policy_01852

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5428081   56755     0        
Allow    Ingress     1          ANY          NONE         disabled    5397585   57081     0        
Allow    Egress      0          ANY          NONE         disabled    6990475   70106     0        


Endpoint ID: 2617
Path: /sys/fs/bpf/tc/globals/cilium_policy_02617

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3236
Path: /sys/fs/bpf/tc/globals/cilium_policy_03236

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3256     30        0        
Allow    Ingress     1          ANY          NONE         disabled    133854   1535      0        
Allow    Egress      0          ANY          NONE         disabled    19404    214       0        


