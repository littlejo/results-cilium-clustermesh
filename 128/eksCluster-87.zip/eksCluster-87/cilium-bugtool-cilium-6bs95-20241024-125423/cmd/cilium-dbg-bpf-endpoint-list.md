IP ADDRESS         LOCAL ENDPOINT INFO
10.87.0.158:0      id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29   
172.31.206.154:0   (localhost)                                                                                        
10.87.0.111:0      (localhost)                                                                                        
10.87.0.250:0      id=3236  sec_id=5819803 flags=0x0000 ifindex=14  mac=8A:B6:07:13:FB:15 nodemac=0E:38:2B:8A:86:9B   
10.87.0.178:0      id=1852  sec_id=5768327 flags=0x0000 ifindex=18  mac=3E:AC:C5:21:2F:41 nodemac=66:D0:1D:B9:1E:CA   
172.31.210.124:0   (localhost)                                                                                        
10.87.0.153:0      id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35   
10.87.0.192:0      id=1170  sec_id=5819803 flags=0x0000 ifindex=12  mac=4A:58:AE:3E:DE:60 nodemac=42:6C:0D:B9:13:46   
10.87.0.112:0      id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6   
10.87.0.197:0      id=1604  sec_id=4     flags=0x0000 ifindex=10  mac=BE:6A:2C:FE:AD:28 nodemac=7E:68:C4:1D:2C:1C     
