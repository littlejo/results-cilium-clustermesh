markdown output at /tmp/cilium-bugtool-20241024-125425.464+0000-UTC-3245308452/cmd/cilium-debuginfo-20241024-125426.336+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125425.464+0000-UTC-3245308452/cmd/cilium-debuginfo-20241024-125426.336+0000-UTC.json
