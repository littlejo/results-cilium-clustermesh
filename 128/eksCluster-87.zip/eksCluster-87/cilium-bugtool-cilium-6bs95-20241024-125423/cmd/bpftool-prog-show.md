29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:42+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name tail_handle_ipv4  tag 8be6d210de5ea39f  gpl
	loaded_at 2024-10-24T12:30:55+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
479: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:30:55+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
480: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:30:55+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:30:55+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
482: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 129
483: sched_cls  name tail_handle_ipv4_from_host  tag 97197880f6f89dcc  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 130
484: sched_cls  name __send_drop_notify  tag eed2184c243ab676  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 131
487: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,101
	btf_id 134
488: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 135
490: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 138
491: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 139
492: sched_cls  name tail_handle_ipv4_from_host  tag 97197880f6f89dcc  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 140
493: sched_cls  name __send_drop_notify  tag eed2184c243ab676  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 141
496: sched_cls  name __send_drop_notify  tag eed2184c243ab676  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 145
498: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 147
500: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 149
502: sched_cls  name tail_handle_ipv4_from_host  tag 97197880f6f89dcc  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 151
504: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 154
506: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 156
508: sched_cls  name tail_handle_ipv4_from_host  tag 97197880f6f89dcc  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 158
509: sched_cls  name __send_drop_notify  tag eed2184c243ab676  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
511: sched_cls  name tail_handle_ipv4_cont  tag b782c1181d10daa4  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 163
512: sched_cls  name cil_from_container  tag 10cd26cc786163e1  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 165
513: sched_cls  name tail_handle_arp  tag 74087a72e7f89089  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 166
514: sched_cls  name tail_ipv4_ct_egress  tag 6962ede1bbf77b43  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 167
517: sched_cls  name tail_ipv4_ct_ingress  tag 9421c2d42514e177  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 168
519: sched_cls  name handle_policy  tag 085e0aee1d7f4223  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 171
525: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 175
526: sched_cls  name __send_drop_notify  tag eedcaf3ae51a6489  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
530: sched_cls  name tail_ipv4_to_endpoint  tag 01fac7797420133c  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 181
531: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 185
532: sched_cls  name tail_handle_ipv4_cont  tag c9a64aaa123dd310  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 186
533: sched_cls  name tail_handle_ipv4  tag fd258f83383e72d7  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 183
534: sched_cls  name cil_from_container  tag 0213ad22a243c631  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 187
535: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 190
536: sched_cls  name tail_ipv4_ct_ingress  tag 0b84bf45c8865bfe  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 191
537: sched_cls  name __send_drop_notify  tag 23d76e404242c7cf  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
538: sched_cls  name tail_handle_ipv4  tag 75bbd1491a2fb90d  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 193
539: sched_cls  name tail_handle_arp  tag 5b86d50afad42fae  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 194
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 195
541: sched_cls  name tail_ipv4_to_endpoint  tag 12129aea3cf861cc  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 188
542: sched_cls  name tail_handle_ipv4_cont  tag 15abb17403e1de10  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 196
543: sched_cls  name cil_from_container  tag 4f405a0d1ec6d4b2  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 198
545: sched_cls  name handle_policy  tag 4efe18e5e4d22e93  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 197
546: sched_cls  name __send_drop_notify  tag 37ee91157d60e8a9  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
547: sched_cls  name handle_policy  tag 49c03b609b543af2  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 200
548: sched_cls  name tail_handle_ipv4  tag 8f5d46ce1469f357  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 202
550: sched_cls  name tail_ipv4_to_endpoint  tag 5745a15fdb9d0259  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 203
551: sched_cls  name tail_ipv4_ct_egress  tag 6962ede1bbf77b43  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 205
552: sched_cls  name tail_handle_arp  tag b879cf6880ed0b4d  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 206
553: sched_cls  name tail_ipv4_ct_ingress  tag 9df984b971455266  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 207
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
561: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
562: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
565: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: sched_cls  name tail_handle_ipv4_cont  tag 99136785ac3c73b1  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 221
611: sched_cls  name tail_ipv4_ct_egress  tag 0e55b7a32ef9db10  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 223
612: sched_cls  name cil_from_container  tag 49cabf5c3a774ea3  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 224
613: sched_cls  name tail_ipv4_ct_ingress  tag 74168db586a474f7  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 225
614: sched_cls  name tail_handle_ipv4  tag 9efa1ecd3f0a8c8b  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 226
615: sched_cls  name tail_ipv4_to_endpoint  tag 99e943b054e4aaba  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 227
616: sched_cls  name tail_handle_arp  tag 5e23397e7d79ba4d  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 228
617: sched_cls  name __send_drop_notify  tag 98b6e81e0068bb4d  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 229
618: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 230
619: sched_cls  name handle_policy  tag 8d75836ef74c90fc  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 231
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
659: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
662: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
685: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
688: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
689: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
692: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
693: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
696: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
697: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
700: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
701: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
704: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
705: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
708: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3262: sched_cls  name tail_ipv4_ct_egress  tag b93be6fb9f727216  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,623,82,83,624,84
	btf_id 3054
3264: sched_cls  name tail_ipv4_to_endpoint  tag 7dc16608f1c5787b  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,624,41,82,83,80,147,39,623,40,37,38
	btf_id 3055
3266: sched_cls  name tail_ipv4_ct_ingress  tag a56a9597377ae4c6  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,623,82,83,624,84
	btf_id 3059
3268: sched_cls  name tail_handle_ipv4_cont  tag c08e6fee8b3a4d01  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,624,41,147,82,83,39,76,74,77,623,40,37,38,81
	btf_id 3061
3269: sched_cls  name tail_handle_arp  tag 91cbf4865511bfb2  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,623
	btf_id 3062
3270: sched_cls  name tail_handle_ipv4  tag 3229f561023a5666  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,623
	btf_id 3064
3271: sched_cls  name cil_from_container  tag 133aa8a34da88b76  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 623,76
	btf_id 3065
3272: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,623
	btf_id 3066
3273: sched_cls  name __send_drop_notify  tag ae4e1df099989375  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3067
3276: sched_cls  name handle_policy  tag 409846a22499c61e  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,623,82,83,624,41,80,147,39,84,75,40,37,38
	btf_id 3068
3317: sched_cls  name __send_drop_notify  tag 9502d86b4120aa04  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3116
3318: sched_cls  name tail_handle_arp  tag 76fcd75f8b21fb8f  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3117
3319: sched_cls  name cil_from_container  tag 60a5282a1d67be98  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3118
3320: sched_cls  name tail_ipv4_to_endpoint  tag 0a117f34aa571be8  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,143,39,633,40,37,38
	btf_id 3113
3321: sched_cls  name tail_handle_arp  tag 8a65469ca4719eec  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3120
3322: sched_cls  name __send_drop_notify  tag 77e0049a869815da  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3121
3323: sched_cls  name cil_from_container  tag 2087b62d230a1444  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3122
3324: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3123
3325: sched_cls  name tail_ipv4_ct_egress  tag e606b00854a8db2d  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3119
3326: sched_cls  name tail_ipv4_ct_ingress  tag 27d840335cdaf206  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3125
3327: sched_cls  name tail_handle_ipv4  tag 95bba1c6a63a0b07  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3124
3328: sched_cls  name tail_handle_ipv4_cont  tag 904c9aff6808058a  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,143,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3127
3330: sched_cls  name tail_ipv4_ct_egress  tag 03d4796f08657574  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3129
3331: sched_cls  name tail_ipv4_ct_ingress  tag 0b0dc976d38fe8ed  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3130
3332: sched_cls  name handle_policy  tag 3e91eab42c851724  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,150,39,84,75,40,37,38
	btf_id 3126
3333: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3132
3334: sched_cls  name handle_policy  tag acf7d9351166919b  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,143,39,84,75,40,37,38
	btf_id 3131
3335: sched_cls  name tail_ipv4_to_endpoint  tag 3e8deea73bec446d  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,150,39,636,40,37,38
	btf_id 3133
3336: sched_cls  name tail_handle_ipv4_cont  tag 218bc5ee70af947d  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,150,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3134
3337: sched_cls  name tail_handle_ipv4  tag c8609a4d5bd44858  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3135
