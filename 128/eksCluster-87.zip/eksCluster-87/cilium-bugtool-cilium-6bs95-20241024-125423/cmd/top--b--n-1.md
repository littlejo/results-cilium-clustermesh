top - 12:54:25 up 31 min,  0 users,  load average: 0.44, 0.44, 0.29
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 48.4 us, 32.3 sy,  0.0 ni,  9.7 id,  0.0 wa,  0.0 hi,  9.7 si,  0.0 st
MiB Mem :   3836.2 total,    290.3 free,   1049.1 used,   2496.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2606.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 286856  78520 S  12.5   7.3   1:05.71 cilium-+
   3202 root      20   0 1240432  16048  11228 S   6.2   0.4   0:00.03 cilium-+
    395 root      20   0 1229744  10404   3836 S   0.0   0.3   0:03.93 cilium-+
   3239 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3269 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3279 root      20   0 1539912   8276   6204 S   0.0   0.2   0:00.00 runc:[2+
