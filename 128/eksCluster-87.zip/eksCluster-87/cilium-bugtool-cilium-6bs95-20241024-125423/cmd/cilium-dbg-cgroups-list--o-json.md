[
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd51b781_4c62_48b6_84b0_a3f5722c9221.slice/cri-containerd-5aa6817e6837587dc14b237d077e0c90f764042cea0bec629530a402ba39b6ab.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd51b781_4c62_48b6_84b0_a3f5722c9221.slice/cri-containerd-b9a9154cd4a7add26cc7444dd5c60a1192f9827989e47d4f22d19852bd605905.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd51b781_4c62_48b6_84b0_a3f5722c9221.slice/cri-containerd-9c523ba1b58c6ee29fa9021ab023f06496c00c908ac1b50314fb8088383601de.scope"
      }
    ],
    "ips": [
      "10.87.0.178"
    ],
    "name": "clustermesh-apiserver-5b65d75d8c-ts7g6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f3be70c_64af_44e1_8855_d6da2b290989.slice/cri-containerd-f78589ae3b8c82e0aa97973520601b15639609f414eedc886c760e42866f0360.scope"
      }
    ],
    "ips": [
      "10.87.0.250"
    ],
    "name": "coredns-cc6ccd49c-h99vz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb0e3087b_3a89_40ad_9828_af57d31b1b87.slice/cri-containerd-75a98a15e29f16b44252249b005f2e677d334909d7094e47684b7649f1c459b2.scope"
      }
    ],
    "ips": [
      "10.87.0.153"
    ],
    "name": "client2-57cf4468f-hqr6j",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7d44ad5_c4d1_4dc6_89f4_b18696fd05fe.slice/cri-containerd-5eb2e6a27672e692bd7934382051d3e0b1f89dea717a11d80e4d26bda2ec7498.scope"
      }
    ],
    "ips": [
      "10.87.0.112"
    ],
    "name": "client-974f6c69d-cd6c5",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8c8553d_e2a6_4b95_ace4_103f5e865170.slice/cri-containerd-67a38e96fda49a5d896a6591a10cd85096ae25bae73d224e64bb2fd64b34e191.scope"
      }
    ],
    "ips": [
      "10.87.0.192"
    ],
    "name": "coredns-cc6ccd49c-wls6k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod350ae185_35ba_4e50_b7d7_8fd22a9cf7b8.slice/cri-containerd-fb836150c0f30e45872a22ac42c716b8ae70401f32c20ba8cc7b591f4024f471.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod350ae185_35ba_4e50_b7d7_8fd22a9cf7b8.slice/cri-containerd-70e76c6da54246863ddd27d39fc1c23ea13388c99aa2a8d7b10eb75399cc984c.scope"
      }
    ],
    "ips": [
      "10.87.0.158"
    ],
    "name": "echo-same-node-86d9cc975c-c99xh",
    "namespace": "cilium-test-1"
  }
]

