Node 0, zone      DMA     67     21     18      6      1      5      5      3      3      4     45 
Node 0, zone   Normal      4      2      1      2     34     10     14      4      3      1      7 
