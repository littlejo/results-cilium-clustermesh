{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.061Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.519Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.521Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.560Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.574Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.612Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.849Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.853Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.898Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.922Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.962Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.574Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.575Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.623Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.630Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.684Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.701Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.727Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.939Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.947Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.993Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.037Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.085Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.645Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.647Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.695Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.696Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.739Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.743Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.780Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.999Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.003Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.057Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.063Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.105Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.697Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.697Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.760Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.775Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.804Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.018Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.058Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.141Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.185Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.201Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.567Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.573Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.610Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.647Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.657Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.900Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.938Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.973Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.986Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.013Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.390Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.438Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.442Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.486Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.503Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.523Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.755Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.759Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.813Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.815Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.856Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.214Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.245Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.269Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.295Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.325Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.650Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.655Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.750Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.768Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.823Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.227Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.234Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.238Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.273Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.279Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.311Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.566Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.600Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.620Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.694Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.701Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.042Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.079Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.082Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.128Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.136Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.163Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.373Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.417Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.422Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.469Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.492Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.771Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.821Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.826Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.868Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.882Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.904Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.131Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.160Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.195Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.214Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.294Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.620Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.627Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.670Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.688Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.708Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.946Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.969Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.975Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.983Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.990Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.659Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.662Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.692Z",
  "value": "id=1747  sec_id=5780655 flags=0x0000 ifindex=22  mac=1A:07:0C:2D:C1:22 nodemac=1E:E2:04:71:84:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.720Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.734Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.995Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.000Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.648Z",
  "value": "id=1231  sec_id=5776579 flags=0x0000 ifindex=20  mac=2E:0C:58:F4:DE:9B nodemac=CE:38:F9:81:6D:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.672Z",
  "value": "id=2617  sec_id=5770648 flags=0x0000 ifindex=24  mac=92:A5:6D:1C:72:84 nodemac=92:04:C2:DE:8F:35"
}

