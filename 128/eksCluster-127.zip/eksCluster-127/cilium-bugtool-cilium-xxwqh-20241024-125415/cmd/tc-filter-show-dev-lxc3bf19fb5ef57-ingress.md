filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3bf19fb5ef57 direct-action not_in_hw id 530 tag 94e4cd46b6b34a36 jited 
