KEY             VALUE
AgentLiveness   1858521405404
UTimeOffset     3378462166015625
