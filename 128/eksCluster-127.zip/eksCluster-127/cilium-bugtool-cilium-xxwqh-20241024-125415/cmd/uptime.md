 12:54:16 up 30 min,  0 users,  load average: 0.46, 0.41, 0.21
