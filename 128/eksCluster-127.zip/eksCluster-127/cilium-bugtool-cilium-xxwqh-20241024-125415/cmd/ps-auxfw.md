USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3202  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3172  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3160  0.0  0.4 1240432 16340 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3217  0.0  0.0   6408  1636 ?        R    12:54   0:00  \_ ps auxfw
root        3219  0.0  0.0   1892   388 ?        R    12:54   0:00  \_ ip a
root           1  6.2  7.3 1538804 287648 ?      Ssl  12:36   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         418  0.4  0.2 1229744 9980 ?        Sl   12:37   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
