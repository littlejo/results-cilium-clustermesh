{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.049Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.075Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.105Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.664Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.677Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.765Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.798Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.843Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.039Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.043Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.098Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.112Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.149Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.745Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.768Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.812Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.823Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.853Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.072Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.089Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.152Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.164Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.205Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.791Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.795Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.839Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.847Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.897Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.899Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.933Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.208Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.256Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.271Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.349Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.362Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.881Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.882Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.930Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.943Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.978Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.990Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.022Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.278Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.307Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.360Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.379Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.400Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.825Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.859Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.892Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.911Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.935Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.192Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.208Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.236Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.296Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.304Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.762Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.777Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.810Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.857Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.863Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.106Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.107Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.203Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.206Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.254Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.588Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.627Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.630Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.675Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.685Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.711Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.947Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.951Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.038Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.093Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.117Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.563Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.573Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.617Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.626Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.656Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.889Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.903Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.949Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.959Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.013Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.440Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.449Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.502Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.527Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.549Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.785Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.815Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.832Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.924Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.936Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.302Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.302Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.318Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.412Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.413Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.448Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.704Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.706Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.766Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.769Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.809Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.178Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.184Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.226Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.227Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.271Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.274Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.530Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.532Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.557Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.581Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.287Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.290Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.321Z",
  "value": "id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.344Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.364Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.631Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.634Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:38.338Z",
  "value": "id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:38.340Z",
  "value": "id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4"
}

