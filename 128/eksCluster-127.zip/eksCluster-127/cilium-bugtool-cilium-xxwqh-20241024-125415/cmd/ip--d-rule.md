9:	from all fwmark 0x200/0xf00 lookup 2004 proto kernel
100:	from all lookup local proto kernel
512:	from all to 172.31.198.47 lookup main proto unspec
512:	from all to 172.31.237.236 lookup main proto unspec
1024:	from all fwmark 0x80/0x80 lookup main proto unspec
32766:	from all lookup main proto kernel
32767:	from all lookup default proto kernel
