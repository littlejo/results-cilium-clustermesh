[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fd33b97_ec80_4995_adee_364c3cf355a7.slice/cri-containerd-a105f095b7eeaf5c76d5234d96a92e02431b5cb338d05517cd75d66ec56b7a94.scope"
      }
    ],
    "ips": [
      "10.127.0.19"
    ],
    "name": "coredns-cc6ccd49c-mg47r",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98ae2fa5_e96d_4856_a9a0_8644630ddef6.slice/cri-containerd-53825ed7a10acb0b778f5f1b9350d4a88ac7cfa57cc3f13bc6236ba065ae3f1d.scope"
      }
    ],
    "ips": [
      "10.127.0.9"
    ],
    "name": "client2-57cf4468f-cmb25",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8639e3da_075d_47df_939b_66dc2d9283fe.slice/cri-containerd-4b0e84838c2b36137c78e58df8f9afdafd5465c174e8ef9d87258932e1af5071.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8639e3da_075d_47df_939b_66dc2d9283fe.slice/cri-containerd-a6ddeb2d7b09fc880a6d19d1ded644a18711faa38aa032f70288a911d9e3dcf7.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8639e3da_075d_47df_939b_66dc2d9283fe.slice/cri-containerd-5518bd8b15583aafe72e66554aa2c970343cf00c40463ac133fd7907fd66255c.scope"
      }
    ],
    "ips": [
      "10.127.0.224"
    ],
    "name": "clustermesh-apiserver-6f55fd9bfb-4p9td",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67ad9bb8_d843_4e48_807d_3ffd3e690be2.slice/cri-containerd-134fdb6370441777cc57d1eb3bb2b2913d0583f55a0989d6f0876e7b3f44e2ac.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67ad9bb8_d843_4e48_807d_3ffd3e690be2.slice/cri-containerd-60f7f6aec298fafd0927f6dc5ee1eace6faf61e25e392904fe2c222355707760.scope"
      }
    ],
    "ips": [
      "10.127.0.152"
    ],
    "name": "echo-same-node-86d9cc975c-hwhbr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04495685_cab3_492b_b3be_e24f94afcf39.slice/cri-containerd-a4e554ba48c197e7ea813bdc3dbf6e6e1f92b9994226faf6fe2cc8b1b6ac09a1.scope"
      }
    ],
    "ips": [
      "10.127.0.76"
    ],
    "name": "client-974f6c69d-nvd29",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9fdbeb3_7403_4f81_8d35_a442f71b1fe7.slice/cri-containerd-02fdbbd686b3f22c26c38b3c739ca8b1ba2cd3d1854ef7353536eed87209bb9b.scope"
      }
    ],
    "ips": [
      "10.127.0.3"
    ],
    "name": "coredns-cc6ccd49c-4tpfx",
    "namespace": "kube-system"
  }
]

