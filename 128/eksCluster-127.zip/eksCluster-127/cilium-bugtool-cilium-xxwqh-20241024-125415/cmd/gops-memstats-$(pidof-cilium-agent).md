alloc: 128.17MB (134398912 bytes)
total-alloc: 3.01GB (3229691832 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 74016238
frees: 72750107
heap-alloc: 128.17MB (134398912 bytes)
heap-sys: 176.64MB (185221120 bytes)
heap-idle: 27.30MB (28631040 bytes)
heap-in-use: 149.34MB (156590080 bytes)
heap-released: 8.85MB (9281536 bytes)
heap-objects: 1266131
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.31MB (2420800 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 752.87KB (770937 bytes)
gc-sys: 5.53MB (5803128 bytes)
next-gc: when heap-alloc >= 149.20MB (156443608 bytes)
last-gc: 2024-10-24 12:54:16.104209757 +0000 UTC
gc-pause-total: 9.138497ms
gc-pause: 81681
gc-pause-end: 1729774456104209757
num-gc: 95
num-forced-gc: 0
gc-cpu-fraction: 0.0007914812909000471
enable-gc: true
debug-gc: false
