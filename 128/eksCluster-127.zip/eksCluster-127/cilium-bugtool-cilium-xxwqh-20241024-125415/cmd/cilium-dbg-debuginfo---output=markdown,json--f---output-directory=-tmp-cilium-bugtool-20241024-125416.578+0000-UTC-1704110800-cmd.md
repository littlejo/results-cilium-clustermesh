markdown output at /tmp/cilium-bugtool-20241024-125416.578+0000-UTC-1704110800/cmd/cilium-debuginfo-20241024-125447.463+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.578+0000-UTC-1704110800/cmd/cilium-debuginfo-20241024-125447.463+0000-UTC.json
