1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6c:a6:16:ea:8b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.221.249/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3586sec preferred_lft 3586sec
    inet6 fe80::86c:a6ff:fe16:ea8b/64 scope link 
       valid_lft forever preferred_lft forever
4: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b7:df:e5:61:13 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.192.111/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8b7:dfff:fee5:6113/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:38:bc:94:72:61 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9c38:bcff:fe94:7261/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:93:ec:8f:cc:80 brd ff:ff:ff:ff:ff:ff
    inet 10.127.0.127/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e493:ecff:fe8f:cc80/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 52:ee:36:ea:3e:c1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::50ee:36ff:feea:3ec1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:6a:72:e7:cc:c5 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ac6a:72ff:fee7:ccc5/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3bf19fb5ef57@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:f7:de:8d:5b:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d8f7:deff:fe8d:5bd6/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca37082ee842f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:19:e1:e0:76:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::7819:e1ff:fee0:76a4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcec09bc29f015@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:37:00:4f:5e:0a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1037:ff:fe4f:5e0a/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc93aa9418b900@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:53:67:3a:20:da brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1053:67ff:fe3a:20da/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc8c1c955bcc0a@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:e0:d2:9c:5b:d2 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::c0e0:d2ff:fe9c:5bd2/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc99f865188ecd@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:0e:5d:c1:0c:f4 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::bc0e:5dff:fec1:cf4/64 scope link 
       valid_lft forever preferred_lft forever
