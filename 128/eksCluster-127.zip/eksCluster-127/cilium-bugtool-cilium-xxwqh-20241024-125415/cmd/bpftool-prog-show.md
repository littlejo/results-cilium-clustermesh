29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:54+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:54+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:55+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:55+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:55+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:55+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:24:00+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:24:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:36:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:36:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:36:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:36:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:36:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:36:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:36:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:36:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
104: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:36:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
107: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:36:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:36:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:36:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:37:08+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
479: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:37:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
480: sched_cls  name tail_handle_ipv4  tag 9db4ce101855dc58  gpl
	loaded_at 2024-10-24T12:37:08+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:37:08+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
513: sched_cls  name tail_ipv4_to_endpoint  tag 2338dc3a01792faf  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,109,39,113,40,37,38
	btf_id 163
514: sched_cls  name tail_handle_ipv4_cont  tag 3b3d57d3c5bed94c  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,111,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 167
516: sched_cls  name tail_ipv4_ct_ingress  tag fd53e7303c244ca9  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,111,84
	btf_id 168
517: sched_cls  name tail_handle_arp  tag fdd4a627551db703  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 170
523: sched_cls  name handle_policy  tag faaff966cb7d4662  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,111,41,80,109,39,84,75,40,37,38
	btf_id 171
525: sched_cls  name tail_ipv4_ct_egress  tag 9e71d3ecc24f23de  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,111,84
	btf_id 177
526: sched_cls  name __send_drop_notify  tag f3eaf3bb1934f63e  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
529: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 181
530: sched_cls  name cil_from_container  tag 94e4cd46b6b34a36  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 182
531: sched_cls  name cil_from_container  tag 117bbdd430316842  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 185
532: sched_cls  name tail_handle_arp  tag 1576be4d527477ea  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 186
534: sched_cls  name tail_ipv4_ct_egress  tag 9e71d3ecc24f23de  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 188
535: sched_cls  name tail_handle_ipv4  tag c7aab1d7ebc2efbc  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 183
536: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 191
537: sched_cls  name tail_ipv4_to_endpoint  tag bcfac5ce28e06f99  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 189
539: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 193
541: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 196
542: sched_cls  name tail_handle_ipv4_from_host  tag a06a6f8201622633  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 197
543: sched_cls  name __send_drop_notify  tag f827219d59d5a129  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
544: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
545: sched_cls  name tail_handle_ipv4_from_host  tag a06a6f8201622633  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 201
546: sched_cls  name __send_drop_notify  tag f827219d59d5a129  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
547: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 203
551: sched_cls  name tail_handle_ipv4_from_host  tag a06a6f8201622633  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 208
552: sched_cls  name __send_drop_notify  tag f827219d59d5a129  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 209
553: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
554: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 211
555: sched_cls  name tail_handle_ipv4  tag 31d9c018f22b03b1  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 194
561: sched_cls  name tail_handle_ipv4_from_host  tag a06a6f8201622633  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 219
562: sched_cls  name __send_drop_notify  tag f827219d59d5a129  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 220
563: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 221
564: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 222
566: sched_cls  name tail_ipv4_ct_ingress  tag b29506f41b722c1f  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 214
567: sched_cls  name tail_handle_ipv4_cont  tag 7ecac59a1493f8ad  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 224
568: sched_cls  name __send_drop_notify  tag 6b2935f095b6eb6a  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 225
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 226
571: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 230
572: sched_cls  name tail_handle_arp  tag 0df3fb52dd00ee6b  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 231
573: sched_cls  name handle_policy  tag 9304e209a0eccd34  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 228
574: sched_cls  name tail_handle_ipv4_cont  tag c696e768ca64e3da  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 232
575: sched_cls  name handle_policy  tag 7450cf4f830ab7b4  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 233
576: sched_cls  name tail_ipv4_to_endpoint  tag c88ee165b3b80441  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 234
577: sched_cls  name cil_from_container  tag f85ab6078c63d0ef  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 235
578: sched_cls  name tail_ipv4_ct_ingress  tag 267a19be9fa1abd2  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 236
579: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 237
580: sched_cls  name tail_handle_ipv4  tag 3d059de1ed84a333  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 238
581: sched_cls  name __send_drop_notify  tag b4ed0c9e5d6fb5b5  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
582: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
585: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
589: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
594: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
597: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:37:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
638: sched_cls  name tail_ipv4_ct_ingress  tag 7ee74e43028ff705  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 254
639: sched_cls  name cil_from_container  tag a47b8b1e5c4989fc  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 255
640: sched_cls  name tail_ipv4_to_endpoint  tag 6a706603b5616d99  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 256
641: sched_cls  name handle_policy  tag 6a9cf20979ee34a9  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 257
642: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 258
643: sched_cls  name tail_handle_ipv4  tag 7ea3a1ce6ee3ae3d  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 259
644: sched_cls  name tail_handle_arp  tag 6f705dfed4f4f5de  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 260
645: sched_cls  name __send_drop_notify  tag f198fafc66c9401f  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 261
646: sched_cls  name tail_handle_ipv4_cont  tag 8abaa2b03d7167bc  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 262
647: sched_cls  name tail_ipv4_ct_egress  tag e6a03f7458f3d6de  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 263
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
698: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
701: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
717: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
720: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
721: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
724: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
725: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
728: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
729: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
732: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
733: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
736: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3311: sched_cls  name tail_handle_arp  tag 724bcb4bcacb506b  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,635
	btf_id 3109
3312: sched_cls  name tail_ipv4_ct_egress  tag cd267e940f798eeb  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3110
3313: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,635
	btf_id 3111
3314: sched_cls  name tail_handle_ipv4  tag 201727031e39a5c0  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,635
	btf_id 3112
3315: sched_cls  name __send_drop_notify  tag 0d4d87ad23917748  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3113
3316: sched_cls  name tail_ipv4_ct_ingress  tag e581ef4c78c044f7  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3114
3319: sched_cls  name tail_handle_ipv4_cont  tag 2173448b4a00a71a  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,636,41,154,82,83,39,76,74,77,635,40,37,38,81
	btf_id 3118
3323: sched_cls  name tail_ipv4_to_endpoint  tag 4b340c5fea6b9bde  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,636,41,82,83,80,154,39,635,40,37,38
	btf_id 3120
3325: sched_cls  name handle_policy  tag 5234b0b676491db0  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,635,82,83,636,41,80,154,39,84,75,40,37,38
	btf_id 3124
3326: sched_cls  name cil_from_container  tag 2fc1daa813af5372  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 635,76
	btf_id 3126
3366: sched_cls  name __send_drop_notify  tag 071f93f8942a9a05  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3170
3367: sched_cls  name __send_drop_notify  tag fafed8a3229668b0  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3171
3368: sched_cls  name tail_handle_arp  tag c1d62379791d6d3c  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,647
	btf_id 3172
3369: sched_cls  name tail_handle_arp  tag d4e00b0e2d2dffba  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,646
	btf_id 3173
3370: sched_cls  name tail_handle_ipv4  tag 8507eab64cdc9912  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,647
	btf_id 3174
3371: sched_cls  name cil_from_container  tag 9f01b41d8a036391  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 647,76
	btf_id 3176
3372: sched_cls  name tail_ipv4_to_endpoint  tag f391c5216768d422  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,648,41,82,83,80,159,39,646,40,37,38
	btf_id 3175
3373: sched_cls  name tail_ipv4_ct_egress  tag 6960f9fc43cec7e8  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,647,82,83,645,84
	btf_id 3177
3375: sched_cls  name tail_ipv4_ct_ingress  tag 052555a715c31a33  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,647,82,83,645,84
	btf_id 3180
3376: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,647
	btf_id 3181
3377: sched_cls  name handle_policy  tag 56bf25d1d1307793  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,646,82,83,648,41,80,159,39,84,75,40,37,38
	btf_id 3179
3378: sched_cls  name cil_from_container  tag 70771d88842b60b7  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 646,76
	btf_id 3183
3379: sched_cls  name tail_ipv4_to_endpoint  tag 4697ff60d883b112  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,645,41,82,83,80,151,39,647,40,37,38
	btf_id 3182
3380: sched_cls  name tail_ipv4_ct_egress  tag d501e34549123020  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,648,84
	btf_id 3184
3382: sched_cls  name tail_handle_ipv4_cont  tag c92e5f92fc84ce19  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,645,41,151,82,83,39,76,74,77,647,40,37,38,81
	btf_id 3185
3383: sched_cls  name tail_ipv4_ct_ingress  tag db56c9a3bedecf74  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,648,84
	btf_id 3187
3384: sched_cls  name tail_handle_ipv4  tag cbb1d643226eb7f1  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,646
	btf_id 3189
3385: sched_cls  name handle_policy  tag a3b80a8b7bc3dcc1  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,647,82,83,645,41,80,151,39,84,75,40,37,38
	btf_id 3188
3386: sched_cls  name tail_handle_ipv4_cont  tag 53cb16e86a1c1d36  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,648,41,159,82,83,39,76,74,77,646,40,37,38,81
	btf_id 3190
3387: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,646
	btf_id 3191
