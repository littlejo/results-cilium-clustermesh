top - 12:54:16 up 30 min,  0 users,  load average: 0.46, 0.41, 0.21
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 21.4 us, 32.1 sy,  0.0 ni, 46.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    298.6 free,   1038.8 used,   2498.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2616.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 287648  80844 S   6.7   7.3   1:05.19 cilium-+
    418 root      20   0 1229744   9980   3900 S   0.0   0.3   0:04.49 cilium-+
   3160 root      20   0 1240432  16828  11356 S   0.0   0.4   0:00.02 cilium-+
   3172 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3202 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3228 root      20   0    6576   2432   2104 R   0.0   0.1   0:00.00 top
   3253 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3258 root      20   0 1539912   8332   6260 S   0.0   0.2   0:00.00 runc:[2+
