REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     129043    10467209    677    bpf_overlay.c
Interface                   INGRESS     655967    244675765   1132   bpf_host.c
Policy denied               EGRESS      61        4514        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      127661    10343661    53     encap.h
Success                     EGRESS      146459    19572894    1308   bpf_lxc.c
Success                     EGRESS      52714     4271176     1694   bpf_host.c
Success                     EGRESS      596       156337      86     l3.h
Success                     INGRESS     171757    19607517    86     l3.h
Success                     INGRESS     249313    26002357    235    trace.h
Unsupported L3 protocol     EGRESS      73        5514        1492   bpf_lxc.c
