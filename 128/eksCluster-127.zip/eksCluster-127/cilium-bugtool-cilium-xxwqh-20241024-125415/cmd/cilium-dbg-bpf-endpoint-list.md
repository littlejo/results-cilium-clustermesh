IP ADDRESS         LOCAL ENDPOINT INFO
10.127.0.3:0       id=714   sec_id=8395950 flags=0x0000 ifindex=12  mac=4E:8E:02:21:83:71 nodemac=DA:F7:DE:8D:5B:D6   
10.127.0.224:0     id=3031  sec_id=8400677 flags=0x0000 ifindex=18  mac=52:DA:DF:8D:39:DD nodemac=12:37:00:4F:5E:0A   
10.127.0.127:0     (localhost)                                                                                        
10.127.0.151:0     id=897   sec_id=4     flags=0x0000 ifindex=10  mac=66:50:C6:B1:16:53 nodemac=AE:6A:72:E7:CC:C5     
172.31.221.249:0   (localhost)                                                                                        
10.127.0.19:0      id=85    sec_id=8395950 flags=0x0000 ifindex=14  mac=CA:32:18:B3:D9:58 nodemac=7A:19:E1:E0:76:A4   
10.127.0.9:0       id=3784  sec_id=8436013 flags=0x0000 ifindex=24  mac=A6:88:91:F7:5E:40 nodemac=BE:0E:5D:C1:0C:F4   
10.127.0.152:0     id=3205  sec_id=8415081 flags=0x0000 ifindex=22  mac=C2:C7:43:09:60:B9 nodemac=C2:E0:D2:9C:5B:D2   
172.31.192.111:0   (localhost)                                                                                        
10.127.0.76:0      id=3398  sec_id=8434187 flags=0x0000 ifindex=20  mac=72:D3:6E:F8:33:B3 nodemac=12:53:67:3A:20:DA   
