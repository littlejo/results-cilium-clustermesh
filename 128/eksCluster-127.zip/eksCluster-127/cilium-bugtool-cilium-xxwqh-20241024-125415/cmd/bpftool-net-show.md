xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 554
ens6(4) clsact/ingress cil_from_netdev-ens6 id 564
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 544
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 539
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 577
lxc3bf19fb5ef57(12) clsact/ingress cil_from_container-lxc3bf19fb5ef57 id 530
lxca37082ee842f(14) clsact/ingress cil_from_container-lxca37082ee842f id 531
lxcec09bc29f015(18) clsact/ingress cil_from_container-lxcec09bc29f015 id 639
lxc93aa9418b900(20) clsact/ingress cil_from_container-lxc93aa9418b900 id 3371
lxc8c1c955bcc0a(22) clsact/ingress cil_from_container-lxc8c1c955bcc0a id 3326
lxc99f865188ecd(24) clsact/ingress cil_from_container-lxc99f865188ecd id 3378

flow_dissector:

netfilter:

