Endpoint ID: 85
Path: /sys/fs/bpf/tc/globals/cilium_policy_00085

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3616     36        0        
Allow    Ingress     1          ANY          NONE         disabled    100879   1160      0        
Allow    Egress      0          ANY          NONE         disabled    16473    177       0        


Endpoint ID: 714
Path: /sys/fs/bpf/tc/globals/cilium_policy_00714

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2280     24        0        
Allow    Ingress     1          ANY          NONE         disabled    101530   1173      0        
Allow    Egress      0          ANY          NONE         disabled    16216    175       0        


Endpoint ID: 896
Path: /sys/fs/bpf/tc/globals/cilium_policy_00896

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 897
Path: /sys/fs/bpf/tc/globals/cilium_policy_00897

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6240203   76982     0        
Allow    Ingress     1          ANY          NONE         disabled    53875     651       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3031
Path: /sys/fs/bpf/tc/globals/cilium_policy_03031

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6141550   61332     0        
Allow    Ingress     1          ANY          NONE         disabled    5398824   56980     0        
Allow    Egress      0          ANY          NONE         disabled    6423389   63839     0        


Endpoint ID: 3205
Path: /sys/fs/bpf/tc/globals/cilium_policy_03205

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376445   4379      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3398
Path: /sys/fs/bpf/tc/globals/cilium_policy_03398

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3784
Path: /sys/fs/bpf/tc/globals/cilium_policy_03784

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


