Node 0, zone      DMA     65     38     40      2      0      5      4      2      2      2     43 
Node 0, zone   Normal    129     34      4     40     14      2      9      7      1      2      7 
