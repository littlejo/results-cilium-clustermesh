filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc99f865188ecd direct-action not_in_hw id 3378 tag 70771d88842b60b7 jited 
