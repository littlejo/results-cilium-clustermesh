CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fd33b97_ec80_4995_adee_364c3cf355a7.slice/cri-containerd-a105f095b7eeaf5c76d5234d96a92e02431b5cb338d05517cd75d66ec56b7a94.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fd33b97_ec80_4995_adee_364c3cf355a7.slice/cri-containerd-9c7a8d61e7d6dd9994713495f49d6d7eb0c1a8803fbcec74386bb36274e773e6.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d78bc14_c9e1_422c_b91b_f391e07b7f7b.slice/cri-containerd-2e1dc32a96fb5504434c8b221a444c560b198e009d7df39a8990e9c2409cdf86.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d78bc14_c9e1_422c_b91b_f391e07b7f7b.slice/cri-containerd-7554609071dad253897dfbb9aa548a32f0c365519f8452204d32d2e04714a49d.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0054e161_f728_42fd_bf91_a5452658de78.slice/cri-containerd-658860b757aac0598cb03ad54cd56e0d7d8ccba1c55f4c94c65c0f9e9b0b7e37.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0054e161_f728_42fd_bf91_a5452658de78.slice/cri-containerd-22a5c244129a8935c2e02a4f8915d5d9648d91a3b06acd5b4cf08b7fb7c4c2a8.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9fdbeb3_7403_4f81_8d35_a442f71b1fe7.slice/cri-containerd-02fdbbd686b3f22c26c38b3c739ca8b1ba2cd3d1854ef7353536eed87209bb9b.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9fdbeb3_7403_4f81_8d35_a442f71b1fe7.slice/cri-containerd-a661a22588f883a000377ed14042a350037fb5fd4ff0b3f59c66ca0e00327294.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04495685_cab3_492b_b3be_e24f94afcf39.slice/cri-containerd-a4e554ba48c197e7ea813bdc3dbf6e6e1f92b9994226faf6fe2cc8b1b6ac09a1.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04495685_cab3_492b_b3be_e24f94afcf39.slice/cri-containerd-7ded717f9e9507c8de73000ce22120807287cdf651b55b18a3b6b057f77d02f8.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod68b3c65c_20da_4470_a064_fc6c331c23f2.slice/cri-containerd-95fc3d3afc46dc92aaeb4c39170382210ba36334a61503991ef9213d6d8cd19f.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod68b3c65c_20da_4470_a064_fc6c331c23f2.slice/cri-containerd-bf15906a0f39eddb1ac23a29499bce6df4495ddb9dd2a587d3d606fe362e0bce.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8639e3da_075d_47df_939b_66dc2d9283fe.slice/cri-containerd-f830c11166aaa6fa05d97a66d35152ed39f2e2757111639edacd36158ba26910.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8639e3da_075d_47df_939b_66dc2d9283fe.slice/cri-containerd-4b0e84838c2b36137c78e58df8f9afdafd5465c174e8ef9d87258932e1af5071.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8639e3da_075d_47df_939b_66dc2d9283fe.slice/cri-containerd-a6ddeb2d7b09fc880a6d19d1ded644a18711faa38aa032f70288a911d9e3dcf7.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8639e3da_075d_47df_939b_66dc2d9283fe.slice/cri-containerd-5518bd8b15583aafe72e66554aa2c970343cf00c40463ac133fd7907fd66255c.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98ae2fa5_e96d_4856_a9a0_8644630ddef6.slice/cri-containerd-2a77b7bdc3fd4e00acfaf572f977728e1ed6da6ba2c8ece908f31b687804c949.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98ae2fa5_e96d_4856_a9a0_8644630ddef6.slice/cri-containerd-53825ed7a10acb0b778f5f1b9350d4a88ac7cfa57cc3f13bc6236ba065ae3f1d.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6452f7f9_8134_4efe_a0ef_d19a0db2491c.slice/cri-containerd-a33977b430328f6ecb3719f28ff17bacb857d3c7dfa90125c4ddb54ea9de692d.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6452f7f9_8134_4efe_a0ef_d19a0db2491c.slice/cri-containerd-5a247e3be410328f0d16d28f621bd3729d7b7c9166bdaf79fc870ae4c5734a63.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67ad9bb8_d843_4e48_807d_3ffd3e690be2.slice/cri-containerd-3c83773f83caf5e2ad8d497b1c2705ccce1470cd7a63c34bdd11df0a74bc84fe.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67ad9bb8_d843_4e48_807d_3ffd3e690be2.slice/cri-containerd-134fdb6370441777cc57d1eb3bb2b2913d0583f55a0989d6f0876e7b3f44e2ac.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67ad9bb8_d843_4e48_807d_3ffd3e690be2.slice/cri-containerd-60f7f6aec298fafd0927f6dc5ee1eace6faf61e25e392904fe2c222355707760.scope
    736      cgroup_device   multi                                          
