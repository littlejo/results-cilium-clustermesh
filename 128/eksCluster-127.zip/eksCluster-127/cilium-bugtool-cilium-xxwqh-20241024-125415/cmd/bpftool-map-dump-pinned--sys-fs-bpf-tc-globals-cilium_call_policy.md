key: 55 00 00 00  value: 3d 02 00 00
key: ca 02 00 00  value: 0b 02 00 00
key: 81 03 00 00  value: 3f 02 00 00
key: d7 0b 00 00  value: 81 02 00 00
key: 85 0c 00 00  value: fd 0c 00 00
key: 46 0d 00 00  value: 39 0d 00 00
key: c8 0e 00 00  value: 31 0d 00 00
Found 7 elements
