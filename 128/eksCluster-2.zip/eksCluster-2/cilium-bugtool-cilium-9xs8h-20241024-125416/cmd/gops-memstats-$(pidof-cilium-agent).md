alloc: 74.63MB (78253232 bytes)
total-alloc: 3.10GB (3327610328 bytes)
sys: 227.32MB (238363988 bytes)
lookups: 0
mallocs: 75159204
frees: 74592270
heap-alloc: 74.63MB (78253232 bytes)
heap-sys: 180.76MB (189538304 bytes)
heap-idle: 59.47MB (62357504 bytes)
heap-in-use: 121.29MB (127180800 bytes)
heap-released: 8.85MB (9281536 bytes)
heap-objects: 566934
stack-in-use: 35.22MB (36929536 bytes)
stack-sys: 35.22MB (36929536 bytes)
stack-mspan-inuse: 2.05MB (2152800 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 970.37KB (993657 bytes)
gc-sys: 5.50MB (5762120 bytes)
next-gc: when heap-alloc >= 152.63MB (160046904 bytes)
last-gc: 2024-10-24 12:54:43.98409289 +0000 UTC
gc-pause-total: 19.95515ms
gc-pause: 99363
gc-pause-end: 1729774483984092890
num-gc: 103
num-forced-gc: 0
gc-cpu-fraction: 0.0005519285527060627
enable-gc: true
debug-gc: false
