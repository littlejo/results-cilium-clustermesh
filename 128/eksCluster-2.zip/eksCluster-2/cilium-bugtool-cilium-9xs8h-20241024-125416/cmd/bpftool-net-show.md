xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 574
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 554
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 519
lxcbb96d750bfce(12) clsact/ingress cil_from_container-lxcbb96d750bfce id 544
lxc64a0c343bf91(14) clsact/ingress cil_from_container-lxc64a0c343bf91 id 512
lxc953d9bc0f04c(18) clsact/ingress cil_from_container-lxc953d9bc0f04c id 624
lxc46c927a7ff21(20) clsact/ingress cil_from_container-lxc46c927a7ff21 id 3284
lxc47d0dd4bfe15(22) clsact/ingress cil_from_container-lxc47d0dd4bfe15 id 3334
lxcd800bb1de50c(24) clsact/ingress cil_from_container-lxcd800bb1de50c id 3329

flow_dissector:

netfilter:

