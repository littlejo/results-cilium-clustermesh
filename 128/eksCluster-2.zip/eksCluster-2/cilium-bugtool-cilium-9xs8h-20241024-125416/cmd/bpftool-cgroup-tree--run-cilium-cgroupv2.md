CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7df43c47_df2a_4db3_86b4_23c1591f2a39.slice/cri-containerd-5c5d9c54b458f7865c450dd707081732c49aaeca0d0e316ea37ca66d0d10dae1.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7df43c47_df2a_4db3_86b4_23c1591f2a39.slice/cri-containerd-161d13e6058710d2c6380e32ca2934525453ab936947ee7add741d0a363cfd52.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8470a1a4_6a0a_4df7_84b5_ef4cfb28d4bb.slice/cri-containerd-5b1a47cdca030444e43c363e881b0e39153f21f3bdae9190116d708b2159d4e9.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8470a1a4_6a0a_4df7_84b5_ef4cfb28d4bb.slice/cri-containerd-7181d5f4a173455f0e5be2720b971e5fd036e7493e45d2ca52a2d0db8a28d6c2.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ccbccbf_5ae4_490f_add1_afc38db71739.slice/cri-containerd-818177ba7179906b6756b91abde6f9e37221cf4ec08d1bbb2624794d84d07195.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ccbccbf_5ae4_490f_add1_afc38db71739.slice/cri-containerd-fe2205932629b1946152a129fe908df29701b896c9747a38ba4c214223f59fc1.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a3f1483_ef2b_493c_9374_6702098e3856.slice/cri-containerd-99c6d92e9a448de765a98b56d69e036ecbe0f7f9d648cfa991c518981aab0342.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a3f1483_ef2b_493c_9374_6702098e3856.slice/cri-containerd-673bad39adab7bf1f9907f0111da9adc504d3112233dd956c55d8b5e1bf55a59.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35eb7b53_755b_4f78_9817_253ee808c0d8.slice/cri-containerd-af1bdbe9da681619bf4c91809aa094333ecef2143e18c51b3684ef68f70d79ca.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35eb7b53_755b_4f78_9817_253ee808c0d8.slice/cri-containerd-0bcef1875a1a54081513f87a6ed4c3acc64972477aad8547be968db3ec3a6ae4.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35eb7b53_755b_4f78_9817_253ee808c0d8.slice/cri-containerd-e7712da4e6dc5d52c5f31760457d75c5194083bf31c1316f50d7a0b37bd8d091.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3408e144_5ca0_4be6_b496_708af6df49b7.slice/cri-containerd-6b6febdae71f64373b66767a82c1b55d90efbc9736cdc179b90b132884c1cf0a.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3408e144_5ca0_4be6_b496_708af6df49b7.slice/cri-containerd-457d32348896824f56c584c5a5133aeef011ccae923575b10f710d691a29c0e4.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod691ff1c7_14ab_4227_830e_17981b3ebdd7.slice/cri-containerd-e00c9bfdd70aac7452536a71ba3106c20b75f43bf7f49cff9cca4d30498481c4.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod691ff1c7_14ab_4227_830e_17981b3ebdd7.slice/cri-containerd-3e1b00d527d96d073067d16d10e3e92faa50f6e48bc50654246c607cd88f22cf.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefe55820_453c_48bd_b0f9_a2792fa1dcfd.slice/cri-containerd-ceba6973ab60d0678e4a9a753693e356b9e71d8a699738944d07903cc197a7e1.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefe55820_453c_48bd_b0f9_a2792fa1dcfd.slice/cri-containerd-d5fa1751875c7d6282fb8dedee56acc1266f738e0e3bda4d06bf047eedb07d8b.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefe55820_453c_48bd_b0f9_a2792fa1dcfd.slice/cri-containerd-91566c2e23ab4761479d90a38c07a174248774b3b002c29c2c115141649a061b.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefe55820_453c_48bd_b0f9_a2792fa1dcfd.slice/cri-containerd-91ec3a0ca34ead8289f8c0e7c47a72dd3c4b17707fa86600f0a0fa12ac485f04.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd94378eb_1487_4f4c_bdd7_1c51c1349a46.slice/cri-containerd-9683725c8b73c8ade8748e3bd4728aa7f39aea5cb1f6720613f46d48731e655a.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd94378eb_1487_4f4c_bdd7_1c51c1349a46.slice/cri-containerd-b18b44e7349e8b8ac3cb7dec371028bd8c616abf26f80f78b1ffa9c80e6a5202.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5318afa6_1bf8_42e2_8519_6d180115801d.slice/cri-containerd-ffac951cb6eb9d567a92f7738e0c1f0865ac0d95c7a9b0b112651e0464d791c4.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5318afa6_1bf8_42e2_8519_6d180115801d.slice/cri-containerd-74d592dceb32891ed2998585d77a691b00721d1084fec8bfc8a339a17f92c4ee.scope
    99       cgroup_device   multi                                          
