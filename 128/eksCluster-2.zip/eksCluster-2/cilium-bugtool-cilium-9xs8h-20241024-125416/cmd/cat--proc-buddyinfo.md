Node 0, zone      DMA      0     45     42     29     22     41     44     15     10      4     34 
Node 0, zone   Normal    277     79     15     16     18      7      2      2      4      4      6 
