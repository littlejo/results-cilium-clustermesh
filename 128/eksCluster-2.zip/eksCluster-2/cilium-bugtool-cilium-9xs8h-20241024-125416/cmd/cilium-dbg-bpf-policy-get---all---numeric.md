Endpoint ID: 1002
Path: /sys/fs/bpf/tc/globals/cilium_policy_01002

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1115
Path: /sys/fs/bpf/tc/globals/cilium_policy_01115

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1259
Path: /sys/fs/bpf/tc/globals/cilium_policy_01259

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6050667   59849     0        
Allow    Ingress     1          ANY          NONE         disabled    4783005   50130     0        
Allow    Egress      0          ANY          NONE         disabled    5926163   59441     0        


Endpoint ID: 1658
Path: /sys/fs/bpf/tc/globals/cilium_policy_01658

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2548     27        0        
Allow    Ingress     1          ANY          NONE         disabled    172273   1989      0        
Allow    Egress      0          ANY          NONE         disabled    22573    253       0        


Endpoint ID: 2675
Path: /sys/fs/bpf/tc/globals/cilium_policy_02675

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377299   4408      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2714
Path: /sys/fs/bpf/tc/globals/cilium_policy_02714

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3077
Path: /sys/fs/bpf/tc/globals/cilium_policy_03077

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6211394   76904     0        
Allow    Ingress     1          ANY          NONE         disabled    71008     861       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3150
Path: /sys/fs/bpf/tc/globals/cilium_policy_03150

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3348     33        0        
Allow    Ingress     1          ANY          NONE         disabled    171811   1982      0        
Allow    Egress      0          ANY          NONE         disabled    20865    235       0        


