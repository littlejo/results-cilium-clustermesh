[
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8470a1a4_6a0a_4df7_84b5_ef4cfb28d4bb.slice/cri-containerd-5b1a47cdca030444e43c363e881b0e39153f21f3bdae9190116d708b2159d4e9.scope"
      }
    ],
    "ips": [
      "10.2.0.48"
    ],
    "name": "coredns-cc6ccd49c-lq9zw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7df43c47_df2a_4db3_86b4_23c1591f2a39.slice/cri-containerd-161d13e6058710d2c6380e32ca2934525453ab936947ee7add741d0a363cfd52.scope"
      }
    ],
    "ips": [
      "10.2.0.67"
    ],
    "name": "coredns-cc6ccd49c-crl4v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod691ff1c7_14ab_4227_830e_17981b3ebdd7.slice/cri-containerd-e00c9bfdd70aac7452536a71ba3106c20b75f43bf7f49cff9cca4d30498481c4.scope"
      }
    ],
    "ips": [
      "10.2.0.152"
    ],
    "name": "client-974f6c69d-mmdb7",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefe55820_453c_48bd_b0f9_a2792fa1dcfd.slice/cri-containerd-91ec3a0ca34ead8289f8c0e7c47a72dd3c4b17707fa86600f0a0fa12ac485f04.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefe55820_453c_48bd_b0f9_a2792fa1dcfd.slice/cri-containerd-91566c2e23ab4761479d90a38c07a174248774b3b002c29c2c115141649a061b.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefe55820_453c_48bd_b0f9_a2792fa1dcfd.slice/cri-containerd-d5fa1751875c7d6282fb8dedee56acc1266f738e0e3bda4d06bf047eedb07d8b.scope"
      }
    ],
    "ips": [
      "10.2.0.35"
    ],
    "name": "clustermesh-apiserver-8c7476f9c-24lsf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35eb7b53_755b_4f78_9817_253ee808c0d8.slice/cri-containerd-af1bdbe9da681619bf4c91809aa094333ecef2143e18c51b3684ef68f70d79ca.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35eb7b53_755b_4f78_9817_253ee808c0d8.slice/cri-containerd-0bcef1875a1a54081513f87a6ed4c3acc64972477aad8547be968db3ec3a6ae4.scope"
      }
    ],
    "ips": [
      "10.2.0.233"
    ],
    "name": "echo-same-node-86d9cc975c-v9lxt",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd94378eb_1487_4f4c_bdd7_1c51c1349a46.slice/cri-containerd-b18b44e7349e8b8ac3cb7dec371028bd8c616abf26f80f78b1ffa9c80e6a5202.scope"
      }
    ],
    "ips": [
      "10.2.0.105"
    ],
    "name": "client2-57cf4468f-4b26w",
    "namespace": "cilium-test-1"
  }
]

