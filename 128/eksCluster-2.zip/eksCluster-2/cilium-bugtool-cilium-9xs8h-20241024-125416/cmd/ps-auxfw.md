USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3252  0.0  0.3 1240432 15652 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3267  0.0  0.0   6408  1644 ?        R    12:54   0:00  \_ ps auxfw
root        3268  0.0  0.3 1240432 15652 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3243  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3221  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3214  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3203  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3197  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.1  7.4 1539060 292676 ?      Ssl  12:24   1:13 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.2  0.2 1229744 9100 ?        Sl   12:24   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
