filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc46c927a7ff21 direct-action not_in_hw id 3284 tag 410c31e7c92db714 jited 
