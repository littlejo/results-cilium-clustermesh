top - 12:54:17 up 33 min,  0 users,  load average: 0.62, 0.55, 0.31
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 36.4 us, 45.5 sy,  0.0 ni, 15.2 id,  0.0 wa,  0.0 hi,  3.0 si,  0.0 st
MiB Mem :   3836.2 total,    285.9 free,   1053.3 used,   2496.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2601.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 298868  79172 S  29.4   7.6   1:13.61 cilium-+
    395 root      20   0 1229744   9100   2924 S   0.0   0.2   0:04.43 cilium-+
   3243 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3252 root      20   0 1240432  15872  10640 S   0.0   0.4   0:00.03 cilium-+
   3278 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3304 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
