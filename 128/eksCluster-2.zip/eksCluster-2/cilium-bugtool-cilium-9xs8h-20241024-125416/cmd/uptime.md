 12:54:17 up 33 min,  0 users,  load average: 0.62, 0.55, 0.31
