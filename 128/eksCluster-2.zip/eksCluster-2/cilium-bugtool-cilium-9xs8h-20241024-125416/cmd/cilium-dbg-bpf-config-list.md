KEY             VALUE
AgentLiveness   2068746130487
UTimeOffset     3378461755859375
