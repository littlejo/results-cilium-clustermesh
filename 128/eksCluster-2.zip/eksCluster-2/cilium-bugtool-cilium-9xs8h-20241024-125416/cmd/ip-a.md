1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:5e:46:08:63:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.165.27/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3373sec preferred_lft 3373sec
    inet6 fe80::45e:46ff:fe08:6387/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7c:a7:2f:e4:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.191.187/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::47c:a7ff:fe2f:e487/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:aa:3a:e0:e2:79 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::10aa:3aff:fee0:e279/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:a4:50:c3:0a:23 brd ff:ff:ff:ff:ff:ff
    inet 10.2.0.133/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b8a4:50ff:fec3:a23/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:fd:80:b6:e0:92 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::94fd:80ff:feb6:e092/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:d2:9b:28:aa:45 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::40d2:9bff:fe28:aa45/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcbb96d750bfce@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:64:d0:a2:35:36 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c64:d0ff:fea2:3536/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc64a0c343bf91@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:8f:1a:a5:f9:69 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e08f:1aff:fea5:f969/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc953d9bc0f04c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:ae:01:91:cc:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::28ae:1ff:fe91:ccb0/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc46c927a7ff21@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:dc:99:10:b6:28 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::30dc:99ff:fe10:b628/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc47d0dd4bfe15@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:42:ef:6d:b3:25 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::1c42:efff:fe6d:b325/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcd800bb1de50c@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:4f:eb:7a:2e:98 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::604f:ebff:fe7a:2e98/64 scope link 
       valid_lft forever preferred_lft forever
