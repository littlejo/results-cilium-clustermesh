key: 5b 04 00 00  value: 04 0d 00 00
key: eb 04 00 00  value: 6c 02 00 00
key: 7a 06 00 00  value: 1e 02 00 00
key: 73 0a 00 00  value: c9 0c 00 00
key: 9a 0a 00 00  value: 0d 0d 00 00
key: 05 0c 00 00  value: 03 02 00 00
key: 4e 0c 00 00  value: fe 01 00 00
Found 7 elements
