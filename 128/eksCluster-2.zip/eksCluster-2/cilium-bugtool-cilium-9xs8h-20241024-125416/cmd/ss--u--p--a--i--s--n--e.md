Total: 597
TCP:   4261 (estab 321, closed 3921, orphaned 0, timewait 3450)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  340       328       12       
INET	  350       334       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                   172.31.165.27%ens5:68         0.0.0.0:*    uid:192 ino:82991 sk:1 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:28461 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:37185      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:28303 sk:3 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15513 sk:4 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:28460 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15514 sk:6 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::45e:46ff:fe08:6387]%ens5:546           [::]:*    uid:192 ino:15709 sk:7 cgroup:unreachable:bd0 v6only:1 <->                   
