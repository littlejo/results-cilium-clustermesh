{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:29.062Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:29.117Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:29.124Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:29.165Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.873Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.888Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.922Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.951Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.962Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.215Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.238Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.282Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.305Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.335Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.977Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.984Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.029Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.053Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.097Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.391Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.415Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.501Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.513Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.546Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.028Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.060Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.082Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.129Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.131Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.171Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.415Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.433Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.471Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.520Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.524Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.141Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.145Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.188Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.224Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.253Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.302Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.310Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.564Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.607Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.682Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.720Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.737Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.129Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.175Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.207Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.229Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.267Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.473Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.489Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.549Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.564Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.599Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.056Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.059Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.119Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.121Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.160Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.392Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.400Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.490Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.501Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.536Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.040Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.047Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.117Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.134Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.157Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.378Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.395Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.442Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.473Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.518Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.925Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.958Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.978Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.027Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.034Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.095Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.334Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.337Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.391Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.403Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.442Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.857Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.901Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.908Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.953Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.959Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.997Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.254Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.289Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.375Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.401Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.421Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.662Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.673Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.733Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.736Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.774Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.024Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.056Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.095Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.124Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.161Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.457Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.506Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.560Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.590Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.620Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.638Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.871Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.877Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.897Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.947Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.692Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.694Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.724Z",
  "value": "id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.752Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.793Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.107Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.111Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.770Z",
  "value": "id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.779Z",
  "value": "id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98"
}

