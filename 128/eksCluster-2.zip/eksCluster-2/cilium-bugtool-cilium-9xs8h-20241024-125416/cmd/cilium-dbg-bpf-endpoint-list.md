IP ADDRESS         LOCAL ENDPOINT INFO
10.2.0.233:0       id=2675  sec_id=252020 flags=0x0000 ifindex=20  mac=7A:28:0E:06:24:9F nodemac=32:DC:99:10:B6:28   
10.2.0.152:0       id=1115  sec_id=231255 flags=0x0000 ifindex=22  mac=EA:D5:43:9F:6B:22 nodemac=1E:42:EF:6D:B3:25   
10.2.0.67:0        id=1658  sec_id=212904 flags=0x0000 ifindex=12  mac=EA:74:FB:B1:07:19 nodemac=0E:64:D0:A2:35:36   
10.2.0.105:0       id=2714  sec_id=256993 flags=0x0000 ifindex=24  mac=4A:2A:60:25:27:D3 nodemac=62:4F:EB:7A:2E:98   
172.31.191.187:0   (localhost)                                                                                       
10.2.0.35:0        id=1259  sec_id=199370 flags=0x0000 ifindex=18  mac=DE:A8:20:8D:AA:CD nodemac=2A:AE:01:91:CC:B0   
10.2.0.48:0        id=3150  sec_id=212904 flags=0x0000 ifindex=14  mac=06:56:FF:97:68:0D nodemac=E2:8F:1A:A5:F9:69   
10.2.0.117:0       id=3077  sec_id=4     flags=0x0000 ifindex=10  mac=D2:8B:CA:E6:7C:B0 nodemac=42:D2:9B:28:AA:45    
172.31.165.27:0    (localhost)                                                                                       
10.2.0.133:0       (localhost)                                                                                       
