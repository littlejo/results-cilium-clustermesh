filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc64a0c343bf91 direct-action not_in_hw id 512 tag 4463c3aa9c2e2e6c jited 
