Node 0, zone      DMA      2     94     42     48     26      9      6      3      3      5     40 
Node 0, zone   Normal     80      4      4      1      4      8      3      3      6      4      6 
