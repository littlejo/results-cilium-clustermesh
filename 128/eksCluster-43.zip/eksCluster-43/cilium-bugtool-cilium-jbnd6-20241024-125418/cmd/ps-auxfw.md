USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3252  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3241  0.0  0.4 1240432 16304 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3276  0.0  0.0   6408  1632 ?        R    12:54   0:00  \_ ps auxfw
root        3277  0.0  0.0   2068   240 ?        R    12:54   0:00  \_ hostname
root           1  4.5  7.5 1539132 297944 ?      Ssl  12:27   1:12 cilium-agent --config-dir=/tmp/cilium/config-map
root         408  0.2  0.2 1229744 10236 ?       Sl   12:27   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
