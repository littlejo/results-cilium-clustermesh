alloc: 96.24MB (100913072 bytes)
total-alloc: 3.11GB (3340562960 bytes)
sys: 227.39MB (238437716 bytes)
lookups: 0
mallocs: 75491033
frees: 74566269
heap-alloc: 96.24MB (100913072 bytes)
heap-sys: 180.60MB (189374464 bytes)
heap-idle: 53.32MB (55910400 bytes)
heap-in-use: 127.28MB (133464064 bytes)
heap-released: 10.72MB (11239424 bytes)
heap-objects: 924764
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.13MB (2238560 bytes)
stack-mspan-sys: 2.82MB (2953920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1064681 bytes)
gc-sys: 5.49MB (5753928 bytes)
next-gc: when heap-alloc >= 151.90MB (159276136 bytes)
last-gc: 2024-10-24 12:54:30.096989836 +0000 UTC
gc-pause-total: 12.165492ms
gc-pause: 74403
gc-pause-end: 1729774470096989836
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0005676751623814579
enable-gc: true
debug-gc: false
