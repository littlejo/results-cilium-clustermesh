CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod697ececf_8fc2_4a37_a615_c18fb44f3282.slice/cri-containerd-262cd7805890dde8ddfe152ea96f80825099372b2b9fc1c38a39976e8a32d7e0.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod697ececf_8fc2_4a37_a615_c18fb44f3282.slice/cri-containerd-2857b257522d0e1c38aaf50266ea42c988ee3705e0419e2ed862bd0844e0160d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45571a85_e687_4d90_a3d8_3346f4cd9ae2.slice/cri-containerd-2d7fdab8cda7b9e9cebe457cbac4cc84b631b0cc900381a068a808302679f118.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45571a85_e687_4d90_a3d8_3346f4cd9ae2.slice/cri-containerd-067934909e3c2a6677cc0c15d89953e580769b7766d1f27ac38d2cd4b5f2b919.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a1bfdb6_c890_4809_bc8e_64e29a8c8722.slice/cri-containerd-646564b584fe0433f5e29a75232bffd204a6c4c6f3e45eb3150c189cc5fed5cc.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a1bfdb6_c890_4809_bc8e_64e29a8c8722.slice/cri-containerd-14757840b166d4b5b7142a6856e69edf5a5104e0bd41ff1228f7339da75d0a45.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb94bb6ca_0e55_4bcf_98da_1169a024efef.slice/cri-containerd-b8a51131554d04b0756c676681fd2ceb4a1b5d04d79a6c1d44c251c712a4db8b.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb94bb6ca_0e55_4bcf_98da_1169a024efef.slice/cri-containerd-9afa6aad8598fb4ba3d48e613a88bb04185cd32bf9015f6388a5dd0e4558495b.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55904df6_f05a_4ab9_8a30_8831aef31c9e.slice/cri-containerd-2fdc1d8a2cf41681235c60fec9b48d28ab1be41a981ba9e5d8e9cd72ae95ce6e.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55904df6_f05a_4ab9_8a30_8831aef31c9e.slice/cri-containerd-88d9d0bb8eb61af0fecc4e20e25374bede0fc702a804ebc06d82094102ffe02a.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55904df6_f05a_4ab9_8a30_8831aef31c9e.slice/cri-containerd-a9a3cf7a4ad71104c333286d864f37c859fc494292166bb93d1581313afb791f.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55904df6_f05a_4ab9_8a30_8831aef31c9e.slice/cri-containerd-cb96bf09d0c5b1b43c5c14bae738eba4180781810cfa9b6a455319ef2755ca3a.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod581c2ba6_169b_4ed6_8546_eba79947036b.slice/cri-containerd-677d73d7b3cdf6d715b3205305eda673a45cde49c71a654998d0a7f77bc279cf.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod581c2ba6_169b_4ed6_8546_eba79947036b.slice/cri-containerd-3943b4e9dcbb221d7c5051e4bf86f5b73c633fe6a80a35b49ac5b55f4e294aeb.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca2f93d1_3fec_4551_abd9_9fdffe4fd290.slice/cri-containerd-c24b4e555192f516b1e804b6f2afc095b7f259d852a0371a0d324f760e2a43e2.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca2f93d1_3fec_4551_abd9_9fdffe4fd290.slice/cri-containerd-4b09003dd013bb8e301c0d3d293c9e998acb27017a20bbb754dabce6a3936452.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55d203ee_0b71_4463_92a7_957aacdde633.slice/cri-containerd-1bc127a421b69294df91c6ca99755c897aa7a0880200a865c654b49948bba81c.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55d203ee_0b71_4463_92a7_957aacdde633.slice/cri-containerd-49d14765ee60cbe15f52f5df6b8c85831dbccab4be4b6882be16433ddff0c05a.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod410bee22_5538_49b1_b2a1_aee0257a57e1.slice/cri-containerd-b207507a83d8160676c2315441e5cb9f7c070c752185a7400da5aea52880c551.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod410bee22_5538_49b1_b2a1_aee0257a57e1.slice/cri-containerd-b2b9b3612fe595b2b9e6fb31667e73ea77e24e21463e6ba8b898598c8e5c2d6d.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod410bee22_5538_49b1_b2a1_aee0257a57e1.slice/cri-containerd-b3f7581e8feacabe4db917af056fd258d4b252b1b4c200a864ba274f2c17ff09.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3156e743_5ee3_4263_ab04_0e37997b6e34.slice/cri-containerd-70c59df425f4201972d1d8491e39e751bb7521be01d4d6f8559b1fad0abe2301.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3156e743_5ee3_4263_ab04_0e37997b6e34.slice/cri-containerd-c5441d082de8f72942ebe5026a71d84279f88eefa05e2b58f6d186bbfeb4cb8f.scope
    709      cgroup_device   multi                                          
