Endpoint ID: 298
Path: /sys/fs/bpf/tc/globals/cilium_policy_00298

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 561
Path: /sys/fs/bpf/tc/globals/cilium_policy_00561

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2042     21        0        
Allow    Ingress     1          ANY          NONE         disabled    154930   1776      0        
Allow    Egress      0          ANY          NONE         disabled    22313    251       0        


Endpoint ID: 701
Path: /sys/fs/bpf/tc/globals/cilium_policy_00701

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 958
Path: /sys/fs/bpf/tc/globals/cilium_policy_00958

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1052
Path: /sys/fs/bpf/tc/globals/cilium_policy_01052

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6194346   76805     0        
Allow    Ingress     1          ANY          NONE         disabled    63398     765       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1386
Path: /sys/fs/bpf/tc/globals/cilium_policy_01386

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379411   4425      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1412
Path: /sys/fs/bpf/tc/globals/cilium_policy_01412

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3854     39        0        
Allow    Ingress     1          ANY          NONE         disabled    156514   1800      0        
Allow    Egress      0          ANY          NONE         disabled    21579    241       0        


Endpoint ID: 1916
Path: /sys/fs/bpf/tc/globals/cilium_policy_01916

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6112424   61725     0        
Allow    Ingress     1          ANY          NONE         disabled    5558015   58886     0        
Allow    Egress      0          ANY          NONE         disabled    7179789   70414     0        


