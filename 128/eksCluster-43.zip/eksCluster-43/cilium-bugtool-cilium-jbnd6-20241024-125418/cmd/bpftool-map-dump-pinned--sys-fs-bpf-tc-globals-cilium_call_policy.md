key: 2a 01 00 00  value: 19 0d 00 00
key: 31 02 00 00  value: 02 02 00 00
key: bd 02 00 00  value: 1a 0d 00 00
key: 1c 04 00 00  value: 12 02 00 00
key: 6a 05 00 00  value: e3 0c 00 00
key: 84 05 00 00  value: 1e 02 00 00
key: 7c 07 00 00  value: 75 02 00 00
Found 7 elements
