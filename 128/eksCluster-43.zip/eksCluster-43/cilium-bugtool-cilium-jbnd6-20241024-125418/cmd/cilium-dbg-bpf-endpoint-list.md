IP ADDRESS         LOCAL ENDPOINT INFO
172.31.252.251:0   (localhost)                                                                                        
10.43.0.106:0      id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56   
10.43.0.128:0      id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22   
10.43.0.132:0      (localhost)                                                                                        
10.43.0.238:0      id=1916  sec_id=2928938 flags=0x0000 ifindex=18  mac=BA:D1:12:F6:81:0A nodemac=7A:53:FE:94:4F:A9   
10.43.0.4:0        id=1052  sec_id=4     flags=0x0000 ifindex=10  mac=E2:74:6D:24:0E:E3 nodemac=02:F5:81:E0:DA:7C     
10.43.0.29:0       id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11   
172.31.194.195:0   (localhost)                                                                                        
10.43.0.110:0      id=1412  sec_id=2900006 flags=0x0000 ifindex=12  mac=E6:F7:C8:4C:90:A7 nodemac=16:C5:CA:49:95:F1   
10.43.0.235:0      id=561   sec_id=2900006 flags=0x0000 ifindex=14  mac=12:74:B8:D7:D4:7C nodemac=B6:ED:C9:35:94:6A   
