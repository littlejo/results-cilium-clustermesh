Total: 560
TCP:   4136 (estab 283, closed 3834, orphaned 0, timewait 3384)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  302       293       9        
INET	  312       299       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:41017      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:30956 sk:e5e fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.194.195%ens5:68         0.0.0.0:*    uid:192 ino:95409 sk:e5f cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:30541 sk:e60 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15612 sk:e61 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:30540 sk:e62 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15613 sk:e63 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::8c3:17ff:fea0:9a21]%ens5:546           [::]:*    uid:192 ino:15845 sk:e64 cgroup:unreachable:bd0 v6only:1 <->                   
