top - 12:54:20 up 32 min,  0 users,  load average: 0.28, 0.48, 0.33
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 35.7 sy,  0.0 ni, 10.7 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   3836.2 total,    281.8 free,   1057.8 used,   2496.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2597.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3298 root      20   0 1244340  21628  14468 S  26.7   0.6   0:00.04 hubble
   3241 root      20   0 1240432  16556  11356 S  13.3   0.4   0:00.04 cilium-+
      1 root      20   0 1539132 297944  80444 S   6.7   7.6   1:12.60 cilium-+
    408 root      20   0 1229744  10236   3900 S   0.0   0.3   0:04.46 cilium-+
   3252 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3286 root      20   0    2208    792    712 S   0.0   0.0   0:00.00 timeout
   3294 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3327 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
