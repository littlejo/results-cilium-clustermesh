{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.596Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.598Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.622Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.254Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.280Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.325Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.333Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.382Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.639Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.647Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.728Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.748Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.794Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.452Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.457Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.563Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.594Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.605Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.804Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.814Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.867Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.889Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.924Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.530Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.533Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.569Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.599Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.629Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.640Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.640Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.669Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.968Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.968Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.035Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.048Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.086Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.660Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.664Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.705Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.709Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.753Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.768Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.797Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.083Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.086Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.182Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.213Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.234Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.637Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.639Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.692Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.720Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.741Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.962Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.977Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.028Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.039Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.074Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.509Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.514Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.556Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.584Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.603Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.887Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.897Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.944Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.982Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.004Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.452Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.473Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.572Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.593Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.616Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.795Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.802Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.857Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.865Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.915Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.353Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.386Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.396Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.443Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.461Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.486Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.726Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.728Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.793Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.802Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.837Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.272Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.276Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.339Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.340Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.380Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.616Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.678Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.698Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.810Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.813Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.117Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.136Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.180Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.181Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.218Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.455Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.465Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.508Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.537Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.552Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.565Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.599Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.944Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.974Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.994Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.026Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.295Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.304Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.322Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.352Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.099Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.103Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.192Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.197Z",
  "value": "id=1386  sec_id=2914079 flags=0x0000 ifindex=22  mac=FA:60:95:AE:CA:8A nodemac=3E:72:DC:2E:49:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.255Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.535Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.542Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.223Z",
  "value": "id=701   sec_id=2908380 flags=0x0000 ifindex=24  mac=EA:91:C1:68:6F:44 nodemac=02:00:49:15:3D:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.241Z",
  "value": "id=298   sec_id=2905991 flags=0x0000 ifindex=20  mac=9E:3E:D5:C1:90:01 nodemac=42:BE:61:B0:B0:22"
}

