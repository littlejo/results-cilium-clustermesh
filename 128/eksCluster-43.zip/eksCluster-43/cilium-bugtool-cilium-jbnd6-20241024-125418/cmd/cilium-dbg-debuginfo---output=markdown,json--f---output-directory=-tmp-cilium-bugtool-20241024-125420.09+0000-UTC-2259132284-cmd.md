markdown output at /tmp/cilium-bugtool-20241024-125420.09+0000-UTC-2259132284/cmd/cilium-debuginfo-20241024-125450.814+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125420.09+0000-UTC-2259132284/cmd/cilium-debuginfo-20241024-125450.814+0000-UTC.json
