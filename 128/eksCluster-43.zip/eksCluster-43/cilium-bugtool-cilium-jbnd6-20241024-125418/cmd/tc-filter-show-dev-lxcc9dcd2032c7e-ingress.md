filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc9dcd2032c7e direct-action not_in_hw id 3302 tag 155e18e1cf40bad2 jited 
