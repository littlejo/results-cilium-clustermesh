 12:54:20 up 32 min,  0 users,  load average: 0.28, 0.48, 0.33
