1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c3:17:a0:9a:21 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.194.195/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3436sec preferred_lft 3436sec
    inet6 fe80::8c3:17ff:fea0:9a21/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:92:7c:66:e8:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.252.251/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::892:7cff:fe66:e863/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:6d:fe:df:bc:1d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d46d:feff:fedf:bc1d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:73:06:ce:0b:85 brd ff:ff:ff:ff:ff:ff
    inet 10.43.0.132/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b473:6ff:fece:b85/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3a:cd:dc:a0:03:c8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::38cd:dcff:fea0:3c8/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:f5:81:e0:da:7c brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f5:81ff:fee0:da7c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2f2efc85c335@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:c5:ca:49:95:f1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::14c5:caff:fe49:95f1/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca9f7bb9da8c4@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:ed:c9:35:94:6a brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::b4ed:c9ff:fe35:946a/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7904a2bef516@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:53:fe:94:4f:a9 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7853:feff:fe94:4fa9/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcd808b388da22@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:be:61:b0:b0:22 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::40be:61ff:feb0:b022/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcc9dcd2032c7e@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:72:dc:2e:49:56 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::3c72:dcff:fe2e:4956/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc8d029a0833df@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:00:49:15:3d:11 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::49ff:fe15:3d11/64 scope link 
       valid_lft forever preferred_lft forever
