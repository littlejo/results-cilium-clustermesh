KEY             VALUE
AgentLiveness   2003479049053
UTimeOffset     3378461888671875
