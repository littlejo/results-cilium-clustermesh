[
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3156e743_5ee3_4263_ab04_0e37997b6e34.slice/cri-containerd-70c59df425f4201972d1d8491e39e751bb7521be01d4d6f8559b1fad0abe2301.scope"
      }
    ],
    "ips": [
      "10.43.0.29"
    ],
    "name": "client2-57cf4468f-h4k9v",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45571a85_e687_4d90_a3d8_3346f4cd9ae2.slice/cri-containerd-067934909e3c2a6677cc0c15d89953e580769b7766d1f27ac38d2cd4b5f2b919.scope"
      }
    ],
    "ips": [
      "10.43.0.235"
    ],
    "name": "coredns-cc6ccd49c-2rgnx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod581c2ba6_169b_4ed6_8546_eba79947036b.slice/cri-containerd-677d73d7b3cdf6d715b3205305eda673a45cde49c71a654998d0a7f77bc279cf.scope"
      }
    ],
    "ips": [
      "10.43.0.128"
    ],
    "name": "client-974f6c69d-9mxg8",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55904df6_f05a_4ab9_8a30_8831aef31c9e.slice/cri-containerd-2fdc1d8a2cf41681235c60fec9b48d28ab1be41a981ba9e5d8e9cd72ae95ce6e.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55904df6_f05a_4ab9_8a30_8831aef31c9e.slice/cri-containerd-88d9d0bb8eb61af0fecc4e20e25374bede0fc702a804ebc06d82094102ffe02a.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55904df6_f05a_4ab9_8a30_8831aef31c9e.slice/cri-containerd-a9a3cf7a4ad71104c333286d864f37c859fc494292166bb93d1581313afb791f.scope"
      }
    ],
    "ips": [
      "10.43.0.238"
    ],
    "name": "clustermesh-apiserver-7584db5fcd-q5479",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb94bb6ca_0e55_4bcf_98da_1169a024efef.slice/cri-containerd-b8a51131554d04b0756c676681fd2ceb4a1b5d04d79a6c1d44c251c712a4db8b.scope"
      }
    ],
    "ips": [
      "10.43.0.110"
    ],
    "name": "coredns-cc6ccd49c-dkkgp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod410bee22_5538_49b1_b2a1_aee0257a57e1.slice/cri-containerd-b2b9b3612fe595b2b9e6fb31667e73ea77e24e21463e6ba8b898598c8e5c2d6d.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod410bee22_5538_49b1_b2a1_aee0257a57e1.slice/cri-containerd-b207507a83d8160676c2315441e5cb9f7c070c752185a7400da5aea52880c551.scope"
      }
    ],
    "ips": [
      "10.43.0.106"
    ],
    "name": "echo-same-node-86d9cc975c-bfn8f",
    "namespace": "cilium-test-1"
  }
]

