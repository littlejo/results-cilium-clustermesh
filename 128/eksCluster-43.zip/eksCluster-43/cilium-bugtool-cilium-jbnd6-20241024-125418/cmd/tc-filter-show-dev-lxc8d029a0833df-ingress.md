filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8d029a0833df direct-action not_in_hw id 3345 tag 0ef45ec60dc25a36 jited 
