alloc: 114.86MB (120442344 bytes)
total-alloc: 3.05GB (3278789344 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 74813665
frees: 73528502
heap-alloc: 114.86MB (120442344 bytes)
heap-sys: 176.47MB (185040896 bytes)
heap-idle: 40.80MB (42786816 bytes)
heap-in-use: 135.66MB (142254080 bytes)
heap-released: 17.81MB (18677760 bytes)
heap-objects: 1285163
stack-in-use: 35.53MB (37257216 bytes)
stack-sys: 35.53MB (37257216 bytes)
stack-mspan-inuse: 2.31MB (2422080 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 990.68KB (1014457 bytes)
gc-sys: 5.49MB (5756048 bytes)
next-gc: when heap-alloc >= 145.57MB (152640616 bytes)
last-gc: 2024-10-24 12:53:35.144110814 +0000 UTC
gc-pause-total: 8.984518ms
gc-pause: 75685
gc-pause-end: 1729774415144110814
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006197750136130954
enable-gc: true
debug-gc: false
