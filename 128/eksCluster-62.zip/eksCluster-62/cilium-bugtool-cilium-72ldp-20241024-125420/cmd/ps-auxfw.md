USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3203  0.0  0.3 1240176 15472 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3221  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3222  0.0  0.0    216     4 ?        R    12:54   0:00  \_ [hostname]
root           1  4.3  7.2 1539060 283856 ?      Ssl  12:28   1:06 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.2  0.2 1229744 8864 ?        Sl   12:29   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
