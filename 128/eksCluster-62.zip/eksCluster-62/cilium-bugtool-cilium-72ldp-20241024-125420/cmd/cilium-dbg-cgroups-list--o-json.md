[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67c1f822_3609_47d7_bddb_fe0929929fec.slice/cri-containerd-9452c06ef8a0c2f6b0f151ef298a2ab99c71a16c5b0f27ef4cecb701fe2779b8.scope"
      }
    ],
    "ips": [
      "10.62.0.242"
    ],
    "name": "coredns-cc6ccd49c-hg7k7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode395d0de_4237_42bb_b7fe_a6d61ea74697.slice/cri-containerd-91614e7a4689e1813e5a8ed313f32c728499a2b70eae8e1400ff45d3e2b08513.scope"
      }
    ],
    "ips": [
      "10.62.0.187"
    ],
    "name": "client2-57cf4468f-46jlk",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a15828b_82d5_47b9_ba83_4e67f80b54e8.slice/cri-containerd-5fa3cd21b03b033c369b40896b83d9f27c8e8ea91bf1eee82d6cf80a0c951be0.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a15828b_82d5_47b9_ba83_4e67f80b54e8.slice/cri-containerd-c5d709404e9c5fa629d990a962d79b63ccf791bbc7059062644f5f12b0d86141.scope"
      }
    ],
    "ips": [
      "10.62.0.112"
    ],
    "name": "echo-same-node-86d9cc975c-5bzjq",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeebaa13e_2fdb_4c12_ba94_aa7b5a799221.slice/cri-containerd-f25aa8b31ae00c1ff731b957d31fac5466e04e7d30fc3eb6c070070dce259a61.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeebaa13e_2fdb_4c12_ba94_aa7b5a799221.slice/cri-containerd-00c00e2c4832cb47152fa25bf37fc1663b568b386f0b47077100486c46a765f2.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeebaa13e_2fdb_4c12_ba94_aa7b5a799221.slice/cri-containerd-c193c19d8eb3b5b9d62b985223bf84f1ff1ab0e4ff8ba5e7eeeed1cbdc1ca6c0.scope"
      }
    ],
    "ips": [
      "10.62.0.178"
    ],
    "name": "clustermesh-apiserver-755d6b9567-ssj8n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb5b613d1_144a_4980_b350_b99721613a51.slice/cri-containerd-1bc38ae178a9df4ebc4360d7d3b4217b48d0965a91b42c5da963448c605caaf7.scope"
      }
    ],
    "ips": [
      "10.62.0.9"
    ],
    "name": "coredns-cc6ccd49c-v4722",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2a8031c_265f_4ac3_b7fd_8a26563d6731.slice/cri-containerd-93e3b53588db95b103fd71ef2e94301d2e9c25a20f89b8a173f22e80b5e304a7.scope"
      }
    ],
    "ips": [
      "10.62.0.8"
    ],
    "name": "client-974f6c69d-cs7j5",
    "namespace": "cilium-test-1"
  }
]

