1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3e:ed:a2:04:29 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.179.183/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3471sec preferred_lft 3471sec
    inet6 fe80::43e:edff:fea2:429/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:77:3b:9f:3c:a7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.128.13/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::477:3bff:fe9f:3ca7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:fb:be:be:28:78 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::78fb:beff:febe:2878/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:3b:28:55:99:f6 brd ff:ff:ff:ff:ff:ff
    inet 10.62.0.248/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::383b:28ff:fe55:99f6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ee:57:89:9f:2e:3e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ec57:89ff:fe9f:2e3e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:e1:ad:0f:b8:dc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::bce1:adff:fe0f:b8dc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc534b0d3dfd05@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:fe:d6:20:8c:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c0fe:d6ff:fe20:8ca2/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc4f6403a03e83@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:ad:a1:39:13:bc brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::34ad:a1ff:fe39:13bc/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf12f1a13669b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:59:ea:a3:a3:59 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8059:eaff:fea3:a359/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc1ae54c2cd04d@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:c5:36:65:0d:06 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3cc5:36ff:fe65:d06/64 scope link 
       valid_lft forever preferred_lft forever
22: lxce6cb8905eb85@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:e3:90:7b:46:46 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::8ce3:90ff:fe7b:4646/64 scope link 
       valid_lft forever preferred_lft forever
24: lxce4766b88234f@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:3a:e0:79:44:0b brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::943a:e0ff:fe79:440b/64 scope link 
       valid_lft forever preferred_lft forever
