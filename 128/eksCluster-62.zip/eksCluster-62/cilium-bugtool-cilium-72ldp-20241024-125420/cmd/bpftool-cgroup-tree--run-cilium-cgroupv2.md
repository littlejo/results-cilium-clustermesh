CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67c1f822_3609_47d7_bddb_fe0929929fec.slice/cri-containerd-56b6e0df838b1110c4896a7aa532937d25fe7a6c3c3b183af41a4bc82e88de09.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67c1f822_3609_47d7_bddb_fe0929929fec.slice/cri-containerd-9452c06ef8a0c2f6b0f151ef298a2ab99c71a16c5b0f27ef4cecb701fe2779b8.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb5b613d1_144a_4980_b350_b99721613a51.slice/cri-containerd-1bc38ae178a9df4ebc4360d7d3b4217b48d0965a91b42c5da963448c605caaf7.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb5b613d1_144a_4980_b350_b99721613a51.slice/cri-containerd-9851c6210c30d6115bacb9cebe77295d029d28b3f19ada3febe2d36466f3bc39.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod942c7345_549c_4749_b689_05e1a589baa3.slice/cri-containerd-7400c0c1f4a17a0f17105420693f768b5a8d8093ed5afd72d167c7592eefb4e3.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod942c7345_549c_4749_b689_05e1a589baa3.slice/cri-containerd-3df52344f75b1f3d4d0193845959249666ab0e35d4df72727b46306b2ac71282.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58d0e50c_66b4_4b9e_911d_148e020d7aa1.slice/cri-containerd-3034133ed3b7f473ced26ab5e40188a0a586c368bca396e60806c9a9415c8308.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58d0e50c_66b4_4b9e_911d_148e020d7aa1.slice/cri-containerd-fbdf20200f564e14802d3cc7bc35b77009f42b8c75e69246369043610a370361.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb6b7dfa_dc35_4e64_a759_a2dfc953429e.slice/cri-containerd-b274cb04366cb086286d3ed30663def687d3bd1a54561138307ddd58e31e2cf0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb6b7dfa_dc35_4e64_a759_a2dfc953429e.slice/cri-containerd-901949429739f12c74b619965fb97146fed8a0690bd669f67bfcf8e1a8a5c280.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9742f0cb_8cc0_4588_a373_d96185023e26.slice/cri-containerd-28061c999dd7da17e5a7d765a1d393a6ef9bc8f54d7b147328d458268557e674.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9742f0cb_8cc0_4588_a373_d96185023e26.slice/cri-containerd-641a05a910e7a0308c54e1b14d5221b7c4d99d6fabaad5c23a919e43b7b76be9.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2a8031c_265f_4ac3_b7fd_8a26563d6731.slice/cri-containerd-6c4359da4a2f2beb5a6f90f4a5a8da8c75387c126fd8fd59248181abed4e6535.scope
    665      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2a8031c_265f_4ac3_b7fd_8a26563d6731.slice/cri-containerd-93e3b53588db95b103fd71ef2e94301d2e9c25a20f89b8a173f22e80b5e304a7.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode395d0de_4237_42bb_b7fe_a6d61ea74697.slice/cri-containerd-1df0f6e25959eca06b8cc2ef0bb7dd755a5c7727d01211fb852637743d7f77aa.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode395d0de_4237_42bb_b7fe_a6d61ea74697.slice/cri-containerd-91614e7a4689e1813e5a8ed313f32c728499a2b70eae8e1400ff45d3e2b08513.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeebaa13e_2fdb_4c12_ba94_aa7b5a799221.slice/cri-containerd-f25aa8b31ae00c1ff731b957d31fac5466e04e7d30fc3eb6c070070dce259a61.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeebaa13e_2fdb_4c12_ba94_aa7b5a799221.slice/cri-containerd-c193c19d8eb3b5b9d62b985223bf84f1ff1ab0e4ff8ba5e7eeeed1cbdc1ca6c0.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeebaa13e_2fdb_4c12_ba94_aa7b5a799221.slice/cri-containerd-0efb8e7951542ee21aa2aac2e0c78f32a4ca245e11d4607bfc178f217a3cba9b.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeebaa13e_2fdb_4c12_ba94_aa7b5a799221.slice/cri-containerd-00c00e2c4832cb47152fa25bf37fc1663b568b386f0b47077100486c46a765f2.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a15828b_82d5_47b9_ba83_4e67f80b54e8.slice/cri-containerd-c5d709404e9c5fa629d990a962d79b63ccf791bbc7059062644f5f12b0d86141.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a15828b_82d5_47b9_ba83_4e67f80b54e8.slice/cri-containerd-73db5648b92e8a29ccbfa7786f9fd89406182972a8cdcf29ddcff31bf98d1518.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a15828b_82d5_47b9_ba83_4e67f80b54e8.slice/cri-containerd-5fa3cd21b03b033c369b40896b83d9f27c8e8ea91bf1eee82d6cf80a0c951be0.scope
    711      cgroup_device   multi                                          
