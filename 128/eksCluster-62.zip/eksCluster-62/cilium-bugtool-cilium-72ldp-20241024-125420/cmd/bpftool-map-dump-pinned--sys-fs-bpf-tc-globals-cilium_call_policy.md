key: 5e 00 00 00  value: 0b 0d 00 00
key: b8 00 00 00  value: e3 0c 00 00
key: d5 02 00 00  value: 14 02 00 00
key: c8 03 00 00  value: 6e 02 00 00
key: bc 04 00 00  value: 20 02 00 00
key: 9f 06 00 00  value: 06 0d 00 00
key: 38 0c 00 00  value: 1f 02 00 00
Found 7 elements
