IP ADDRESS         LOCAL ENDPOINT INFO
10.62.0.187:0      id=94    sec_id=4141303 flags=0x0000 ifindex=22  mac=22:67:66:0D:2E:11 nodemac=8E:E3:90:7B:46:46   
10.62.0.9:0        id=725   sec_id=4131959 flags=0x0000 ifindex=14  mac=9A:2A:C5:01:86:62 nodemac=36:AD:A1:39:13:BC   
172.31.128.13:0    (localhost)                                                                                        
10.62.0.248:0      (localhost)                                                                                        
10.62.0.178:0      id=968   sec_id=4136167 flags=0x0000 ifindex=18  mac=B6:54:23:46:9C:3E nodemac=82:59:EA:A3:A3:59   
10.62.0.8:0        id=1695  sec_id=4174167 flags=0x0000 ifindex=20  mac=E6:56:B6:A1:0B:C3 nodemac=3E:C5:36:65:0D:06   
10.62.0.112:0      id=184   sec_id=4159066 flags=0x0000 ifindex=24  mac=DE:C5:E1:10:7A:EA nodemac=96:3A:E0:79:44:0B   
10.62.0.204:0      id=1212  sec_id=4     flags=0x0000 ifindex=10  mac=26:CF:6A:37:EE:49 nodemac=BE:E1:AD:0F:B8:DC     
172.31.179.183:0   (localhost)                                                                                        
10.62.0.242:0      id=3128  sec_id=4131959 flags=0x0000 ifindex=12  mac=2A:94:1E:59:36:A6 nodemac=C2:FE:D6:20:8C:A2   
