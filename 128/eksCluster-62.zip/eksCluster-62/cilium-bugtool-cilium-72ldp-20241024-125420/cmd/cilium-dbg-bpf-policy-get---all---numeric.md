Endpoint ID: 94
Path: /sys/fs/bpf/tc/globals/cilium_policy_00094

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 184
Path: /sys/fs/bpf/tc/globals/cilium_policy_00184

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    355292   4148      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 725
Path: /sys/fs/bpf/tc/globals/cilium_policy_00725

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2498     25        0        
Allow    Ingress     1          ANY          NONE         disabled    144751   1670      0        
Allow    Egress      0          ANY          NONE         disabled    20843    231       0        


Endpoint ID: 968
Path: /sys/fs/bpf/tc/globals/cilium_policy_00968

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5372303   56392     0        
Allow    Ingress     1          ANY          NONE         disabled    5391793   56925     0        
Allow    Egress      0          ANY          NONE         disabled    6976696   69876     0        


Endpoint ID: 1008
Path: /sys/fs/bpf/tc/globals/cilium_policy_01008

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1212
Path: /sys/fs/bpf/tc/globals/cilium_policy_01212

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6203286   76672     0        
Allow    Ingress     1          ANY          NONE         disabled    63366     766       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1695
Path: /sys/fs/bpf/tc/globals/cilium_policy_01695

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3128
Path: /sys/fs/bpf/tc/globals/cilium_policy_03128

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3398     35        0        
Allow    Ingress     1          ANY          NONE         disabled    145202   1666      0        
Allow    Egress      0          ANY          NONE         disabled    19418    215       0        


