xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 504
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 495
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 485
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 550
lxc534b0d3dfd05(12) clsact/ingress cil_from_container-lxc534b0d3dfd05 id 556
lxc4f6403a03e83(14) clsact/ingress cil_from_container-lxc4f6403a03e83 id 524
lxcf12f1a13669b(18) clsact/ingress cil_from_container-lxcf12f1a13669b id 613
lxc1ae54c2cd04d(20) clsact/ingress cil_from_container-lxc1ae54c2cd04d id 3350
lxce6cb8905eb85(22) clsact/ingress cil_from_container-lxce6cb8905eb85 id 3344
lxce4766b88234f(24) clsact/ingress cil_from_container-lxce4766b88234f id 3279

flow_dissector:

netfilter:

