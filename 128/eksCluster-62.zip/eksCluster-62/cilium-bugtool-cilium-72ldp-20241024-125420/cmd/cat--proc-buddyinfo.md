Node 0, zone      DMA    288     31      3      1      4      0      3      2      3      4     36 
Node 0, zone   Normal    674    239    100     51     35     20     12      3      3      3      4 
