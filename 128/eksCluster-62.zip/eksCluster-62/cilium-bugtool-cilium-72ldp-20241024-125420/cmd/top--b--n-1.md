top - 12:54:22 up 32 min,  0 users,  load average: 0.59, 0.44, 0.25
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.0 us, 25.0 sy,  0.0 ni, 42.9 id,  0.0 wa,  0.0 hi,  7.1 si,  0.0 st
MiB Mem :   3836.2 total,    302.7 free,   1038.6 used,   2494.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2616.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 287056  78588 S  40.0   7.3   1:06.13 cilium-+
    395 root      20   0 1229744   8864   2864 S   0.0   0.2   0:04.30 cilium-+
   3203 root      20   0 1240432  15772  10768 S   0.0   0.4   0:00.02 cilium-+
   3234 root      20   0    6576   2416   2088 R   0.0   0.1   0:00.00 top
   3258 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
