KEY             VALUE
AgentLiveness   1942055658685
UTimeOffset     3378461958984375
