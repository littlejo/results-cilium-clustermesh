REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     131720    10675534    677    bpf_overlay.c
Interface                   INGRESS     647362    244779830   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      131834    10679807    53     encap.h
Success                     EGRESS      145150    18569708    1308   bpf_lxc.c
Success                     EGRESS      55727     4518440     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     167237    19020231    86     l3.h
Success                     INGRESS     244457    25376094    235    trace.h
Unsupported L3 protocol     EGRESS      72        5420        1492   bpf_lxc.c
