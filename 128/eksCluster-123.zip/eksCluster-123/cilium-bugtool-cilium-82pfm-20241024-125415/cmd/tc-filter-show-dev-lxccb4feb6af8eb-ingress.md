filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxccb4feb6af8eb direct-action not_in_hw id 3271 tag 2ba2676acc92d5ad jited 
