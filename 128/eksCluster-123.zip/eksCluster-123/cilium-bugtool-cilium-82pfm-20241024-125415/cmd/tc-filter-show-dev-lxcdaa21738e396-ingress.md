filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcdaa21738e396 direct-action not_in_hw id 644 tag c68086419656b9ca jited 
