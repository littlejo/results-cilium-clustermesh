KEY             VALUE
AgentLiveness   1874253439589
UTimeOffset     3378462136718750
