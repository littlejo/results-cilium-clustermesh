key: bb 00 00 00  value: 0e 02 00 00
key: d1 00 00 00  value: c3 0c 00 00
key: 1f 01 00 00  value: 82 02 00 00
key: cf 01 00 00  value: 01 0d 00 00
key: 09 06 00 00  value: 2e 02 00 00
key: 39 08 00 00  value: f7 0c 00 00
key: 08 0e 00 00  value: 41 02 00 00
Found 7 elements
