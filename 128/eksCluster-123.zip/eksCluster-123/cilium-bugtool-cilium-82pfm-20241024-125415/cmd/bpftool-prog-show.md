32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:38+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:39+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:40+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:40+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:40+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:40+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:45+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:24:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag 8a13bedf4852ce5b  gpl
	loaded_at 2024-10-24T12:34:39+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:34:39+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
483: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:34:39+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:34:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
513: sched_cls  name __send_drop_notify  tag 6423015d75b04619  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 162
514: sched_cls  name tail_handle_ipv4_cont  tag 6d100f0ce5dab9dc  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 164
517: sched_cls  name tail_handle_ipv4  tag a7d792269d59cac6  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 165
519: sched_cls  name cil_from_container  tag fb833723eb299cda  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 169
523: sched_cls  name tail_ipv4_ct_egress  tag 004af962607e176d  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 170
526: sched_cls  name handle_policy  tag 58f9ab028d55cd98  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 174
527: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 177
528: sched_cls  name tail_handle_arp  tag 569f88eee9ba39f5  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 178
533: sched_cls  name cil_from_container  tag 57bcf314be8f2997  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 184
534: sched_cls  name tail_ipv4_ct_ingress  tag 935920ae24eb78ab  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 180
535: sched_cls  name tail_ipv4_ct_egress  tag 004af962607e176d  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 185
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 187
537: sched_cls  name tail_ipv4_to_endpoint  tag d828b59832510d1e  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 186
538: sched_cls  name tail_ipv4_ct_ingress  tag 78b0c8dbdccb686c  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 188
539: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 190
541: sched_cls  name __send_drop_notify  tag 284a73f29a29335b  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
542: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 193
544: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 195
545: sched_cls  name tail_handle_ipv4_from_host  tag 416cb9137c71ffb8  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 196
548: sched_cls  name __send_drop_notify  tag 284a73f29a29335b  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
551: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 204
552: sched_cls  name tail_handle_ipv4_from_host  tag 416cb9137c71ffb8  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 205
553: sched_cls  name __send_drop_notify  tag 284a73f29a29335b  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
554: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 208
555: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 209
557: sched_cls  name tail_handle_ipv4_from_host  tag 416cb9137c71ffb8  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 211
558: sched_cls  name handle_policy  tag 8f7724f4c623e22a  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 197
562: sched_cls  name tail_ipv4_to_endpoint  tag d4392b96d1dac5ee  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 216
564: sched_cls  name __send_drop_notify  tag 284a73f29a29335b  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
565: sched_cls  name tail_handle_ipv4_cont  tag 8fc84e7b738d1c6c  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 219
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 221
567: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 222
569: sched_cls  name tail_handle_ipv4_from_host  tag 416cb9137c71ffb8  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 224
570: sched_cls  name tail_handle_arp  tag 6fa2de346df579b5  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 226
572: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 228
573: sched_cls  name tail_handle_ipv4  tag d7d934ba816eef3c  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 220
575: sched_cls  name tail_handle_arp  tag 5da4ee4e7a168a02  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 231
576: sched_cls  name __send_drop_notify  tag 0603b60b73ef55ad  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 232
577: sched_cls  name handle_policy  tag 76c63bece6b4c9bc  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 229
578: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 233
579: sched_cls  name tail_ipv4_ct_ingress  tag 93dac9ef13b9aec3  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 234
580: sched_cls  name tail_ipv4_to_endpoint  tag 88fd7b58937ead8d  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 235
581: sched_cls  name cil_from_container  tag 2ce0bdeef9eedcaa  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 236
582: sched_cls  name tail_handle_ipv4_cont  tag e5e7a528456f9055  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 237
583: sched_cls  name __send_drop_notify  tag 06d598d0ddba7a28  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 238
584: sched_cls  name tail_handle_ipv4  tag 0a30281213ed91dd  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:34:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_handle_ipv4  tag e9063c85929a25e5  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 253
641: sched_cls  name tail_ipv4_ct_egress  tag 8ba7c46cefa6a03d  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 254
642: sched_cls  name handle_policy  tag 51b20dc0cc4a5b4d  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 255
643: sched_cls  name tail_ipv4_to_endpoint  tag 760b86f9da710438  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 256
644: sched_cls  name cil_from_container  tag c68086419656b9ca  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 257
645: sched_cls  name tail_handle_arp  tag 51166f2fabd41a7b  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 258
646: sched_cls  name __send_drop_notify  tag 89bb6083873cbdce  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 259
648: sched_cls  name tail_ipv4_ct_ingress  tag 9fa3e9a1643fe029  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 261
649: sched_cls  name tail_handle_ipv4_cont  tag fcfccb8ac1d7d2b0  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 262
650: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
690: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
693: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
720: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
723: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
724: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
727: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
728: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
731: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
732: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
735: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
736: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
739: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3259: sched_cls  name tail_handle_ipv4_cont  tag ab1d72ad083c7c54  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,626,41,155,82,83,39,76,74,77,625,40,37,38,81
	btf_id 3049
3261: sched_cls  name __send_drop_notify  tag aa37a3aabaa1c6e6  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3053
3262: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,625
	btf_id 3054
3265: sched_cls  name tail_ipv4_to_endpoint  tag 1bb22b1e8ced8de2  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,626,41,82,83,80,155,39,625,40,37,38
	btf_id 3055
3267: sched_cls  name handle_policy  tag 97fe2b0ea7b4f4ce  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,625,82,83,626,41,80,155,39,84,75,40,37,38
	btf_id 3058
3268: sched_cls  name tail_handle_arp  tag 826d207a6160ec67  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,625
	btf_id 3060
3270: sched_cls  name tail_handle_ipv4  tag 3d14261f20291598  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,625
	btf_id 3061
3271: sched_cls  name cil_from_container  tag 2ba2676acc92d5ad  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 625,76
	btf_id 3063
3274: sched_cls  name tail_ipv4_ct_egress  tag 6b540f2ef2029787  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,625,82,83,626,84
	btf_id 3064
3276: sched_cls  name tail_ipv4_ct_ingress  tag bed5726ed8c7c2cb  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,625,82,83,626,84
	btf_id 3067
3314: sched_cls  name cil_from_container  tag 1c415a1bbc0cded4  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,76
	btf_id 3111
3316: sched_cls  name tail_handle_arp  tag 65cf3d41a91c90fa  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,638
	btf_id 3113
3317: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,638
	btf_id 3114
3318: sched_cls  name tail_handle_ipv4_cont  tag 7f85ee7edf1f08fc  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,637,41,151,82,83,39,76,74,77,638,40,37,38,81
	btf_id 3115
3319: sched_cls  name handle_policy  tag 38fe2e0eefe0859d  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,635,82,83,636,41,80,158,39,84,75,40,37,38
	btf_id 3110
3320: sched_cls  name tail_handle_ipv4  tag 54ddbca6197dd595  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,638
	btf_id 3116
3321: sched_cls  name __send_drop_notify  tag 5c90a89f83923288  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3118
3322: sched_cls  name tail_handle_ipv4_cont  tag 66caf89ded99f024  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,636,41,158,82,83,39,76,74,77,635,40,37,38,81
	btf_id 3117
3323: sched_cls  name tail_ipv4_ct_ingress  tag 85c269371883146d  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3119
3324: sched_cls  name tail_ipv4_ct_egress  tag 7845e83aab74dc7f  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3120
3325: sched_cls  name __send_drop_notify  tag 0a41251bb1789b34  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3122
3326: sched_cls  name tail_ipv4_ct_ingress  tag 4ce82fe5d171f717  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3123
3327: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,635
	btf_id 3124
3329: sched_cls  name handle_policy  tag 4b80fb1361548c65  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,638,82,83,637,41,80,151,39,84,75,40,37,38
	btf_id 3121
3330: sched_cls  name tail_ipv4_to_endpoint  tag e773d72c56006c89  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,636,41,82,83,80,158,39,635,40,37,38
	btf_id 3126
3331: sched_cls  name tail_handle_arp  tag c1aacc6f34dd9578  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,635
	btf_id 3127
3332: sched_cls  name tail_handle_ipv4  tag 590168057877601a  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,635
	btf_id 3129
3333: sched_cls  name cil_from_container  tag 80cab18838f7f7af  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 635,76
	btf_id 3130
3334: sched_cls  name tail_ipv4_to_endpoint  tag bfc1163a075b3421  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,637,41,82,83,80,151,39,638,40,37,38
	btf_id 3128
3335: sched_cls  name tail_ipv4_ct_egress  tag 0697f954dc78540a  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3131
