USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3246  0.0  0.3 1240176 15400 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3265  0.0  0.0   6408  1632 ?        R    12:54   0:00  \_ ps auxfw
root        3266  0.0  0.0   2068   240 ?        R    12:54   0:00  \_ hostname
root        3240  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  5.4  7.4 1539060 293492 ?      Ssl  12:34   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.3  0.2 1229744 10012 ?       Sl   12:34   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
