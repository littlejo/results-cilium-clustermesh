IP ADDRESS         LOCAL ENDPOINT INFO
10.123.0.192:0     id=3592  sec_id=4     flags=0x0000 ifindex=10  mac=16:E8:1B:7E:1A:ED nodemac=5E:D3:55:45:E6:AD     
172.31.210.235:0   (localhost)                                                                                        
10.123.0.101:0     id=209   sec_id=8149977 flags=0x0000 ifindex=22  mac=36:A4:E2:C8:F0:21 nodemac=DA:00:33:3C:8B:A5   
10.123.0.29:0      (localhost)                                                                                        
172.31.212.31:0    (localhost)                                                                                        
10.123.0.250:0     id=463   sec_id=8126660 flags=0x0000 ifindex=20  mac=12:5C:EE:C4:10:9F nodemac=6A:74:C0:04:16:26   
10.123.0.48:0      id=287   sec_id=8132804 flags=0x0000 ifindex=18  mac=16:71:DB:4B:40:FA nodemac=6A:FB:C3:12:F6:8B   
10.123.0.105:0     id=2105  sec_id=8135441 flags=0x0000 ifindex=24  mac=0A:9D:6A:81:1E:9D nodemac=12:91:CC:F9:26:87   
10.123.0.39:0      id=187   sec_id=8190704 flags=0x0000 ifindex=12  mac=1E:72:75:42:2E:61 nodemac=26:F7:D4:D9:88:2B   
10.123.0.143:0     id=1545  sec_id=8190704 flags=0x0000 ifindex=14  mac=86:F5:5C:EC:65:81 nodemac=12:05:EF:AF:0C:45   
