Node 0, zone      DMA    114    103      6     23      9      4      4      3      2      3     44 
Node 0, zone   Normal      5      7      2     10     27      6      4      2      1      0      9 
