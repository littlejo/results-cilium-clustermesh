ip-172-31-210-235.eu-west-3.compute.internal
