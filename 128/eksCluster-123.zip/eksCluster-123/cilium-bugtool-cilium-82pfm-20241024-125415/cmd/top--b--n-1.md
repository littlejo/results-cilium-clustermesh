top - 12:54:17 up 30 min,  0 users,  load average: 0.26, 0.40, 0.29
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 37.9 us, 58.6 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    286.8 free,   1051.2 used,   2498.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2604.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3292 root      20   0 1244340  20032  13248 S  26.7   0.5   0:00.04 hubble
      1 root      20   0 1539060 293492  78400 S  13.3   7.5   1:04.92 cilium-+
   3246 root      20   0 1240432  15400  10640 S  13.3   0.4   0:00.03 cilium-+
    392 root      20   0 1229744  10012   3840 S   0.0   0.3   0:04.49 cilium-+
   3240 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3282 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3286 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3311 root      20   0    1756      4      0 R   0.0   0.0   0:00.00 bash
