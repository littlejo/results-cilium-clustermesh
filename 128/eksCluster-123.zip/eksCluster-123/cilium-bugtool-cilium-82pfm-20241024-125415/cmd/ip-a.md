1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:45:d0:da:63:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.210.235/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3570sec preferred_lft 3570sec
    inet6 fe80::845:d0ff:feda:6387/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:78:1c:f5:91:9b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.212.31/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::878:1cff:fef5:919b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:11:e2:60:54:30 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6411:e2ff:fe60:5430/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:bc:19:db:9a:4c brd ff:ff:ff:ff:ff:ff
    inet 10.123.0.29/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1cbc:19ff:fedb:9a4c/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d2:94:f0:9e:73:be brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d094:f0ff:fe9e:73be/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:d3:55:45:e6:ad brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5cd3:55ff:fe45:e6ad/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc57ef9c7dbe1f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:f7:d4:d9:88:2b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::24f7:d4ff:fed9:882b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc1aa8bfe0ccbf@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:05:ef:af:0c:45 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1005:efff:feaf:c45/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcdaa21738e396@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:fb:c3:12:f6:8b brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::68fb:c3ff:fe12:f68b/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc8562b45c8046@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:74:c0:04:16:26 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6874:c0ff:fe04:1626/64 scope link 
       valid_lft forever preferred_lft forever
22: lxccb4feb6af8eb@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:00:33:3c:8b:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::d800:33ff:fe3c:8ba5/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc8e4c2da844f1@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:91:cc:f9:26:87 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::1091:ccff:fef9:2687/64 scope link 
       valid_lft forever preferred_lft forever
