filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8562b45c8046 direct-action not_in_hw id 3314 tag 1c415a1bbc0cded4 jited 
