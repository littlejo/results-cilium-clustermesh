 12:54:17 up 30 min,  0 users,  load average: 0.26, 0.40, 0.29
