Total: 559
TCP:   3977 (estab 298, closed 3660, orphaned 0, timewait 3198)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  317       307       10       
INET	  327       313       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:36251      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:36344 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.210.235%ens5:68         0.0.0.0:*    uid:192 ino:158761 sk:1002 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:37094 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15235 sk:1004 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:37093 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15236 sk:1006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::845:d0ff:feda:6387]%ens5:546           [::]:*    uid:192 ino:15635 sk:1007 cgroup:unreachable:bd0 v6only:1 <->                   
