[
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6257fe31_4bca_4edd_921c_7a96d18f803e.slice/cri-containerd-d5a267865263e26f94b44439450bd4072307aa34e569346bcb31a63da1977a6c.scope"
      }
    ],
    "ips": [
      "10.123.0.39"
    ],
    "name": "coredns-cc6ccd49c-cnbxk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd33ac82c_c883_4ff5_9b88_bad05e769800.slice/cri-containerd-e7bcaa8d7d18850a15bb799a846fc4a47eef732d4caacf11cc785e1924041876.scope"
      }
    ],
    "ips": [
      "10.123.0.143"
    ],
    "name": "coredns-cc6ccd49c-nz86h",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e90a3d6_3516_4206_bd41_7977a76540fa.slice/cri-containerd-de8d938250142427d771e32d90668208147af47d0c9582ba02bb4c805e95a5dd.scope"
      }
    ],
    "ips": [
      "10.123.0.250"
    ],
    "name": "client-974f6c69d-gbln7",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b0e3f26_a8b7_4423_a208_1ad5baa8cbbe.slice/cri-containerd-2a3f97b1daa604b6be452ee356db3bc4c5085a6898d4e244b3cf96d2fdcbfe84.scope"
      }
    ],
    "ips": [
      "10.123.0.105"
    ],
    "name": "client2-57cf4468f-xv7bg",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861dfe0_84a0_45b4_b65e_0ab88c09f781.slice/cri-containerd-8540866ee00bf166f78c9db61b0108e844c06d1963a6651ab0fabbe85bb106da.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861dfe0_84a0_45b4_b65e_0ab88c09f781.slice/cri-containerd-684493801aa9b51f3a8ed3555961977755393d4bd0ab0691ab62fe9f83602b0a.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861dfe0_84a0_45b4_b65e_0ab88c09f781.slice/cri-containerd-c3310ad67d3be4411f2291d16aee799f0dc685933493dd2e3b548de406ec1036.scope"
      }
    ],
    "ips": [
      "10.123.0.48"
    ],
    "name": "clustermesh-apiserver-6c8d7768df-q5trs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6d96b0a_1c71_4967_b07f_656aa27be218.slice/cri-containerd-c413a331fc5b1598d6a59a3d3daaf874ac0589900b491762c7f95ba10993ae61.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6d96b0a_1c71_4967_b07f_656aa27be218.slice/cri-containerd-2d6bf797eddff050b0e5d8c82e1596b6872f74e057e71344b46395526d4c6f20.scope"
      }
    ],
    "ips": [
      "10.123.0.101"
    ],
    "name": "echo-same-node-86d9cc975c-v5lks",
    "namespace": "cilium-test-1"
  }
]

