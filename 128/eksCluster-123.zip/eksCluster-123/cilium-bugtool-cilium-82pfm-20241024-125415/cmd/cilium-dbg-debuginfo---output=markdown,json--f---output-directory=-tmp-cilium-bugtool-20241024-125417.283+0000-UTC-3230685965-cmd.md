markdown output at /tmp/cilium-bugtool-20241024-125417.283+0000-UTC-3230685965/cmd/cilium-debuginfo-20241024-125448.011+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.283+0000-UTC-3230685965/cmd/cilium-debuginfo-20241024-125448.011+0000-UTC.json
