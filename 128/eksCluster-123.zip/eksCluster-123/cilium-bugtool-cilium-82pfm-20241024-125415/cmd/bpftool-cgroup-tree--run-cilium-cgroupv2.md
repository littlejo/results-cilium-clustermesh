CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad4c3ff7_8434_478b_bd25_47e4e9a50cb6.slice/cri-containerd-e02f5bbecc8d41d0f4bb0220258a88bd25344abd3143885c61c21285d614ea2f.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad4c3ff7_8434_478b_bd25_47e4e9a50cb6.slice/cri-containerd-b2c95f0fc77a2eb3fcfaa2ea3aaa87366cdfca54a7bde2ba9de3f4905e95ee5f.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd33ac82c_c883_4ff5_9b88_bad05e769800.slice/cri-containerd-80d39decd0f3006543cdd0d71d6517017774f8ea346da952c9b6edcd167f575d.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd33ac82c_c883_4ff5_9b88_bad05e769800.slice/cri-containerd-e7bcaa8d7d18850a15bb799a846fc4a47eef732d4caacf11cc785e1924041876.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod843a5785_f097_48f0_95c0_d0391de5fbdf.slice/cri-containerd-1248230e104c7a0b7b8c65ec289a48194bfff18618692c8a300be94d8c0bf5e4.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod843a5785_f097_48f0_95c0_d0391de5fbdf.slice/cri-containerd-1303d02be8ab964404c482a03297690fd0a23bd611de7acc1f663a1661b162a1.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6257fe31_4bca_4edd_921c_7a96d18f803e.slice/cri-containerd-f662a36a17da4f7565df1ab945e8ab88126d23deac57f62de7b89a9841032526.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6257fe31_4bca_4edd_921c_7a96d18f803e.slice/cri-containerd-d5a267865263e26f94b44439450bd4072307aa34e569346bcb31a63da1977a6c.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e90a3d6_3516_4206_bd41_7977a76540fa.slice/cri-containerd-de8d938250142427d771e32d90668208147af47d0c9582ba02bb4c805e95a5dd.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e90a3d6_3516_4206_bd41_7977a76540fa.slice/cri-containerd-2fb48fdf3c3579cb0669a0830eecdbd999a15d9f376f46e6aadb93fefd6571b8.scope
    693      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcfb1717d_639d_4219_8a3d_e573a6ab0e95.slice/cri-containerd-d16e9a022d2da953e4f6783942c38a71d9ec133bc2ff03669b9019eda715dd88.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcfb1717d_639d_4219_8a3d_e573a6ab0e95.slice/cri-containerd-51cd3af263c675df834ada22eefe263137326c40ff0d3110a7911b316786040c.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b0e3f26_a8b7_4423_a208_1ad5baa8cbbe.slice/cri-containerd-5f5abdbb510aaafa919c5bea96c5475180dfa303b1b472d8117b30489b4870e4.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b0e3f26_a8b7_4423_a208_1ad5baa8cbbe.slice/cri-containerd-2a3f97b1daa604b6be452ee356db3bc4c5085a6898d4e244b3cf96d2fdcbfe84.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861dfe0_84a0_45b4_b65e_0ab88c09f781.slice/cri-containerd-684493801aa9b51f3a8ed3555961977755393d4bd0ab0691ab62fe9f83602b0a.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861dfe0_84a0_45b4_b65e_0ab88c09f781.slice/cri-containerd-8540866ee00bf166f78c9db61b0108e844c06d1963a6651ab0fabbe85bb106da.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861dfe0_84a0_45b4_b65e_0ab88c09f781.slice/cri-containerd-a149a7ee67bb3c1e7a27bd7f8e58a82abcf06351ee06ab9bc366143973645075.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861dfe0_84a0_45b4_b65e_0ab88c09f781.slice/cri-containerd-c3310ad67d3be4411f2291d16aee799f0dc685933493dd2e3b548de406ec1036.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6d96b0a_1c71_4967_b07f_656aa27be218.slice/cri-containerd-2d6bf797eddff050b0e5d8c82e1596b6872f74e057e71344b46395526d4c6f20.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6d96b0a_1c71_4967_b07f_656aa27be218.slice/cri-containerd-c413a331fc5b1598d6a59a3d3daaf874ac0589900b491762c7f95ba10993ae61.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6d96b0a_1c71_4967_b07f_656aa27be218.slice/cri-containerd-499e41c1a0c59a3de25f13d9f7212c521cda2e41302de90d339208beffdf3ffb.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5f570e33_a6a2_4c8b_bd9a_dacb58cf7c82.slice/cri-containerd-79ead4255f7bfc636209fa7efd59571b27608110328a17601571fff0854883c0.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5f570e33_a6a2_4c8b_bd9a_dacb58cf7c82.slice/cri-containerd-4a8d6870bd7a5c8b38aeaf84561b5450ac6b4228a43300104e0ee119f04aa2d1.scope
    102      cgroup_device   multi                                          
