xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 567
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 551
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 544
cilium_host(7) clsact/egress cil_from_host-cilium_host id 539
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 581
lxc57ef9c7dbe1f(12) clsact/ingress cil_from_container-lxc57ef9c7dbe1f id 519
lxc1aa8bfe0ccbf(14) clsact/ingress cil_from_container-lxc1aa8bfe0ccbf id 533
lxcdaa21738e396(18) clsact/ingress cil_from_container-lxcdaa21738e396 id 644
lxc8562b45c8046(20) clsact/ingress cil_from_container-lxc8562b45c8046 id 3314
lxccb4feb6af8eb(22) clsact/ingress cil_from_container-lxccb4feb6af8eb id 3271
lxc8e4c2da844f1(24) clsact/ingress cil_from_container-lxc8e4c2da844f1 id 3333

flow_dissector:

netfilter:

