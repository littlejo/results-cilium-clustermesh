Endpoint ID: 187
Path: /sys/fs/bpf/tc/globals/cilium_policy_00187

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3586     34        0        
Allow    Ingress     1          ANY          NONE         disabled    114106   1307      0        
Allow    Egress      0          ANY          NONE         disabled    17469    191       0        


Endpoint ID: 209
Path: /sys/fs/bpf/tc/globals/cilium_policy_00209

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    374960   4360      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 287
Path: /sys/fs/bpf/tc/globals/cilium_policy_00287

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6080689   60218     0        
Allow    Ingress     1          ANY          NONE         disabled    5183188   54601     0        
Allow    Egress      0          ANY          NONE         disabled    5938410   59636     0        


Endpoint ID: 463
Path: /sys/fs/bpf/tc/globals/cilium_policy_00463

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1283
Path: /sys/fs/bpf/tc/globals/cilium_policy_01283

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1545
Path: /sys/fs/bpf/tc/globals/cilium_policy_01545

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2310     26        0        
Allow    Ingress     1          ANY          NONE         disabled    115597   1326      0        
Allow    Egress      0          ANY          NONE         disabled    18325    201       0        


Endpoint ID: 2105
Path: /sys/fs/bpf/tc/globals/cilium_policy_02105

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3592
Path: /sys/fs/bpf/tc/globals/cilium_policy_03592

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6235000   76911     0        
Allow    Ingress     1          ANY          NONE         disabled    59166     714       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


