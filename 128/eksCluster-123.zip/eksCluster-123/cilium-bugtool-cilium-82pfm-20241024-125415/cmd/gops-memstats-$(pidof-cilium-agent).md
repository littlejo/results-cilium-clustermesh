alloc: 72.17MB (75675032 bytes)
total-alloc: 3.04GB (3268747136 bytes)
sys: 227.32MB (238363988 bytes)
lookups: 0
mallocs: 74421371
frees: 73933491
heap-alloc: 72.17MB (75675032 bytes)
heap-sys: 182.91MB (191791104 bytes)
heap-idle: 61.51MB (64495616 bytes)
heap-in-use: 121.40MB (127295488 bytes)
heap-released: 5.54MB (5808128 bytes)
heap-objects: 487880
stack-in-use: 33.09MB (34701312 bytes)
stack-sys: 33.09MB (34701312 bytes)
stack-mspan-inuse: 2.00MB (2099840 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 975.20KB (998609 bytes)
gc-sys: 5.49MB (5760120 bytes)
next-gc: when heap-alloc >= 159.07MB (166799784 bytes)
last-gc: 2024-10-24 12:54:47.487682329 +0000 UTC
gc-pause-total: 11.87329ms
gc-pause: 103696
gc-pause-end: 1729774487487682329
num-gc: 97
num-forced-gc: 0
gc-cpu-fraction: 0.0006795660435500539
enable-gc: true
debug-gc: false
