[
  {
    "containers": [
      {
        "cgroup-id": 9814,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf8b3967_4f3b_4222_ac35_fbd5908ffeb5.slice/cri-containerd-3582a7f6bc57dd8b92fdd81b296ecb64211b4e3ec7d623d3e6d0c2e081b971ab.scope"
      }
    ],
    "ips": [
      "10.85.0.61"
    ],
    "name": "client-974f6c69d-8rvx4",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9898,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6be0b727_5fa6_486b_9067_80160985f0fa.slice/cri-containerd-caa0232e16f637c264989ec1f3b040d8a77d14287629dc50fbf07e6493656d54.scope"
      }
    ],
    "ips": [
      "10.85.0.79"
    ],
    "name": "client2-57cf4468f-xj4gk",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9058,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9032fe8_43ef_4688_a091_34e7fe6a9007.slice/cri-containerd-701f05706540a542ec1d4d85a65afa28fe5ec9a15ca942de287987f34c2fc431.scope"
      },
      {
        "cgroup-id": 9142,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9032fe8_43ef_4688_a091_34e7fe6a9007.slice/cri-containerd-b614f6edab12c7477bf1c0a542c4babf9634e6f7023751404961356049d4be1b.scope"
      },
      {
        "cgroup-id": 9226,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9032fe8_43ef_4688_a091_34e7fe6a9007.slice/cri-containerd-ec4ca52a7543b3857d807630a40e6db104861852be10571064665265b9c8bf07.scope"
      }
    ],
    "ips": [
      "10.85.0.236"
    ],
    "name": "clustermesh-apiserver-6bc686c6d9-q854b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7582,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2859fa59_eec3_470a_9f23_9f6712e740f4.slice/cri-containerd-7af3be4a1728679b50ce870e394427154ce6b4d751fea6e2b56356e2c0cf5732.scope"
      }
    ],
    "ips": [
      "10.85.0.84"
    ],
    "name": "coredns-cc6ccd49c-xqmmc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9982,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bf8a24_e7be_4c1a_8d6c_89e98c19f0fc.slice/cri-containerd-a3b74021ffd1e172df083178a0fc3dd7fc3571eaf0d03c9b10e8515b64006208.scope"
      },
      {
        "cgroup-id": 10066,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bf8a24_e7be_4c1a_8d6c_89e98c19f0fc.slice/cri-containerd-891140b5160fe834dea9cb58f6827b842b10de558173f4748ce4f8a92b398268.scope"
      }
    ],
    "ips": [
      "10.85.0.163"
    ],
    "name": "echo-same-node-86d9cc975c-9f5ld",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7666,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb7595dd_e2ff_4cfa_96f0_e8863dda3384.slice/cri-containerd-fa384963efb7433f73c5df2dfba5488aad2e4b1035830412d5664434348cec4d.scope"
      }
    ],
    "ips": [
      "10.85.0.132"
    ],
    "name": "coredns-cc6ccd49c-cxn2s",
    "namespace": "kube-system"
  }
]

