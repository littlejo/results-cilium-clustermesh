top - 12:54:25 up 31 min,  0 users,  load average: 0.31, 0.28, 0.16
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.3 us, 24.1 sy,  0.0 ni, 65.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    287.6 free,   1050.9 used,   2497.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2604.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 290776  78464 S   6.7   7.4   1:04.71 cilium-+
    394 root      20   0 1229744   8724   2864 S   0.0   0.2   0:03.87 cilium-+
   3299 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3300 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3310 root      20   0 1240432  15980  11100 S   0.0   0.4   0:00.02 cilium-+
   3317 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3318 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3368 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3386 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
