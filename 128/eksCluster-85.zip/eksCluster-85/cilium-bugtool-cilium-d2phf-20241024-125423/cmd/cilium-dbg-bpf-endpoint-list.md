IP ADDRESS         LOCAL ENDPOINT INFO
10.85.0.61:0       id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8   
10.85.0.79:0       id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC   
10.85.0.236:0      id=828   sec_id=5690958 flags=0x0000 ifindex=18  mac=DA:03:F6:A3:FC:4E nodemac=9E:B9:BB:AD:36:9E   
172.31.250.159:0   (localhost)                                                                                        
172.31.217.206:0   (localhost)                                                                                        
10.85.0.137:0      (localhost)                                                                                        
10.85.0.163:0      id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32   
10.85.0.132:0      id=3059  sec_id=5687169 flags=0x0000 ifindex=12  mac=AE:FD:21:15:40:DC nodemac=36:B0:4A:94:6D:C2   
10.85.0.109:0      id=669   sec_id=4     flags=0x0000 ifindex=10  mac=6E:C4:C6:5A:BD:A2 nodemac=D2:96:AD:9A:19:CB     
10.85.0.84:0       id=1863  sec_id=5687169 flags=0x0000 ifindex=14  mac=0E:12:EB:04:7A:23 nodemac=EA:C5:A9:A0:9B:E4   
