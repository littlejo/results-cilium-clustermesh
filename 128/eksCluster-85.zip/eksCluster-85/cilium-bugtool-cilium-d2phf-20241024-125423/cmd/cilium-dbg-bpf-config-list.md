KEY             VALUE
AgentLiveness   1942534421344
UTimeOffset     3378462017578125
