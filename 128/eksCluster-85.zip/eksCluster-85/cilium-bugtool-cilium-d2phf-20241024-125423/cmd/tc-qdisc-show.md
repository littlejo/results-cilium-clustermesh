qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxcb5f2d1a7971e root refcnt 2 
qdisc clsact ffff: dev lxcb5f2d1a7971e parent ffff:fff1 
qdisc noqueue 0: dev lxce379333a4632 root refcnt 2 
qdisc clsact ffff: dev lxce379333a4632 parent ffff:fff1 
qdisc noqueue 0: dev lxcbb402f817d75 root refcnt 2 
qdisc clsact ffff: dev lxcbb402f817d75 parent ffff:fff1 
qdisc noqueue 0: dev lxc32e8823f7903 root refcnt 2 
qdisc clsact ffff: dev lxc32e8823f7903 parent ffff:fff1 
qdisc noqueue 0: dev lxceed10328d7ad root refcnt 2 
qdisc clsact ffff: dev lxceed10328d7ad parent ffff:fff1 
qdisc noqueue 0: dev lxc7b1fe78fd26f root refcnt 2 
qdisc clsact ffff: dev lxc7b1fe78fd26f parent ffff:fff1 
