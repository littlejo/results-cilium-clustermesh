xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 575
ens6(5) clsact/ingress cil_from_netdev-ens6 id 585
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 571
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 523
lxcb5f2d1a7971e(12) clsact/ingress cil_from_container-lxcb5f2d1a7971e id 547
lxce379333a4632(14) clsact/ingress cil_from_container-lxce379333a4632 id 516
lxcbb402f817d75(18) clsact/ingress cil_from_container-lxcbb402f817d75 id 628
lxc32e8823f7903(20) clsact/ingress cil_from_container-lxc32e8823f7903 id 3294
lxceed10328d7ad(22) clsact/ingress cil_from_container-lxceed10328d7ad id 3346
lxc7b1fe78fd26f(24) clsact/ingress cil_from_container-lxc7b1fe78fd26f id 3343

flow_dissector:

netfilter:

