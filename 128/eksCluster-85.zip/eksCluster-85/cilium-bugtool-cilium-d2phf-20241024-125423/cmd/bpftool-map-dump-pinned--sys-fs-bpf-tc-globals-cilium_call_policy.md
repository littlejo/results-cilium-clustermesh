key: 7c 01 00 00  value: 11 0d 00 00
key: 9d 02 00 00  value: 0d 02 00 00
key: f2 02 00 00  value: dc 0c 00 00
key: 3c 03 00 00  value: 73 02 00 00
key: df 03 00 00  value: 15 0d 00 00
key: 47 07 00 00  value: 08 02 00 00
key: f3 0b 00 00  value: 24 02 00 00
Found 7 elements
