CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2859fa59_eec3_470a_9f23_9f6712e740f4.slice/cri-containerd-c5e9138cf7ec5d9b4673dfeb806ae22c6bfe91a8403e59303d58f333bbcb7628.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2859fa59_eec3_470a_9f23_9f6712e740f4.slice/cri-containerd-7af3be4a1728679b50ce870e394427154ce6b4d751fea6e2b56356e2c0cf5732.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc5de0f8c_d6c8_4959_8c2f_bafffe89feb2.slice/cri-containerd-63acef0e59abdb1cbd2d5cd3d1b66c650c0cf25b4fa0f8ccf7bbcf6b885cd85b.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc5de0f8c_d6c8_4959_8c2f_bafffe89feb2.slice/cri-containerd-61e3d9379af221fda371d651b1715b13dc7980e7c3a570a37a3bc2f821f6a0c1.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb7595dd_e2ff_4cfa_96f0_e8863dda3384.slice/cri-containerd-fa384963efb7433f73c5df2dfba5488aad2e4b1035830412d5664434348cec4d.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb7595dd_e2ff_4cfa_96f0_e8863dda3384.slice/cri-containerd-3823d9f1a935200b94b381d506377d10050df6aafa47e58798f1849350a3d6c0.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbd8857a_99e0_463d_84c2_bf9fd4f30d49.slice/cri-containerd-8b0a2719ac8432bacd9aa969a333ae668c015dd263893dd1a28570f445b395f3.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbd8857a_99e0_463d_84c2_bf9fd4f30d49.slice/cri-containerd-0ca11bae1abd440fbec538bbea8993c51440b6b22098f94c275124cb8ada96c6.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e75d628_ccd5_4190_b84a_f183585b6926.slice/cri-containerd-ccd324dbf0700621410ed7580a0b57d92e75fee132c59eaa4c74747e7d8d5289.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e75d628_ccd5_4190_b84a_f183585b6926.slice/cri-containerd-be7a2b8c0fc964a3819a5edea26c86e6f9d94500ab1d5bcdbb70410603de8362.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf8b3967_4f3b_4222_ac35_fbd5908ffeb5.slice/cri-containerd-4674dbf48955e639aac9fbc8965bcb11777ea0ef3eb6cc1d0652b91a2bbad3c9.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf8b3967_4f3b_4222_ac35_fbd5908ffeb5.slice/cri-containerd-3582a7f6bc57dd8b92fdd81b296ecb64211b4e3ec7d623d3e6d0c2e081b971ab.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6be0b727_5fa6_486b_9067_80160985f0fa.slice/cri-containerd-caa0232e16f637c264989ec1f3b040d8a77d14287629dc50fbf07e6493656d54.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6be0b727_5fa6_486b_9067_80160985f0fa.slice/cri-containerd-0ac06055449f332f9810c582819f9ba1421c1cb69c33276a728b205750cdfcb2.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9032fe8_43ef_4688_a091_34e7fe6a9007.slice/cri-containerd-701f05706540a542ec1d4d85a65afa28fe5ec9a15ca942de287987f34c2fc431.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9032fe8_43ef_4688_a091_34e7fe6a9007.slice/cri-containerd-ab8a13f7966cf8c539b2b1e4f52dd7bf5987739a4a4a72552046619db4bbe9bd.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9032fe8_43ef_4688_a091_34e7fe6a9007.slice/cri-containerd-ec4ca52a7543b3857d807630a40e6db104861852be10571064665265b9c8bf07.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9032fe8_43ef_4688_a091_34e7fe6a9007.slice/cri-containerd-b614f6edab12c7477bf1c0a542c4babf9634e6f7023751404961356049d4be1b.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4e3c046_510c_4a5a_9053_11cecddc95b3.slice/cri-containerd-d330b26a14a2a0bca07444d0483204b5e1fbc48904abeaa5734b35b07752beae.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4e3c046_510c_4a5a_9053_11cecddc95b3.slice/cri-containerd-a15ebb12ee9eb9bfff84921c18d4666af3071648c87da3addd312575d07b0798.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bf8a24_e7be_4c1a_8d6c_89e98c19f0fc.slice/cri-containerd-a3b74021ffd1e172df083178a0fc3dd7fc3571eaf0d03c9b10e8515b64006208.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bf8a24_e7be_4c1a_8d6c_89e98c19f0fc.slice/cri-containerd-891140b5160fe834dea9cb58f6827b842b10de558173f4748ce4f8a92b398268.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bf8a24_e7be_4c1a_8d6c_89e98c19f0fc.slice/cri-containerd-6ea0b9b91faf3e5086ae96cadcd167ce07cf7f774eae4f0016644f67202e6345.scope
    690      cgroup_device   multi                                          
