{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.057Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.070Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.121Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.124Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.169Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.704Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.707Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.757Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.758Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.789Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.058Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.076Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.172Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.192Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.208Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.695Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.710Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.756Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.782Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.791Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.021Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.029Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.061Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.085Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.119Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.703Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.727Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.747Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.787Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.789Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.820Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.029Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.046Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.103Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.124Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.185Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.664Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.672Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.700Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.713Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.751Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.766Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.791Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.991Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.997Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.049Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.052Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.095Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.516Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.526Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.567Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.579Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.605Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.827Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.834Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.879Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.921Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.981Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.356Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.394Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.404Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.451Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.462Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.490Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.687Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.693Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.758Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.761Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.805Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.224Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.228Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.261Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.264Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.296Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.560Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.593Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.618Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.817Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.840Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.269Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.282Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.322Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.333Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.360Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.586Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.592Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.645Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.671Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.686Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.158Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.188Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.210Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.228Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.263Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.274Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.472Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.482Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.531Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.532Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.584Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.968Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.970Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.052Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.055Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.086Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.237Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.249Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.310Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.326Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.352Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.612Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.648Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.653Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.691Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.714Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.987Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.991Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.004Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.036Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.726Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.729Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.765Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.771Z",
  "value": "id=754   sec_id=5664787 flags=0x0000 ifindex=20  mac=32:C1:C8:A3:F1:05 nodemac=F2:28:3B:BD:48:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.801Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.061Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.071Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.728Z",
  "value": "id=380   sec_id=5659256 flags=0x0000 ifindex=22  mac=3A:A1:6E:A2:93:83 nodemac=3A:56:BD:FE:81:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.733Z",
  "value": "id=991   sec_id=5652749 flags=0x0000 ifindex=24  mac=5E:56:1B:88:61:48 nodemac=62:BB:10:22:18:AC"
}

