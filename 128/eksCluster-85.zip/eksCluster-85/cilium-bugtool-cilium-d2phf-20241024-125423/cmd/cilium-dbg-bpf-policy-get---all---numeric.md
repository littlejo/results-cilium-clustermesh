Endpoint ID: 380
Path: /sys/fs/bpf/tc/globals/cilium_policy_00380

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 669
Path: /sys/fs/bpf/tc/globals/cilium_policy_00669

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6229386   76984     0        
Allow    Ingress     1          ANY          NONE         disabled    65180     786       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 754
Path: /sys/fs/bpf/tc/globals/cilium_policy_00754

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    380366   4436      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 828
Path: /sys/fs/bpf/tc/globals/cilium_policy_00828

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6104359   61769     0        
Allow    Ingress     1          ANY          NONE         disabled    6197770   64117     0        
Allow    Egress      0          ANY          NONE         disabled    7466858   73074     0        


Endpoint ID: 991
Path: /sys/fs/bpf/tc/globals/cilium_policy_00991

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1863
Path: /sys/fs/bpf/tc/globals/cilium_policy_01863

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2376     27        0        
Allow    Ingress     1          ANY          NONE         disabled    135662   1556      0        
Allow    Egress      0          ANY          NONE         disabled    18559    204       0        


Endpoint ID: 3059
Path: /sys/fs/bpf/tc/globals/cilium_policy_03059

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3520     33        0        
Allow    Ingress     1          ANY          NONE         disabled    135747   1553      0        
Allow    Egress      0          ANY          NONE         disabled    18442    203       0        


Endpoint ID: 4049
Path: /sys/fs/bpf/tc/globals/cilium_policy_04049

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


