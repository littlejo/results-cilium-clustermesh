 12:54:25 up 31 min,  0 users,  load average: 0.31, 0.28, 0.16
