1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:22:c1:5f:00:3b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.217.206/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3500sec preferred_lft 3500sec
    inet6 fe80::822:c1ff:fe5f:3b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:3d:1d:f4:4c:a1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.250.159/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::83d:1dff:fef4:4ca1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:c6:16:98:9c:eb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::38c6:16ff:fe98:9ceb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:d6:7f:6c:9e:f6 brd ff:ff:ff:ff:ff:ff
    inet 10.85.0.137/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::20d6:7fff:fe6c:9ef6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d6:33:ca:95:34:ef brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d433:caff:fe95:34ef/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:96:ad:9a:19:cb brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d096:adff:fe9a:19cb/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb5f2d1a7971e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:b0:4a:94:6d:c2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::34b0:4aff:fe94:6dc2/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce379333a4632@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:c5:a9:a0:9b:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::e8c5:a9ff:fea0:9be4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcbb402f817d75@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:b9:bb:ad:36:9e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9cb9:bbff:fead:369e/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc32e8823f7903@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:28:3b:bd:48:32 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f028:3bff:febd:4832/64 scope link 
       valid_lft forever preferred_lft forever
22: lxceed10328d7ad@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:56:bd:fe:81:c8 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::3856:bdff:fefe:81c8/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc7b1fe78fd26f@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:bb:10:22:18:ac brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::60bb:10ff:fe22:18ac/64 scope link 
       valid_lft forever preferred_lft forever
