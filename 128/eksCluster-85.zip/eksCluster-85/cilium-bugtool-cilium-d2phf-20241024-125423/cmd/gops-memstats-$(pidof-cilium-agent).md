alloc: 93.35MB (97888712 bytes)
total-alloc: 3.24GB (3480170352 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 77535786
frees: 76859351
heap-alloc: 93.35MB (97888712 bytes)
heap-sys: 175.30MB (183812096 bytes)
heap-idle: 37.12MB (38928384 bytes)
heap-in-use: 138.17MB (144883712 bytes)
heap-released: 4.51MB (4726784 bytes)
heap-objects: 676435
stack-in-use: 36.66MB (38436864 bytes)
stack-sys: 36.66MB (38436864 bytes)
stack-mspan-inuse: 2.17MB (2280320 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 946.47KB (969185 bytes)
gc-sys: 5.52MB (5788720 bytes)
next-gc: when heap-alloc >= 149.98MB (157266104 bytes)
last-gc: 2024-10-24 12:54:49.640701371 +0000 UTC
gc-pause-total: 13.856205ms
gc-pause: 63173
gc-pause-end: 1729774489640701371
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0006988337203989201
enable-gc: true
debug-gc: false
