USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3318  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3317  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3310  0.0  0.4 1240432 15980 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3357  0.0  0.0   6408  1632 ?        R    12:54   0:00  \_ ps auxfw
root        3358  0.0  0.0      0     0 ?        Z    12:54   0:00  \_ [hostname] <defunct>
root        3300  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3299  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.5  7.4 1539060 290776 ?      Ssl  12:30   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 8724 ?        Sl   12:30   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
