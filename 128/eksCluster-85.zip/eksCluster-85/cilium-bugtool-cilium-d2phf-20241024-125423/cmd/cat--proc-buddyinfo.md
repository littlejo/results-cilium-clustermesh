Node 0, zone      DMA     28      6     29     44     18      6      4      3      1      2     38 
Node 0, zone   Normal    154     30      4      2     20     16     11      6      4      4      5 
