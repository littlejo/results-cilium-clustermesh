USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3231  0.0  0.4 1240432 16208 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3262  0.0  0.0   6408  1644 ?        R    12:54   0:00  \_ ps auxfw
root           1  4.1  7.4 1539060 290752 ?      Ssl  12:29   1:03 cilium-agent --config-dir=/tmp/cilium/config-map
root         410  0.2  0.2 1229744 9932 ?        Sl   12:29   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
