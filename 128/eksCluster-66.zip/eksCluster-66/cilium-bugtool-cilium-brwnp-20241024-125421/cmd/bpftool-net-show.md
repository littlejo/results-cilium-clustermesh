xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 551
ens6(5) clsact/ingress cil_from_netdev-ens6 id 561
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 539
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 533
cilium_host(7) clsact/egress cil_from_host-cilium_host id 537
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 570
lxc606d1e199907(12) clsact/ingress cil_from_container-lxc606d1e199907 id 531
lxc6c094534c1ca(14) clsact/ingress cil_from_container-lxc6c094534c1ca id 564
lxc0641426a71cd(18) clsact/ingress cil_from_container-lxc0641426a71cd id 639
lxc634be8eb1e64(20) clsact/ingress cil_from_container-lxc634be8eb1e64 id 3338
lxc99b4dc499d4a(22) clsact/ingress cil_from_container-lxc99b4dc499d4a id 3336
lxc89aaeac67be9(24) clsact/ingress cil_from_container-lxc89aaeac67be9 id 3298

flow_dissector:

netfilter:

