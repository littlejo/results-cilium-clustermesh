Endpoint ID: 208
Path: /sys/fs/bpf/tc/globals/cilium_policy_00208

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 827
Path: /sys/fs/bpf/tc/globals/cilium_policy_00827

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3668     37        0        
Allow    Ingress     1          ANY          NONE         disabled    146611   1682      0        
Allow    Egress      0          ANY          NONE         disabled    19263    213       0        


Endpoint ID: 1119
Path: /sys/fs/bpf/tc/globals/cilium_policy_01119

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6109456   60820     0        
Allow    Ingress     1          ANY          NONE         disabled    5166294   54388     0        
Allow    Egress      0          ANY          NONE         disabled    6244323   62281     0        


Endpoint ID: 1421
Path: /sys/fs/bpf/tc/globals/cilium_policy_01421

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2228     23        0        
Allow    Ingress     1          ANY          NONE         disabled    145780   1674      0        
Allow    Egress      0          ANY          NONE         disabled    19157    213       0        


Endpoint ID: 1645
Path: /sys/fs/bpf/tc/globals/cilium_policy_01645

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1979
Path: /sys/fs/bpf/tc/globals/cilium_policy_01979

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    383273   4483      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3379
Path: /sys/fs/bpf/tc/globals/cilium_policy_03379

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6212816   76912     0        
Allow    Ingress     1          ANY          NONE         disabled    64854     786       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3462
Path: /sys/fs/bpf/tc/globals/cilium_policy_03462

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


