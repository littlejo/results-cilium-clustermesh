CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod64c337c9_980d_4a37_8c4f_29b38e338d4e.slice/cri-containerd-0340f3cb440af15541d7c13f4c26f1fc9f1398392848bf931a0846469b6c8fa4.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod64c337c9_980d_4a37_8c4f_29b38e338d4e.slice/cri-containerd-cd2d66732aff9b13b8170d0efa221bcf378e5d38d83e2f1686a17673baff43fc.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd71e08ab_5c8c_4842_93de_89b97fb6b0bc.slice/cri-containerd-eaa81c132cecbb68374adb6aa279d20a3eceef8ec3cd357dcaafaea55076fad2.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd71e08ab_5c8c_4842_93de_89b97fb6b0bc.slice/cri-containerd-1ce999d292392cf99560bee7092f3937603640d5c08cf18c5fe4df2e85560693.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb856ade1_d123_42da_aa4f_01cbb47b337a.slice/cri-containerd-cf5fbe32ae3646c083a411640b86251f976ac97388a4d7f495ec75b171e566e6.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb856ade1_d123_42da_aa4f_01cbb47b337a.slice/cri-containerd-9c52df2eda2ae73f29808f4759b99d1249d49ee23cf91b2041199479eee9dc7a.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf311b8c_207e_43d5_a984_b158fc6f957a.slice/cri-containerd-74c5858490bfdb6df049c713b0767f60c13cdc266c8ad3af7ba834b861b2f568.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf311b8c_207e_43d5_a984_b158fc6f957a.slice/cri-containerd-c3dc413b3a8655b7517cfa2f5971be1d73601ef3fcd0bffbf74e7f16f33f3fce.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ffa90af_fe05_480c_940c_1cbb0bb8eb90.slice/cri-containerd-a16a053503344b6529e51ecce05757b38fe1670d94029fdef0b33e92ff940eeb.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ffa90af_fe05_480c_940c_1cbb0bb8eb90.slice/cri-containerd-6b54ded9ad7681493f87188ebb0f7f3570328b0ac6f577c34f86eb7dcdfa62e3.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ffa90af_fe05_480c_940c_1cbb0bb8eb90.slice/cri-containerd-a7aa0c5161306a758531cb3f246e0c21fb3184f8369b79ec48946767f8d42e39.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0ebc309_f42a_4eb9_86b8_a890a42a8ec4.slice/cri-containerd-18ec131e875adf9618f3c451e8e5ea65f5fa50692eec29680ce4c6ba0038cb41.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0ebc309_f42a_4eb9_86b8_a890a42a8ec4.slice/cri-containerd-b054ae67f1a21b97a398eab302afab480d7ea48520dcb215599e1c3492fac885.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3812122_c640_4ed2_827b_4628d5f3d194.slice/cri-containerd-d34677f0698da0b0c27ca00f8f674185ad9d31a09e4d999a02b383fd90642bec.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3812122_c640_4ed2_827b_4628d5f3d194.slice/cri-containerd-d0f3e21ac1aaafe41312c862453af6733d33644f5b5e571c30df331621532a92.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aecf876_502e_4ea4_a7c2_620725292d48.slice/cri-containerd-b63e68bf7bb27254d572e54aead4160c3c6549fde1a824d25329b0d7205a85f3.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aecf876_502e_4ea4_a7c2_620725292d48.slice/cri-containerd-e6be96390b7458875aeb190d1d7f2f11c89653b706e5e2380cdc16905c94fec7.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc169ce23_adf8_4f86_b8b5_58cefec011d5.slice/cri-containerd-13af55335657dda120ecee936a3fe23d1ab8ba58142c354dbfcd59005494c93a.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc169ce23_adf8_4f86_b8b5_58cefec011d5.slice/cri-containerd-4f80dda684bfe59c38e9bcf9ea61052e3c16040f3e0517721611fedfb389b434.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc169ce23_adf8_4f86_b8b5_58cefec011d5.slice/cri-containerd-28f86301c086e17b158615d9a14e547f37bbe44b76a5c4278ea84fb8be7deb95.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc169ce23_adf8_4f86_b8b5_58cefec011d5.slice/cri-containerd-415ff780d555f911c72afd773bc3acf4e170f979209fca84989cc820c7e56581.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeae595a4_aea2_4ee0_bf2d_11b6122bdbba.slice/cri-containerd-7a3531f2e8dc3737721f3d3deb31f72f0f6f55196258f7e3b4773dda05b4c40d.scope
    712      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeae595a4_aea2_4ee0_bf2d_11b6122bdbba.slice/cri-containerd-546bdafde6489b3f4e631cbb6f4101d1b6a668c6e43d1f10498123698c6badec.scope
    728      cgroup_device   multi                                          
