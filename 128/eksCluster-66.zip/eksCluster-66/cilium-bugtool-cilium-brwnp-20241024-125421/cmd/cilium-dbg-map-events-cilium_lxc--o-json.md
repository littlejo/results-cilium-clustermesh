{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.607Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.642Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.194Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.203Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.261Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.276Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.297Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.534Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.545Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.629Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.641Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.684Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.272Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.287Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.331Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.336Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.368Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.564Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.571Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.644Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.659Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.686Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.195Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.203Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.263Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.332Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.345Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.375Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.393Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.592Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.604Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.667Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.715Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.720Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.215Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.216Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.274Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.282Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.324Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.338Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.366Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.609Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.613Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.678Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.690Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.726Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.110Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.132Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.187Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.204Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.229Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.491Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.525Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.584Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.588Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.622Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.953Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.956Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.023Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.028Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.058Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.267Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.275Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.335Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.337Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.376Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.739Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.769Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.779Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.804Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.820Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.848Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.117Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.118Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.166Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.209Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.229Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.752Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.759Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.824Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.843Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.861Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.032Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.039Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.088Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.133Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.143Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.520Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.549Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.561Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.562Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.601Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.603Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.822Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.836Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.886Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.906Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.928Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.231Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.285Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.287Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.329Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.357Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.420Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.630Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.653Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.693Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.704Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.744Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.011Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.045Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.075Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.094Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.115Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.394Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.397Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.404Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.411Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.435Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.104Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.107Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.148Z",
  "value": "id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.152Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.185Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.460Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.475Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.111Z",
  "value": "id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.120Z",
  "value": "id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C"
}

