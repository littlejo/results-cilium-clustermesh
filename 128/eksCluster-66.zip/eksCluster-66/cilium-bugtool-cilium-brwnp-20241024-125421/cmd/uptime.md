 12:54:22 up 32 min,  0 users,  load average: 0.48, 0.68, 0.41
