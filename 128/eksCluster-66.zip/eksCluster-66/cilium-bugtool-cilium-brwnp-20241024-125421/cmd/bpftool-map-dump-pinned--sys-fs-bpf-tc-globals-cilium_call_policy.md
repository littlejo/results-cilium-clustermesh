key: d0 00 00 00  value: 14 0d 00 00
key: 3b 03 00 00  value: 22 02 00 00
key: 5f 04 00 00  value: 82 02 00 00
key: 8d 05 00 00  value: 01 02 00 00
key: 6d 06 00 00  value: 09 0d 00 00
key: bb 07 00 00  value: d7 0c 00 00
key: 33 0d 00 00  value: 40 02 00 00
Found 7 elements
