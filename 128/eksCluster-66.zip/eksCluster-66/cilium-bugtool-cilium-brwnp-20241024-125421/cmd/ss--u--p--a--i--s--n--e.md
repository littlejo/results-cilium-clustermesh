Total: 570
TCP:   3253 (estab 293, closed 2941, orphaned 0, timewait 2479)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  312       303       9        
INET	  322       309       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32455 sk:adf cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15532 sk:ae0 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                  172.31.169.129%ens5:68         0.0.0.0:*    uid:192 ino:116912 sk:ae1 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                            127.0.0.1:39065      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=26)) ino:31374 sk:ae2 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32454 sk:ae3 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15533 sk:ae4 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::4cf:23ff:fe1a:576f]%ens5:546           [::]:*    uid:192 ino:15732 sk:ae5 cgroup:unreachable:bd0 v6only:1 <->                   
