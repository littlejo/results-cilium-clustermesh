IP ADDRESS         LOCAL ENDPOINT INFO
10.66.0.133:0      id=827   sec_id=4411665 flags=0x0000 ifindex=14  mac=D6:71:E1:B1:6F:3F nodemac=C2:7B:16:F9:1E:DA   
10.66.0.177:0      id=1645  sec_id=4415538 flags=0x0000 ifindex=20  mac=B2:B2:98:7E:9C:41 nodemac=62:94:8C:C5:28:96   
172.31.132.191:0   (localhost)                                                                                        
172.31.169.129:0   (localhost)                                                                                        
10.66.0.88:0       id=1979  sec_id=4450445 flags=0x0000 ifindex=24  mac=D6:57:D8:78:51:A7 nodemac=9E:D8:4F:94:DC:1F   
10.66.0.77:0       id=3379  sec_id=4     flags=0x0000 ifindex=10  mac=92:09:01:9A:45:CA nodemac=8E:EE:2A:BB:B1:65     
10.66.0.61:0       id=1119  sec_id=4418009 flags=0x0000 ifindex=18  mac=4E:A2:77:B4:38:E8 nodemac=E6:E0:85:FD:7C:27   
10.66.0.45:0       id=1421  sec_id=4411665 flags=0x0000 ifindex=12  mac=1E:77:37:04:67:8A nodemac=CA:A8:4C:AF:B2:7D   
10.66.0.229:0      (localhost)                                                                                        
10.66.0.214:0      id=208   sec_id=4394637 flags=0x0000 ifindex=22  mac=B6:84:74:19:C8:46 nodemac=EA:18:31:91:27:5C   
