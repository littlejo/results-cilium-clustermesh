KEY             VALUE
AgentLiveness   1964360875551
UTimeOffset     3378461970703125
