alloc: 104.47MB (109543000 bytes)
total-alloc: 3.09GB (3312588424 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75183890
frees: 74063217
heap-alloc: 104.47MB (109543000 bytes)
heap-sys: 172.60MB (180985856 bytes)
heap-idle: 46.25MB (48496640 bytes)
heap-in-use: 126.35MB (132489216 bytes)
heap-released: 6.34MB (6651904 bytes)
heap-objects: 1120673
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.10MB (2197440 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 999.43KB (1023417 bytes)
gc-sys: 5.51MB (5774456 bytes)
next-gc: when heap-alloc >= 151.19MB (158535848 bytes)
last-gc: 2024-10-24 12:54:25.152210899 +0000 UTC
gc-pause-total: 11.22389ms
gc-pause: 1557606
gc-pause-end: 1729774465152210899
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005357078414679603
enable-gc: true
debug-gc: false
