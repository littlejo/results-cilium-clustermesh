1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:cf:23:1a:57:6f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.169.129/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3476sec preferred_lft 3476sec
    inet6 fe80::4cf:23ff:fe1a:576f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d1:4a:b9:6b:df brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.132.191/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d1:4aff:feb9:6bdf/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:6c:80:53:e0:90 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c6c:80ff:fe53:e090/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:55:c1:81:ef:04 brd ff:ff:ff:ff:ff:ff
    inet 10.66.0.229/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6055:c1ff:fe81:ef04/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0e:41:2b:04:aa:da brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c41:2bff:fe04:aada/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:ee:2a:bb:b1:65 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8cee:2aff:febb:b165/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc606d1e199907@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:a8:4c:af:b2:7d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c8a8:4cff:feaf:b27d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6c094534c1ca@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:7b:16:f9:1e:da brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c07b:16ff:fef9:1eda/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0641426a71cd@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:e0:85:fd:7c:27 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e4e0:85ff:fefd:7c27/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc634be8eb1e64@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:94:8c:c5:28:96 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6094:8cff:fec5:2896/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc99b4dc499d4a@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:18:31:91:27:5c brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::e818:31ff:fe91:275c/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc89aaeac67be9@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:d8:4f:94:dc:1f brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::9cd8:4fff:fe94:dc1f/64 scope link 
       valid_lft forever preferred_lft forever
