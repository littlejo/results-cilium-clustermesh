Node 0, zone      DMA    306    123     28     42     15      8     10      3      1      3     41 
Node 0, zone   Normal    117      5      3      4      2      4     17      5      2      2      7 
