[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf311b8c_207e_43d5_a984_b158fc6f957a.slice/cri-containerd-c3dc413b3a8655b7517cfa2f5971be1d73601ef3fcd0bffbf74e7f16f33f3fce.scope"
      }
    ],
    "ips": [
      "10.66.0.45"
    ],
    "name": "coredns-cc6ccd49c-4b8rn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeae595a4_aea2_4ee0_bf2d_11b6122bdbba.slice/cri-containerd-546bdafde6489b3f4e631cbb6f4101d1b6a668c6e43d1f10498123698c6badec.scope"
      }
    ],
    "ips": [
      "10.66.0.177"
    ],
    "name": "client-974f6c69d-nfrtg",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod64c337c9_980d_4a37_8c4f_29b38e338d4e.slice/cri-containerd-0340f3cb440af15541d7c13f4c26f1fc9f1398392848bf931a0846469b6c8fa4.scope"
      }
    ],
    "ips": [
      "10.66.0.133"
    ],
    "name": "coredns-cc6ccd49c-nvp2m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3812122_c640_4ed2_827b_4628d5f3d194.slice/cri-containerd-d34677f0698da0b0c27ca00f8f674185ad9d31a09e4d999a02b383fd90642bec.scope"
      }
    ],
    "ips": [
      "10.66.0.214"
    ],
    "name": "client2-57cf4468f-6bx52",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc169ce23_adf8_4f86_b8b5_58cefec011d5.slice/cri-containerd-28f86301c086e17b158615d9a14e547f37bbe44b76a5c4278ea84fb8be7deb95.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc169ce23_adf8_4f86_b8b5_58cefec011d5.slice/cri-containerd-415ff780d555f911c72afd773bc3acf4e170f979209fca84989cc820c7e56581.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc169ce23_adf8_4f86_b8b5_58cefec011d5.slice/cri-containerd-13af55335657dda120ecee936a3fe23d1ab8ba58142c354dbfcd59005494c93a.scope"
      }
    ],
    "ips": [
      "10.66.0.61"
    ],
    "name": "clustermesh-apiserver-5f87d69ff6-gt4k4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ffa90af_fe05_480c_940c_1cbb0bb8eb90.slice/cri-containerd-a16a053503344b6529e51ecce05757b38fe1670d94029fdef0b33e92ff940eeb.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ffa90af_fe05_480c_940c_1cbb0bb8eb90.slice/cri-containerd-a7aa0c5161306a758531cb3f246e0c21fb3184f8369b79ec48946767f8d42e39.scope"
      }
    ],
    "ips": [
      "10.66.0.88"
    ],
    "name": "echo-same-node-86d9cc975c-xl6fk",
    "namespace": "cilium-test-1"
  }
]

