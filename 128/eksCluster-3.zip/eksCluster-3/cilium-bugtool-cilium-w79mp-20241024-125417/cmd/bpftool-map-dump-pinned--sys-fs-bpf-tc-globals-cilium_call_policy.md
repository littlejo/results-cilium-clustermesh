key: 21 01 00 00  value: 1c 02 00 00
key: a7 01 00 00  value: 14 02 00 00
key: d1 07 00 00  value: 15 0d 00 00
key: 45 09 00 00  value: 18 0d 00 00
key: a7 09 00 00  value: 77 02 00 00
key: 51 0c 00 00  value: 04 02 00 00
key: ff 0d 00 00  value: de 0c 00 00
Found 7 elements
