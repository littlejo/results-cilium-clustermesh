[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod301878bd_5138_4968_8257_fc71f4c328ac.slice/cri-containerd-807af12fe50045e756619f0c9dea30b79e286f9fa2c9db1aa969c9703adf19e1.scope"
      }
    ],
    "ips": [
      "10.3.0.53"
    ],
    "name": "coredns-cc6ccd49c-tg86c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f9802f2_a945_4216_8459_158935c51f41.slice/cri-containerd-8cbfaa909f724c2895f0f4d1932b450a8691c6a6093811c198299a0c1a187e0e.scope"
      }
    ],
    "ips": [
      "10.3.0.77"
    ],
    "name": "client-974f6c69d-g8hrq",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2fe4d7af_2795_4a69_9e9e_9f2b62ced06b.slice/cri-containerd-630878fc386f2d7496330d16588ed7ce6cba6393f9539f968bf05ebd8f14c89c.scope"
      },
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2fe4d7af_2795_4a69_9e9e_9f2b62ced06b.slice/cri-containerd-d3f268383bd237d90d9b31e39973863b8afbae362bbe8f5e789b9e5d827a79ff.scope"
      }
    ],
    "ips": [
      "10.3.0.75"
    ],
    "name": "echo-same-node-86d9cc975c-hhnsr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fbca3c7_0dbe_4225_ab3e_b78dfd3cfb81.slice/cri-containerd-d2a3d9be5ecc4a561f4e7443af143c9b19c59d49b47b849587e85bdad330aa37.scope"
      }
    ],
    "ips": [
      "10.3.0.168"
    ],
    "name": "coredns-cc6ccd49c-hzxnx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5636336_582b_4f9f_b0fd_c3ba747ea892.slice/cri-containerd-5627826e8651a5ad665c40328e27a2c354815a93150f1d84cf07a67ca4abf5b8.scope"
      }
    ],
    "ips": [
      "10.3.0.135"
    ],
    "name": "client2-57cf4468f-88bsc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod25acbe0f_11df_46f2_8e27_97def387a872.slice/cri-containerd-20abeeb2a32a4d1e37bb896e9223eeca80ca2892bded9963f1757bc304782bd0.scope"
      },
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod25acbe0f_11df_46f2_8e27_97def387a872.slice/cri-containerd-db714046664467b09ae7f9af43387ccc9a58f6573df9747e4d870c2a0725f2c8.scope"
      },
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod25acbe0f_11df_46f2_8e27_97def387a872.slice/cri-containerd-31e3d4743e033ac3a409ac0fb0b52552a4976d94c5a4c0857f16143054d187eb.scope"
      }
    ],
    "ips": [
      "10.3.0.23"
    ],
    "name": "clustermesh-apiserver-68cbdd477f-2pmfm",
    "namespace": "kube-system"
  }
]

