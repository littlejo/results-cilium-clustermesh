alloc: 132.13MB (138552568 bytes)
total-alloc: 3.11GB (3341285824 bytes)
sys: 227.07MB (238101844 bytes)
lookups: 0
mallocs: 75342706
frees: 74029677
heap-alloc: 132.13MB (138552568 bytes)
heap-sys: 180.54MB (189308928 bytes)
heap-idle: 28.62MB (30007296 bytes)
heap-in-use: 151.92MB (159301632 bytes)
heap-released: 5.84MB (6127616 bytes)
heap-objects: 1313029
stack-in-use: 35.44MB (37158912 bytes)
stack-sys: 35.44MB (37158912 bytes)
stack-mspan-inuse: 2.33MB (2445760 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 729.17KB (746665 bytes)
gc-sys: 5.50MB (5764168 bytes)
next-gc: when heap-alloc >= 158.39MB (166085224 bytes)
last-gc: 2024-10-24 12:54:18.318856102 +0000 UTC
gc-pause-total: 12.708082ms
gc-pause: 321994
gc-pause-end: 1729774458318856102
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.0006024685354592355
enable-gc: true
debug-gc: false
