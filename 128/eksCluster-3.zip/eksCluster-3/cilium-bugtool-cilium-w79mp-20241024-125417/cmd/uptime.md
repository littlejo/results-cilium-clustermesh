 12:54:18 up 34 min,  0 users,  load average: 0.40, 0.46, 0.27
