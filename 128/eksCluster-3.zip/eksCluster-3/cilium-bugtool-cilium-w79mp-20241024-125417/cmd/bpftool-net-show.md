xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 572
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 560
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 536
lxc0437ecfab5b5(12) clsact/ingress cil_from_container-lxc0437ecfab5b5 id 520
lxc68cae2cde3e7(14) clsact/ingress cil_from_container-lxc68cae2cde3e7 id 500
lxc04ae6f46339b(18) clsact/ingress cil_from_container-lxc04ae6f46339b id 628
lxcdc07bee00e16(20) clsact/ingress cil_from_container-lxcdc07bee00e16 id 3350
lxca46c7b292bd2(22) clsact/ingress cil_from_container-lxca46c7b292bd2 id 3341
lxc60f9b914b0c3(24) clsact/ingress cil_from_container-lxc60f9b914b0c3 id 3293

flow_dissector:

netfilter:

