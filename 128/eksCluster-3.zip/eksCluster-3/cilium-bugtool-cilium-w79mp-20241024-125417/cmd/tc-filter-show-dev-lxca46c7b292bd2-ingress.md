filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca46c7b292bd2 direct-action not_in_hw id 3341 tag a8ed77542ad4740f jited 
