USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3135  0.0  0.4 1240432 16352 ?       Dsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3153  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3154  0.0  0.4 1240432 16352 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3121  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3103  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3101  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3100  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root           1  4.5  7.4 1538804 293852 ?      Ssl  12:24   1:20 cilium-agent --config-dir=/tmp/cilium/config-map
root         404  0.2  0.2 1229744 9024 ?        Sl   12:24   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
