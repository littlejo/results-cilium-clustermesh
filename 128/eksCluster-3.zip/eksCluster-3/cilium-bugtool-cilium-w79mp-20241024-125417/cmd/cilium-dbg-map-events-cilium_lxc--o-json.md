{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.065Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.099Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.153Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.160Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.205Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.842Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.856Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.904Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.934Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.975Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.255Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.258Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.326Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.361Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.389Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.071Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.084Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.130Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.135Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.169Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.434Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.438Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.499Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.573Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.609Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.218Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.227Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.246Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.295Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.318Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.352Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.375Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.570Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.597Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.656Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.668Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.711Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.296Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.331Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.361Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.392Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.432Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.438Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.696Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.744Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.762Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.847Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.849Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.235Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.292Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.298Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.353Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.368Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.397Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.642Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.653Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.739Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.757Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.792Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.257Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.271Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.342Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.347Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.384Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.617Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.653Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.686Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.718Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.739Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.217Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.239Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.316Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.348Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.374Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.602Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.602Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.684Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.723Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.737Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.165Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.175Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.224Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.225Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.281Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.513Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.543Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.597Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.619Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.644Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.030Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.093Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.093Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.151Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.171Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.195Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.448Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.449Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.619Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.620Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.658Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.899Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.903Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.956Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.968Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.010Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.267Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.295Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.344Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.384Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.392Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.761Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.766Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.810Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.836Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.861Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.133Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.134Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.154Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.184Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.869Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.873Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.924Z",
  "value": "id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.962Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.021Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.273Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.293Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.025Z",
  "value": "id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.040Z",
  "value": "id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF"
}

