REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     129875    10498883    677    bpf_overlay.c
Interface                   INGRESS     666706    247534569   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      128911    10440274    53     encap.h
Success                     EGRESS      154458    20075919    1308   bpf_lxc.c
Success                     EGRESS      53354     4323161     1694   bpf_host.c
Success                     EGRESS      616       159025      86     l3.h
Success                     INGRESS     177138    20514601    86     l3.h
Success                     INGRESS     254780    26882490    235    trace.h
Unsupported L3 protocol     EGRESS      72        5420        1492   bpf_lxc.c
