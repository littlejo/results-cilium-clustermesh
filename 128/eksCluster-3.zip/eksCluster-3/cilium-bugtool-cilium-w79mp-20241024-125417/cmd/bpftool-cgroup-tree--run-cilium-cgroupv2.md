CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod301878bd_5138_4968_8257_fc71f4c328ac.slice/cri-containerd-b976125084ac2f6b8cea77dabe10b951d9537d02182d0320b2fd66709c2e4b05.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod301878bd_5138_4968_8257_fc71f4c328ac.slice/cri-containerd-807af12fe50045e756619f0c9dea30b79e286f9fa2c9db1aa969c9703adf19e1.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fbca3c7_0dbe_4225_ab3e_b78dfd3cfb81.slice/cri-containerd-a0393bb068c74a9cf39937ddf8cb7870985298b6f9c4e5440e5694b2cb96478f.scope
    525      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fbca3c7_0dbe_4225_ab3e_b78dfd3cfb81.slice/cri-containerd-d2a3d9be5ecc4a561f4e7443af143c9b19c59d49b47b849587e85bdad330aa37.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod52464a0f_ab39_41c8_bb92_bab166539d04.slice/cri-containerd-18f69406b16433db01350059f68bbc38b9c39a3dbf497859d6043558033a6203.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod52464a0f_ab39_41c8_bb92_bab166539d04.slice/cri-containerd-a98f5e0ea10248dd57782ece4d0c8b08ecd2f3ca7bd654ce212c576f1c5a7571.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ca3b3e2_acd0_4700_ae90_0e031c7d5d2a.slice/cri-containerd-9f27034fe7c7390e93288c4a689715eed93c2bb70c61554b52fad8691b3575c7.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ca3b3e2_acd0_4700_ae90_0e031c7d5d2a.slice/cri-containerd-da48ed3587a38d540c0303684324747ff509febfb4b4a6eedc683114c4639335.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56ffdfaa_47d4_483e_ac10_10b0611d9715.slice/cri-containerd-e3aa955d9d28b8802c8795eaf77463db726ed7e196c025dc1252a1bd7e613dc9.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56ffdfaa_47d4_483e_ac10_10b0611d9715.slice/cri-containerd-d0974af807e73012e721e9dc4dee09c6d2ff0de38396966a66304c82ff412069.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f9802f2_a945_4216_8459_158935c51f41.slice/cri-containerd-b0b92ce750ef055faf6a0e0c0ed5016e46316c0e4ff0f13213de37c5861f28fa.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f9802f2_a945_4216_8459_158935c51f41.slice/cri-containerd-8cbfaa909f724c2895f0f4d1932b450a8691c6a6093811c198299a0c1a187e0e.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2fe4d7af_2795_4a69_9e9e_9f2b62ced06b.slice/cri-containerd-d3f268383bd237d90d9b31e39973863b8afbae362bbe8f5e789b9e5d827a79ff.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2fe4d7af_2795_4a69_9e9e_9f2b62ced06b.slice/cri-containerd-bd8a7df730ad1fd91f1657293007ec326e87bd61ce9fff928b040fafba6d0549.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2fe4d7af_2795_4a69_9e9e_9f2b62ced06b.slice/cri-containerd-630878fc386f2d7496330d16588ed7ce6cba6393f9539f968bf05ebd8f14c89c.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbbaf71d_e517_47c4_a184_7dfa27a26b48.slice/cri-containerd-319245bd235dd49f7fe40f1757625ccc095ffddf7acc2be50d0dbcf62ca4da60.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbbaf71d_e517_47c4_a184_7dfa27a26b48.slice/cri-containerd-46c7cb0d295ca355e0dd6ff228b691ef864cdf79d2ed41f7abf95b9c3916bbc8.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5636336_582b_4f9f_b0fd_c3ba747ea892.slice/cri-containerd-1c5fb07abac2fb12d217cff966222c790fbea0d3d04163942b59f3eac379b5b3.scope
    676      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5636336_582b_4f9f_b0fd_c3ba747ea892.slice/cri-containerd-5627826e8651a5ad665c40328e27a2c354815a93150f1d84cf07a67ca4abf5b8.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod25acbe0f_11df_46f2_8e27_97def387a872.slice/cri-containerd-31e3d4743e033ac3a409ac0fb0b52552a4976d94c5a4c0857f16143054d187eb.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod25acbe0f_11df_46f2_8e27_97def387a872.slice/cri-containerd-20abeeb2a32a4d1e37bb896e9223eeca80ca2892bded9963f1757bc304782bd0.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod25acbe0f_11df_46f2_8e27_97def387a872.slice/cri-containerd-db714046664467b09ae7f9af43387ccc9a58f6573df9747e4d870c2a0725f2c8.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod25acbe0f_11df_46f2_8e27_97def387a872.slice/cri-containerd-8ea8d95d283b0afb6df4fd59ea7b472a0bef0d9c48ace2e31874f4c41d3b24ac.scope
    637      cgroup_device   multi                                          
