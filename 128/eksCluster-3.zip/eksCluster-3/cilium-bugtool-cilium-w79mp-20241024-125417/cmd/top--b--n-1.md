top - 12:54:18 up 34 min,  0 users,  load average: 0.40, 0.46, 0.27
Tasks:   9 total,   3 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.7 us, 33.3 sy,  0.0 ni, 10.0 id,  0.0 wa,  0.0 hi, 10.0 si,  0.0 st
MiB Mem :   3836.2 total,    274.9 free,   1065.0 used,   2496.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2590.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 299376  80496 S  66.7   7.6   1:20.79 cilium-+
   3101 root      20   0 1229640  16428   4004 S  13.3   0.4   0:00.02 gops
    404 root      20   0 1229744   9024   2864 S   0.0   0.2   0:04.58 cilium-+
   3103 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3135 root      20   0 1240432  16352  11292 S   0.0   0.4   0:00.03 cilium-+
   3169 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3179 root      20   0    2304    832    752 D   0.0   0.0   0:00.00 sh
   3182 root      20   0    4356   2456   2004 R   0.0   0.1   0:00.00 iptable+
   3189 root      20   0    2304    832    752 R   0.0   0.0   0:00.00 sh
