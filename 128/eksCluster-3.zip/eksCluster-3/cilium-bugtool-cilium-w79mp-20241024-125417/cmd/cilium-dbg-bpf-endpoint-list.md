IP ADDRESS        LOCAL ENDPOINT INFO
10.3.0.13:0       id=289   sec_id=4     flags=0x0000 ifindex=10  mac=2A:75:64:91:2F:52 nodemac=EA:5D:6D:D3:AD:0D    
10.3.0.23:0       id=2471  sec_id=327171 flags=0x0000 ifindex=18  mac=0E:16:71:0F:18:A1 nodemac=AE:14:B9:ED:97:16   
10.3.0.236:0      (localhost)                                                                                       
10.3.0.168:0      id=423   sec_id=277012 flags=0x0000 ifindex=12  mac=72:23:F3:77:BF:30 nodemac=F6:DB:00:E9:9C:ED   
172.31.217.24:0   (localhost)                                                                                       
10.3.0.75:0       id=3583  sec_id=308620 flags=0x0000 ifindex=24  mac=5E:A2:AD:E9:F3:95 nodemac=82:41:39:0F:6C:74   
172.31.199.12:0   (localhost)                                                                                       
10.3.0.135:0      id=2001  sec_id=317813 flags=0x0000 ifindex=20  mac=7A:36:C8:51:F0:D3 nodemac=32:F7:12:2B:35:DF   
10.3.0.77:0       id=2373  sec_id=265367 flags=0x0000 ifindex=22  mac=B2:39:C4:63:81:C0 nodemac=F6:F8:44:F0:BB:F2   
10.3.0.53:0       id=3153  sec_id=277012 flags=0x0000 ifindex=14  mac=AA:0C:DB:E3:1B:3A nodemac=FE:24:90:72:3B:FA   
