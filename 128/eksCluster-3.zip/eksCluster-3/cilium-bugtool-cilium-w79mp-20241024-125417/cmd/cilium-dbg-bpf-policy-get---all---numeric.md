Endpoint ID: 289
Path: /sys/fs/bpf/tc/globals/cilium_policy_00289

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6212836   77078     0        
Allow    Ingress     1          ANY          NONE         disabled    64736     782       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 423
Path: /sys/fs/bpf/tc/globals/cilium_policy_00423

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3519     36        0        
Allow    Ingress     1          ANY          NONE         disabled    170947   1960      0        
Allow    Egress      0          ANY          NONE         disabled    22615    255       0        


Endpoint ID: 469
Path: /sys/fs/bpf/tc/globals/cilium_policy_00469

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2001
Path: /sys/fs/bpf/tc/globals/cilium_policy_02001

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2373
Path: /sys/fs/bpf/tc/globals/cilium_policy_02373

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2471
Path: /sys/fs/bpf/tc/globals/cilium_policy_02471

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6002462   60948     0        
Allow    Ingress     1          ANY          NONE         disabled    5426371   57385     0        
Allow    Egress      0          ANY          NONE         disabled    7657043   74771     0        


Endpoint ID: 3153
Path: /sys/fs/bpf/tc/globals/cilium_policy_03153

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3355     34        0        
Allow    Ingress     1          ANY          NONE         disabled    172900   1995      0        
Allow    Egress      0          ANY          NONE         disabled    22775    256       0        


Endpoint ID: 3583
Path: /sys/fs/bpf/tc/globals/cilium_policy_03583

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376137   4407      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


