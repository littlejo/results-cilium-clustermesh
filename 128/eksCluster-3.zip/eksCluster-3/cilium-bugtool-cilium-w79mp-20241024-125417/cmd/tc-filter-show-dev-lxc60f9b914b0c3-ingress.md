filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc60f9b914b0c3 direct-action not_in_hw id 3293 tag 8188661939b24c8c jited 
