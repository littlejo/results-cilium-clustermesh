KEY             VALUE
AgentLiveness   2077540079571
UTimeOffset     3378461742187500
