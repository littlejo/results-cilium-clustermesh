# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.3.0.0/24, 
Allocated addresses:
  10.3.0.13 (health)
  10.3.0.135 (cilium-test-1/client2-57cf4468f-88bsc)
  10.3.0.168 (kube-system/coredns-cc6ccd49c-hzxnx)
  10.3.0.23 (kube-system/clustermesh-apiserver-68cbdd477f-2pmfm)
  10.3.0.236 (router)
  10.3.0.53 (kube-system/coredns-cc6ccd49c-tg86c)
  10.3.0.75 (cilium-test-1/echo-same-node-86d9cc975c-hhnsr)
  10.3.0.77 (cilium-test-1/client-974f6c69d-g8hrq)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407548bcd4909ca7
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      177/177 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    8s ago         never        0       no error   
  ct-map-pressure                                                     9s ago         never        0       no error   
  daemon-validate-config                                              40s ago        never        0       no error   
  dns-garbage-collector-job                                           12s ago        never        0       no error   
  endpoint-2001-regeneration-recovery                                 never          never        0       no error   
  endpoint-2373-regeneration-recovery                                 never          never        0       no error   
  endpoint-2471-regeneration-recovery                                 never          never        0       no error   
  endpoint-289-regeneration-recovery                                  never          never        0       no error   
  endpoint-3153-regeneration-recovery                                 never          never        0       no error   
  endpoint-3583-regeneration-recovery                                 never          never        0       no error   
  endpoint-423-regeneration-recovery                                  never          never        0       no error   
  endpoint-469-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         12s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                9s ago         never        0       no error   
  ipcache-inject-labels                                               10s ago        never        0       no error   
  k8s-heartbeat                                                       12s ago        never        0       no error   
  link-cache                                                          9s ago         never        0       no error   
  local-identity-checkpoint                                           2m57s ago      never        0       no error   
  node-neighbor-link-updater                                          9s ago         never        0       no error   
  remote-etcd-cmesh1                                                  12m34s ago     never        0       no error   
  remote-etcd-cmesh10                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh100                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh101                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh102                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh103                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh104                                                12m35s ago     never        0       no error   
  remote-etcd-cmesh105                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh106                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh107                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh108                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh109                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh11                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh110                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh111                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh112                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh113                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh114                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh115                                                12m35s ago     never        0       no error   
  remote-etcd-cmesh116                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh117                                                12m35s ago     never        0       no error   
  remote-etcd-cmesh118                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh119                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh12                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh120                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh121                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh122                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh123                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh124                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh125                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh126                                                12m34s ago     never        0       no error   
  remote-etcd-cmesh127                                                12m35s ago     never        0       no error   
  remote-etcd-cmesh128                                                12m35s ago     never        0       no error   
  remote-etcd-cmesh13                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh14                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh15                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh16                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh17                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh18                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh19                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh2                                                  12m34s ago     never        0       no error   
  remote-etcd-cmesh20                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh21                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh22                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh23                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh24                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh25                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh26                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh27                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh28                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh29                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh3                                                  12m34s ago     never        0       no error   
  remote-etcd-cmesh30                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh31                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh32                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh33                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh34                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh35                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh36                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh37                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh38                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh39                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh40                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh41                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh42                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh43                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh44                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh45                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh46                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh47                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh48                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh49                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh5                                                  12m34s ago     never        0       no error   
  remote-etcd-cmesh50                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh51                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh52                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh53                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh54                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh55                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh56                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh57                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh58                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh59                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh6                                                  12m34s ago     never        0       no error   
  remote-etcd-cmesh60                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh61                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh62                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh63                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh64                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh65                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh66                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh67                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh68                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh69                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh7                                                  12m34s ago     never        0       no error   
  remote-etcd-cmesh70                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh71                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh72                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh73                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh74                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh75                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh76                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh77                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh78                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh79                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh8                                                  12m34s ago     never        0       no error   
  remote-etcd-cmesh80                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh81                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh82                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh83                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh84                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh85                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh86                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh87                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh88                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh89                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh9                                                  12m34s ago     never        0       no error   
  remote-etcd-cmesh90                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh91                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh92                                                 12m35s ago     never        0       no error   
  remote-etcd-cmesh93                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh94                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh95                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh96                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh97                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh98                                                 12m34s ago     never        0       no error   
  remote-etcd-cmesh99                                                 12m34s ago     never        0       no error   
  resolve-identity-2001                                               1m28s ago      never        0       no error   
  resolve-identity-2373                                               1m28s ago      never        0       no error   
  resolve-identity-2471                                               3m52s ago      never        0       no error   
  resolve-identity-289                                                8s ago         never        0       no error   
  resolve-identity-3153                                               8s ago         never        0       no error   
  resolve-identity-3583                                               1m28s ago      never        0       no error   
  resolve-identity-423                                                8s ago         never        0       no error   
  resolve-identity-469                                                9s ago         never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-g8hrq                 6m28s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-88bsc                6m28s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-hhnsr        6m28s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-68cbdd477f-2pmfm   13m52s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-hzxnx                  30m8s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-tg86c                  30m8s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      30m9s ago      never        0       no error   
  sync-policymap-2001                                                 6m28s ago      never        0       no error   
  sync-policymap-2373                                                 6m28s ago      never        0       no error   
  sync-policymap-2471                                                 13m52s ago     never        0       no error   
  sync-policymap-289                                                  5s ago         never        0       no error   
  sync-policymap-3153                                                 5s ago         never        0       no error   
  sync-policymap-3583                                                 6m28s ago      never        0       no error   
  sync-policymap-423                                                  5s ago         never        0       no error   
  sync-policymap-469                                                  8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2001)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2373)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2471)                                   12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3153)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3583)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (423)                                    8s ago         never        0       no error   
  sync-utime                                                          10s ago        never        0       no error   
  write-cni-file                                                      30m12s ago     never        0       no error   
Proxy Status:            OK, ip 10.3.0.236, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 262144, max 327679
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 153.06   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Policy get

```
:
 []
Revision: 129

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33663995                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33663995                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33663995                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d800000 rw-p 00000000 00:00 0 
400d800000-4010000000 ---p 00000000 00:00 0 
ffff4143f000-ffff41715000 rw-p 00000000 00:00 0 
ffff4171d000-ffff4183e000 rw-p 00000000 00:00 0 
ffff4183e000-ffff4187f000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4187f000-ffff418c0000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff418c0000-ffff418c2000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff418c2000-ffff418c4000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff418c4000-ffff41e6b000 rw-p 00000000 00:00 0 
ffff41e6b000-ffff41f6b000 rw-p 00000000 00:00 0 
ffff41f6b000-ffff41f7c000 rw-p 00000000 00:00 0 
ffff41f7c000-ffff43f7c000 rw-p 00000000 00:00 0 
ffff43f7c000-ffff43ffc000 ---p 00000000 00:00 0 
ffff43ffc000-ffff43ffd000 rw-p 00000000 00:00 0 
ffff43ffd000-ffff63ffc000 ---p 00000000 00:00 0 
ffff63ffc000-ffff63ffd000 rw-p 00000000 00:00 0 
ffff63ffd000-ffff83f8c000 ---p 00000000 00:00 0 
ffff83f8c000-ffff83f8d000 rw-p 00000000 00:00 0 
ffff83f8d000-ffff87f7e000 ---p 00000000 00:00 0 
ffff87f7e000-ffff87f7f000 rw-p 00000000 00:00 0 
ffff87f7f000-ffff8877c000 ---p 00000000 00:00 0 
ffff8877c000-ffff8877d000 rw-p 00000000 00:00 0 
ffff8877d000-ffff8887c000 ---p 00000000 00:00 0 
ffff8887c000-ffff888dc000 rw-p 00000000 00:00 0 
ffff888dc000-ffff888de000 r--p 00000000 00:00 0                          [vvar]
ffff888de000-ffff888df000 r-xp 00000000 00:00 0                          [vdso]
fffff4c43000-fffff4c64000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=10) "10.3.0.236": (string) (len=6) "router",
  (string) (len=9) "10.3.0.13": (string) (len=6) "health",
  (string) (len=10) "10.3.0.168": (string) (len=35) "kube-system/coredns-cc6ccd49c-hzxnx",
  (string) (len=9) "10.3.0.53": (string) (len=35) "kube-system/coredns-cc6ccd49c-tg86c",
  (string) (len=10) "10.3.0.135": (string) (len=37) "cilium-test-1/client2-57cf4468f-88bsc",
  (string) (len=9) "10.3.0.23": (string) (len=50) "kube-system/clustermesh-apiserver-68cbdd477f-2pmfm",
  (string) (len=9) "10.3.0.77": (string) (len=36) "cilium-test-1/client-974f6c69d-g8hrq",
  (string) (len=9) "10.3.0.75": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-hhnsr"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.217.24": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4000bc14a0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001c20120,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001c20120,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001a57080)(frontends:[10.100.75.60]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001a57130)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40026380b0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002638160)(frontends:[10.100.84.20]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x4009f628f0)(frontends:[10.100.201.9]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001a56fd0)(frontends:[10.100.0.1]/ports=[https]/selector=map[])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400137fc90)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x400230e4e0)(172.31.159.229:443/TCP,172.31.229.220:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400137fc98)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-5569w": (*k8s.Endpoints)(0x40010ccea0)(172.31.217.24:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400137fca0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-8hcf6": (*k8s.Endpoints)(0x400363f5f0)(10.3.0.168:53/TCP[eu-west-3b],10.3.0.168:53/UDP[eu-west-3b],10.3.0.168:9153/TCP[eu-west-3b],10.3.0.53:53/TCP[eu-west-3b],10.3.0.53:53/UDP[eu-west-3b],10.3.0.53:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x400148dec0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-q4j4m": (*k8s.Endpoints)(0x4003b21ad0)(10.3.0.23:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x400181c308)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-mljcg": (*k8s.Endpoints)(0x4002a1b790)(10.3.0.75:8080/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4000299650)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40024f1220)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400a27b278
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002904de0,
  gcExited: (chan struct {}) 0x4002904e40,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40005a9180)({
     ObserverVec: (*prometheus.HistogramVec)(0x400148dc98)({
      MetricVec: (*prometheus.MetricVec)(0x4000a4b860)({
       metricMap: (*prometheus.metricMap)(0x4000a4b8c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001382a80)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40005a9200)({
     ObserverVec: (*prometheus.HistogramVec)(0x400148dca0)({
      MetricVec: (*prometheus.MetricVec)(0x4000a4b920)({
       metricMap: (*prometheus.metricMap)(0x4000a4b950)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001382cc0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40005a9400)({
     GaugeVec: (*prometheus.GaugeVec)(0x400148dca8)({
      MetricVec: (*prometheus.MetricVec)(0x4000a4b9b0)({
       metricMap: (*prometheus.metricMap)(0x4000a4b9e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001382f60)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40005a9500)({
     GaugeVec: (*prometheus.GaugeVec)(0x400148dcb0)({
      MetricVec: (*prometheus.MetricVec)(0x4000a4ba70)({
       metricMap: (*prometheus.metricMap)(0x4000a4baa0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001383560)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40005a9580)({
     GaugeVec: (*prometheus.GaugeVec)(0x400148dcb8)({
      MetricVec: (*prometheus.MetricVec)(0x4000a4bb00)({
       metricMap: (*prometheus.metricMap)(0x4000a4bb30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40003bd560)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40005a9600)({
     GaugeVec: (*prometheus.GaugeVec)(0x400148dcc0)({
      MetricVec: (*prometheus.MetricVec)(0x4000a4bb90)({
       metricMap: (*prometheus.metricMap)(0x4000a4bbc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40003bd6e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40005a9700)({
     GaugeVec: (*prometheus.GaugeVec)(0x400148dcc8)({
      MetricVec: (*prometheus.MetricVec)(0x4000a4bc50)({
       metricMap: (*prometheus.metricMap)(0x4000a4bcb0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40003bd740)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40005a9800)({
     GaugeVec: (*prometheus.GaugeVec)(0x400148dcd0)({
      MetricVec: (*prometheus.MetricVec)(0x4000a4bd10)({
       metricMap: (*prometheus.metricMap)(0x4000a4bd40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40003bd7a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40005a9880)({
     ObserverVec: (*prometheus.HistogramVec)(0x400148dcd8)({
      MetricVec: (*prometheus.MetricVec)(0x4000a4bda0)({
       metricMap: (*prometheus.metricMap)(0x4000a4bdd0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40003bd800)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4000299650)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40001677a0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x400198d638)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 287ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium environment keys

```
bpf-lb-service-map-max:0
k8s-sync-timeout:3m0s
enable-recorder:false
install-no-conntrack-iptables-rules:false
remove-cilium-node-taints:true
disable-endpoint-crd:false
l2-announcements-retry-period:2s
ipv6-native-routing-cidr:
enable-service-topology:false
mtu:0
node-labels:
hubble-metrics-server:
dns-max-ips-per-restored-rule:1000
enable-ip-masq-agent:false
ipv6-pod-subnets:
ipv6-node:auto
policy-queue-size:100
enable-local-redirect-policy:false
trace-sock:true
bpf-lb-rev-nat-map-max:0
read-cni-conf:
unmanaged-pod-watcher-interval:15
cluster-health-port:4240
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
synchronize-k8s-nodes:true
bgp-announce-lb-ip:false
config-sources:config-map:kube-system/cilium-config
encryption-strict-mode-cidr:
use-full-tls-context:false
config:
envoy-log:
monitor-aggregation-interval:5s
enable-tracing:false
k8s-heartbeat-timeout:30s
bpf-lb-map-max:65536
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
hubble-event-buffer-capacity:4095
policy-accounting:true
k8s-service-proxy-name:
set-cilium-node-taints:true
enable-hubble:true
http-request-timeout:3600
tunnel-port:0
prometheus-serve-addr:
proxy-max-connection-duration-seconds:0
clustermesh-ip-identities-sync-timeout:1m0s
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
disable-envoy-version-check:false
datapath-mode:veth
cluster-pool-ipv4-cidr:10.3.0.0/16
hubble-socket-path:/var/run/cilium/hubble.sock
enable-host-firewall:false
tofqdns-proxy-port:0
ipv4-node:auto
mesh-auth-gc-interval:5m0s
proxy-admin-port:0
ipam:cluster-pool
conntrack-gc-interval:0s
tofqdns-min-ttl:0
enable-ipv6-ndp:false
bpf-root:/sys/fs/bpf
allocator-list-timeout:3m0s
enable-wireguard-userspace-fallback:false
enable-k8s-api-discovery:false
hubble-flowlogs-config-path:
node-port-range:
dnsproxy-socket-linger-timeout:10
ipv4-native-routing-cidr:
identity-gc-interval:15m0s
hubble-export-file-path:
cmdref:
proxy-xff-num-trusted-hops-egress:0
vtep-mac:
bpf-auth-map-max:524288
policy-cidr-match-mode:
k8s-service-cache-size:128
encrypt-node:false
enable-cilium-endpoint-slice:false
ipsec-key-rotation-duration:5m0s
enable-gateway-api:false
pprof-port:6060
enable-metrics:true
egress-gateway-policy-map-max:16384
dns-policy-unload-on-shutdown:false
bpf-lb-acceleration:disabled
bpf-lb-dsr-dispatch:opt
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
proxy-connect-timeout:2
bpf-sock-rev-map-max:262144
hubble-redact-http-headers-deny:
hubble-recorder-sink-queue-size:1024
enable-runtime-device-detection:true
tofqdns-proxy-response-max-delay:100ms
cilium-endpoint-gc-interval:5m0s
ipam-cilium-node-update-rate:15s
disable-external-ip-mitigation:false
enable-icmp-rules:true
enable-ipv4-egress-gateway:false
local-router-ipv4:
service-no-backend-response:reject
identity-heartbeat-timeout:30m0s
monitor-aggregation:medium
ipv4-pod-subnets:
bpf-lb-service-backend-map-max:0
enable-ipip-termination:false
hubble-prefer-ipv6:false
direct-routing-skip-unreachable:false
l2-pod-announcements-interface:
proxy-idle-timeout-seconds:60
kvstore-periodic-sync:5m0s
encrypt-interface:
http-retry-timeout:0
enable-host-legacy-routing:false
disable-iptables-feeder-rules:
nodes-gc-interval:5m0s
envoy-config-timeout:2m0s
hubble-export-denylist:
bpf-neigh-global-max:524288
fixed-identity-mapping:
enable-bandwidth-manager:false
allow-icmp-frag-needed:true
operator-api-serve-addr:127.0.0.1:9234
enable-ipv6-masquerade:true
bpf-node-map-max:16384
custom-cni-conf:false
static-cnp-path:
k8s-api-server:
proxy-gid:1337
clustermesh-sync-timeout:1m0s
ip-masq-agent-config-path:/etc/config/ip-masq-agent
log-driver:
ipsec-key-file:
enable-l2-announcements:false
wireguard-persistent-keepalive:0s
identity-change-grace-period:5s
node-port-algorithm:random
join-cluster:false
use-cilium-internal-ip-for-ipsec:false
proxy-max-requests-per-connection:0
arping-refresh-period:30s
enable-monitor:true
hubble-export-fieldmask:
bpf-lb-sock-hostns-only:false
ipv4-range:auto
enable-l2-neigh-discovery:true
controller-group-metrics:
bpf-ct-timeout-regular-tcp:2h13m20s
bpf-lb-sock-terminate-pod-connections:false
derive-masq-ip-addr-from-device:
hubble-export-allowlist:
ipv4-service-loopback-address:169.254.42.1
envoy-keep-cap-netbindservice:false
hubble-redact-enabled:false
mesh-auth-spire-admin-socket:
enable-health-checking:true
auto-direct-node-routes:false
cgroup-root:/run/cilium/cgroupv2
max-connected-clusters:255
enable-bbr:false
bpf-lb-maglev-map-max:0
enable-ipsec-xfrm-state-caching:true
enable-local-node-route:true
enable-encryption-strict-mode:false
enable-cilium-health-api-server-access:
devices:
mesh-auth-rotated-identities-queue-size:1024
crd-wait-timeout:5m0s
cluster-name:cmesh4
mesh-auth-mutual-listener-port:0
gateway-api-secrets-namespace:
enable-k8s-endpoint-slice:true
l2-announcements-lease-duration:15s
enable-xdp-prefilter:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
proxy-prometheus-port:0
force-device-detection:false
local-router-ipv6:
node-port-bind-protection:true
l2-announcements-renew-deadline:5s
dnsproxy-concurrency-limit:0
enable-bpf-tproxy:false
enable-ipv4:true
enable-endpoint-routes:false
vtep-endpoint:
cflags:
tofqdns-enable-dns-compression:true
http-idle-timeout:0
egress-multi-home-ip-rule-compat:false
hubble-event-queue-size:0
k8s-namespace:kube-system
enable-mke:false
nodeport-addresses:
cni-exclusive:true
annotate-k8s-node:false
ipv6-mcast-device:
hubble-export-file-compress:false
max-controller-interval:0
bpf-ct-timeout-service-tcp-grace:1m0s
cni-chaining-mode:none
enable-nat46x64-gateway:false
api-rate-limit:
http-max-grpc-timeout:0
max-internal-timer-delay:0s
identity-allocation-mode:crd
k8s-client-connection-keep-alive:30s
enable-ipv4-big-tcp:false
keep-config:false
proxy-xff-num-trusted-hops-ingress:0
enable-bpf-masquerade:false
endpoint-queue-size:25
enable-wireguard:false
enable-well-known-identities:false
bpf-lb-external-clusterip:false
hubble-drop-events-interval:2m0s
preallocate-bpf-maps:false
pprof-address:localhost
enable-ipsec:false
routing-mode:tunnel
bgp-announce-pod-cidr:false
bpf-events-policy-verdict-enabled:true
nat-map-stats-interval:30s
envoy-secrets-namespace:
enable-svc-source-range-check:true
enable-identity-mark:true
enable-ipsec-key-watcher:true
policy-trigger-interval:1s
agent-liveness-update-interval:1s
enable-custom-calls:false
ipv4-service-range:auto
ipv6-range:auto
procfs:/host/proc
bpf-lb-rss-ipv4-src-cidr:
enable-tcx:true
envoy-config-retry-interval:15s
enable-envoy-config:false
enable-xt-socket-fallback:true
state-dir:/var/run/cilium
gops-port:9890
enable-high-scale-ipcache:false
enable-node-port:false
enable-ipv6-big-tcp:false
iptables-lock-timeout:5s
vtep-cidr:
hubble-metrics:
bpf-map-event-buffers:
monitor-queue-size:0
set-cilium-is-up-condition:true
bpf-ct-global-any-max:262144
bpf-events-trace-enabled:true
enable-k8s-networkpolicy:true
bpf-policy-map-max:16384
cni-chaining-target:
hubble-disable-tls:false
enable-pmtu-discovery:false
bpf-filter-priority:1
k8s-client-connection-timeout:30s
enable-unreachable-routes:false
enable-endpoint-health-checking:true
policy-audit-mode:false
fqdn-regex-compile-lru-size:1024
bpf-ct-timeout-regular-any:1m0s
envoy-base-id:0
egress-gateway-reconciliation-trigger-interval:1s
tunnel-protocol:vxlan
config-dir:/tmp/cilium/config-map
bpf-ct-global-tcp-max:524288
clustermesh-enable-mcs-api:false
cluster-id:4
version:false
bpf-nat-global-max:524288
hubble-skip-unknown-cgroup-ids:true
http-normalize-path:true
kube-proxy-replacement-healthz-bind-address:
mesh-auth-signal-backoff-duration:1s
hubble-drop-events:false
enable-bgp-control-plane:false
enable-ipsec-encrypted-overlay:false
mke-cgroup-mount:
dnsproxy-concurrency-processing-grace-period:0s
ipam-default-ip-pool:default
encryption-strict-mode-allow-remote-node-identities:false
enable-health-check-nodeport:true
enable-route-mtu-for-cni-chaining:false
bpf-events-drop-enabled:true
identity-restore-grace-period:30s
log-system-load:false
cni-log-file:/var/run/cilium/cilium-cni.log
enable-auto-protect-node-port-range:true
dnsproxy-lock-count:131
tofqdns-idle-connection-grace-period:0s
bpf-ct-timeout-service-any:1m0s
endpoint-gc-interval:5m0s
operator-prometheus-serve-addr::9963
proxy-portrange-min:10000
bpf-lb-source-range-map-max:0
k8s-require-ipv6-pod-cidr:false
kube-proxy-replacement:false
enable-srv6:false
enable-ingress-controller:false
enable-sctp:false
ipv6-service-range:auto
hubble-recorder-storage-path:/var/run/cilium/pcaps
kvstore:
enable-session-affinity:false
k8s-client-qps:10
k8s-client-burst:20
enable-l2-pod-announcements:false
bpf-ct-timeout-service-tcp:2h13m20s
enable-stale-cilium-endpoint-cleanup:true
debug-verbose:
hubble-drop-events-reasons:auth_required,policy_denied
route-metric:0
log-opt:
enable-cilium-api-server-access:
agent-labels:
iptables-random-fully:false
srv6-encap-mode:reduced
nat-map-stats-entries:32
http-retry-count:3
enable-host-port:false
ipv6-cluster-alloc-cidr:f00d::/64
container-ip-local-reserved-ports:auto
enable-policy:default
enable-k8s:true
bpf-ct-timeout-regular-tcp-syn:1m0s
conntrack-gc-max-interval:0s
pprof:false
bpf-lb-mode:snat
enable-ipv4-masquerade:true
hubble-redact-http-headers-allow:
external-envoy-proxy:true
exclude-node-label-patterns:
bypass-ip-availability-upon-restore:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-l7-proxy:true
k8s-require-ipv4-pod-cidr:false
direct-routing-device:
ipam-multi-pool-pre-allocation:
tofqdns-endpoint-max-ip-per-hostname:50
enable-vtep:false
socket-path:/var/run/cilium/cilium.sock
allow-localhost:auto
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-export-file-max-size-mb:10
label-prefix-file:
hubble-redact-http-urlquery:false
enable-k8s-terminating-endpoint:true
mesh-auth-enabled:true
restore:true
bpf-lb-rss-ipv6-src-cidr:
bpf-policy-map-full-reconciliation-interval:15m0s
enable-node-selector-labels:false
enable-health-check-loadbalancer-ip:false
egress-masquerade-interfaces:ens+
bpf-lb-maglev-table-size:16381
exclude-local-address:
enable-bpf-clock-probe:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
bpf-lb-sock:false
hubble-listen-address::4244
node-port-mode:snat
trace-payloadlen:128
cluster-pool-ipv4-mask-size:24
enable-hubble-recorder-api:true
node-port-acceleration:disabled
debug:false
kvstore-max-consecutive-quorum-errors:2
monitor-aggregation-flags:all
enable-active-connection-tracking:false
bpf-lb-algorithm:random
enable-external-ips:false
enable-masquerade-to-route-source:false
cni-external-routing:false
mesh-auth-queue-size:1024
vlan-bpf-bypass:
endpoint-bpf-prog-watchdog-interval:30s
proxy-portrange-max:20000
bpf-ct-timeout-regular-tcp-fin:10s
kvstore-lease-ttl:15m0s
enable-ipv6:false
bpf-lb-affinity-map-max:0
hubble-redact-http-userinfo:true
agent-health-port:9879
dnsproxy-lock-timeout:500ms
clustermesh-enable-endpoint-sync:false
k8s-kubeconfig-path:
dnsproxy-insecure-skip-transparent-mode-check:false
tofqdns-pre-cache:
auto-create-cilium-node-resource:true
install-iptables-rules:true
hubble-monitor-events:
kvstore-opt:
certificates-directory:/var/run/cilium/certs
bpf-map-dynamic-size-ratio:0.0025
metrics:
prepend-iptables-chains:true
kvstore-connectivity-timeout:2m0s
dnsproxy-enable-transparent-mode:true
multicast-enabled:false
tofqdns-dns-reject-response-code:refused
local-max-addr-scope:252
mesh-auth-mutual-connect-timeout:5s
tofqdns-max-deferred-connection-deletes:10000
hubble-export-file-max-backups:5
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
ingress-secrets-namespace:
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-ipv4-fragment-tracking:true
clustermesh-config:/var/lib/cilium/clustermesh/
hubble-redact-kafka-apikey:false
bpf-fragments-map-max:8192
bpf-lb-dsr-l4-xlate:frontend
lib-dir:/var/lib/cilium
vtep-mask:
labels:
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
289        Disabled           Disabled          4          reserved:health                                                                       10.3.0.13    ready   
423        Disabled           Disabled          277012     k8s:eks.amazonaws.com/component=coredns                                               10.3.0.168   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh4                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
469        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                 
                                                           reserved:host                                                                                              
2001       Disabled           Disabled          317813     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.3.0.135   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh4                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                            
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client2                                                                                           
                                                           k8s:other=client                                                                                           
2373       Disabled           Disabled          265367     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.3.0.77    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh4                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client                                                                                            
2471       Disabled           Disabled          327171     k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.3.0.23    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh4                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
3153       Disabled           Disabled          277012     k8s:eks.amazonaws.com/component=coredns                                               10.3.0.53    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh4                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
3583       Disabled           Disabled          308620     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.3.0.75    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh4                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                     
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=echo                                                                                              
                                                           k8s:name=echo-same-node                                                                                    
                                                           k8s:other=echo                                                                                             
```

#### BPF Policy Get 289

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6210010   77041     0        
Allow    Ingress     1          ANY          NONE         disabled    64736     782       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 289

```
Invalid argument: unknown type 289
```


#### Endpoint Get 289

```
[
  {
    "id": 289,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-289-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d50120ea-46cd-47b5-b246-13fd5eedb35d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-289",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.343Z",
            "success-count": 7
          },
          "uuid": "634920eb-561b-4c38-b3b9-55340e7f5735"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-289",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:43.653Z",
            "success-count": 3
          },
          "uuid": "2d400457-afc4-454f-a386-8557adee6c53"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.3.0.13",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ea:5d:6d:d3:ad:0d",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "2a:75:64:91:2f:52"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 289

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 289

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:16Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T12:24:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:24:43Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T12:24:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T12:24:40Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:24:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:24:40Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:24:39Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 423

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3519     36        0        
Allow    Ingress     1          ANY          NONE         disabled    170054   1950      0        
Allow    Egress      0          ANY          NONE         disabled    22615    255       0        

```


#### BPF CT List 423

```
Invalid argument: unknown type 423
```


#### Endpoint Get 423

```
[
  {
    "id": 423,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-423-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "174e54d2-8e1b-44e7-a756-8091efcdbf40"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-423",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.336Z",
            "success-count": 7
          },
          "uuid": "cf576c26-0c50-4e5e-bf72-7da088552cb8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-hzxnx",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:24:40.331Z",
            "success-count": 1
          },
          "uuid": "8f2ee6a5-062a-4e05-9ed7-72139e9baa5c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-423",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:43.612Z",
            "success-count": 3
          },
          "uuid": "adbf86e3-fe05-4196-ba78-3e21a7b3d4bf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (423)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.473Z",
            "success-count": 182
          },
          "uuid": "6d525165-420d-4ee6-bcfd-f9d37c91b64c"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "a0393bb068c74a9cf39937ddf8cb7870985298b6f9c4e5440e5694b2cb96478f:eth0",
        "container-id": "a0393bb068c74a9cf39937ddf8cb7870985298b6f9c4e5440e5694b2cb96478f",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-hzxnx",
        "pod-name": "kube-system/coredns-cc6ccd49c-hzxnx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 277012,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.3.0.168",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f6:db:00:e9:9c:ed",
        "interface-index": 12,
        "interface-name": "lxc0437ecfab5b5",
        "mac": "72:23:f3:77:bf:30"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 277012,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 277012,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 423

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 423

```
Timestamp              Status    State                   Message
2024-10-24T12:48:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:16Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:42:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:14Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:14Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:14Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:14Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T12:24:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:24:43Z   OK        regenerating            Regenerating endpoint: devices changed
2024-10-24T12:24:43Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:24:41Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:24:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T12:24:40Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:24:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:24:40Z   OK        ready                   Set identity for this endpoint
2024-10-24T12:24:40Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:40Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 277012

```
ID       LABELS
277012   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh4
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 469

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 469

```
Invalid argument: unknown type 469
```


#### Endpoint Get 469

```
[
  {
    "id": 469,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-469-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "fbe6095c-d2df-4d63-bd15-b98392fbb7d8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-469",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:39.142Z",
            "success-count": 7
          },
          "uuid": "3995a7f8-b097-4c45-8652-488214e83c70"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-469",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.368Z",
            "success-count": 3
          },
          "uuid": "27bcaf84-079e-4525-9121-1212aaff97a2"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "aa:22:38:f4:3b:05",
        "interface-name": "cilium_host",
        "mac": "aa:22:38:f4:3b:05"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 469

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 469

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:16Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:24:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:24:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:24:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:24:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:39Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:24:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:24:39Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:24:39Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2001

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2001

```
Invalid argument: unknown type 2001
```


#### Endpoint Get 2001

```
[
  {
    "id": 2001,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2001-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "144bf19d-cc09-4536-9f3a-a3b26e06a2d9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2001",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:20.259Z",
            "success-count": 2
          },
          "uuid": "d47dff8c-e61a-4a4f-96a5-f9a809898eb8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-88bsc",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.249Z",
            "success-count": 1
          },
          "uuid": "9eb1a9af-779f-4d19-a75e-147fe1bfdddf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2001",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.298Z",
            "success-count": 1
          },
          "uuid": "0b399c91-93a2-40db-86f8-b27e457c2795"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2001)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:50.287Z",
            "success-count": 41
          },
          "uuid": "3aacf979-8c0e-42d7-af0f-cbc0bfbdd02b"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "1c5fb07abac2fb12d217cff966222c790fbea0d3d04163942b59f3eac379b5b3:eth0",
        "container-id": "1c5fb07abac2fb12d217cff966222c790fbea0d3d04163942b59f3eac379b5b3",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-88bsc",
        "pod-name": "cilium-test-1/client2-57cf4468f-88bsc"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 317813,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:36Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.3.0.135",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "32:f7:12:2b:35:df",
        "interface-index": 20,
        "interface-name": "lxcdc07bee00e16",
        "mac": "7a:36:c8:51:f0:d3"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 317813,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 317813,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2001

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2001

```
Timestamp              Status   State                   Message
2024-10-24T12:51:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 317813

```
ID       LABELS
317813   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh4
         k8s:io.cilium.k8s.policy.serviceaccount=client2
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client2
         k8s:other=client

```


#### BPF Policy Get 2373

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2373

```
Invalid argument: unknown type 2373
```


#### Endpoint Get 2373

```
[
  {
    "id": 2373,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2373-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c4b9893b-ca9b-4724-8da5-4a59a544fcc9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2373",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:20.530Z",
            "success-count": 2
          },
          "uuid": "171e7428-cf01-4b06-8465-b3ed98f13cc1"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-g8hrq",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.528Z",
            "success-count": 1
          },
          "uuid": "6b59c761-1711-40ee-a7e1-767aa783c33a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2373",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.572Z",
            "success-count": 1
          },
          "uuid": "f4bef6a7-7776-4f00-85ff-4d7f06c37a2d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2373)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:50.574Z",
            "success-count": 41
          },
          "uuid": "80065d6e-35ce-465c-93af-85110a8cecbc"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b0b92ce750ef055faf6a0e0c0ed5016e46316c0e4ff0f13213de37c5861f28fa:eth0",
        "container-id": "b0b92ce750ef055faf6a0e0c0ed5016e46316c0e4ff0f13213de37c5861f28fa",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-g8hrq",
        "pod-name": "cilium-test-1/client-974f6c69d-g8hrq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 265367,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:36Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.3.0.77",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f6:f8:44:f0:bb:f2",
        "interface-index": 22,
        "interface-name": "lxca46c7b292bd2",
        "mac": "b2:39:c4:63:81:c0"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 265367,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 265367,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2373

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2373

```
Timestamp              Status   State                   Message
2024-10-24T12:51:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 265367

```
ID       LABELS
265367   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh4
         k8s:io.cilium.k8s.policy.serviceaccount=client
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client

```


#### BPF Policy Get 2471

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6001626   60939     0        
Allow    Ingress     1          ANY          NONE         disabled    5426371   57385     0        
Allow    Egress      0          ANY          NONE         disabled    7655681   74757     0        

```


#### BPF CT List 2471

```
Invalid argument: unknown type 2471
```


#### Endpoint Get 2471

```
[
  {
    "id": 2471,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2471-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e4049593-d5b2-49a9-a807-c8a067e94560"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2471",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:50:56.431Z",
            "success-count": 3
          },
          "uuid": "7bde2415-4502-4009-bc73-0f1473e11362"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-68cbdd477f-2pmfm",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:40:56.430Z",
            "success-count": 1
          },
          "uuid": "c3a7ae01-6616-4bfb-9f37-2f11b44e0cac"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2471",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:40:56.474Z",
            "success-count": 1
          },
          "uuid": "83eeb742-db13-48f1-8f04-d74209690dd8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2471)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:46.511Z",
            "success-count": 85
          },
          "uuid": "ebfdcd4f-68db-4556-af93-31f5d9dc23b7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8ea8d95d283b0afb6df4fd59ea7b472a0bef0d9c48ace2e31874f4c41d3b24ac:eth0",
        "container-id": "8ea8d95d283b0afb6df4fd59ea7b472a0bef0d9c48ace2e31874f4c41d3b24ac",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-68cbdd477f-2pmfm",
        "pod-name": "kube-system/clustermesh-apiserver-68cbdd477f-2pmfm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 327171,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=68cbdd477f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.3.0.23",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ae:14:b9:ed:97:16",
        "interface-index": 18,
        "interface-name": "lxc04ae6f46339b",
        "mac": "0e:16:71:0f:18:a1"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 327171,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 327171,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2471

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2471

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:16Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:40:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:40:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:40:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:40:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:40:56Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:40:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 327171

```
ID       LABELS
327171   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh4
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 3153

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3355     34        0        
Allow    Ingress     1          ANY          NONE         disabled    172900   1995      0        
Allow    Egress      0          ANY          NONE         disabled    22775    256       0        

```


#### BPF CT List 3153

```
Invalid argument: unknown type 3153
```


#### Endpoint Get 3153

```
[
  {
    "id": 3153,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3153-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "98c4f261-e53e-4a88-ae00-b50db298175c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3153",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.346Z",
            "success-count": 7
          },
          "uuid": "67206f97-f95a-4447-93a9-6c3bc98b43ec"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-tg86c",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:24:40.342Z",
            "success-count": 1
          },
          "uuid": "e9b642b1-2032-4627-acd8-97d3b206dadf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3153",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:43.700Z",
            "success-count": 3
          },
          "uuid": "21bf363f-a753-42b0-bc7e-912798d62a11"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3153)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:50.494Z",
            "success-count": 183
          },
          "uuid": "5fe62d07-c155-4832-b6f1-908b7743d7b5"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b976125084ac2f6b8cea77dabe10b951d9537d02182d0320b2fd66709c2e4b05:eth0",
        "container-id": "b976125084ac2f6b8cea77dabe10b951d9537d02182d0320b2fd66709c2e4b05",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-tg86c",
        "pod-name": "kube-system/coredns-cc6ccd49c-tg86c"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 277012,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.3.0.53",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "fe:24:90:72:3b:fa",
        "interface-index": 14,
        "interface-name": "lxc68cae2cde3e7",
        "mac": "aa:0c:db:e3:1b:3a"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 277012,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 277012,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3153

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3153

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:16Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:33:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:33:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:33:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:33:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:24:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:24:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:24:43Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:24:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:24:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:24:40Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:24:40Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 277012

```
ID       LABELS
277012   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh4
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3583

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376137   4407      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3583

```
Invalid argument: unknown type 3583
```


#### Endpoint Get 3583

```
[
  {
    "id": 3583,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3583-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "48438f57-c31f-4fab-aa6e-ad47e851fa47"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3583",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:20.867Z",
            "success-count": 2
          },
          "uuid": "7378d25e-cff1-4d1a-9a03-2c6d67becddf"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-hhnsr",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.866Z",
            "success-count": 1
          },
          "uuid": "aa4a5b7e-946f-44ed-a2d4-b5a2d62abe87"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3583",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.917Z",
            "success-count": 1
          },
          "uuid": "493b282e-bceb-415a-bc3a-bae8f082d023"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3583)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:50.912Z",
            "success-count": 41
          },
          "uuid": "aff0d687-f1a0-4084-a332-7591ebf43ce1"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "bd8a7df730ad1fd91f1657293007ec326e87bd61ce9fff928b040fafba6d0549:eth0",
        "container-id": "bd8a7df730ad1fd91f1657293007ec326e87bd61ce9fff928b040fafba6d0549",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-hhnsr",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-hhnsr"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 308620,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh4",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:26Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.3.0.75",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "82:41:39:0f:6c:74",
        "interface-index": 24,
        "interface-name": "lxc60f9b914b0c3",
        "mac": "5e:a2:ad:e9:f3:95"
      },
      "policy": {
        "proxy-policy-revision": 126,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 308620,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 126,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 308620,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 126
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3583

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3583

```
Timestamp              Status   State                   Message
2024-10-24T12:51:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 308620

```
ID       LABELS
308620   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh4
         k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=echo
         k8s:name=echo-same-node
         k8s:other=echo

```


#### Service list

```
ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.159.229:443 (active)   
                                        2 => 172.31.229.220:443 (active)   
2    10.100.75.60:443    ClusterIP      1 => 172.31.217.24:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.3.0.53:53 (active)         
                                        2 => 10.3.0.168:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.3.0.53:9153 (active)       
                                        2 => 10.3.0.168:9153 (active)      
5    10.100.84.20:2379   ClusterIP      1 => 10.3.0.23:2379 (active)       
6    10.100.201.9:8080   ClusterIP      1 => 10.3.0.75:8080 (active)       
```

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```

