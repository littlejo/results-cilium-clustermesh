32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:14+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:20:15+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:20:16+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:20:16+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:20:16+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:16+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:20:20+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:20:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:20:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:20:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:24:41+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
482: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:24:41+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
483: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:24:41+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
484: sched_cls  name tail_handle_ipv4  tag 19843125436f5c0e  gpl
	loaded_at 2024-10-24T12:24:41+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
500: sched_cls  name cil_from_container  tag 73c10de2b19cdf75  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 147
506: sched_cls  name tail_handle_ipv4  tag 08167b81a026a3a0  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 148
510: sched_cls  name tail_handle_ipv4_cont  tag 92f329c09cdf0fb1  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 156
511: sched_cls  name tail_ipv4_ct_ingress  tag 57f42edd91d6852e  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 157
512: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 158
513: sched_cls  name tail_handle_arp  tag e62574f5d031aafb  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 159
514: sched_cls  name __send_drop_notify  tag 4a0b29a5dac6c55c  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 160
515: sched_cls  name tail_ipv4_to_endpoint  tag 768f8425cbd7a898  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 161
516: sched_cls  name handle_policy  tag 42e435e290bedc48  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 162
517: sched_cls  name tail_ipv4_ct_egress  tag c6849b476654a979  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 163
518: sched_cls  name tail_handle_ipv4  tag 3e28d90c12846b47  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 165
520: sched_cls  name cil_from_container  tag b4db6541b3a65db5  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 167
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
522: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 168
525: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
526: sched_cls  name tail_handle_ipv4_cont  tag 1893200635ac9db1  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,110,40,37,38,81
	btf_id 169
527: sched_cls  name __send_drop_notify  tag 54fcfbc2caa43cf7  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 170
528: sched_cls  name tail_ipv4_ct_ingress  tag e78afd2044a0203a  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 171
529: sched_cls  name tail_ipv4_ct_egress  tag c6849b476654a979  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 172
530: sched_cls  name tail_ipv4_to_endpoint  tag 871e774b5c1a899f  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,110,40,37,38
	btf_id 173
531: sched_cls  name tail_handle_arp  tag b70d71e531b9b666  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 174
532: sched_cls  name handle_policy  tag ba951fd729638f63  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 175
533: sched_cls  name tail_handle_ipv4  tag a928d5524ac42f78  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 177
534: sched_cls  name tail_ipv4_to_endpoint  tag 72f9a1382c4af15d  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,113,41,82,83,80,101,39,112,40,37,38
	btf_id 178
535: sched_cls  name tail_handle_arp  tag 35889e865d68a653  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 179
536: sched_cls  name cil_from_container  tag 419a60fe11fd9dcb  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,76
	btf_id 180
537: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 181
538: sched_cls  name tail_ipv4_ct_ingress  tag 27c7c94879ed6894  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 182
540: sched_cls  name handle_policy  tag c553920f2ca6ae45  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,112,82,83,113,41,80,101,39,84,75,40,37,38
	btf_id 184
541: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 185
545: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
546: sched_cls  name __send_drop_notify  tag 2d5aef6fd95168e2  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
547: sched_cls  name tail_handle_ipv4_cont  tag 7b7e33a1af0ea818  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,113,41,101,82,83,39,76,74,77,112,40,37,38,81
	btf_id 187
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
557: sched_cls  name tail_handle_ipv4_from_host  tag d3f2cb53b6640496  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 190
558: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 191
559: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 192
560: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
561: sched_cls  name __send_drop_notify  tag f37a9b2fc4d0afe2  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
563: sched_cls  name tail_handle_ipv4_from_host  tag d3f2cb53b6640496  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 197
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 198
566: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
567: sched_cls  name __send_drop_notify  tag f37a9b2fc4d0afe2  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
571: sched_cls  name __send_drop_notify  tag f37a9b2fc4d0afe2  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
572: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 207
574: sched_cls  name tail_handle_ipv4_from_host  tag d3f2cb53b6640496  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 209
575: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 210
579: sched_cls  name __send_drop_notify  tag f37a9b2fc4d0afe2  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
580: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 216
582: sched_cls  name tail_handle_ipv4_from_host  tag d3f2cb53b6640496  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 218
583: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 219
623: sched_cls  name tail_ipv4_ct_egress  tag de6f794e97176fb4  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 233
625: sched_cls  name __send_drop_notify  tag b94e0c6f9558e8ac  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
626: sched_cls  name tail_handle_arp  tag fa647b1a5e70bec2  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 236
627: sched_cls  name tail_handle_ipv4  tag 00f69f4a0730a37f  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 237
628: sched_cls  name cil_from_container  tag 1fc9134acf8f6d2b  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 238
629: sched_cls  name tail_handle_ipv4_cont  tag 4b4c71b98e18e0c7  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 239
630: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 240
631: sched_cls  name handle_policy  tag e77492e6d6306a50  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 241
632: sched_cls  name tail_ipv4_ct_ingress  tag 63fdbfb7054ff6c5  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 242
633: sched_cls  name tail_ipv4_to_endpoint  tag 07a4140bc2fc38a7  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 243
634: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
637: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
673: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
676: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
688: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
691: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3286: sched_cls  name __send_drop_notify  tag e3d5f92de7edbf0b  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3077
3288: sched_cls  name tail_ipv4_ct_egress  tag 3c078fc98ff5481f  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3079
3289: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3080
3290: sched_cls  name tail_handle_ipv4  tag 95faa6ca0296c14d  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3081
3293: sched_cls  name cil_from_container  tag 8188661939b24c8c  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3086
3294: sched_cls  name handle_policy  tag ca84c2af07517610  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,153,39,84,75,40,37,38
	btf_id 3087
3296: sched_cls  name tail_handle_ipv4_cont  tag e2e30e1cf72cb347  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,153,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3088
3298: sched_cls  name tail_ipv4_to_endpoint  tag 409413c4b9d77c5a  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,153,39,627,40,37,38
	btf_id 3090
3299: sched_cls  name tail_handle_arp  tag 1899bdd5015a2eb1  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3092
3300: sched_cls  name tail_ipv4_ct_ingress  tag 5076a911fb5fe0f8  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3093
3341: sched_cls  name cil_from_container  tag a8ed77542ad4740f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3139
3342: sched_cls  name tail_ipv4_ct_egress  tag 90b0b61af73afdee  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3140
3343: sched_cls  name tail_ipv4_to_endpoint  tag cef71a3f0f023560  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,145,39,637,40,37,38
	btf_id 3138
3344: sched_cls  name tail_ipv4_to_endpoint  tag 8669c34fcb45ff28  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,149,39,640,40,37,38
	btf_id 3141
3345: sched_cls  name tail_handle_arp  tag f552a0893e466dca  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3143
3347: sched_cls  name tail_handle_ipv4_cont  tag b61f4370572c5289  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,149,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3145
3348: sched_cls  name tail_handle_ipv4  tag e2c3960916561f13  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3146
3349: sched_cls  name handle_policy  tag 45d859de0733681a  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,145,39,84,75,40,37,38
	btf_id 3142
3350: sched_cls  name cil_from_container  tag 2ac97de9687858e7  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3148
3351: sched_cls  name tail_handle_ipv4  tag f913efe7b4f935eb  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3149
3352: sched_cls  name handle_policy  tag 54cadbf7e36dd8d3  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,639,41,80,149,39,84,75,40,37,38
	btf_id 3147
3353: sched_cls  name __send_drop_notify  tag eddd7565808877eb  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3151
3354: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3152
3355: sched_cls  name tail_handle_arp  tag e36c1d6cccf02df3  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3150
3356: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3154
3357: sched_cls  name tail_ipv4_ct_ingress  tag 81d9dc2a32aef0ec  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3153
3359: sched_cls  name tail_ipv4_ct_ingress  tag bda8afe2015efeb4  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3156
3360: sched_cls  name tail_handle_ipv4_cont  tag e2159c1cb4a72693  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,145,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3157
3361: sched_cls  name tail_ipv4_ct_egress  tag 6eca06eb39611b29  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3158
3362: sched_cls  name __send_drop_notify  tag f191923ec96c993c  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3159
