Node 0, zone      DMA    127     42     25     50     27     15      6      4      1      3     41 
Node 0, zone   Normal    650     92     49     23     24     10      4      1      1      2      7 
