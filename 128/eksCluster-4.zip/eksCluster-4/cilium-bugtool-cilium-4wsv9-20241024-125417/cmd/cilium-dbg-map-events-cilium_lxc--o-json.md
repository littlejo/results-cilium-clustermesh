{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.148Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.611Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.661Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.672Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.714Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.727Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.756Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.041Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.093Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.138Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.215Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.238Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.868Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.895Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.948Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.978Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.050Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.301Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.325Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.358Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.381Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.411Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.035Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.052Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.105Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.110Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.153Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.154Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.155Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.446Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.451Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.507Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.516Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.554Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.160Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.160Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.244Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.259Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.320Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.518Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.523Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.584Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.621Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.631Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.029Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.082Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.096Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.135Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.154Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.394Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.401Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.467Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.487Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.524Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.946Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.974Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.024Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.041Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.041Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.070Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.379Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.425Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.511Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.535Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.562Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.934Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.963Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.977Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.013Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.040Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.056Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.322Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.324Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.378Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.403Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.425Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.824Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.880Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.897Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.962Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.969Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.006Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.198Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.205Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.290Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.300Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.341Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.714Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.724Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.776Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.795Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.822Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.050Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.074Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.115Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.119Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.174Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.494Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.527Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.540Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.581Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.618Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.619Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.903Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.923Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.992Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.048Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.101Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.319Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.355Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.368Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.410Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.434Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.456Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.676Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.683Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.711Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.717Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.740Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.482Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.484Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.529Z",
  "value": "id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.546Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.573Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.857Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.859Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:37.534Z",
  "value": "id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:37.549Z",
  "value": "id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B"
}

