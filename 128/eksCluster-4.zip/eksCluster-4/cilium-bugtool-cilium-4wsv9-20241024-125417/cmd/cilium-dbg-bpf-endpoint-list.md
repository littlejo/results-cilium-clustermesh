IP ADDRESS        LOCAL ENDPOINT INFO
10.4.0.100:0      id=2482  sec_id=332921 flags=0x0000 ifindex=14  mac=52:66:3B:E0:AE:16 nodemac=DA:1C:82:69:10:DC   
10.4.0.5:0        id=2258  sec_id=345420 flags=0x0000 ifindex=20  mac=72:1E:D7:21:15:97 nodemac=2E:C0:F8:68:FC:C6   
172.31.147.80:0   (localhost)                                                                                       
10.4.0.183:0      (localhost)                                                                                       
10.4.0.168:0      id=377   sec_id=4     flags=0x0000 ifindex=10  mac=6E:90:B8:1B:4A:7B nodemac=FE:40:C2:53:74:E0    
10.4.0.78:0       id=978   sec_id=358785 flags=0x0000 ifindex=24  mac=CA:B6:EA:A0:8B:29 nodemac=BE:FB:2E:85:DC:2B   
172.31.178.92:0   (localhost)                                                                                       
10.4.0.57:0       id=1191  sec_id=332921 flags=0x0000 ifindex=12  mac=86:76:77:06:3E:07 nodemac=02:C4:D3:3E:BA:5D   
10.4.0.114:0      id=3153  sec_id=355925 flags=0x0000 ifindex=22  mac=3A:FF:B9:B9:41:73 nodemac=8E:B0:E3:42:C3:DC   
10.4.0.9:0        id=1288  sec_id=333031 flags=0x0000 ifindex=18  mac=6E:E2:DE:DB:00:58 nodemac=DE:5E:C6:F6:B2:94   
