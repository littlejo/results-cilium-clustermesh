 12:54:19 up 34 min,  0 users,  load average: 0.43, 0.70, 0.42
