alloc: 124.45MB (130496064 bytes)
total-alloc: 3.10GB (3332111368 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75312143
frees: 73997134
heap-alloc: 124.45MB (130496064 bytes)
heap-sys: 172.36MB (180731904 bytes)
heap-idle: 29.05MB (30466048 bytes)
heap-in-use: 143.30MB (150265856 bytes)
heap-released: 6.66MB (6979584 bytes)
heap-objects: 1315009
stack-in-use: 35.59MB (37322752 bytes)
stack-sys: 35.59MB (37322752 bytes)
stack-mspan-inuse: 2.33MB (2444320 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 947.83KB (970577 bytes)
gc-sys: 5.56MB (5825800 bytes)
next-gc: when heap-alloc >= 155.38MB (162931528 bytes)
last-gc: 2024-10-24 12:54:19.129212107 +0000 UTC
gc-pause-total: 19.306697ms
gc-pause: 639350
gc-pause-end: 1729774459129212107
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.0005782800989241845
enable-gc: true
debug-gc: false
