top - 12:54:19 up 34 min,  0 users,  load average: 0.43, 0.70, 0.42
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.2 us, 31.0 sy,  0.0 ni, 51.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    311.0 free,   1028.7 used,   2496.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2626.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3148 root      20   0 1240432  16484  11420 S  13.3   0.4   0:00.03 cilium-+
      1 root      20   0 1539060 291756  78148 S   0.0   7.4   1:17.31 cilium-+
    406 root      20   0 1229744   9988   3836 S   0.0   0.3   0:04.47 cilium-+
   3154 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3194 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3213 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
