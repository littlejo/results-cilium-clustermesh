KEY             VALUE
AgentLiveness   2072907019157
UTimeOffset     3378461751953125
