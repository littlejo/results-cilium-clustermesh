qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc23a730885def root refcnt 2 
qdisc clsact ffff: dev lxc23a730885def parent ffff:fff1 
qdisc noqueue 0: dev lxc36b91af6589e root refcnt 2 
qdisc clsact ffff: dev lxc36b91af6589e parent ffff:fff1 
qdisc noqueue 0: dev lxcb392a1fdf74e root refcnt 2 
qdisc clsact ffff: dev lxcb392a1fdf74e parent ffff:fff1 
qdisc noqueue 0: dev lxcdc604791c360 root refcnt 2 
qdisc clsact ffff: dev lxcdc604791c360 parent ffff:fff1 
qdisc noqueue 0: dev lxcf881b02ad150 root refcnt 2 
qdisc clsact ffff: dev lxcf881b02ad150 parent ffff:fff1 
qdisc noqueue 0: dev lxcb489470b641d root refcnt 2 
qdisc clsact ffff: dev lxcb489470b641d parent ffff:fff1 
