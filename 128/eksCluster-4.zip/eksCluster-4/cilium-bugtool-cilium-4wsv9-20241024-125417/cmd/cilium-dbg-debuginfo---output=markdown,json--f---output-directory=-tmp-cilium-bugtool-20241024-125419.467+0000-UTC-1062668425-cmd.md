markdown output at /tmp/cilium-bugtool-20241024-125419.467+0000-UTC-1062668425/cmd/cilium-debuginfo-20241024-125450.179+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125419.467+0000-UTC-1062668425/cmd/cilium-debuginfo-20241024-125450.179+0000-UTC.json
