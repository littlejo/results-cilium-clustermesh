filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf881b02ad150 direct-action not_in_hw id 3262 tag 9d7ce8da9454ef35 jited 
