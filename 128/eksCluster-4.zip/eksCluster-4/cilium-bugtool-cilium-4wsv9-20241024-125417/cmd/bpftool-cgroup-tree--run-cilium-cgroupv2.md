CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod334eb88f_f7ab_4848_8181_0c7dfa73111e.slice/cri-containerd-d6aad40de3631cfb1f4986d0cafc6add742b08e98c3190ba0d302d529c94a70a.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod334eb88f_f7ab_4848_8181_0c7dfa73111e.slice/cri-containerd-76bfbdf22a4230be465f1e3b9734624dbc5a921287484b80c40c7d5998dc6567.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfdb85ce0_88db_458f_9d4a_b978ff69d772.slice/cri-containerd-c0d4c734498a5718b20be1d50d3d2a854bf06a4e996a4bd4ed2d0aa04a77ddf3.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfdb85ce0_88db_458f_9d4a_b978ff69d772.slice/cri-containerd-78653c3f5932fb781b84fceee36d9959432efc0c9fa786b738d5a95db1bec379.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03f16fa1_b2f5_48f8_91d9_c3e21f715d56.slice/cri-containerd-c22709d9a38ccaf82be7d6baed9377917cf5cc43b90e942f439b9e3dbaf96d66.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03f16fa1_b2f5_48f8_91d9_c3e21f715d56.slice/cri-containerd-9f5c5480e9e24a7c87ce8b17c94c4c29da9992da767517f3b139181bf376156e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8460ed32_038c_4a3a_989a_afa52c85e638.slice/cri-containerd-481dece10ad40ce7c62692e1bacc0cdb18d83295b6c68ad7ad2d1993e5618a2c.scope
    51       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8460ed32_038c_4a3a_989a_afa52c85e638.slice/cri-containerd-947a01e332735e239714eea7850cd1d23f77c08abc37538ad1f350aad34b2750.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8224915_2288_400e_9bd9_9a3a20773084.slice/cri-containerd-4f412381a53a8cb8e0f282775952bfbc8fadbbaa6784de81a5b1970c4519db5f.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8224915_2288_400e_9bd9_9a3a20773084.slice/cri-containerd-4b4146f585322eef363a288e33c290c44f1bbb7a6ff97d5d89c51f92a304f85f.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4da3ac86_fbe7_438f_a301_e472f40b8012.slice/cri-containerd-d8247ab2a217926682edcf8c7997dbd83906ff9f3903710d7d8c91ca24eb541b.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4da3ac86_fbe7_438f_a301_e472f40b8012.slice/cri-containerd-52f082db42a86536c811c160d5495ebedbf59b645a531fcb8a4309fdd9fac0a4.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod923635ee_0d4a_46d6_825b_84c4378d9fc9.slice/cri-containerd-f10b5b01c7d05b6b25d824a1a7d2473f2fb458f60e11f52590c06a05a7256c48.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod923635ee_0d4a_46d6_825b_84c4378d9fc9.slice/cri-containerd-70ccfe4f7921cd0f30e7e1bd9c1bf34cbcd4139e6aa6097d29fd50e2ebf03355.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36e612df_7c2a_4a5d_a22c_c2065602e865.slice/cri-containerd-b6e2e91777db71a156d8885109e387e1261b0586f689ed1a23e797ec55baf167.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36e612df_7c2a_4a5d_a22c_c2065602e865.slice/cri-containerd-e894093fad2be2de82558dff317e0f68f3ec0645e08188fe461803a07a982385.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73f29bbe_bd1a_459b_8142_a75156f436e9.slice/cri-containerd-1e103c4555d7572c181f1625815cde5a41af151d0b3f7a06a78ec09cf057f364.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73f29bbe_bd1a_459b_8142_a75156f436e9.slice/cri-containerd-db9b7a400d3cec78ae7cc49f2c1944d32394276df467fc52eb536f07557b89b8.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73f29bbe_bd1a_459b_8142_a75156f436e9.slice/cri-containerd-f90a40e0eb9263faec74ddce8a9b9b515aedeb29c54d05093299e57ed715a360.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f94a66d_8df9_427a_af15_0a8a80a8b835.slice/cri-containerd-c60de2eae3d812a3f63bdc77ad2bcd3cfbc9ed9cf0f434c5b5601107d9ab2d37.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f94a66d_8df9_427a_af15_0a8a80a8b835.slice/cri-containerd-c17cbd2b5ca91668a07dac72837376f7b7f14c8116a0d011270cad476cf782ea.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f94a66d_8df9_427a_af15_0a8a80a8b835.slice/cri-containerd-aa3756a80008016b3809d02df40fc77d604412f8c5ebc908183acc6aa673614f.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f94a66d_8df9_427a_af15_0a8a80a8b835.slice/cri-containerd-8c09e68552154f6725b05fffb7c25d232505fbc8a33e5f3fb59be0efeeab7d51.scope
    634      cgroup_device   multi                                          
