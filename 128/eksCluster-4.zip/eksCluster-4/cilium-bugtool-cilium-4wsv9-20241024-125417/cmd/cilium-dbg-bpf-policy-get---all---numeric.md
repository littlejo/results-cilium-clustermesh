Endpoint ID: 377
Path: /sys/fs/bpf/tc/globals/cilium_policy_00377

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6205386   76803     0        
Allow    Ingress     1          ANY          NONE         disabled    65879     794       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 978
Path: /sys/fs/bpf/tc/globals/cilium_policy_00978

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1191
Path: /sys/fs/bpf/tc/globals/cilium_policy_01191

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2064     22        0        
Allow    Ingress     1          ANY          NONE         disabled    171514   1974      0        
Allow    Egress      0          ANY          NONE         disabled    21647    243       0        


Endpoint ID: 1235
Path: /sys/fs/bpf/tc/globals/cilium_policy_01235

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1288
Path: /sys/fs/bpf/tc/globals/cilium_policy_01288

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6052461   61262     0        
Allow    Ingress     1          ANY          NONE         disabled    5362416   56559     0        
Allow    Egress      0          ANY          NONE         disabled    7209149   70912     0        


Endpoint ID: 2258
Path: /sys/fs/bpf/tc/globals/cilium_policy_02258

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2482
Path: /sys/fs/bpf/tc/globals/cilium_policy_02482

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3832     38        0        
Allow    Ingress     1          ANY          NONE         disabled    172399   1982      0        
Allow    Egress      0          ANY          NONE         disabled    22161    250       0        


Endpoint ID: 3153
Path: /sys/fs/bpf/tc/globals/cilium_policy_03153

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    375686   4387      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


