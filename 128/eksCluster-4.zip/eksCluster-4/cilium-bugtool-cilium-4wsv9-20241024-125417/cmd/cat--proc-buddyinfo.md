Node 0, zone      DMA      2     12     36     43     23     10      7      4      2      3     46 
Node 0, zone   Normal   1418    265    146     37      5      2      1      2      5      2      5 
