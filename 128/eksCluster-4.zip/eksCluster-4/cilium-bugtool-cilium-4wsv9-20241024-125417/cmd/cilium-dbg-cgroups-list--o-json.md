[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod334eb88f_f7ab_4848_8181_0c7dfa73111e.slice/cri-containerd-d6aad40de3631cfb1f4986d0cafc6add742b08e98c3190ba0d302d529c94a70a.scope"
      }
    ],
    "ips": [
      "10.4.0.100"
    ],
    "name": "coredns-cc6ccd49c-4b2fl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfdb85ce0_88db_458f_9d4a_b978ff69d772.slice/cri-containerd-78653c3f5932fb781b84fceee36d9959432efc0c9fa786b738d5a95db1bec379.scope"
      }
    ],
    "ips": [
      "10.4.0.57"
    ],
    "name": "coredns-cc6ccd49c-45wfb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4da3ac86_fbe7_438f_a301_e472f40b8012.slice/cri-containerd-52f082db42a86536c811c160d5495ebedbf59b645a531fcb8a4309fdd9fac0a4.scope"
      }
    ],
    "ips": [
      "10.4.0.5"
    ],
    "name": "client-974f6c69d-zl2js",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73f29bbe_bd1a_459b_8142_a75156f436e9.slice/cri-containerd-1e103c4555d7572c181f1625815cde5a41af151d0b3f7a06a78ec09cf057f364.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73f29bbe_bd1a_459b_8142_a75156f436e9.slice/cri-containerd-db9b7a400d3cec78ae7cc49f2c1944d32394276df467fc52eb536f07557b89b8.scope"
      }
    ],
    "ips": [
      "10.4.0.114"
    ],
    "name": "echo-same-node-86d9cc975c-w69zh",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8224915_2288_400e_9bd9_9a3a20773084.slice/cri-containerd-4f412381a53a8cb8e0f282775952bfbc8fadbbaa6784de81a5b1970c4519db5f.scope"
      }
    ],
    "ips": [
      "10.4.0.78"
    ],
    "name": "client2-57cf4468f-wm8ll",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f94a66d_8df9_427a_af15_0a8a80a8b835.slice/cri-containerd-aa3756a80008016b3809d02df40fc77d604412f8c5ebc908183acc6aa673614f.scope"
      },
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f94a66d_8df9_427a_af15_0a8a80a8b835.slice/cri-containerd-c60de2eae3d812a3f63bdc77ad2bcd3cfbc9ed9cf0f434c5b5601107d9ab2d37.scope"
      },
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f94a66d_8df9_427a_af15_0a8a80a8b835.slice/cri-containerd-c17cbd2b5ca91668a07dac72837376f7b7f14c8116a0d011270cad476cf782ea.scope"
      }
    ],
    "ips": [
      "10.4.0.9"
    ],
    "name": "clustermesh-apiserver-6785459d4b-trvkk",
    "namespace": "kube-system"
  }
]

