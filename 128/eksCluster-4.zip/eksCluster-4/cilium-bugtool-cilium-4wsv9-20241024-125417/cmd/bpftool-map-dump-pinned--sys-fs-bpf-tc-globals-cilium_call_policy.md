key: 79 01 00 00  value: 0c 02 00 00
key: d2 03 00 00  value: 05 0d 00 00
key: a7 04 00 00  value: 1f 02 00 00
key: 08 05 00 00  value: 6e 02 00 00
key: d2 08 00 00  value: 04 0d 00 00
key: b2 09 00 00  value: fb 01 00 00
key: 51 0c 00 00  value: ca 0c 00 00
Found 7 elements
