xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 567
ens6(5) clsact/ingress cil_from_netdev-ens6 id 575
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 562
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 557
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 529
lxc23a730885def(12) clsact/ingress cil_from_container-lxc23a730885def id 533
lxc36b91af6589e(14) clsact/ingress cil_from_container-lxc36b91af6589e id 508
lxcb392a1fdf74e(18) clsact/ingress cil_from_container-lxcb392a1fdf74e id 627
lxcdc604791c360(20) clsact/ingress cil_from_container-lxcdc604791c360 id 3329
lxcf881b02ad150(22) clsact/ingress cil_from_container-lxcf881b02ad150 id 3262
lxcb489470b641d(24) clsact/ingress cil_from_container-lxcb489470b641d id 3317

flow_dissector:

netfilter:

