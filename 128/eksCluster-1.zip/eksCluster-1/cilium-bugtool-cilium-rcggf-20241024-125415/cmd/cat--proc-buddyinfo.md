Node 0, zone      DMA      2      0      4      2      2      5     14      4      2      1     50 
Node 0, zone   Normal    571    159     25     19     27      8      1      3      3      1      7 
