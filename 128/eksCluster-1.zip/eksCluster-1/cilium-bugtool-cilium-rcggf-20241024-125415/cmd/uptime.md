 12:54:16 up 34 min,  0 users,  load average: 0.72, 0.77, 0.46
