IP ADDRESS         LOCAL ENDPOINT INFO
10.1.0.112:0       id=2497  sec_id=183673 flags=0x0000 ifindex=12  mac=B6:4B:AC:F4:F9:09 nodemac=DE:D0:05:43:10:AC   
10.1.0.27:0        id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15   
10.1.0.17:0        id=254   sec_id=4     flags=0x0000 ifindex=10  mac=E2:4E:11:B7:96:97 nodemac=56:06:A5:1E:E9:AF    
10.1.0.101:0       (localhost)                                                                                       
172.31.246.143:0   (localhost)                                                                                       
10.1.0.28:0        id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50   
10.1.0.153:0       id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26   
172.31.242.222:0   (localhost)                                                                                       
10.1.0.152:0       id=849   sec_id=183673 flags=0x0000 ifindex=14  mac=EA:AF:5A:DE:A6:C0 nodemac=0A:98:8F:0A:82:40   
10.1.0.232:0       id=2104  sec_id=142268 flags=0x0000 ifindex=18  mac=BE:90:93:8B:32:DF nodemac=82:57:97:D2:36:37   
