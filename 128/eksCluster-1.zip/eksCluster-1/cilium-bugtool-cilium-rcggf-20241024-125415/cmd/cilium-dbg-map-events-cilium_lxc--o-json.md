{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.792Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.880Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.902Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.945Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.512Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.522Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.565Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.592Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.623Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.864Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.887Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.956Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.984Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.041Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.709Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.750Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.762Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.823Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.838Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.115Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.125Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.228Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.813Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.814Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.875Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.902Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.930Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.950Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.971Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.240Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.249Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.304Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.339Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.363Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.950Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.958Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.984Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.034Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.054Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.105Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.117Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.347Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.352Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.418Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.422Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.533Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.068Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.074Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.125Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.142Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.179Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.416Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.431Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.485Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.503Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.555Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.078Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.086Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.155Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.158Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.193Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.452Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.471Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.511Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.533Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.618Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.009Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.019Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.084Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.098Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.123Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.343Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.358Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.423Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.441Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.480Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.899Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.925Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.972Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.013Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.014Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.260Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.273Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.318Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.410Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.442Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.825Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.862Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.884Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.920Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.934Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.988Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.244Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.252Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.311Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.325Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.330Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.626Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.665Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.674Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.737Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.744Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.776Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.052Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.056Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.096Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.150Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.156Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.460Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.544Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.556Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.638Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.645Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.673Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.903Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.912Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.919Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.931Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.958Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.735Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.738Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.783Z",
  "value": "id=1570  sec_id=132874 flags=0x0000 ifindex=20  mac=92:B2:18:99:CA:40 nodemac=F2:14:D6:8D:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.809Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.835Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.139Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.149Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.850Z",
  "value": "id=2125  sec_id=183315 flags=0x0000 ifindex=22  mac=9A:A9:60:BE:9B:BC nodemac=A6:A6:8A:69:5F:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.863Z",
  "value": "id=3390  sec_id=153763 flags=0x0000 ifindex=24  mac=46:07:54:AF:CA:6F nodemac=5A:C5:5B:18:54:50"
}

