alloc: 117.40MB (123104656 bytes)
total-alloc: 3.07GB (3292367840 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 74776308
frees: 73482172
heap-alloc: 117.40MB (123104656 bytes)
heap-sys: 176.41MB (184983552 bytes)
heap-idle: 43.42MB (45531136 bytes)
heap-in-use: 132.99MB (139452416 bytes)
heap-released: 9.93MB (10412032 bytes)
heap-objects: 1294136
stack-in-use: 35.56MB (37289984 bytes)
stack-sys: 35.56MB (37289984 bytes)
stack-mspan-inuse: 2.22MB (2326080 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 731.97KB (749537 bytes)
gc-sys: 5.52MB (5784768 bytes)
next-gc: when heap-alloc >= 151.75MB (159116632 bytes)
last-gc: 2024-10-24 12:54:17.312000747 +0000 UTC
gc-pause-total: 20.344036ms
gc-pause: 101094
gc-pause-end: 1729774457312000747
num-gc: 103
num-forced-gc: 0
gc-cpu-fraction: 0.0006189662666826856
enable-gc: true
debug-gc: false
