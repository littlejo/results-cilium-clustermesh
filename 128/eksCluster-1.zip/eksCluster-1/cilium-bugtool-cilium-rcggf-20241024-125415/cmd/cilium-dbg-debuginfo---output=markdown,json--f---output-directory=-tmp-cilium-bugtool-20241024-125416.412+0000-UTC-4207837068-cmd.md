markdown output at /tmp/cilium-bugtool-20241024-125416.412+0000-UTC-4207837068/cmd/cilium-debuginfo-20241024-125447.26+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.412+0000-UTC-4207837068/cmd/cilium-debuginfo-20241024-125447.26+0000-UTC.json
