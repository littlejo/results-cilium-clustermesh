CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode2c822f4_2e89_4ef0_8e7d_aedc76995447.slice/cri-containerd-dd3ddf72dc52d02e3ab534482f58eef5e7a7bbb7969769d146bfe9ed15c345ab.scope
    608      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode2c822f4_2e89_4ef0_8e7d_aedc76995447.slice/cri-containerd-d10c5ff6181be22f9b0c2f1a56bac1a2c0eae3e0b57a85fae7714c3b7ef7a0ee.scope
    604      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ffe506b_e5d1_4880_9b59_45d581ff9941.slice/cri-containerd-3ad1aa9aadcbde8410d3aa39812d68377907905ac54ba8f6296b6496fd51b1ba.scope
    492      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ffe506b_e5d1_4880_9b59_45d581ff9941.slice/cri-containerd-41862dae146d8998fb47d479c88fd4d7c1469db4310d770fa97ae9339e5eb554.scope
    496      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95839acb_7ce7_41ac_8f67_6bcf3837e789.slice/cri-containerd-fe45e40285eda22d77da553244d9f759d5b05f0bbe2964fb56ee1fa7cc12759a.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95839acb_7ce7_41ac_8f67_6bcf3837e789.slice/cri-containerd-2008e9caf6ebcdb8a683e151c432c35cf4db3063a0d25b9ae97cb85a38787c15.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7780e6b7_e466_4429_ae39_7edc33eafe9e.slice/cri-containerd-2fbd1c515043459d29627abf18ec4f48198aaa06d1be8fe3be8a10c2781c8061.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7780e6b7_e466_4429_ae39_7edc33eafe9e.slice/cri-containerd-48ffdf48b8b76e364dae1c5be5a002043b72fe58400fed297a20f2ee8297054c.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd071e1f_f122_49e8_8d7f_307d15109e39.slice/cri-containerd-3355553a0cf7b80a3d049074c45e9215fd01f9feb75ac9d2d57fb56923ada1dd.scope
    743      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd071e1f_f122_49e8_8d7f_307d15109e39.slice/cri-containerd-318f65aab61812817bc5354dab85dce62caf5b447f3fe731a4c74b2d63110761.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd071e1f_f122_49e8_8d7f_307d15109e39.slice/cri-containerd-26b3a3f8e2c7c167a8c145942f03964f739fd0358587826b0491ac40b6a17159.scope
    747      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5695b6b8_362d_4ce9_97a4_6c874a3021ed.slice/cri-containerd-4e034d8058f467702938ba50c6814a65b5d579862fb0676510574412d5794234.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5695b6b8_362d_4ce9_97a4_6c874a3021ed.slice/cri-containerd-f05cffa4d44db2ba7022b394257a259ec8151b9008297937b5bab20c444f8b83.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca23bb30_17e7_4bd9_8028_c7dd328246b1.slice/cri-containerd-ab6879152bef630d5923ff5b508d158ea874873548564b8c5ccf75d38784036d.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca23bb30_17e7_4bd9_8028_c7dd328246b1.slice/cri-containerd-aa89e1d86b34e417b72c5b944bf9cd3187c1e0e3c553317e3256b92cd1909545.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58f3f44c_83ac_416f_9391_1cf87fd38ba3.slice/cri-containerd-5675e3ea39fa63a0c750fef92a9ddb1d139871d82978c5b0cdfc9e41d60e3bb8.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58f3f44c_83ac_416f_9391_1cf87fd38ba3.slice/cri-containerd-813cd4125015927f6f1d362159bdd399364fda9c4d76cb4979e9af2e3114876f.scope
    662      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58f3f44c_83ac_416f_9391_1cf87fd38ba3.slice/cri-containerd-0cd770d9673c889702c96b0fbdd1015b65da767b63e6a4bf4711333b290bdd07.scope
    682      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58f3f44c_83ac_416f_9391_1cf87fd38ba3.slice/cri-containerd-99c98e5074c1524846f43ca666fd84b3c4d911ef96c2d96dec271471dfb7de68.scope
    686      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfba70552_c7cc_484b_8510_040d4ae56ebe.slice/cri-containerd-ac1086dfc31d1d6093ecdaf305feb4ab9a31371810220472d655846be9dc3641.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfba70552_c7cc_484b_8510_040d4ae56ebe.slice/cri-containerd-baca8169c8d493ee4add09083c5c3245bfe8bd35cd2190220e00511c155e7b7c.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0950f69f_906c_479c_aa24_3c64b4e925df.slice/cri-containerd-9ea3135b7375b1c221cf76c48a6896e8e7714412e407d3e211b826d6e8c63b6a.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0950f69f_906c_479c_aa24_3c64b4e925df.slice/cri-containerd-a5c65e98dd8cad3afb2b458d1eecd507510822b08a53699b0974879eb6aa8731.scope
    107      cgroup_device   multi                                          
