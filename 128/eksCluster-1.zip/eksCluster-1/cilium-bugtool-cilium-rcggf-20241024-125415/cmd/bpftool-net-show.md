xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 575
ens6(5) clsact/ingress cil_from_netdev-ens6 id 578
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 555
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 498
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 499
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 599
lxc0b2119e9f3ff(12) clsact/ingress cil_from_container-lxc0b2119e9f3ff id 542
lxc7b373a155765(14) clsact/ingress cil_from_container-lxc7b373a155765 id 586
lxca9860f026f49(18) clsact/ingress cil_from_container-lxca9860f026f49 id 650
lxc323c0fca7e62(20) clsact/ingress cil_from_container-lxc323c0fca7e62 id 3282
lxcf3e2950465bd(22) clsact/ingress cil_from_container-lxcf3e2950465bd id 3335
lxc0410a3de7325(24) clsact/ingress cil_from_container-lxc0410a3de7325 id 3337

flow_dissector:

netfilter:

