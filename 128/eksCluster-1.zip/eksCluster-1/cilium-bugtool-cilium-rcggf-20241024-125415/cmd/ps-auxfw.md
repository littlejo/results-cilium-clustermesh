USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3316  2.0  0.3 1240432 15348 ?       Dsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3330  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3332  0.0  0.3 1240432 15348 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  4.3  7.4 1538804 293688 ?      Ssl  12:24   1:18 cilium-agent --config-dir=/tmp/cilium/config-map
root         421  0.2  0.2 1229744 8680 ?        Sl   12:24   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
