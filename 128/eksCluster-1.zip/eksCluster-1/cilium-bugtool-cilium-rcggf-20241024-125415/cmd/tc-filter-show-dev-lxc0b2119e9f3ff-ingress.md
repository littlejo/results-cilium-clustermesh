filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc0b2119e9f3ff direct-action not_in_hw id 542 tag cab5165a4e4a1dc8 jited 
