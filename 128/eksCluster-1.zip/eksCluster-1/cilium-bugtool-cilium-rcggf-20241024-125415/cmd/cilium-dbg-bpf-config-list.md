KEY             VALUE
AgentLiveness   2078425602244
UTimeOffset     3378461736328125
