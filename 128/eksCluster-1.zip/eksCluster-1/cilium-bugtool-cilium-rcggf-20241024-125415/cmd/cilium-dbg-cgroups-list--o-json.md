[
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5695b6b8_362d_4ce9_97a4_6c874a3021ed.slice/cri-containerd-f05cffa4d44db2ba7022b394257a259ec8151b9008297937b5bab20c444f8b83.scope"
      }
    ],
    "ips": [
      "10.1.0.28"
    ],
    "name": "client-974f6c69d-fshqf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7457,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ffe506b_e5d1_4880_9b59_45d581ff9941.slice/cri-containerd-41862dae146d8998fb47d479c88fd4d7c1469db4310d770fa97ae9339e5eb554.scope"
      }
    ],
    "ips": [
      "10.1.0.112"
    ],
    "name": "coredns-cc6ccd49c-fl89b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58f3f44c_83ac_416f_9391_1cf87fd38ba3.slice/cri-containerd-5675e3ea39fa63a0c750fef92a9ddb1d139871d82978c5b0cdfc9e41d60e3bb8.scope"
      },
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58f3f44c_83ac_416f_9391_1cf87fd38ba3.slice/cri-containerd-99c98e5074c1524846f43ca666fd84b3c4d911ef96c2d96dec271471dfb7de68.scope"
      },
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58f3f44c_83ac_416f_9391_1cf87fd38ba3.slice/cri-containerd-0cd770d9673c889702c96b0fbdd1015b65da767b63e6a4bf4711333b290bdd07.scope"
      }
    ],
    "ips": [
      "10.1.0.232"
    ],
    "name": "clustermesh-apiserver-5497d4ddbf-st9tg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd071e1f_f122_49e8_8d7f_307d15109e39.slice/cri-containerd-3355553a0cf7b80a3d049074c45e9215fd01f9feb75ac9d2d57fb56923ada1dd.scope"
      },
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd071e1f_f122_49e8_8d7f_307d15109e39.slice/cri-containerd-26b3a3f8e2c7c167a8c145942f03964f739fd0358587826b0491ac40b6a17159.scope"
      }
    ],
    "ips": [
      "10.1.0.153"
    ],
    "name": "echo-same-node-86d9cc975c-qztfd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7709,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode2c822f4_2e89_4ef0_8e7d_aedc76995447.slice/cri-containerd-dd3ddf72dc52d02e3ab534482f58eef5e7a7bbb7969769d146bfe9ed15c345ab.scope"
      }
    ],
    "ips": [
      "10.1.0.152"
    ],
    "name": "coredns-cc6ccd49c-tbhdp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfba70552_c7cc_484b_8510_040d4ae56ebe.slice/cri-containerd-baca8169c8d493ee4add09083c5c3245bfe8bd35cd2190220e00511c155e7b7c.scope"
      }
    ],
    "ips": [
      "10.1.0.27"
    ],
    "name": "client2-57cf4468f-ksz9q",
    "namespace": "cilium-test-1"
  }
]

