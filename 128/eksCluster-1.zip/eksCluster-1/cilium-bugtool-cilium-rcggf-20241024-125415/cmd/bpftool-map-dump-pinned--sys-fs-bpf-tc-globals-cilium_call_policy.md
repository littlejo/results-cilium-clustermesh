key: fe 00 00 00  value: 58 02 00 00
key: 51 03 00 00  value: 2c 02 00 00
key: 22 06 00 00  value: d0 0c 00 00
key: 38 08 00 00  value: 8e 02 00 00
key: 4d 08 00 00  value: 17 0d 00 00
key: c1 09 00 00  value: 19 02 00 00
key: 3e 0d 00 00  value: 1a 0d 00 00
Found 7 elements
