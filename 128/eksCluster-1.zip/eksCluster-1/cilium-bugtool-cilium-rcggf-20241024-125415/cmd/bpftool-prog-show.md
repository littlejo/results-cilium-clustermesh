29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:20:13+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:20:14+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:20:14+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:20:14+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:14+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:20:18+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:20:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:20:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:20:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
104: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
107: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
489: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
492: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
493: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
496: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
497: sched_cls  name tail_handle_ipv4  tag b3d53435fd07449f  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 136
498: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 137
499: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 138
500: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:24:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 139
530: sched_cls  name tail_ipv4_ct_egress  tag 503120e9abd24a71  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,117,84
	btf_id 175
531: sched_cls  name __send_drop_notify  tag 61660831b3089bb8  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 177
533: sched_cls  name tail_handle_ipv4_cont  tag ee48ac426725efdf  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,117,41,91,82,83,39,76,74,77,116,40,37,38,81
	btf_id 178
537: sched_cls  name handle_policy  tag fb5c6e896c10b202  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,117,41,80,91,39,84,75,40,37,38
	btf_id 180
541: sched_cls  name tail_ipv4_ct_ingress  tag e08b8b7a39b5a2e9  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,117,84
	btf_id 185
542: sched_cls  name cil_from_container  tag cab5165a4e4a1dc8  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 188
543: sched_cls  name tail_handle_arp  tag 601f8e987d03b032  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 189
548: sched_cls  name tail_handle_ipv4  tag d54da530a8dee60e  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 191
549: sched_cls  name __send_drop_notify  tag 06488c603adf19d3  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 196
550: sched_cls  name tail_handle_ipv4_cont  tag 86443f7055fcb653  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,119,41,118,82,83,39,76,74,77,120,40,37,38,81
	btf_id 197
552: sched_cls  name tail_ipv4_to_endpoint  tag def4d3bf93b806c1  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,117,41,82,83,80,91,39,116,40,37,38
	btf_id 194
553: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 200
555: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,122
	btf_id 203
556: sched_cls  name handle_policy  tag 1a04623aa092be0f  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,120,82,83,119,41,80,118,39,84,75,40,37,38
	btf_id 199
557: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 204
559: sched_cls  name __send_drop_notify  tag 7249e53fad2bcce0  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
560: sched_cls  name tail_handle_ipv4_from_host  tag ff78d992a7682e0a  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 208
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 209
563: sched_cls  name __send_drop_notify  tag 7249e53fad2bcce0  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
564: sched_cls  name tail_ipv4_ct_egress  tag 503120e9abd24a71  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,120,82,83,119,84
	btf_id 206
565: sched_cls  name tail_handle_ipv4_from_host  tag ff78d992a7682e0a  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 213
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 214
569: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 218
570: sched_cls  name tail_handle_ipv4_from_host  tag ff78d992a7682e0a  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,126
	btf_id 220
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,126
	btf_id 221
575: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,126,75
	btf_id 225
576: sched_cls  name __send_drop_notify  tag 7249e53fad2bcce0  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 226
577: sched_cls  name tail_ipv4_ct_ingress  tag c801cdac199b49d2  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,120,82,83,119,84
	btf_id 216
578: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,128,75
	btf_id 228
579: sched_cls  name __send_drop_notify  tag 7249e53fad2bcce0  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
580: sched_cls  name tail_handle_ipv4_from_host  tag ff78d992a7682e0a  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,128
	btf_id 231
581: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,128
	btf_id 232
585: sched_cls  name tail_ipv4_to_endpoint  tag 9ea53a104197fbd1  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,119,41,82,83,80,118,39,120,40,37,38
	btf_id 229
586: sched_cls  name cil_from_container  tag 44237f5010a156fb  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 120,76
	btf_id 238
587: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,120
	btf_id 239
588: sched_cls  name tail_handle_arp  tag 3c173b0f27db0c07  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,120
	btf_id 240
589: sched_cls  name tail_handle_ipv4  tag 85ba7fc4e098fc1c  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,120
	btf_id 241
590: sched_cls  name tail_ipv4_to_endpoint  tag 0abf977762756e45  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,129,41,82,83,80,105,39,130,40,37,38
	btf_id 237
591: sched_cls  name __send_drop_notify  tag 9d61a90147174701  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 242
592: sched_cls  name tail_ipv4_ct_ingress  tag cf7c1ecdc9680f0f  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,130,82,83,129,84
	btf_id 243
593: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,130,82,83,129,84
	btf_id 244
594: sched_cls  name tail_handle_arp  tag 61ca6d8aa165736d  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,130
	btf_id 245
595: sched_cls  name tail_handle_ipv4_cont  tag 2a348b434734ab29  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,129,41,105,82,83,39,76,74,77,130,40,37,38,81
	btf_id 246
596: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,130
	btf_id 247
597: sched_cls  name tail_handle_ipv4  tag 295a4b80de8e5b91  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,130
	btf_id 248
599: sched_cls  name cil_from_container  tag 28f8e56fb9b1562d  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 130,76
	btf_id 250
600: sched_cls  name handle_policy  tag 9375be89787360b5  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,130,82,83,129,41,80,105,39,84,75,40,37,38
	btf_id 251
601: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
604: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
605: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
608: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
648: sched_cls  name tail_handle_ipv4  tag 05c31ab9774a6a74  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,144
	btf_id 265
650: sched_cls  name cil_from_container  tag b33e9e823269a46b  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 144,76
	btf_id 267
651: sched_cls  name tail_handle_ipv4_cont  tag 08e0dd0a7b10ddec  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,145,41,143,82,83,39,76,74,77,144,40,37,38,81
	btf_id 268
652: sched_cls  name tail_ipv4_ct_egress  tag 3273fd5df62d76cc  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,144,82,83,145,84
	btf_id 269
653: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,144
	btf_id 270
654: sched_cls  name handle_policy  tag 8d60384647aa675d  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,144,82,83,145,41,80,143,39,84,75,40,37,38
	btf_id 271
655: sched_cls  name tail_ipv4_to_endpoint  tag 272e5d15afd94918  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,145,41,82,83,80,143,39,144,40,37,38
	btf_id 272
656: sched_cls  name tail_handle_arp  tag 3c55188aed23ef63  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,144
	btf_id 273
657: sched_cls  name __send_drop_notify  tag e632fc5cd9d4c51a  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 274
658: sched_cls  name tail_ipv4_ct_ingress  tag c772a4395147c233  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,144,82,83,145,84
	btf_id 275
659: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
662: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
679: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
682: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
683: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
686: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
720: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
723: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
724: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
727: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
728: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
731: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
732: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
735: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
736: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
739: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
740: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
743: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
744: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
747: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3278: sched_cls  name tail_ipv4_ct_egress  tag 1ddd59ae84e9b77b  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,629,82,83,630,84
	btf_id 3073
3279: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,629
	btf_id 3074
3280: sched_cls  name handle_policy  tag fbbdbf363dfad922  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,629,82,83,630,41,80,153,39,84,75,40,37,38
	btf_id 3075
3281: sched_cls  name tail_handle_arp  tag d215b27995f9530e  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,629
	btf_id 3076
3282: sched_cls  name cil_from_container  tag 8a34f2b7e90c4eea  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 629,76
	btf_id 3077
3283: sched_cls  name __send_drop_notify  tag 3f18a63781521585  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3078
3285: sched_cls  name tail_handle_ipv4_cont  tag ed6eaebc3255314b  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,630,41,153,82,83,39,76,74,77,629,40,37,38,81
	btf_id 3079
3288: sched_cls  name tail_handle_ipv4  tag 0460776ea5470123  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,629
	btf_id 3084
3289: sched_cls  name tail_ipv4_ct_ingress  tag b19bff07d7fa4074  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,629,82,83,630,84
	btf_id 3086
3292: sched_cls  name tail_ipv4_to_endpoint  tag 637a6c3fc5fe7cd2  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,630,41,82,83,80,153,39,629,40,37,38
	btf_id 3087
3333: sched_cls  name tail_handle_arp  tag 7d998613a5159e0c  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3133
3334: sched_cls  name tail_ipv4_ct_egress  tag 35a8eb13620a89e6  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3135
3335: sched_cls  name cil_from_container  tag 05b6934ada556ed4  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 641,76
	btf_id 3137
3336: sched_cls  name tail_handle_ipv4_cont  tag 35f6a82bcbe5f8a7  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,159,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3136
3337: sched_cls  name cil_from_container  tag 6c777b1c07c0897a  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3139
3338: sched_cls  name __send_drop_notify  tag 3da853dcb676f93b  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3140
3339: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3141
3341: sched_cls  name tail_ipv4_to_endpoint  tag 20d53b93c8fc606e  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,642,41,82,83,80,156,39,641,40,37,38
	btf_id 3138
3342: sched_cls  name tail_handle_ipv4  tag 7c3d8bb127799c3b  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3143
3343: sched_cls  name tail_handle_ipv4  tag be0007bbc0d5c677  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,641
	btf_id 3144
3344: sched_cls  name tail_ipv4_ct_ingress  tag c3476386f0a357ea  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3146
3346: sched_cls  name tail_ipv4_ct_ingress  tag f3790c2f6cc7511f  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3145
3347: sched_cls  name tail_handle_ipv4_cont  tag 3f6196e77e408706  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,642,41,156,82,83,39,76,74,77,641,40,37,38,81
	btf_id 3148
3348: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,641
	btf_id 3150
3349: sched_cls  name tail_ipv4_ct_egress  tag 93bc7769364a7777  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3149
3350: sched_cls  name tail_ipv4_to_endpoint  tag a069b66bf4b0cf1c  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,159,39,639,40,37,38
	btf_id 3152
3351: sched_cls  name handle_policy  tag a4f7f4a9967b337f  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,641,82,83,642,41,80,156,39,84,75,40,37,38
	btf_id 3151
3352: sched_cls  name tail_handle_arp  tag c32e09588bdd72da  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,641
	btf_id 3154
3353: sched_cls  name __send_drop_notify  tag 7c264f1e44380672  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3155
3354: sched_cls  name handle_policy  tag 02c28babff77821e  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,159,39,84,75,40,37,38
	btf_id 3153
