Endpoint ID: 3
Path: /sys/fs/bpf/tc/globals/cilium_policy_00003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 254
Path: /sys/fs/bpf/tc/globals/cilium_policy_00254

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6208768   77024     0        
Allow    Ingress     1          ANY          NONE         disabled    63292     762       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 849
Path: /sys/fs/bpf/tc/globals/cilium_policy_00849

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    265864   2402      0        
Allow    Ingress     1          ANY          NONE         disabled    173552   2003      0        
Allow    Egress      0          ANY          NONE         disabled    70393    700       0        


Endpoint ID: 1570
Path: /sys/fs/bpf/tc/globals/cilium_policy_01570

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377827   4416      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2104
Path: /sys/fs/bpf/tc/globals/cilium_policy_02104

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6026972   59612     0        
Allow    Ingress     1          ANY          NONE         disabled    4813643   50563     0        
Allow    Egress      0          ANY          NONE         disabled    5759121   57903     0        


Endpoint ID: 2125
Path: /sys/fs/bpf/tc/globals/cilium_policy_02125

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2497
Path: /sys/fs/bpf/tc/globals/cilium_policy_02497

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    260873   2351      0        
Allow    Ingress     1          ANY          NONE         disabled    172364   1985      0        
Allow    Egress      0          ANY          NONE         disabled    71188    711       0        


Endpoint ID: 3390
Path: /sys/fs/bpf/tc/globals/cilium_policy_03390

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


