REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     127768    10330374    677    bpf_overlay.c
Interface                   INGRESS     648631    244766653   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      125785    10195808    53     encap.h
Success                     EGRESS      143846    19323245    1308   bpf_lxc.c
Success                     EGRESS      51405     4166420     1694   bpf_host.c
Success                     EGRESS      9982      1639996     86     l3.h
Success                     INGRESS     167005    19016957    86     l3.h
Success                     INGRESS     253981    26863377    235    trace.h
Unsupported L3 protocol     EGRESS      73        5490        1492   bpf_lxc.c
