key: 02 00 00 00  value: ac 1f d6 36 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 58 00 df 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f a9 89 01 bb 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 58 00 61 1f 90 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 58 00 df 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 58 00 cb 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 58 00 cf 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 58 00 cf 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 9e 18 10 94 00 00  00 00 00 00
Found 9 elements
