Endpoint ID: 2
Path: /sys/fs/bpf/tc/globals/cilium_policy_00002

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3454     34        0        
Allow    Ingress     1          ANY          NONE         disabled    137727   1583      0        
Allow    Egress      0          ANY          NONE         disabled    19632    217       0        


Endpoint ID: 284
Path: /sys/fs/bpf/tc/globals/cilium_policy_00284

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6240577   77307     0        
Allow    Ingress     1          ANY          NONE         disabled    65834     800       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 341
Path: /sys/fs/bpf/tc/globals/cilium_policy_00341

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6201239   61773     0        
Allow    Ingress     1          ANY          NONE         disabled    5004414   52638     0        
Allow    Egress      0          ANY          NONE         disabled    6248832   62431     0        


Endpoint ID: 490
Path: /sys/fs/bpf/tc/globals/cilium_policy_00490

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1151
Path: /sys/fs/bpf/tc/globals/cilium_policy_01151

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2442     26        0        
Allow    Ingress     1          ANY          NONE         disabled    137265   1576      0        
Allow    Egress      0          ANY          NONE         disabled    20216    224       0        


Endpoint ID: 2062
Path: /sys/fs/bpf/tc/globals/cilium_policy_02062

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    383896   4489      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2357
Path: /sys/fs/bpf/tc/globals/cilium_policy_02357

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3581
Path: /sys/fs/bpf/tc/globals/cilium_policy_03581

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


