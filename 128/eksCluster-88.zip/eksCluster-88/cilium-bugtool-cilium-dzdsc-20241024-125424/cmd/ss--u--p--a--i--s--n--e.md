Total: 586
TCP:   2886 (estab 309, closed 2558, orphaned 0, timewait 2089)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  328       318       10       
INET	  338       324       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:34909      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:33314 sk:1476 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34609 sk:1477 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15070 sk:1478 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                   172.31.158.24%ens5:68         0.0.0.0:*    uid:192 ino:131933 sk:1479 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34608 sk:147a cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15071 sk:147b cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::42d:42ff:fe5e:dfb1]%ens5:546           [::]:*    uid:192 ino:15249 sk:147c cgroup:unreachable:bd0 v6only:1 <->                   
