[
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c40c653_8165_4295_b028_2a27dfec3636.slice/cri-containerd-df6a81dc3ef2dfaa4ae343d789fb5bc361413f068eba329c1bb31ff9d9b7a78e.scope"
      }
    ],
    "ips": [
      "10.88.0.48"
    ],
    "name": "client2-57cf4468f-mgxww",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bd95332_f68f_4441_a916_0171f75d0fe1.slice/cri-containerd-7fab252598a9f49a5ed06c2c48745990d7ff318313a1b6bee80e03611e87af70.scope"
      }
    ],
    "ips": [
      "10.88.0.71"
    ],
    "name": "client-974f6c69d-jrwff",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95d5c690_de4a_4908_933d_255a5df193fd.slice/cri-containerd-e205438eedd46512b661e4cb073951e5f1bbe62893be46ecc1a3a8d3876692df.scope"
      }
    ],
    "ips": [
      "10.88.0.207"
    ],
    "name": "coredns-cc6ccd49c-nzf4m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6649a035_2529_4292_ab93_b4e0c930f88d.slice/cri-containerd-b613518bc613d95300078c7b6dfcf083ceadcd1f027217e03eb62961a5ef2738.scope"
      }
    ],
    "ips": [
      "10.88.0.223"
    ],
    "name": "coredns-cc6ccd49c-qbhck",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b8ddaa6_fd17_4b31_90e0_2e6655fac492.slice/cri-containerd-8bef376c6b5f5e8b2a1e40acd96d122b048143124a3e75798cb29ec8ad3d0c74.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b8ddaa6_fd17_4b31_90e0_2e6655fac492.slice/cri-containerd-3668f467ee3eca6582285d2f9b3bc586e987700da83818fb4e51f7cbc16261df.scope"
      }
    ],
    "ips": [
      "10.88.0.97"
    ],
    "name": "echo-same-node-86d9cc975c-xvkln",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod540e0854_67d4_4c4c_bae7_5a97f15503a7.slice/cri-containerd-ef3e22c006df38d11c5920852ddccf15f4e5837d4170c8d9685cafc741007577.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod540e0854_67d4_4c4c_bae7_5a97f15503a7.slice/cri-containerd-3fc89d55be4bd4e172f1eb9ae1ca49ead8f5ac99519f6ec8a85156617a830170.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod540e0854_67d4_4c4c_bae7_5a97f15503a7.slice/cri-containerd-fdc05d166c8296653de7fb73ea0376df47edaa296146d6454766108e08e43663.scope"
      }
    ],
    "ips": [
      "10.88.0.203"
    ],
    "name": "clustermesh-apiserver-5b9db79cd8-7qgcv",
    "namespace": "kube-system"
  }
]

