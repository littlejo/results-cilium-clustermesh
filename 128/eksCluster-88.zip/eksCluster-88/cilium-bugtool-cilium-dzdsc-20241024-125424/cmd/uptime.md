 12:54:26 up 31 min,  0 users,  load average: 0.39, 0.45, 0.29
