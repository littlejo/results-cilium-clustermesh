KEY             VALUE
AgentLiveness   1940506692153
UTimeOffset     3378462023437500
