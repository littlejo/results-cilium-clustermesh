29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:39+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:39+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:40+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:40+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:40+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:40+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:44+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
108: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
111: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
479: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
480: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
481: sched_cls  name tail_handle_ipv4  tag c275307c19c88aeb  gpl
	loaded_at 2024-10-24T12:30:56+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
510: sched_cls  name tail_handle_ipv4_cont  tag b07fb65f650391e6  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 163
511: sched_cls  name __send_drop_notify  tag 14a8abb1da3356d7  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 164
515: sched_cls  name tail_handle_ipv4  tag 8eb7f693e6e1a8fe  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 165
518: sched_cls  name tail_ipv4_to_endpoint  tag 982ae209a2f924f3  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 169
519: sched_cls  name tail_handle_arp  tag e08a21035387b3a3  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 172
520: sched_cls  name cil_from_container  tag 79079b6f804c700d  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 173
522: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 175
525: sched_cls  name handle_policy  tag 9781ae309b75af4c  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 176
528: sched_cls  name tail_ipv4_ct_egress  tag ef2f7d84db31fc24  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 179
531: sched_cls  name tail_ipv4_ct_ingress  tag 76439f1fc26c9cc6  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 182
532: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 185
533: sched_cls  name __send_drop_notify  tag 49e0f4bccad08f61  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 188
534: sched_cls  name tail_handle_ipv4  tag e90a313e82f2013d  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 189
536: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 187
537: sched_cls  name tail_handle_arp  tag caf27ea2770a349d  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 191
539: sched_cls  name __send_drop_notify  tag 19ffdef5d4a74023  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
540: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 195
541: sched_cls  name tail_handle_ipv4_from_host  tag 13a60369a6b1fccf  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 196
542: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 197
544: sched_cls  name tail_ipv4_ct_ingress  tag 9ef25943040c71a5  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 193
545: sched_cls  name cil_from_container  tag 2a0517b9762519d1  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 200
546: sched_cls  name tail_handle_ipv4_from_host  tag 13a60369a6b1fccf  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 201
547: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
551: sched_cls  name __send_drop_notify  tag 19ffdef5d4a74023  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
552: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 208
553: sched_cls  name tail_handle_ipv4_cont  tag 3d4908e000d0fa8f  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 202
555: sched_cls  name __send_drop_notify  tag 19ffdef5d4a74023  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 213
557: sched_cls  name tail_handle_ipv4_from_host  tag 13a60369a6b1fccf  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 214
559: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 216
561: sched_cls  name __send_drop_notify  tag 19ffdef5d4a74023  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
562: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 220
563: sched_cls  name tail_handle_ipv4_from_host  tag 13a60369a6b1fccf  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 221
565: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 223
568: sched_cls  name tail_ipv4_to_endpoint  tag 8b7744e8e891dd00  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 211
569: sched_cls  name __send_drop_notify  tag 5374f0f534050489  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 228
570: sched_cls  name tail_handle_arp  tag 309286a1e66584ea  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 229
571: sched_cls  name tail_handle_ipv4  tag 489ec2239620c974  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 230
572: sched_cls  name handle_policy  tag f5478568a780521d  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 226
573: sched_cls  name tail_ipv4_to_endpoint  tag 87ac3a10526cbe17  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 231
574: sched_cls  name cil_from_container  tag 60f34f7e29210ae7  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 233
575: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 234
576: sched_cls  name tail_ipv4_ct_egress  tag ef2f7d84db31fc24  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 232
577: sched_cls  name tail_ipv4_ct_ingress  tag 92e072897e3edc01  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 235
578: sched_cls  name handle_policy  tag ebdf38420e5c463a  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 236
579: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 237
581: sched_cls  name tail_handle_ipv4_cont  tag e7ed1057fdb6202d  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 239
582: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
585: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
589: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
594: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
597: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: sched_cls  name tail_ipv4_ct_egress  tag 73b77259e64a5463  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 253
638: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 254
639: sched_cls  name tail_ipv4_to_endpoint  tag 5709f1c0c5ba8e80  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 255
640: sched_cls  name tail_handle_arp  tag 2beeb01419a2c732  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 256
641: sched_cls  name handle_policy  tag 2333a0f899ca5e16  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 257
642: sched_cls  name tail_ipv4_ct_ingress  tag cce19ceeee049a1f  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 258
643: sched_cls  name tail_handle_ipv4_cont  tag a3a3a8cfba5a3358  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 259
644: sched_cls  name cil_from_container  tag fa7facbe4d4905bf  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 260
646: sched_cls  name __send_drop_notify  tag f9c9d74fc731736f  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 262
647: sched_cls  name tail_handle_ipv4  tag 7d32e6ae6a6f25c6  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 263
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
698: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
701: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
717: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
720: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
721: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
724: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
725: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
728: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
729: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
732: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
733: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
736: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3300: sched_cls  name tail_handle_arp  tag fd69f26a23924771  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,634
	btf_id 3097
3301: sched_cls  name tail_ipv4_to_endpoint  tag 74f017b7386b1b33  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,633,41,82,83,80,151,39,634,40,37,38
	btf_id 3098
3302: sched_cls  name tail_ipv4_ct_egress  tag b11ebb528e4b92c2  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3099
3303: sched_cls  name __send_drop_notify  tag c53ed0b90b6ca8cc  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3102
3306: sched_cls  name tail_handle_ipv4  tag ce63ca25507c62df  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,634
	btf_id 3103
3307: sched_cls  name cil_from_container  tag c4b85ce8c7676370  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,76
	btf_id 3106
3309: sched_cls  name tail_handle_ipv4_cont  tag fee2dacf8c21c091  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,633,41,151,82,83,39,76,74,77,634,40,37,38,81
	btf_id 3108
3311: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,634
	btf_id 3109
3313: sched_cls  name handle_policy  tag 57a5d5a9905b319e  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,634,82,83,633,41,80,151,39,84,75,40,37,38
	btf_id 3111
3316: sched_cls  name tail_ipv4_ct_ingress  tag 5f44b8e0b0f535b7  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3113
3355: sched_cls  name tail_handle_ipv4_cont  tag 5e4151359dce0e76  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,645,41,154,82,83,39,76,74,77,646,40,37,38,81
	btf_id 3159
3356: sched_cls  name tail_handle_ipv4  tag d7fc5ba6d34d10d8  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,646
	btf_id 3160
3357: sched_cls  name handle_policy  tag eaf9d849413ddbc2  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,644,82,83,643,41,80,159,39,84,75,40,37,38
	btf_id 3158
3358: sched_cls  name tail_ipv4_ct_egress  tag 811c54742b30f698  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3162
3359: sched_cls  name handle_policy  tag a03916a9aca47ccc  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,646,82,83,645,41,80,154,39,84,75,40,37,38
	btf_id 3161
3360: sched_cls  name tail_handle_ipv4  tag 7ded818877dae685  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,644
	btf_id 3163
3361: sched_cls  name tail_handle_arp  tag 9dd2e0028defdf85  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,646
	btf_id 3164
3362: sched_cls  name tail_handle_arp  tag 5d193d9745a8372e  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,644
	btf_id 3166
3363: sched_cls  name cil_from_container  tag e3e92499adba9cd0  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 646,76
	btf_id 3165
3364: sched_cls  name tail_ipv4_ct_ingress  tag fdfc6096aa2d61cf  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3167
3366: sched_cls  name __send_drop_notify  tag 9b1ba62ffb04e539  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3170
3367: sched_cls  name cil_from_container  tag f4cac41c6dd41be5  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 644,76
	btf_id 3171
3368: sched_cls  name tail_ipv4_ct_egress  tag a602dc1bc2daf004  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3168
3370: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,644
	btf_id 3173
3371: sched_cls  name tail_ipv4_to_endpoint  tag e7e38b31153022de  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,645,41,82,83,80,154,39,646,40,37,38
	btf_id 3174
3372: sched_cls  name tail_ipv4_ct_ingress  tag 8a5e7d478b1b1d73  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3175
3373: sched_cls  name __send_drop_notify  tag f705b736656f92c8  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3176
3374: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,646
	btf_id 3178
3375: sched_cls  name tail_handle_ipv4_cont  tag d519b6f2fa98b8e8  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,643,41,159,82,83,39,76,74,77,644,40,37,38,81
	btf_id 3177
3376: sched_cls  name tail_ipv4_to_endpoint  tag c4a540c52b0f394b  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,643,41,82,83,80,159,39,644,40,37,38
	btf_id 3179
