CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95d5c690_de4a_4908_933d_255a5df193fd.slice/cri-containerd-60c56353398d28d7da593d7bfa443496b5ca4d8627808d1474fb68357d7c2f06.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95d5c690_de4a_4908_933d_255a5df193fd.slice/cri-containerd-e205438eedd46512b661e4cb073951e5f1bbe62893be46ecc1a3a8d3876692df.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9b4aa8f_53fa_4941_a823_09d759e2a0a3.slice/cri-containerd-4a3e3d992a9d850dfcc43a7d024489c9629d775b06bbf0f46d288cfb00b9a6c1.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9b4aa8f_53fa_4941_a823_09d759e2a0a3.slice/cri-containerd-c57b4a4966f273a99ccf2694dc9e0e3a83006f09e3943ae5999e33fa8b8c4bc3.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6649a035_2529_4292_ab93_b4e0c930f88d.slice/cri-containerd-fba7749121b9feda9c6410601f336db30bc6a3d583b767b3bad2dab5ea16bee5.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6649a035_2529_4292_ab93_b4e0c930f88d.slice/cri-containerd-b613518bc613d95300078c7b6dfcf083ceadcd1f027217e03eb62961a5ef2738.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podefd8426a_3ee6_49e1_8b40_47762cae84f3.slice/cri-containerd-2647a13f32bdc7fd019bd7d7fbd762f331624abb206fe01db96c87d9ec5f08e2.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podefd8426a_3ee6_49e1_8b40_47762cae84f3.slice/cri-containerd-88197e6fed48ce8f15068bbcaa9c6ef32d7ffed033a0b2697d0315d26e05790a.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod540e0854_67d4_4c4c_bae7_5a97f15503a7.slice/cri-containerd-3fc89d55be4bd4e172f1eb9ae1ca49ead8f5ac99519f6ec8a85156617a830170.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod540e0854_67d4_4c4c_bae7_5a97f15503a7.slice/cri-containerd-12a62fa2d0cd21393162a865450381b9db0ff7164024c4f63e858c0a6aab7cba.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod540e0854_67d4_4c4c_bae7_5a97f15503a7.slice/cri-containerd-ef3e22c006df38d11c5920852ddccf15f4e5837d4170c8d9685cafc741007577.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod540e0854_67d4_4c4c_bae7_5a97f15503a7.slice/cri-containerd-fdc05d166c8296653de7fb73ea0376df47edaa296146d6454766108e08e43663.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c40c653_8165_4295_b028_2a27dfec3636.slice/cri-containerd-95a99c0bd52c0c4977b81dc21d811034aa42fc78b51b803f68c6a3e6ce7ee91e.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c40c653_8165_4295_b028_2a27dfec3636.slice/cri-containerd-df6a81dc3ef2dfaa4ae343d789fb5bc361413f068eba329c1bb31ff9d9b7a78e.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bd95332_f68f_4441_a916_0171f75d0fe1.slice/cri-containerd-d6fc1cc2edea3c6f7a25bd27439b5fb57574979220c3e0fc170a90febaa40caa.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bd95332_f68f_4441_a916_0171f75d0fe1.slice/cri-containerd-7fab252598a9f49a5ed06c2c48745990d7ff318313a1b6bee80e03611e87af70.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e546d0a_c7c8_470f_bcab_cd7611a24a82.slice/cri-containerd-1474896610dc41b858c480ef394bb43e2661775221241b4c62cd3c2c7a42a645.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e546d0a_c7c8_470f_bcab_cd7611a24a82.slice/cri-containerd-ffb950a74dc3f85fd6916332bb5c7c7c6bf26bf332d4d4b00e1466b20ac2a68b.scope
    111      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b8ddaa6_fd17_4b31_90e0_2e6655fac492.slice/cri-containerd-3668f467ee3eca6582285d2f9b3bc586e987700da83818fb4e51f7cbc16261df.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b8ddaa6_fd17_4b31_90e0_2e6655fac492.slice/cri-containerd-8bef376c6b5f5e8b2a1e40acd96d122b048143124a3e75798cb29ec8ad3d0c74.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b8ddaa6_fd17_4b31_90e0_2e6655fac492.slice/cri-containerd-c71ff8b71c306b48704342264a1d02c42ba3b4cc17bc81f6d55bafd00395b7b1.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd414f9af_c3ae_4355_9544_a2b7fa40abdb.slice/cri-containerd-704e43a5cb99270bf1dfeaf53ffcc08944865df4d97665d36e6e5e73e008fbd5.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd414f9af_c3ae_4355_9544_a2b7fa40abdb.slice/cri-containerd-4c247cf32457a1b9664d6335ca86ef463e195eda12614f350ce5aaf09bc6834a.scope
    99       cgroup_device   multi                                          
