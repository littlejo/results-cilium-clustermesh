top - 12:54:26 up 31 min,  0 users,  load average: 0.39, 0.45, 0.29
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 16.1 us, 32.3 sy,  0.0 ni, 51.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    301.9 free,   1039.4 used,   2494.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2615.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 281572  78276 S   0.0   7.2   1:04.03 cilium-+
    413 root      20   0 1229488   9048   2864 S   0.0   0.2   0:04.39 cilium-+
   3262 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3268 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3274 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3283 root      20   0 1240432  16716  11548 S   0.0   0.4   0:00.02 cilium-+
   3327 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3346 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3351 root      20   0 1616008   8332   6264 S   0.0   0.2   0:00.00 runc:[2+
