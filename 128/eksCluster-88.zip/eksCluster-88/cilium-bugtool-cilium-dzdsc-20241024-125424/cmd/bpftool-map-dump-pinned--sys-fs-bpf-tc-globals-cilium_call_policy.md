key: 02 00 00 00  value: 0d 02 00 00
key: 1c 01 00 00  value: 42 02 00 00
key: 55 01 00 00  value: 81 02 00 00
key: ea 01 00 00  value: 1d 0d 00 00
key: 7f 04 00 00  value: 3c 02 00 00
key: 0e 08 00 00  value: f1 0c 00 00
key: fd 0d 00 00  value: 1f 0d 00 00
Found 7 elements
