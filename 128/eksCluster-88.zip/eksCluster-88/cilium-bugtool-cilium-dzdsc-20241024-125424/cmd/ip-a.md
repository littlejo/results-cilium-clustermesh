1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2d:42:5e:df:b1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.158.24/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3500sec preferred_lft 3500sec
    inet6 fe80::42d:42ff:fe5e:dfb1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a3:55:17:6a:e7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.177.140/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a3:55ff:fe17:6ae7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:03:a5:62:ed:6e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dc03:a5ff:fe62:ed6e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:c9:35:af:1c:a3 brd ff:ff:ff:ff:ff:ff
    inet 10.88.0.78/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::94c9:35ff:feaf:1ca3/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fa:40:93:02:84:61 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f840:93ff:fe02:8461/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:8f:25:c6:c3:87 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::188f:25ff:fec6:c387/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc54d77de8cef1@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:a5:ec:2d:84:29 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9ca5:ecff:fe2d:8429/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8abda55b9891@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:84:67:75:2c:4c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fc84:67ff:fe75:2c4c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca877e918b5e7@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:71:ed:79:f5:58 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::bc71:edff:fe79:f558/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc4b46e1fdf1fc@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:97:d9:c8:ce:55 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::cc97:d9ff:fec8:ce55/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc7be5885b792a@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:e2:c4:db:cb:ff brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::34e2:c4ff:fedb:cbff/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc51a422931a39@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:77:fa:e5:1b:8d brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::a877:faff:fee5:1b8d/64 scope link 
       valid_lft forever preferred_lft forever
