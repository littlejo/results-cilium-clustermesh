alloc: 83.23MB (87277256 bytes)
total-alloc: 3.09GB (3314318928 bytes)
sys: 215.07MB (225518932 bytes)
lookups: 0
mallocs: 75254390
frees: 74735346
heap-alloc: 83.23MB (87277256 bytes)
heap-sys: 169.64MB (177881088 bytes)
heap-idle: 41.63MB (43655168 bytes)
heap-in-use: 128.01MB (134225920 bytes)
heap-released: 2.74MB (2875392 bytes)
heap-objects: 519044
stack-in-use: 34.09MB (35749888 bytes)
stack-sys: 34.09MB (35749888 bytes)
stack-mspan-inuse: 2.02MB (2118400 bytes)
stack-mspan-sys: 2.72MB (2856000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 784.58KB (803409 bytes)
gc-sys: 5.74MB (6022264 bytes)
next-gc: when heap-alloc >= 151.85MB (159221400 bytes)
last-gc: 2024-10-24 12:54:56.107841869 +0000 UTC
gc-pause-total: 9.145075ms
gc-pause: 64747
gc-pause-end: 1729774496107841869
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005876144355809018
enable-gc: true
debug-gc: false
