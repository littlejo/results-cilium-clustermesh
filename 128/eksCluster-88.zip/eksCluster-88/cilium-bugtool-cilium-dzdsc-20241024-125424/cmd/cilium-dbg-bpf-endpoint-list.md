IP ADDRESS         LOCAL ENDPOINT INFO
10.88.0.25:0       id=284   sec_id=4     flags=0x0000 ifindex=10  mac=76:A2:FF:99:E7:DA nodemac=1A:8F:25:C6:C3:87     
10.88.0.97:0       id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55   
172.31.177.140:0   (localhost)                                                                                        
10.88.0.48:0       id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D   
10.88.0.207:0      id=1151  sec_id=5847024 flags=0x0000 ifindex=14  mac=8A:3F:BF:F1:6A:A1 nodemac=FE:84:67:75:2C:4C   
10.88.0.223:0      id=2     sec_id=5847024 flags=0x0000 ifindex=12  mac=76:5E:E9:F8:54:F2 nodemac=9E:A5:EC:2D:84:29   
172.31.158.24:0    (localhost)                                                                                        
10.88.0.203:0      id=341   sec_id=5836511 flags=0x0000 ifindex=18  mac=16:90:8E:38:30:E8 nodemac=BE:71:ED:79:F5:58   
10.88.0.78:0       (localhost)                                                                                        
10.88.0.71:0       id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF   
