{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.657Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.679Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.723Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.727Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.761Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.053Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.059Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.106Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.153Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.168Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.746Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.748Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.795Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.799Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.840Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.863Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.884Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.212Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.234Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.299Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.330Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.348Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.801Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.803Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.848Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.850Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.899Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.905Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.935Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.134Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.139Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.193Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.202Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.230Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.246Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.770Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.772Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.829Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.830Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.872Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.876Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.912Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.174Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.185Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.228Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.276Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.316Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.770Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.779Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.816Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.819Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.853Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.135Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.169Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.191Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.234Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.237Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.676Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.693Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.742Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.760Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.783Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.996Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.008Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.057Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.117Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.143Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.517Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.548Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.560Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.600Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.608Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.640Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.882Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.889Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.936Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.984Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.994Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.351Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.390Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.431Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.439Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.474Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.481Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.723Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.734Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.783Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.794Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.822Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.267Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.349Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.353Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.420Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.446Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.461Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.661Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.661Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.720Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.736Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.774Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.076Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.095Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.139Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.146Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.176Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.372Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.374Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.432Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.437Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.475Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.832Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.835Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.885Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.900Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.924Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.179Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.181Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.239Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.303Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.947Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.951Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.001Z",
  "value": "id=2062  sec_id=5841696 flags=0x0000 ifindex=20  mac=B2:4F:7B:A6:38:C9 nodemac=CE:97:D9:C8:CE:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.014Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.039Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.308Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.313Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.906Z",
  "value": "id=3581  sec_id=5882333 flags=0x0000 ifindex=22  mac=CA:54:39:77:8E:07 nodemac=36:E2:C4:DB:CB:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.917Z",
  "value": "id=490   sec_id=5859069 flags=0x0000 ifindex=24  mac=9E:6F:08:0A:FA:A0 nodemac=AA:77:FA:E5:1B:8D"
}

