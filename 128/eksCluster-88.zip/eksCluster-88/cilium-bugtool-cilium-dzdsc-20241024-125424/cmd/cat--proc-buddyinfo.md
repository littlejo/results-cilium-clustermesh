Node 0, zone      DMA     58      8      3     17      7      3      3      1      2      3     46 
Node 0, zone   Normal    326     51      7      5     10     20      1      7      3      3      6 
