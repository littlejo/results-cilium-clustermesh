IP ADDRESS         LOCAL ENDPOINT INFO
10.15.0.132:0      (localhost)                                                                                        
10.15.0.80:0       id=2911  sec_id=1095663 flags=0x0000 ifindex=12  mac=AA:E7:F8:13:5F:06 nodemac=CE:2B:A1:AF:96:7D   
172.31.242.159:0   (localhost)                                                                                        
10.15.0.14:0       id=2401  sec_id=1074394 flags=0x0000 ifindex=22  mac=02:7B:34:A9:35:CD nodemac=06:90:F3:86:9F:F6   
10.15.0.32:0       id=1987  sec_id=1057179 flags=0x0000 ifindex=20  mac=46:DC:54:CE:13:18 nodemac=06:5F:F1:8F:93:48   
172.31.206.30:0    (localhost)                                                                                        
10.15.0.77:0       id=3557  sec_id=4     flags=0x0000 ifindex=10  mac=86:7E:C4:2E:03:86 nodemac=AE:AE:EA:9E:6C:14     
10.15.0.28:0       id=1539  sec_id=1084373 flags=0x0000 ifindex=18  mac=6A:FA:3F:D2:70:E2 nodemac=4E:C6:F4:82:83:18   
10.15.0.56:0       id=519   sec_id=1095663 flags=0x0000 ifindex=14  mac=22:B5:F1:63:FC:BD nodemac=A2:7A:ED:F3:E1:73   
10.15.0.82:0       id=2798  sec_id=1059881 flags=0x0000 ifindex=24  mac=0E:11:FB:41:C6:A9 nodemac=02:A0:1B:40:F1:02   
