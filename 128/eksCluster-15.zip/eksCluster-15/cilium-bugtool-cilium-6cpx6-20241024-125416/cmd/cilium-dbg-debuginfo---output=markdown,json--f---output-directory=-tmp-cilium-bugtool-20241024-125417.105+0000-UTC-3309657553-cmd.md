markdown output at /tmp/cilium-bugtool-20241024-125417.105+0000-UTC-3309657553/cmd/cilium-debuginfo-20241024-125448.202+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.105+0000-UTC-3309657553/cmd/cilium-debuginfo-20241024-125448.202+0000-UTC.json
