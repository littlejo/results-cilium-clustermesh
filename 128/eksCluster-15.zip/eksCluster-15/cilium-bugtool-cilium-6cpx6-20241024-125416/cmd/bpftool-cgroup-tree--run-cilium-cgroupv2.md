CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc18ae5c5_0b35_4e2f_9df8_59a394456303.slice/cri-containerd-95ae319f46e5ff251ce8d2959f6d8067d3331bb8512c87f1a134c10f16ebe1a0.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc18ae5c5_0b35_4e2f_9df8_59a394456303.slice/cri-containerd-ae0e80d4355a40912a59f7fa6647846da330dd6666ae973473361f6bd98cc096.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08dbffde_0dce_4270_b782_d95e97a90532.slice/cri-containerd-f9b342551c51a55e536d0f46df26aeebd0b73206612887eff3f627cda5971a00.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08dbffde_0dce_4270_b782_d95e97a90532.slice/cri-containerd-5b4cbd07407136d44973c99f1da029b93aa6e3562719b012bb85a85cdf103678.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod417c21c6_15a6_4504_9f1d_64926c15417e.slice/cri-containerd-69c22c8ac4d4a18dcd84cd5132ba2b9f5f7b73b14ec49ff0f23ce09f5450c9be.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod417c21c6_15a6_4504_9f1d_64926c15417e.slice/cri-containerd-c9e9369193a57d20946f21635b63a8ba4e5f1dcbb6b2ae65c3ab0f0329b1ccb4.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb33138f8_e667_48de_8e9f_bc2d284da22f.slice/cri-containerd-20f045365c857f97bbc8aac95705a3f31742d2487b99826c36af4c28d2130e01.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb33138f8_e667_48de_8e9f_bc2d284da22f.slice/cri-containerd-f10c9ac653dcfb081bcba7539b20d96ed6126f547a71beb647f899c82d731ec8.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4c9cd83c_192b_4b20_8ada_0307c2bf898e.slice/cri-containerd-60efeab7bdb8442dba5e2f424de498022c41d24141ae65775675f4027ac274d8.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4c9cd83c_192b_4b20_8ada_0307c2bf898e.slice/cri-containerd-5ad180b0d24b382ae17d0773ab93930cdd67522b530b9d73d822f17fc34f7d89.scope
    118      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72b14ad_81c7_4c5b_9fe3_7249da19b2e3.slice/cri-containerd-2426a5aa6ad2d37dff1b852015c6bd7d42864d68686b5d714b5ec010891f1591.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72b14ad_81c7_4c5b_9fe3_7249da19b2e3.slice/cri-containerd-e56c151187b7d555f63a540bb5ea439f2e149527240e4cbcf6a61fa34faa620a.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72b14ad_81c7_4c5b_9fe3_7249da19b2e3.slice/cri-containerd-ecbb4e6cdbb9adacce407c618ab2e8875863b275710ac4b95889822293491767.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72b14ad_81c7_4c5b_9fe3_7249da19b2e3.slice/cri-containerd-9cd0aea3636f7565e0288c8f47538234210d3b4d00111e48197e8c6f95628564.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb673c9ad_b031_4fe7_98bd_64fb6375c78e.slice/cri-containerd-b210b367d208cb80655d577191fc394e97d968c2c1aee32dd0163b854e29cc4f.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb673c9ad_b031_4fe7_98bd_64fb6375c78e.slice/cri-containerd-0ad85caf47d629f302b19d69ac88394a649b6e20447724b43b64b49286a2f299.scope
    696      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62f68ff7_1d62_4627_93b4_6419f5201e41.slice/cri-containerd-d132fbf2a1dfac54beed166af6af605a5137f9bb4542be6f72b1158d2decb5c2.scope
    662      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62f68ff7_1d62_4627_93b4_6419f5201e41.slice/cri-containerd-ea8bd8f01f546955ebeea3fab6b2f63b28239d6e7a5fa8fded7ed2bf48f7371b.scope
    700      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6eb3524f_71ce_464b_aba2_24ccfe041312.slice/cri-containerd-1fb55334a4be16cab861d7ce486664c7d9ddd9f1ff5c1ba5e4dca19ff2865ebe.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6eb3524f_71ce_464b_aba2_24ccfe041312.slice/cri-containerd-d3d52c838ce02c093162678c1ecd3b7ff137e77c71f929e1eaf5c8c8304ab3b2.scope
    708      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6eb3524f_71ce_464b_aba2_24ccfe041312.slice/cri-containerd-793bea297465a68c1fc92088fdf7131a6bc2ee29013bbc5e64433bf6356e247a.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaff445f3_a504_4871_b23c_9ddfee58fd77.slice/cri-containerd-faa6935c2cf34b1db1e6b334b3d5fbde2e488c83f914ea11101d702a82bfa47d.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaff445f3_a504_4871_b23c_9ddfee58fd77.slice/cri-containerd-0a8bef032a5c802323d24c09c6c42023937ec1183bec7e974b5ff159c10caee9.scope
    87       cgroup_device   multi                                          
