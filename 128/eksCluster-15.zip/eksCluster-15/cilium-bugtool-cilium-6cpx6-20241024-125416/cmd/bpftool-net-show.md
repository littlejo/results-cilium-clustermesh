xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 497
ens6(5) clsact/ingress cil_from_netdev-ens6 id 503
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 493
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 485
cilium_host(7) clsact/egress cil_from_host-cilium_host id 482
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 533
lxca4837776d16e(12) clsact/ingress cil_from_container-lxca4837776d16e id 514
lxcc9c02aede1fa(14) clsact/ingress cil_from_container-lxcc9c02aede1fa id 559
lxc4ce946e49508(18) clsact/ingress cil_from_container-lxc4ce946e49508 id 619
lxc57e33d6026a9(20) clsact/ingress cil_from_container-lxc57e33d6026a9 id 3328
lxc1a75798db0d4(22) clsact/ingress cil_from_container-lxc1a75798db0d4 id 3333
lxcb262f6b90eb7(24) clsact/ingress cil_from_container-lxcb262f6b90eb7 id 3282

flow_dissector:

netfilter:

