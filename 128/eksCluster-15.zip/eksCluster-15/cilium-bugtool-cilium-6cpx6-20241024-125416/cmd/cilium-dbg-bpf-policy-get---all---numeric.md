Endpoint ID: 187
Path: /sys/fs/bpf/tc/globals/cilium_policy_00187

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 519
Path: /sys/fs/bpf/tc/globals/cilium_policy_00519

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    73404    666       0        
Allow    Ingress     1          ANY          NONE         disabled    168447   1938      0        
Allow    Egress      0          ANY          NONE         disabled    48405    492       0        


Endpoint ID: 1539
Path: /sys/fs/bpf/tc/globals/cilium_policy_01539

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6101659   60184     0        
Allow    Ingress     1          ANY          NONE         disabled    5025738   52729     0        
Allow    Egress      0          ANY          NONE         disabled    5877663   58968     0        


Endpoint ID: 1987
Path: /sys/fs/bpf/tc/globals/cilium_policy_01987

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2401
Path: /sys/fs/bpf/tc/globals/cilium_policy_02401

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2798
Path: /sys/fs/bpf/tc/globals/cilium_policy_02798

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376462   4397      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2911
Path: /sys/fs/bpf/tc/globals/cilium_policy_02911

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    73408    664       0        
Allow    Ingress     1          ANY          NONE         disabled    168299   1934      0        
Allow    Egress      0          ANY          NONE         disabled    50052    513       0        


Endpoint ID: 3557
Path: /sys/fs/bpf/tc/globals/cilium_policy_03557

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6212161   76901     0        
Allow    Ingress     1          ANY          NONE         disabled    65595     793       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


