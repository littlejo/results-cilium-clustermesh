filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca4837776d16e direct-action not_in_hw id 514 tag 2ed7f5ab5bc162f8 jited 
