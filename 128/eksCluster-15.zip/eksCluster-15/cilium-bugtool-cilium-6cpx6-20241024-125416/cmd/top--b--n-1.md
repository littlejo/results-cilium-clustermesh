top - 12:54:17 up 33 min,  0 users,  load average: 0.48, 0.54, 0.30
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.2 us, 37.9 sy,  0.0 ni, 44.8 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    291.5 free,   1046.5 used,   2498.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2608.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 284228  78916 S   6.7   7.2   1:21.01 cilium-+
   3139 root      20   0 1240432  16108  11100 S   6.7   0.4   0:00.03 cilium-+
    416 root      20   0 1229744   8948   2864 S   0.0   0.2   0:04.74 cilium-+
   3145 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3156 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3188 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
   3194 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3202 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3227 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
