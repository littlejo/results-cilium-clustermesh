filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc57e33d6026a9 direct-action not_in_hw id 3328 tag a306b58b82c9c3b6 jited 
