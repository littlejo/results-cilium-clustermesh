 12:54:17 up 33 min,  0 users,  load average: 0.48, 0.54, 0.30
