USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3156  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3145  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3139  0.0  0.4 1240432 16108 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3178  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3179  0.0  0.0      0     0 ?        Z    12:54   0:00  \_ [hostname] <defunct>
root           1  4.6  7.2 1539060 284228 ?      Ssl  12:25   1:21 cilium-agent --config-dir=/tmp/cilium/config-map
root         416  0.2  0.2 1229744 8948 ?        Sl   12:25   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
