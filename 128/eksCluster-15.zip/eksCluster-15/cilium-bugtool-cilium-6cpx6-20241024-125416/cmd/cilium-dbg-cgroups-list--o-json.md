[
  {
    "containers": [
      {
        "cgroup-id": 7409,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod417c21c6_15a6_4504_9f1d_64926c15417e.slice/cri-containerd-69c22c8ac4d4a18dcd84cd5132ba2b9f5f7b73b14ec49ff0f23ce09f5450c9be.scope"
      }
    ],
    "ips": [
      "10.15.0.80"
    ],
    "name": "coredns-cc6ccd49c-ljpt8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08dbffde_0dce_4270_b782_d95e97a90532.slice/cri-containerd-f9b342551c51a55e536d0f46df26aeebd0b73206612887eff3f627cda5971a00.scope"
      }
    ],
    "ips": [
      "10.15.0.56"
    ],
    "name": "coredns-cc6ccd49c-w6255",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb673c9ad_b031_4fe7_98bd_64fb6375c78e.slice/cri-containerd-0ad85caf47d629f302b19d69ac88394a649b6e20447724b43b64b49286a2f299.scope"
      }
    ],
    "ips": [
      "10.15.0.14"
    ],
    "name": "client2-57cf4468f-7mc69",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72b14ad_81c7_4c5b_9fe3_7249da19b2e3.slice/cri-containerd-9cd0aea3636f7565e0288c8f47538234210d3b4d00111e48197e8c6f95628564.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72b14ad_81c7_4c5b_9fe3_7249da19b2e3.slice/cri-containerd-ecbb4e6cdbb9adacce407c618ab2e8875863b275710ac4b95889822293491767.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72b14ad_81c7_4c5b_9fe3_7249da19b2e3.slice/cri-containerd-e56c151187b7d555f63a540bb5ea439f2e149527240e4cbcf6a61fa34faa620a.scope"
      }
    ],
    "ips": [
      "10.15.0.28"
    ],
    "name": "clustermesh-apiserver-cb784fd7f-7xkph",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6eb3524f_71ce_464b_aba2_24ccfe041312.slice/cri-containerd-793bea297465a68c1fc92088fdf7131a6bc2ee29013bbc5e64433bf6356e247a.scope"
      },
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6eb3524f_71ce_464b_aba2_24ccfe041312.slice/cri-containerd-d3d52c838ce02c093162678c1ecd3b7ff137e77c71f929e1eaf5c8c8304ab3b2.scope"
      }
    ],
    "ips": [
      "10.15.0.82"
    ],
    "name": "echo-same-node-86d9cc975c-rhshc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62f68ff7_1d62_4627_93b4_6419f5201e41.slice/cri-containerd-ea8bd8f01f546955ebeea3fab6b2f63b28239d6e7a5fa8fded7ed2bf48f7371b.scope"
      }
    ],
    "ips": [
      "10.15.0.32"
    ],
    "name": "client-974f6c69d-kktr5",
    "namespace": "cilium-test-1"
  }
]

