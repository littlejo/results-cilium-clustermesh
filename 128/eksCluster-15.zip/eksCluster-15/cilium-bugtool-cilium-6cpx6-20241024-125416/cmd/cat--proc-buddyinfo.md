Node 0, zone      DMA    387    132     11      2      1      2      5      3      3      3     34 
Node 0, zone   Normal    300     52      4      3     13      3      4      2      1      2      8 
