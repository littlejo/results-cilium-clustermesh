key: 07 02 00 00  value: 28 02 00 00
key: 03 06 00 00  value: 6a 02 00 00
key: c3 07 00 00  value: fd 0c 00 00
key: 61 09 00 00  value: 03 0d 00 00
key: ee 0a 00 00  value: d1 0c 00 00
key: 5f 0b 00 00  value: 00 02 00 00
key: e5 0d 00 00  value: 1b 02 00 00
Found 7 elements
