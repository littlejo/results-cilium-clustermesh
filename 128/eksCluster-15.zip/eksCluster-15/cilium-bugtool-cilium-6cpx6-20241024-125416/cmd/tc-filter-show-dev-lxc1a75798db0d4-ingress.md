filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc1a75798db0d4 direct-action not_in_hw id 3333 tag ba6dc9c1377f4140 jited 
