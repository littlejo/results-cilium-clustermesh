Total: 576
TCP:   4181 (estab 294, closed 3868, orphaned 0, timewait 3415)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  313       302       11       
INET	  323       308       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                  172.31.242.159%ens5:68         0.0.0.0:*    uid:192 ino:87937 sk:1 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:28227 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15273 sk:3 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:35287      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:28143 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:28226 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15274 sk:6 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::8de:21ff:fe63:e4d9]%ens5:546           [::]:*    uid:192 ino:16511 sk:7 cgroup:unreachable:bd0 v6only:1 <->                   
