1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:de:21:63:e4:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.242.159/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3404sec preferred_lft 3404sec
    inet6 fe80::8de:21ff:fe63:e4d9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:87:3d:50:6c:eb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.206.30/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::887:3dff:fe50:6ceb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:ec:68:66:35:d8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dcec:68ff:fe66:35d8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:5f:63:b4:43:5b brd ff:ff:ff:ff:ff:ff
    inet 10.15.0.132/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::105f:63ff:feb4:435b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 72:ba:90:e8:70:e4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::70ba:90ff:fee8:70e4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:ae:ea:9e:6c:14 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::acae:eaff:fe9e:6c14/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca4837776d16e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:2b:a1:af:96:7d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::cc2b:a1ff:feaf:967d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcc9c02aede1fa@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:7a:ed:f3:e1:73 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::a07a:edff:fef3:e173/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4ce946e49508@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:c6:f4:82:83:18 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4cc6:f4ff:fe82:8318/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc57e33d6026a9@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:5f:f1:8f:93:48 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::45f:f1ff:fe8f:9348/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc1a75798db0d4@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:90:f3:86:9f:f6 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::490:f3ff:fe86:9ff6/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcb262f6b90eb7@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:a0:1b:40:f1:02 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::a0:1bff:fe40:f102/64 scope link 
       valid_lft forever preferred_lft forever
