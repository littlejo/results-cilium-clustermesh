alloc: 79.54MB (83400664 bytes)
total-alloc: 3.07GB (3297920808 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 74778550
frees: 74265966
heap-alloc: 79.54MB (83400664 bytes)
heap-sys: 179.07MB (187768832 bytes)
heap-idle: 53.13MB (55713792 bytes)
heap-in-use: 125.94MB (132055040 bytes)
heap-released: 9.93MB (10412032 bytes)
heap-objects: 512584
stack-in-use: 32.91MB (34504704 bytes)
stack-sys: 32.91MB (34504704 bytes)
stack-mspan-inuse: 1.98MB (2079200 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 982.92KB (1006505 bytes)
gc-sys: 5.52MB (5788864 bytes)
next-gc: when heap-alloc >= 153.99MB (161469960 bytes)
last-gc: 2024-10-24 12:54:47.297396252 +0000 UTC
gc-pause-total: 32.302197ms
gc-pause: 136744
gc-pause-end: 1729774487297396252
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.000627391910407522
enable-gc: true
debug-gc: false
