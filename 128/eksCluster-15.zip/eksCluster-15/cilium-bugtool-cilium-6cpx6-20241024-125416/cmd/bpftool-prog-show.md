29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:20:54+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:20:54+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:20:54+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:54+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
104: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
107: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
115: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
118: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:25:19+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
479: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:25:19+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
480: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:25:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
481: sched_cls  name tail_handle_ipv4  tag 09f1b281f2d0273c  gpl
	loaded_at 2024-10-24T12:25:19+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
482: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,102
	btf_id 129
483: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 130
484: sched_cls  name tail_handle_ipv4_from_host  tag 96a8d8a8e41cc14f  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 131
485: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 132
486: sched_cls  name __send_drop_notify  tag 8a918ffd4783470d  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 133
491: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 139
492: sched_cls  name tail_handle_ipv4_from_host  tag 96a8d8a8e41cc14f  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 140
493: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 141
494: sched_cls  name __send_drop_notify  tag 8a918ffd4783470d  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 142
496: sched_cls  name __send_drop_notify  tag 8a918ffd4783470d  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 145
497: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 146
500: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 149
501: sched_cls  name tail_handle_ipv4_from_host  tag 96a8d8a8e41cc14f  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 150
503: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 153
506: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 156
507: sched_cls  name tail_handle_ipv4_from_host  tag 96a8d8a8e41cc14f  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 157
509: sched_cls  name __send_drop_notify  tag 8a918ffd4783470d  gpl
	loaded_at 2024-10-24T12:25:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
512: sched_cls  name handle_policy  tag 1fb0c98755092ef1  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 163
513: sched_cls  name tail_handle_arp  tag e7dc75fb2a2275f0  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 166
514: sched_cls  name cil_from_container  tag 2ed7f5ab5bc162f8  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 167
515: sched_cls  name tail_handle_ipv4_cont  tag fad636f065cd39e2  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 168
516: sched_cls  name __send_drop_notify  tag 1eb0dd8a81b28b60  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 169
518: sched_cls  name tail_ipv4_to_endpoint  tag 05d84648c80a86ab  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 170
522: sched_cls  name tail_ipv4_ct_egress  tag 14a9107dde3661bc  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 172
524: sched_cls  name tail_handle_ipv4  tag 90c6fbb1ce72ff4f  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 176
527: sched_cls  name tail_ipv4_ct_ingress  tag a06507c264c1569a  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 179
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 182
532: sched_cls  name tail_handle_ipv4_cont  tag 27bbebb6114ddbef  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,114,41,100,82,83,39,76,74,77,115,40,37,38,81
	btf_id 185
533: sched_cls  name cil_from_container  tag d6e51503ccb84f8b  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 115,76
	btf_id 186
535: sched_cls  name __send_drop_notify  tag 589dbdfd70a4eced  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 188
536: sched_cls  name tail_ipv4_ct_ingress  tag e8335f6f88b5810c  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 189
537: sched_cls  name tail_handle_ipv4  tag ef17dadcea58f866  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 190
538: sched_cls  name tail_handle_arp  tag d4e63ad6f705872e  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 191
539: sched_cls  name handle_policy  tag 3ba33718cc43b653  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,115,82,83,114,41,80,100,39,84,75,40,37,38
	btf_id 192
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 193
541: sched_cls  name tail_ipv4_to_endpoint  tag bf86a3832c2c09f1  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,114,41,82,83,80,100,39,115,40,37,38
	btf_id 194
542: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 195
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
551: sched_cls  name tail_ipv4_ct_ingress  tag 5385e57a08c462fb  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 197
552: sched_cls  name handle_policy  tag 4c5db7af10277fbd  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,119,82,83,120,41,80,118,39,84,75,40,37,38
	btf_id 198
553: sched_cls  name tail_ipv4_to_endpoint  tag 7eae24aab7544ca2  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,120,41,82,83,80,118,39,119,40,37,38
	btf_id 199
554: sched_cls  name tail_handle_ipv4  tag aaf0ea0c050f1ffc  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,119
	btf_id 200
555: sched_cls  name tail_handle_ipv4_cont  tag e4b97575f462480b  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,120,41,118,82,83,39,76,74,77,119,40,37,38,81
	btf_id 201
557: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,119
	btf_id 203
558: sched_cls  name __send_drop_notify  tag ceea721cd7e6134b  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 204
559: sched_cls  name cil_from_container  tag ec4b8cd0f83109c7  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 119,76
	btf_id 205
560: sched_cls  name tail_handle_arp  tag 1b5b9f663a7b6f99  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,119
	btf_id 206
561: sched_cls  name tail_ipv4_ct_egress  tag 14a9107dde3661bc  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 207
562: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
565: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: sched_cls  name tail_handle_arp  tag 556841ce89b16956  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 221
610: sched_cls  name tail_handle_ipv4  tag 40c5c28620e586bb  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 222
611: sched_cls  name __send_drop_notify  tag b2c633ba8099126d  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
612: sched_cls  name tail_ipv4_ct_ingress  tag 56206ea8c55856fc  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 224
613: sched_cls  name tail_ipv4_ct_egress  tag a502147effb98982  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 225
615: sched_cls  name tail_handle_ipv4_cont  tag 982be8a6736500ce  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 227
616: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 228
617: sched_cls  name tail_ipv4_to_endpoint  tag 3a58f881afcc3082  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 229
618: sched_cls  name handle_policy  tag 8f592a0ab7cf5439  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 230
619: sched_cls  name cil_from_container  tag 759f70196e96f4c5  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 231
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
659: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
662: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
685: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
688: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
689: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
692: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
693: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
696: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
697: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
700: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
701: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
704: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
705: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
708: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3263: sched_cls  name tail_ipv4_ct_ingress  tag 236dd04d906b9ef8  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,626,82,83,625,84
	btf_id 3057
3266: sched_cls  name tail_ipv4_ct_egress  tag 7f81f1e4df80ee84  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,626,82,83,625,84
	btf_id 3058
3273: sched_cls  name tail_ipv4_to_endpoint  tag 148a0806c4550065  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,625,41,82,83,80,150,39,626,40,37,38
	btf_id 3062
3274: sched_cls  name tail_handle_ipv4  tag 341d1144502a0f47  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,626
	btf_id 3068
3275: sched_cls  name tail_handle_arp  tag 7ea2f3de15b37c08  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,626
	btf_id 3069
3277: sched_cls  name __send_drop_notify  tag 162641d711f0d96e  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3070
3279: sched_cls  name tail_handle_ipv4_cont  tag 364a42657696e96d  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,625,41,150,82,83,39,76,74,77,626,40,37,38,81
	btf_id 3072
3281: sched_cls  name handle_policy  tag 00d8f51e4479c003  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,626,82,83,625,41,80,150,39,84,75,40,37,38
	btf_id 3073
3282: sched_cls  name cil_from_container  tag d0712328978a98e1  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 626,76
	btf_id 3077
3283: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,626
	btf_id 3078
3316: sched_cls  name __send_drop_notify  tag 19d22b9e7833ee23  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3113
3318: sched_cls  name tail_handle_ipv4  tag 540fed0340b32364  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,634
	btf_id 3116
3319: sched_cls  name tail_handle_ipv4_cont  tag bb8d72647826a2af  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,633,41,143,82,83,39,76,74,77,634,40,37,38,81
	btf_id 3118
3320: sched_cls  name tail_ipv4_to_endpoint  tag aa1d302663c59792  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,147,39,636,40,37,38
	btf_id 3117
3321: sched_cls  name tail_ipv4_ct_egress  tag 5c66229f86efbbe8  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3119
3322: sched_cls  name tail_handle_ipv4  tag eb2c4c4b49b8555f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3120
3323: sched_cls  name tail_handle_ipv4_cont  tag 768efe2735fb242b  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,147,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3122
3324: sched_cls  name tail_handle_arp  tag 9da4e34297d94af5  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3123
3325: sched_cls  name handle_policy  tag 3f619da080ea3c92  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,634,82,83,633,41,80,143,39,84,75,40,37,38
	btf_id 3121
3326: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,634
	btf_id 3125
3327: sched_cls  name tail_handle_arp  tag f9bb1efeba1f417f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,634
	btf_id 3126
3328: sched_cls  name cil_from_container  tag a306b58b82c9c3b6  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,76
	btf_id 3127
3329: sched_cls  name tail_ipv4_to_endpoint  tag 1ec67334252d4df5  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,633,41,82,83,80,143,39,634,40,37,38
	btf_id 3128
3330: sched_cls  name tail_ipv4_ct_ingress  tag 7767d8967ffca4c8  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3129
3331: sched_cls  name handle_policy  tag 407e2aece1626e9b  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,147,39,84,75,40,37,38
	btf_id 3124
3332: sched_cls  name tail_ipv4_ct_ingress  tag 5fca9c96e654f1f4  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3130
3333: sched_cls  name cil_from_container  tag ba6dc9c1377f4140  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3131
3334: sched_cls  name __send_drop_notify  tag 68c6fa621cd6e66c  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3132
3335: sched_cls  name tail_ipv4_ct_egress  tag 23a1c661f484f33b  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3133
3336: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3134
