[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4285f5fc_2231_479e_801c_97037ff6a4e8.slice/cri-containerd-8152e0052c289259439c46310208d951ee447501724ca726a28a8881d1eb5cbd.scope"
      }
    ],
    "ips": [
      "10.74.0.245"
    ],
    "name": "coredns-cc6ccd49c-ptc4m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4ddaf67_c1a1_4ce6_a565_b1ae94ff52ce.slice/cri-containerd-86d0fb2856e9872f1f8bb2506dd35760e863fe686fb06f6ac92a4c24599ade4b.scope"
      }
    ],
    "ips": [
      "10.74.0.125"
    ],
    "name": "client2-57cf4468f-79q2r",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52763037_6e6d_4a03_ab25_ca4b76209bb8.slice/cri-containerd-08918f558f66f8ca198b242c4e568f482a24c5c61ba92507c60eba966586f8ad.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52763037_6e6d_4a03_ab25_ca4b76209bb8.slice/cri-containerd-37e70be1326d79bd262cac7ab765a2b82e12f8f2bf7fb36513389b3c7646baa5.scope"
      }
    ],
    "ips": [
      "10.74.0.135"
    ],
    "name": "echo-same-node-86d9cc975c-hjgx6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f74eed1_0a61_443e_be16_2d7389bbf1f8.slice/cri-containerd-56581543067c5dfab86f92b18ad02e0db2c61235202981ea224ff031507117de.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f74eed1_0a61_443e_be16_2d7389bbf1f8.slice/cri-containerd-d8bd598403987a056adff224f37f8cbdaebe751f77cefc4abea89a713b4b25b0.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f74eed1_0a61_443e_be16_2d7389bbf1f8.slice/cri-containerd-08a681be444b4d9038795784b6dd07181fd6149fab2c7b8d1a9ac9511cc6885c.scope"
      }
    ],
    "ips": [
      "10.74.0.154"
    ],
    "name": "clustermesh-apiserver-8466ddf8f6-b4cz8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd15f443_fcad_4faa_bc57_ecd25258b0fa.slice/cri-containerd-adce6440a45a38d853155b5c65e3333fd12ac3b2c8380ce38f5ad82b1100ef44.scope"
      }
    ],
    "ips": [
      "10.74.0.60"
    ],
    "name": "coredns-cc6ccd49c-thct5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod184971ff_c15b_4de4_9e2e_106fdea7ecb2.slice/cri-containerd-5ecb48fc6f735687e1fedc1132b19538a8a0fe5d33ba62a738730d012b00c6d0.scope"
      }
    ],
    "ips": [
      "10.74.0.84"
    ],
    "name": "client-974f6c69d-dcfvx",
    "namespace": "cilium-test-1"
  }
]

