CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd15f443_fcad_4faa_bc57_ecd25258b0fa.slice/cri-containerd-d60e26b89f80813d0ba1b047ddfc0a806fe715062ad0efe2dfc2a323edc22cda.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd15f443_fcad_4faa_bc57_ecd25258b0fa.slice/cri-containerd-adce6440a45a38d853155b5c65e3333fd12ac3b2c8380ce38f5ad82b1100ef44.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5701a08_282e_46fc_b596_34cb03e6dd95.slice/cri-containerd-9e2a5ad0c00c171b475c278a190e6a6eff7dbedb4f50ef7cc5ffd69980a05c4a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5701a08_282e_46fc_b596_34cb03e6dd95.slice/cri-containerd-63f82746ff77f17ca02735192cc16e03ec7fa09a89c6789cb0b59e8253a8d45e.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded67649e_2186_4ff4_9a84_2412733f5133.slice/cri-containerd-426c894f96ce7907f3860faa45881b9f979b2af11b6aee9413ebe47e9ee930b0.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded67649e_2186_4ff4_9a84_2412733f5133.slice/cri-containerd-af67dc3caed574f25a7946f2dbb37043375ea1d5ebe92b6c4bc1b0e52d3ff645.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4285f5fc_2231_479e_801c_97037ff6a4e8.slice/cri-containerd-2c134890aec5cde67b00cd47cd8294723960ebac6fc0534755d1ef2ac41f5b61.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4285f5fc_2231_479e_801c_97037ff6a4e8.slice/cri-containerd-8152e0052c289259439c46310208d951ee447501724ca726a28a8881d1eb5cbd.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod184971ff_c15b_4de4_9e2e_106fdea7ecb2.slice/cri-containerd-5ecb48fc6f735687e1fedc1132b19538a8a0fe5d33ba62a738730d012b00c6d0.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod184971ff_c15b_4de4_9e2e_106fdea7ecb2.slice/cri-containerd-54151bc87dd3eda0b7bc6aada289c7c5bfeb281abb357489213b3933819e87ce.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod30fb9d94_af24_406e_9088_5ce1a11b004d.slice/cri-containerd-a9f498a1be7accae354b709920cfdefac78ce13dc8bf7f103a63fbcd0aecc906.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod30fb9d94_af24_406e_9088_5ce1a11b004d.slice/cri-containerd-0963c907626a1febecaadf49da39560ac787bab977744194cd1c91d142e20172.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4ddaf67_c1a1_4ce6_a565_b1ae94ff52ce.slice/cri-containerd-86d0fb2856e9872f1f8bb2506dd35760e863fe686fb06f6ac92a4c24599ade4b.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4ddaf67_c1a1_4ce6_a565_b1ae94ff52ce.slice/cri-containerd-1dab514dc44f792e054bc94a7505909a2fedb9d9b6fa9cf32f6de6660f639092.scope
    708      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f74eed1_0a61_443e_be16_2d7389bbf1f8.slice/cri-containerd-56581543067c5dfab86f92b18ad02e0db2c61235202981ea224ff031507117de.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f74eed1_0a61_443e_be16_2d7389bbf1f8.slice/cri-containerd-d8bd598403987a056adff224f37f8cbdaebe751f77cefc4abea89a713b4b25b0.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f74eed1_0a61_443e_be16_2d7389bbf1f8.slice/cri-containerd-207aace30cc7438899ef7644e59bf27ceecb12de1fc36d3a383ddad207743b82.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f74eed1_0a61_443e_be16_2d7389bbf1f8.slice/cri-containerd-08a681be444b4d9038795784b6dd07181fd6149fab2c7b8d1a9ac9511cc6885c.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52763037_6e6d_4a03_ab25_ca4b76209bb8.slice/cri-containerd-37e70be1326d79bd262cac7ab765a2b82e12f8f2bf7fb36513389b3c7646baa5.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52763037_6e6d_4a03_ab25_ca4b76209bb8.slice/cri-containerd-8fb90c83ec234ce18f2831d61bbc7d0cd42fbed0e6bfa4f5ce28d2c295351aa3.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52763037_6e6d_4a03_ab25_ca4b76209bb8.slice/cri-containerd-08918f558f66f8ca198b242c4e568f482a24c5c61ba92507c60eba966586f8ad.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37458736_5645_4e42_9939_64ee7225d26b.slice/cri-containerd-d61fd460bde9bba70d7085e4f2c27145e95472ebab5604dcdccf5f175d042da2.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37458736_5645_4e42_9939_64ee7225d26b.slice/cri-containerd-56333aad853d89253c4cdcb041ff6e99dcd54a44a4699844d89b8814b78333e3.scope
    90       cgroup_device   multi                                          
