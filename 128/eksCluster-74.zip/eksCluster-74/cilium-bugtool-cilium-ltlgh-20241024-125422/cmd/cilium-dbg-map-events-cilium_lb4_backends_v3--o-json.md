{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:45.193Z",
  "value": "ANY://172.31.166.171"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:45.193Z",
  "value": "ANY://172.31.196.125"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:45.193Z",
  "value": "ANY://172.31.144.228"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:45.193Z",
  "value": "ANY://172.31.144.228"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:48.909Z",
  "value": "ANY://172.31.140.172"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:50.187Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:50.187Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:52.287Z",
  "value": "ANY://10.74.0.245"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:52.287Z",
  "value": "ANY://10.74.0.245"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:52.307Z",
  "value": "ANY://10.74.0.60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:52.308Z",
  "value": "ANY://10.74.0.60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:37:36.109Z",
  "value": "ANY://10.74.0.158"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "11",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:04.634Z",
  "value": "ANY://10.74.0.154"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:04.801Z",
  "value": "ANY://10.74.0.158"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:05.279Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "12",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:33.393Z",
  "value": "ANY://10.74.0.135"
}

