Total: 579
TCP:   3620 (estab 302, closed 3299, orphaned 0, timewait 2837)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  321       311       10       
INET	  331       317       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                  172.31.140.172%ens5:68         0.0.0.0:*    uid:192 ino:122200 sk:1001 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32924 sk:1002 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15434 sk:1003 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:34369      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=38)) ino:32866 sk:1004 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32923 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15435 sk:1006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::460:56ff:fe4b:34fb]%ens5:546           [::]:*    uid:192 ino:16474 sk:1007 cgroup:unreachable:bd0 v6only:1 <->                   
