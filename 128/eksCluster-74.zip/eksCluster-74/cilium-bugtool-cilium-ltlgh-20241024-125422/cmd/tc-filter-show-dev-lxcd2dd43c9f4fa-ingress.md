filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd2dd43c9f4fa direct-action not_in_hw id 3306 tag 58dc739ec1ba6f3e jited 
