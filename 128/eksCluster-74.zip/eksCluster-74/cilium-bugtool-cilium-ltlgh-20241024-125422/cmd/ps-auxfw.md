USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3172  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3170  0.0  0.4 1240432 16452 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3223  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3228  0.0  0.0   4220   812 ?        R    12:54   0:00  \_ ip -6 r
root        3169  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3162  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.3  7.2 1538804 285284 ?      Ssl  12:29   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         391  0.2  0.2 1229744 9784 ?        Sl   12:29   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
