IP ADDRESS         LOCAL ENDPOINT INFO
10.74.0.84:0       id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D   
10.74.0.248:0      id=653   sec_id=4     flags=0x0000 ifindex=10  mac=E6:1F:8B:4D:E1:5E nodemac=AA:4E:EB:BE:27:3E     
10.74.0.135:0      id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD   
10.74.0.154:0      id=1567  sec_id=4933397 flags=0x0000 ifindex=18  mac=A6:F3:01:79:B2:3C nodemac=9E:EA:B7:50:C7:FD   
10.74.0.236:0      (localhost)                                                                                        
10.74.0.245:0      id=68    sec_id=4927080 flags=0x0000 ifindex=12  mac=D6:26:99:33:C1:9A nodemac=5A:72:80:46:4B:77   
172.31.149.73:0    (localhost)                                                                                        
10.74.0.60:0       id=1274  sec_id=4927080 flags=0x0000 ifindex=14  mac=66:9A:4A:19:0C:82 nodemac=DA:1C:30:61:DA:4B   
172.31.140.172:0   (localhost)                                                                                        
10.74.0.125:0      id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F   
