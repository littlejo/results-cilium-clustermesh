1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:60:56:4b:34:fb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.140.172/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3487sec preferred_lft 3487sec
    inet6 fe80::460:56ff:fe4b:34fb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:98:6d:ad:8f:0d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.149.73/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::498:6dff:fead:8f0d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:a3:78:72:8f:bf brd ff:ff:ff:ff:ff:ff
    inet6 fe80::78a3:78ff:fe72:8fbf/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:0a:e1:81:0c:ec brd ff:ff:ff:ff:ff:ff
    inet 10.74.0.236/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::800a:e1ff:fe81:cec/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:bf:7e:06:64:27 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3cbf:7eff:fe06:6427/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:4e:eb:be:27:3e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a84e:ebff:febe:273e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7700183b97c1@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:72:80:46:4b:77 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::5872:80ff:fe46:4b77/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca089743ebff1@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:1c:30:61:da:4b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d81c:30ff:fe61:da4b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc139d2af2d419@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:ea:b7:50:c7:fd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9cea:b7ff:fe50:c7fd/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc401dad34b2bb@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:4f:8b:dd:7b:0d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::304f:8bff:fedd:7b0d/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc5fbef1377807@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:3f:68:0e:63:1f brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::d03f:68ff:fe0e:631f/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcd2dd43c9f4fa@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:52:07:39:ed:ad brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::8452:7ff:fe39:edad/64 scope link 
       valid_lft forever preferred_lft forever
