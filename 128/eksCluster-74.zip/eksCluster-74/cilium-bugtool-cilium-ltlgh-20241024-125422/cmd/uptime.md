 12:54:23 up 32 min,  0 users,  load average: 0.53, 0.56, 0.33
