key: 44 00 00 00  value: 38 02 00 00
key: 86 00 00 00  value: 26 0d 00 00
key: 1c 02 00 00  value: f0 0c 00 00
key: 8d 02 00 00  value: 46 02 00 00
key: 55 04 00 00  value: 32 0d 00 00
key: fa 04 00 00  value: 15 02 00 00
key: 1f 06 00 00  value: 87 02 00 00
Found 7 elements
