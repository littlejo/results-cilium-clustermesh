alloc: 137.36MB (144028088 bytes)
total-alloc: 3.09GB (3316864944 bytes)
sys: 215.07MB (225518932 bytes)
lookups: 0
mallocs: 75319233
frees: 73809023
heap-alloc: 137.36MB (144028088 bytes)
heap-sys: 168.61MB (176799744 bytes)
heap-idle: 15.30MB (16039936 bytes)
heap-in-use: 153.31MB (160759808 bytes)
heap-released: 8.03MB (8421376 bytes)
heap-objects: 1510210
stack-in-use: 35.34MB (37060608 bytes)
stack-sys: 35.34MB (37060608 bytes)
stack-mspan-inuse: 2.49MB (2608800 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 740.49KB (758257 bytes)
gc-sys: 5.54MB (5809320 bytes)
next-gc: when heap-alloc >= 146.95MB (154089192 bytes)
last-gc: 2024-10-24 12:54:12.377157095 +0000 UTC
gc-pause-total: 9.186951ms
gc-pause: 106981
gc-pause-end: 1729774452377157095
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0005750967864683658
enable-gc: true
debug-gc: false
