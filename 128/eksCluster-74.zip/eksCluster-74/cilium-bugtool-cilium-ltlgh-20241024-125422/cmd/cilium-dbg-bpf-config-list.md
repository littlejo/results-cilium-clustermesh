KEY             VALUE
AgentLiveness   1958003407867
UTimeOffset     3378461984375000
