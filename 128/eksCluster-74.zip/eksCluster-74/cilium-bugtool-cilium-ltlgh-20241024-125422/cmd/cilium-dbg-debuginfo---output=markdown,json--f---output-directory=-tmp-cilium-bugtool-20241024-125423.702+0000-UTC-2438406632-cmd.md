markdown output at /tmp/cilium-bugtool-20241024-125423.702+0000-UTC-2438406632/cmd/cilium-debuginfo-20241024-125454.544+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125423.702+0000-UTC-2438406632/cmd/cilium-debuginfo-20241024-125454.544+0000-UTC.json
