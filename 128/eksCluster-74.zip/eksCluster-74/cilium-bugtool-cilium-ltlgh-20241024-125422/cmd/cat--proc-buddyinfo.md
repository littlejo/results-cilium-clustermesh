Node 0, zone      DMA      0    105     34     41     26     14      5      3      4      3     28 
Node 0, zone   Normal    223     76     28     29     18      6      5      2      3      2      7 
