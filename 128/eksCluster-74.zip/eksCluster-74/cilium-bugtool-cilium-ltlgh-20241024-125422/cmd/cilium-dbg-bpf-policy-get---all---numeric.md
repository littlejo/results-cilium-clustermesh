Endpoint ID: 68
Path: /sys/fs/bpf/tc/globals/cilium_policy_00068

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2574     26        0        
Allow    Ingress     1          ANY          NONE         disabled    143889   1655      0        
Allow    Egress      0          ANY          NONE         disabled    19865    220       0        


Endpoint ID: 134
Path: /sys/fs/bpf/tc/globals/cilium_policy_00134

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 540
Path: /sys/fs/bpf/tc/globals/cilium_policy_00540

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    383068   4470      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 653
Path: /sys/fs/bpf/tc/globals/cilium_policy_00653

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6230454   76997     0        
Allow    Ingress     1          ANY          NONE         disabled    63608     768       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1002
Path: /sys/fs/bpf/tc/globals/cilium_policy_01002

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1109
Path: /sys/fs/bpf/tc/globals/cilium_policy_01109

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1274
Path: /sys/fs/bpf/tc/globals/cilium_policy_01274

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3322     34        0        
Allow    Ingress     1          ANY          NONE         disabled    143726   1657      0        
Allow    Egress      0          ANY          NONE         disabled    19598    218       0        


Endpoint ID: 1567
Path: /sys/fs/bpf/tc/globals/cilium_policy_01567

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6144315   61661     0        
Allow    Ingress     1          ANY          NONE         disabled    5375673   56694     0        
Allow    Egress      0          ANY          NONE         disabled    6703782   66238     0        


