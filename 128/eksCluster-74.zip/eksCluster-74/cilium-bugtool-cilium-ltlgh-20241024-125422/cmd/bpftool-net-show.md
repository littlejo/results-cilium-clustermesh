xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 554
ens6(5) clsact/ingress cil_from_netdev-ens6 id 567
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 544
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 574
lxc7700183b97c1(12) clsact/ingress cil_from_container-lxc7700183b97c1 id 535
lxca089743ebff1(14) clsact/ingress cil_from_container-lxca089743ebff1 id 515
lxc139d2af2d419(18) clsact/ingress cil_from_container-lxc139d2af2d419 id 644
lxc401dad34b2bb(20) clsact/ingress cil_from_container-lxc401dad34b2bb id 3358
lxc5fbef1377807(22) clsact/ingress cil_from_container-lxc5fbef1377807 id 3363
lxcd2dd43c9f4fa(24) clsact/ingress cil_from_container-lxcd2dd43c9f4fa id 3306

flow_dissector:

netfilter:

