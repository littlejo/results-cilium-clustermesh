{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.969Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.235Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.255Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.306Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.314Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.346Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.907Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.920Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.956Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.971Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.994Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.228Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.254Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.300Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.304Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.360Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.972Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.976Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.041Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.097Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.126Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.345Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.356Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.412Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.416Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.468Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.172Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.200Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.216Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.254Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.268Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.291Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.509Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.518Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.571Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.611Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.633Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.194Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.210Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.254Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.271Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.307Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.511Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.516Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.557Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.587Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.602Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.043Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.043Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.082Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.111Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.120Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.361Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.370Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.421Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.437Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.470Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.897Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.934Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.939Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.990Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.016Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.029Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.276Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.291Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.371Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.408Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.455Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.911Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.918Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.973Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.976Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.012Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.226Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.228Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.291Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.325Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.332Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.779Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.782Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.820Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.821Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.859Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.171Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.190Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.232Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.246Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.281Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.733Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.832Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.834Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.908Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.927Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.953Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.137Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.150Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.204Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.208Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.255Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.521Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.559Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.563Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.607Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.616Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.648Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.886Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.913Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.944Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.967Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.993Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.321Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.325Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.367Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.404Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.418Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.670Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.718Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.743Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.768Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.697Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.701Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.730Z",
  "value": "id=540   sec_id=4919868 flags=0x0000 ifindex=24  mac=D2:BA:83:BD:01:41 nodemac=86:52:07:39:ED:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.757Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.776Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.017Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.021Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.717Z",
  "value": "id=134   sec_id=4954411 flags=0x0000 ifindex=22  mac=C2:94:CC:32:27:56 nodemac=D2:3F:68:0E:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.718Z",
  "value": "id=1109  sec_id=4923310 flags=0x0000 ifindex=20  mac=2A:C8:A5:8C:98:05 nodemac=32:4F:8B:DD:7B:0D"
}

