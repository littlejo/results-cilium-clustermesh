CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc608ca4_2e61_41fa_b0e4_1119513dc6f0.slice/cri-containerd-919199e079499a47aa5a3edc308057238dae6a81d6268ec455adb75dce7ddce6.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc608ca4_2e61_41fa_b0e4_1119513dc6f0.slice/cri-containerd-d4cea679765bd55cfbbb305c8fd81deafb36a92caea092bd92cbcd09a4d4068f.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1879bcff_f043_4490_bd15_2d15043e3189.slice/cri-containerd-4c84ae5db7c25a2a16a5f0f2acc50d0d6ad438a40e7c417a33884b348b33bb86.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1879bcff_f043_4490_bd15_2d15043e3189.slice/cri-containerd-2c688219a0b356e44355718fe920c589ae18cdc25210e972032f4c98e7a197ff.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod746b4637_5be6_4414_b378_f0e9b6b7c2de.slice/cri-containerd-86a10b18be41fe2c2d329db9112e7cbbe83f27c88255e24488d00539f7d5f039.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod746b4637_5be6_4414_b378_f0e9b6b7c2de.slice/cri-containerd-d8651a16758876c94f3e77c88326d1b69cd82e16c5a6a1169f4d880663e49aa6.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc1e31f87_da4d_4123_8c2c_394e257bf5ae.slice/cri-containerd-2d20b246849e2cdd54474dde2d2a7ef2af491efbefab4d652927ba3b37b61c0c.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc1e31f87_da4d_4123_8c2c_394e257bf5ae.slice/cri-containerd-e36dd4c472ef54e6c2952dee932d181a6ca5177952c2bd99ad61b902c4b92a9d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84751056_24f2_4435_a69d_b3c8301109c5.slice/cri-containerd-7cf3af2d83a3eda24b20f4f1f26129a6d03be6eb70989242ca5dca88cac05942.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84751056_24f2_4435_a69d_b3c8301109c5.slice/cri-containerd-3fe6f38e04f0117c389cc895f161ceb8fe81e59babaf025fbd0783ea7efb210b.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffc60087_6441_4c37_ae32_976e613e4880.slice/cri-containerd-5aa1e6133e5b37f13c5ef93c07e94e224a83bbde97b2f6c581d3c4977ac74665.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffc60087_6441_4c37_ae32_976e613e4880.slice/cri-containerd-24cce861b52e470f8c6588dc5c4e0249b0be4be891a8fafc7e783568af24a525.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66467d73_21d6_4a6f_b9e4_0707ea1eabb6.slice/cri-containerd-067b138bc02ee76cd5fefb7131f228d4ccd9b865231d1fbce02266ed65eeeff7.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66467d73_21d6_4a6f_b9e4_0707ea1eabb6.slice/cri-containerd-e751dc63bebf856d7288b512b87351bc587dc12063fc360e78ced70618d5dd2c.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbacb63b0_6bc4_4307_b338_9e6ca7578132.slice/cri-containerd-15bbc6b55f6e9e5081324759f6cba3fc2f2036445963735a151f9ff890d24f88.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbacb63b0_6bc4_4307_b338_9e6ca7578132.slice/cri-containerd-94b9d74c417726b4337bb53f637d869524ce3274315399f209dd7273acddc8ab.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbacb63b0_6bc4_4307_b338_9e6ca7578132.slice/cri-containerd-b358452d4ddd5cd90dd12b8b8ba73dcb9464c7d6655d7fe2f792582bd6f2625c.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1200c6_88d7_475a_9f11_112eb7e98f59.slice/cri-containerd-94dfe0f984125da15d7d5d4212a2e9b0a04a4b710ed6306a11876c244f95a52e.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1200c6_88d7_475a_9f11_112eb7e98f59.slice/cri-containerd-eb06b99e8bfc2eaeb3645893dc1f9543135642fd49aabfc24e6472423beb6179.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1200c6_88d7_475a_9f11_112eb7e98f59.slice/cri-containerd-4e4deb2c867b64272c72cf19e38a7ab7e9ded5e77a99c1a86945c8827cdd05cf.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1200c6_88d7_475a_9f11_112eb7e98f59.slice/cri-containerd-4a11b8891b2d8d1e8145b042a5124ea0fae3849f874622256f3f801dae7024c5.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c88dcd2_681e_48eb_880a_36ae4fa423d8.slice/cri-containerd-bdc3b9bcdc2128be94f4f06e29de631060d5f10f8806e3f23f68a94d06dc46df.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c88dcd2_681e_48eb_880a_36ae4fa423d8.slice/cri-containerd-89266292e337dda88e011133543cf387970b47020bdf60bf400826ca3232f587.scope
    713      cgroup_device   multi                                          
