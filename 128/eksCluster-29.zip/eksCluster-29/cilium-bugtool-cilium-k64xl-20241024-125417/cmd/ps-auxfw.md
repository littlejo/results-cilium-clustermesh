USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3233  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3227  0.0  0.3 1240432 15184 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3252  0.0  0.0   6408  1640 ?        R    12:54   0:00  \_ ps auxfw
root        3253  0.0  0.0   3728   488 ?        R    12:54   0:00  \_ bash -c hostname
root           1  4.8  7.4 1539060 293452 ?      Ssl  12:26   1:21 cilium-agent --config-dir=/tmp/cilium/config-map
root         416  0.2  0.2 1229744 8860 ?        Sl   12:26   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
