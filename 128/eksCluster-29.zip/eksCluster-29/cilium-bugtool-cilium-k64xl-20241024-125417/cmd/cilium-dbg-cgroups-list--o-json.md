[
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c88dcd2_681e_48eb_880a_36ae4fa423d8.slice/cri-containerd-89266292e337dda88e011133543cf387970b47020bdf60bf400826ca3232f587.scope"
      }
    ],
    "ips": [
      "10.29.0.31"
    ],
    "name": "client-974f6c69d-b8src",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1200c6_88d7_475a_9f11_112eb7e98f59.slice/cri-containerd-4e4deb2c867b64272c72cf19e38a7ab7e9ded5e77a99c1a86945c8827cdd05cf.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1200c6_88d7_475a_9f11_112eb7e98f59.slice/cri-containerd-eb06b99e8bfc2eaeb3645893dc1f9543135642fd49aabfc24e6472423beb6179.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b1200c6_88d7_475a_9f11_112eb7e98f59.slice/cri-containerd-94dfe0f984125da15d7d5d4212a2e9b0a04a4b710ed6306a11876c244f95a52e.scope"
      }
    ],
    "ips": [
      "10.29.0.183"
    ],
    "name": "clustermesh-apiserver-7ff8b756ff-dgr2g",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbacb63b0_6bc4_4307_b338_9e6ca7578132.slice/cri-containerd-15bbc6b55f6e9e5081324759f6cba3fc2f2036445963735a151f9ff890d24f88.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbacb63b0_6bc4_4307_b338_9e6ca7578132.slice/cri-containerd-b358452d4ddd5cd90dd12b8b8ba73dcb9464c7d6655d7fe2f792582bd6f2625c.scope"
      }
    ],
    "ips": [
      "10.29.0.115"
    ],
    "name": "echo-same-node-86d9cc975c-jc6h6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod746b4637_5be6_4414_b378_f0e9b6b7c2de.slice/cri-containerd-86a10b18be41fe2c2d329db9112e7cbbe83f27c88255e24488d00539f7d5f039.scope"
      }
    ],
    "ips": [
      "10.29.0.218"
    ],
    "name": "coredns-cc6ccd49c-wct5l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84751056_24f2_4435_a69d_b3c8301109c5.slice/cri-containerd-3fe6f38e04f0117c389cc895f161ceb8fe81e59babaf025fbd0783ea7efb210b.scope"
      }
    ],
    "ips": [
      "10.29.0.224"
    ],
    "name": "client2-57cf4468f-l54b2",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc608ca4_2e61_41fa_b0e4_1119513dc6f0.slice/cri-containerd-919199e079499a47aa5a3edc308057238dae6a81d6268ec455adb75dce7ddce6.scope"
      }
    ],
    "ips": [
      "10.29.0.157"
    ],
    "name": "coredns-cc6ccd49c-gjjpc",
    "namespace": "kube-system"
  }
]

