 12:54:18 up 33 min,  0 users,  load average: 0.54, 0.63, 0.35
