key: e2 00 00 00  value: 09 02 00 00
key: ca 01 00 00  value: e7 0c 00 00
key: ff 03 00 00  value: 00 02 00 00
key: 1d 07 00 00  value: 1b 0d 00 00
key: 6e 08 00 00  value: 17 0d 00 00
key: b7 08 00 00  value: 78 02 00 00
key: 9b 0a 00 00  value: 1c 02 00 00
Found 7 elements
