top - 12:54:18 up 33 min,  0 users,  load average: 0.54, 0.63, 0.35
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.9 us, 35.7 sy,  0.0 ni, 46.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    286.4 free,   1051.6 used,   2498.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2603.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 293452  79804 S   6.7   7.5   1:21.74 cilium-+
    416 root      20   0 1229744   8860   2868 S   0.0   0.2   0:04.74 cilium-+
   3227 root      20   0 1240432  15500  10512 S   0.0   0.4   0:00.02 cilium-+
   3233 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3263 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3288 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
