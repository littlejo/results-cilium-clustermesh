Endpoint ID: 110
Path: /sys/fs/bpf/tc/globals/cilium_policy_00110

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 226
Path: /sys/fs/bpf/tc/globals/cilium_policy_00226

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6224114   76920     0        
Allow    Ingress     1          ANY          NONE         disabled    66702     803       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 458
Path: /sys/fs/bpf/tc/globals/cilium_policy_00458

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379710   4433      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1023
Path: /sys/fs/bpf/tc/globals/cilium_policy_01023

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1940     20        0        
Allow    Ingress     1          ANY          NONE         disabled    162016   1862      0        
Allow    Egress      0          ANY          NONE         disabled    22229    250       0        


Endpoint ID: 1821
Path: /sys/fs/bpf/tc/globals/cilium_policy_01821

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2158
Path: /sys/fs/bpf/tc/globals/cilium_policy_02158

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2231
Path: /sys/fs/bpf/tc/globals/cilium_policy_02231

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6137410   61579     0        
Allow    Ingress     1          ANY          NONE         disabled    5330109   56165     0        
Allow    Egress      0          ANY          NONE         disabled    6693477   66258     0        


Endpoint ID: 2715
Path: /sys/fs/bpf/tc/globals/cilium_policy_02715

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3956     40        0        
Allow    Ingress     1          ANY          NONE         disabled    162346   1867      0        
Allow    Egress      0          ANY          NONE         disabled    20265    227       0        


