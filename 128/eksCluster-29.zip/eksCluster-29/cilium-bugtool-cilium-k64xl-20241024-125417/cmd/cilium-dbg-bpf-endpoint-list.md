IP ADDRESS         LOCAL ENDPOINT INFO
10.29.0.224:0      id=1821  sec_id=1993353 flags=0x0000 ifindex=22  mac=3A:5A:1A:74:9F:DC nodemac=CA:CA:BC:1D:AC:57   
10.29.0.183:0      id=2231  sec_id=1973336 flags=0x0000 ifindex=18  mac=4A:DE:04:08:CB:42 nodemac=3E:D3:AB:AB:CE:F2   
172.31.224.108:0   (localhost)                                                                                        
10.29.0.179:0      id=226   sec_id=4     flags=0x0000 ifindex=10  mac=CE:21:A9:60:D2:5B nodemac=96:4A:86:52:B2:A5     
10.29.0.31:0       id=2158  sec_id=1973593 flags=0x0000 ifindex=20  mac=86:73:8A:9E:7A:49 nodemac=E6:9D:EF:D4:26:A9   
10.29.0.29:0       (localhost)                                                                                        
10.29.0.157:0      id=1023  sec_id=2002441 flags=0x0000 ifindex=14  mac=4E:71:66:F0:F9:D9 nodemac=2E:7F:FC:74:F3:D9   
172.31.202.253:0   (localhost)                                                                                        
10.29.0.218:0      id=2715  sec_id=2002441 flags=0x0000 ifindex=12  mac=FE:0E:B7:2F:86:53 nodemac=62:77:00:83:51:9E   
10.29.0.115:0      id=458   sec_id=2003116 flags=0x0000 ifindex=24  mac=C6:71:9C:07:89:CA nodemac=E2:0E:98:B4:42:72   
