alloc: 88.11MB (92386960 bytes)
total-alloc: 3.13GB (3363020080 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75753480
frees: 74963551
heap-alloc: 88.11MB (92386960 bytes)
heap-sys: 176.79MB (185376768 bytes)
heap-idle: 51.08MB (53559296 bytes)
heap-in-use: 125.71MB (131817472 bytes)
heap-released: 10.41MB (10919936 bytes)
heap-objects: 789929
stack-in-use: 35.19MB (36896768 bytes)
stack-sys: 35.19MB (36896768 bytes)
stack-mspan-inuse: 2.11MB (2214720 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1015.17KB (1039529 bytes)
gc-sys: 5.50MB (5764144 bytes)
next-gc: when heap-alloc >= 149.55MB (156817224 bytes)
last-gc: 2024-10-24 12:54:34.240935123 +0000 UTC
gc-pause-total: 11.203893ms
gc-pause: 66050
gc-pause-end: 1729774474240935123
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.0006094115899122369
enable-gc: true
debug-gc: false
