xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 575
ens6(5) clsact/ingress cil_from_netdev-ens6 id 586
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 571
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 563
cilium_host(7) clsact/egress cil_from_host-cilium_host id 561
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 525
lxcddcdacc85486(12) clsact/ingress cil_from_container-lxcddcdacc85486 id 536
lxc128df01e7929(14) clsact/ingress cil_from_container-lxc128df01e7929 id 511
lxcf7f52510cf80(18) clsact/ingress cil_from_container-lxcf7f52510cf80 id 635
lxc8d8e9a335f71(20) clsact/ingress cil_from_container-lxc8d8e9a335f71 id 3348
lxc8ae13fa7b703(22) clsact/ingress cil_from_container-lxc8ae13fa7b703 id 3346
lxcfee5966371e4(24) clsact/ingress cil_from_container-lxcfee5966371e4 id 3289

flow_dissector:

netfilter:

