1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:bd:16:93:aa:7f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.224.108/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3418sec preferred_lft 3418sec
    inet6 fe80::8bd:16ff:fe93:aa7f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b5:96:11:c4:85 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.202.253/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8b5:96ff:fe11:c485/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:4d:75:2f:49:01 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::844d:75ff:fe2f:4901/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:ca:da:7c:db:ce brd ff:ff:ff:ff:ff:ff
    inet 10.29.0.29/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::38ca:daff:fe7c:dbce/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether aa:ce:54:2a:b5:a4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a8ce:54ff:fe2a:b5a4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:4a:86:52:b2:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::944a:86ff:fe52:b2a5/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcddcdacc85486@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:77:00:83:51:9e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::6077:ff:fe83:519e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc128df01e7929@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:7f:fc:74:f3:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::2c7f:fcff:fe74:f3d9/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf7f52510cf80@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:d3:ab:ab:ce:f2 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3cd3:abff:feab:cef2/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc8d8e9a335f71@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:9d:ef:d4:26:a9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e49d:efff:fed4:26a9/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc8ae13fa7b703@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:ca:bc:1d:ac:57 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::c8ca:bcff:fe1d:ac57/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcfee5966371e4@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:0e:98:b4:42:72 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::e00e:98ff:feb4:4272/64 scope link 
       valid_lft forever preferred_lft forever
