Node 0, zone      DMA    185     45     12     46     18     13      6      3      1      4     40 
Node 0, zone   Normal    670     94     25     26     13      5      2      3      2      2      7 
