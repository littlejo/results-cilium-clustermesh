filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcfee5966371e4 direct-action not_in_hw id 3289 tag edaa9fa9bd6f822c jited 
