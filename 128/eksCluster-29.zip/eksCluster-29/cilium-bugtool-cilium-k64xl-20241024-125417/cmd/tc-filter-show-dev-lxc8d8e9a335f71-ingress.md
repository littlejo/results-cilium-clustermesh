filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8d8e9a335f71 direct-action not_in_hw id 3348 tag 7464f881a76bab5a jited 
