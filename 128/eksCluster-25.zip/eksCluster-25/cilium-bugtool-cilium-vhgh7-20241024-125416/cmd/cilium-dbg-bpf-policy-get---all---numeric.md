Endpoint ID: 48
Path: /sys/fs/bpf/tc/globals/cilium_policy_00048

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    214483   1934      0        
Allow    Ingress     1          ANY          NONE         disabled    165398   1899      0        
Allow    Egress      0          ANY          NONE         disabled    67623    672       0        


Endpoint ID: 964
Path: /sys/fs/bpf/tc/globals/cilium_policy_00964

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2152
Path: /sys/fs/bpf/tc/globals/cilium_policy_02152

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2794
Path: /sys/fs/bpf/tc/globals/cilium_policy_02794

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3121
Path: /sys/fs/bpf/tc/globals/cilium_policy_03121

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6227880   76957     0        
Allow    Ingress     1          ANY          NONE         disabled    61322     738       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3230
Path: /sys/fs/bpf/tc/globals/cilium_policy_03230

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6114004   61286     0        
Allow    Ingress     1          ANY          NONE         disabled    5284958   55743     0        
Allow    Egress      0          ANY          NONE         disabled    6678053   66019     0        


Endpoint ID: 3422
Path: /sys/fs/bpf/tc/globals/cilium_policy_03422

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    375356   4382      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3883
Path: /sys/fs/bpf/tc/globals/cilium_policy_03883

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    224984   2033      0        
Allow    Ingress     1          ANY          NONE         disabled    162824   1860      0        
Allow    Egress      0          ANY          NONE         disabled    68314    682       0        


