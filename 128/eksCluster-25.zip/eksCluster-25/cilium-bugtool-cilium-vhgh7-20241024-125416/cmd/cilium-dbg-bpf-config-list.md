KEY             VALUE
AgentLiveness   3397363154091
UTimeOffset     3378459162109375
