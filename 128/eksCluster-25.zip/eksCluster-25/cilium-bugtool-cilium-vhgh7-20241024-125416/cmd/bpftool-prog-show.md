29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T11:58:14+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T11:58:19+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:58:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:58:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T11:58:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:25:59+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
479: sched_cls  name tail_handle_ipv4  tag 4f7778106fc1115a  gpl
	loaded_at 2024-10-24T12:25:59+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:25:59+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:25:59+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
511: sched_cls  name tail_handle_ipv4  tag 0d08b31af660841c  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 163
512: sched_cls  name tail_handle_ipv4_cont  tag a9630b27f4714ce1  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 165
513: sched_cls  name __send_drop_notify  tag 6fcdfe1aae6c123b  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 166
516: sched_cls  name tail_ipv4_ct_ingress  tag f143bd44e44575b3  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 168
517: sched_cls  name cil_from_container  tag b0a06ec83d5dba17  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 170
518: sched_cls  name tail_ipv4_to_endpoint  tag 39ee582c74c01bbc  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 171
520: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 172
522: sched_cls  name tail_ipv4_ct_egress  tag ee72614f1329df8d  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 174
529: sched_cls  name handle_policy  tag 156695fe0dd7192f  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 178
530: sched_cls  name tail_handle_arp  tag f511586466fab354  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 183
532: sched_cls  name cil_from_container  tag 7f603b028d30cbbf  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 185
533: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 188
535: sched_cls  name tail_handle_ipv4_from_host  tag 4fa1cbe77ecf19ce  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 190
537: sched_cls  name __send_drop_notify  tag e7126a0a5363fce0  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
538: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
539: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 194
540: sched_cls  name tail_handle_ipv4_from_host  tag 4fa1cbe77ecf19ce  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 196
541: sched_cls  name tail_ipv4_to_endpoint  tag 9c0c7f241e0aa352  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 186
543: sched_cls  name tail_handle_ipv4_cont  tag 0787ac26070b9521  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 197
544: sched_cls  name __send_drop_notify  tag e7126a0a5363fce0  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
545: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
546: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 201
549: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 204
551: sched_cls  name tail_handle_ipv4_from_host  tag 4fa1cbe77ecf19ce  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 207
552: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 209
553: sched_cls  name tail_ipv4_ct_egress  tag ee72614f1329df8d  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 208
554: sched_cls  name __send_drop_notify  tag e7126a0a5363fce0  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 212
558: sched_cls  name tail_handle_ipv4  tag 131f9c804632e830  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 214
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 217
563: sched_cls  name tail_handle_ipv4_from_host  tag 4fa1cbe77ecf19ce  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 220
564: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 221
565: sched_cls  name __send_drop_notify  tag e7126a0a5363fce0  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 222
566: sched_cls  name tail_handle_arp  tag 554b5d89a4779b41  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 223
567: sched_cls  name tail_handle_ipv4  tag 015e5e4f67434292  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 225
568: sched_cls  name tail_handle_arp  tag 79fac15b3a1bd62f  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 227
569: sched_cls  name handle_policy  tag 6db80ee4f53b2c88  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 226
570: sched_cls  name tail_ipv4_ct_ingress  tag 2aba1a5c50775a80  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 229
572: sched_cls  name __send_drop_notify  tag ea3552bae160c44a  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 231
573: sched_cls  name tail_ipv4_to_endpoint  tag 3b28e34812da4def  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 228
575: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
578: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
579: sched_cls  name handle_policy  tag 72b59fbf1e3066cd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 233
580: sched_cls  name __send_drop_notify  tag 32436b3357fc446a  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 234
581: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 235
582: sched_cls  name tail_ipv4_ct_ingress  tag a80c6c6b4dd013e1  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 236
583: sched_cls  name cil_from_container  tag 7957206d395b67f2  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 237
584: sched_cls  name tail_handle_ipv4_cont  tag a7982f28dd1e7709  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 238
585: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 239
586: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
589: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
594: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
597: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: sched_cls  name tail_ipv4_ct_egress  tag 90dd54e80058dafe  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 253
638: sched_cls  name tail_ipv4_ct_ingress  tag d3ef51984b8a2510  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 254
639: sched_cls  name tail_handle_ipv4  tag 83ccb443e57344d1  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 255
640: sched_cls  name tail_handle_arp  tag 95cc64a9b4b87fa4  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 256
641: sched_cls  name cil_from_container  tag d0669f456fa89841  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 257
642: sched_cls  name tail_handle_ipv4_cont  tag 4b6810e385bce382  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 258
643: sched_cls  name tail_ipv4_to_endpoint  tag 441f61f094ec866c  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 259
645: sched_cls  name __send_drop_notify  tag d02ffaa9e18e7c2c  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 261
646: sched_cls  name handle_policy  tag 568188365c20a6b3  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 262
647: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 263
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
701: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
704: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
713: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
716: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
717: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
720: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
721: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
724: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
725: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
728: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
729: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
732: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
733: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
736: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3305: sched_cls  name tail_ipv4_ct_ingress  tag 1061ebbef6cb1ec1  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3104
3308: sched_cls  name cil_from_container  tag 5293822c0240f5d2  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3106
3309: sched_cls  name tail_handle_ipv4_cont  tag 128d6b5ad10f09cc  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,154,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3108
3314: sched_cls  name handle_policy  tag 2e94e7ce7123ac92  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,154,39,84,75,40,37,38
	btf_id 3109
3315: sched_cls  name tail_handle_arp  tag b26dfdc34b3543ee  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3113
3316: sched_cls  name __send_drop_notify  tag 286b3b6af7c4d61a  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3114
3317: sched_cls  name tail_handle_ipv4  tag c22993ffb49c28ed  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3115
3318: sched_cls  name tail_ipv4_ct_egress  tag 83955eb8dc5b3031  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3116
3319: sched_cls  name tail_ipv4_to_endpoint  tag 9e2098b37922d8c6  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,154,39,636,40,37,38
	btf_id 3117
3320: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3118
3344: sched_cls  name cil_from_container  tag 06a31a60e55c2cbd  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 644,76
	btf_id 3147
3345: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,641
	btf_id 3145
3346: sched_cls  name tail_handle_arp  tag 6eea450010bb216e  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,641
	btf_id 3149
3347: sched_cls  name tail_handle_ipv4  tag 6964b0595430cddf  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,644
	btf_id 3148
3348: sched_cls  name handle_policy  tag 9dcba52ad55b295b  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,641,82,83,642,41,80,155,39,84,75,40,37,38
	btf_id 3150
3349: sched_cls  name tail_handle_ipv4_cont  tag 4429b54565e8f69c  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,642,41,155,82,83,39,76,74,77,641,40,37,38,81
	btf_id 3152
3350: sched_cls  name __send_drop_notify  tag da24c2ff38cfedae  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3153
3351: sched_cls  name tail_ipv4_ct_egress  tag 7b23de67559594a9  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3154
3352: sched_cls  name handle_policy  tag e31b2f3d91305627  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,644,82,83,643,41,80,151,39,84,75,40,37,38
	btf_id 3151
3353: sched_cls  name tail_ipv4_to_endpoint  tag 93bbab07f6fdd5f3  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,642,41,82,83,80,155,39,641,40,37,38
	btf_id 3155
3354: sched_cls  name cil_from_container  tag 0ea259e211786edf  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 641,76
	btf_id 3157
3356: sched_cls  name tail_ipv4_ct_ingress  tag 29e36a7e8a50f0bb  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3156
3358: sched_cls  name tail_handle_ipv4_cont  tag 2cda0f7bfeeddbc1  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,643,41,151,82,83,39,76,74,77,644,40,37,38,81
	btf_id 3161
3359: sched_cls  name tail_handle_ipv4  tag 761c11520dcbc481  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,641
	btf_id 3160
3360: sched_cls  name tail_handle_arp  tag 1c3d32d559b1d778  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,644
	btf_id 3162
3361: sched_cls  name tail_ipv4_ct_egress  tag 9a5ef4f8ff2767b0  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3164
3362: sched_cls  name tail_ipv4_ct_ingress  tag 49b9a4e15eeb6eff  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3163
3363: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,644
	btf_id 3165
3364: sched_cls  name tail_ipv4_to_endpoint  tag 61ed96601bf161e5  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,643,41,82,83,80,151,39,644,40,37,38
	btf_id 3166
3365: sched_cls  name __send_drop_notify  tag 1b2fc9d76d241cfd  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3167
