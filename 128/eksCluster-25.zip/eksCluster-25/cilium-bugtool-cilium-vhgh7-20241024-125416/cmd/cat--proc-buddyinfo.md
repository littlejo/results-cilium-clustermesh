Node 0, zone      DMA    127    173     18     28     18      4      3      3      2      2     37 
Node 0, zone   Normal    288     63      3     10     24      6     11      8      3      0      7 
