markdown output at /tmp/cilium-bugtool-20241024-125417.649+0000-UTC-3200258989/cmd/cilium-debuginfo-20241024-125448.501+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.649+0000-UTC-3200258989/cmd/cilium-debuginfo-20241024-125448.501+0000-UTC.json
