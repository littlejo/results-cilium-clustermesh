alloc: 116.92MB (122594888 bytes)
total-alloc: 3.07GB (3292640080 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 74841653
frees: 73686079
heap-alloc: 116.92MB (122594888 bytes)
heap-sys: 176.77MB (185352192 bytes)
heap-idle: 35.97MB (37715968 bytes)
heap-in-use: 140.80MB (147636224 bytes)
heap-released: 9.75MB (10223616 bytes)
heap-objects: 1155574
stack-in-use: 35.19MB (36896768 bytes)
stack-sys: 35.19MB (36896768 bytes)
stack-mspan-inuse: 2.20MB (2305920 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 717.95KB (735177 bytes)
gc-sys: 5.56MB (5831992 bytes)
next-gc: when heap-alloc >= 147.85MB (155028600 bytes)
last-gc: 2024-10-24 12:54:20.914003841 +0000 UTC
gc-pause-total: 18.119637ms
gc-pause: 77809
gc-pause-end: 1729774460914003841
num-gc: 103
num-forced-gc: 0
gc-cpu-fraction: 0.0006129912721353401
enable-gc: true
debug-gc: false
