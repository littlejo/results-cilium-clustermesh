2024-10-24T11:58:11,000000+00:00 Booting Linux on physical CPU 0x0000000000 [0x413fd0c1]
2024-10-24T11:58:11,000000+00:00 Linux version 6.1.112-122.189.amzn2023.aarch64 (mockbuild@ip-10-0-39-248) (gcc (GCC) 11.4.1 20230605 (Red Hat 11.4.1-2), GNU ld version 2.39-6.amzn2023.0.10) #1 SMP Tue Oct  8 17:01:34 UTC 2024
2024-10-24T11:58:11,000000+00:00 efi: EFI v2.70 by EDK II
2024-10-24T11:58:11,000000+00:00 efi: SMBIOS=0x7bed0000 SMBIOS 3.0=0x7beb0000 ACPI=0x786e0000 ACPI 2.0=0x786e0014 MEMATTR=0x7aff0a98 RNG=0x74ca0018 MEMRESERVE=0x784d0d98 
2024-10-24T11:58:11,000000+00:00 random: crng init done
2024-10-24T11:58:11,000000+00:00 ACPI: Early table checksum verification disabled
2024-10-24T11:58:11,000000+00:00 ACPI: RSDP 0x00000000786E0014 000024 (v02 AMAZON)
2024-10-24T11:58:11,000000+00:00 ACPI: XSDT 0x00000000786D00E8 000064 (v01 AMAZON AMZNFACP 00000001      01000013)
2024-10-24T11:58:11,000000+00:00 ACPI: FACP 0x00000000786B0000 000114 (v06 AMAZON AMZNFACP 00000001 AMZN 00000001)
2024-10-24T11:58:11,000000+00:00 ACPI: DSDT 0x0000000078640000 00159D (v02 AMAZON AMZNDSDT 00000001 INTL 20160527)
2024-10-24T11:58:11,000000+00:00 ACPI: FACS 0x0000000078630000 000040
2024-10-24T11:58:11,000000+00:00 ACPI: APIC 0x00000000786C0000 000108 (v04 AMAZON AMZNAPIC 00000001 AMZN 00000001)
2024-10-24T11:58:11,000000+00:00 ACPI: SPCR 0x00000000786A0000 000050 (v02 AMAZON AMZNSPCR 00000001 AMZN 00000001)
2024-10-24T11:58:11,000000+00:00 ACPI: GTDT 0x0000000078690000 000060 (v02 AMAZON AMZNGTDT 00000001 AMZN 00000001)
2024-10-24T11:58:11,000000+00:00 ACPI: MCFG 0x0000000078680000 00003C (v02 AMAZON AMZNMCFG 00000001 AMZN 00000001)
2024-10-24T11:58:11,000000+00:00 ACPI: SLIT 0x0000000078670000 00002D (v01 AMAZON AMZNSLIT 00000001 AMZN 00000001)
2024-10-24T11:58:11,000000+00:00 ACPI: IORT 0x0000000078660000 000078 (v01 AMAZON AMZNIORT 00000001 AMZN 00000001)
2024-10-24T11:58:11,000000+00:00 ACPI: PPTT 0x0000000078650000 0000D4 (v02 AMAZON AMZNPPTT 00000001 AMZN 00000001)
2024-10-24T11:58:11,000000+00:00 ACPI: SPCR: console: uart,mmio,0x90a0000,115200
2024-10-24T11:58:11,000000+00:00 NUMA: Failed to initialise from firmware
2024-10-24T11:58:11,000000+00:00 NUMA: Faking a node at [mem 0x0000000040000000-0x00000004bb7fffff]
2024-10-24T11:58:11,000000+00:00 NUMA: NODE_DATA [mem 0x4bb01a7c0-0x4bb01cfff]
2024-10-24T11:58:11,000000+00:00 Zone ranges:
2024-10-24T11:58:11,000000+00:00   DMA      [mem 0x0000000040000000-0x00000000ffffffff]
2024-10-24T11:58:11,000000+00:00   DMA32    empty
2024-10-24T11:58:11,000000+00:00   Normal   [mem 0x0000000100000000-0x00000004bb7fffff]
2024-10-24T11:58:11,000000+00:00   Device   empty
2024-10-24T11:58:11,000000+00:00 Movable zone start for each node
2024-10-24T11:58:11,000000+00:00 Early memory node ranges
2024-10-24T11:58:11,000000+00:00   node   0: [mem 0x0000000040000000-0x000000007862ffff]
2024-10-24T11:58:11,000000+00:00   node   0: [mem 0x0000000078630000-0x000000007863ffff]
2024-10-24T11:58:11,000000+00:00   node   0: [mem 0x0000000078640000-0x00000000786effff]
2024-10-24T11:58:11,000000+00:00   node   0: [mem 0x00000000786f0000-0x000000007872ffff]
2024-10-24T11:58:11,000000+00:00   node   0: [mem 0x0000000078730000-0x000000007bbfffff]
2024-10-24T11:58:11,000000+00:00   node   0: [mem 0x000000007bc00000-0x000000007bfdffff]
2024-10-24T11:58:11,000000+00:00   node   0: [mem 0x000000007bfe0000-0x000000007fffffff]
2024-10-24T11:58:11,000000+00:00   node   0: [mem 0x0000000400000000-0x00000004bb7fffff]
2024-10-24T11:58:11,000000+00:00 Initmem setup node 0 [mem 0x0000000040000000-0x00000004bb7fffff]
2024-10-24T11:58:11,000000+00:00 On node 0, zone Normal: 18432 pages in unavailable ranges
2024-10-24T11:58:11,000000+00:00 cma: Reserved 64 MiB at 0x000000007c000000 on node -1
2024-10-24T11:58:11,000000+00:00 psci: probing for conduit method from ACPI.
2024-10-24T11:58:11,000000+00:00 psci: PSCIv1.0 detected in firmware.
2024-10-24T11:58:11,000000+00:00 psci: Using standard PSCI v0.2 function IDs
2024-10-24T11:58:11,000000+00:00 psci: Trusted OS migration not required
2024-10-24T11:58:11,000000+00:00 psci: SMC Calling Convention v1.1
2024-10-24T11:58:11,000000+00:00 percpu: Embedded 31 pages/cpu s86440 r8192 d32344 u126976
2024-10-24T11:58:11,000000+00:00 pcpu-alloc: s86440 r8192 d32344 u126976 alloc=31*4096
2024-10-24T11:58:11,000000+00:00 pcpu-alloc: [0] 0 [0] 1 
2024-10-24T11:58:11,000000+00:00 Detected PIPT I-cache on CPU0
2024-10-24T11:58:11,000000+00:00 CPU features: detected: GIC system register CPU interface
2024-10-24T11:58:11,000000+00:00 CPU features: detected: Hardware dirty bit management
2024-10-24T11:58:11,000000+00:00 CPU features: detected: Spectre-v4
2024-10-24T11:58:11,000000+00:00 CPU features: detected: Spectre-BHB
2024-10-24T11:58:11,000000+00:00 CPU features: detected: ARM erratum 1418040
2024-10-24T11:58:11,000000+00:00 CPU features: detected: ARM erratum 1542419 (kernel portion)
2024-10-24T11:58:11,000000+00:00 CPU features: detected: SSBS not fully self-synchronizing
2024-10-24T11:58:11,000000+00:00 alternatives: applying boot alternatives
2024-10-24T11:58:11,000000+00:00 Fallback order for Node 0: 0 
2024-10-24T11:58:11,000000+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 1014048
2024-10-24T11:58:11,000000+00:00 Policy zone: Normal
2024-10-24T11:58:11,000000+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64 root=UUID=b5c7fae5-1de8-4038-8408-06c720e69aff ro console=tty0 console=ttyS0,115200n8 nvme_core.io_timeout=4294967295 rd.emergency=poweroff rd.shell=0 selinux=1 security=selinux quiet numa_cma=1:64M
2024-10-24T11:58:11,000000+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64", will be passed to user space.
2024-10-24T11:58:11,000000+00:00 Dentry cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-10-24T11:58:11,000000+00:00 Inode-cache hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2024-10-24T11:58:11,000000+00:00 mem auto-init: stack:off, heap alloc:off, heap free:off
2024-10-24T11:58:11,000000+00:00 software IO TLB: area num 2.
2024-10-24T11:58:11,000000+00:00 software IO TLB: mapped [mem 0x000000006de00000-0x0000000071e00000] (64MB)
2024-10-24T11:58:11,000000+00:00 Memory: 3846296K/4120576K available (12096K kernel code, 8838K rwdata, 8416K rodata, 4480K init, 11359K bss, 208744K reserved, 65536K cma-reserved)
2024-10-24T11:58:11,000000+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-10-24T11:58:11,000000+00:00 ftrace: allocating 40237 entries in 158 pages
2024-10-24T11:58:11,000000+00:00 ftrace: allocated 158 pages with 5 groups
2024-10-24T11:58:11,000000+00:00 trace event string verifier disabled
2024-10-24T11:58:11,000000+00:00 rcu: Hierarchical RCU implementation.
2024-10-24T11:58:11,000000+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=4096 to nr_cpu_ids=2.
2024-10-24T11:58:11,000000+00:00 	Rude variant of Tasks RCU enabled.
2024-10-24T11:58:11,000000+00:00 	Tracing variant of Tasks RCU enabled.
2024-10-24T11:58:11,000000+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 10 jiffies.
2024-10-24T11:58:11,000000+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-10-24T11:58:11,000000+00:00 NR_IRQS: 64, nr_irqs: 64, preallocated irqs: 0
2024-10-24T11:58:11,000000+00:00 GICv3: 96 SPIs implemented
2024-10-24T11:58:11,000000+00:00 GICv3: 0 Extended SPIs implemented
2024-10-24T11:58:11,000000+00:00 Root IRQ handler: gic_handle_irq
2024-10-24T11:58:11,000000+00:00 GICv3: GICv3 features: 16 PPIs
2024-10-24T11:58:11,000000+00:00 GICv3: CPU0: found redistributor 0 region 0:0x0000000010200000
2024-10-24T11:58:11,000000+00:00 ITS [mem 0x10080000-0x1009ffff]
2024-10-24T11:58:11,000000+00:00 ITS@0x0000000010080000: allocated 8192 Devices @4001a0000 (indirect, esz 8, psz 64K, shr 1)
2024-10-24T11:58:11,000000+00:00 ITS@0x0000000010080000: allocated 8192 Interrupt Collections @4001b0000 (flat, esz 8, psz 64K, shr 1)
2024-10-24T11:58:11,000000+00:00 GICv3: using LPI property table @0x00000004001c0000
2024-10-24T11:58:11,000000+00:00 ITS: Using hypervisor restricted LPI range [128]
2024-10-24T11:58:11,000000+00:00 GICv3: CPU0: using allocated LPI pending table @0x00000004001d0000
2024-10-24T11:58:11,000000+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-10-24T11:58:11,000000+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-24T11:58:11,000000+00:00 arch_timer: cp15 timer(s) running at 121.87MHz (virt).
2024-10-24T11:58:11,000000+00:00 clocksource: arch_sys_counter: mask: 0x3ffffffffffffff max_cycles: 0x383759f8ff, max_idle_ns: 881590415659 ns
2024-10-24T11:58:11,000000+00:00 sched_clock: 58 bits at 122MHz, resolution 8ns, wraps every 4398046511103ns
2024-10-24T11:58:11,000021+00:00 arm-pv: using stolen time PV
2024-10-24T11:58:11,000089+00:00 Console: colour dummy device 80x25
2024-10-24T11:58:11,000103+00:00 printk: console [tty0] enabled
2024-10-24T11:58:11,000121+00:00 ACPI: Core revision 20220331
2024-10-24T11:58:11,000156+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 243.75 BogoMIPS (lpj=1218750)
2024-10-24T11:58:11,000159+00:00 pid_max: default: 32768 minimum: 301
2024-10-24T11:58:11,000180+00:00 LSM: Security Framework initializing
2024-10-24T11:58:11,000196+00:00 Yama: becoming mindful.
2024-10-24T11:58:11,000204+00:00 SELinux:  Initializing.
2024-10-24T11:58:11,000219+00:00 LSM support for eBPF active
2024-10-24T11:58:11,000237+00:00 Mount-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-10-24T11:58:11,000241+00:00 Mountpoint-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-10-24T11:58:11,000584+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-24T11:58:11,000586+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-24T11:58:11,000599+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-24T11:58:11,000600+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-24T11:58:11,000641+00:00 rcu: Hierarchical SRCU implementation.
2024-10-24T11:58:11,000643+00:00 rcu: 	Max phase no-delay instances is 1000.
2024-10-24T11:58:11,000843+00:00 Platform MSI: ITS@0x10080000 domain created
2024-10-24T11:58:11,000849+00:00 PCI/MSI: ITS@0x10080000 domain created
2024-10-24T11:58:11,000854+00:00 Remapping and enabling EFI services.
2024-10-24T11:58:11,000968+00:00 smp: Bringing up secondary CPUs ...
2024-10-24T11:58:11,001138+00:00 Detected PIPT I-cache on CPU1
2024-10-24T11:58:11,001167+00:00 GICv3: CPU1: found redistributor 1 region 0:0x0000000010220000
2024-10-24T11:58:11,001195+00:00 GICv3: CPU1: using allocated LPI pending table @0x00000004001e0000
2024-10-24T11:58:11,001214+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-24T11:58:11,001230+00:00 CPU1: Booted secondary processor 0x0000000001 [0x413fd0c1]
2024-10-24T11:58:11,001309+00:00 smp: Brought up 1 node, 2 CPUs
2024-10-24T11:58:11,001314+00:00 SMP: Total of 2 processors activated.
2024-10-24T11:58:11,001316+00:00 CPU features: detected: 32-bit EL0 Support
2024-10-24T11:58:11,001317+00:00 CPU features: detected: Instruction cache invalidation not required for I/D coherence
2024-10-24T11:58:11,001319+00:00 CPU features: detected: Data cache clean to the PoU not required for I/D coherence
2024-10-24T11:58:11,001320+00:00 CPU features: detected: Common not Private translations
2024-10-24T11:58:11,001321+00:00 CPU features: detected: CRC32 instructions
2024-10-24T11:58:11,001323+00:00 CPU features: detected: RCpc load-acquire (LDAPR)
2024-10-24T11:58:11,001324+00:00 CPU features: detected: LSE atomic instructions
2024-10-24T11:58:11,001324+00:00 CPU features: detected: Privileged Access Never
2024-10-24T11:58:11,001325+00:00 CPU features: detected: RAS Extension Support
2024-10-24T11:58:11,001327+00:00 CPU features: detected: Speculative Store Bypassing Safe (SSBS)
2024-10-24T11:58:11,001375+00:00 CPU: All CPU(s) started at EL1
2024-10-24T11:58:11,001379+00:00 alternatives: applying system-wide alternatives
2024-10-24T11:58:11,003645+00:00 devtmpfs: initialized
2024-10-24T11:58:11,004127+00:00 Registered cp15_barrier emulation handler
2024-10-24T11:58:11,004139+00:00 Registered setend emulation handler
2024-10-24T11:58:11,004177+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604462750000 ns
2024-10-24T11:58:11,004181+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-10-24T11:58:11,004409+00:00 pinctrl core: initialized pinctrl subsystem
2024-10-24T11:58:11,004458+00:00 SMBIOS 3.0.0 present.
2024-10-24T11:58:11,004461+00:00 DMI: Amazon EC2 t4g.medium/, BIOS 1.0 11/1/2018
2024-10-24T11:58:11,004566+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-10-24T11:58:11,004754+00:00 DMA: preallocated 512 KiB GFP_KERNEL pool for atomic allocations
2024-10-24T11:58:11,004777+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-10-24T11:58:11,004809+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-10-24T11:58:11,004820+00:00 audit: initializing netlink subsys (disabled)
2024-10-24T11:58:11,004874+00:00 audit: type=2000 audit(0.000:1): state=initialized audit_enabled=0 res=1
2024-10-24T11:58:11,004930+00:00 thermal_sys: Registered thermal governor 'fair_share'
2024-10-24T11:58:11,004931+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-10-24T11:58:11,004932+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-10-24T11:58:11,004940+00:00 cpuidle: using governor ladder
2024-10-24T11:58:11,004944+00:00 cpuidle: using governor menu
2024-10-24T11:58:11,004983+00:00 hw-breakpoint: found 6 breakpoint and 4 watchpoint registers.
2024-10-24T11:58:11,005016+00:00 ASID allocator initialised with 65536 entries
2024-10-24T11:58:11,005022+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-10-24T11:58:11,005035+00:00 Serial: AMBA PL011 UART driver
2024-10-24T11:58:11,010150+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2024-10-24T11:58:11,010154+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 1.00 GiB page
2024-10-24T11:58:11,010156+00:00 HugeTLB: registered 32.0 MiB page size, pre-allocated 0 pages
2024-10-24T11:58:11,010157+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 32.0 MiB page
2024-10-24T11:58:11,010158+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-10-24T11:58:11,010159+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 2.00 MiB page
2024-10-24T11:58:11,010160+00:00 HugeTLB: registered 64.0 KiB page size, pre-allocated 0 pages
2024-10-24T11:58:11,010161+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 64.0 KiB page
2024-10-24T11:58:11,010671+00:00 ACPI: Added _OSI(Module Device)
2024-10-24T11:58:11,010673+00:00 ACPI: Added _OSI(Processor Device)
2024-10-24T11:58:11,010675+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-10-24T11:58:11,010676+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-10-24T11:58:11,011250+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-10-24T11:58:11,011598+00:00 ACPI: Interpreter enabled
2024-10-24T11:58:11,011600+00:00 ACPI: Using GIC for interrupt routing
2024-10-24T11:58:11,011610+00:00 ACPI: MCFG table detected, 1 entries
2024-10-24T11:58:11,013067+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-0f])
2024-10-24T11:58:11,013077+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-10-24T11:58:11,013117+00:00 acpi PNP0A08:00: _OSC: platform does not support [SHPCHotplug LTR]
2024-10-24T11:58:11,013169+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug PME PCIeCapability]
2024-10-24T11:58:11,013245+00:00 acpi PNP0A08:00: ECAM area [mem 0x20000000-0x20ffffff] reserved by PNP0C02:00
2024-10-24T11:58:11,013251+00:00 acpi PNP0A08:00: ECAM at [mem 0x20000000-0x20ffffff] for [bus 00-0f]
2024-10-24T11:58:11,013265+00:00 ACPI: Remapped I/O 0x000000001fff0000 to [io  0x0000-0xffff window]
2024-10-24T11:58:11,013512+00:00 acpiphp: Slot [1] registered
2024-10-24T11:58:11,013523+00:00 acpiphp: Slot [2] registered
2024-10-24T11:58:11,013533+00:00 acpiphp: Slot [3] registered
2024-10-24T11:58:11,013543+00:00 acpiphp: Slot [4] registered
2024-10-24T11:58:11,013553+00:00 acpiphp: Slot [5] registered
2024-10-24T11:58:11,013563+00:00 acpiphp: Slot [6] registered
2024-10-24T11:58:11,013572+00:00 acpiphp: Slot [7] registered
2024-10-24T11:58:11,013582+00:00 acpiphp: Slot [8] registered
2024-10-24T11:58:11,013591+00:00 acpiphp: Slot [9] registered
2024-10-24T11:58:11,013601+00:00 acpiphp: Slot [10] registered
2024-10-24T11:58:11,013610+00:00 acpiphp: Slot [11] registered
2024-10-24T11:58:11,013619+00:00 acpiphp: Slot [12] registered
2024-10-24T11:58:11,013630+00:00 acpiphp: Slot [13] registered
2024-10-24T11:58:11,013639+00:00 acpiphp: Slot [14] registered
2024-10-24T11:58:11,013651+00:00 acpiphp: Slot [15] registered
2024-10-24T11:58:11,013661+00:00 acpiphp: Slot [16] registered
2024-10-24T11:58:11,013671+00:00 acpiphp: Slot [17] registered
2024-10-24T11:58:11,013680+00:00 acpiphp: Slot [18] registered
2024-10-24T11:58:11,013690+00:00 acpiphp: Slot [19] registered
2024-10-24T11:58:11,013700+00:00 acpiphp: Slot [20] registered
2024-10-24T11:58:11,013709+00:00 acpiphp: Slot [21] registered
2024-10-24T11:58:11,013719+00:00 acpiphp: Slot [22] registered
2024-10-24T11:58:11,013728+00:00 acpiphp: Slot [23] registered
2024-10-24T11:58:11,013738+00:00 acpiphp: Slot [24] registered
2024-10-24T11:58:11,013748+00:00 acpiphp: Slot [25] registered
2024-10-24T11:58:11,013758+00:00 acpiphp: Slot [26] registered
2024-10-24T11:58:11,013767+00:00 acpiphp: Slot [27] registered
2024-10-24T11:58:11,013777+00:00 acpiphp: Slot [28] registered
2024-10-24T11:58:11,013786+00:00 acpiphp: Slot [29] registered
2024-10-24T11:58:11,013796+00:00 acpiphp: Slot [30] registered
2024-10-24T11:58:11,013805+00:00 acpiphp: Slot [31] registered
2024-10-24T11:58:11,013821+00:00 PCI host bridge to bus 0000:00
2024-10-24T11:58:11,013823+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xffffffff window]
2024-10-24T11:58:11,013825+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0xffff window]
2024-10-24T11:58:11,013827+00:00 pci_bus 0000:00: root bus resource [mem 0x400000000000-0x407fffffffff window]
2024-10-24T11:58:11,013828+00:00 pci_bus 0000:00: root bus resource [bus 00-0f]
2024-10-24T11:58:11,013865+00:00 pci 0000:00:00.0: [1d0f:0200] type 00 class 0x060000
2024-10-24T11:58:11,014116+00:00 pci 0000:00:01.0: [1d0f:8250] type 00 class 0x070003
2024-10-24T11:58:11,014166+00:00 pci 0000:00:01.0: reg 0x10: [mem 0x80008000-0x80008fff]
2024-10-24T11:58:11,014364+00:00 pci 0000:00:04.0: [1d0f:8061] type 00 class 0x010802
2024-10-24T11:58:11,015986+00:00 pci 0000:00:04.0: reg 0x10: [mem 0x80004000-0x80007fff]
2024-10-24T11:58:11,022321+00:00 pci 0000:00:04.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T11:58:11,022522+00:00 pci 0000:00:05.0: [1d0f:ec20] type 00 class 0x020000
2024-10-24T11:58:11,022565+00:00 pci 0000:00:05.0: reg 0x10: [mem 0x80000000-0x80003fff]
2024-10-24T11:58:11,022768+00:00 pci 0000:00:05.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T11:58:11,022937+00:00 pci 0000:00:04.0: BAR 0: assigned [mem 0x80000000-0x80003fff]
2024-10-24T11:58:11,023544+00:00 pci 0000:00:05.0: BAR 0: assigned [mem 0x80004000-0x80007fff]
2024-10-24T11:58:11,023553+00:00 pci 0000:00:01.0: BAR 0: assigned [mem 0x80008000-0x80008fff]
2024-10-24T11:58:11,023562+00:00 pci_bus 0000:00: resource 4 [mem 0x80000000-0xffffffff window]
2024-10-24T11:58:11,023564+00:00 pci_bus 0000:00: resource 5 [io  0x0000-0xffff window]
2024-10-24T11:58:11,023566+00:00 pci_bus 0000:00: resource 6 [mem 0x400000000000-0x407fffffffff window]
2024-10-24T11:58:11,023600+00:00 ACPI: PCI: Interrupt link GSI0 configured for IRQ 35
2024-10-24T11:58:11,023607+00:00 ACPI: PCI: Interrupt link GSI1 configured for IRQ 36
2024-10-24T11:58:11,023613+00:00 ACPI: PCI: Interrupt link GSI2 configured for IRQ 37
2024-10-24T11:58:11,023618+00:00 ACPI: PCI: Interrupt link GSI3 configured for IRQ 38
2024-10-24T11:58:11,024005+00:00 iommu: Default domain type: Translated 
2024-10-24T11:58:11,024007+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2024-10-24T11:58:11,024046+00:00 pps_core: LinuxPPS API ver. 1 registered
2024-10-24T11:58:11,024047+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2024-10-24T11:58:11,024050+00:00 PTP clock support registered
2024-10-24T11:58:11,024079+00:00 EDAC MC: Ver: 3.0.0
2024-10-24T11:58:11,024262+00:00 Registered efivars operations
2024-10-24T11:58:11,024481+00:00 NetLabel: Initializing
2024-10-24T11:58:11,024482+00:00 NetLabel:  domain hash size = 128
2024-10-24T11:58:11,024483+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-10-24T11:58:11,024494+00:00 NetLabel:  unlabeled traffic allowed by default
2024-10-24T11:58:11,024538+00:00 vgaarb: loaded
2024-10-24T11:58:11,024644+00:00 clocksource: Switched to clocksource arch_sys_counter
2024-10-24T11:58:11,024718+00:00 VFS: Disk quotas dquot_6.6.0
2024-10-24T11:58:11,024727+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-10-24T11:58:11,024782+00:00 pnp: PnP ACPI init
2024-10-24T11:58:11,024862+00:00 system 00:00: [mem 0x20000000-0x2fffffff] could not be reserved
2024-10-24T11:58:11,024874+00:00 pnp: PnP ACPI: found 1 devices
2024-10-24T11:58:11,030934+00:00 NET: Registered PF_INET protocol family
2024-10-24T11:58:11,030970+00:00 IP idents hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-10-24T11:58:11,031725+00:00 tcp_listen_portaddr_hash hash table entries: 2048 (order: 3, 32768 bytes, linear)
2024-10-24T11:58:11,031738+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-10-24T11:58:11,031743+00:00 TCP established hash table entries: 32768 (order: 6, 262144 bytes, linear)
2024-10-24T11:58:11,031860+00:00 TCP bind hash table entries: 32768 (order: 8, 1048576 bytes, linear)
2024-10-24T11:58:11,032168+00:00 TCP: Hash tables configured (established 32768 bind 32768)
2024-10-24T11:58:11,032205+00:00 MPTCP token hash table entries: 4096 (order: 4, 98304 bytes, linear)
2024-10-24T11:58:11,032221+00:00 UDP hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-10-24T11:58:11,032252+00:00 UDP-Lite hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-10-24T11:58:11,032307+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-10-24T11:58:11,032316+00:00 NET: Registered PF_XDP protocol family
2024-10-24T11:58:11,032364+00:00 PCI: CLS 0 bytes, default 64
2024-10-24T11:58:11,032501+00:00 Trying to unpack rootfs image as initramfs...
2024-10-24T11:58:11,045404+00:00 hw perfevents: enabled with armv8_pmuv3_0 PMU driver, 3 counters available
2024-10-24T11:58:11,045431+00:00 kvm [1]: HYP mode not available
2024-10-24T11:58:11,045660+00:00 Initialise system trusted keyrings
2024-10-24T11:58:11,045666+00:00 Key type blacklist registered
2024-10-24T11:58:11,045901+00:00 workingset: timestamp_bits=44 max_order=20 bucket_order=0
2024-10-24T11:58:11,046918+00:00 zbud: loaded
2024-10-24T11:58:11,047074+00:00 SGI XFS with ACLs, security attributes, quota, no debug enabled
2024-10-24T11:58:11,047586+00:00 integrity: Platform Keyring initialized
2024-10-24T11:58:11,054610+00:00 Key type asymmetric registered
2024-10-24T11:58:11,054613+00:00 Asymmetric key parser 'x509' registered
2024-10-24T11:58:11,054635+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 248)
2024-10-24T11:58:11,054696+00:00 io scheduler mq-deadline registered
2024-10-24T11:58:11,054697+00:00 io scheduler kyber registered
2024-10-24T11:58:11,054722+00:00 io scheduler bfq registered
2024-10-24T11:58:11,056667+00:00 pl061_gpio ARMH0061:00: PL061 GPIO chip registered
2024-10-24T11:58:11,056715+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2024-10-24T11:58:11,057947+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing disabled
2024-10-24T11:58:11,058450+00:00 ACPI: \_SB_.PCI0.GSI2: Enabled at IRQ 37
2024-10-24T11:58:11,058480+00:00 serial 0000:00:01.0: enabling device (0010 -> 0012)
2024-10-24T11:58:11,058787+00:00 printk: console [ttyS0] disabled
2024-10-24T11:58:11,059039+00:00 0000:00:01.0: ttyS0 at MMIO 0x80008000 (irq = 14, base_baud = 115200) is a 16550A
2024-10-24T11:58:11,059137+00:00 printk: console [ttyS0] enabled
2024-10-24T11:58:11,059905+00:00 ACPI: \_SB_.PCI0.GSI0: Enabled at IRQ 35
2024-10-24T11:58:11,059991+00:00 nvme nvme0: pci function 0000:00:04.0
2024-10-24T11:58:11,060668+00:00 rtc-efi rtc-efi.0: registered as rtc0
2024-10-24T11:58:11,060699+00:00 rtc-efi rtc-efi.0: setting system clock to 2024-10-24T11:58:11 UTC (1729771091)
2024-10-24T11:58:11,060765+00:00 pstore: Registered efi as persistent store backend
2024-10-24T11:58:11,060777+00:00 hid: raw HID events driver (C) Jiri Kosina
2024-10-24T11:58:11,070061+00:00 nvme nvme0: 2/0/0 default/read/poll queues
2024-10-24T11:58:11,070563+00:00 NET: Registered PF_INET6 protocol family
2024-10-24T11:58:11,079181+00:00  nvme0n1: p1 p128
2024-10-24T11:58:11,153976+00:00 Freeing initrd memory: 11908K
2024-10-24T11:58:11,160486+00:00 Segment Routing with IPv6
2024-10-24T11:58:11,160501+00:00 In-situ OAM (IOAM) with IPv6
2024-10-24T11:58:11,160536+00:00 NET: Registered PF_PACKET protocol family
2024-10-24T11:58:11,160840+00:00 registered taskstats version 1
2024-10-24T11:58:11,160850+00:00 Loading compiled-in X.509 certificates
2024-10-24T11:58:11,172882+00:00 Loaded X.509 cert 'Amazon.com: Amazon Linux Kernel Signing Key: 3c3163dcb84c1049cf8b75ca4bcf01c5583dbccb'
2024-10-24T11:58:11,173128+00:00 zswap: loaded using pool lzo/zbud
2024-10-24T11:58:11,173375+00:00 Key type .fscrypt registered
2024-10-24T11:58:11,173377+00:00 Key type fscrypt-provisioning registered
2024-10-24T11:58:11,173600+00:00 pstore: Using crash dump compression: deflate
2024-10-24T11:58:11,173986+00:00 ima: secureboot mode disabled
2024-10-24T11:58:11,173993+00:00 ima: No TPM chip found, activating TPM-bypass!
2024-10-24T11:58:11,174011+00:00 ima: Allocated hash algorithm: sha256
2024-10-24T11:58:11,174024+00:00 ima: No architecture policies found
2024-10-24T11:58:11,317198+00:00 clk: Disabling unused clocks
2024-10-24T11:58:11,318602+00:00 Freeing unused kernel memory: 4480K
2024-10-24T11:58:11,318628+00:00 Run /init as init process
2024-10-24T11:58:11,318630+00:00   with arguments:
2024-10-24T11:58:11,318631+00:00     /init
2024-10-24T11:58:11,318632+00:00   with environment:
2024-10-24T11:58:11,318633+00:00     HOME=/
2024-10-24T11:58:11,318635+00:00     TERM=linux
2024-10-24T11:58:11,318636+00:00     BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64
2024-10-24T11:58:11,346288+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-24T11:58:11,346294+00:00 systemd[1]: Detected virtualization amazon.
2024-10-24T11:58:11,346298+00:00 systemd[1]: Detected architecture arm64.
2024-10-24T11:58:11,346300+00:00 systemd[1]: Running in initrd.
2024-10-24T11:58:11,346402+00:00 systemd[1]: No hostname configured, using default hostname.
2024-10-24T11:58:11,346444+00:00 systemd[1]: Hostname set to <localhost>.
2024-10-24T11:58:11,346518+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-24T11:58:11,461532+00:00 systemd[1]: Queued start job for default target initrd.target.
2024-10-24T11:58:11,475473+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-24T11:58:11,475524+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-b5c7fae5\x2d1de8\x2d4038\x2d8408\x2d06c720e69aff.device - /dev/disk/by-uuid/b5c7fae5-1de8-4038-8408-06c720e69aff...
2024-10-24T11:58:11,475558+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2024-10-24T11:58:11,475570+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2024-10-24T11:58:11,475581+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-24T11:58:11,475600+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-24T11:58:11,475615+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-24T11:58:11,475627+00:00 systemd[1]: Reached target timers.target - Timer Units.
2024-10-24T11:58:11,475940+00:00 systemd[1]: Listening on systemd-journald-audit.socket - Journal Audit Socket.
2024-10-24T11:58:11,476071+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2024-10-24T11:58:11,476163+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Socket.
2024-10-24T11:58:11,476255+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-24T11:58:11,476318+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-24T11:58:11,476333+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2024-10-24T11:58:11,476386+00:00 systemd[1]: kmod-static-nodes.service - Create List of Static Device Nodes was skipped because of an unmet condition check (ConditionFileNotEmpty=/lib/modules/6.1.112-122.189.amzn2023.aarch64/modules.devname).
2024-10-24T11:58:11,477321+00:00 systemd[1]: Started rngd.service - Hardware RNG Entropy Gatherer Daemon.
2024-10-24T11:58:11,478660+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-24T11:58:11,478790+00:00 systemd[1]: systemd-modules-load.service - Load Kernel Modules was skipped because no trigger condition checks were met.
2024-10-24T11:58:11,479582+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-24T11:58:11,480330+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2024-10-24T11:58:11,481117+00:00 systemd[1]: Starting systemd-vconsole-setup.service - Setup Virtual Console...
2024-10-24T11:58:11,488950+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2024-10-24T11:58:11,505397+00:00 systemd[1]: Finished systemd-vconsole-setup.service - Setup Virtual Console.
2024-10-24T11:58:11,505539+00:00 systemd[1]: dracut-cmdline-ask.service - dracut ask for additional cmdline parameters was skipped because no trigger condition checks were met.
2024-10-24T11:58:11,506384+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2024-10-24T11:58:11,506449+00:00 audit: type=1130 audit(1729771091.939:2): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-vconsole-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T11:58:11,510289+00:00 systemd[1]: Finished systemd-sysctl.service - Apply Kernel Variables.
2024-10-24T11:58:11,510406+00:00 audit: type=1130 audit(1729771091.939:3): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-sysctl comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T11:58:11,519919+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-24T11:58:11,521060+00:00 audit: type=1130 audit(1729771091.949:4): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-journald comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T11:58:11,529122+00:00 audit: type=1130 audit(1729771091.959:5): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-tmpfiles-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T11:58:11,586974+00:00 audit: type=1130 audit(1729771092.019:6): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=dracut-cmdline comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T11:58:11,586982+00:00 audit: type=1334 audit(1729771092.019:7): prog-id=6 op=LOAD
2024-10-24T11:58:11,586984+00:00 audit: type=1334 audit(1729771092.019:8): prog-id=7 op=LOAD
2024-10-24T11:58:11,640605+00:00 audit: type=1130 audit(1729771092.069:9): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udevd comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T11:58:11,719642+00:00 audit: type=1130 audit(1729771092.149:10): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udev-trigger comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T11:58:11,868570+00:00 XFS (nvme0n1p1): Mounting V5 Filesystem
2024-10-24T11:58:12,097445+00:00 XFS (nvme0n1p1): Ending clean mount
2024-10-24T11:58:12,447335+00:00 systemd-journald[326]: Received SIGTERM from PID 1 (systemd).
2024-10-24T11:58:12,642962+00:00 SELinux:  Class user_namespace not defined in policy.
2024-10-24T11:58:12,642969+00:00 SELinux: the above unknown classes and permissions will be allowed
2024-10-24T11:58:12,645984+00:00 SELinux:  policy capability network_peer_controls=1
2024-10-24T11:58:12,645990+00:00 SELinux:  policy capability open_perms=1
2024-10-24T11:58:12,645991+00:00 SELinux:  policy capability extended_socket_class=1
2024-10-24T11:58:12,645992+00:00 SELinux:  policy capability always_check_network=0
2024-10-24T11:58:12,645993+00:00 SELinux:  policy capability cgroup_seclabel=1
2024-10-24T11:58:12,645994+00:00 SELinux:  policy capability nnp_nosuid_transition=1
2024-10-24T11:58:12,645995+00:00 SELinux:  policy capability genfs_seclabel_symlinks=1
2024-10-24T11:58:12,645996+00:00 SELinux:  policy capability ioctl_skip_cloexec=0
2024-10-24T11:58:12,751446+00:00 systemd[1]: Successfully loaded SELinux policy in 147.830ms.
2024-10-24T11:58:12,818111+00:00 systemd[1]: Relabelled /dev, /dev/shm, /run, /sys/fs/cgroup in 23.696ms.
2024-10-24T11:58:12,828786+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-24T11:58:12,828791+00:00 systemd[1]: Detected virtualization amazon.
2024-10-24T11:58:12,828806+00:00 systemd[1]: Detected architecture arm64.
2024-10-24T11:58:12,833133+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-24T11:58:12,833242+00:00 systemd[1]: Installed transient /etc/machine-id file.
2024-10-24T11:58:12,934676+00:00 systemd[1]: bpf-lsm: Failed to link program; assuming BPF LSM is not available
2024-10-24T11:58:12,970303+00:00 zram_generator::config[823]: zram0: system has too much memory (3836MB), limit is 800MB, ignoring.
2024-10-24T11:58:13,122144+00:00 systemd[1]: /usr/lib/systemd/system/update-motd.service:40: Invalid CPU quota '25', ignoring.
2024-10-24T11:58:13,360079+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2024-10-24T11:58:13,360246+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2024-10-24T11:58:13,360958+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2024-10-24T11:58:13,361540+00:00 systemd[1]: Created slice system-getty.slice - Slice /system/getty.
2024-10-24T11:58:13,362034+00:00 systemd[1]: Created slice system-modprobe.slice - Slice /system/modprobe.
2024-10-24T11:58:13,362469+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2024-10-24T11:58:13,362937+00:00 systemd[1]: Created slice system-sshd\x2dkeygen.slice - Slice /system/sshd-keygen.
2024-10-24T11:58:13,363385+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2024-10-24T11:58:13,363600+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-24T11:58:13,363734+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2024-10-24T11:58:13,364370+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2024-10-24T11:58:13,364405+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2024-10-24T11:58:13,364445+00:00 systemd[1]: Reached target cryptsetup.target - Local Encrypted Volumes.
2024-10-24T11:58:13,364494+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2024-10-24T11:58:13,364514+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2024-10-24T11:58:13,364532+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2024-10-24T11:58:13,364548+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2024-10-24T11:58:13,364594+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-24T11:58:13,364624+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-24T11:58:13,364685+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-24T11:58:13,364716+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2024-10-24T11:58:13,365430+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2024-10-24T11:58:13,367578+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2024-10-24T11:58:13,370109+00:00 systemd[1]: Listening on systemd-coredump.socket - Process Core Dump Socket.
2024-10-24T11:58:13,370333+00:00 systemd[1]: Listening on systemd-initctl.socket - initctl Compatibility Named Pipe.
2024-10-24T11:58:13,370741+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Service Netlink Socket.
2024-10-24T11:58:13,372644+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-24T11:58:13,373217+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-24T11:58:13,373689+00:00 systemd[1]: Listening on systemd-userdbd.socket - User Database Manager Socket.
2024-10-24T11:58:13,375840+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2024-10-24T11:58:13,378285+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2024-10-24T11:58:13,380632+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2024-10-24T11:58:13,384776+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2024-10-24T11:58:13,386300+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2024-10-24T11:58:13,386405+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS was skipped because of an unmet condition check (ConditionPathExists=/etc/krb5.keytab).
2024-10-24T11:58:13,388059+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2024-10-24T11:58:13,389603+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2024-10-24T11:58:13,391752+00:00 systemd[1]: Starting modprobe@configfs.service - Load Kernel Module configfs...
2024-10-24T11:58:13,395158+00:00 systemd[1]: Starting modprobe@dm_mod.service - Load Kernel Module dm_mod...
2024-10-24T11:58:13,396469+00:00 systemd[1]: Starting modprobe@drm.service - Load Kernel Module drm...
2024-10-24T11:58:13,397923+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2024-10-24T11:58:13,399342+00:00 systemd[1]: Starting modprobe@fuse.service - Load Kernel Module fuse...
2024-10-24T11:58:13,400690+00:00 systemd[1]: Starting modprobe@loop.service - Load Kernel Module loop...
2024-10-24T11:58:13,402047+00:00 systemd[1]: Starting nfs-convert.service - Preprocess NFS configuration convertion...
2024-10-24T11:58:13,403500+00:00 systemd[1]: Starting systemd-fsck-root.service - File System Check on Root Device...
2024-10-24T11:58:13,403586+00:00 systemd[1]: Stopped systemd-journald.service - Journal Service.
2024-10-24T11:58:13,407523+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-24T11:58:13,409989+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2024-10-24T11:58:13,414434+00:00 systemd[1]: Starting systemd-network-generator.service - Generate network units from Kernel command line...
2024-10-24T11:58:13,416277+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2024-10-24T11:58:13,418106+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2024-10-24T11:58:13,418220+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2024-10-24T11:58:13,418288+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2024-10-24T11:58:13,418360+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2024-10-24T11:58:13,418430+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2024-10-24T11:58:13,418672+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2024-10-24T11:58:13,419210+00:00 systemd[1]: nfs-convert.service: Deactivated successfully.
2024-10-24T11:58:13,419376+00:00 systemd[1]: Finished nfs-convert.service - Preprocess NFS configuration convertion.
2024-10-24T11:58:13,419735+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-10-24T11:58:13,419864+00:00 systemd[1]: Finished modprobe@configfs.service - Load Kernel Module configfs.
2024-10-24T11:58:13,421547+00:00 systemd[1]: Mounting sys-kernel-config.mount - Kernel Configuration File System...
2024-10-24T11:58:13,425074+00:00 systemd[1]: Mounted sys-kernel-config.mount - Kernel Configuration File System.
2024-10-24T11:58:13,428498+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-10-24T11:58:13,428661+00:00 systemd[1]: Finished modprobe@drm.service - Load Kernel Module drm.
2024-10-24T11:58:13,430713+00:00 systemd[1]: Finished systemd-network-generator.service - Generate network units from Kernel command line.
2024-10-24T11:58:13,438609+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2024-10-24T11:58:13,438646+00:00 device-mapper: uevent: version 1.0.3
2024-10-24T11:58:13,439364+00:00 device-mapper: ioctl: 4.47.0-ioctl (2022-07-28) initialised: dm-devel@redhat.com
2024-10-24T11:58:13,440543+00:00 systemd[1]: modprobe@dm_mod.service: Deactivated successfully.
2024-10-24T11:58:13,440695+00:00 systemd[1]: Finished modprobe@dm_mod.service - Load Kernel Module dm_mod.
2024-10-24T11:58:13,445690+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2024-10-24T11:58:13,447426+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-24T11:58:13,447727+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-10-24T11:58:13,447881+00:00 systemd[1]: Finished modprobe@efi_pstore.service - Load Kernel Module efi_pstore.
2024-10-24T11:58:13,453596+00:00 loop: module loaded
2024-10-24T11:58:13,454249+00:00 systemd[1]: modprobe@loop.service: Deactivated successfully.
2024-10-24T11:58:13,454394+00:00 systemd[1]: Finished modprobe@loop.service - Load Kernel Module loop.
2024-10-24T11:58:13,454595+00:00 systemd[1]: systemd-repart.service - Repartition Root Disk was skipped because no trigger condition checks were met.
2024-10-24T11:58:13,467867+00:00 fuse: init (API version 7.38)
2024-10-24T11:58:13,469533+00:00 systemd[1]: modprobe@fuse.service: Deactivated successfully.
2024-10-24T11:58:13,469694+00:00 systemd[1]: Finished modprobe@fuse.service - Load Kernel Module fuse.
2024-10-24T11:58:13,471615+00:00 systemd[1]: Mounting sys-fs-fuse-connections.mount - FUSE Control File System...
2024-10-24T11:58:13,476279+00:00 systemd[1]: Mounted sys-fs-fuse-connections.mount - FUSE Control File System.
2024-10-24T11:58:13,478629+00:00 systemd[1]: Finished systemd-fsck-root.service - File System Check on Root Device.
2024-10-24T11:58:13,480097+00:00 systemd[1]: Starting systemd-remount-fs.service - Remount Root and Kernel File Systems...
2024-10-24T11:58:13,482581+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-24T11:58:13,608640+00:00 systemd-journald[845]: Received client request to flush runtime journal.
2024-10-24T11:58:13,994712+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input0
2024-10-24T11:58:13,996851+00:00 ACPI: button: Power Button [PWRB]
2024-10-24T11:58:13,997249+00:00 input: Sleep Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0E:00/input/input1
2024-10-24T11:58:13,998074+00:00 ACPI: button: Sleep Button [SLPB]
2024-10-24T11:58:14,022041+00:00 ACPI: \_SB_.PCI0.GSI1: Enabled at IRQ 36
2024-10-24T11:58:14,022482+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) v2.13.0g
2024-10-24T11:58:14,023011+00:00 ena 0000:00:05.0: enabling device (0010 -> 0012)
2024-10-24T11:58:14,034678+00:00 ena 0000:00:05.0: ENA device version: 0.10
2024-10-24T11:58:14,035132+00:00 ena 0000:00:05.0: ENA controller version: 0.0.1 implementation version 1
2024-10-24T11:58:14,114675+00:00 ena 0000:00:05.0: LLQ is not supported Fallback to host mode policy.
2024-10-24T11:58:14,129868+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) found at mem 80004000, mac addr 0a:57:85:4b:1a:69
2024-10-24T11:58:14,194811+00:00 ena 0000:00:05.0 ens5: renamed from eth0
2024-10-24T11:58:14,506037+00:00 RPC: Registered named UNIX socket transport module.
2024-10-24T11:58:14,506544+00:00 RPC: Registered udp transport module.
2024-10-24T11:58:14,506918+00:00 RPC: Registered tcp transport module.
2024-10-24T11:58:14,507294+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2024-10-24T11:58:14,895209+00:00 ena 0000:00:05.0 ens5: Local page cache is disabled for less than 16 channels
2024-10-24T11:58:41,882432+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T11:58:42,919954+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eni26d037b45bb: link becomes ready
2024-10-24T11:58:42,925938+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T11:58:47,988395+00:00 pci 0000:00:06.0: [1d0f:ec20] type 00 class 0x020000
2024-10-24T11:58:47,988962+00:00 pci 0000:00:06.0: reg 0x10: [mem 0x00000000-0x00003fff]
2024-10-24T11:58:47,989666+00:00 pci 0000:00:06.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T11:58:47,990431+00:00 pci 0000:00:06.0: BAR 0: assigned [mem 0x8000c000-0x8000ffff]
2024-10-24T11:58:47,991129+00:00 ena 0000:00:06.0: enabling device (0000 -> 0002)
2024-10-24T11:58:48,000070+00:00 ena 0000:00:06.0: ENA device version: 0.10
2024-10-24T11:58:48,000517+00:00 ena 0000:00:06.0: ENA controller version: 0.0.1 implementation version 1
2024-10-24T11:58:48,075701+00:00 ena 0000:00:06.0: LLQ is not supported Fallback to host mode policy.
2024-10-24T11:58:48,083618+00:00 ena 0000:00:06.0: Elastic Network Adapter (ENA) found at mem 8000c000, mac addr 0a:64:31:6e:f2:b9
2024-10-24T11:58:48,130276+00:00 ena 0000:00:06.0 ens6: renamed from eth0
2024-10-24T11:58:48,520194+00:00 ena 0000:00:06.0 ens6: Local page cache is disabled for less than 16 channels
2024-10-24T11:58:48,521714+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): ens6: link becomes ready
2024-10-24T12:25:54,264301+00:00 Initializing XFRM netlink socket
2024-10-24T12:25:54,728393+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2024-10-24T12:25:55,785094+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2024-10-24T12:25:57,018271+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-10-24T12:25:58,549256+00:00 eth0: renamed from tmp139f0
2024-10-24T12:25:58,611031+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:25:58,611635+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc5a251d41f91d: link becomes ready
2024-10-24T12:25:58,667289+00:00 eth0: renamed from tmp5235e
2024-10-24T12:25:58,707831+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc0d16d604d44a: link becomes ready
2024-10-24T12:34:35,009817+00:00 eth0: renamed from tmp4fa14
2024-10-24T12:34:35,049450+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:34:35,050033+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc74e3dd3c58df: link becomes ready
2024-10-24T12:41:57,161411+00:00 eth0: renamed from tmp9da6f
2024-10-24T12:41:57,206323+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:41:57,206902+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcef762c12f1a9: link becomes ready
2024-10-24T12:48:19,838615+00:00 eth0: renamed from tmp41c45
2024-10-24T12:48:19,883966+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:48:19,884547+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc46532a37f6a1: link becomes ready
2024-10-24T12:48:20,003194+00:00 eth0: renamed from tmp45839
2024-10-24T12:48:20,043037+00:00 eth0: renamed from tmp99a4b
2024-10-24T12:48:20,104029+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc55001b939e14: link becomes ready
2024-10-24T12:48:20,104698+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc50f937d9fb13: link becomes ready
2024-10-24T12:54:17,808856+00:00 printk: dmesg (21528): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
