IP ADDRESS        LOCAL ENDPOINT INFO
172.31.206.14:0   (localhost)                                                                                        
172.31.248.30:0   (localhost)                                                                                        
10.25.0.6:0       (localhost)                                                                                        
10.25.0.236:0     id=3883  sec_id=1710523 flags=0x0000 ifindex=14  mac=7E:F4:8D:7D:DB:C1 nodemac=1A:21:61:16:69:45   
10.25.0.101:0     id=48    sec_id=1710523 flags=0x0000 ifindex=12  mac=26:55:B1:AE:C6:2F nodemac=96:0E:F0:54:71:5D   
10.25.0.41:0      id=3230  sec_id=1726732 flags=0x0000 ifindex=18  mac=72:08:41:79:BB:CF nodemac=5E:C5:42:92:43:BE   
10.25.0.21:0      id=2794  sec_id=1751814 flags=0x0000 ifindex=22  mac=C2:DC:40:52:CA:2B nodemac=BE:16:74:41:9A:FB   
10.25.0.213:0     id=964   sec_id=1705127 flags=0x0000 ifindex=20  mac=36:71:5C:90:F1:E4 nodemac=AA:AA:EE:F2:25:64   
10.25.0.47:0      id=3422  sec_id=1744850 flags=0x0000 ifindex=24  mac=56:BE:B9:0C:A1:64 nodemac=62:AF:47:92:87:AF   
10.25.0.215:0     id=3121  sec_id=4     flags=0x0000 ifindex=10  mac=1A:C6:46:D2:EC:38 nodemac=92:F5:B1:00:78:43     
