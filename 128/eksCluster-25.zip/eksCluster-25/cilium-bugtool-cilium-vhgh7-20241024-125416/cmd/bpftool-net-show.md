xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 552
ens6(5) clsact/ingress cil_from_netdev-ens6 id 564
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 545
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(7) clsact/egress cil_from_host-cilium_host id 533
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 583
lxc5a251d41f91d(12) clsact/ingress cil_from_container-lxc5a251d41f91d id 517
lxc0d16d604d44a(14) clsact/ingress cil_from_container-lxc0d16d604d44a id 532
lxcef762c12f1a9(18) clsact/ingress cil_from_container-lxcef762c12f1a9 id 641
lxc46532a37f6a1(20) clsact/ingress cil_from_container-lxc46532a37f6a1 id 3344
lxc55001b939e14(22) clsact/ingress cil_from_container-lxc55001b939e14 id 3354
lxc50f937d9fb13(24) clsact/ingress cil_from_container-lxc50f937d9fb13 id 3308

flow_dissector:

netfilter:

