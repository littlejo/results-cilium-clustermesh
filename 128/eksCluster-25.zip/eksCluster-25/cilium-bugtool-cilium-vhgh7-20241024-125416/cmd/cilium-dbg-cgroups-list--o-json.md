[
  {
    "containers": [
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod725a4821_30fa_4233_8dde_37163a210080.slice/cri-containerd-9a67a59a78c25f13ce62e113efad54132991831fa3644897b0da90db7635d7e6.scope"
      },
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod725a4821_30fa_4233_8dde_37163a210080.slice/cri-containerd-bb8f9227caca155d41fbe2c8a854295dc195fe751481d43a4feea4763c7e789a.scope"
      },
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod725a4821_30fa_4233_8dde_37163a210080.slice/cri-containerd-e445dc5a171bb98ec7f46913b9050fb1440c8c80db344f7be2dc164de023efe2.scope"
      }
    ],
    "ips": [
      "10.25.0.41"
    ],
    "name": "clustermesh-apiserver-8586c94666-6wqng",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7668,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd48bdf2f_da15_4f8f_b444_d8c31e3aac5f.slice/cri-containerd-d94c111b29e2908bc411d541e12e8fa944b97cc2b620c57bb771fd1ae3713329.scope"
      }
    ],
    "ips": [
      "10.25.0.101"
    ],
    "name": "coredns-cc6ccd49c-lvqmh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73484a98_a3e5_4d3d_94fe_49ebbcc60543.slice/cri-containerd-57391daad2aeeadb4e268b0390b3d583988812bf61ef0886eb4d97c530257f4f.scope"
      }
    ],
    "ips": [
      "10.25.0.213"
    ],
    "name": "client-974f6c69d-hsp2g",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d0024bb_aec1_456a_b152_166524f6fdef.slice/cri-containerd-62ad15a53d8e000b2ceda3f3138150d7eb73013917f48b84d711c2707eba2b1d.scope"
      }
    ],
    "ips": [
      "10.25.0.21"
    ],
    "name": "client2-57cf4468f-55qzf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12f64a53_8a77_4eee_af88_0a891a2d12f8.slice/cri-containerd-b3fbcd5457b2dc45629a6b37b928d9d29964857bd5ba48fbcc264aff44f21c30.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12f64a53_8a77_4eee_af88_0a891a2d12f8.slice/cri-containerd-4b066a83879e3550fc49026b96d3cb8d58aec5a85ca850ca27e4798fda13c033.scope"
      }
    ],
    "ips": [
      "10.25.0.47"
    ],
    "name": "echo-same-node-86d9cc975c-b9qnf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7752,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8bf5c4b_ae35_4486_a486_498728795cda.slice/cri-containerd-bd4e7131c5688ecc6336f8c3382a27c3cf20a0581ec13c033c0713e04221a4a3.scope"
      }
    ],
    "ips": [
      "10.25.0.236"
    ],
    "name": "coredns-cc6ccd49c-5znjw",
    "namespace": "kube-system"
  }
]

