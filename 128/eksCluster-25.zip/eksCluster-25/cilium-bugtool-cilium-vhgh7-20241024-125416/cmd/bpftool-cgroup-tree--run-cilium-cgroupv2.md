CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65d00203_f934_4463_a0d4_3c6086bebeb6.slice/cri-containerd-ffd4c4480f02d20da834b86611297bab4f637c991e8fc46c4d4c5ddb117123c8.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65d00203_f934_4463_a0d4_3c6086bebeb6.slice/cri-containerd-83b1090ec42d1330a74e5d8520569df5cf1282c707bc89610d798616c52f0cec.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8bf5c4b_ae35_4486_a486_498728795cda.slice/cri-containerd-bd4e7131c5688ecc6336f8c3382a27c3cf20a0581ec13c033c0713e04221a4a3.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8bf5c4b_ae35_4486_a486_498728795cda.slice/cri-containerd-5235e214420f6fc6f7731a109fa4920dc5c4bff03c96322705d2eb94869102ed.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd48bdf2f_da15_4f8f_b444_d8c31e3aac5f.slice/cri-containerd-d94c111b29e2908bc411d541e12e8fa944b97cc2b620c57bb771fd1ae3713329.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd48bdf2f_da15_4f8f_b444_d8c31e3aac5f.slice/cri-containerd-139f053aeeba977c3f31254d2331b86a9267aad78d4ea51777ae9880563897ad.scope
    578      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d8eb89c_2f72_463b_9b07_fb9b60b7da93.slice/cri-containerd-5e2eddc29b551a29165c604f64acfc26b9b01b5c4b6085c1a3c02a0883cc03d6.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d8eb89c_2f72_463b_9b07_fb9b60b7da93.slice/cri-containerd-8d6bc46955d9e47d3887e73c9c14c36a94c917f39d4c492a1ad97a677ac40108.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod617ac572_fa60_4a59_a09a_3a2b97b73675.slice/cri-containerd-84bbdd2b2af433f59e4be868d121eee6857cdbfc25025a64ed772c2295c005b4.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod617ac572_fa60_4a59_a09a_3a2b97b73675.slice/cri-containerd-269efe6a543b1ed689110014d330a91d1fe3400cd7831eb7ced0b16b8716a5dd.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73484a98_a3e5_4d3d_94fe_49ebbcc60543.slice/cri-containerd-57391daad2aeeadb4e268b0390b3d583988812bf61ef0886eb4d97c530257f4f.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73484a98_a3e5_4d3d_94fe_49ebbcc60543.slice/cri-containerd-41c45026801c0ebef935ede2b1060d4278a8f34fe8a6d458da27c9d4649b1f69.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod725a4821_30fa_4233_8dde_37163a210080.slice/cri-containerd-9da6ff87fb6cd8988a96c5708d143bb2c3de8f90a80eebab1ceda6f77c0cdf97.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod725a4821_30fa_4233_8dde_37163a210080.slice/cri-containerd-e445dc5a171bb98ec7f46913b9050fb1440c8c80db344f7be2dc164de023efe2.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod725a4821_30fa_4233_8dde_37163a210080.slice/cri-containerd-9a67a59a78c25f13ce62e113efad54132991831fa3644897b0da90db7635d7e6.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod725a4821_30fa_4233_8dde_37163a210080.slice/cri-containerd-bb8f9227caca155d41fbe2c8a854295dc195fe751481d43a4feea4763c7e789a.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d0024bb_aec1_456a_b152_166524f6fdef.slice/cri-containerd-458394f75e559a8954c3b14bda0925312b2133c540d4a4ea03d22349fcb0a47c.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d0024bb_aec1_456a_b152_166524f6fdef.slice/cri-containerd-62ad15a53d8e000b2ceda3f3138150d7eb73013917f48b84d711c2707eba2b1d.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf227d31_cf00_4a0f_a18e_ea5e938a9d19.slice/cri-containerd-9a7e1a235268cf1817104ef178e503f06d2d89386c5a1e02014a097a4403434d.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf227d31_cf00_4a0f_a18e_ea5e938a9d19.slice/cri-containerd-3dac579ad4d4ccf6786113fddbbc47bcc8599a38b59f09b7685f7d505360547d.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12f64a53_8a77_4eee_af88_0a891a2d12f8.slice/cri-containerd-99a4b6f17009e24a1588d46b1ab4f09652600f6f79290b1c0b644859429325c7.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12f64a53_8a77_4eee_af88_0a891a2d12f8.slice/cri-containerd-b3fbcd5457b2dc45629a6b37b928d9d29964857bd5ba48fbcc264aff44f21c30.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12f64a53_8a77_4eee_af88_0a891a2d12f8.slice/cri-containerd-4b066a83879e3550fc49026b96d3cb8d58aec5a85ca850ca27e4798fda13c033.scope
    732      cgroup_device   multi                                          
