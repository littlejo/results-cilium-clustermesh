 12:54:17 up 56 min,  0 users,  load average: 0.35, 0.54, 0.35
