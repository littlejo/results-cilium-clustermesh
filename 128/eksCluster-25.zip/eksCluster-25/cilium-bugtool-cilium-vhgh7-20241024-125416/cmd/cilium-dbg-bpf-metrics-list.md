REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     126826    10273058    677    bpf_overlay.c
Interface                   INGRESS     653812    246041413   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      124583    10090541    53     encap.h
Success                     EGRESS      150754    19968592    1308   bpf_lxc.c
Success                     EGRESS      50548     4091484     1694   bpf_host.c
Success                     EGRESS      8410      1391434     86     l3.h
Success                     INGRESS     174365    20035689    86     l3.h
Success                     INGRESS     259685    27651237    235    trace.h
Unsupported L3 protocol     EGRESS      71        5330        1492   bpf_lxc.c
