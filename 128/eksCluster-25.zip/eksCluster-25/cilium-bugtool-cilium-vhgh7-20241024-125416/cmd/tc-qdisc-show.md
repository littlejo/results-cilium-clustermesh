qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc5a251d41f91d root refcnt 2 
qdisc clsact ffff: dev lxc5a251d41f91d parent ffff:fff1 
qdisc noqueue 0: dev lxc0d16d604d44a root refcnt 2 
qdisc clsact ffff: dev lxc0d16d604d44a parent ffff:fff1 
qdisc noqueue 0: dev lxcef762c12f1a9 root refcnt 2 
qdisc clsact ffff: dev lxcef762c12f1a9 parent ffff:fff1 
qdisc noqueue 0: dev lxc46532a37f6a1 root refcnt 2 
qdisc clsact ffff: dev lxc46532a37f6a1 parent ffff:fff1 
qdisc noqueue 0: dev lxc55001b939e14 root refcnt 2 
qdisc clsact ffff: dev lxc55001b939e14 parent ffff:fff1 
qdisc noqueue 0: dev lxc50f937d9fb13 root refcnt 2 
qdisc clsact ffff: dev lxc50f937d9fb13 parent ffff:fff1 
