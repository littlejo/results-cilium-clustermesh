key: 30 00 00 00  value: 11 02 00 00
key: c4 03 00 00  value: 18 0d 00 00
key: ea 0a 00 00  value: 14 0d 00 00
key: 31 0c 00 00  value: 43 02 00 00
key: 9e 0c 00 00  value: 86 02 00 00
key: 5e 0d 00 00  value: f2 0c 00 00
key: 2b 0f 00 00  value: 39 02 00 00
Found 7 elements
