filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5a251d41f91d direct-action not_in_hw id 517 tag b0a06ec83d5dba17 jited 
