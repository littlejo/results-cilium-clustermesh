top - 12:54:17 up 56 min,  0 users,  load average: 0.35, 0.54, 0.35
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 12.9 us, 25.8 sy,  0.0 ni, 58.1 id,  0.0 wa,  0.0 hi,  0.0 si,  3.2 st
MiB Mem :   3836.2 total,    286.8 free,   1053.1 used,   2496.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2602.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 287660  78656 S   6.7   7.3   1:21.06 cilium-+
    414 root      20   0 1229744   8680   2864 S   0.0   0.2   0:04.72 cilium-+
   3087 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3106 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
   3107 root      20   0 1228744   3652   2976 S   0.0   0.1   0:00.00 gops
   3126 root      20   0 1240432  16320  11356 S   0.0   0.4   0:00.02 cilium-+
   3152 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3171 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
