1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:57:85:4b:1a:69 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.248.30/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2045sec preferred_lft 2045sec
    inet6 fe80::857:85ff:fe4b:1a69/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:64:31:6e:f2:b9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.206.14/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::864:31ff:fe6e:f2b9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:ee:25:f5:dc:8e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d0ee:25ff:fef5:dc8e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:f4:70:ce:77:a4 brd ff:ff:ff:ff:ff:ff
    inet 10.25.0.6/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::24f4:70ff:fece:77a4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 16:10:ba:a1:3b:7c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1410:baff:fea1:3b7c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:f5:b1:00:78:43 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::90f5:b1ff:fe00:7843/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5a251d41f91d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:0e:f0:54:71:5d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::940e:f0ff:fe54:715d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0d16d604d44a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:21:61:16:69:45 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1821:61ff:fe16:6945/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcef762c12f1a9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:c5:42:92:43:be brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5cc5:42ff:fe92:43be/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc46532a37f6a1@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:aa:ee:f2:25:64 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::a8aa:eeff:fef2:2564/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc55001b939e14@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:16:74:41:9a:fb brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::bc16:74ff:fe41:9afb/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc50f937d9fb13@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:af:47:92:87:af brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::60af:47ff:fe92:87af/64 scope link 
       valid_lft forever preferred_lft forever
