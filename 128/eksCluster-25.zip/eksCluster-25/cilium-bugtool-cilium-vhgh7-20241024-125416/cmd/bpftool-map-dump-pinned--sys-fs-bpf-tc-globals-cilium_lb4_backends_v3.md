key: 04 00 00 00  value: 0a 19 00 ec 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f e9 a1 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 19 00 65 00 35 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f f8 1e 10 94 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 19 00 ec 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 19 00 29 09 4b 00 00  00 00 00 00
key: 0a 00 00 00  value: 0a 19 00 2f 1f 90 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 19 00 65 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f ae e9 01 bb 00 00  00 00 00 00
Found 9 elements
