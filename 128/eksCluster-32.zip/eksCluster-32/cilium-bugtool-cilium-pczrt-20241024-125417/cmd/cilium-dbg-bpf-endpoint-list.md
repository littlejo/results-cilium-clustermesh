IP ADDRESS        LOCAL ENDPOINT INFO
10.32.0.186:0     id=400   sec_id=2170263 flags=0x0000 ifindex=21  mac=0A:D4:90:5A:6E:6F nodemac=AE:CD:26:E1:6D:FE   
10.32.0.144:0     id=1100  sec_id=2164791 flags=0x0000 ifindex=19  mac=8E:A5:8A:17:A5:BE nodemac=9A:E6:BF:10:65:ED   
172.31.176.93:0   (localhost)                                                                                        
10.32.0.192:0     id=3945  sec_id=4     flags=0x0000 ifindex=7   mac=D6:7F:44:A4:61:DD nodemac=F6:FE:BA:B0:81:C2     
10.32.0.45:0      id=490   sec_id=2178327 flags=0x0000 ifindex=9   mac=6A:12:93:28:E7:52 nodemac=8E:DB:7F:03:BA:FE   
10.32.0.226:0     id=3696  sec_id=2178327 flags=0x0000 ifindex=11  mac=0A:39:90:C3:12:16 nodemac=7A:E4:02:94:A5:C5   
10.32.0.23:0      id=565   sec_id=2186441 flags=0x0000 ifindex=17  mac=CE:70:3C:65:DA:12 nodemac=72:C0:9D:89:9C:81   
10.32.0.97:0      id=376   sec_id=2171396 flags=0x0000 ifindex=15  mac=72:57:EE:8A:F5:C9 nodemac=2A:74:3E:09:5B:58   
10.32.0.60:0      (localhost)                                                                                        
