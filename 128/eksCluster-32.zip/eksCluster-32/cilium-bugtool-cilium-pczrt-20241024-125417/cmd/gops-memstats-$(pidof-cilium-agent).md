alloc: 117.81MB (123530352 bytes)
total-alloc: 3.37GB (3623511352 bytes)
sys: 231.64MB (242894164 bytes)
lookups: 0
mallocs: 78809654
frees: 77537522
heap-alloc: 117.81MB (123530352 bytes)
heap-sys: 183.13MB (192028672 bytes)
heap-idle: 38.06MB (39911424 bytes)
heap-in-use: 145.07MB (152117248 bytes)
heap-released: 5.09MB (5332992 bytes)
heap-objects: 1272132
stack-in-use: 36.84MB (38633472 bytes)
stack-sys: 36.84MB (38633472 bytes)
stack-mspan-inuse: 2.44MB (2554400 bytes)
stack-mspan-sys: 2.91MB (3051840 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.11MB (1168609 bytes)
gc-sys: 5.52MB (5784744 bytes)
next-gc: when heap-alloc >= 151.83MB (159207144 bytes)
last-gc: 2024-10-24 12:54:19.166559944 +0000 UTC
gc-pause-total: 11.606453ms
gc-pause: 86122
gc-pause-end: 1729774459166559944
num-gc: 116
num-forced-gc: 0
gc-cpu-fraction: 0.00031970435377401564
enable-gc: true
debug-gc: false
