Node 0, zone      DMA    183     45      1     17      6      4      9      3      2      2    142 
Node 0, zone   Normal    706    409    115     89     42     24      9      3      4      3      3 
