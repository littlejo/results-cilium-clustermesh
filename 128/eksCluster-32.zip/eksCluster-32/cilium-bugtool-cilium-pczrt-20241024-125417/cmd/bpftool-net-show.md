xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 514
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 501
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 491
cilium_host(4) clsact/egress cil_from_host-cilium_host id 496
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 441
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 442
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 525
lxc5a5bae9edf98(9) clsact/ingress cil_from_container-lxc5a5bae9edf98 id 467
lxc9dca57d2b192(11) clsact/ingress cil_from_container-lxc9dca57d2b192 id 489
lxc4437f0341c66(15) clsact/ingress cil_from_container-lxc4437f0341c66 id 592
lxcad2b7fad4a76(17) clsact/ingress cil_from_container-lxcad2b7fad4a76 id 3279
lxc6cb0181e7372(19) clsact/ingress cil_from_container-lxc6cb0181e7372 id 3333
lxc96a1f3d7d06b(21) clsact/ingress cil_from_container-lxc96a1f3d7d06b id 3318

flow_dissector:

netfilter:

