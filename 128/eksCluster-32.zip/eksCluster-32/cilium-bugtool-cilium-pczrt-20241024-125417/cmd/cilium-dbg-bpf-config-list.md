KEY             VALUE
AgentLiveness   3439283226928
UTimeOffset     3378459082031250
