[
  {
    "containers": [
      {
        "cgroup-id": 6742,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50af4752_de38_49b2_906d_909d00f75cd0.slice/cri-containerd-f04961e685f9a19f831fc41c2c3fc9f904fd6e114a26b9c09d8eaf2a886a1f8f.scope"
      }
    ],
    "ips": [
      "10.32.0.226"
    ],
    "name": "coredns-cc6ccd49c-w2rjc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8890,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7270b65_b718_4657_811b_3d3cfeecd2cf.slice/cri-containerd-e8eb4401cf415030604a391a3555c231a5f0a75f75549f6dd68c127ccd5ad457.scope"
      }
    ],
    "ips": [
      "10.32.0.144"
    ],
    "name": "client2-57cf4468f-t54qh",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8134,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecc68316_bf10_4e61_af4b_1c686edacfcc.slice/cri-containerd-493aa11020903383f0020444943074694defc3f49a6e4e00b11b90e6ad0c1ac7.scope"
      },
      {
        "cgroup-id": 8218,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecc68316_bf10_4e61_af4b_1c686edacfcc.slice/cri-containerd-3abb47c13bd5caaadcecec5a5e4799ac528a6f6fd2c5e7bbab426c638c45b45b.scope"
      },
      {
        "cgroup-id": 8302,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecc68316_bf10_4e61_af4b_1c686edacfcc.slice/cri-containerd-a8bf5dcc19bc98d58c017322f02633290dd32fe812f57d8e4643fd461a03cbf9.scope"
      }
    ],
    "ips": [
      "10.32.0.97"
    ],
    "name": "clustermesh-apiserver-55cf64d44c-g6dmf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9058,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18c37a46_b7dd_44ef_b326_fb965b6a642e.slice/cri-containerd-19c995728bb58787be67fb5f60f3be30117b8a6a5a236a6cad862055489f845a.scope"
      },
      {
        "cgroup-id": 9142,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18c37a46_b7dd_44ef_b326_fb965b6a642e.slice/cri-containerd-098d1ded9e85919afc047b4ea28886ee185f6f17749f4bf45513e006ac1a2d4d.scope"
      }
    ],
    "ips": [
      "10.32.0.23"
    ],
    "name": "echo-same-node-86d9cc975c-7zg77",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 6658,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ffc0c5b_66e1_4234_8b98_69c54b149355.slice/cri-containerd-b616771673ee159b2caa5e28e980c5f171fd2a333c0788f5c962a7fcc85e02f7.scope"
      }
    ],
    "ips": [
      "10.32.0.45"
    ],
    "name": "coredns-cc6ccd49c-s7q8c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8974,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e71cb94_0764_4fe9_b540_48844931710e.slice/cri-containerd-05418dc6cd383326275b33d5f30b9321df7af6bc15daabc1c6915233a3865006.scope"
      }
    ],
    "ips": [
      "10.32.0.186"
    ],
    "name": "client-974f6c69d-gzvxn",
    "namespace": "cilium-test-1"
  }
]

