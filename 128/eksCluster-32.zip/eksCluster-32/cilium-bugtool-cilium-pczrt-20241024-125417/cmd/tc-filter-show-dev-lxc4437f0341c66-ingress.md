filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4437f0341c66 direct-action not_in_hw id 592 tag 9a399c41548696b9 jited 
