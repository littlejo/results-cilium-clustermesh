Total: 556
TCP:   3862 (estab 299, closed 3544, orphaned 0, timewait 3083)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  318       307       11       
INET	  328       313       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                   172.31.176.93%ens5:68         0.0.0.0:*    uid:192 ino:42279 sk:1 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:20419 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15068 sk:3 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:33279      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:20318 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:20418 sk:d45 cgroup:/ v6only:1 <->                                       
UNCONN 0      0                                [::1]:323           [::]:*    ino:15069 sk:d46 cgroup:unreachable:e8e v6only:1 <->                         
UNCONN 0      0      [fe80::482:f9ff:fe7e:9f3d]%ens5:546           [::]:*    uid:192 ino:15835 sk:d47 cgroup:unreachable:bd0 v6only:1 <->                 
