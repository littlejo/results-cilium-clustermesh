29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:57:33+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:57:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:57:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:57:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:57:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T11:57:33+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T11:57:34+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T11:57:34+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:57:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:57:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T11:57:34+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:57:34+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T11:57:38+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:57:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:57:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:57:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:57:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
55: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:57:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
58: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:57:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
59: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:57:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
62: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:57:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T11:57:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:57:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:57:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:57:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:57:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:58:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:58:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
441: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T11:58:18+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 112
442: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T11:58:18+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 113
443: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T11:58:18+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 114
444: sched_cls  name tail_handle_ipv4  tag e13ce8ff230285ff  gpl
	loaded_at 2024-10-24T11:58:18+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 115
466: sched_cls  name __send_drop_notify  tag 9b1ba62ffb04e539  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 143
467: sched_cls  name cil_from_container  tag 357dbf389e8264f9  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,68
	btf_id 144
468: sched_cls  name tail_ipv4_ct_egress  tag 7b50a5b27761c2ed  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,100,76
	btf_id 145
471: sched_cls  name tail_handle_ipv4  tag ba6a36e27fcff1be  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,101
	btf_id 146
472: sched_cls  name tail_ipv4_to_endpoint  tag 9cc9e984b1142970  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,97,31,101,32,29,30
	btf_id 149
473: sched_cls  name tail_handle_arp  tag f6a54317f9b1aded  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,101
	btf_id 150
475: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,101
	btf_id 151
478: sched_cls  name tail_handle_ipv4_cont  tag 3e178271b6ac7d59  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,97,74,75,31,68,66,69,101,32,29,30,73
	btf_id 153
486: sched_cls  name handle_policy  tag 4ed555960651a0f5  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,101,74,75,100,33,72,97,31,76,67,32,29,30
	btf_id 157
487: sched_cls  name tail_ipv4_ct_ingress  tag 9ebe5a52a2dbdae8  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,100,76
	btf_id 163
488: sched_cls  name tail_handle_ipv4_cont  tag a362fb618725de12  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,104,33,102,74,75,31,68,66,69,103,32,29,30,73
	btf_id 165
489: sched_cls  name cil_from_container  tag 18bd97e34ddba726  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,68
	btf_id 166
491: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 170
492: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,105
	btf_id 171
493: sched_cls  name __send_drop_notify  tag 65885af03d79bf23  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 172
495: sched_cls  name tail_handle_ipv4_from_host  tag ca1b49a0557f09dd  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,105
	btf_id 174
496: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,105
	btf_id 175
497: sched_cls  name tail_ipv4_to_endpoint  tag 69f037589870dcfe  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,104,33,74,75,72,102,31,103,32,29,30
	btf_id 167
499: sched_cls  name __send_drop_notify  tag 4d0ac189421cf9a2  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 178
501: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 181
502: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,107
	btf_id 182
503: sched_cls  name __send_drop_notify  tag 65885af03d79bf23  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 183
504: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 180
507: sched_cls  name tail_handle_ipv4_from_host  tag ca1b49a0557f09dd  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,107
	btf_id 186
508: sched_cls  name tail_handle_ipv4_from_host  tag ca1b49a0557f09dd  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 189
512: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 193
513: sched_cls  name __send_drop_notify  tag 65885af03d79bf23  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 194
514: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,110,67
	btf_id 195
515: sched_cls  name tail_ipv4_ct_egress  tag 7b50a5b27761c2ed  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 187
516: sched_cls  name handle_policy  tag f0a37a5a0140034a  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,103,74,75,104,33,72,102,31,76,67,32,29,30
	btf_id 196
517: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,112,74,75,111,76
	btf_id 198
518: sched_cls  name tail_handle_ipv4_cont  tag b1ad577623236329  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,111,33,90,74,75,31,68,66,69,112,32,29,30,73
	btf_id 200
519: sched_cls  name tail_handle_ipv4  tag 27fb41829eacbc09  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 199
520: sched_cls  name tail_ipv4_ct_ingress  tag 6bf10df567ae846f  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 202
521: sched_cls  name tail_handle_arp  tag 9f4aac152008da1f  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 203
522: sched_cls  name tail_ipv4_to_endpoint  tag f1d727c2819d71ff  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,111,33,74,75,72,90,31,112,32,29,30
	btf_id 201
523: sched_cls  name tail_handle_arp  tag 1197ad08313459de  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,112
	btf_id 204
524: sched_cls  name tail_ipv4_ct_ingress  tag 2c42bfb947f0d0be  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,112,74,75,111,76
	btf_id 205
525: sched_cls  name cil_from_container  tag d204878d1eef7b99  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,68
	btf_id 206
526: sched_cls  name tail_handle_ipv4  tag 9d29e4c72a3139dd  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,112
	btf_id 207
527: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,112
	btf_id 208
528: sched_cls  name __send_drop_notify  tag 3976b6c420dd9244  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 209
530: sched_cls  name handle_policy  tag c75df1ce84e91e0a  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,112,74,75,111,33,72,90,31,76,67,32,29,30
	btf_id 211
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:58:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:58:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:58:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:58:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:58:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: sched_cls  name tail_handle_ipv4  tag 64981cb8d3b43204  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,129
	btf_id 227
587: sched_cls  name handle_policy  tag 52427cc38fd04f8d  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,129,74,75,128,33,72,127,31,76,67,32,29,30
	btf_id 228
588: sched_cls  name tail_handle_ipv4_cont  tag d60a767321f7eecf  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,128,33,127,74,75,31,68,66,69,129,32,29,30,73
	btf_id 229
589: sched_cls  name tail_ipv4_ct_egress  tag 03f88720aa316976  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 230
590: sched_cls  name tail_handle_arp  tag 441748e78db0b528  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,129
	btf_id 231
591: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,129
	btf_id 232
592: sched_cls  name cil_from_container  tag 9a399c41548696b9  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,68
	btf_id 233
593: sched_cls  name tail_ipv4_to_endpoint  tag e31ec9423c597183  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,128,33,74,75,72,127,31,129,32,29,30
	btf_id 234
594: sched_cls  name __send_drop_notify  tag d28d797212902b7b  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 235
596: sched_cls  name tail_ipv4_ct_ingress  tag 0767fdebb2e56e9f  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 237
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
662: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
665: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
666: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
669: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
682: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
685: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3260: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,621
	btf_id 3083
3262: sched_cls  name tail_ipv4_ct_egress  tag 282e09a858bc7134  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,621,74,75,622,76
	btf_id 3084
3263: sched_cls  name tail_handle_ipv4_cont  tag 9ac5604d7b7166d5  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,622,33,137,74,75,31,68,66,69,621,32,29,30,73
	btf_id 3088
3264: sched_cls  name __send_drop_notify  tag d080f29eaf0c8685  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3089
3268: sched_cls  name handle_policy  tag 9e5a97b1ac3ba52c  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,621,74,75,622,33,72,137,31,76,67,32,29,30
	btf_id 3090
3272: sched_cls  name tail_ipv4_to_endpoint  tag a92589b480831a1c  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,622,33,74,75,72,137,31,621,32,29,30
	btf_id 3096
3276: sched_cls  name tail_ipv4_ct_ingress  tag 5658a3e0fd2d9164  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,621,74,75,622,76
	btf_id 3098
3278: sched_cls  name tail_handle_ipv4  tag 51f61e66a598bcc3  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,621
	btf_id 3102
3279: sched_cls  name cil_from_container  tag 170c7739712b097f  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 621,68
	btf_id 3104
3280: sched_cls  name tail_handle_arp  tag bfb8ee6823807884  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,621
	btf_id 3105
3315: sched_cls  name tail_handle_ipv4  tag cb2f9636558985e9  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,632
	btf_id 3143
3316: sched_cls  name tail_ipv4_ct_egress  tag 94aedbebcd9e9d0c  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,634,74,75,633,76
	btf_id 3145
3317: sched_cls  name tail_ipv4_to_endpoint  tag f2b205f4787dba29  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,633,33,74,75,72,140,31,634,32,29,30
	btf_id 3147
3318: sched_cls  name cil_from_container  tag 4455175de5fd2b30  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 632,68
	btf_id 3146
3319: sched_cls  name __send_drop_notify  tag d33b3d4eb65fa9bf  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3148
3321: sched_cls  name tail_ipv4_ct_ingress  tag 5da08785f55406c8  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,632,74,75,631,76
	btf_id 3150
3322: sched_cls  name tail_ipv4_ct_egress  tag c31dbee940634d57  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,632,74,75,631,76
	btf_id 3152
3323: sched_cls  name tail_ipv4_ct_ingress  tag 999798a91278b011  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,634,74,75,633,76
	btf_id 3151
3324: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,632
	btf_id 3153
3325: sched_cls  name tail_ipv4_to_endpoint  tag e163a1c4eefe13fa  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,631,33,74,75,72,143,31,632,32,29,30
	btf_id 3155
3326: sched_cls  name tail_handle_arp  tag 8ac514c554f134df  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,632
	btf_id 3156
3327: sched_cls  name tail_handle_ipv4  tag 86c97a0f065482f1  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,634
	btf_id 3154
3328: sched_cls  name tail_handle_ipv4_cont  tag 9f76c09afeba0074  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,631,33,143,74,75,31,68,66,69,632,32,29,30,73
	btf_id 3157
3329: sched_cls  name handle_policy  tag 7fa8e7008f0aba4f  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,632,74,75,631,33,72,143,31,76,67,32,29,30
	btf_id 3159
3331: sched_cls  name handle_policy  tag 0e9438fc8ff543c6  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,634,74,75,633,33,72,140,31,76,67,32,29,30
	btf_id 3158
3332: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,634
	btf_id 3161
3333: sched_cls  name cil_from_container  tag 04027454a9a28c3a  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,68
	btf_id 3162
3334: sched_cls  name tail_handle_arp  tag 756033e25e505434  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,634
	btf_id 3163
3335: sched_cls  name __send_drop_notify  tag 737b832298fc942c  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3164
3336: sched_cls  name tail_handle_ipv4_cont  tag 1ad67b98a0faaa51  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,633,33,140,74,75,31,68,66,69,634,32,29,30,73
	btf_id 3165
