1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:82:f9:7e:9f:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.176.93/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2002sec preferred_lft 2002sec
    inet6 fe80::482:f9ff:fe7e:9f3d/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:d3:b5:0c:ea:c0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b0d3:b5ff:fe0c:eac0/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:3f:09:90:27:11 brd ff:ff:ff:ff:ff:ff
    inet 10.32.0.60/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e03f:9ff:fe90:2711/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e2:8c:e7:52:f1:05 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e08c:e7ff:fe52:f105/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:fe:ba:b0:81:c2 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f4fe:baff:feb0:81c2/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc5a5bae9edf98@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:db:7f:03:ba:fe brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8cdb:7fff:fe03:bafe/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc9dca57d2b192@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:e4:02:94:a5:c5 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::78e4:2ff:fe94:a5c5/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc4437f0341c66@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:74:3e:09:5b:58 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2874:3eff:fe09:5b58/64 scope link 
       valid_lft forever preferred_lft forever
17: lxcad2b7fad4a76@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:c0:9d:89:9c:81 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::70c0:9dff:fe89:9c81/64 scope link 
       valid_lft forever preferred_lft forever
19: lxc6cb0181e7372@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:e6:bf:10:65:ed brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::98e6:bfff:fe10:65ed/64 scope link 
       valid_lft forever preferred_lft forever
21: lxc96a1f3d7d06b@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:cd:26:e1:6d:fe brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::accd:26ff:fee1:6dfe/64 scope link 
       valid_lft forever preferred_lft forever
