Endpoint ID: 376
Path: /sys/fs/bpf/tc/globals/cilium_policy_00376

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6047150   61469     0        
Allow    Ingress     1          ANY          NONE         disabled    6236027   64551     0        
Allow    Egress      0          ANY          NONE         disabled    7681693   75012     0        


Endpoint ID: 400
Path: /sys/fs/bpf/tc/globals/cilium_policy_00400

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 490
Path: /sys/fs/bpf/tc/globals/cilium_policy_00490

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3716     37        0        
Allow    Ingress     1          ANY          NONE         disabled    325703   3747      0        
Allow    Egress      0          ANY          NONE         disabled    37490    418       0        


Endpoint ID: 565
Path: /sys/fs/bpf/tc/globals/cilium_policy_00565

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379337   4432      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1100
Path: /sys/fs/bpf/tc/globals/cilium_policy_01100

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1630
Path: /sys/fs/bpf/tc/globals/cilium_policy_01630

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3696
Path: /sys/fs/bpf/tc/globals/cilium_policy_03696

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2180     23        0        
Allow    Ingress     1          ANY          NONE         disabled    325980   3741      0        
Allow    Egress      0          ANY          NONE         disabled    38513    428       0        


Endpoint ID: 3945
Path: /sys/fs/bpf/tc/globals/cilium_policy_03945

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6219702   76845     0        
Allow    Ingress     1          ANY          NONE         disabled    87082     1036      0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


