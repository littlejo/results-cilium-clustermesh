 12:54:18 up 56 min,  0 users,  load average: 0.43, 0.43, 0.19
