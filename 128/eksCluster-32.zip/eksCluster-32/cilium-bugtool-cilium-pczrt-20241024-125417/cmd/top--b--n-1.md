top - 12:54:18 up 56 min,  0 users,  load average: 0.43, 0.43, 0.19
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 48.3 us, 37.9 sy,  0.0 ni, 10.3 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    669.7 free,   1055.1 used,   2111.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2600.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539388 310832  79612 S  46.7   7.9   1:24.96 cilium-+
   3170 root      20   0 1240432  16308  10896 S  13.3   0.4   0:00.03 cilium-+
    395 root      20   0 1229744   9048   2924 S   0.0   0.2   0:04.19 cilium-+
   3210 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3230 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3256 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3258 root      20   0 1616264   8768   6264 S   0.0   0.2   0:00.00 runc:[2+
