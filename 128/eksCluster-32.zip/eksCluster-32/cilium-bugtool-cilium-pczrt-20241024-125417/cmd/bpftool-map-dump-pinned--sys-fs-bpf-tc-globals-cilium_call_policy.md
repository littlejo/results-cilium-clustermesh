key: 78 01 00 00  value: 4b 02 00 00
key: 90 01 00 00  value: 01 0d 00 00
key: ea 01 00 00  value: e6 01 00 00
key: 35 02 00 00  value: c4 0c 00 00
key: 4c 04 00 00  value: 03 0d 00 00
key: 70 0e 00 00  value: 04 02 00 00
key: 69 0f 00 00  value: 12 02 00 00
Found 7 elements
