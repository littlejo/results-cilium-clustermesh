CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebf7efd6_2f58_4ae7_aa09_e3769d28166b.slice/cri-containerd-63563ec11d829e6fee3219cdcd79485ba1c07d7e4778341145511718c6b52259.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebf7efd6_2f58_4ae7_aa09_e3769d28166b.slice/cri-containerd-577d19dd0eeda59b3d24ead7a0979f5cf0caebc929da2f99e13fc94522acf11f.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0aa7bcbd_c8b2_43ae_8f4e_50b08dcc46a1.slice/cri-containerd-26cea8e5502ebdff7ade57699b1d703730053351774105bc393239cd2261ae75.scope
    58       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0aa7bcbd_c8b2_43ae_8f4e_50b08dcc46a1.slice/cri-containerd-1165bdfa1ebd2209fbcbcae0faef848d24aaed2f0867bbf77942f94617f8e11b.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50af4752_de38_49b2_906d_909d00f75cd0.slice/cri-containerd-f4e6d3819245b23adfb0e852adb4bed38f643248649231c23395ec1f3b73f908.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50af4752_de38_49b2_906d_909d00f75cd0.slice/cri-containerd-f04961e685f9a19f831fc41c2c3fc9f904fd6e114a26b9c09d8eaf2a886a1f8f.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ffc0c5b_66e1_4234_8b98_69c54b149355.slice/cri-containerd-b616771673ee159b2caa5e28e980c5f171fd2a333c0788f5c962a7fcc85e02f7.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ffc0c5b_66e1_4234_8b98_69c54b149355.slice/cri-containerd-d6f4c770cbdad3ce3f0f8e07ab6324ac9c94663dd441ac345311ecbeab556d02.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7f8df5c7_b3e9_4ee8_b13d_5703dec2de2f.slice/cri-containerd-cfcaa8f59c5432f11e3df6a44753fde2ff8d87b5f7bb8864c5b6753579e40cc4.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7f8df5c7_b3e9_4ee8_b13d_5703dec2de2f.slice/cri-containerd-c765ecab52c42709341b7b8add96d27b04eb32b6bfe4a417338c3fcd55611304.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecc68316_bf10_4e61_af4b_1c686edacfcc.slice/cri-containerd-3abb47c13bd5caaadcecec5a5e4799ac528a6f6fd2c5e7bbab426c638c45b45b.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecc68316_bf10_4e61_af4b_1c686edacfcc.slice/cri-containerd-a8bf5dcc19bc98d58c017322f02633290dd32fe812f57d8e4643fd461a03cbf9.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecc68316_bf10_4e61_af4b_1c686edacfcc.slice/cri-containerd-493aa11020903383f0020444943074694defc3f49a6e4e00b11b90e6ad0c1ac7.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecc68316_bf10_4e61_af4b_1c686edacfcc.slice/cri-containerd-202ccda7ba8dd973ea45725d2489a28821c406d43f54b5bc0d2ba48c4c0c92e6.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4b63993_b791_4ae4_b060_85f856aecd31.slice/cri-containerd-62793be0656ba8d3917e13e1ce0af0156561c4158661cc669c6a2da0ef0c9fb3.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4b63993_b791_4ae4_b060_85f856aecd31.slice/cri-containerd-91162274bad27bc6e9cfc8e7ae1577bf4c6e118bdd940ddef56b14ff31da020d.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7270b65_b718_4657_811b_3d3cfeecd2cf.slice/cri-containerd-40da6ccc87fa4e0d6934daa81d2e035cbaf216887e22342404b911a2961c55d4.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7270b65_b718_4657_811b_3d3cfeecd2cf.slice/cri-containerd-e8eb4401cf415030604a391a3555c231a5f0a75f75549f6dd68c127ccd5ad457.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18c37a46_b7dd_44ef_b326_fb965b6a642e.slice/cri-containerd-19c995728bb58787be67fb5f60f3be30117b8a6a5a236a6cad862055489f845a.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18c37a46_b7dd_44ef_b326_fb965b6a642e.slice/cri-containerd-b32ed73b4fd63e79c8abb7b76d48724c41bda608a897549257cc1212ddc55781.scope
    665      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18c37a46_b7dd_44ef_b326_fb965b6a642e.slice/cri-containerd-098d1ded9e85919afc047b4ea28886ee185f6f17749f4bf45513e006ac1a2d4d.scope
    685      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e71cb94_0764_4fe9_b540_48844931710e.slice/cri-containerd-05418dc6cd383326275b33d5f30b9321df7af6bc15daabc1c6915233a3865006.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e71cb94_0764_4fe9_b540_48844931710e.slice/cri-containerd-3d043f8a89faa0d5d558057f7f8ac75d905506002e98e128e2ce54a5882c9b90.scope
    669      cgroup_device   multi                                          
