markdown output at /tmp/cilium-bugtool-20241024-125418.62+0000-UTC-105469135/cmd/cilium-debuginfo-20241024-125449.544+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125418.62+0000-UTC-105469135/cmd/cilium-debuginfo-20241024-125449.544+0000-UTC.json
