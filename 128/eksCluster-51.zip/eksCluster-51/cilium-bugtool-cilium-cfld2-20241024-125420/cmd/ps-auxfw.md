USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3274  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3267  0.0  0.4 1240432 16560 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3305  0.0  0.0   6408  1632 ?        R    12:54   0:00  \_ ps auxfw
root        3249  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.2  7.4 1538804 292384 ?      Ssl  12:28   1:06 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.2  0.2 1229744 9896 ?        Sl   12:28   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
