CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b40fd89_3012_47bc_8b64_92a601c63b8a.slice/cri-containerd-744f35c5b68261b7670198eccb7e8733b77a3426c78abe6514eb83eb881064f5.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b40fd89_3012_47bc_8b64_92a601c63b8a.slice/cri-containerd-89e51c82d46c3313be41f87d3cd3a7ea641136ee86df7dc2b628f2cb10b71e88.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94eba559_692f_4e50_b360_273ca7454eb9.slice/cri-containerd-692df9b62324929a29ecb57e0c305e40df3ce2ede61cf298e90463a04cf290c3.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94eba559_692f_4e50_b360_273ca7454eb9.slice/cri-containerd-6259e0d28ddb2633a8f47ea3fd4a4116b12bfc3d72d13fd7e7fcc22b30df9ea7.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod281903a9_376e_49b6_9fb8_1ab4a6e3f773.slice/cri-containerd-2b61e9e2c4a19a1281015b36d8a83d7a49278015a836d98f5cea53b41458ed50.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod281903a9_376e_49b6_9fb8_1ab4a6e3f773.slice/cri-containerd-6fb31bd4d5340b9dafc359cbbc92ff7e2ece21b6bc33a1526ddc42f053892e3a.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3885b5a1_be1d_49cb_a047_6a1dd395ea06.slice/cri-containerd-7d1f357f1b790bd916a3041722ab3d00449cb5109f6530d30addc18f5ddc7a53.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3885b5a1_be1d_49cb_a047_6a1dd395ea06.slice/cri-containerd-c36013e502a26d9d2f55acd0d75ba9b054390381436eda23697b7c1ff9107f9e.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd27b2b9_cbdb_4720_a945_e546e9678558.slice/cri-containerd-eea8c9b6252c56d806d1a0e6bc65b28bd1987d5c5af4cfd702974e91b676d40e.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd27b2b9_cbdb_4720_a945_e546e9678558.slice/cri-containerd-8a52ce8643a00d7f5644f9117d4cce774af6d3d9783e3c1ff23c1a80829068e7.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf10d2e10_2818_4ca9_b6f9_60b453637a2c.slice/cri-containerd-f46bb7e17afd524d7371713042156298682ef3e4eb37740159d6f41ca621bc70.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf10d2e10_2818_4ca9_b6f9_60b453637a2c.slice/cri-containerd-4afc705f3680521f03aeafbb8e3fe13012760b0157331db4619b5a0ee735e7bd.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec770c76_5f25_43b6_97c5_1ba0f89fa48f.slice/cri-containerd-5caf7d64403547246d8bb6c4050e1d648b9b29467ffef3170a6b8a37c6f4436f.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec770c76_5f25_43b6_97c5_1ba0f89fa48f.slice/cri-containerd-8c5d2e3c92c58cd99b30952b0c30c34b0aa0eb1bee8c95716f6119396ffa75dc.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec770c76_5f25_43b6_97c5_1ba0f89fa48f.slice/cri-containerd-3cae62878d738e5026e4cdae5bce2bbe58db440e7521e906b36bddb7faba576c.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3622241_26c5_4566_a5b5_7af27ceebe98.slice/cri-containerd-5c09c6f745da30a7aa2ea6c97a6b125db2339dd439d51c3bf4a8bf66d93a1aaf.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3622241_26c5_4566_a5b5_7af27ceebe98.slice/cri-containerd-ed587fff35dd3b03e5257d6c46c530820a0d573c36b453ebf2e03bf6b10e2864.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7b51963_4f00_4089_91d3_8fc3d1211db2.slice/cri-containerd-3bba73535ce5eee96b7ac1247aaaae581d74da7bd18509344ebfafd35b4ad6c3.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7b51963_4f00_4089_91d3_8fc3d1211db2.slice/cri-containerd-ee03d85bd848d686beef8a41aac9a01d11d8f97ce10e0ef347d1178feb670fa9.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7b51963_4f00_4089_91d3_8fc3d1211db2.slice/cri-containerd-c4c1a5b834006018925b331489860c31b073f76ddb25f5e23bddc4aefab374d9.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7b51963_4f00_4089_91d3_8fc3d1211db2.slice/cri-containerd-daf63997588ca0bc00e3ad683867c7c304e44041c0c806a3d3fc3f669dc6e8ef.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55935e99_1da8_4721_9d8d_9b1da663d26d.slice/cri-containerd-9b7c10e2ada3239bebc24600e46c26937bc33ec9493c66f1e806e760e421bf85.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55935e99_1da8_4721_9d8d_9b1da663d26d.slice/cri-containerd-f09998a5e1b1d8ca507fc01797fa86eb14b038ffc6288cf566bea70d168347fb.scope
    734      cgroup_device   multi                                          
