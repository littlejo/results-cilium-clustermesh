alloc: 72.71MB (76243832 bytes)
total-alloc: 3.11GB (3335376080 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75418538
frees: 74904215
heap-alloc: 72.71MB (76243832 bytes)
heap-sys: 177.41MB (186032128 bytes)
heap-idle: 53.11MB (55689216 bytes)
heap-in-use: 124.30MB (130342912 bytes)
heap-released: 5.83MB (6111232 bytes)
heap-objects: 514323
stack-in-use: 34.56MB (36241408 bytes)
stack-sys: 34.56MB (36241408 bytes)
stack-mspan-inuse: 2.11MB (2211520 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 991.13KB (1014913 bytes)
gc-sys: 5.50MB (5768288 bytes)
next-gc: when heap-alloc >= 157.91MB (165582392 bytes)
last-gc: 2024-10-24 12:54:22.14338076 +0000 UTC
gc-pause-total: 16.614754ms
gc-pause: 174941
gc-pause-end: 1729774462143380760
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0006201609937419199
enable-gc: true
debug-gc: false
