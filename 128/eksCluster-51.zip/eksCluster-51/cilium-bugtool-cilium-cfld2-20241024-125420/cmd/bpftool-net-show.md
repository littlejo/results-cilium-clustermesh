xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 553
ens6(5) clsact/ingress cil_from_netdev-ens6 id 568
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 552
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 543
cilium_host(7) clsact/egress cil_from_host-cilium_host id 539
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 586
lxcca86f4d226d7(12) clsact/ingress cil_from_container-lxcca86f4d226d7 id 526
lxc7ceb21d0baa5(14) clsact/ingress cil_from_container-lxc7ceb21d0baa5 id 562
lxc2100f0d50a70(18) clsact/ingress cil_from_container-lxc2100f0d50a70 id 650
lxc9c80de8c57a7(20) clsact/ingress cil_from_container-lxc9c80de8c57a7 id 3382
lxccc62f2bc5f01(22) clsact/ingress cil_from_container-lxccc62f2bc5f01 id 3375
lxc9831a778b69c(24) clsact/ingress cil_from_container-lxc9831a778b69c id 3325

flow_dissector:

netfilter:

