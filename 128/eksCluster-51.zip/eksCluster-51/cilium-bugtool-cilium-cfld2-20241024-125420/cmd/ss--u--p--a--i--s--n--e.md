Total: 567
TCP:   3674 (estab 290, closed 3365, orphaned 0, timewait 2913)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  309       299       10       
INET	  319       305       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.228.238%ens5:68         0.0.0.0:*    uid:192 ino:101730 sk:c8d cgroup:unreachable:bd0 <->                           
UNCONN 0      0                            127.0.0.1:39037      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=39)) ino:31278 sk:c8e fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31370 sk:c8f cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15611 sk:c90 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31369 sk:c91 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15612 sk:c92 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::826:86ff:fede:9b8b]%ens5:546           [::]:*    uid:192 ino:15849 sk:c93 cgroup:unreachable:bd0 v6only:1 <->                   
