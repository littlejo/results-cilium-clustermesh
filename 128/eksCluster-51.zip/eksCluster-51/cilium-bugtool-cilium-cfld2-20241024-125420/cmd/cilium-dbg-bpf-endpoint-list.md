IP ADDRESS         LOCAL ENDPOINT INFO
172.31.228.238:0   (localhost)                                                                                        
10.51.0.110:0      id=954   sec_id=3415806 flags=0x0000 ifindex=14  mac=36:82:01:EF:34:95 nodemac=82:30:16:28:D8:C8   
10.51.0.150:0      id=449   sec_id=3417861 flags=0x0000 ifindex=22  mac=F2:29:BF:24:5C:08 nodemac=B2:85:97:F1:3F:00   
10.51.0.227:0      id=2003  sec_id=4     flags=0x0000 ifindex=10  mac=36:AC:CC:18:66:35 nodemac=C2:6D:53:ED:61:F3     
10.51.0.117:0      id=1592  sec_id=3415806 flags=0x0000 ifindex=12  mac=5E:F1:DF:73:19:60 nodemac=72:96:C4:91:BD:3E   
10.51.0.143:0      (localhost)                                                                                        
10.51.0.2:0        id=372   sec_id=3409958 flags=0x0000 ifindex=20  mac=CA:D8:65:DD:C0:EA nodemac=8E:36:6B:0B:C8:CB   
10.51.0.57:0       id=3933  sec_id=3419603 flags=0x0000 ifindex=18  mac=3A:B6:87:CF:C0:06 nodemac=76:F2:F8:3C:6A:14   
172.31.248.206:0   (localhost)                                                                                        
10.51.0.55:0       id=3229  sec_id=3425947 flags=0x0000 ifindex=24  mac=8A:3B:ED:E1:8C:08 nodemac=62:79:72:DB:EB:73   
