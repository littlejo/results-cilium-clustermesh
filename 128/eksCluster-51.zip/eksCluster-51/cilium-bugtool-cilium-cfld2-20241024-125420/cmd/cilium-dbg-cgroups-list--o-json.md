[
  {
    "containers": [
      {
        "cgroup-id": 9982,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec770c76_5f25_43b6_97c5_1ba0f89fa48f.slice/cri-containerd-3cae62878d738e5026e4cdae5bce2bbe58db440e7521e906b36bddb7faba576c.scope"
      },
      {
        "cgroup-id": 10066,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec770c76_5f25_43b6_97c5_1ba0f89fa48f.slice/cri-containerd-5caf7d64403547246d8bb6c4050e1d648b9b29467ffef3170a6b8a37c6f4436f.scope"
      }
    ],
    "ips": [
      "10.51.0.55"
    ],
    "name": "echo-same-node-86d9cc975c-s7pgt",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7582,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94eba559_692f_4e50_b360_273ca7454eb9.slice/cri-containerd-6259e0d28ddb2633a8f47ea3fd4a4116b12bfc3d72d13fd7e7fcc22b30df9ea7.scope"
      }
    ],
    "ips": [
      "10.51.0.117"
    ],
    "name": "coredns-cc6ccd49c-cn7s7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9814,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf10d2e10_2818_4ca9_b6f9_60b453637a2c.slice/cri-containerd-f46bb7e17afd524d7371713042156298682ef3e4eb37740159d6f41ca621bc70.scope"
      }
    ],
    "ips": [
      "10.51.0.2"
    ],
    "name": "client2-57cf4468f-kpqcn",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9898,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55935e99_1da8_4721_9d8d_9b1da663d26d.slice/cri-containerd-f09998a5e1b1d8ca507fc01797fa86eb14b038ffc6288cf566bea70d168347fb.scope"
      }
    ],
    "ips": [
      "10.51.0.150"
    ],
    "name": "client-974f6c69d-w4mbv",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7666,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b40fd89_3012_47bc_8b64_92a601c63b8a.slice/cri-containerd-744f35c5b68261b7670198eccb7e8733b77a3426c78abe6514eb83eb881064f5.scope"
      }
    ],
    "ips": [
      "10.51.0.110"
    ],
    "name": "coredns-cc6ccd49c-czzvk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9058,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7b51963_4f00_4089_91d3_8fc3d1211db2.slice/cri-containerd-3bba73535ce5eee96b7ac1247aaaae581d74da7bd18509344ebfafd35b4ad6c3.scope"
      },
      {
        "cgroup-id": 9142,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7b51963_4f00_4089_91d3_8fc3d1211db2.slice/cri-containerd-ee03d85bd848d686beef8a41aac9a01d11d8f97ce10e0ef347d1178feb670fa9.scope"
      },
      {
        "cgroup-id": 9226,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7b51963_4f00_4089_91d3_8fc3d1211db2.slice/cri-containerd-daf63997588ca0bc00e3ad683867c7c304e44041c0c806a3d3fc3f669dc6e8ef.scope"
      }
    ],
    "ips": [
      "10.51.0.57"
    ],
    "name": "clustermesh-apiserver-6d648955f5-w7cnc",
    "namespace": "kube-system"
  }
]

