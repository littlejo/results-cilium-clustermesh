 12:54:21 up 32 min,  0 users,  load average: 0.43, 0.70, 0.46
