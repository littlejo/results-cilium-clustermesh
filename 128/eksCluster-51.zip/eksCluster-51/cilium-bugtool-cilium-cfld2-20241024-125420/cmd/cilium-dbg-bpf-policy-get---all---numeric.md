Endpoint ID: 372
Path: /sys/fs/bpf/tc/globals/cilium_policy_00372

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 449
Path: /sys/fs/bpf/tc/globals/cilium_policy_00449

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 954
Path: /sys/fs/bpf/tc/globals/cilium_policy_00954

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2376     25        0        
Allow    Ingress     1          ANY          NONE         disabled    148034   1700      0        
Allow    Egress      0          ANY          NONE         disabled    20020    223       0        


Endpoint ID: 1155
Path: /sys/fs/bpf/tc/globals/cilium_policy_01155

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1592
Path: /sys/fs/bpf/tc/globals/cilium_policy_01592

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3520     35        0        
Allow    Ingress     1          ANY          NONE         disabled    147704   1695      0        
Allow    Egress      0          ANY          NONE         disabled    20439    227       0        


Endpoint ID: 2003
Path: /sys/fs/bpf/tc/globals/cilium_policy_02003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6197432   76596     0        
Allow    Ingress     1          ANY          NONE         disabled    65904     794       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3229
Path: /sys/fs/bpf/tc/globals/cilium_policy_03229

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    351259   4108      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3933
Path: /sys/fs/bpf/tc/globals/cilium_policy_03933

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5760561   58408     0        
Allow    Ingress     1          ANY          NONE         disabled    5372746   56694     0        
Allow    Egress      0          ANY          NONE         disabled    6815406   67563     0        


