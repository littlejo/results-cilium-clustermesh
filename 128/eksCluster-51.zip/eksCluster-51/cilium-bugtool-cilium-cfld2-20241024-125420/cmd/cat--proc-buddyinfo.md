Node 0, zone      DMA   1337    390    220    129     63     51     37     28     19     14     40 
Node 0, zone   Normal     86    147     19     36     21     12      5      4      3      3      6 
