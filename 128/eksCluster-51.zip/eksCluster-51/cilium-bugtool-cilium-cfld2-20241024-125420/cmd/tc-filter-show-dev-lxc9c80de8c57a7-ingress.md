filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc9c80de8c57a7 direct-action not_in_hw id 3382 tag d936746c1dcfc45f jited 
