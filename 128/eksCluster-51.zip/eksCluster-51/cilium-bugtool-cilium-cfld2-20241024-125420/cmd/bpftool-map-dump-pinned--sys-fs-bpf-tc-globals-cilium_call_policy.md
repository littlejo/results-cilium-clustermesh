key: 74 01 00 00  value: 33 0d 00 00
key: c1 01 00 00  value: 28 0d 00 00
key: ba 03 00 00  value: 2c 02 00 00
key: 38 06 00 00  value: 14 02 00 00
key: d3 07 00 00  value: 43 02 00 00
key: 9d 0c 00 00  value: fa 0c 00 00
key: 5d 0f 00 00  value: 8c 02 00 00
Found 7 elements
