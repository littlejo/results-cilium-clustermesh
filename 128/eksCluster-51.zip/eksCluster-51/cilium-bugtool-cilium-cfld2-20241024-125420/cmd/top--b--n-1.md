top - 12:54:22 up 32 min,  0 users,  load average: 0.43, 0.70, 0.46
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 54.8 us, 38.7 sy,  0.0 ni,  3.2 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   3836.2 total,    301.5 free,   1069.5 used,   2465.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2585.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 297292  79424 S  80.0   7.6   1:07.03 cilium-+
   3249 root      20   0 1229640  19060   4004 R  13.3   0.5   0:00.02 gops
   3267 root      20   0 1240432  16772  11484 S   6.7   0.4   0:00.03 cilium-+
    392 root      20   0 1229744   9896   3836 S   0.0   0.3   0:03.96 cilium-+
   3317 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3320 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3347 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
