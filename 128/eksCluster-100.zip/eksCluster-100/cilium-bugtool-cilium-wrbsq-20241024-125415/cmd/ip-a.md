1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:8c:35:2d:c0:6d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.164.193/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3531sec preferred_lft 3531sec
    inet6 fe80::48c:35ff:fe2d:c06d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a8:e0:49:d3:53 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.172.47/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a8:e0ff:fe49:d353/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:79:57:e2:4d:11 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f879:57ff:fee2:4d11/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:d0:4a:1e:bf:6e brd ff:ff:ff:ff:ff:ff
    inet 10.100.0.2/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::cd0:4aff:fe1e:bf6e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:ad:db:42:34:e8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3cad:dbff:fe42:34e8/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:21:d8:c3:92:da brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7c21:d8ff:fec3:92da/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc406913a8cb2c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:f4:f2:c3:ed:ac brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::94f4:f2ff:fec3:edac/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfa3234fa1508@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:26:46:f7:f4:5b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::bc26:46ff:fef7:f45b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc47c699abea70@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:30:a5:7a:45:e3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4830:a5ff:fe7a:45e3/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc5bf629053c18@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:7c:b3:35:f0:93 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::7c7c:b3ff:fe35:f093/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc49aee7392aa7@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:23:e7:06:7d:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::8c23:e7ff:fe06:7da7/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc3cac84c63441@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:e7:15:31:2f:00 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::3ce7:15ff:fe31:2f00/64 scope link 
       valid_lft forever preferred_lft forever
