alloc: 79.45MB (83309296 bytes)
total-alloc: 3.05GB (3270632536 bytes)
sys: 215.32MB (225781076 bytes)
lookups: 0
mallocs: 74562437
frees: 73912706
heap-alloc: 79.45MB (83309296 bytes)
heap-sys: 168.85MB (177053696 bytes)
heap-idle: 46.37MB (48619520 bytes)
heap-in-use: 122.48MB (128434176 bytes)
heap-released: 9.26MB (9707520 bytes)
heap-objects: 649731
stack-in-use: 35.12MB (36831232 bytes)
stack-sys: 35.12MB (36831232 bytes)
stack-mspan-inuse: 2.06MB (2160960 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 982.01KB (1005577 bytes)
gc-sys: 5.52MB (5788840 bytes)
next-gc: when heap-alloc >= 147.22MB (154374936 bytes)
last-gc: 2024-10-24 12:54:06.571941913 +0000 UTC
gc-pause-total: 10.123884ms
gc-pause: 127748
gc-pause-end: 1729774446571941913
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006286948845482249
enable-gc: true
debug-gc: false
