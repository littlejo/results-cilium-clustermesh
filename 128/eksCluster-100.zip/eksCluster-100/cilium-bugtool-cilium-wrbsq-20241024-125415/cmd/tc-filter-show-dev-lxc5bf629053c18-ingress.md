filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5bf629053c18 direct-action not_in_hw id 3287 tag 9b960b7865530928 jited 
