KEY             VALUE
AgentLiveness   1878901730746
UTimeOffset     3378462068359375
