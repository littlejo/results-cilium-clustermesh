Node 0, zone      DMA    105      9      3      4      3      5      3      4      3      2     48 
Node 0, zone   Normal    515    142     28     31     43     13      4      2      1      1      7 
