Endpoint ID: 27
Path: /sys/fs/bpf/tc/globals/cilium_policy_00027

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5533578   56486     0        
Allow    Ingress     1          ANY          NONE         disabled    5029809   52918     0        
Allow    Egress      0          ANY          NONE         disabled    5662203   58188     0        


Endpoint ID: 72
Path: /sys/fs/bpf/tc/globals/cilium_policy_00072

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 231
Path: /sys/fs/bpf/tc/globals/cilium_policy_00231

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 955
Path: /sys/fs/bpf/tc/globals/cilium_policy_00955

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3044     31        0        
Allow    Ingress     1          ANY          NONE         disabled    128975   1486      0        
Allow    Egress      0          ANY          NONE         disabled    19025    209       0        


Endpoint ID: 1555
Path: /sys/fs/bpf/tc/globals/cilium_policy_01555

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1903
Path: /sys/fs/bpf/tc/globals/cilium_policy_01903

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6193274   76388     0        
Allow    Ingress     1          ANY          NONE         disabled    63337     761       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2642
Path: /sys/fs/bpf/tc/globals/cilium_policy_02642

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2852     29        0        
Allow    Ingress     1          ANY          NONE         disabled    128314   1472      0        
Allow    Egress      0          ANY          NONE         disabled    18394    201       0        


Endpoint ID: 3440
Path: /sys/fs/bpf/tc/globals/cilium_policy_03440

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    349375   4074      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


