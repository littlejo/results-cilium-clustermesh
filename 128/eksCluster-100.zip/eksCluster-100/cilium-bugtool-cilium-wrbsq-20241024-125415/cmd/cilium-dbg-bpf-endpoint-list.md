IP ADDRESS         LOCAL ENDPOINT INFO
10.100.0.247:0     id=2642  sec_id=6664572 flags=0x0000 ifindex=14  mac=2E:3B:D3:90:4E:C8 nodemac=BE:26:46:F7:F4:5B   
172.31.172.47:0    (localhost)                                                                                        
10.100.0.61:0      id=3440  sec_id=6636783 flags=0x0000 ifindex=20  mac=92:21:87:7B:18:6E nodemac=7E:7C:B3:35:F0:93   
10.100.0.71:0      id=72    sec_id=6621518 flags=0x0000 ifindex=22  mac=A6:2A:F5:AC:0E:8D nodemac=8E:23:E7:06:7D:A7   
10.100.0.181:0     id=1555  sec_id=6644563 flags=0x0000 ifindex=24  mac=F6:5F:2C:47:0C:A9 nodemac=3E:E7:15:31:2F:00   
10.100.0.2:0       (localhost)                                                                                        
10.100.0.151:0     id=1903  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D8:06:F5:7E:65 nodemac=7E:21:D8:C3:92:DA     
172.31.164.193:0   (localhost)                                                                                        
10.100.0.12:0      id=27    sec_id=6648039 flags=0x0000 ifindex=18  mac=D2:97:37:00:2B:7C nodemac=4A:30:A5:7A:45:E3   
10.100.0.72:0      id=955   sec_id=6664572 flags=0x0000 ifindex=12  mac=96:DC:EB:FD:57:C1 nodemac=96:F4:F2:C3:ED:AC   
