filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc406913a8cb2c direct-action not_in_hw id 517 tag ca5b2ad9b0e45b23 jited 
