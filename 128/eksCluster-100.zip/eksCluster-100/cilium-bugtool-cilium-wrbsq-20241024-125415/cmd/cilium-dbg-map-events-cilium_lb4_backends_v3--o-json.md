{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:31:54.025Z",
  "value": "ANY://172.31.161.198"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:31:54.025Z",
  "value": "ANY://172.31.206.165"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:31:54.025Z",
  "value": "ANY://172.31.183.208"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:31:54.025Z",
  "value": "ANY://172.31.183.208"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:31:56.979Z",
  "value": "ANY://172.31.164.193"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:31:57.031Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:31:57.031Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:32:01.979Z",
  "value": "ANY://10.100.0.247"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:32:01.979Z",
  "value": "ANY://10.100.0.247"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:32:02.002Z",
  "value": "ANY://10.100.0.72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:32:02.002Z",
  "value": "ANY://10.100.0.72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:38:45.705Z",
  "value": "ANY://10.100.0.29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "11",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:21.101Z",
  "value": "ANY://10.100.0.12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:21.221Z",
  "value": "ANY://10.100.0.29"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:21.636Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "12",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:29.746Z",
  "value": "ANY://10.100.0.61"
}

