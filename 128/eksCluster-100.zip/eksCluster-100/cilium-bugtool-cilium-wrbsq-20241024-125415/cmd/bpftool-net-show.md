xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 568
ens6(5) clsact/ingress cil_from_netdev-ens6 id 579
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 558
cilium_host(7) clsact/egress cil_from_host-cilium_host id 555
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 532
lxc406913a8cb2c(12) clsact/ingress cil_from_container-lxc406913a8cb2c id 517
lxcfa3234fa1508(14) clsact/ingress cil_from_container-lxcfa3234fa1508 id 510
lxc47c699abea70(18) clsact/ingress cil_from_container-lxc47c699abea70 id 623
lxc5bf629053c18(20) clsact/ingress cil_from_container-lxc5bf629053c18 id 3287
lxc49aee7392aa7(22) clsact/ingress cil_from_container-lxc49aee7392aa7 id 3344
lxc3cac84c63441(24) clsact/ingress cil_from_container-lxc3cac84c63441 id 3345

flow_dissector:

netfilter:

