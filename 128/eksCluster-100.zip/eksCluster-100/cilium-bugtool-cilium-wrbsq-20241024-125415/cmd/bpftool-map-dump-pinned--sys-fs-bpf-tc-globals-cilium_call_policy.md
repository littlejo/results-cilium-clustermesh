key: 1b 00 00 00  value: 6d 02 00 00
key: 48 00 00 00  value: 06 0d 00 00
key: bb 03 00 00  value: 10 02 00 00
key: 13 06 00 00  value: 14 0d 00 00
key: 6f 07 00 00  value: 1e 02 00 00
key: 52 0a 00 00  value: 02 02 00 00
key: 70 0d 00 00  value: d6 0c 00 00
Found 7 elements
