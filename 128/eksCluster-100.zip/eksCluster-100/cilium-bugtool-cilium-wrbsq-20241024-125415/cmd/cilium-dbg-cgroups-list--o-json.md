[
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod170adb03_3ff2_4f1c_ae6c_92baf4cb5ee9.slice/cri-containerd-3111d628d40fda08e58f46515aef7411d026feeafe1a5ab9a910b865547e8f05.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod170adb03_3ff2_4f1c_ae6c_92baf4cb5ee9.slice/cri-containerd-347478050a10436791e04cb4dc90ba6cb7acec36b4d43a35a7a0322b647fc1ef.scope"
      }
    ],
    "ips": [
      "10.100.0.61"
    ],
    "name": "echo-same-node-86d9cc975c-4z5zw",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod889d7c50_8713_4edd_b343_7c7c64908709.slice/cri-containerd-e8440d629cf57d9d8b4783fe96d73fba653acb782a0eede3b854f5fd385948c4.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod889d7c50_8713_4edd_b343_7c7c64908709.slice/cri-containerd-da412aad16c24d428d2c506f83505499795537b625f41740f26e93c1abedde59.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod889d7c50_8713_4edd_b343_7c7c64908709.slice/cri-containerd-dd65ec1aab30af68262c259ad204a744cc301bfb584e317850dcc2334cccad33.scope"
      }
    ],
    "ips": [
      "10.100.0.12"
    ],
    "name": "clustermesh-apiserver-6588c7c56f-9kblm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7dc2398b_fa2a_4dd8_a004_e464547c7d5a.slice/cri-containerd-f477bbf047ee3dba828c0dd4ddeabd05e7eea0b6d586252c5b5ece96983d6100.scope"
      }
    ],
    "ips": [
      "10.100.0.72"
    ],
    "name": "coredns-cc6ccd49c-kk6pb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc85ee77d_1af0_4607_bd00_256c949aebf5.slice/cri-containerd-177cb31d7d4d8d8834c159cd0e2ad00f0ead6675e5c0bfc63dc51847555f0063.scope"
      }
    ],
    "ips": [
      "10.100.0.247"
    ],
    "name": "coredns-cc6ccd49c-m7c49",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02b4fe97_093f_4062_bab7_2f4a84e57b87.slice/cri-containerd-7c057b0c8b145807ad2b8596fd850029c7608cd9b660e5db793580dca345bcff.scope"
      }
    ],
    "ips": [
      "10.100.0.181"
    ],
    "name": "client2-57cf4468f-7kf4b",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ce7d221_ef08_4098_99f2_afc4d4352f40.slice/cri-containerd-1ed2460e99ee7f852cb883ef980a60460eaea29bb2a8f1a732ea730563801e62.scope"
      }
    ],
    "ips": [
      "10.100.0.71"
    ],
    "name": "client-974f6c69d-n54v8",
    "namespace": "cilium-test-1"
  }
]

