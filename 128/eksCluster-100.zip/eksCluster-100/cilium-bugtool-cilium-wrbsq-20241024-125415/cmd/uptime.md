 12:54:16 up 31 min,  0 users,  load average: 0.25, 0.39, 0.23
