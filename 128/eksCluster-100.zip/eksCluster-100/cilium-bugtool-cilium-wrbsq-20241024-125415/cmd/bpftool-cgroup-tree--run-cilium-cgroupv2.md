CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podec66349d_ba47_4f88_898d_a2f2f9ebb1b8.slice/cri-containerd-c3dce7121a67a4bfd78ff5a6cc66d333fcbe749042599563a2ee83ce9c6ff6cd.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podec66349d_ba47_4f88_898d_a2f2f9ebb1b8.slice/cri-containerd-f509e45ec142eac21a556c3f14aba2b97197991b227aca4fef9f18372534001f.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod262f6865_604a_418b_a998_b74fa8a789bd.slice/cri-containerd-26e6bc18054dc992bf6ed230a798a015b4f1f38fbe2d7d038b2cd490892b67c6.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod262f6865_604a_418b_a998_b74fa8a789bd.slice/cri-containerd-bbdb1950c08363afd2d4bda2cbbc4516d1ffc385921877cb4118dc719e145014.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7dc2398b_fa2a_4dd8_a004_e464547c7d5a.slice/cri-containerd-f477bbf047ee3dba828c0dd4ddeabd05e7eea0b6d586252c5b5ece96983d6100.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7dc2398b_fa2a_4dd8_a004_e464547c7d5a.slice/cri-containerd-67d425d96115c281a22620d2439fae41c798fcad9ea7eb54645e9885a75a4d19.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc85ee77d_1af0_4607_bd00_256c949aebf5.slice/cri-containerd-bba1545c5888e570640b02d642e042f82f4e22c4bfb9b83523e600df365f6ab6.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc85ee77d_1af0_4607_bd00_256c949aebf5.slice/cri-containerd-177cb31d7d4d8d8834c159cd0e2ad00f0ead6675e5c0bfc63dc51847555f0063.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf2a9635_a54a_44b5_a19d_36ed451283ed.slice/cri-containerd-962dbee88ab51cfb9d707cc32916305c6a39a01cd604df1b81a1541c6e39a2ff.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf2a9635_a54a_44b5_a19d_36ed451283ed.slice/cri-containerd-9e1fe4be4222397eef18f73b30bb84d779f05a0393ff335d8beff4010c10a711.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod170adb03_3ff2_4f1c_ae6c_92baf4cb5ee9.slice/cri-containerd-347478050a10436791e04cb4dc90ba6cb7acec36b4d43a35a7a0322b647fc1ef.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod170adb03_3ff2_4f1c_ae6c_92baf4cb5ee9.slice/cri-containerd-e7066c0eb0c10449cd90942fa8f4c4d070fffa025f4df40d495277bef8a1094f.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod170adb03_3ff2_4f1c_ae6c_92baf4cb5ee9.slice/cri-containerd-3111d628d40fda08e58f46515aef7411d026feeafe1a5ab9a910b865547e8f05.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ce7d221_ef08_4098_99f2_afc4d4352f40.slice/cri-containerd-1ed2460e99ee7f852cb883ef980a60460eaea29bb2a8f1a732ea730563801e62.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ce7d221_ef08_4098_99f2_afc4d4352f40.slice/cri-containerd-4d2a53439faa4ad308562d2fdbac2cfd63796bfd9a91d6c6bc4a52993f8dc2ee.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc0ea339a_1baf_4a37_8ef9_449a0f58b5f2.slice/cri-containerd-4f5f6fb4d4e335f9fea3804b3fdc9e37a7bce240a4a31dd61360d5a325931838.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc0ea339a_1baf_4a37_8ef9_449a0f58b5f2.slice/cri-containerd-69466883fae9237ede76ce3ddcd85097a108d4ec9736e8155b93f24cef16418e.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02b4fe97_093f_4062_bab7_2f4a84e57b87.slice/cri-containerd-8196865f8fbf1fcb8331ad6560c094a113eeac790ab0c60d4527f94a00addd29.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02b4fe97_093f_4062_bab7_2f4a84e57b87.slice/cri-containerd-7c057b0c8b145807ad2b8596fd850029c7608cd9b660e5db793580dca345bcff.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod889d7c50_8713_4edd_b343_7c7c64908709.slice/cri-containerd-dd65ec1aab30af68262c259ad204a744cc301bfb584e317850dcc2334cccad33.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod889d7c50_8713_4edd_b343_7c7c64908709.slice/cri-containerd-03b4d25b7d642242018f95aef7a8223f5fde348c4ba29ca5d9a63790529e4ae3.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod889d7c50_8713_4edd_b343_7c7c64908709.slice/cri-containerd-da412aad16c24d428d2c506f83505499795537b625f41740f26e93c1abedde59.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod889d7c50_8713_4edd_b343_7c7c64908709.slice/cri-containerd-e8440d629cf57d9d8b4783fe96d73fba653acb782a0eede3b854f5fd385948c4.scope
    654      cgroup_device   multi                                          
