top - 12:54:16 up 31 min,  0 users,  load average: 0.25, 0.39, 0.23
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 27.6 us, 34.5 sy,  0.0 ni, 37.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    308.5 free,   1032.6 used,   2495.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2622.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 286988  78584 S  18.8   7.3   1:04.73 cilium-+
   3251 root      20   0 1240432  15852  11100 S   6.2   0.4   0:00.03 cilium-+
    395 root      20   0 1229744  10368   4028 S   0.0   0.3   0:04.37 cilium-+
   3286 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3316 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
