key: 41 01 00 00  value: 1f 0d 00 00
key: 84 01 00 00  value: 15 02 00 00
key: ff 01 00 00  value: 77 02 00 00
key: 19 03 00 00  value: 20 02 00 00
key: 80 03 00 00  value: d6 0c 00 00
key: 25 06 00 00  value: 1b 0d 00 00
key: f1 0f 00 00  value: 27 02 00 00
Found 7 elements
