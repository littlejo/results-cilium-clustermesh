CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ed8e45a_478b_4792_a1e3_8ac23bb3b13d.slice/cri-containerd-b3a14db373197108da7ce0cf56e2438803f9696c9893bb97a8bf10157f12d1ac.scope
    492      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ed8e45a_478b_4792_a1e3_8ac23bb3b13d.slice/cri-containerd-f868fe92e90c6c519ba2fbf3c61e95bed9c2463f8c92a0428f5c9f1b2db5f5e9.scope
    496      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod998ddedf_6e23_443a_aaf1_d7412dc6d9a1.slice/cri-containerd-747d35d6a64521e0bb25157cffd980ecbce15264260ecdc7e95c429f7aacc346.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod998ddedf_6e23_443a_aaf1_d7412dc6d9a1.slice/cri-containerd-7bde1a73e6f1ca0a7597fc62258056eacff8b1a19655b4e017186fbebd6362f5.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04dc6c25_f22f_46c5_8c06_43bf84b9c3c6.slice/cri-containerd-9da88aabe51e0834cdff8782360708e944ad1c440a6a25b2dae2ebd78c0f8839.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04dc6c25_f22f_46c5_8c06_43bf84b9c3c6.slice/cri-containerd-861ec24785d02c3ccbd74701fefeba37b66ab3fa3d6985a4a0455a39c3ed9943.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4154f217_3900_48fa_a3d2_d29278f6f6e9.slice/cri-containerd-f2b8766b4d5f4a79f6676f48078ef5223584eb6004d2dd8de0df1d4cf30c1094.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4154f217_3900_48fa_a3d2_d29278f6f6e9.slice/cri-containerd-7569d8254e876ad5a19eccb079b1c5c85b81f2af349675a7d4e16ad5ef74c502.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18b10659_749a_4f18_b44e_499c37966a42.slice/cri-containerd-b4487bb9f8e0ef357d38a6ee55fd6b50982a5dcfb0537b62fe1245120d65fe1c.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18b10659_749a_4f18_b44e_499c37966a42.slice/cri-containerd-49a99ec1665637ddde5690a4eebe535d02a266bb6060b737c3778737f838ab8d.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e887f5b_7ced_4d21_abe6_5fe1f3a46da3.slice/cri-containerd-46ab97296313a6e660ffb7cad43a4fc587942b60d783923afc884d6a7ed60c96.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e887f5b_7ced_4d21_abe6_5fe1f3a46da3.slice/cri-containerd-846757104f94d0a2fcaef01267edf6ed5584cc35abec046d281748f10d19c2c4.scope
    665      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e887f5b_7ced_4d21_abe6_5fe1f3a46da3.slice/cri-containerd-17d05921863743983e861cc07a489879b196f8a2d98a7f87c848a4b109bad1b8.scope
    669      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e887f5b_7ced_4d21_abe6_5fe1f3a46da3.slice/cri-containerd-288bfb5545d702d97c65de31b261a90f8a7d45e6014a0b8bbe6b138b703102e0.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92c989c3_2737_401d_b363_14a9be7b1dfa.slice/cri-containerd-d215af17348924272bf4d462fbd6e2ac43a52ac7cba34f99bf71457998f730e3.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92c989c3_2737_401d_b363_14a9be7b1dfa.slice/cri-containerd-f80775bd395df5fc0bf3d6674cb0c4e6bb5954aa479a4808aa8037042efe0af2.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92c989c3_2737_401d_b363_14a9be7b1dfa.slice/cri-containerd-6fbd40a18b75f57ba6d1b2ce05bb28bde969b71c7c255c36acc3abb555c0a3e7.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1679eb2_e26f_4b6b_b5f0_be5bbcfa07e1.slice/cri-containerd-4d89478c88d968743bca5b62fbf38ec4a6fed0375f901c6437cbf9d0f1414d30.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1679eb2_e26f_4b6b_b5f0_be5bbcfa07e1.slice/cri-containerd-e19e8abbf11190a7bcefca65484e15025e7540bc83cf8243b973aa727e15b708.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd1b047b8_141a_4749_8fb4_65ae454e7ed1.slice/cri-containerd-42114390f9713d53bd4128f333601195e2334c6d0dd47d5f84461026c94bffcc.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd1b047b8_141a_4749_8fb4_65ae454e7ed1.slice/cri-containerd-148f67f12dc83aaf2078e669b32a79506cf090f441af4d78339535087167e41a.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0cd5089_21df_485a_b35e_35b5348363d2.slice/cri-containerd-c4c443d17dbc83afcd1820f6c61c526273d18a9f6781e11e58fdc54e602f87ee.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0cd5089_21df_485a_b35e_35b5348363d2.slice/cri-containerd-88bbaa4b4595274183f5de60da40cffd83b60a50a133a275ab52ff73744bd801.scope
    103      cgroup_device   multi                                          
