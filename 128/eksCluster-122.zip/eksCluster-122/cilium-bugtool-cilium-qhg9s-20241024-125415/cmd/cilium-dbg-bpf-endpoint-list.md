IP ADDRESS         LOCAL ENDPOINT INFO
10.122.0.146:0     id=511   sec_id=8090388 flags=0x0000 ifindex=18  mac=52:3E:84:A4:8E:73 nodemac=6A:3F:55:55:D1:92   
10.122.0.252:0     id=4081  sec_id=8068691 flags=0x0000 ifindex=14  mac=B2:4B:F8:80:1B:A5 nodemac=2A:42:E0:60:87:80   
172.31.183.142:0   (localhost)                                                                                        
10.122.0.186:0     id=388   sec_id=8068691 flags=0x0000 ifindex=12  mac=76:A6:2F:B9:80:05 nodemac=A2:CE:2B:58:01:6E   
172.31.191.30:0    (localhost)                                                                                        
10.122.0.47:0      id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F   
10.122.0.110:0     id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5   
10.122.0.213:0     id=793   sec_id=4     flags=0x0000 ifindex=10  mac=B6:91:64:8B:AD:B1 nodemac=76:33:32:AF:18:01     
10.122.0.137:0     (localhost)                                                                                        
10.122.0.11:0      id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA   
