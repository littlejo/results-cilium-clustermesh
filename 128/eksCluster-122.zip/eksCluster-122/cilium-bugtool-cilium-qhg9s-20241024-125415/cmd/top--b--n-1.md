top - 12:54:16 up 30 min,  0 users,  load average: 0.27, 0.29, 0.18
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s):  7.1 us, 39.3 sy,  0.0 ni, 53.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    284.6 free,   1054.5 used,   2497.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2600.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539132 294464  78400 S   6.7   7.5   1:04.80 cilium-+
    394 root      20   0 1229744  10108   3836 S   0.0   0.3   0:04.36 cilium-+
   3255 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3256 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3269 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3297 root      20   0 1240432  16240  11292 S   0.0   0.4   0:00.02 cilium-+
   3335 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3360 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
