1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:75:43:83:9a:c1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.191.30/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3565sec preferred_lft 3565sec
    inet6 fe80::475:43ff:fe83:9ac1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a5:34:6b:d1:45 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.183.142/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a5:34ff:fe6b:d145/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:ef:52:b8:65:22 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::94ef:52ff:feb8:6522/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:a1:1e:ed:33:58 brd ff:ff:ff:ff:ff:ff
    inet 10.122.0.137/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::80a1:1eff:feed:3358/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d2:ff:04:7c:e1:d0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d0ff:4ff:fe7c:e1d0/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:33:32:af:18:01 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7433:32ff:feaf:1801/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2134dfadd79c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:ce:2b:58:01:6e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a0ce:2bff:fe58:16e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcacfa48760e45@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:42:e0:60:87:80 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::2842:e0ff:fe60:8780/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6b69e45b4718@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:3f:55:55:d1:92 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::683f:55ff:fe55:d192/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcd7b09778453f@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:cc:a2:26:65:e5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::50cc:a2ff:fe26:65e5/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc80620d885184@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:9a:c6:93:f2:5f brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::dc9a:c6ff:fe93:f25f/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcff196b51af5c@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:51:b8:95:62:fa brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::9851:b8ff:fe95:62fa/64 scope link 
       valid_lft forever preferred_lft forever
