Endpoint ID: 321
Path: /sys/fs/bpf/tc/globals/cilium_policy_00321

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 388
Path: /sys/fs/bpf/tc/globals/cilium_policy_00388

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3774     38        0        
Allow    Ingress     1          ANY          NONE         disabled    117205   1336      0        
Allow    Egress      0          ANY          NONE         disabled    18003    197       0        


Endpoint ID: 511
Path: /sys/fs/bpf/tc/globals/cilium_policy_00511

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6121015   60532     0        
Allow    Ingress     1          ANY          NONE         disabled    5562988   56983     0        
Allow    Egress      0          ANY          NONE         disabled    5760389   57945     0        


Endpoint ID: 793
Path: /sys/fs/bpf/tc/globals/cilium_policy_00793

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6240726   77000     0        
Allow    Ingress     1          ANY          NONE         disabled    60655     732       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 896
Path: /sys/fs/bpf/tc/globals/cilium_policy_00896

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378126   4409      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 979
Path: /sys/fs/bpf/tc/globals/cilium_policy_00979

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1573
Path: /sys/fs/bpf/tc/globals/cilium_policy_01573

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 4081
Path: /sys/fs/bpf/tc/globals/cilium_policy_04081

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2122     22        0        
Allow    Ingress     1          ANY          NONE         disabled    117205   1336      0        
Allow    Egress      0          ANY          NONE         disabled    17402    190       0        


