[
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e887f5b_7ced_4d21_abe6_5fe1f3a46da3.slice/cri-containerd-17d05921863743983e861cc07a489879b196f8a2d98a7f87c848a4b109bad1b8.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e887f5b_7ced_4d21_abe6_5fe1f3a46da3.slice/cri-containerd-288bfb5545d702d97c65de31b261a90f8a7d45e6014a0b8bbe6b138b703102e0.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e887f5b_7ced_4d21_abe6_5fe1f3a46da3.slice/cri-containerd-846757104f94d0a2fcaef01267edf6ed5584cc35abec046d281748f10d19c2c4.scope"
      }
    ],
    "ips": [
      "10.122.0.146"
    ],
    "name": "clustermesh-apiserver-558cb5597-xzb8j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7493,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ed8e45a_478b_4792_a1e3_8ac23bb3b13d.slice/cri-containerd-f868fe92e90c6c519ba2fbf3c61e95bed9c2463f8c92a0428f5c9f1b2db5f5e9.scope"
      }
    ],
    "ips": [
      "10.122.0.186"
    ],
    "name": "coredns-cc6ccd49c-9pbzg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4154f217_3900_48fa_a3d2_d29278f6f6e9.slice/cri-containerd-7569d8254e876ad5a19eccb079b1c5c85b81f2af349675a7d4e16ad5ef74c502.scope"
      }
    ],
    "ips": [
      "10.122.0.252"
    ],
    "name": "coredns-cc6ccd49c-4f7gr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd1b047b8_141a_4749_8fb4_65ae454e7ed1.slice/cri-containerd-148f67f12dc83aaf2078e669b32a79506cf090f441af4d78339535087167e41a.scope"
      }
    ],
    "ips": [
      "10.122.0.110"
    ],
    "name": "client-974f6c69d-g6l6q",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18b10659_749a_4f18_b44e_499c37966a42.slice/cri-containerd-b4487bb9f8e0ef357d38a6ee55fd6b50982a5dcfb0537b62fe1245120d65fe1c.scope"
      }
    ],
    "ips": [
      "10.122.0.11"
    ],
    "name": "client2-57cf4468f-868bs",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92c989c3_2737_401d_b363_14a9be7b1dfa.slice/cri-containerd-d215af17348924272bf4d462fbd6e2ac43a52ac7cba34f99bf71457998f730e3.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92c989c3_2737_401d_b363_14a9be7b1dfa.slice/cri-containerd-f80775bd395df5fc0bf3d6674cb0c4e6bb5954aa479a4808aa8037042efe0af2.scope"
      }
    ],
    "ips": [
      "10.122.0.47"
    ],
    "name": "echo-same-node-86d9cc975c-f5n6d",
    "namespace": "cilium-test-1"
  }
]

