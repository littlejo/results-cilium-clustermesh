{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.357Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.430Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.447Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.478Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.141Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.167Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.212Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.220Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.221Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.247Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.451Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.457Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.514Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.558Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.581Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.208Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.215Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.262Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.268Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.305Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.536Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.550Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.583Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.604Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.659Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.179Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.250Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.365Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.365Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.409Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.412Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.613Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.619Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.673Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.696Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.743Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.273Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.294Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.345Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.357Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.386Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.631Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.655Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.691Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.712Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.742Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.160Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.165Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.217Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.234Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.255Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.456Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.471Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.512Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.525Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.552Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.011Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.017Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.064Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.072Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.106Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.329Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.335Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.415Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.442Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.496Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.909Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.939Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.961Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.987Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.005Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.260Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.265Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.341Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.373Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.391Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.850Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.884Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.897Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.945Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.973Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.996Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.264Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.265Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.316Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.380Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.386Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.809Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.817Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.860Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.866Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.907Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.109Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.114Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.165Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.186Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.212Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.540Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.580Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.583Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.631Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.639Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.667Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.877Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.892Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.983Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.000Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.056Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.267Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.332Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.336Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.391Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.392Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.432Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.658Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.673Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.680Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.688Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.701Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.389Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.392Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.425Z",
  "value": "id=896   sec_id=8099877 flags=0x0000 ifindex=22  mac=E6:B6:E5:0F:81:11 nodemac=DE:9A:C6:93:F2:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.434Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.460Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.724Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.741Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.435Z",
  "value": "id=1573  sec_id=8097192 flags=0x0000 ifindex=20  mac=36:0E:31:A4:42:48 nodemac=52:CC:A2:26:65:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.436Z",
  "value": "id=321   sec_id=8080382 flags=0x0000 ifindex=24  mac=86:E0:D0:D0:34:88 nodemac=9A:51:B8:95:62:FA"
}

