xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 584
ens6(5) clsact/ingress cil_from_netdev-ens6 id 587
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 572
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 567
cilium_host(7) clsact/egress cil_from_host-cilium_host id 566
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 499
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 500
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 539
lxc2134dfadd79c(12) clsact/ingress cil_from_container-lxc2134dfadd79c id 523
lxcacfa48760e45(14) clsact/ingress cil_from_container-lxcacfa48760e45 id 552
lxc6b69e45b4718(18) clsact/ingress cil_from_container-lxc6b69e45b4718 id 634
lxcd7b09778453f(20) clsact/ingress cil_from_container-lxcd7b09778453f id 3358
lxc80620d885184(22) clsact/ingress cil_from_container-lxc80620d885184 id 3289
lxcff196b51af5c(24) clsact/ingress cil_from_container-lxcff196b51af5c id 3346

flow_dissector:

netfilter:

