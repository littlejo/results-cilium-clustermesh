 12:54:16 up 30 min,  0 users,  load average: 0.27, 0.29, 0.18
