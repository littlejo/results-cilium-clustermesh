alloc: 87.56MB (91817960 bytes)
total-alloc: 3.13GB (3355457112 bytes)
sys: 223.64MB (234505556 bytes)
lookups: 0
mallocs: 75545724
frees: 74848417
heap-alloc: 87.56MB (91817960 bytes)
heap-sys: 174.73MB (183214080 bytes)
heap-idle: 41.34MB (43352064 bytes)
heap-in-use: 133.38MB (139862016 bytes)
heap-released: 4.70MB (4923392 bytes)
heap-objects: 697307
stack-in-use: 37.25MB (39059456 bytes)
stack-sys: 37.25MB (39059456 bytes)
stack-mspan-inuse: 2.15MB (2251520 bytes)
stack-mspan-sys: 2.88MB (3019200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.14MB (1199329 bytes)
gc-sys: 5.52MB (5792960 bytes)
next-gc: when heap-alloc >= 149.46MB (156722104 bytes)
last-gc: 2024-10-24 12:54:31.77070753 +0000 UTC
gc-pause-total: 10.243899ms
gc-pause: 70294
gc-pause-end: 1729774471770707530
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0007854225653223683
enable-gc: true
debug-gc: false
