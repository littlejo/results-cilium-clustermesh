Total: 585
TCP:   4657 (estab 309, closed 4329, orphaned 0, timewait 3864)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  328       317       11       
INET	  338       323       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                   172.31.191.30%ens5:68         0.0.0.0:*    uid:192 ino:159820 sk:2001 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:37431 sk:2002 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15695 sk:2003 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:33173      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:37224 sk:2004 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:37430 sk:2005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15696 sk:2006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::475:43ff:fe83:9ac1]%ens5:546           [::]:*    uid:192 ino:14078 sk:2007 cgroup:unreachable:bd0 v6only:1 <->                   
