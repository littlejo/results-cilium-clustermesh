Node 0, zone      DMA    251     44     19      2      4      9      4      2      3      3     39 
Node 0, zone   Normal    321     94      3      2      2     27      9      6      1      3      6 
