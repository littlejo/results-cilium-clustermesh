[
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2158c33_beb5_4687_a98d_fa2f5a893c90.slice/cri-containerd-e47157de2f7061cb9f89fc8389c55ee3120dc51d5be12db083dead4cec740a02.scope"
      }
    ],
    "ips": [
      "10.117.0.209"
    ],
    "name": "client-974f6c69d-788wb",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod139159c2_30ad_4fef_8c56_7a97045945a6.slice/cri-containerd-9107974599830f1e1905c6a8f6250096f027588f55f39824df72f7563b8c3352.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod139159c2_30ad_4fef_8c56_7a97045945a6.slice/cri-containerd-e4558027b2ba69723aecce6565b480658436fda8c8ceafbe8cfd590db3771bee.scope"
      }
    ],
    "ips": [
      "10.117.0.125"
    ],
    "name": "echo-same-node-86d9cc975c-c66wk",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedff765f_7c7b_473b_b535_4c1106f612e8.slice/cri-containerd-43f2e43108b8ab541609a2e0718d8741de1aa58d5086a23ff4c65e6508c702f9.scope"
      }
    ],
    "ips": [
      "10.117.0.122"
    ],
    "name": "coredns-cc6ccd49c-xmjfl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d328752_0fd6_4c47_acf7_198e38b8b851.slice/cri-containerd-24f6b4ed888fb1ea4106af6423151ac2c4f3224af3205f47f4a5f951988f3fe0.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d328752_0fd6_4c47_acf7_198e38b8b851.slice/cri-containerd-a4e46de581826b769c05d0d015960deb2dd3785f82d9c1065c5da629f7b508cc.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d328752_0fd6_4c47_acf7_198e38b8b851.slice/cri-containerd-62de92820a01d9fd749ad86c5a07e03201708ca6703260adfa769bd857bdd2e6.scope"
      }
    ],
    "ips": [
      "10.117.0.132"
    ],
    "name": "clustermesh-apiserver-7f66685666-xz9bq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3440918a_b12f_43a8_abde_64a927af0d58.slice/cri-containerd-3efe5fa3da8a8ad33f046a1ce02a834d7739e2b0200c700c409527cb23503814.scope"
      }
    ],
    "ips": [
      "10.117.0.69"
    ],
    "name": "coredns-cc6ccd49c-xm49d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod380f870c_6b1b_4154_a3d1_4b54a1ef97fa.slice/cri-containerd-1e835525e8b037c52fa427112a68c61c1028ca80715c4c631cac087f8d8ed9f2.scope"
      }
    ],
    "ips": [
      "10.117.0.62"
    ],
    "name": "client2-57cf4468f-hj2dg",
    "namespace": "cilium-test-1"
  }
]

