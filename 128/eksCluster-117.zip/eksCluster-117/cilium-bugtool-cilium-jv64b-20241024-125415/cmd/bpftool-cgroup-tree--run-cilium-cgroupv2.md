CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode34b4af1_ce62_41a3_94f8_c9f9f7310f9f.slice/cri-containerd-0d26bf43ef5ef65566b0417f178684ebeaf3c9ccd2de04f7d4bc7f617ccb798d.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode34b4af1_ce62_41a3_94f8_c9f9f7310f9f.slice/cri-containerd-28c45d3842d6de2f65b2077010943d76a57b2b3118cacdb200b368df8fd1806e.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc6763bd_2492_4d7d_a1fc_eaebb569b057.slice/cri-containerd-2dd611f78b5721f7cb7e2f75537f638b9834ea2dcc1d48c45cf5a20c03ba4cd8.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc6763bd_2492_4d7d_a1fc_eaebb569b057.slice/cri-containerd-f12791262d1de1dd1b5643bbe3860751c89386fd0ecde61dbce15de2091a7c3f.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3440918a_b12f_43a8_abde_64a927af0d58.slice/cri-containerd-324fa811e04e010ac507520278d85b82ab2a1ad078b6fd7a43e864e81363d2aa.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3440918a_b12f_43a8_abde_64a927af0d58.slice/cri-containerd-3efe5fa3da8a8ad33f046a1ce02a834d7739e2b0200c700c409527cb23503814.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedff765f_7c7b_473b_b535_4c1106f612e8.slice/cri-containerd-43f2e43108b8ab541609a2e0718d8741de1aa58d5086a23ff4c65e6508c702f9.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedff765f_7c7b_473b_b535_4c1106f612e8.slice/cri-containerd-b402a8d4ee6060bd70ca0827da5fa58c1b9406d959a97655644ba112aa15a664.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod380f870c_6b1b_4154_a3d1_4b54a1ef97fa.slice/cri-containerd-8fa7ffff873dd4a8ecc48028e46b96c0772904dc63431d69030dd38ec3a1d847.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod380f870c_6b1b_4154_a3d1_4b54a1ef97fa.slice/cri-containerd-1e835525e8b037c52fa427112a68c61c1028ca80715c4c631cac087f8d8ed9f2.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d7d0e47_643a_4425_9e98_d9caa3c7d359.slice/cri-containerd-f3678641655bba97750e1a0da9a6850c603bdc277c9c5282199457f692e57bf9.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d7d0e47_643a_4425_9e98_d9caa3c7d359.slice/cri-containerd-922e28bac12d1ff673448a3dd52dd74c66672635271db7320dc96b59d1834dd1.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2158c33_beb5_4687_a98d_fa2f5a893c90.slice/cri-containerd-e47157de2f7061cb9f89fc8389c55ee3120dc51d5be12db083dead4cec740a02.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2158c33_beb5_4687_a98d_fa2f5a893c90.slice/cri-containerd-d4df000313c332e79c3f48f6dae99d13e21c7f188919014ecc5ed775a8bb5360.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d328752_0fd6_4c47_acf7_198e38b8b851.slice/cri-containerd-eb0c2e2e603d9d394774ce86ca1a8fdb7ec3c91f8c8002fda790c49e6b368a9e.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d328752_0fd6_4c47_acf7_198e38b8b851.slice/cri-containerd-a4e46de581826b769c05d0d015960deb2dd3785f82d9c1065c5da629f7b508cc.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d328752_0fd6_4c47_acf7_198e38b8b851.slice/cri-containerd-24f6b4ed888fb1ea4106af6423151ac2c4f3224af3205f47f4a5f951988f3fe0.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d328752_0fd6_4c47_acf7_198e38b8b851.slice/cri-containerd-62de92820a01d9fd749ad86c5a07e03201708ca6703260adfa769bd857bdd2e6.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod139159c2_30ad_4fef_8c56_7a97045945a6.slice/cri-containerd-e4558027b2ba69723aecce6565b480658436fda8c8ceafbe8cfd590db3771bee.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod139159c2_30ad_4fef_8c56_7a97045945a6.slice/cri-containerd-9107974599830f1e1905c6a8f6250096f027588f55f39824df72f7563b8c3352.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod139159c2_30ad_4fef_8c56_7a97045945a6.slice/cri-containerd-0adb31fabf5fbd42f6938948329d97fc57486f2c038a068723058757c445d8cc.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c3762af_4cfc_445f_b150_df2efc27a39e.slice/cri-containerd-836fa0649568f7ea5b4ca5aa7b0c2a8bd832447870edf2dd593d60229e5e275a.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c3762af_4cfc_445f_b150_df2efc27a39e.slice/cri-containerd-4efa6bf73a1f8c95aaa80d12575696588b9b90f9f5c745a02b0e88a84958444a.scope
    99       cgroup_device   multi                                          
