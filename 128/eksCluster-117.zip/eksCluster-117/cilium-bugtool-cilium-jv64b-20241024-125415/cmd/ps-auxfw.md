USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3243  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3237  0.0  0.3 1240432 15644 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3261  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3263  0.0  0.3 1240432 15644 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3224  0.0  0.0 1228744 3604 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3209  0.0  0.0 1228744 3716 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  5.2  7.3 1539060 286916 ?      Ssl  12:33   1:06 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.3  0.2 1229744 10124 ?       Sl   12:33   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
