filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8f640a2d8f24 direct-action not_in_hw id 504 tag d8513f2c48708dce jited 
