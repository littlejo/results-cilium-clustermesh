Endpoint ID: 1963
Path: /sys/fs/bpf/tc/globals/cilium_policy_01963

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3778     38        0        
Allow    Ingress     1          ANY          NONE         disabled    120767   1383      0        
Allow    Egress      0          ANY          NONE         disabled    17479    190       0        


Endpoint ID: 2244
Path: /sys/fs/bpf/tc/globals/cilium_policy_02244

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377039   4388      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2593
Path: /sys/fs/bpf/tc/globals/cilium_policy_02593

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2747
Path: /sys/fs/bpf/tc/globals/cilium_policy_02747

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3223
Path: /sys/fs/bpf/tc/globals/cilium_policy_03223

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6241530   77011     0        
Allow    Ingress     1          ANY          NONE         disabled    60972     738       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3336
Path: /sys/fs/bpf/tc/globals/cilium_policy_03336

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3439
Path: /sys/fs/bpf/tc/globals/cilium_policy_03439

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6094557   61192     0        
Allow    Ingress     1          ANY          NONE         disabled    5372002   56756     0        
Allow    Egress      0          ANY          NONE         disabled    6901651   68116     0        


Endpoint ID: 3718
Path: /sys/fs/bpf/tc/globals/cilium_policy_03718

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2118     22        0        
Allow    Ingress     1          ANY          NONE         disabled    122272   1402      0        
Allow    Egress      0          ANY          NONE         disabled    17825    196       0        


