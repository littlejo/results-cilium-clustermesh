IP ADDRESS         LOCAL ENDPOINT INFO
10.117.0.209:0     id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F   
172.31.255.207:0   (localhost)                                                                                        
10.117.0.122:0     id=3718  sec_id=7746594 flags=0x0000 ifindex=12  mac=B6:4E:D9:00:B5:F6 nodemac=32:A6:D7:47:28:8C   
10.117.0.69:0      id=1963  sec_id=7746594 flags=0x0000 ifindex=14  mac=0A:F4:7E:0A:4D:5A nodemac=D2:AE:EE:25:BD:E7   
10.117.0.125:0     id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D   
10.117.0.185:0     (localhost)                                                                                        
10.117.0.62:0      id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08   
172.31.202.9:0     (localhost)                                                                                        
10.117.0.217:0     id=3223  sec_id=4     flags=0x0000 ifindex=10  mac=E2:71:29:F9:23:BA nodemac=AE:4B:2F:05:95:44     
10.117.0.132:0     id=3439  sec_id=7790111 flags=0x0000 ifindex=18  mac=1A:38:5A:05:DE:4A nodemac=5E:30:26:3E:3A:01   
