xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 568
ens6(5) clsact/ingress cil_from_netdev-ens6 id 575
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 530
lxcc06e9ad2998d(12) clsact/ingress cil_from_container-lxcc06e9ad2998d id 544
lxc8f640a2d8f24(14) clsact/ingress cil_from_container-lxc8f640a2d8f24 id 504
lxced856720da64(18) clsact/ingress cil_from_container-lxced856720da64 id 620
lxcb13c93e809e3(20) clsact/ingress cil_from_container-lxcb13c93e809e3 id 3332
lxcc608c6fd051b(22) clsact/ingress cil_from_container-lxcc608c6fd051b id 3292
lxcf605b082a21a(24) clsact/ingress cil_from_container-lxcf605b082a21a id 3338

flow_dissector:

netfilter:

