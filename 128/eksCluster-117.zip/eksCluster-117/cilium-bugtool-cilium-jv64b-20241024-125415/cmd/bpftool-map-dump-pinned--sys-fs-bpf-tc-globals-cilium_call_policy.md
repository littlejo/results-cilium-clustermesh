key: ab 07 00 00  value: fb 01 00 00
key: c4 08 00 00  value: da 0c 00 00
key: 21 0a 00 00  value: 01 0d 00 00
key: 97 0c 00 00  value: 11 02 00 00
key: 08 0d 00 00  value: 11 0d 00 00
key: 6f 0d 00 00  value: 6f 02 00 00
key: 86 0e 00 00  value: 1f 02 00 00
Found 7 elements
