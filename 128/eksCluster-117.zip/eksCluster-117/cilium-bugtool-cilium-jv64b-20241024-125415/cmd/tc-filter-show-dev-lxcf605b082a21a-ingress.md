filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf605b082a21a direct-action not_in_hw id 3338 tag 9d42ec4441c4cf7b jited 
