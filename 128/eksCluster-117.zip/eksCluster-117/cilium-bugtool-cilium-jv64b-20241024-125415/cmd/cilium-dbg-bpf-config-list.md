KEY             VALUE
AgentLiveness   1882176073160
UTimeOffset     3378462119140625
