Node 0, zone      DMA    215     56     19     14      5      7      8      2      4      2     42 
Node 0, zone   Normal    286     31      9      7     19     12      2      2      2      3      7 
