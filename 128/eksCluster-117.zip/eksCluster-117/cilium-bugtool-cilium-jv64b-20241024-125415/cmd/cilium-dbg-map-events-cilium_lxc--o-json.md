{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.957Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.485Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.490Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.536Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.538Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.572Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.820Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.824Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.881Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.903Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.924Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.642Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.725Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.735Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.766Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.783Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.994Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.006Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.083Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.105Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.144Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.675Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.677Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.724Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.737Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.773Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.784Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.813Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.029Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.049Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.088Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.132Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.153Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.717Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.722Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.758Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.777Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.811Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.825Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.868Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.130Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.136Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.187Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.200Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.236Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.639Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.673Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.682Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.716Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.727Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.757Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.011Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.015Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.066Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.085Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.115Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.543Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.547Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.597Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.601Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.630Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.888Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.897Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.028Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.049Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.080Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.462Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.498Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.506Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.541Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.558Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.579Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.818Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.845Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.868Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.907Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.921Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.353Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.358Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.396Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.427Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.434Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.725Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.728Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.790Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.802Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.842Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.194Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.302Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.341Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.382Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.393Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.425Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.649Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.649Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.715Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.721Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.767Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.061Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.100Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.104Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.152Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.165Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.192Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.425Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.436Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.495Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.504Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.547Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.864Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.891Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.935Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.943Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.943Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.974Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.324Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.324Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.346Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.385Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.005Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.005Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.072Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.083Z",
  "value": "id=2244  sec_id=7748546 flags=0x0000 ifindex=22  mac=86:70:DB:97:73:62 nodemac=E2:23:BC:79:52:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.111Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.363Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.370Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.114Z",
  "value": "id=2593  sec_id=7763191 flags=0x0000 ifindex=20  mac=D2:32:D3:DC:AF:2A nodemac=E6:83:9B:35:EA:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.136Z",
  "value": "id=3336  sec_id=7793692 flags=0x0000 ifindex=24  mac=E6:A9:FF:9E:B6:94 nodemac=66:31:B5:A7:A0:08"
}

