 12:54:16 up 30 min,  0 users,  load average: 0.62, 0.67, 0.39
