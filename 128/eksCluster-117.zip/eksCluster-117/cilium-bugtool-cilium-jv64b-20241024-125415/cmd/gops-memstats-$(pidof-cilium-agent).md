alloc: 142.01MB (148908312 bytes)
total-alloc: 3.07GB (3293983824 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74887497
frees: 73407797
heap-alloc: 142.01MB (148908312 bytes)
heap-sys: 170.48MB (178765824 bytes)
heap-idle: 12.52MB (13131776 bytes)
heap-in-use: 157.96MB (165634048 bytes)
heap-released: 6.69MB (7012352 bytes)
heap-objects: 1479700
stack-in-use: 37.28MB (39092224 bytes)
stack-sys: 37.28MB (39092224 bytes)
stack-mspan-inuse: 2.47MB (2591840 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1001.84KB (1025881 bytes)
gc-sys: 5.71MB (5987400 bytes)
next-gc: when heap-alloc >= 146.83MB (153966648 bytes)
last-gc: 2024-10-24 12:54:07.732149303 +0000 UTC
gc-pause-total: 13.73447ms
gc-pause: 86752
gc-pause-end: 1729774447732149303
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0007389656523061297
enable-gc: true
debug-gc: false
