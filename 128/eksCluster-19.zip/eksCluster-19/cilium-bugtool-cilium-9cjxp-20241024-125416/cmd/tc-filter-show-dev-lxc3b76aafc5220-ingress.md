filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3b76aafc5220 direct-action not_in_hw id 3302 tag e18bc4ee7e6d8740 jited 
