{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.705Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.412Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.420Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.454Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.482Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.504Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.522Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.768Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.769Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.824Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.874Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.881Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.457Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.544Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.572Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.603Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.610Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.784Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.790Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.826Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.858Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.876Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.471Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.500Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.530Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.548Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.576Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.579Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.827Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.830Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.904Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.904Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.945Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.507Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.514Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.543Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.553Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.591Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.616Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.628Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.932Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.933Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.996Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.019Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.044Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.419Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.427Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.480Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.484Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.514Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.729Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.730Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.782Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.783Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.832Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.257Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.257Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.303Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.312Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.343Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.543Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.571Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.700Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.711Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.754Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.106Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.143Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.147Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.185Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.209Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.232Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.455Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.460Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.525Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.527Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.565Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.961Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.966Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.014Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.031Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.068Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.301Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.309Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.359Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.404Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.414Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.844Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.878Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.889Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.924Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.949Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.963Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.214Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.232Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.282Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.295Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.326Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.646Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.649Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.686Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.689Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.736Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.740Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.008Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.023Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.067Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.079Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.115Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.429Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.524Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.525Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.584Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.589Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.617Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.841Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.846Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.877Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.881Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.884Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.614Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.618Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.653Z",
  "value": "id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.679Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.695Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.935Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.942Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.652Z",
  "value": "id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.657Z",
  "value": "id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29"
}

