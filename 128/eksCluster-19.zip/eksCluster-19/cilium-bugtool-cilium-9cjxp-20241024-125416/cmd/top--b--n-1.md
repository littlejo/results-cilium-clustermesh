top - 12:54:17 up 33 min,  0 users,  load average: 1.37, 0.61, 0.30
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 29.0 us, 35.5 sy,  0.0 ni, 32.3 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   3836.2 total,    286.2 free,   1051.7 used,   2498.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2603.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 293816  79096 S  26.7   7.5   1:01.55 cilium-+
    413 root      20   0 1229744  10076   3836 S   0.0   0.3   0:03.86 cilium-+
   3303 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3308 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3313 root      20   0 1240432  16096  10640 S   0.0   0.4   0:00.03 cilium-+
   3346 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3365 root      20   0 1229000   3968   3292 S   0.0   0.1   0:00.00 gops
   3371 root      20   0 1615752   8392   6316 S   0.0   0.2   0:00.00 runc:[2+
