CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6b92514_9b95_42a9_8bdf_6fc6cd13d168.slice/cri-containerd-f235c438d29d704ddbceb61fce65bb52dfc57b7ea2eeafe69830ce1eed5d8e14.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6b92514_9b95_42a9_8bdf_6fc6cd13d168.slice/cri-containerd-d5277ea2af1f91ac437c909e562426d00e955f78e7a6126bcd1f2f099d094c8e.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd055cd59_4d07_43d7_9de6_6373c711a09a.slice/cri-containerd-e0f9ce1b6508c897771a214c5884e93396d3ab52c292da6ec28ea8083f2a4792.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd055cd59_4d07_43d7_9de6_6373c711a09a.slice/cri-containerd-9494dec807bd4cf2b41dfac9678bbeaceb6ae26857bae27b09985c2f7851fa6d.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod513e493b_2135_415b_bed5_0162d7650a29.slice/cri-containerd-1a8b2f0ea7eced2d67bf98e0c4a851bed2826a637a986c1b36b8ce7be57b9d14.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod513e493b_2135_415b_bed5_0162d7650a29.slice/cri-containerd-907ed73b712a241ba4699b3423ea476c4f46a9ffc319fb44ac1e18eb58c6045d.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb321120f_768c_4c52_a500_34e70fa72491.slice/cri-containerd-269b2168442563c530f9d28ab86762d1d539cdf4d4fa7d002c49223815bc1353.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb321120f_768c_4c52_a500_34e70fa72491.slice/cri-containerd-7f4cd462f87136c35d87b9c1e145bcac6684381f7c20c245de0fa749f8ef5e56.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b93c93a_3ff2_4a3f_9cef_7f5d9fe8cc5c.slice/cri-containerd-56e64d71d44d81cd9d917bc5de78776f1d6bbe32293e5b2799ad00114d7a5632.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b93c93a_3ff2_4a3f_9cef_7f5d9fe8cc5c.slice/cri-containerd-42584abf323d51e6c93f9acdece4a30e1f1ed7b937263635e99f84b1f45a47fc.scope
    676      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b93c93a_3ff2_4a3f_9cef_7f5d9fe8cc5c.slice/cri-containerd-716db7d52c687cfb7811a8a8051f54e55510845f570f2744dad906f645f4db43.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36fa8cc6_d7ff_4878_b62c_e4237897dda5.slice/cri-containerd-beacde5db4c78d6d6db15cbe02df01b508d004546a5b065110805f7f71fd1370.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36fa8cc6_d7ff_4878_b62c_e4237897dda5.slice/cri-containerd-2bf0f97f7f6e9a327b8809af9dfa182ab23538957839c61abe1847b76ac3a98a.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7450b5a_7cc1_445a_8662_67a5845e0a02.slice/cri-containerd-42968ee36e1d8dbf4ea1729b76d199966bbade3c5f99aa223bda16d85ae83674.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7450b5a_7cc1_445a_8662_67a5845e0a02.slice/cri-containerd-34eefd3ae1dde932e114570de1eca0afbea0c5e51304c8ea5497b59d21b063cc.scope
    680      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3272a16b_a89a_47c2_a742_3bdd19f72fc4.slice/cri-containerd-cdc1d88591679cde50eb1dcd817656f1413e5dad2a35b7f2fbb32621907ba848.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3272a16b_a89a_47c2_a742_3bdd19f72fc4.slice/cri-containerd-30d9555be2a11128424b18b026b77328059a32d367b7de0ec82fc722c38d3dbf.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3272a16b_a89a_47c2_a742_3bdd19f72fc4.slice/cri-containerd-f0f18ebfe6d5a0e942561fb8c72e730b510095f404bd346a6772b0858c112975.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3272a16b_a89a_47c2_a742_3bdd19f72fc4.slice/cri-containerd-306b77d2c71d65171f47482f58187ef38d3ac650e43dce3f117df87f306b4010.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda32631e8_a9f4_4b12_a1ec_9275f64d36d6.slice/cri-containerd-1f7dd428a523eec92ddaf619b91c8f1177685030f23fd4ff72601b3dd0b28510.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda32631e8_a9f4_4b12_a1ec_9275f64d36d6.slice/cri-containerd-4413d4927c42193339145769f20dbcd4b40d5d77b5a004aeef36d482b71e1f99.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod42aa9c44_48de_4fd3_9aeb_ca1e66dbe61d.slice/cri-containerd-7620c070a2dcc56c15641dfee0510cfac7712dba8183f81b0a7bf70cd0b9abd2.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod42aa9c44_48de_4fd3_9aeb_ca1e66dbe61d.slice/cri-containerd-1d5f9058c5f0ad1732c8c1ec3125340f05e204594f4f18e25e9ac76c6d5cd723.scope
    102      cgroup_device   multi                                          
