USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3313  0.0  0.4 1240432 15888 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3334  0.0  0.4 1240432 15888 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3335  0.0  0.0   6408  1640 ?        R    12:54   0:00  \_ ps auxfw
root        3308  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3303  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3285  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3266  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  3.6  7.4 1539060 293168 ?      Ssl  12:25   1:01 cilium-agent --config-dir=/tmp/cilium/config-map
root         413  0.2  0.2 1229744 10076 ?       Sl   12:26   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
