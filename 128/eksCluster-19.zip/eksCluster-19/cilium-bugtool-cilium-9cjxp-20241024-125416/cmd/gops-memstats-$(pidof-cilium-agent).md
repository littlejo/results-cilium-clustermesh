alloc: 123.36MB (129352256 bytes)
total-alloc: 3.14GB (3368758912 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75814303
frees: 74570839
heap-alloc: 123.36MB (129352256 bytes)
heap-sys: 176.64MB (185221120 bytes)
heap-idle: 29.73MB (31178752 bytes)
heap-in-use: 146.91MB (154042368 bytes)
heap-released: 9.43MB (9887744 bytes)
heap-objects: 1243464
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.34MB (2451520 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 954.17KB (977073 bytes)
gc-sys: 5.53MB (5801080 bytes)
next-gc: when heap-alloc >= 159.67MB (167423096 bytes)
last-gc: 2024-10-24 12:54:17.469349208 +0000 UTC
gc-pause-total: 12.006824ms
gc-pause: 156712
gc-pause-end: 1729774457469349208
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.0005873668743299274
enable-gc: true
debug-gc: false
