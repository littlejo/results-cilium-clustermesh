Node 0, zone      DMA    129     88     27     12      3      7      5      2      3      3     40 
Node 0, zone   Normal     70     58     11     22     12      5      4      0      0      1      9 
