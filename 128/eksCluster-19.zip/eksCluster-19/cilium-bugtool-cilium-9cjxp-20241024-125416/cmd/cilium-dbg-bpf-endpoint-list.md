IP ADDRESS         LOCAL ENDPOINT INFO
10.19.0.104:0      (localhost)                                                                                        
10.19.0.17:0       id=3327  sec_id=1311089 flags=0x0000 ifindex=18  mac=C6:7A:5B:DE:9A:32 nodemac=86:F4:B0:C1:35:6E   
10.19.0.229:0      id=2688  sec_id=1345149 flags=0x0000 ifindex=20  mac=22:15:2C:2E:F9:AA nodemac=B6:F1:35:FF:B6:1F   
10.19.0.116:0      id=2696  sec_id=1334869 flags=0x0000 ifindex=24  mac=26:C3:17:68:C8:21 nodemac=76:7A:B9:CF:68:29   
10.19.0.65:0       id=115   sec_id=1358356 flags=0x0000 ifindex=14  mac=92:E3:34:C7:DF:27 nodemac=66:8E:E2:F4:91:05   
10.19.0.214:0      id=446   sec_id=1358356 flags=0x0000 ifindex=12  mac=52:DB:75:D2:37:AA nodemac=22:14:F4:2B:32:E9   
172.31.197.143:0   (localhost)                                                                                        
10.19.0.232:0      id=2309  sec_id=1337149 flags=0x0000 ifindex=22  mac=BE:4F:C4:E8:1D:B1 nodemac=6A:8A:46:78:00:C0   
172.31.214.60:0    (localhost)                                                                                        
10.19.0.176:0      id=1701  sec_id=4     flags=0x0000 ifindex=10  mac=9E:BC:EE:1E:A8:12 nodemac=42:90:E9:C0:1D:91     
