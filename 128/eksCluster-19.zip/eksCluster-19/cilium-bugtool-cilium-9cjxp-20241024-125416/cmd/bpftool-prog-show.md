32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:04+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag a89536940f3acd3e  gpl
	loaded_at 2024-10-24T12:26:04+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:26:04+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
483: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:26:04+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:26:04+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
486: sched_cls  name tail_handle_ipv4_from_host  tag 7776accde364fbc0  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 130
487: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 131
489: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 133
490: sched_cls  name __send_drop_notify  tag a030ed500e072dc8  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 134
491: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,101
	btf_id 135
492: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 137
494: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 139
495: sched_cls  name __send_drop_notify  tag a030ed500e072dc8  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 140
498: sched_cls  name tail_handle_ipv4_from_host  tag 7776accde364fbc0  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 143
500: sched_cls  name __send_drop_notify  tag a030ed500e072dc8  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 146
503: sched_cls  name tail_handle_ipv4_from_host  tag 7776accde364fbc0  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 149
504: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 150
505: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 151
506: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 153
508: sched_cls  name __send_drop_notify  tag a030ed500e072dc8  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 155
511: sched_cls  name tail_handle_ipv4_from_host  tag 7776accde364fbc0  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 158
512: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 159
514: sched_cls  name tail_ipv4_ct_ingress  tag 1aa024c86c48e783  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 163
519: sched_cls  name handle_policy  tag b0af43a82e584db6  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 166
521: sched_cls  name __send_drop_notify  tag 46af84f000e8e7d8  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
523: sched_cls  name tail_handle_ipv4_cont  tag d9ec1885dc34c982  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 172
524: sched_cls  name cil_from_container  tag 8e49d5ac38c55099  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 174
525: sched_cls  name tail_handle_arp  tag 06bdcdf64210f3a6  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 175
526: sched_cls  name tail_ipv4_ct_egress  tag dd465e7afa2d31d1  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 176
527: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 177
531: sched_cls  name tail_handle_ipv4  tag 354a177c8f0ebd2e  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 178
534: sched_cls  name tail_ipv4_to_endpoint  tag aaa4ed4af9cc27dc  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 182
535: sched_cls  name tail_ipv4_to_endpoint  tag e6d7bf71577928dd  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 185
536: sched_cls  name tail_handle_ipv4  tag f12e649a8a307378  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 187
537: sched_cls  name tail_ipv4_to_endpoint  tag ab0f38baaa75eaca  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 188
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 190
539: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 191
540: sched_cls  name tail_ipv4_ct_egress  tag dd465e7afa2d31d1  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 189
541: sched_cls  name cil_from_container  tag 77db3d0c3d305fd1  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 193
543: sched_cls  name tail_handle_ipv4_cont  tag a056ddadc9377a2d  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 192
544: sched_cls  name tail_handle_arp  tag ca669c5d13a197f5  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 196
545: sched_cls  name tail_ipv4_ct_ingress  tag 2126be5e1a2cff8d  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 195
546: sched_cls  name tail_handle_ipv4_cont  tag 6fb15132f9fd9036  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 197
547: sched_cls  name cil_from_container  tag cac06564372a60b1  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 198
548: sched_cls  name __send_drop_notify  tag 258a7197cca03e23  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
549: sched_cls  name tail_handle_arp  tag 6b2bf56c91b97a86  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 201
550: sched_cls  name tail_ipv4_ct_ingress  tag 0fab62e990dc93a3  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 200
551: sched_cls  name __send_drop_notify  tag e4e28cd0f027c79b  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
552: sched_cls  name tail_handle_ipv4  tag ae8032018a2fac10  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 204
553: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 205
554: sched_cls  name handle_policy  tag 13c012c84f5b7e3b  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 202
555: sched_cls  name handle_policy  tag 5df02f721611cc87  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 206
557: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
560: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
561: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
564: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
565: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
612: sched_cls  name tail_ipv4_ct_egress  tag 8deab99b7fdc1578  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 221
613: sched_cls  name tail_handle_ipv4_cont  tag fad7eff7070e1a30  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 222
614: sched_cls  name cil_from_container  tag 254fe9be15e7c73b  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 223
615: sched_cls  name handle_policy  tag 446ef27d0c5c77b9  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 224
616: sched_cls  name __send_drop_notify  tag 8386e25b2f42d008  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 225
617: sched_cls  name tail_handle_arp  tag 217070ee6225810e  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 226
618: sched_cls  name tail_handle_ipv4  tag e36233acfe7d98cd  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 227
619: sched_cls  name tail_ipv4_ct_ingress  tag 32fde353fc52448d  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 228
620: sched_cls  name tail_ipv4_to_endpoint  tag 5c21a6b6983352d9  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 229
621: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 230
623: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
626: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
639: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
642: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
646: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
673: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
676: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
677: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
680: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
692: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
695: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
696: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
699: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
700: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
703: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3297: sched_cls  name tail_handle_arp  tag 25950180ea502d9d  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,629
	btf_id 3089
3299: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,629
	btf_id 3091
3301: sched_cls  name tail_ipv4_ct_ingress  tag 67407a30f87a9559  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,629,82,83,630,84
	btf_id 3092
3302: sched_cls  name cil_from_container  tag e18bc4ee7e6d8740  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 629,76
	btf_id 3096
3305: sched_cls  name handle_policy  tag 082f654c85adf370  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,629,82,83,630,41,80,143,39,84,75,40,37,38
	btf_id 3097
3308: sched_cls  name tail_ipv4_to_endpoint  tag 5ac859b23cf2a654  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,630,41,82,83,80,143,39,629,40,37,38
	btf_id 3100
3309: sched_cls  name tail_handle_ipv4_cont  tag 9585c94efdce4e3f  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,630,41,143,82,83,39,76,74,77,629,40,37,38,81
	btf_id 3103
3310: sched_cls  name tail_handle_ipv4  tag 04081efc12973f4d  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,629
	btf_id 3104
3311: sched_cls  name tail_ipv4_ct_egress  tag 2fe854dffb43efc1  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,629,82,83,630,84
	btf_id 3105
3312: sched_cls  name __send_drop_notify  tag edbf1bef86c7df46  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3106
3352: sched_cls  name cil_from_container  tag 68815c45ed1a23b8  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3149
3353: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3152
3354: sched_cls  name tail_handle_arp  tag d37bc1b177597e87  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3153
3355: sched_cls  name tail_ipv4_ct_ingress  tag 5990affccc0a1a0d  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3154
3356: sched_cls  name tail_handle_ipv4  tag 325cfd2eb096b3f3  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,642
	btf_id 3151
3357: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,642
	btf_id 3156
3358: sched_cls  name tail_handle_ipv4  tag 0eec0ee1c3894ed7  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3155
3359: sched_cls  name handle_policy  tag 4926a472cc438187  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,642,82,83,641,41,80,146,39,84,75,40,37,38
	btf_id 3157
3360: sched_cls  name cil_from_container  tag 9804f663189897b2  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 642,76
	btf_id 3159
3361: sched_cls  name handle_policy  tag c17e8a815d593ad4  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,151,39,84,75,40,37,38
	btf_id 3158
3362: sched_cls  name tail_ipv4_ct_ingress  tag 527a1f42d70867f0  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3160
3363: sched_cls  name __send_drop_notify  tag 613ec19b36756853  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3161
3364: sched_cls  name tail_handle_arp  tag 66c76d170971cdd6  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,642
	btf_id 3162
3366: sched_cls  name tail_handle_ipv4_cont  tag 712b08c498c361b2  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,641,41,146,82,83,39,76,74,77,642,40,37,38,81
	btf_id 3165
3367: sched_cls  name tail_handle_ipv4_cont  tag 2471200268b17c9e  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,151,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3163
3368: sched_cls  name tail_ipv4_to_endpoint  tag 56c4ec28b6fefc5f  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,641,41,82,83,80,146,39,642,40,37,38
	btf_id 3166
3369: sched_cls  name tail_ipv4_ct_egress  tag 17308118cb7ebd5c  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3168
3370: sched_cls  name __send_drop_notify  tag 51e4b7f4919ef822  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3169
3371: sched_cls  name tail_ipv4_to_endpoint  tag d194d0e20c372c5d  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,151,39,639,40,37,38
	btf_id 3167
3372: sched_cls  name tail_ipv4_ct_egress  tag 27e364de5bdeeace  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3170
