1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:8f:10:3a:51:97 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.214.60/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3410sec preferred_lft 3410sec
    inet6 fe80::88f:10ff:fe3a:5197/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:89:ab:b9:00:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.197.143/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::889:abff:feb9:67/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:71:f5:1f:33:f6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a471:f5ff:fe1f:33f6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:48:3c:8a:7a:8f brd ff:ff:ff:ff:ff:ff
    inet 10.19.0.104/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5048:3cff:fe8a:7a8f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:04:b7:8e:e5:88 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6804:b7ff:fe8e:e588/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:90:e9:c0:1d:91 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4090:e9ff:fec0:1d91/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc95a3a34fc455@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:14:f4:2b:32:e9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2014:f4ff:fe2b:32e9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc162aa4c6a848@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:8e:e2:f4:91:05 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::648e:e2ff:fef4:9105/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3ae8506abe3c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:f4:b0:c1:35:6e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::84f4:b0ff:fec1:356e/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc3b76aafc5220@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:f1:35:ff:b6:1f brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::b4f1:35ff:feff:b61f/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcabc875a1eb2b@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:8a:46:78:00:c0 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::688a:46ff:fe78:c0/64 scope link 
       valid_lft forever preferred_lft forever
24: lxca7742c262a30@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:7a:b9:cf:68:29 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::747a:b9ff:fecf:6829/64 scope link 
       valid_lft forever preferred_lft forever
