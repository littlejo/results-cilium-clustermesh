 12:54:17 up 33 min,  0 users,  load average: 0.36, 0.40, 0.23
