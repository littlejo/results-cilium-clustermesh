Total: 556
TCP:   4662 (estab 299, closed 4344, orphaned 0, timewait 3889)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  318       307       11       
INET	  328       313       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:35937      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:29834 sk:12d fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.214.60%ens5:68         0.0.0.0:*    uid:192 ino:88942 sk:12e cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:29362 sk:12f cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15606 sk:130 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:29361 sk:131 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15607 sk:132 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::88f:10ff:fe3a:5197]%ens5:546           [::]:*    uid:192 ino:15742 sk:133 cgroup:unreachable:bd0 v6only:1 <->                   
