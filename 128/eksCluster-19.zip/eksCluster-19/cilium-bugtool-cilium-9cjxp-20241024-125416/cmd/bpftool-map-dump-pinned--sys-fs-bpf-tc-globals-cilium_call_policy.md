key: 73 00 00 00  value: 2b 02 00 00
key: be 01 00 00  value: 07 02 00 00
key: a5 06 00 00  value: 2a 02 00 00
key: 05 09 00 00  value: 1f 0d 00 00
key: 80 0a 00 00  value: e9 0c 00 00
key: 88 0a 00 00  value: 21 0d 00 00
key: ff 0c 00 00  value: 67 02 00 00
Found 7 elements
