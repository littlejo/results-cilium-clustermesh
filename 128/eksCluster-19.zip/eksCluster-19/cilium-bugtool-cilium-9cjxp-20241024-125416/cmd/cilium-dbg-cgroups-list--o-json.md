[
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6b92514_9b95_42a9_8bdf_6fc6cd13d168.slice/cri-containerd-f235c438d29d704ddbceb61fce65bb52dfc57b7ea2eeafe69830ce1eed5d8e14.scope"
      }
    ],
    "ips": [
      "10.19.0.214"
    ],
    "name": "coredns-cc6ccd49c-slps6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7450b5a_7cc1_445a_8662_67a5845e0a02.slice/cri-containerd-42968ee36e1d8dbf4ea1729b76d199966bbade3c5f99aa223bda16d85ae83674.scope"
      }
    ],
    "ips": [
      "10.19.0.232"
    ],
    "name": "client-974f6c69d-tkpfw",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda32631e8_a9f4_4b12_a1ec_9275f64d36d6.slice/cri-containerd-4413d4927c42193339145769f20dbcd4b40d5d77b5a004aeef36d482b71e1f99.scope"
      }
    ],
    "ips": [
      "10.19.0.116"
    ],
    "name": "client2-57cf4468f-dmn7q",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3272a16b_a89a_47c2_a742_3bdd19f72fc4.slice/cri-containerd-f0f18ebfe6d5a0e942561fb8c72e730b510095f404bd346a6772b0858c112975.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3272a16b_a89a_47c2_a742_3bdd19f72fc4.slice/cri-containerd-30d9555be2a11128424b18b026b77328059a32d367b7de0ec82fc722c38d3dbf.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3272a16b_a89a_47c2_a742_3bdd19f72fc4.slice/cri-containerd-306b77d2c71d65171f47482f58187ef38d3ac650e43dce3f117df87f306b4010.scope"
      }
    ],
    "ips": [
      "10.19.0.17"
    ],
    "name": "clustermesh-apiserver-7f8b8598dd-dv5w6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b93c93a_3ff2_4a3f_9cef_7f5d9fe8cc5c.slice/cri-containerd-56e64d71d44d81cd9d917bc5de78776f1d6bbe32293e5b2799ad00114d7a5632.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b93c93a_3ff2_4a3f_9cef_7f5d9fe8cc5c.slice/cri-containerd-716db7d52c687cfb7811a8a8051f54e55510845f570f2744dad906f645f4db43.scope"
      }
    ],
    "ips": [
      "10.19.0.229"
    ],
    "name": "echo-same-node-86d9cc975c-bbvml",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb321120f_768c_4c52_a500_34e70fa72491.slice/cri-containerd-269b2168442563c530f9d28ab86762d1d539cdf4d4fa7d002c49223815bc1353.scope"
      }
    ],
    "ips": [
      "10.19.0.65"
    ],
    "name": "coredns-cc6ccd49c-kq2ww",
    "namespace": "kube-system"
  }
]

