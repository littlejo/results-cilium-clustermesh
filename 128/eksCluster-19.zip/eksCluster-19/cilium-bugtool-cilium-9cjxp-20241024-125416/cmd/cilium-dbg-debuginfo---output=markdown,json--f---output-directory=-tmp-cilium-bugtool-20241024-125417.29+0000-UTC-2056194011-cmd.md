markdown output at /tmp/cilium-bugtool-20241024-125417.29+0000-UTC-2056194011/cmd/cilium-debuginfo-20241024-125448.16+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.29+0000-UTC-2056194011/cmd/cilium-debuginfo-20241024-125448.16+0000-UTC.json
