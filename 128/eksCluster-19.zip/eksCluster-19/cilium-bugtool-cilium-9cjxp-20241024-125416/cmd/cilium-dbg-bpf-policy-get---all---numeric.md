Endpoint ID: 6
Path: /sys/fs/bpf/tc/globals/cilium_policy_00006

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 115
Path: /sys/fs/bpf/tc/globals/cilium_policy_00115

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3182     33        0        
Allow    Ingress     1          ANY          NONE         disabled    165022   1902      0        
Allow    Egress      0          ANY          NONE         disabled    20873    234       0        


Endpoint ID: 446
Path: /sys/fs/bpf/tc/globals/cilium_policy_00446

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2714     27        0        
Allow    Ingress     1          ANY          NONE         disabled    165097   1898      0        
Allow    Egress      0          ANY          NONE         disabled    21267    240       0        


Endpoint ID: 1701
Path: /sys/fs/bpf/tc/globals/cilium_policy_01701

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6223624   76921     0        
Allow    Ingress     1          ANY          NONE         disabled    68262     822       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2309
Path: /sys/fs/bpf/tc/globals/cilium_policy_02309

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2688
Path: /sys/fs/bpf/tc/globals/cilium_policy_02688

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377004   4392      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2696
Path: /sys/fs/bpf/tc/globals/cilium_policy_02696

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3327
Path: /sys/fs/bpf/tc/globals/cilium_policy_03327

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6086322   61000     0        
Allow    Ingress     1          ANY          NONE         disabled    5245470   55387     0        
Allow    Egress      0          ANY          NONE         disabled    6736520   66633     0        


