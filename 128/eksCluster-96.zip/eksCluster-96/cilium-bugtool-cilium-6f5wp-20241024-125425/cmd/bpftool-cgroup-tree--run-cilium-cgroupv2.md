CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3fce24ab_4ca8_4c6d_a10f_0b623b136d3e.slice/cri-containerd-e88ac28e8023ffb4aa79b1f868205261f6a921121b090d50a2c77d4816b998aa.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3fce24ab_4ca8_4c6d_a10f_0b623b136d3e.slice/cri-containerd-9b790f643dff636918ed453ca8a6a9e2f6a28a1aa217e2462b0b7b37c10422aa.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5a8c32a_341d_4554_89c3_80fcd926fb21.slice/cri-containerd-da62d980c986ee0450d552c287456e40b5113247df1f57b7b2562fe3b3ed6202.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5a8c32a_341d_4554_89c3_80fcd926fb21.slice/cri-containerd-29863b658fcb010d5b4e649a935c6f2c714e69ec4b098bc20f7ec0df28393c41.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd739d92f_bba2_4533_8767_cb29db928b28.slice/cri-containerd-5a8a8178b690df4ce223ed13009a08a53d455a46e5804fcb1b55975924045d56.scope
    566      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd739d92f_bba2_4533_8767_cb29db928b28.slice/cri-containerd-ab2d9131fe0bc068f23d0a0d01197d918d45e369ddefd87e05dd7f2b6820cbfe.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5538bd41_9553_4a09_ada2_658eb80a3683.slice/cri-containerd-11fca3b66c3ff3e28f145fed738b125e397ff55cab56cccf01ddc4dc99ecf372.scope
    495      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5538bd41_9553_4a09_ada2_658eb80a3683.slice/cri-containerd-2ac3c4f8442f249ff2dc28b807eb9942b1fe2417f88498659d903f8396ef2daf.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa35f6aa_3559_427e_a5ca_e9417a289a6d.slice/cri-containerd-62ceeb4a28ec5d89a11d6dad80b96ec17657ab4ce909f45429eaf3517e7a91bb.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa35f6aa_3559_427e_a5ca_e9417a289a6d.slice/cri-containerd-3158eb8804dd742b13d555763a488ac569cb16580097999cf02a2b09db87057b.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa35f6aa_3559_427e_a5ca_e9417a289a6d.slice/cri-containerd-5faf5c68a1ef96e61f0c057222164b8ca936397745a61587a11d28c0aa1d67f7.scope
    648      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa35f6aa_3559_427e_a5ca_e9417a289a6d.slice/cri-containerd-e6c2b2d15dd650ab4417fdfdd6a39989cc5937ee0491eb2fccd8804bebdbbac8.scope
    672      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e38c784_4419_4966_a31b_2b28610f7ce4.slice/cri-containerd-944b7a5ed4b1121922eeec8aef0bc67431d846f8b925d1ad509fb75c587df5b8.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e38c784_4419_4966_a31b_2b28610f7ce4.slice/cri-containerd-0529d833ef4f80e86d107723e727e2f5813c2a97896197edb84a3e0ae6864ec4.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22428d83_cf2c_473f_97c6_c13e5ab01887.slice/cri-containerd-c3d1bf1ed5f508295696a286b4da4bfbba3b9cc151b26125690547341c4ba6f7.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22428d83_cf2c_473f_97c6_c13e5ab01887.slice/cri-containerd-7ef4f4c0b4abd958b8bb7616acc3b06a4be03e3d6d48b2378503ca9c06e9c964.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca478a55_f4dc_4bff_a277_2c0b7216b3a1.slice/cri-containerd-1a71fd128cbe4322207eaf82c952ba5cc728e6a28e7b1f46f001ef222f4a58c0.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca478a55_f4dc_4bff_a277_2c0b7216b3a1.slice/cri-containerd-a93b570c1020ce91367ab7a85901971bf00b717128680b930285d03ea8ba5272.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf692b842_4ac5_4b61_a078_0236ba77333d.slice/cri-containerd-c25aa2e10b52ad945c9cd52109cee27440584b89520185648ee0282770e048fb.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf692b842_4ac5_4b61_a078_0236ba77333d.slice/cri-containerd-2f81c63c94a6f5e94c5d2a2ebb7190021d769856c1f0ea3721718c3b56ed96e7.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3b12435_18b9_408c_aa83_2b1fa534c984.slice/cri-containerd-a69d06e9d9136624ded9dc433b19478d1880d53daf35e4801ff58c61bdfcd25b.scope
    733      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3b12435_18b9_408c_aa83_2b1fa534c984.slice/cri-containerd-c08f75603c7259146d857cbd037b20e43ef68a4c6123203bc06855ca95ee16ef.scope
    729      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3b12435_18b9_408c_aa83_2b1fa534c984.slice/cri-containerd-21a096cb438a8e77b6f7613ef285a5107b73bef8076f2b7947005acf5d0bb3ba.scope
    698      cgroup_device   multi                                          
