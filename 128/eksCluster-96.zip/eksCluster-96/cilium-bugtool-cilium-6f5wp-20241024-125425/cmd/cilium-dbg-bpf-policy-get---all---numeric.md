Endpoint ID: 540
Path: /sys/fs/bpf/tc/globals/cilium_policy_00540

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6218431   76976     0        
Allow    Ingress     1          ANY          NONE         disabled    64327     782       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 579
Path: /sys/fs/bpf/tc/globals/cilium_policy_00579

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    205701   1857      0        
Allow    Ingress     1          ANY          NONE         disabled    134184   1540      0        
Allow    Egress      0          ANY          NONE         disabled    64105    631       0        


Endpoint ID: 701
Path: /sys/fs/bpf/tc/globals/cilium_policy_00701

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    204561   1847      0        
Allow    Ingress     1          ANY          NONE         disabled    134303   1546      0        
Allow    Egress      0          ANY          NONE         disabled    63015    617       0        


Endpoint ID: 1638
Path: /sys/fs/bpf/tc/globals/cilium_policy_01638

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1871
Path: /sys/fs/bpf/tc/globals/cilium_policy_01871

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    1488    18        0        


Endpoint ID: 2591
Path: /sys/fs/bpf/tc/globals/cilium_policy_02591

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6157077   61553     0        
Allow    Ingress     1          ANY          NONE         disabled    5300301   55831     0        
Allow    Egress      0          ANY          NONE         disabled    6500208   64666     0        


Endpoint ID: 2820
Path: /sys/fs/bpf/tc/globals/cilium_policy_02820

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    381293   4463      0        
Allow    Ingress     67909      8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     183315     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     256993     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     317813     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     358785     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     401207     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     483566     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     540191     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     600811     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     671800     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     731723     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     840783     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     882868     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     965807     8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1002458    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1074394    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1129712    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1210707    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1251559    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1334869    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1380324    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1483778    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1529146    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1594930    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1673992    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1751814    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1807419    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1846590    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1931818    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     1993353    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2051297    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2126466    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2164791    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2254611    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2303026    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2392726    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2465861    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2552834    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2562520    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2636403    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2723172    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2782436    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2819786    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2908380    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     2953912    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3039129    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3137585    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3182032    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3235721    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3284969    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3359695    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3409958    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3475753    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3542655    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3614473    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3676488    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3765653    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3815889    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3887242    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     3996401    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4027136    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4084097    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4141303    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4211496    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4303089    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4373777    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4394637    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4466109    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4574229    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4603413    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4690407    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4724289    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4784981    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4865964    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     4954411    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5026816    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5054456    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5118000    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5238546    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5251565    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5359114    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5410215    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5455655    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5568487    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5609800    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5652749    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5753031    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5770648    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5859069    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     5918486    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6017915    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6072151    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6123850    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6170583    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6232096    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6345479    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6395033    8080/TCP     19093        disabled    1488     18        24       
Allow    Ingress     6422852    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6493899    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6590228    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6644563    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6704587    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6791911    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6857970    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     6889673    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7004635    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7042127    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7107118    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7204632    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7259365    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7308813    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7379131    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7420801    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7482056    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7554089    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7635488    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7704195    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7793692    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7805443    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7889830    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     7930117    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     8015803    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     8080382    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     8135441    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     8244869    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     8278356    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     8325387    8080/TCP     19093        disabled    0        0         24       
Allow    Ingress     8436013    8080/TCP     19093        disabled    0        0         24       
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3011
Path: /sys/fs/bpf/tc/globals/cilium_policy_03011

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    296     4         0        


