top - 12:54:26 up 31 min,  0 users,  load average: 0.60, 0.52, 0.31
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 32.1 us, 35.7 sy,  0.0 ni, 32.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    289.1 free,   1050.0 used,   2497.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2605.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 293464  78652 S  40.0   7.5   1:04.15 cilium-+
    400 root      20   0 1229744   9044   2924 S   0.0   0.2   0:04.37 cilium-+
   3285 root      20   0 1240432  15928  10640 S   0.0   0.4   0:00.02 cilium-+
   3300 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3302 root      20   0 1228744   3980   3328 S   0.0   0.1   0:00.00 gops
   3303 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3324 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3351 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
   3370 root      20   0 1228744   3712   3040 S   0.0   0.1   0:00.00 gops
