filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcabb022f8a474 direct-action not_in_hw id 537 tag bd1d8adb51e66832 jited 
