xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 582
ens6(5) clsact/ingress cil_from_netdev-ens6 id 589
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 576
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 569
cilium_host(7) clsact/egress cil_from_host-cilium_host id 567
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 501
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 502
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 561
lxce25322578c60(12) clsact/ingress cil_from_container-lxce25322578c60 id 529
lxcabb022f8a474(14) clsact/ingress cil_from_container-lxcabb022f8a474 id 537
lxc3f0e3e3e4f76(18) clsact/ingress cil_from_container-lxc3f0e3e3e4f76 id 642
lxc098e2b61383b(20) clsact/ingress cil_from_container-lxc098e2b61383b id 3373
lxc6de251dc5c17(22) clsact/ingress cil_from_container-lxc6de251dc5c17 id 3346
lxc75e1fe1f323b(24) clsact/ingress cil_from_container-lxc75e1fe1f323b id 3341

flow_dissector:

netfilter:

