IP ADDRESS         LOCAL ENDPOINT INFO
10.96.0.21:0       id=701   sec_id=6417690 flags=0x0000 ifindex=14  mac=4A:1B:01:44:E5:BE nodemac=EA:01:3C:00:6D:A7   
10.96.0.60:0       (localhost)                                                                                        
10.96.0.28:0       id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58   
10.96.0.4:0        id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D   
10.96.0.8:0        id=2591  sec_id=6360297 flags=0x0000 ifindex=18  mac=0A:D6:C4:63:68:64 nodemac=46:1A:3F:6A:54:AF   
10.96.0.198:0      id=579   sec_id=6417690 flags=0x0000 ifindex=12  mac=12:9C:21:93:B3:2B nodemac=42:B5:5A:83:1D:4A   
10.96.0.206:0      id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4   
172.31.146.189:0   (localhost)                                                                                        
10.96.0.14:0       id=540   sec_id=4     flags=0x0000 ifindex=10  mac=A6:81:B4:D9:1C:74 nodemac=B6:C8:DB:01:5F:C3     
172.31.163.67:0    (localhost)                                                                                        
