[
  {
    "containers": [
      {
        "cgroup-id": 7488,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5538bd41_9553_4a09_ada2_658eb80a3683.slice/cri-containerd-2ac3c4f8442f249ff2dc28b807eb9942b1fe2417f88498659d903f8396ef2daf.scope"
      }
    ],
    "ips": [
      "10.96.0.198"
    ],
    "name": "coredns-cc6ccd49c-c97kq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd739d92f_bba2_4533_8767_cb29db928b28.slice/cri-containerd-5a8a8178b690df4ce223ed13009a08a53d455a46e5804fcb1b55975924045d56.scope"
      }
    ],
    "ips": [
      "10.96.0.21"
    ],
    "name": "coredns-cc6ccd49c-2h6l6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3b12435_18b9_408c_aa83_2b1fa534c984.slice/cri-containerd-c08f75603c7259146d857cbd037b20e43ef68a4c6123203bc06855ca95ee16ef.scope"
      },
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3b12435_18b9_408c_aa83_2b1fa534c984.slice/cri-containerd-a69d06e9d9136624ded9dc433b19478d1880d53daf35e4801ff58c61bdfcd25b.scope"
      }
    ],
    "ips": [
      "10.96.0.4"
    ],
    "name": "echo-same-node-86d9cc975c-5z5df",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e38c784_4419_4966_a31b_2b28610f7ce4.slice/cri-containerd-944b7a5ed4b1121922eeec8aef0bc67431d846f8b925d1ad509fb75c587df5b8.scope"
      }
    ],
    "ips": [
      "10.96.0.206"
    ],
    "name": "client-974f6c69d-nx5c5",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22428d83_cf2c_473f_97c6_c13e5ab01887.slice/cri-containerd-c3d1bf1ed5f508295696a286b4da4bfbba3b9cc151b26125690547341c4ba6f7.scope"
      }
    ],
    "ips": [
      "10.96.0.28"
    ],
    "name": "client2-57cf4468f-f2lf6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa35f6aa_3559_427e_a5ca_e9417a289a6d.slice/cri-containerd-e6c2b2d15dd650ab4417fdfdd6a39989cc5937ee0491eb2fccd8804bebdbbac8.scope"
      },
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa35f6aa_3559_427e_a5ca_e9417a289a6d.slice/cri-containerd-62ceeb4a28ec5d89a11d6dad80b96ec17657ab4ce909f45429eaf3517e7a91bb.scope"
      },
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa35f6aa_3559_427e_a5ca_e9417a289a6d.slice/cri-containerd-3158eb8804dd742b13d555763a488ac569cb16580097999cf02a2b09db87057b.scope"
      }
    ],
    "ips": [
      "10.96.0.8"
    ],
    "name": "clustermesh-apiserver-9575b7484-ks6v8",
    "namespace": "kube-system"
  }
]

