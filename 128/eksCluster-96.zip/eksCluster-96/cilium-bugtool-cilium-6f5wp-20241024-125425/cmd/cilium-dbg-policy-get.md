[
  {
    "endpointSelector": {
      "matchLabels": {
        "any:kind": "echo",
        "k8s:io.kubernetes.pod.namespace": "cilium-test-1"
      }
    },
    "ingress": [
      {
        "fromEndpoints": [
          {
            "matchLabels": {
              "any:other": "client",
              "k8s:io.kubernetes.pod.namespace": "cilium-test-1"
            }
          }
        ],
        "toPorts": [
          {
            "ports": [
              {
                "port": "8080",
                "protocol": "TCP"
              }
            ],
            "rules": {
              "http": [
                {
                  "path": "/$",
                  "method": "GET"
                },
                {
                  "path": "/public$",
                  "method": "GET"
                },
                {
                  "path": "/private$",
                  "method": "GET",
                  "headers": [
                    "X-Very-Secret-Token: 42"
                  ]
                }
              ]
            }
          }
        ]
      }
    ],
    "labels": [
      {
        "key": "io.cilium.k8s.policy.derived-from",
        "value": "CiliumNetworkPolicy",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.name",
        "value": "echo-ingress-l7-http",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.namespace",
        "value": "cilium-test-1",
        "source": "k8s"
      },
      {
        "key": "io.cilium.k8s.policy.uid",
        "value": "d994a40a-3fb3-4801-8968-1c773806c107",
        "source": "k8s"
      }
    ],
    "enableDefaultDeny": {
      "ingress": true,
      "egress": false
    },
    "description": "Allow other client to GET on echo"
  }
]
Revision: 130
