32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:52+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:52+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:53+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:53+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:53+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:53+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:56+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
492: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
495: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
496: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
499: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
500: sched_cls  name tail_handle_ipv4  tag 6566b8b34ab034aa  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 136
501: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 137
502: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 138
503: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 139
526: sched_cls  name tail_handle_ipv4_cont  tag c6b4f51d427b62fe  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,91,82,83,39,76,74,77,111,40,37,38,81
	btf_id 165
527: sched_cls  name handle_policy  tag aac5c5ed8dc6dd4b  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,91,39,84,75,40,37,38
	btf_id 166
528: sched_cls  name tail_ipv4_to_endpoint  tag 226dc2eb420f1e6f  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,91,39,111,40,37,38
	btf_id 167
529: sched_cls  name cil_from_container  tag 3f3945b5809fd9bf  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 168
530: sched_cls  name tail_handle_arp  tag 787fe52cd297b8ba  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 169
532: sched_cls  name __send_drop_notify  tag 165f1a42fbc3cf8a  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
533: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 172
534: sched_cls  name tail_ipv4_ct_ingress  tag abb2467da8ebd096  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 173
535: sched_cls  name tail_ipv4_ct_egress  tag 40376feca20acf11  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 174
536: sched_cls  name tail_handle_ipv4  tag 9a23b399e3d7c04a  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 175
537: sched_cls  name cil_from_container  tag bd1d8adb51e66832  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,76
	btf_id 177
538: sched_cls  name __send_drop_notify  tag d26e9c585046357a  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
539: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 179
540: sched_cls  name tail_handle_arp  tag 815aa5c19439a550  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 180
541: sched_cls  name tail_ipv4_to_endpoint  tag 1602f6544f1a718b  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,106,39,114,40,37,38
	btf_id 181
542: sched_cls  name handle_policy  tag fc1c036e745ec785  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,114,82,83,113,41,80,106,39,84,75,40,37,38
	btf_id 182
544: sched_cls  name tail_ipv4_ct_egress  tag 40376feca20acf11  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 184
545: sched_cls  name tail_ipv4_ct_ingress  tag affeb62157862d60  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 185
546: sched_cls  name tail_handle_ipv4  tag cd403366e242d9fb  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 186
547: sched_cls  name tail_handle_ipv4_cont  tag f53431e839451664  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,106,82,83,39,76,74,77,114,40,37,38,81
	btf_id 187
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: sched_cls  name __send_drop_notify  tag 4bc1344163c58214  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
553: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 190
554: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 191
555: sched_cls  name tail_handle_ipv4  tag c028345939d31496  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 192
556: sched_cls  name tail_ipv4_ct_ingress  tag 58cde1046a14f3ec  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 193
557: sched_cls  name handle_policy  tag b1a6426de215d096  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,116,41,80,105,39,84,75,40,37,38
	btf_id 194
558: sched_cls  name tail_ipv4_to_endpoint  tag a3c0ed41fd5f8612  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,116,41,82,83,80,105,39,117,40,37,38
	btf_id 195
559: sched_cls  name tail_handle_arp  tag f48d4f0b1ffddcbb  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 196
560: sched_cls  name tail_handle_ipv4_cont  tag 694773981b7893ec  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,116,41,105,82,83,39,76,74,77,117,40,37,38,81
	btf_id 197
561: sched_cls  name cil_from_container  tag a6bea6798fa15bae  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 198
563: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
566: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
567: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,119
	btf_id 201
569: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
571: sched_cls  name __send_drop_notify  tag 7cb0072bf0e3984d  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
572: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 206
573: sched_cls  name tail_handle_ipv4_from_host  tag c8b952cd3ba1c39c  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 207
576: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 211
578: sched_cls  name __send_drop_notify  tag 7cb0072bf0e3984d  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
579: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 214
580: sched_cls  name tail_handle_ipv4_from_host  tag c8b952cd3ba1c39c  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 215
582: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 218
583: sched_cls  name __send_drop_notify  tag 7cb0072bf0e3984d  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
584: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 220
585: sched_cls  name tail_handle_ipv4_from_host  tag c8b952cd3ba1c39c  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 221
589: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 226
590: sched_cls  name __send_drop_notify  tag 7cb0072bf0e3984d  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 227
591: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 228
592: sched_cls  name tail_handle_ipv4_from_host  tag c8b952cd3ba1c39c  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 229
634: sched_cls  name tail_handle_arp  tag 161b21ac2145dabd  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,138
	btf_id 245
635: sched_cls  name handle_policy  tag 0455206bf2b03bfd  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,138,82,83,139,41,80,137,39,84,75,40,37,38
	btf_id 246
636: sched_cls  name tail_handle_ipv4  tag b2bcf001e63b4fb0  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,138
	btf_id 247
637: sched_cls  name __send_drop_notify  tag 514e2b9ded98ecee  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 248
638: sched_cls  name tail_handle_ipv4_cont  tag 9645dd396ecb3a88  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,139,41,137,82,83,39,76,74,77,138,40,37,38,81
	btf_id 249
640: sched_cls  name tail_ipv4_ct_egress  tag 0664c4b4ed6095c1  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,138,82,83,139,84
	btf_id 251
641: sched_cls  name tail_ipv4_to_endpoint  tag 44ee338427ae8436  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,139,41,82,83,80,137,39,138,40,37,38
	btf_id 252
642: sched_cls  name cil_from_container  tag 927f51caf2ebed0c  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 138,76
	btf_id 253
643: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,138
	btf_id 254
644: sched_cls  name tail_ipv4_ct_ingress  tag 38e43f6ea8b3d82b  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,138,82,83,139,84
	btf_id 255
645: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
648: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
665: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
668: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
669: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
672: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
695: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
698: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
726: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
729: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
730: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
733: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3341: sched_cls  name cil_from_container  tag cf108279edf0173c  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3137
3343: sched_cls  name __send_drop_notify  tag f19f5683b74f2787  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3140
3344: sched_cls  name tail_handle_arp  tag 8d394636f5501446  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3141
3345: sched_cls  name __send_drop_notify  tag 4fccc717f33cb8c1  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3143
3346: sched_cls  name cil_from_container  tag 2e4f9571e398eaba  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3144
3347: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3142
3348: sched_cls  name tail_ipv4_ct_egress  tag 909447023d880ed5  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3145
3349: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3147
3350: sched_cls  name tail_handle_ipv4  tag 2c9551e705ed7540  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3146
3351: sched_cls  name tail_handle_ipv4_cont  tag 143a219faff403af  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,155,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3149
3352: sched_cls  name tail_ipv4_ct_ingress  tag 4a37272b77e229da  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3148
3354: sched_cls  name tail_handle_ipv4_cont  tag 54924ef8bb56ee82  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,150,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3151
3355: sched_cls  name tail_ipv4_ct_ingress  tag a73a9b5052a49f22  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3152
3356: sched_cls  name tail_ipv4_ct_egress  tag cbeaa4fd398e2338  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3154
3357: sched_cls  name handle_policy  tag f222d778e49c64dd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,639,41,80,150,39,84,75,40,37,38
	btf_id 3153
3358: sched_cls  name tail_ipv4_to_endpoint  tag c174dab3d179c5d3  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,155,39,637,40,37,38
	btf_id 3155
3359: sched_cls  name tail_handle_arp  tag 1a7d658bf2115f08  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3157
3360: sched_cls  name tail_ipv4_to_endpoint  tag 817090505cbb931c  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,150,39,640,40,37,38
	btf_id 3156
3361: sched_cls  name handle_policy  tag e3ee24b3cdbf94c0  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,155,39,84,75,40,37,38
	btf_id 3158
3362: sched_cls  name tail_handle_ipv4  tag cdf09ecb349f66bc  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3159
3363: sched_cls  name tail_handle_arp  tag 2aa6164de064af76  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,642
	btf_id 3161
3364: sched_cls  name __send_drop_notify  tag 81069fc55c661bd6  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3162
3365: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,642
	btf_id 3163
3366: sched_cls  name tail_ipv4_ct_egress  tag dc50993f8d2ad77f  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3164
3367: sched_cls  name tail_handle_ipv4_cont  tag e2335cc754ff80b8  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,641,41,147,82,83,39,76,74,77,642,40,37,38,81
	btf_id 3165
3368: sched_cls  name handle_policy  tag 26c07d7403a7dc1e  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 15040B  jited 10296B  memlock 16384B  map_ids 76,642,82,83,641,41,80,147,39,84,75,40,37,38
	btf_id 3166
3369: sched_cls  name tail_ipv4_ct_ingress  tag 2533af334c727a2c  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3167
3370: sched_cls  name tail_handle_ipv4  tag f0ea53f9fbda1582  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,642
	btf_id 3168
3371: sched_cls  name tail_ipv4_to_endpoint  tag 138a17257f9cd3b3  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 9096B  jited 5960B  memlock 12288B  map_ids 75,76,641,41,82,83,80,147,39,642,40,37,38
	btf_id 3169
3373: sched_cls  name cil_from_container  tag 53283bfbe67c38e1  gpl
	loaded_at 2024-10-24T12:53:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 642,76
	btf_id 3171
