Node 0, zone      DMA     79     73      2     12      3     11     12      1      1      1     41 
Node 0, zone   Normal    319     19     12      1     11     10      2      2      1      2      8 
