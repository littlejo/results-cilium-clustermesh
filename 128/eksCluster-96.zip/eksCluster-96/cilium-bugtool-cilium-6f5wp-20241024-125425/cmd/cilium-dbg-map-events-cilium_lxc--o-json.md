{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.453Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.465Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.491Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.044Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.094Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.119Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.133Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.175Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.197Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.444Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.456Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.496Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.528Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.566Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.164Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.169Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.215Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.216Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.262Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.488Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.491Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.540Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.593Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.608Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.081Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.088Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.121Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.139Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.172Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.216Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.219Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.448Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.452Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.519Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.524Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.567Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.107Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.186Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.227Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.270Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.299Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.307Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.520Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.527Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.582Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.588Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.620Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.066Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.069Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.115Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.133Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.151Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.422Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.434Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.500Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.510Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.550Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.873Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.907Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.939Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.954Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.982Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.999Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.252Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.367Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.393Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.420Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.436Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.788Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.793Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.837Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.856Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.876Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.157Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.163Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.219Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.236Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.267Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.641Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.679Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.681Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.726Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.737Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.766Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.041Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.069Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.098Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.117Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.153Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.627Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.648Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.717Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.729Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.757Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.110Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.171Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.263Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.326Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.625Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.687Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.694Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.731Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.740Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.770Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.976Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.990Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.034Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.065Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.100Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.416Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.428Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.463Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.490Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.498Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.726Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.738Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.772Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.820Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.499Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.503Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.561Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.565Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.593Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.844Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.845Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.462Z",
  "value": "id=1871  sec_id=6395033 flags=0x0000 ifindex=24  mac=72:1E:F2:2F:F7:3E nodemac=3E:F6:97:A1:AF:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.467Z",
  "value": "id=3011  sec_id=6394428 flags=0x0000 ifindex=22  mac=9E:50:E7:5E:36:AC nodemac=BA:68:C4:49:20:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:53:31.706Z",
  "value": "id=2820  sec_id=6400521 flags=0x0000 ifindex=20  mac=22:3E:98:71:7C:BD nodemac=32:C5:09:EE:AB:4D"
}

