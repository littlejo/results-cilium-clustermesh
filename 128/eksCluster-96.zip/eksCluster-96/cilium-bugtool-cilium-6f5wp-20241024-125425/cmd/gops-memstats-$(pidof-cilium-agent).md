alloc: 102.57MB (107557040 bytes)
total-alloc: 3.14GB (3366794720 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 75856267
frees: 74878684
heap-alloc: 102.57MB (107557040 bytes)
heap-sys: 176.48MB (185057280 bytes)
heap-idle: 45.45MB (47652864 bytes)
heap-in-use: 131.04MB (137404416 bytes)
heap-released: 8.39MB (8798208 bytes)
heap-objects: 977583
stack-in-use: 35.47MB (37191680 bytes)
stack-sys: 35.47MB (37191680 bytes)
stack-mspan-inuse: 2.14MB (2240480 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 724.64KB (742033 bytes)
gc-sys: 5.52MB (5792840 bytes)
next-gc: when heap-alloc >= 153.90MB (161372952 bytes)
last-gc: 2024-10-24 12:54:31.545237049 +0000 UTC
gc-pause-total: 10.598409ms
gc-pause: 77022
gc-pause-end: 1729774471545237049
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006297978870796143
enable-gc: true
debug-gc: false
