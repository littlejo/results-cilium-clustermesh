filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3f0e3e3e4f76 direct-action not_in_hw id 642 tag 927f51caf2ebed0c jited 
