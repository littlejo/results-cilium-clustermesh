key: 1c 02 00 00  value: 2d 02 00 00
key: 43 02 00 00  value: 0f 02 00 00
key: bd 02 00 00  value: 1e 02 00 00
key: 4f 07 00 00  value: 21 0d 00 00
key: 1f 0a 00 00  value: 7b 02 00 00
key: 04 0b 00 00  value: 28 0d 00 00
key: c3 0b 00 00  value: 1d 0d 00 00
Found 7 elements
