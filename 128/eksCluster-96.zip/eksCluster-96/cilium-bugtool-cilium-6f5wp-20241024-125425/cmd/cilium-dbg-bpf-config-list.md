KEY             VALUE
AgentLiveness   1928795734653
UTimeOffset     3378462048828125
