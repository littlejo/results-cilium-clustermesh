key: 2e 00 00 00  value: 7a 02 00 00
key: 54 00 00 00  value: 01 02 00 00
key: 4a 07 00 00  value: 11 02 00 00
key: 87 07 00 00  value: 0d 0d 00 00
key: 13 09 00 00  value: ff 0c 00 00
key: db 0a 00 00  value: cd 0c 00 00
key: e4 0f 00 00  value: 1d 02 00 00
Found 7 elements
