xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 575
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 561
cilium_host(7) clsact/egress cil_from_host-cilium_host id 563
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 532
lxcd7007b15649d(12) clsact/ingress cil_from_container-lxcd7007b15649d id 524
lxcfe084920d5da(14) clsact/ingress cil_from_container-lxcfe084920d5da id 516
lxc0941d3491421(18) clsact/ingress cil_from_container-lxc0941d3491421 id 626
lxc798711a1d056(20) clsact/ingress cil_from_container-lxc798711a1d056 id 3333
lxc8ceb3d475728(22) clsact/ingress cil_from_container-lxc8ceb3d475728 id 3267
lxc73fe954e0a71(24) clsact/ingress cil_from_container-lxc73fe954e0a71 id 3325

flow_dissector:

netfilter:

