IP ADDRESS         LOCAL ENDPOINT INFO
10.63.0.230:0      id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95   
10.63.0.66:0       id=1866  sec_id=4215392 flags=0x0000 ifindex=12  mac=FA:13:8C:79:C1:9C nodemac=8A:44:2D:69:56:09   
10.63.0.16:0       id=84    sec_id=4215392 flags=0x0000 ifindex=14  mac=8E:D9:81:99:3C:45 nodemac=9E:51:EA:B6:F0:2B   
10.63.0.98:0       (localhost)                                                                                        
10.63.0.161:0      id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13   
10.63.0.48:0       id=4068  sec_id=4     flags=0x0000 ifindex=10  mac=C2:20:B4:02:C7:42 nodemac=9A:A8:18:0D:D3:FF     
10.63.0.226:0      id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9   
10.63.0.69:0       id=46    sec_id=4204229 flags=0x0000 ifindex=18  mac=22:3D:EA:AE:A6:1E nodemac=92:F4:5A:12:3C:F6   
172.31.235.106:0   (localhost)                                                                                        
172.31.203.206:0   (localhost)                                                                                        
