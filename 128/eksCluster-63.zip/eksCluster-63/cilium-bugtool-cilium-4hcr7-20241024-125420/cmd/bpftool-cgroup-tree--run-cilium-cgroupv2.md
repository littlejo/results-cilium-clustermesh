CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a4348f3_5f0e_4414_85c6_961c1c792b98.slice/cri-containerd-15f1001832e6ff5364b5c034d8495b4e1c0bd55b02a28aa2bfc95d64d0e60738.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a4348f3_5f0e_4414_85c6_961c1c792b98.slice/cri-containerd-203f2a2a25c9f2aac1430c0797f9b74bb4c553c79b1c5004d2a9e98f86002d97.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0afafd5_24c8_4ab1_bfc4_a12d0235047d.slice/cri-containerd-a4251735bc24e243f2004e5678b1babe68c5b3e55e24b6e6e05162acc4fad2f2.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0afafd5_24c8_4ab1_bfc4_a12d0235047d.slice/cri-containerd-db98248c4383e5cfab512b9a6d2e28702d70a50e458ebc8f3a64e20d390ea802.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a81a8b9_d1a9_459b_acbd_760868e77618.slice/cri-containerd-73959941784355ac02305c9b8a7f74fa1e39f9740f7d810dba0693416bbdb701.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a81a8b9_d1a9_459b_acbd_760868e77618.slice/cri-containerd-ba4589b26bbe05eaee9e6cc720c856a9172bcc807aaba5a521357bffcf0e7bd3.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47c418c1_d91b_42d5_9a24_66187c4f8e1c.slice/cri-containerd-f034e473c73e01d6447f94e44a0b34b54b343b30a0afb5007f7387d60304dd70.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47c418c1_d91b_42d5_9a24_66187c4f8e1c.slice/cri-containerd-f16776eac0e7842a78b89e1970b136977c1088c917d2d81a9eccf0576a1d5edc.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9520598_2cfc_4fce_b6ce_421fff216965.slice/cri-containerd-899a0c3512fc499c81a30df2e92180b25da9af8cfa7028fe8b1964783ddbe8be.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9520598_2cfc_4fce_b6ce_421fff216965.slice/cri-containerd-2d04173c8f27f7e315b4fb6d9e15d4fc5aae52de51cda6145aa67763d34d1575.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9520598_2cfc_4fce_b6ce_421fff216965.slice/cri-containerd-2d959632ed1c0c0dc5f21e5e725f9fba053fe9d1e6de570491078e3fac43bca2.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9520598_2cfc_4fce_b6ce_421fff216965.slice/cri-containerd-88d945ed1f70cfa6c977be2235b065c24a97397118f2cfaad9c439497ce0c8c2.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6951c0c_ef52_4309_81d5_e826691746c5.slice/cri-containerd-0e7f844a43393a71135a2f51870dbc167512207a78986ad328e6d7eb8f358247.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6951c0c_ef52_4309_81d5_e826691746c5.slice/cri-containerd-6450f78e1f25457e087558c420ead3ea97d9feecf61d4467f120f1458695f6e9.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11b48b62_f587_430d_8ba3_9d469235eab5.slice/cri-containerd-1bc400ff41aec4e95730f85f4a0367a4491335c5adef804ce6119a3c886811c0.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11b48b62_f587_430d_8ba3_9d469235eab5.slice/cri-containerd-e2fdebc88565a50da9725021839d8562e500874c20edd9c9978731295b8e9c67.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11b48b62_f587_430d_8ba3_9d469235eab5.slice/cri-containerd-f01c970889ff5d69412486336376e0f9c18aae7a56898c0a6d9da832d87970e0.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61ed6fa4_94af_4a30_bee9_21f0af256033.slice/cri-containerd-531f6e6cfea1b57b4ebd44b2f43d47d2f0fbdb82d4db66a64b93927473340a66.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61ed6fa4_94af_4a30_bee9_21f0af256033.slice/cri-containerd-136429b5ea7261238d54d5578166f74ff8ad2e9f9741e5b2c8b7d4c5967334be.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6078a3a8_8d29_44c3_bde8_fa2cd04953e0.slice/cri-containerd-33f99265a853e877593830cf9f76d2f723629e1db9c48addea4e2c1c66bd528d.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6078a3a8_8d29_44c3_bde8_fa2cd04953e0.slice/cri-containerd-f7cd6c65b59d9b04560543a334fae2b7b245ac771b1612dcf390b3d3e7bf697f.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6768d08_eb31_49d9_818c_97640703b746.slice/cri-containerd-0270be4be1020287cdf93cb2bfeb67c714bc1dd5c5653466bbdc68983a47c9f6.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6768d08_eb31_49d9_818c_97640703b746.slice/cri-containerd-3ee09cc5bb6a2acec2f3d12df10160d1acf37cf50f690b2d8fd41aea8d90c0f2.scope
    101      cgroup_device   multi                                          
