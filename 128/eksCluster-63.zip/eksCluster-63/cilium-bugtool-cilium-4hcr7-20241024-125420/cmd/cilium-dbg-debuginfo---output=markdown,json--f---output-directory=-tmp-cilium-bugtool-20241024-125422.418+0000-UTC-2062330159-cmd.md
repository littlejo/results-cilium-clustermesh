markdown output at /tmp/cilium-bugtool-20241024-125422.418+0000-UTC-2062330159/cmd/cilium-debuginfo-20241024-125423.676+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125422.418+0000-UTC-2062330159/cmd/cilium-debuginfo-20241024-125423.676+0000-UTC.json
