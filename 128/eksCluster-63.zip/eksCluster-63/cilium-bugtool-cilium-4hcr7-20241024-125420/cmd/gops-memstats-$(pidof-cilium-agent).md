alloc: 95.22MB (99840608 bytes)
total-alloc: 3.04GB (3267582392 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 74458588
frees: 73698223
heap-alloc: 95.22MB (99840608 bytes)
heap-sys: 176.79MB (185376768 bytes)
heap-idle: 42.53MB (44597248 bytes)
heap-in-use: 134.26MB (140779520 bytes)
heap-released: 10.27MB (10772480 bytes)
heap-objects: 760365
stack-in-use: 35.19MB (36896768 bytes)
stack-sys: 35.19MB (36896768 bytes)
stack-mspan-inuse: 2.12MB (2225760 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 722.88KB (740233 bytes)
gc-sys: 5.52MB (5784744 bytes)
next-gc: when heap-alloc >= 148.32MB (155526520 bytes)
last-gc: 2024-10-24 12:54:09.529002491 +0000 UTC
gc-pause-total: 9.220341ms
gc-pause: 74305
gc-pause-end: 1729774449529002491
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0005659340612671294
enable-gc: true
debug-gc: false
