1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:75:8a:e2:51:05 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.235.106/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3469sec preferred_lft 3469sec
    inet6 fe80::875:8aff:fee2:5105/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9f:8d:6e:9d:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.203.206/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::89f:8dff:fe6e:9dd1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:2a:ac:78:cd:47 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dc2a:acff:fe78:cd47/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:6c:17:ca:e2:6e brd ff:ff:ff:ff:ff:ff
    inet 10.63.0.98/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::446c:17ff:feca:e26e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9e:a6:d8:84:00:9c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9ca6:d8ff:fe84:9c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:a8:18:0d:d3:ff brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::98a8:18ff:fe0d:d3ff/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd7007b15649d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:44:2d:69:56:09 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8844:2dff:fe69:5609/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfe084920d5da@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:51:ea:b6:f0:2b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9c51:eaff:feb6:f02b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0941d3491421@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:f4:5a:12:3c:f6 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::90f4:5aff:fe12:3cf6/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc798711a1d056@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:36:a7:85:c8:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::a836:a7ff:fe85:c8b9/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc8ceb3d475728@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:03:cd:b4:ff:95 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::4003:cdff:feb4:ff95/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc73fe954e0a71@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:36:c3:87:53:13 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::9836:c3ff:fe87:5313/64 scope link 
       valid_lft forever preferred_lft forever
