top - 12:54:22 up 32 min,  0 users,  load average: 0.43, 0.52, 0.29
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 34.5 us, 27.6 sy,  0.0 ni, 37.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    291.5 free,   1047.0 used,   2497.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2608.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 294356  79276 S  20.0   7.5   1:12.49 cilium-+
   3155 root      20   0 1240432  16476  11292 S  13.3   0.4   0:00.03 cilium-+
    402 root      20   0 1229744  10188   3836 S   0.0   0.3   0:04.39 cilium-+
   3199 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3223 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
