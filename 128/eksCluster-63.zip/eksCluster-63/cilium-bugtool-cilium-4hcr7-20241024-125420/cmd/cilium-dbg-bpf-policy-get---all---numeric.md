Endpoint ID: 46
Path: /sys/fs/bpf/tc/globals/cilium_policy_00046

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5399427   55931     0        
Allow    Ingress     1          ANY          NONE         disabled    5368237   56726     0        
Allow    Egress      0          ANY          NONE         disabled    6242862   63448     0        


Endpoint ID: 84
Path: /sys/fs/bpf/tc/globals/cilium_policy_00084

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2822     27        0        
Allow    Ingress     1          ANY          NONE         disabled    143695   1653      0        
Allow    Egress      0          ANY          NONE         disabled    18679    207       0        


Endpoint ID: 1502
Path: /sys/fs/bpf/tc/globals/cilium_policy_01502

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1866
Path: /sys/fs/bpf/tc/globals/cilium_policy_01866

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3074     33        0        
Allow    Ingress     1          ANY          NONE         disabled    143893   1656      0        
Allow    Egress      0          ANY          NONE         disabled    18577    206       0        


Endpoint ID: 1927
Path: /sys/fs/bpf/tc/globals/cilium_policy_01927

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2323
Path: /sys/fs/bpf/tc/globals/cilium_policy_02323

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2779
Path: /sys/fs/bpf/tc/globals/cilium_policy_02779

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    352605   4116      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 4068
Path: /sys/fs/bpf/tc/globals/cilium_policy_04068

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6182623   76530     0        
Allow    Ingress     1          ANY          NONE         disabled    61989     750       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


