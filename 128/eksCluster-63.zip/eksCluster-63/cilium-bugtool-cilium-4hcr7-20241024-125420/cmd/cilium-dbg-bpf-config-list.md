KEY             VALUE
AgentLiveness   1948428918175
UTimeOffset     3378461945312500
