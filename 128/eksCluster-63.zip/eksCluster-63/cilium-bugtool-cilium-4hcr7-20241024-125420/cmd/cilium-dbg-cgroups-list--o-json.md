[
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9520598_2cfc_4fce_b6ce_421fff216965.slice/cri-containerd-2d959632ed1c0c0dc5f21e5e725f9fba053fe9d1e6de570491078e3fac43bca2.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9520598_2cfc_4fce_b6ce_421fff216965.slice/cri-containerd-2d04173c8f27f7e315b4fb6d9e15d4fc5aae52de51cda6145aa67763d34d1575.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9520598_2cfc_4fce_b6ce_421fff216965.slice/cri-containerd-88d945ed1f70cfa6c977be2235b065c24a97397118f2cfaad9c439497ce0c8c2.scope"
      }
    ],
    "ips": [
      "10.63.0.69"
    ],
    "name": "clustermesh-apiserver-56cb98b47b-bwmm6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6951c0c_ef52_4309_81d5_e826691746c5.slice/cri-containerd-0e7f844a43393a71135a2f51870dbc167512207a78986ad328e6d7eb8f358247.scope"
      }
    ],
    "ips": [
      "10.63.0.161"
    ],
    "name": "client2-57cf4468f-p9v9b",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61ed6fa4_94af_4a30_bee9_21f0af256033.slice/cri-containerd-136429b5ea7261238d54d5578166f74ff8ad2e9f9741e5b2c8b7d4c5967334be.scope"
      }
    ],
    "ips": [
      "10.63.0.226"
    ],
    "name": "client-974f6c69d-m8rbh",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11b48b62_f587_430d_8ba3_9d469235eab5.slice/cri-containerd-e2fdebc88565a50da9725021839d8562e500874c20edd9c9978731295b8e9c67.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11b48b62_f587_430d_8ba3_9d469235eab5.slice/cri-containerd-f01c970889ff5d69412486336376e0f9c18aae7a56898c0a6d9da832d87970e0.scope"
      }
    ],
    "ips": [
      "10.63.0.230"
    ],
    "name": "echo-same-node-86d9cc975c-nh449",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a81a8b9_d1a9_459b_acbd_760868e77618.slice/cri-containerd-73959941784355ac02305c9b8a7f74fa1e39f9740f7d810dba0693416bbdb701.scope"
      }
    ],
    "ips": [
      "10.63.0.16"
    ],
    "name": "coredns-cc6ccd49c-j5bmq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0afafd5_24c8_4ab1_bfc4_a12d0235047d.slice/cri-containerd-a4251735bc24e243f2004e5678b1babe68c5b3e55e24b6e6e05162acc4fad2f2.scope"
      }
    ],
    "ips": [
      "10.63.0.66"
    ],
    "name": "coredns-cc6ccd49c-f79rf",
    "namespace": "kube-system"
  }
]

