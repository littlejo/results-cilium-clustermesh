35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:59+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:00+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:00+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:00+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:08+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:29:09+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:29:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
486: sched_cls  name tail_handle_ipv4  tag a45998a228519d52  gpl
	loaded_at 2024-10-24T12:29:09+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:29:09+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
507: sched_cls  name tail_ipv4_ct_egress  tag bb46c9decd84864e  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 151
510: sched_cls  name tail_handle_ipv4_cont  tag b1e027222487045e  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 152
511: sched_cls  name tail_handle_arp  tag 5030c48fa4d85b9b  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 154
513: sched_cls  name handle_policy  tag 4cb8db86886d3dc7  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 156
514: sched_cls  name tail_ipv4_to_endpoint  tag 0ceaa44f2ec6a29d  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 157
515: sched_cls  name tail_handle_ipv4  tag 7948e8c018e3a2e0  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 158
516: sched_cls  name cil_from_container  tag 76d7709376b01f50  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 159
517: sched_cls  name tail_ipv4_ct_ingress  tag 8c9ffd8c15b17b83  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 160
519: sched_cls  name __send_drop_notify  tag 48a84b2866606717  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 162
520: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 163
521: sched_cls  name tail_ipv4_to_endpoint  tag d69edb91d78ad22e  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,110,41,82,83,80,101,39,109,40,37,38
	btf_id 165
522: sched_cls  name tail_ipv4_ct_ingress  tag c107c841b5a027e0  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 166
523: sched_cls  name tail_ipv4_ct_egress  tag bb46c9decd84864e  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 167
524: sched_cls  name cil_from_container  tag 210fc83c74970120  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 168
526: sched_cls  name tail_handle_ipv4  tag b175e0adc9979d45  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 170
527: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 171
528: sched_cls  name __send_drop_notify  tag 33741f8502b586a7  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 172
529: sched_cls  name handle_policy  tag 4e68794eeed5af4d  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,110,41,80,101,39,84,75,40,37,38
	btf_id 173
530: sched_cls  name tail_handle_ipv4_cont  tag e5b9157e1b779433  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,110,41,101,82,83,39,76,74,77,109,40,37,38,81
	btf_id 174
531: sched_cls  name tail_handle_arp  tag 24ac296b994bce0b  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 175
532: sched_cls  name cil_from_container  tag 01296d7b54e7f3b5  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,76
	btf_id 177
533: sched_cls  name tail_handle_arp  tag 0cbcb839c126116a  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 178
535: sched_cls  name tail_ipv4_to_endpoint  tag 013fbdf72099c808  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,111,41,82,83,80,100,39,112,40,37,38
	btf_id 180
536: sched_cls  name __send_drop_notify  tag 6347de5e23c9533c  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 181
537: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 182
538: sched_cls  name tail_handle_ipv4_cont  tag 6c8d38ae3d6f2d01  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,111,41,100,82,83,39,76,74,77,112,40,37,38,81
	btf_id 183
539: sched_cls  name tail_ipv4_ct_ingress  tag 5587b8b045b6c61b  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 184
540: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 185
541: sched_cls  name handle_policy  tag e959b048e221c017  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,112,82,83,111,41,80,100,39,84,75,40,37,38
	btf_id 186
542: sched_cls  name tail_handle_ipv4  tag 381a5b41bf9932e9  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 187
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 189
560: sched_cls  name __send_drop_notify  tag aefd91825bce9b30  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 190
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
562: sched_cls  name tail_handle_ipv4_from_host  tag 14033144b41f6fc8  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 192
563: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 193
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 197
567: sched_cls  name __send_drop_notify  tag aefd91825bce9b30  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
568: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 199
569: sched_cls  name tail_handle_ipv4_from_host  tag 14033144b41f6fc8  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 200
575: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 207
576: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 208
577: sched_cls  name __send_drop_notify  tag aefd91825bce9b30  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 209
579: sched_cls  name tail_handle_ipv4_from_host  tag 14033144b41f6fc8  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 211
580: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 213
581: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 214
582: sched_cls  name __send_drop_notify  tag aefd91825bce9b30  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
584: sched_cls  name tail_handle_ipv4_from_host  tag 14033144b41f6fc8  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 217
626: sched_cls  name cil_from_container  tag 132739c85f6091b5  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 233
627: sched_cls  name tail_handle_arp  tag 70ecc7d7f25c9702  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 234
629: sched_cls  name tail_handle_ipv4  tag df2d35a582bf16a8  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 236
630: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 237
631: sched_cls  name tail_ipv4_ct_ingress  tag 4866b23ce33b0728  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 238
632: sched_cls  name __send_drop_notify  tag b03b6b42fedffdab  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
633: sched_cls  name tail_handle_ipv4_cont  tag 0ddb05e0061d691b  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 240
634: sched_cls  name handle_policy  tag 6d5456f3f8e2877d  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 241
635: sched_cls  name tail_ipv4_to_endpoint  tag 2f82274402f8a818  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 242
636: sched_cls  name tail_ipv4_ct_egress  tag 90ea8b53e804b708  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
698: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
701: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3267: sched_cls  name cil_from_container  tag 8166bdacba710bc8  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 624,76
	btf_id 3053
3268: sched_cls  name tail_ipv4_ct_egress  tag ca43806c331b5e7a  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,624,82,83,623,84
	btf_id 3054
3269: sched_cls  name __send_drop_notify  tag d25771e8b6c4dc35  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3055
3271: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,624
	btf_id 3057
3272: sched_cls  name tail_handle_ipv4_cont  tag f8f29827bcbba1ad  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,623,41,148,82,83,39,76,74,77,624,40,37,38,81
	btf_id 3058
3277: sched_cls  name handle_policy  tag 5131a71bfb1c9e08  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,624,82,83,623,41,80,148,39,84,75,40,37,38
	btf_id 3059
3278: sched_cls  name tail_handle_ipv4  tag c394178b34d12e14  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,624
	btf_id 3066
3281: sched_cls  name tail_ipv4_ct_ingress  tag 0d7e58757ab7ff7e  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,624,82,83,623,84
	btf_id 3067
3282: sched_cls  name tail_handle_arp  tag 84d599b15b4f881d  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,624
	btf_id 3070
3287: sched_cls  name tail_ipv4_to_endpoint  tag e66fa1d80b5b1362  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,623,41,82,83,80,148,39,624,40,37,38
	btf_id 3071
3322: sched_cls  name __send_drop_notify  tag 55e7c7fff28f58cc  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3113
3323: sched_cls  name tail_ipv4_ct_egress  tag 0f74773002eb5507  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3116
3324: sched_cls  name tail_ipv4_ct_ingress  tag 7481adf3ff098e82  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3117
3325: sched_cls  name cil_from_container  tag 98bb9299ff02e6b8  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,76
	btf_id 3118
3326: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,634
	btf_id 3119
3327: sched_cls  name handle_policy  tag bd1e8193090f2d97  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,145,39,84,75,40,37,38
	btf_id 3115
3328: sched_cls  name tail_handle_arp  tag d864ca893244a89f  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3121
3329: sched_cls  name __send_drop_notify  tag 74e70bc0d5a5a4ab  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3122
3330: sched_cls  name tail_handle_ipv4_cont  tag e9e072dbc5d98354  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,633,41,151,82,83,39,76,74,77,634,40,37,38,81
	btf_id 3120
3331: sched_cls  name tail_handle_ipv4  tag 1bbc22063718e445  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3123
3332: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3125
3333: sched_cls  name cil_from_container  tag a607103fde254c2b  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3126
3334: sched_cls  name tail_ipv4_to_endpoint  tag a3992da36542f13a  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,633,41,82,83,80,151,39,634,40,37,38
	btf_id 3124
3336: sched_cls  name tail_handle_arp  tag 22a39909e470ed79  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,634
	btf_id 3129
3337: sched_cls  name tail_ipv4_ct_ingress  tag 83f024a7d12a508d  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3127
3338: sched_cls  name tail_handle_ipv4  tag ab87f8034433b25c  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,634
	btf_id 3130
3339: sched_cls  name tail_ipv4_to_endpoint  tag 0ff579a2a7bb4210  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,145,39,636,40,37,38
	btf_id 3131
3340: sched_cls  name tail_handle_ipv4_cont  tag d16919aae80caa81  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,145,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3133
3341: sched_cls  name handle_policy  tag beeaa778f713cdba  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,634,82,83,633,41,80,151,39,84,75,40,37,38
	btf_id 3132
3342: sched_cls  name tail_ipv4_ct_egress  tag 51411fbacb0f63f1  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3134
