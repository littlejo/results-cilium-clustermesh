Node 0, zone      DMA     36     32      3     11      3      1      5      3      3      3     45 
Node 0, zone   Normal    259     52     33     28     21     14      4      2      2      2      7 
