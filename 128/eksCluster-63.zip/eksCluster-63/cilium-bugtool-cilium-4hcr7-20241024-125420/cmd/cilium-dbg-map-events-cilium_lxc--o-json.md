{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.468Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.489Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.513Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.531Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.555Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.786Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.811Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.844Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.877Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.915Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.480Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.481Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.534Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.556Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.602Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.629Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.641Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.875Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.880Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.933Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.955Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.977Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.596Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.604Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.633Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.666Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.746Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.749Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.791Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.999Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.011Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.065Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.108Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.140Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.647Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.655Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.689Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.707Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.761Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.779Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.801Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.039Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.048Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.106Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.118Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.156Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.600Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.604Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.665Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.674Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.704Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.964Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.006Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.066Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.108Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.114Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.473Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.503Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.517Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.547Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.548Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.567Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.857Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.864Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.909Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.913Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.962Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.380Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.391Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.440Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.443Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.484Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.719Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.720Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.778Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.787Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.826Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.292Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.365Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.382Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.430Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.439Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.701Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.730Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.782Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.791Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.850Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.278Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.285Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.336Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.344Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.372Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.626Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.631Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.704Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.710Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.758Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.059Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.086Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.107Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.139Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.148Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.177Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.486Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.560Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.580Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.581Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.622Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.908Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.959Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.963Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.020Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.047Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.061Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.298Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.317Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.331Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.335Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.343Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.035Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.038Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.086Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.089Z",
  "value": "id=2779  sec_id=4222425 flags=0x0000 ifindex=22  mac=52:86:00:56:8E:A8 nodemac=42:03:CD:B4:FF:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.121Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.398Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.412Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.105Z",
  "value": "id=1927  sec_id=4211496 flags=0x0000 ifindex=24  mac=DE:CF:FF:42:B5:28 nodemac=9A:36:C3:87:53:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.109Z",
  "value": "id=2323  sec_id=4202823 flags=0x0000 ifindex=20  mac=96:8A:27:FC:37:2E nodemac=AA:36:A7:85:C8:B9"
}

