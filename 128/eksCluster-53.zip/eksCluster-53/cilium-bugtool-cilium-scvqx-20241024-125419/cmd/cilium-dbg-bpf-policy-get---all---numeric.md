Endpoint ID: 116
Path: /sys/fs/bpf/tc/globals/cilium_policy_00116

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 396
Path: /sys/fs/bpf/tc/globals/cilium_policy_00396

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 975
Path: /sys/fs/bpf/tc/globals/cilium_policy_00975

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6034741   61124     0        
Allow    Ingress     1          ANY          NONE         disabled    5767650   61145     0        
Allow    Egress      0          ANY          NONE         disabled    7439010   72840     0        


Endpoint ID: 1193
Path: /sys/fs/bpf/tc/globals/cilium_policy_01193

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    380036   4431      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1911
Path: /sys/fs/bpf/tc/globals/cilium_policy_01911

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2221
Path: /sys/fs/bpf/tc/globals/cilium_policy_02221

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3936     38        0        
Allow    Ingress     1          ANY          NONE         disabled    152538   1754      0        
Allow    Egress      0          ANY          NONE         disabled    20293    228       0        


Endpoint ID: 2727
Path: /sys/fs/bpf/tc/globals/cilium_policy_02727

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1960     22        0        
Allow    Ingress     1          ANY          NONE         disabled    152670   1756      0        
Allow    Egress      0          ANY          NONE         disabled    19443    216       0        


Endpoint ID: 3371
Path: /sys/fs/bpf/tc/globals/cilium_policy_03371

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6225108   77091     0        
Allow    Ingress     1          ANY          NONE         disabled    62735     758       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


