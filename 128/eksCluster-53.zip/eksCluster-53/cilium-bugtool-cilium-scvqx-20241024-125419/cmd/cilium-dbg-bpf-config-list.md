KEY             VALUE
AgentLiveness   1990346715973
UTimeOffset     3378461916015625
