Total: 574
TCP:   3517 (estab 298, closed 3200, orphaned 0, timewait 2737)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  317       308       9        
INET	  327       314       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:34501      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:30546 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.215.117%ens5:68         0.0.0.0:*    uid:192 ino:103714 sk:2 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31707 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14873 sk:4 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31706 sk:1001 cgroup:/ v6only:1 <->                                      
UNCONN 0      0                                [::1]:323           [::]:*    ino:14874 sk:1002 cgroup:unreachable:e8e v6only:1 <->                        
UNCONN 0      0      [fe80::8b6:a8ff:feb7:be01]%ens5:546           [::]:*    uid:192 ino:15940 sk:1003 cgroup:unreachable:bd0 v6only:1 <->                
