filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4c0bcb0c6283 direct-action not_in_hw id 553 tag 94e9140e82ab88c5 jited 
