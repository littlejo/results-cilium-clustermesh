1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b6:a8:b7:be:01 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.215.117/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3452sec preferred_lft 3452sec
    inet6 fe80::8b6:a8ff:feb7:be01/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:cb:03:95:8a:d5 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.205.108/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8cb:3ff:fe95:8ad5/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:19:f8:86:29:02 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d019:f8ff:fe86:2902/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:12:57:a8:de:56 brd ff:ff:ff:ff:ff:ff
    inet 10.53.0.137/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d012:57ff:fea8:de56/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 52:6c:cb:19:71:13 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::506c:cbff:fe19:7113/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:86:1f:35:05:18 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a086:1fff:fe35:518/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc65f814fd9713@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:13:13:c4:1c:bb brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f413:13ff:fec4:1cbb/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc4c0bcb0c6283@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:de:58:6c:12:02 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::14de:58ff:fe6c:1202/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc9697559c6bf1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:06:ab:32:eb:f1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6806:abff:fe32:ebf1/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcd7492c29c311@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:44:55:40:26:48 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2444:55ff:fe40:2648/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc1c599cbfcf31@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:b7:80:52:5d:1c brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::b7:80ff:fe52:5d1c/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcf985ec5798d7@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:15:49:b3:3c:7d brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::2015:49ff:feb3:3c7d/64 scope link 
       valid_lft forever preferred_lft forever
