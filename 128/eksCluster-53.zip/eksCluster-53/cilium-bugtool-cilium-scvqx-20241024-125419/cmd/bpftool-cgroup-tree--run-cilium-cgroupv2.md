CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ad65e53_2427_4ad6_b5e5_d7a81f0985f4.slice/cri-containerd-f3a2342ef578c7d80341cc06421693a7324248dad89b44d726a70637ec3332ac.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ad65e53_2427_4ad6_b5e5_d7a81f0985f4.slice/cri-containerd-90d5a19929305487f5126a0f8ca86e1b7602fe43c3feb2807edf2d2fcb11fdea.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff558691_ac6e_4130_9fb9_e0f0c7763208.slice/cri-containerd-9203588ed74ee8a2c5197b4abe91714eead777166b8b50990bf487af779e5b50.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff558691_ac6e_4130_9fb9_e0f0c7763208.slice/cri-containerd-dbf92a16cd329d40e19ed1938237e2b9f0b7a834bd1b9506676397b048930b8b.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ceb420a_3f2c_400e_9ac9_4e630db38775.slice/cri-containerd-005d80a4ff1558f1a43fc82cd30cdaec9d57b76087c56e31d248535e9a8c4508.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ceb420a_3f2c_400e_9ac9_4e630db38775.slice/cri-containerd-00306d6bd8de77a29fc2f4e6a9ce6df04a9cc219339f1e9caf84f0df92fffef4.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod77bab85e_84ab_4576_bf48_dbfcefc1f2da.slice/cri-containerd-e2efe36af69bb34e03794f09605f08a7bba3bcfa2370fbc775463da7aa064818.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod77bab85e_84ab_4576_bf48_dbfcefc1f2da.slice/cri-containerd-b6d58a10652e9f7eb1f26d72a92c197e75bbb9d0dc0c33d674d0f8f0446ef835.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod815d4554_910e_4e17_be14_994cffcb8728.slice/cri-containerd-ee7b929ba941c6c34251cecc9a6c6ffb590e2732377250ce7d62d66451fd7450.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod815d4554_910e_4e17_be14_994cffcb8728.slice/cri-containerd-cadfb00ec766375060157ccc3ebfa164bc74415768bfdfcfab2dfd5247d1a765.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod815d4554_910e_4e17_be14_994cffcb8728.slice/cri-containerd-56622b7d2ed7381d94c5442833def0b6a5d12411055f26d40ad66e89cb174f24.scope
    683      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a9e5f16_d4c9_40d7_84cb_9ac04858614a.slice/cri-containerd-2304da54e90784a44c392cb8c1665684cde8bf642d7c18e007e3fa1b5849d13d.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a9e5f16_d4c9_40d7_84cb_9ac04858614a.slice/cri-containerd-552e736e426a0d4c522aa228db548cee6e196f49d1b7f7fe2acc500ab196147e.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a439387_7d2c_4b49_9735_6cbc2e6207e2.slice/cri-containerd-e8d919340e7865023af80f833f77c7d95fa73373cbdd1b33526aad463706f41b.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a439387_7d2c_4b49_9735_6cbc2e6207e2.slice/cri-containerd-2a849e0e0e7ecf71846befd0aaad878ad727a8205e323b19b571712250303aad.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd624036d_7706_499a_a874_ce53cdbf75c4.slice/cri-containerd-a76a812a1db565f3398c8a08d29d005dd3b39853b6859c08fb1e591dc453ca49.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd624036d_7706_499a_a874_ce53cdbf75c4.slice/cri-containerd-363fd640db6f47e0c2c8184aae6072fd9c77e510d8e387bb4c87109988475c23.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067237f0_c55c_4ea9_ba84_e499db3dbb98.slice/cri-containerd-7e1d8543ebe36b7050c0176c5baa8411376857c95330f6d250d7abe8e48d4342.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067237f0_c55c_4ea9_ba84_e499db3dbb98.slice/cri-containerd-31f954e170e2fec3f7f2cad4c47d79fb1c2b135ea721b8a41e7985131b570152.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067237f0_c55c_4ea9_ba84_e499db3dbb98.slice/cri-containerd-42975a0efbc22594dd7f9a635adc7e5fe4b4c832c8f312d7740a05d7c6b2180c.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067237f0_c55c_4ea9_ba84_e499db3dbb98.slice/cri-containerd-bdacb831bada80446b5c79fdda11ba8c7afe2694d0149e2027121aa1aece0ef2.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb56a1d16_8481_4b20_9b63_0896c6219f68.slice/cri-containerd-ccdd2f2eac440d8cdba5621ab694edd222928fc5979c55406bdf096257e11adf.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb56a1d16_8481_4b20_9b63_0896c6219f68.slice/cri-containerd-2f9b3020b8727a8f4e8fe82c66de53b92ef9557ad15574d1db252617f19573b0.scope
    105      cgroup_device   multi                                          
