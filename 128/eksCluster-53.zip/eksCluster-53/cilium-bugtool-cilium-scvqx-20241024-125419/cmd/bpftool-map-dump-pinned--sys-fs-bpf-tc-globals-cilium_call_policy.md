key: 74 00 00 00  value: 21 0d 00 00
key: cf 03 00 00  value: 6f 02 00 00
key: a9 04 00 00  value: e4 0c 00 00
key: 77 07 00 00  value: 1e 0d 00 00
key: ad 08 00 00  value: 07 02 00 00
key: a7 0a 00 00  value: 27 02 00 00
key: 2b 0d 00 00  value: 2f 02 00 00
Found 7 elements
