alloc: 125.96MB (132078520 bytes)
total-alloc: 3.12GB (3346162896 bytes)
sys: 223.38MB (234235220 bytes)
lookups: 0
mallocs: 75579455
frees: 74346083
heap-alloc: 125.96MB (132078520 bytes)
heap-sys: 176.61MB (185188352 bytes)
heap-idle: 25.98MB (27246592 bytes)
heap-in-use: 150.62MB (157941760 bytes)
heap-released: 8.95MB (9379840 bytes)
heap-objects: 1233372
stack-in-use: 35.34MB (37060608 bytes)
stack-sys: 35.34MB (37060608 bytes)
stack-mspan-inuse: 2.35MB (2464800 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1023.17KB (1047729 bytes)
gc-sys: 5.58MB (5850160 bytes)
next-gc: when heap-alloc >= 153.00MB (160427720 bytes)
last-gc: 2024-10-24 12:54:22.667454282 +0000 UTC
gc-pause-total: 22.146508ms
gc-pause: 120591
gc-pause-end: 1729774462667454282
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0006260906339055798
enable-gc: true
debug-gc: false
