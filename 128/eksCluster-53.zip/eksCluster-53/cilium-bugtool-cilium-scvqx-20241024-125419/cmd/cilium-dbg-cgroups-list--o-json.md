[
  {
    "containers": [
      {
        "cgroup-id": 9946,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd624036d_7706_499a_a874_ce53cdbf75c4.slice/cri-containerd-363fd640db6f47e0c2c8184aae6072fd9c77e510d8e387bb4c87109988475c23.scope"
      }
    ],
    "ips": [
      "10.53.0.78"
    ],
    "name": "client2-57cf4468f-kcsk6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9190,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067237f0_c55c_4ea9_ba84_e499db3dbb98.slice/cri-containerd-7e1d8543ebe36b7050c0176c5baa8411376857c95330f6d250d7abe8e48d4342.scope"
      },
      {
        "cgroup-id": 9106,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067237f0_c55c_4ea9_ba84_e499db3dbb98.slice/cri-containerd-31f954e170e2fec3f7f2cad4c47d79fb1c2b135ea721b8a41e7985131b570152.scope"
      },
      {
        "cgroup-id": 9274,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067237f0_c55c_4ea9_ba84_e499db3dbb98.slice/cri-containerd-bdacb831bada80446b5c79fdda11ba8c7afe2694d0149e2027121aa1aece0ef2.scope"
      }
    ],
    "ips": [
      "10.53.0.68"
    ],
    "name": "clustermesh-apiserver-7fd5c96f6c-jz9r9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10030,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod815d4554_910e_4e17_be14_994cffcb8728.slice/cri-containerd-ee7b929ba941c6c34251cecc9a6c6ffb590e2732377250ce7d62d66451fd7450.scope"
      },
      {
        "cgroup-id": 10114,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod815d4554_910e_4e17_be14_994cffcb8728.slice/cri-containerd-cadfb00ec766375060157ccc3ebfa164bc74415768bfdfcfab2dfd5247d1a765.scope"
      }
    ],
    "ips": [
      "10.53.0.160"
    ],
    "name": "echo-same-node-86d9cc975c-g9jcs",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7582,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff558691_ac6e_4130_9fb9_e0f0c7763208.slice/cri-containerd-9203588ed74ee8a2c5197b4abe91714eead777166b8b50990bf487af779e5b50.scope"
      }
    ],
    "ips": [
      "10.53.0.179"
    ],
    "name": "coredns-cc6ccd49c-m89n8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7666,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ceb420a_3f2c_400e_9ac9_4e630db38775.slice/cri-containerd-00306d6bd8de77a29fc2f4e6a9ce6df04a9cc219339f1e9caf84f0df92fffef4.scope"
      }
    ],
    "ips": [
      "10.53.0.202"
    ],
    "name": "coredns-cc6ccd49c-vjwff",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9862,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a439387_7d2c_4b49_9735_6cbc2e6207e2.slice/cri-containerd-2a849e0e0e7ecf71846befd0aaad878ad727a8205e323b19b571712250303aad.scope"
      }
    ],
    "ips": [
      "10.53.0.15"
    ],
    "name": "client-974f6c69d-dk7qh",
    "namespace": "cilium-test-1"
  }
]

