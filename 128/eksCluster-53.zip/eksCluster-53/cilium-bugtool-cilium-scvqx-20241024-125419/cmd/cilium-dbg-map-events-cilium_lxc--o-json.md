{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.716Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.410Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.418Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.479Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.489Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.521Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.780Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.786Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.847Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.866Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.908Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.547Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.568Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.605Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.608Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.645Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.867Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.880Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.940Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.952Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.990Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.540Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.545Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.579Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.596Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.640Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.641Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.676Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.953Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.958Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.026Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.028Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.067Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.627Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.659Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.691Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.712Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.751Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.762Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.326Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.329Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.360Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.386Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.405Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.477Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.896Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.944Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.965Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.010Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.020Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.048Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.334Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.336Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.384Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.407Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.454Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.833Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.868Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.876Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.928Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.928Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.967Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.204Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.213Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.285Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.313Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.332Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.828Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.873Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.925Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.932Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.971Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.147Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.157Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.197Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.226Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.269Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.696Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.735Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.740Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.783Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.799Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.830Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.082Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.092Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.149Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.173Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.199Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.590Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.600Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.647Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.651Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.706Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.929Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.957Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.982Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.008Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.043Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.335Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.390Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.393Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.440Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.441Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.483Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.698Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.711Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.768Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.769Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.829Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.117Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.150Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.159Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.204Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.209Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.282Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.526Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.532Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.548Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.587Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.326Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.329Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.364Z",
  "value": "id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.381Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.407Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.702Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.703Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.418Z",
  "value": "id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.422Z",
  "value": "id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48"
}

