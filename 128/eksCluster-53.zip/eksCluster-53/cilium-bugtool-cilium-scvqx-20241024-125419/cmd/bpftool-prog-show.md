35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:45+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:45+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:45+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:45+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:50+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:28:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag 7784e790f35875a2  gpl
	loaded_at 2024-10-24T12:28:21+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:28:21+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:28:21+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
488: sched_cls  name tail_handle_ipv4_from_host  tag 3b7e5168d16c2b2d  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 129
489: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,101
	btf_id 130
491: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 132
492: sched_cls  name __send_drop_notify  tag 72abf04db3189f89  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 133
494: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 135
495: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 137
496: sched_cls  name tail_handle_ipv4_from_host  tag 3b7e5168d16c2b2d  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 138
499: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 141
500: sched_cls  name __send_drop_notify  tag 72abf04db3189f89  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 142
502: sched_cls  name __send_drop_notify  tag 72abf04db3189f89  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 145
503: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 146
504: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 147
505: sched_cls  name tail_handle_ipv4_from_host  tag 3b7e5168d16c2b2d  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 148
512: sched_cls  name __send_drop_notify  tag 72abf04db3189f89  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 156
513: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 157
514: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 158
515: sched_cls  name tail_handle_ipv4_from_host  tag 3b7e5168d16c2b2d  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 159
519: sched_cls  name handle_policy  tag 74c9015028de7eed  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 163
520: sched_cls  name cil_from_container  tag 36ee5e055f54a904  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 167
521: sched_cls  name tail_handle_arp  tag 1b55d00b245a86cb  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 168
522: sched_cls  name tail_ipv4_ct_ingress  tag 9ee632b76a37ba5b  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 169
525: sched_cls  name tail_handle_ipv4_cont  tag ed2cf190457b5419  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 170
526: sched_cls  name tail_ipv4_ct_egress  tag 825a09f2bd12b523  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 173
530: sched_cls  name tail_ipv4_to_endpoint  tag 37e36240d846d533  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 174
531: sched_cls  name tail_handle_ipv4  tag d920ecd7fc9f1f02  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 178
533: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 180
535: sched_cls  name __send_drop_notify  tag 341187622e3f1b7a  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 181
538: sched_cls  name tail_handle_arp  tag 5bb8db35cab56394  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 187
539: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 185
540: sched_cls  name __send_drop_notify  tag 1bd68aea1c3bd86f  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
541: sched_cls  name tail_ipv4_ct_ingress  tag 66a35d5fff1b3a88  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 190
542: sched_cls  name tail_handle_ipv4  tag ecea0f175ba432e8  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 188
543: sched_cls  name tail_handle_ipv4  tag a18c8d9607ec32c4  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 191
544: sched_cls  name tail_handle_ipv4_cont  tag 39258dfd8a652df8  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 192
545: sched_cls  name tail_ipv4_ct_ingress  tag 35244c205e1c09e2  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 194
546: sched_cls  name __send_drop_notify  tag 74e4a4b03f6f8269  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
547: sched_cls  name tail_ipv4_to_endpoint  tag ba4f87eb029cfc91  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 193
548: sched_cls  name tail_handle_arp  tag 1b1c2cd3d8f347c1  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 196
549: sched_cls  name tail_ipv4_ct_egress  tag 825a09f2bd12b523  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 197
550: sched_cls  name tail_ipv4_to_endpoint  tag 680868dee4447537  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,117,40,37,38
	btf_id 198
551: sched_cls  name handle_policy  tag 58f19a6d814f673e  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 199
552: sched_cls  name cil_from_container  tag eb9d75e2dd939330  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 200
553: sched_cls  name cil_from_container  tag 94e9140e82ab88c5  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 201
554: sched_cls  name tail_handle_ipv4_cont  tag 5dcf770cca2e7ac2  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,117,40,37,38,81
	btf_id 202
555: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 203
557: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 205
559: sched_cls  name handle_policy  tag 47e7e21f566fb437  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 207
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
567: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
575: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
615: sched_cls  name tail_ipv4_to_endpoint  tag 895e4e243445fbb0  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 221
616: sched_cls  name tail_handle_ipv4_cont  tag e93dc74b0a8688a7  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 222
617: sched_cls  name tail_ipv4_ct_egress  tag 36d45b5e6c4b324c  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 223
618: sched_cls  name __send_drop_notify  tag 6ecae6dacb538342  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 224
619: sched_cls  name cil_from_container  tag 461de8992c75f969  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 225
620: sched_cls  name tail_handle_ipv4  tag 83fb950013f989d7  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 226
621: sched_cls  name tail_handle_arp  tag d85bebbcde2bb94d  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 227
622: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 228
623: sched_cls  name handle_policy  tag 5216203b9f1d7e78  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 229
625: sched_cls  name tail_ipv4_ct_ingress  tag 5c2352adb37caed7  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 231
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
676: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
679: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
680: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
683: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
695: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
698: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3289: sched_cls  name tail_handle_arp  tag 2c87ebb68820fac6  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3077
3290: sched_cls  name tail_handle_ipv4  tag 3de3144e79f18c9c  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3078
3294: sched_cls  name tail_ipv4_ct_ingress  tag c602feee91bdd0e3  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3079
3295: sched_cls  name tail_ipv4_ct_egress  tag 50e418c87a5846f1  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3085
3296: sched_cls  name cil_from_container  tag e4aab941ef225814  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3086
3297: sched_cls  name tail_handle_ipv4_cont  tag 732a464bbd412321  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,146,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3087
3300: sched_cls  name handle_policy  tag b83395eb94a25629  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,146,39,84,75,40,37,38
	btf_id 3088
3303: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3092
3306: sched_cls  name tail_ipv4_to_endpoint  tag 01b23f2658c0c018  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,146,39,627,40,37,38
	btf_id 3094
3307: sched_cls  name __send_drop_notify  tag 822b7719b3185c55  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3097
3344: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3139
3345: sched_cls  name __send_drop_notify  tag 1efaec45cf8daa9e  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3140
3346: sched_cls  name tail_handle_ipv4_cont  tag 2bd69b2bb9fc9bdc  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,637,41,151,82,83,39,76,74,77,638,40,37,38,81
	btf_id 3137
3347: sched_cls  name __send_drop_notify  tag a033ad59b7bca6c7  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3142
3348: sched_cls  name tail_handle_ipv4_cont  tag d1fd8fac2b724f80  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,143,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3141
3350: sched_cls  name tail_handle_ipv4  tag f05217460e48b33d  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,638
	btf_id 3143
3351: sched_cls  name tail_handle_arp  tag a7a33fed1ee461f7  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,638
	btf_id 3146
3352: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,638
	btf_id 3147
3353: sched_cls  name tail_handle_ipv4  tag 1d79014f0bb6f700  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3145
3354: sched_cls  name tail_ipv4_ct_egress  tag 2b4c72d66756300e  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3148
3356: sched_cls  name tail_ipv4_to_endpoint  tag c430c02cb942b564  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,143,39,639,40,37,38
	btf_id 3149
3357: sched_cls  name tail_ipv4_ct_egress  tag 43683a896c4dc847  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3152
3358: sched_cls  name handle_policy  tag 06c16d3bd9fd549b  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,638,82,83,637,41,80,151,39,84,75,40,37,38
	btf_id 3151
3359: sched_cls  name tail_ipv4_ct_ingress  tag 39d8176afeee2ba4  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3154
3360: sched_cls  name cil_from_container  tag eef7ab4e9975c5b8  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,76
	btf_id 3155
3361: sched_cls  name handle_policy  tag 8987ea9a88dc110f  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,143,39,84,75,40,37,38
	btf_id 3153
3362: sched_cls  name tail_handle_arp  tag 3514031bf8ba18a3  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3157
3363: sched_cls  name tail_ipv4_to_endpoint  tag d78c5581afe3da1c  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,637,41,82,83,80,151,39,638,40,37,38
	btf_id 3156
3364: sched_cls  name tail_ipv4_ct_ingress  tag bf10345b2b284f36  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3158
3365: sched_cls  name cil_from_container  tag b775bb50919d96e3  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3159
