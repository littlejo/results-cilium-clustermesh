Node 0, zone      DMA    137    187     62     38     16      2     18     19      6      4     33 
Node 0, zone   Normal    129     12     13     19     20     10      0      2      1      4      7 
