IP ADDRESS         LOCAL ENDPOINT INFO
10.53.0.78:0       id=1911  sec_id=3542655 flags=0x0000 ifindex=24  mac=02:83:6C:C2:26:EC nodemac=22:15:49:B3:3C:7D   
10.53.0.179:0      id=2221  sec_id=3571696 flags=0x0000 ifindex=12  mac=5A:17:FD:47:BB:CC nodemac=F6:13:13:C4:1C:BB   
172.31.215.117:0   (localhost)                                                                                        
10.53.0.68:0       id=975   sec_id=3544008 flags=0x0000 ifindex=18  mac=B2:49:DD:7B:50:F8 nodemac=6A:06:AB:32:EB:F1   
172.31.205.108:0   (localhost)                                                                                        
10.53.0.15:0       id=116   sec_id=3546924 flags=0x0000 ifindex=20  mac=DE:F3:1E:2D:0B:54 nodemac=26:44:55:40:26:48   
10.53.0.160:0      id=1193  sec_id=3544967 flags=0x0000 ifindex=22  mac=9E:F1:9A:3D:C5:17 nodemac=02:B7:80:52:5D:1C   
10.53.0.202:0      id=2727  sec_id=3571696 flags=0x0000 ifindex=14  mac=B2:5A:02:24:0F:3E nodemac=16:DE:58:6C:12:02   
10.53.0.48:0       id=3371  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:9E:59:D3:23 nodemac=A2:86:1F:35:05:18     
10.53.0.137:0      (localhost)                                                                                        
