key: 01 00 00 00  value: ac 1f a0 1f 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f d7 75 10 94 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 35 00 ca 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 35 00 ca 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 35 00 b3 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ff 44 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 35 00 44 09 4b 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 35 00 a0 1f 90 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 35 00 b3 23 c1 00 00  00 00 00 00
Found 9 elements
