 12:54:20 up 32 min,  0 users,  load average: 0.41, 0.56, 0.32
