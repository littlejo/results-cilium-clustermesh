markdown output at /tmp/cilium-bugtool-20241024-125420.803+0000-UTC-259746416/cmd/cilium-debuginfo-20241024-125451.71+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125420.803+0000-UTC-259746416/cmd/cilium-debuginfo-20241024-125451.71+0000-UTC.json
