key: df 00 00 00  value: 0a 02 00 00
key: 25 01 00 00  value: ff 0c 00 00
key: 2d 02 00 00  value: 44 02 00 00
key: 45 02 00 00  value: 38 0d 00 00
key: a1 04 00 00  value: 41 02 00 00
key: 6e 05 00 00  value: 37 0d 00 00
key: 4d 0c 00 00  value: 80 02 00 00
Found 7 elements
