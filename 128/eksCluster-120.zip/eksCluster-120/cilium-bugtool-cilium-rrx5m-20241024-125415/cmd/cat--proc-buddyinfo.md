Node 0, zone      DMA     34     17     23     17      8      4      5      3      1      2     42 
Node 0, zone   Normal    596    138     38     27     31     10      8      6      3      3      5 
