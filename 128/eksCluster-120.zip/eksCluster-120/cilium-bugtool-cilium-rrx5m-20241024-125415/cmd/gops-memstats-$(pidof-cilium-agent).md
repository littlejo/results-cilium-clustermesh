alloc: 107.91MB (113156792 bytes)
total-alloc: 3.09GB (3321020696 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 75388267
frees: 74311679
heap-alloc: 107.91MB (113156792 bytes)
heap-sys: 176.73MB (185319424 bytes)
heap-idle: 42.53MB (44597248 bytes)
heap-in-use: 134.20MB (140722176 bytes)
heap-released: 8.12MB (8511488 bytes)
heap-objects: 1076588
stack-in-use: 35.22MB (36929536 bytes)
stack-sys: 35.22MB (36929536 bytes)
stack-mspan-inuse: 2.20MB (2306080 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 734.91KB (752545 bytes)
gc-sys: 5.53MB (5797008 bytes)
next-gc: when heap-alloc >= 154.56MB (162063160 bytes)
last-gc: 2024-10-24 12:54:23.406070466 +0000 UTC
gc-pause-total: 15.586025ms
gc-pause: 70836
gc-pause-end: 1729774463406070466
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.000714053904202367
enable-gc: true
debug-gc: false
