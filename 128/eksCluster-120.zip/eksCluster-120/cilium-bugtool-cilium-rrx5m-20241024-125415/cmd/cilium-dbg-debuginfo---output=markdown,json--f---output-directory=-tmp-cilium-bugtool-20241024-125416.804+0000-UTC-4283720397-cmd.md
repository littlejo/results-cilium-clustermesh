markdown output at /tmp/cilium-bugtool-20241024-125416.804+0000-UTC-4283720397/cmd/cilium-debuginfo-20241024-125447.796+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.804+0000-UTC-4283720397/cmd/cilium-debuginfo-20241024-125447.796+0000-UTC.json
