xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 552
ens6(5) clsact/ingress cil_from_netdev-ens6 id 563
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 536
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 575
lxc31cc74d88113(12) clsact/ingress cil_from_container-lxc31cc74d88113 id 528
lxc5c4d0eb24239(14) clsact/ingress cil_from_container-lxc5c4d0eb24239 id 559
lxc00142ac17bee(18) clsact/ingress cil_from_container-lxc00142ac17bee id 644
lxca244d4659878(20) clsact/ingress cil_from_container-lxca244d4659878 id 3371
lxcc02fc8f6e16b(22) clsact/ingress cil_from_container-lxcc02fc8f6e16b id 3376
lxc15156f9abd3d(24) clsact/ingress cil_from_container-lxc15156f9abd3d id 3322

flow_dissector:

netfilter:

