{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.675Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.700Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.727Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.740Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.997Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.008Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.045Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.067Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.112Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.731Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.772Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.774Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.821Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.829Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.068Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.093Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.122Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.169Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.177Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.717Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.721Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.757Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.767Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.804Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.821Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.842Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.051Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.064Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.099Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.128Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.155Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.678Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.682Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.728Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.733Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.771Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.780Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.804Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.069Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.077Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.127Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.134Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.175Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.629Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.683Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.690Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.731Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.739Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.779Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.979Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.988Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.045Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.055Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.084Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.507Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.517Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.561Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.572Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.600Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.847Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.856Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.901Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.919Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.944Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.275Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.344Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.388Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.400Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.477Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.506Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.669Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.691Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.713Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.752Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.762Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.179Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.218Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.219Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.283Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.288Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.328Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.343Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.615Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.635Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.670Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.684Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.726Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.165Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.202Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.259Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.265Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.294Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.474Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.513Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.631Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.652Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.674Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.868Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.903Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.908Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.950Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.964Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.982Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.204Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.230Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.278Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.297Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.329Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.626Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.681Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.691Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.736Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.738Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.769Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.989Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.991Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.005Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.010Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.028Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.651Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.656Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.697Z",
  "value": "id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.702Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.743Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.017Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.024Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.684Z",
  "value": "id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.689Z",
  "value": "id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04"
}

