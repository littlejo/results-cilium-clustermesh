CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod96533dd4_eaa4_454f_80e7_dc0f5724a46d.slice/cri-containerd-10f97da59dd63fa8c87b696ddf16aefc85441c7f8bc8b08c40a65b578bfc5bf2.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod96533dd4_eaa4_454f_80e7_dc0f5724a46d.slice/cri-containerd-7b45ccf74c817df4d84113ff58a98c35e1898bb94531ff4f3195b622f40234db.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcb1e9d6_b7b8_42aa_b78e_22279f1f6e4b.slice/cri-containerd-6d8fd6787071ad67a52b680a0959891904418c578e5814e695f2d16ce65e376d.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcb1e9d6_b7b8_42aa_b78e_22279f1f6e4b.slice/cri-containerd-0cc992407673e8eb2457c1a4ba7e473d67ca8c394af5d1f164a3517b94266390.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37fab5ba_df0f_4e00_863a_a1990ee99480.slice/cri-containerd-48af894566a1372a3ca730539413b1f01478eee735e0a2a2be68cd579f0c2f61.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37fab5ba_df0f_4e00_863a_a1990ee99480.slice/cri-containerd-e8921a54d8ab2394538ba8c2fbfca9644f0f57442e25474fc3c41dae2130d473.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda10af237_dca3_43ae_a3e3_8d6b510d0ff1.slice/cri-containerd-bc255b5e5fb9840244ebf9af1e24a8bd7eb29bdc9fc24580dffcded379d0209b.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda10af237_dca3_43ae_a3e3_8d6b510d0ff1.slice/cri-containerd-d66545b098c56a8b37f908d45fbf1dc10bf65229cb24e28fdecf2405dec4a865.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56a1c45c_c4d0_42b0_8c68_15b9b9538116.slice/cri-containerd-2c0e67dc6e134e847924166a43c0d4a80f448b80ef42147a064a96295081806d.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56a1c45c_c4d0_42b0_8c68_15b9b9538116.slice/cri-containerd-136aab25963c8b0907b6a90d0201c5bbb0be229c9b5a85f1fdc3a8608086aa65.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56a1c45c_c4d0_42b0_8c68_15b9b9538116.slice/cri-containerd-d05c813907201d5d75857566a75a0caac53673ce37148a2b5dac4f125c6121bc.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod069428e2_0ed7_4f48_98a4_63cd2c2aec5b.slice/cri-containerd-eb1e1ca35a530b25e87476f1f49dacd7675eec7fb002f352c88a82a4b0a2c1f8.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod069428e2_0ed7_4f48_98a4_63cd2c2aec5b.slice/cri-containerd-9aa965794feaec551f76dd6bc2b51db91eac2db316adcf0d61a134572a858650.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd33fc229_7870_41f7_a757_8fb4d9d310ea.slice/cri-containerd-11257fab88c19a56adbee2d24709fb9370548ca26c1d3a532d9598aaf7ba18b4.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd33fc229_7870_41f7_a757_8fb4d9d310ea.slice/cri-containerd-39bdde088ce05ab0de65f76bb410327fe66da94b3214b47c0502c4ca46c18475.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7cab2d73_e785_4ea0_b1fa_7291d5413889.slice/cri-containerd-44d774506220bf9f874501379ae987d6ac2f06d792478bd7cc8eb1bcc4f28838.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7cab2d73_e785_4ea0_b1fa_7291d5413889.slice/cri-containerd-369c9273fbb07c673ffa043a77e9de1417cad1b2a184f0bc3717ac7eee1456af.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7cab2d73_e785_4ea0_b1fa_7291d5413889.slice/cri-containerd-33ec8d7b531897b18c0e1a6e733ba2c6f2bf28996544c5ffe873f53d4d0ebde0.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7cab2d73_e785_4ea0_b1fa_7291d5413889.slice/cri-containerd-254a79e4e2cc64fbb457f06d250385ed6922bd5c00d79e4e4ab94b3ef209ccd4.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c986dd2_e6f6_4380_9a93_64da8d8e14d8.slice/cri-containerd-4cb6951a5041610b1bcbd0b369cf82349e6837cd97d83796732eaee2612b47d5.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c986dd2_e6f6_4380_9a93_64da8d8e14d8.slice/cri-containerd-08ed844e39a65dd8fd80e84e07e0798708bd73558a6eb95bc43d90468ffad7c3.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod897c049e_ece1_490d_b828_42e485b0277d.slice/cri-containerd-e194186fb384db49597270909a7716bc8a34dd07988d73af8690ed80f966d55d.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod897c049e_ece1_490d_b828_42e485b0277d.slice/cri-containerd-0530b539e4772d5a8d9ca81132a8f878afff150df0da76e5ffd5d9b4e5fd862c.scope
    727      cgroup_device   multi                                          
