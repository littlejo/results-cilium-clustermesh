 12:54:16 up 30 min,  0 users,  load average: 0.37, 0.52, 0.35
