Total: 569
TCP:   4452 (estab 291, closed 4142, orphaned 0, timewait 3682)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  310       300       10       
INET	  320       306       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.168.52%ens5:68         0.0.0.0:*    uid:192 ino:161630 sk:f90 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36174 sk:f91 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15510 sk:f92 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:39497      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:36086 sk:f93 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36173 sk:f94 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15511 sk:f95 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::4d7:e3ff:fe2b:ec4d]%ens5:546           [::]:*    uid:192 ino:15679 sk:f96 cgroup:unreachable:bd0 v6only:1 <->                   
