KEY             VALUE
AgentLiveness   1879642703723
UTimeOffset     3378462125000000
