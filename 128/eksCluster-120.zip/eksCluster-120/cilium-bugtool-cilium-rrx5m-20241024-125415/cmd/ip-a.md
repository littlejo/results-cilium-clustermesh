1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d7:e3:2b:ec:4d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.168.52/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3562sec preferred_lft 3562sec
    inet6 fe80::4d7:e3ff:fe2b:ec4d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:4f:45:43:7a:01 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.160.172/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::44f:45ff:fe43:7a01/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:5c:1a:3f:24:61 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::485c:1aff:fe3f:2461/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:cd:8d:ea:43:06 brd ff:ff:ff:ff:ff:ff
    inet 10.120.0.219/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::94cd:8dff:feea:4306/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:7d:41:bb:c3:fa brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f47d:41ff:febb:c3fa/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:60:69:12:1c:11 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7460:69ff:fe12:1c11/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc31cc74d88113@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:87:ba:1a:76:3d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b887:baff:fe1a:763d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5c4d0eb24239@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:af:e0:c7:84:81 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b8af:e0ff:fec7:8481/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc00142ac17bee@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:d1:34:dd:3f:16 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::48d1:34ff:fedd:3f16/64 scope link 
       valid_lft forever preferred_lft forever
20: lxca244d4659878@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:a0:20:12:cd:60 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::84a0:20ff:fe12:cd60/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcc02fc8f6e16b@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:1e:9a:21:28:04 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::d01e:9aff:fe21:2804/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc15156f9abd3d@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:e3:b5:47:4c:82 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::f0e3:b5ff:fe47:4c82/64 scope link 
       valid_lft forever preferred_lft forever
