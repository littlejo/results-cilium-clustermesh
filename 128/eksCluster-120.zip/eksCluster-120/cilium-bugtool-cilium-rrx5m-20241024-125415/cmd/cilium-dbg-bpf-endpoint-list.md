IP ADDRESS         LOCAL ENDPOINT INFO
10.120.0.219:0     (localhost)                                                                                        
10.120.0.21:0      id=3149  sec_id=7949692 flags=0x0000 ifindex=18  mac=E2:61:12:E5:7D:E8 nodemac=4A:D1:34:DD:3F:16   
10.120.0.131:0     id=293   sec_id=7966670 flags=0x0000 ifindex=24  mac=B6:1B:A2:38:D9:CC nodemac=F2:E3:B5:47:4C:82   
172.31.160.172:0   (localhost)                                                                                        
10.120.0.99:0      id=1185  sec_id=7943605 flags=0x0000 ifindex=14  mac=E2:30:2C:FC:7F:E3 nodemac=BA:AF:E0:C7:84:81   
172.31.168.52:0    (localhost)                                                                                        
10.120.0.85:0      id=223   sec_id=7943605 flags=0x0000 ifindex=12  mac=C2:96:1B:E3:88:5C nodemac=BA:87:BA:1A:76:3D   
10.120.0.24:0      id=1390  sec_id=7965029 flags=0x0000 ifindex=22  mac=7A:1C:AD:58:9C:92 nodemac=D2:1E:9A:21:28:04   
10.120.0.129:0     id=581   sec_id=7930117 flags=0x0000 ifindex=20  mac=9E:1C:15:EE:78:35 nodemac=86:A0:20:12:CD:60   
10.120.0.212:0     id=557   sec_id=4     flags=0x0000 ifindex=10  mac=2E:48:6B:1B:81:E2 nodemac=76:60:69:12:1C:11     
