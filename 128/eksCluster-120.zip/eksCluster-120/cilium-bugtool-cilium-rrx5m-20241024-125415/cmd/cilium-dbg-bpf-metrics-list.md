REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     132692    10764372    677    bpf_overlay.c
Interface                   INGRESS     668492    246948319   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      132859    10763944    53     encap.h
Success                     EGRESS      148695    19639523    1308   bpf_lxc.c
Success                     EGRESS      56440     4574354     1694   bpf_host.c
Success                     EGRESS      8580      1418181     86     l3.h
Success                     INGRESS     171648    19815255    86     l3.h
Success                     INGRESS     257111    27465924    235    trace.h
Unsupported L3 protocol     EGRESS      72        5440        1492   bpf_lxc.c
