[
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37fab5ba_df0f_4e00_863a_a1990ee99480.slice/cri-containerd-48af894566a1372a3ca730539413b1f01478eee735e0a2a2be68cd579f0c2f61.scope"
      }
    ],
    "ips": [
      "10.120.0.85"
    ],
    "name": "coredns-cc6ccd49c-lnw9c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd33fc229_7870_41f7_a757_8fb4d9d310ea.slice/cri-containerd-39bdde088ce05ab0de65f76bb410327fe66da94b3214b47c0502c4ca46c18475.scope"
      }
    ],
    "ips": [
      "10.120.0.129"
    ],
    "name": "client2-57cf4468f-2qrcz",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7cab2d73_e785_4ea0_b1fa_7291d5413889.slice/cri-containerd-254a79e4e2cc64fbb457f06d250385ed6922bd5c00d79e4e4ab94b3ef209ccd4.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7cab2d73_e785_4ea0_b1fa_7291d5413889.slice/cri-containerd-369c9273fbb07c673ffa043a77e9de1417cad1b2a184f0bc3717ac7eee1456af.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7cab2d73_e785_4ea0_b1fa_7291d5413889.slice/cri-containerd-44d774506220bf9f874501379ae987d6ac2f06d792478bd7cc8eb1bcc4f28838.scope"
      }
    ],
    "ips": [
      "10.120.0.21"
    ],
    "name": "clustermesh-apiserver-78c5b667c5-5vckw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod96533dd4_eaa4_454f_80e7_dc0f5724a46d.slice/cri-containerd-10f97da59dd63fa8c87b696ddf16aefc85441c7f8bc8b08c40a65b578bfc5bf2.scope"
      }
    ],
    "ips": [
      "10.120.0.99"
    ],
    "name": "coredns-cc6ccd49c-g9l9n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod897c049e_ece1_490d_b828_42e485b0277d.slice/cri-containerd-0530b539e4772d5a8d9ca81132a8f878afff150df0da76e5ffd5d9b4e5fd862c.scope"
      }
    ],
    "ips": [
      "10.120.0.24"
    ],
    "name": "client-974f6c69d-zqstx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56a1c45c_c4d0_42b0_8c68_15b9b9538116.slice/cri-containerd-d05c813907201d5d75857566a75a0caac53673ce37148a2b5dac4f125c6121bc.scope"
      },
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56a1c45c_c4d0_42b0_8c68_15b9b9538116.slice/cri-containerd-2c0e67dc6e134e847924166a43c0d4a80f448b80ef42147a064a96295081806d.scope"
      }
    ],
    "ips": [
      "10.120.0.131"
    ],
    "name": "echo-same-node-86d9cc975c-rkt87",
    "namespace": "cilium-test-1"
  }
]

