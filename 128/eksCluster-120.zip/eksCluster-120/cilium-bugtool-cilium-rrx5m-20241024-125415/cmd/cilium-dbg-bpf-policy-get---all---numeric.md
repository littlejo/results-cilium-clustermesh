Endpoint ID: 223
Path: /sys/fs/bpf/tc/globals/cilium_policy_00223

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    221529   2000      0        
Allow    Ingress     1          ANY          NONE         disabled    120173   1374      0        
Allow    Egress      0          ANY          NONE         disabled    63167    618       0        


Endpoint ID: 293
Path: /sys/fs/bpf/tc/globals/cilium_policy_00293

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377666   4394      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 557
Path: /sys/fs/bpf/tc/globals/cilium_policy_00557

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6235186   76917     0        
Allow    Ingress     1          ANY          NONE         disabled    61331     742       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 581
Path: /sys/fs/bpf/tc/globals/cilium_policy_00581

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1185
Path: /sys/fs/bpf/tc/globals/cilium_policy_01185

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    227267   2052      0        
Allow    Ingress     1          ANY          NONE         disabled    120371   1377      0        
Allow    Egress      0          ANY          NONE         disabled    65780    641       0        


Endpoint ID: 1220
Path: /sys/fs/bpf/tc/globals/cilium_policy_01220

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1390
Path: /sys/fs/bpf/tc/globals/cilium_policy_01390

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3149
Path: /sys/fs/bpf/tc/globals/cilium_policy_03149

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6124928   61641     0        
Allow    Ingress     1          ANY          NONE         disabled    5257675   55441     0        
Allow    Egress      0          ANY          NONE         disabled    6880467   67857     0        


