filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5c4d0eb24239 direct-action not_in_hw id 559 tag 0445ad4390c452c6 jited 
