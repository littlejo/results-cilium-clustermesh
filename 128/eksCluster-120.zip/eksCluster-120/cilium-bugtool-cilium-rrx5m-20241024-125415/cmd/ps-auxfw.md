USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3236  0.0  0.4 1240176 16376 ?       Dsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3251  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3253  0.0  0.4 1240176 16376 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3192  0.0  0.4 1229640 16684 ?       Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.9  7.5 1538804 295844 ?      Ssl  12:33   1:02 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.3  0.2 1229488 8816 ?        Sl   12:33   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
