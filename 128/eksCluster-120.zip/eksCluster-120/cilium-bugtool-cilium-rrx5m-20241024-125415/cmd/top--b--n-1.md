top - 12:54:17 up 30 min,  0 users,  load average: 0.37, 0.52, 0.35
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 35.7 us, 46.4 sy,  0.0 ni, 14.3 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   3836.2 total,    282.1 free,   1056.2 used,   2497.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2598.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3303 root      20   0 1244340  21072  14204 S  20.0   0.5   0:00.03 hubble
      1 root      20   0 1538804 296900  79168 S   6.7   7.6   1:02.95 cilium-+
   3236 root      20   0 1240432  16376  11420 S   6.7   0.4   0:00.03 cilium-+
    394 root      20   0 1229488   8816   2864 S   0.0   0.2   0:04.34 cilium-+
   3262 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3266 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3271 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3276 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3311 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
