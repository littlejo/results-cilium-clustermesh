filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc02fc8f6e16b direct-action not_in_hw id 3376 tag cdf3e76271dd6a4a jited 
