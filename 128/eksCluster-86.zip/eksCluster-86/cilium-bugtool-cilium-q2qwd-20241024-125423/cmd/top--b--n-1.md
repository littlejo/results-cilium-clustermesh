top - 12:54:25 up 31 min,  0 users,  load average: 0.20, 0.44, 0.27
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.7 us, 23.3 sy,  0.0 ni, 66.7 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    292.6 free,   1047.2 used,   2496.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2607.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3297 root      20   0 1240432  15836  10832 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1538804 290712  78144 S   0.0   7.4   1:05.75 cilium-+
    404 root      20   0 1229744   8900   2924 S   0.0   0.2   0:04.34 cilium-+
   3250 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3263 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3274 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3284 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3324 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3342 root      20   0 1228744   3976   3328 S   0.0   0.1   0:00.00 gops
