32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:36+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:36+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:37+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:37+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:37+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:37+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:41+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
111: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
114: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:30:47+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
482: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:30:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
483: sched_cls  name tail_handle_ipv4  tag 6b7c39926c5fa1aa  gpl
	loaded_at 2024-10-24T12:30:47+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:30:47+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
515: sched_cls  name tail_handle_arp  tag 08d4038f989208e6  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 165
516: sched_cls  name tail_ipv4_ct_ingress  tag cf6363b380e94b78  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 166
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 167
520: sched_cls  name tail_ipv4_to_endpoint  tag cb94ca28988dbc14  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 168
523: sched_cls  name handle_policy  tag fb5dd2b2d7f7651d  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 171
528: sched_cls  name tail_handle_ipv4_cont  tag a72cd59bb723309c  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 178
529: sched_cls  name __send_drop_notify  tag 30fbf788f9039f79  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
532: sched_cls  name tail_handle_ipv4  tag f1cc3287e38db5fe  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 180
533: sched_cls  name cil_from_container  tag 1ebc3aed33c3b001  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 182
534: sched_cls  name tail_ipv4_ct_egress  tag 5fb45cbeb24e512e  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 183
536: sched_cls  name tail_handle_ipv4_from_host  tag 72ec09a0feade336  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 188
537: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 189
538: sched_cls  name __send_drop_notify  tag e6fef2c0f4de883c  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 190
539: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 191
540: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 192
545: sched_cls  name tail_handle_ipv4_from_host  tag 72ec09a0feade336  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 198
546: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 199
547: sched_cls  name __send_drop_notify  tag e6fef2c0f4de883c  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
548: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 201
549: sched_cls  name __send_drop_notify  tag e6fef2c0f4de883c  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
550: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 204
553: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 207
554: sched_cls  name tail_handle_ipv4_from_host  tag 72ec09a0feade336  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 208
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 211
559: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 214
560: sched_cls  name handle_policy  tag 28a173b2cbe5f273  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 185
561: sched_cls  name tail_handle_ipv4_from_host  tag 72ec09a0feade336  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 215
564: sched_cls  name __send_drop_notify  tag e6fef2c0f4de883c  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
565: sched_cls  name __send_drop_notify  tag 06369972c6821bba  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 221
566: sched_cls  name cil_from_container  tag 659ed024e88205f4  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 222
567: sched_cls  name tail_ipv4_to_endpoint  tag b7ad77b51a06137b  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 219
568: sched_cls  name tail_ipv4_to_endpoint  tag d6b9a3ec12146a6f  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 223
569: sched_cls  name tail_handle_ipv4  tag 82ab1adacd775223  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 224
570: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 225
571: sched_cls  name tail_ipv4_ct_ingress  tag 060b9fc2f8ec807d  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 226
572: sched_cls  name tail_handle_arp  tag db010ffd45d3d8fe  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 227
573: sched_cls  name tail_handle_arp  tag 049722fa783f52b5  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 228
575: sched_cls  name tail_ipv4_ct_egress  tag 5fb45cbeb24e512e  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 229
576: sched_cls  name tail_ipv4_ct_ingress  tag bfb76b5350b0e238  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 231
577: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 232
578: sched_cls  name __send_drop_notify  tag 3d353bed446c5b06  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
579: sched_cls  name cil_from_container  tag ca9569e935c039eb  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 235
580: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 234
581: sched_cls  name tail_handle_ipv4_cont  tag 6ab037c5921892fc  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 236
582: sched_cls  name handle_policy  tag c52ad9f3c7cf8052  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 237
583: sched_cls  name tail_handle_ipv4  tag 5a751fa2efba0d05  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 238
584: sched_cls  name tail_handle_ipv4_cont  tag e5411a04886526f3  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 253
641: sched_cls  name tail_ipv4_to_endpoint  tag 669d14631dab2f62  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 254
642: sched_cls  name __send_drop_notify  tag 6eff42eaa3ab7f1f  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 255
643: sched_cls  name cil_from_container  tag 74791fe291c0e383  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 256
644: sched_cls  name tail_ipv4_ct_ingress  tag af7f44792e1637b3  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 257
645: sched_cls  name tail_handle_ipv4_cont  tag 1aa629026d489827  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 258
647: sched_cls  name tail_ipv4_ct_egress  tag 741d31ade9b63dd1  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 260
648: sched_cls  name tail_handle_ipv4  tag 6270651cb6c8df38  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 261
649: sched_cls  name tail_handle_arp  tag 4f45e8b035d9bbab  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 262
650: sched_cls  name handle_policy  tag 7efa0d1461d3d8ba  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
701: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
704: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
705: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
708: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
720: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
723: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
724: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
727: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
728: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
731: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
732: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
735: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
736: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
739: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3281: sched_cls  name tail_ipv4_ct_egress  tag c08ece361fe3d118  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,629,82,83,630,84
	btf_id 3073
3283: sched_cls  name tail_handle_ipv4  tag 8fd8b446365bfeb2  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,629
	btf_id 3075
3284: sched_cls  name tail_ipv4_ct_ingress  tag bdece3e5b693613f  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,629,82,83,630,84
	btf_id 3078
3287: sched_cls  name tail_ipv4_to_endpoint  tag 81bd8bed88677d2f  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,630,41,82,83,80,159,39,629,40,37,38
	btf_id 3079
3288: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,629
	btf_id 3081
3289: sched_cls  name cil_from_container  tag f28c40e1c7e3e9e2  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 629,76
	btf_id 3082
3293: sched_cls  name handle_policy  tag 988edc7b8ccc3f75  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,629,82,83,630,41,80,159,39,84,75,40,37,38
	btf_id 3083
3295: sched_cls  name __send_drop_notify  tag bea065a61d35deb3  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3088
3297: sched_cls  name tail_handle_arp  tag 7e5686154fa5d4a1  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,629
	btf_id 3090
3298: sched_cls  name tail_handle_ipv4_cont  tag 8850bbf9d24fc356  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,630,41,159,82,83,39,76,74,77,629,40,37,38,81
	btf_id 3091
3336: sched_cls  name tail_handle_arp  tag fb0e6d4140f58b9f  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3133
3337: sched_cls  name tail_handle_arp  tag 76427c187aa64cd6  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,642
	btf_id 3136
3338: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3135
3339: sched_cls  name tail_handle_ipv4_cont  tag 1996023231298950  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,641,41,151,82,83,39,76,74,77,642,40,37,38,81
	btf_id 3137
3341: sched_cls  name __send_drop_notify  tag dcf50ba72f73e434  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3140
3342: sched_cls  name tail_handle_ipv4  tag 8956c4a46258c6dc  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3138
3343: sched_cls  name tail_ipv4_ct_egress  tag dcfdabc0fafac4fb  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3141
3344: sched_cls  name tail_ipv4_ct_egress  tag 7f9e7efdcd16752d  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3142
3345: sched_cls  name cil_from_container  tag 5546b4749ff4ccbd  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3144
3347: sched_cls  name tail_handle_ipv4_cont  tag dbb8947d006d5366  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,154,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3146
3348: sched_cls  name tail_ipv4_to_endpoint  tag 21b72eff331e3138  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,641,41,82,83,80,151,39,642,40,37,38
	btf_id 3143
3349: sched_cls  name tail_ipv4_to_endpoint  tag 43934ac365a185bc  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,154,39,639,40,37,38
	btf_id 3147
3350: sched_cls  name tail_ipv4_ct_ingress  tag 218dab9a7c0e3dc1  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3149
3351: sched_cls  name handle_policy  tag eb024acf379773f2  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,642,82,83,641,41,80,151,39,84,75,40,37,38
	btf_id 3148
3352: sched_cls  name cil_from_container  tag b4156cf2760d0f67  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 642,76
	btf_id 3151
3353: sched_cls  name tail_ipv4_ct_ingress  tag 9016c6768f1cc3e9  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,642,82,83,641,84
	btf_id 3152
3354: sched_cls  name handle_policy  tag face6747a561d826  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,154,39,84,75,40,37,38
	btf_id 3150
3355: sched_cls  name __send_drop_notify  tag 831fd91e45215165  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3154
3356: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,642
	btf_id 3153
3357: sched_cls  name tail_handle_ipv4  tag 91f5f869d7beed57  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,642
	btf_id 3155
