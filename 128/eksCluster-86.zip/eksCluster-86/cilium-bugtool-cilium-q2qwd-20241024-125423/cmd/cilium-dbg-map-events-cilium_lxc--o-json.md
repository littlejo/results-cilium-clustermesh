{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.212Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.241Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.834Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.841Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.887Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.901Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.927Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.209Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.211Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.267Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.279Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.326Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.979Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.015Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.032Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.056Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.074Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.300Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.311Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.463Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.463Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.497Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.039Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.078Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.083Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.128Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.156Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.177Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.407Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.414Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.484Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.491Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.529Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.088Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.091Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.125Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.142Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.172Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.196Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.207Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.455Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.461Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.569Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.585Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.614Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.014Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.014Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.064Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.079Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.114Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.339Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.357Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.407Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.425Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.465Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.766Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.773Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.822Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.829Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.860Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.088Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.113Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.143Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.179Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.192Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.607Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.657Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.706Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.749Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.769Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.802Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.992Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.997Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.056Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.060Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.101Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.518Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.619Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.626Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.626Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.627Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.694Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.011Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.076Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.129Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.229Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.263Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.607Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.661Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.687Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.709Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.738Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.750Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.045Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.047Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.142Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.188Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.188Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.432Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.467Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.483Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.515Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.527Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.553Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.803Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.807Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.863Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.879Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.907Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.245Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.272Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.284Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.319Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.348Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.358Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.582Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.609Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.616Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.645Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.337Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.341Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.415Z",
  "value": "id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.450Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.488Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.724Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.740Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.368Z",
  "value": "id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.384Z",
  "value": "id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39"
}

