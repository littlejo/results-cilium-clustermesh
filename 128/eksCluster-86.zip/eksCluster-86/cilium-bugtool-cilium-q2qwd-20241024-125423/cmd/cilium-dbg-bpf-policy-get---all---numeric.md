Endpoint ID: 435
Path: /sys/fs/bpf/tc/globals/cilium_policy_00435

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 452
Path: /sys/fs/bpf/tc/globals/cilium_policy_00452

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6238754   77121     0        
Allow    Ingress     1          ANY          NONE         disabled    65622     794       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 534
Path: /sys/fs/bpf/tc/globals/cilium_policy_00534

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    920      10        0        
Allow    Ingress     1          ANY          NONE         disabled    139129   1605      0        
Allow    Egress      0          ANY          NONE         disabled    19849    220       0        


Endpoint ID: 853
Path: /sys/fs/bpf/tc/globals/cilium_policy_00853

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2347
Path: /sys/fs/bpf/tc/globals/cilium_policy_02347

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4976     50        0        
Allow    Ingress     1          ANY          NONE         disabled    139480   1606      0        
Allow    Egress      0          ANY          NONE         disabled    20461    227       0        


Endpoint ID: 2840
Path: /sys/fs/bpf/tc/globals/cilium_policy_02840

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6069389   61361     0        
Allow    Ingress     1          ANY          NONE         disabled    5784662   61254     0        
Allow    Egress      0          ANY          NONE         disabled    7438592   72972     0        


Endpoint ID: 3030
Path: /sys/fs/bpf/tc/globals/cilium_policy_03030

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    384058   4485      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3950
Path: /sys/fs/bpf/tc/globals/cilium_policy_03950

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


