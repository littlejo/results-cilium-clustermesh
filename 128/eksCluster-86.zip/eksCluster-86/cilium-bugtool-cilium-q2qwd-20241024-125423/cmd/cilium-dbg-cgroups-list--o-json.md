[
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0aed17aa_758e_46db_814d_c86de85e821a.slice/cri-containerd-aef1ac344f06c3088be41ebc811d0b6749b063ed4f9cf4d6e07e612a7960345a.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0aed17aa_758e_46db_814d_c86de85e821a.slice/cri-containerd-343db2dde6f8f6e5a28a108be72cf8b302cac1aab7de8cb415229a27656fb279.scope"
      }
    ],
    "ips": [
      "10.86.0.222"
    ],
    "name": "echo-same-node-86d9cc975c-phd2d",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88c2caa1_56c1_48c0_b208_ce133c6feadd.slice/cri-containerd-f247b1343e5d9591047ffd348fc16eec8db954fa5c7d807d99bb579362af9413.scope"
      }
    ],
    "ips": [
      "10.86.0.219"
    ],
    "name": "coredns-cc6ccd49c-lk949",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38b591f6_6ccd_491d_9395_67e9aeb9b2c7.slice/cri-containerd-a1315a95c6424a57b8e05368af357e0ca7192d3c501a132729174c4d007518b6.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38b591f6_6ccd_491d_9395_67e9aeb9b2c7.slice/cri-containerd-7859ce63a66009324f681f020b659e7e0752feff8008a7d79659280e703b6556.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38b591f6_6ccd_491d_9395_67e9aeb9b2c7.slice/cri-containerd-69befb1fc0f60d8b7ba6e8ee4cfa27f0ababd15edf4d51442adac293e441852a.scope"
      }
    ],
    "ips": [
      "10.86.0.96"
    ],
    "name": "clustermesh-apiserver-5fbc4d7f4b-k5rzs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a196f10_5a7c_4555_84cb_3a5140a48742.slice/cri-containerd-5f0aa13ddd50b1ee5eb3d6bc940b3b189d9d0fc55a7a9d80939d72d0e1e01766.scope"
      }
    ],
    "ips": [
      "10.86.0.47"
    ],
    "name": "coredns-cc6ccd49c-28v25",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod079b65d7_e829_46d7_9f5f_46eaa68822c4.slice/cri-containerd-8aba1f32fa2340e865c92e7a3a912409a7a1be5ad42bee85d2c24457aaff6f8f.scope"
      }
    ],
    "ips": [
      "10.86.0.99"
    ],
    "name": "client2-57cf4468f-gnbsr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2117e9f9_146a_4b72_9135_aefb605ee778.slice/cri-containerd-0979490fea0f4da0af7a92d0738f8142164486a954af74f81e6390182cf75273.scope"
      }
    ],
    "ips": [
      "10.86.0.227"
    ],
    "name": "client-974f6c69d-dwpnh",
    "namespace": "cilium-test-1"
  }
]

