alloc: 109.70MB (115031912 bytes)
total-alloc: 3.17GB (3400552208 bytes)
sys: 227.07MB (238101844 bytes)
lookups: 0
mallocs: 76542374
frees: 75427414
heap-alloc: 109.70MB (115031912 bytes)
heap-sys: 180.73MB (189513728 bytes)
heap-idle: 47.87MB (50192384 bytes)
heap-in-use: 132.87MB (139321344 bytes)
heap-released: 15.48MB (16228352 bytes)
heap-objects: 1114960
stack-in-use: 35.22MB (36929536 bytes)
stack-sys: 35.22MB (36929536 bytes)
stack-mspan-inuse: 2.18MB (2288800 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 759.15KB (777369 bytes)
gc-sys: 5.52MB (5788768 bytes)
next-gc: when heap-alloc >= 154.30MB (161798264 bytes)
last-gc: 2024-10-24 12:54:30.360076981 +0000 UTC
gc-pause-total: 16.795636ms
gc-pause: 70902
gc-pause-end: 1729774470360076981
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0006596637259021575
enable-gc: true
debug-gc: false
