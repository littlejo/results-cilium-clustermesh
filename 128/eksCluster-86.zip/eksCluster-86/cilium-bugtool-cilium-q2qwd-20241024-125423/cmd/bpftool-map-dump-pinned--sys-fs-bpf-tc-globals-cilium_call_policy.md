key: b3 01 00 00  value: 17 0d 00 00
key: c4 01 00 00  value: 46 02 00 00
key: 16 02 00 00  value: 30 02 00 00
key: 55 03 00 00  value: 1a 0d 00 00
key: 2b 09 00 00  value: 0b 02 00 00
key: 18 0b 00 00  value: 8a 02 00 00
key: d6 0b 00 00  value: dd 0c 00 00
Found 7 elements
