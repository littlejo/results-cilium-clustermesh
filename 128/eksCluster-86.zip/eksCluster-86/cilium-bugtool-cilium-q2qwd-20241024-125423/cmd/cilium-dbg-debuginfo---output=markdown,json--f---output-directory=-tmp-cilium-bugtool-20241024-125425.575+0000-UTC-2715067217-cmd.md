markdown output at /tmp/cilium-bugtool-20241024-125425.575+0000-UTC-2715067217/cmd/cilium-debuginfo-20241024-125455.913+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125425.575+0000-UTC-2715067217/cmd/cilium-debuginfo-20241024-125455.913+0000-UTC.json
