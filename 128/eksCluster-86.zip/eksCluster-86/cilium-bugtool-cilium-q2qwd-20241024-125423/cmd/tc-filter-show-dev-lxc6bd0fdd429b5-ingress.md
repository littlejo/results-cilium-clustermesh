filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6bd0fdd429b5 direct-action not_in_hw id 3352 tag b4156cf2760d0f67 jited 
