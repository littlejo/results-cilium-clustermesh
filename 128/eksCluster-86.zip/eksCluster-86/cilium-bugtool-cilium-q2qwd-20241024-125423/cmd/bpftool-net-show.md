xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 553
ens6(5) clsact/ingress cil_from_netdev-ens6 id 559
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 546
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 537
cilium_host(7) clsact/egress cil_from_host-cilium_host id 540
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 566
lxcee24d791d39e(12) clsact/ingress cil_from_container-lxcee24d791d39e id 533
lxc8b7557b83115(14) clsact/ingress cil_from_container-lxc8b7557b83115 id 579
lxcba35bba95f22(18) clsact/ingress cil_from_container-lxcba35bba95f22 id 643
lxc6bd0fdd429b5(20) clsact/ingress cil_from_container-lxc6bd0fdd429b5 id 3352
lxc4686f2b40e8b(22) clsact/ingress cil_from_container-lxc4686f2b40e8b id 3345
lxc703237af08bb(24) clsact/ingress cil_from_container-lxc703237af08bb id 3289

flow_dissector:

netfilter:

