REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     136344    11052875    677    bpf_overlay.c
Interface                   INGRESS     694233    249515433   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      138121    11188663    53     encap.h
Success                     EGRESS      154815    20276129    1308   bpf_lxc.c
Success                     EGRESS      596       156299      86     l3.h
Success                     EGRESS      59900     4860197     1694   bpf_host.c
Success                     INGRESS     179813    20669399    86     l3.h
Success                     INGRESS     257484    27060846    235    trace.h
Unsupported L3 protocol     EGRESS      70        5264        1492   bpf_lxc.c
