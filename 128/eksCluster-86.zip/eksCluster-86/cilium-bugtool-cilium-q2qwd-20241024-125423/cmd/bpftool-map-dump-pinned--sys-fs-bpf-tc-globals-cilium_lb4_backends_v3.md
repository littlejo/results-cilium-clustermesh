key: 01 00 00 00  value: ac 1f 84 29 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 56 00 db 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 56 00 60 09 4b 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 56 00 db 23 c1 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 56 00 de 1f 90 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 86 76 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ca 67 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 56 00 2f 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 56 00 2f 00 35 00 00  00 00 00 00
Found 9 elements
