Node 0, zone      DMA      0     33      3      3     26     12     19     15      9      4     39 
Node 0, zone   Normal    184     10      9     10      2      1      2      2      1      5      7 
