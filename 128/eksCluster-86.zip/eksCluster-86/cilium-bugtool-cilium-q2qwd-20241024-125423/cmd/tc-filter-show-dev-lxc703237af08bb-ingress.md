filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc703237af08bb direct-action not_in_hw id 3289 tag f28c40e1c7e3e9e2 jited 
