1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:57:11:a1:82:c1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.134.118/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3499sec preferred_lft 3499sec
    inet6 fe80::457:11ff:fea1:82c1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ea:5b:a3:a2:1d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.182.127/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ea:5bff:fea3:a21d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:c4:7a:96:60:a4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::64c4:7aff:fe96:60a4/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:f4:05:ba:02:c1 brd ff:ff:ff:ff:ff:ff
    inet 10.86.0.191/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1cf4:5ff:feba:2c1/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:90:28:9a:24:ba brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d890:28ff:fe9a:24ba/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:36:db:9f:87:43 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b036:dbff:fe9f:8743/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcee24d791d39e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:ec:a7:49:ed:0a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::98ec:a7ff:fe49:ed0a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8b7557b83115@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:db:82:0a:b6:74 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::70db:82ff:fe0a:b674/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcba35bba95f22@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:6f:c0:e2:99:42 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d06f:c0ff:fee2:9942/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc6bd0fdd429b5@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:42:9f:9c:8e:39 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6442:9fff:fe9c:8e39/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc4686f2b40e8b@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:23:89:48:43:dc brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::f423:89ff:fe48:43dc/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc703237af08bb@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:98:c2:a9:7d:d5 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::f498:c2ff:fea9:7dd5/64 scope link 
       valid_lft forever preferred_lft forever
