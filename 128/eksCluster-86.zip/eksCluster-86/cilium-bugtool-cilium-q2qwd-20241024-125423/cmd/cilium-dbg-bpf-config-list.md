KEY             VALUE
AgentLiveness   1942544611215
UTimeOffset     3378462017578125
