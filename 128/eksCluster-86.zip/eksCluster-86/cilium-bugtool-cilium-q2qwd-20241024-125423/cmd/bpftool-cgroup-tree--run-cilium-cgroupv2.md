CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda262bda1_ea49_4cf7_89c3_de2e6dedead3.slice/cri-containerd-cdc3a3218bdbe1d793d2f3cb0013e4fddac3c6a824e90503d48a3fd7d2a11095.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda262bda1_ea49_4cf7_89c3_de2e6dedead3.slice/cri-containerd-fa531f8070789d525148c3ab39da3e345f5ca13a6d49d82b8ef791c4d1b48146.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a196f10_5a7c_4555_84cb_3a5140a48742.slice/cri-containerd-0ede46f27a972befb03b809bd4537ffbb87566a0614e883502cf0b8f3761b491.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a196f10_5a7c_4555_84cb_3a5140a48742.slice/cri-containerd-5f0aa13ddd50b1ee5eb3d6bc940b3b189d9d0fc55a7a9d80939d72d0e1e01766.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9bdb0f0_65d9_4bcc_a229_29eaf9fb0bcd.slice/cri-containerd-3c3ea08b5a6209f33b4cdaff8dbde2a9572096f782df0ff97dfe7322b9d5ca68.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9bdb0f0_65d9_4bcc_a229_29eaf9fb0bcd.slice/cri-containerd-f5cf6d23030b26d5c736d815a7931dd6c99c4a565a8c9d698941505cd621a225.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88c2caa1_56c1_48c0_b208_ce133c6feadd.slice/cri-containerd-f247b1343e5d9591047ffd348fc16eec8db954fa5c7d807d99bb579362af9413.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88c2caa1_56c1_48c0_b208_ce133c6feadd.slice/cri-containerd-0efd6c72a0fcefd165c6bea4879aec629bcedd92e827f1bc3abd0c5ca244e579.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9e5bee73_09f2_4a60_a14e_011f16b26bda.slice/cri-containerd-ac2714791b773661c9874f670ba70803316911164bbda326a1c1e41db772944c.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9e5bee73_09f2_4a60_a14e_011f16b26bda.slice/cri-containerd-93378c7296999b4e418f42fb2389d3746d76a321fffbf469ca29aeec13c96af4.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbe8fad4f_56b5_4619_8fa7_760adbb11e9a.slice/cri-containerd-b58394fac6dd437bf47c791eb90063a3e3778b62c53e99101a8a3ea6f42e020e.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbe8fad4f_56b5_4619_8fa7_760adbb11e9a.slice/cri-containerd-e66dd437206c3f5c31d7337f4e364ba26bb2664a2db0e24508517b006a797a73.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod079b65d7_e829_46d7_9f5f_46eaa68822c4.slice/cri-containerd-8aba1f32fa2340e865c92e7a3a912409a7a1be5ad42bee85d2c24457aaff6f8f.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod079b65d7_e829_46d7_9f5f_46eaa68822c4.slice/cri-containerd-59955d792541e851a72493eabc911e5482acf0e9984f8c97f7d03517b3dd446f.scope
    708      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2117e9f9_146a_4b72_9135_aefb605ee778.slice/cri-containerd-0979490fea0f4da0af7a92d0738f8142164486a954af74f81e6390182cf75273.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2117e9f9_146a_4b72_9135_aefb605ee778.slice/cri-containerd-26b788d3c8499deea5fe27db5e7f0e24a0ad14a30207167f218e0be3715345ce.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38b591f6_6ccd_491d_9395_67e9aeb9b2c7.slice/cri-containerd-a1315a95c6424a57b8e05368af357e0ca7192d3c501a132729174c4d007518b6.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38b591f6_6ccd_491d_9395_67e9aeb9b2c7.slice/cri-containerd-69befb1fc0f60d8b7ba6e8ee4cfa27f0ababd15edf4d51442adac293e441852a.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38b591f6_6ccd_491d_9395_67e9aeb9b2c7.slice/cri-containerd-b5780ddae418411bffa9d3fff6059fea2335c228a5f561071c6ef420ba909da6.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38b591f6_6ccd_491d_9395_67e9aeb9b2c7.slice/cri-containerd-7859ce63a66009324f681f020b659e7e0752feff8008a7d79659280e703b6556.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0aed17aa_758e_46db_814d_c86de85e821a.slice/cri-containerd-343db2dde6f8f6e5a28a108be72cf8b302cac1aab7de8cb415229a27656fb279.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0aed17aa_758e_46db_814d_c86de85e821a.slice/cri-containerd-00d2b84adab08a8b366ba26203dfbc92ab759e670d949392bd1bfeee116927fb.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0aed17aa_758e_46db_814d_c86de85e821a.slice/cri-containerd-aef1ac344f06c3088be41ebc811d0b6749b063ed4f9cf4d6e07e612a7960345a.scope
    739      cgroup_device   multi                                          
