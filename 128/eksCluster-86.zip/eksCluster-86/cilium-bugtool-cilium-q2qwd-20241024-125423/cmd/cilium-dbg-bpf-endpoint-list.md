IP ADDRESS         LOCAL ENDPOINT INFO
10.86.0.219:0      id=2347  sec_id=5725517 flags=0x0000 ifindex=12  mac=EE:0A:36:73:DF:A4 nodemac=9A:EC:A7:49:ED:0A   
10.86.0.191:0      (localhost)                                                                                        
10.86.0.160:0      id=452   sec_id=4     flags=0x0000 ifindex=10  mac=4A:87:00:A1:22:A6 nodemac=B2:36:DB:9F:87:43     
10.86.0.47:0       id=534   sec_id=5725517 flags=0x0000 ifindex=14  mac=82:11:B4:CD:24:48 nodemac=72:DB:82:0A:B6:74   
10.86.0.222:0      id=3030  sec_id=5723676 flags=0x0000 ifindex=24  mac=56:0E:37:38:D8:D7 nodemac=F6:98:C2:A9:7D:D5   
172.31.134.118:0   (localhost)                                                                                        
10.86.0.227:0      id=435   sec_id=5710466 flags=0x0000 ifindex=20  mac=82:E1:7F:8A:43:F3 nodemac=66:42:9F:9C:8E:39   
10.86.0.96:0       id=2840  sec_id=5704835 flags=0x0000 ifindex=18  mac=5E:7A:90:13:E9:E5 nodemac=D2:6F:C0:E2:99:42   
10.86.0.99:0       id=853   sec_id=5753031 flags=0x0000 ifindex=22  mac=72:E8:32:2D:DC:D5 nodemac=F6:23:89:48:43:DC   
172.31.182.127:0   (localhost)                                                                                        
