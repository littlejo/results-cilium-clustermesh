markdown output at /tmp/cilium-bugtool-20241024-125417.39+0000-UTC-903800159/cmd/cilium-debuginfo-20241024-125448.191+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.39+0000-UTC-903800159/cmd/cilium-debuginfo-20241024-125448.191+0000-UTC.json
