CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod276f3464_d60a_4202_9b60_ffdc888456f4.slice/cri-containerd-88ed774216ed285265805160d0e53de6816329ab2ee6cc037864cbc02aae800f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod276f3464_d60a_4202_9b60_ffdc888456f4.slice/cri-containerd-f19015000b17dc2cc2e36e5ebbae886ebb9fffe63a333a9601fbba643fe750a6.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda486be79_83ab_40a8_be51_510c74a74fdf.slice/cri-containerd-5698f068fb17c91d4080253d2dc12978a77e6688cab8d85843888460a2852eb8.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda486be79_83ab_40a8_be51_510c74a74fdf.slice/cri-containerd-104ec393ef3ad87319d00765706ad072772d53415523da73cbee69b3923e93f3.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4abd2834_1764_40ec_aa09_6d429acd3488.slice/cri-containerd-9141f947a31c346d3ad0d878e63fdc4c75d795bb15194b766d151f1857fbc782.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4abd2834_1764_40ec_aa09_6d429acd3488.slice/cri-containerd-396059b1738af4013a1be6c4a5226376d9bebe6dc861715350268558c4772cf7.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podee30bebb_d69c_4850_afbf_c6e1a689ff8c.slice/cri-containerd-4d13b92bd49e5482136d16c3aafe4add55d8014d66d958736fbb6236a77110c6.scope
    581      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podee30bebb_d69c_4850_afbf_c6e1a689ff8c.slice/cri-containerd-1a6dec31baa61c0158e66b5290331914a361599fa4675f3997a0115557eef00a.scope
    577      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89a0dc5f_e46e_44d5_8593_6b64339f67bc.slice/cri-containerd-647bc55531f8dc4289f77f201a2294ea9715a6280e0231181bc4d8521def0f37.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89a0dc5f_e46e_44d5_8593_6b64339f67bc.slice/cri-containerd-2504b1856c3ff34db60af0aa831e595c3eef1939c7f934d70229bfae76f2806c.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda536a482_6772_4b00_aef0_04ed6735ec23.slice/cri-containerd-1ad944fd19583d8df7b0af4a7a6c054274fed32d925ed25727cf937f28f41ef5.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda536a482_6772_4b00_aef0_04ed6735ec23.slice/cri-containerd-79e2de2dbcdce528de619a0a4add6b1bf762942c705c79bf475315b8879ee936.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda536a482_6772_4b00_aef0_04ed6735ec23.slice/cri-containerd-3500ae9dc6850eb827828e10a3f247abf4fe4a6c675c36ed728d577fa3ee1a0f.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc315bfe1_1ed5_45fd_9d64_4a66e4b0c825.slice/cri-containerd-b98a3524452ca0cdafc729d7ce5accd4e106c600bfe9c6a0fe78e8e06e22ccea.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc315bfe1_1ed5_45fd_9d64_4a66e4b0c825.slice/cri-containerd-e48ebe03a1d3abcd702dffa4863ff2a81f62d4123c7653f44e989d803e1c32ff.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc315bfe1_1ed5_45fd_9d64_4a66e4b0c825.slice/cri-containerd-97649a4ddf7957f4fec7009697edd78e8daf8f1a6be5c3368f0ec6b7a3f89b54.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc315bfe1_1ed5_45fd_9d64_4a66e4b0c825.slice/cri-containerd-0b603f9272d79def529addc747400dafc9bbc96e7b012a633fe8f753e9ffbd15.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f3ac361_6f2d_4422_b95b_4e17cd23aab7.slice/cri-containerd-43ec14954c7fb380f6eed266d1395f8792bc11a6731840ff3b27884b21beed33.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f3ac361_6f2d_4422_b95b_4e17cd23aab7.slice/cri-containerd-93e953d779f246362e3566427cfa44ac66c06136010bf7474f1867aafe513395.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda04dbf6a_79ec_45f8_a57d_73a12eed7547.slice/cri-containerd-568e543ddf483328bb07260e7256f8a17188edba005715ee6ed4480df8a12225.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda04dbf6a_79ec_45f8_a57d_73a12eed7547.slice/cri-containerd-bdd918166b464bdbe155e6dd06cc00e42b1aa437b6c33ca4b3ce2163e66d464d.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6dbf114_7f2a_43ad_9ef0_00a61d693b32.slice/cri-containerd-795786ed20a0ba074324d578598d0bcec72f8535950777604772273a66e5fc75.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6dbf114_7f2a_43ad_9ef0_00a61d693b32.slice/cri-containerd-659ed5a32f172a07be3156622f3cf49eb6402a652f98414f39e08e9110ddbeb3.scope
    727      cgroup_device   multi                                          
