1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:18:b5:6f:35:c7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.129.74/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3409sec preferred_lft 3409sec
    inet6 fe80::418:b5ff:fe6f:35c7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:eb:5b:97:6d:59 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.181.235/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4eb:5bff:fe97:6d59/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:88:d5:23:b2:df brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c88:d5ff:fe23:b2df/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:89:dc:34:b6:ec brd ff:ff:ff:ff:ff:ff
    inet 10.20.0.76/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9489:dcff:fe34:b6ec/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5e:b6:f0:7b:5e:a1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5cb6:f0ff:fe7b:5ea1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:36:37:01:96:50 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5036:37ff:fe01:9650/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb3a7e883356f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:12:89:35:e4:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4412:89ff:fe35:e4c6/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc33dcd1dee812@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:dc:1c:17:18:7e brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::cdc:1cff:fe17:187e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd751748a2944@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:58:6c:87:62:aa brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ac58:6cff:fe87:62aa/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcecd058b34828@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:eb:22:2d:82:77 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::cceb:22ff:fe2d:8277/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc743964c7e5f6@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:a7:a5:a4:22:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::a8a7:a5ff:fea4:22e2/64 scope link 
       valid_lft forever preferred_lft forever
24: lxca7e3694c04d7@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:b4:73:d7:0c:60 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::1cb4:73ff:fed7:c60/64 scope link 
       valid_lft forever preferred_lft forever
