Endpoint ID: 16
Path: /sys/fs/bpf/tc/globals/cilium_policy_00016

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6934     75        0        
Allow    Ingress     1          ANY          NONE         disabled    164258   1885      0        
Allow    Egress      0          ANY          NONE         disabled    22071    248       0        


Endpoint ID: 389
Path: /sys/fs/bpf/tc/globals/cilium_policy_00389

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6274658   77574     0        
Allow    Ingress     1          ANY          NONE         disabled    27200     318       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 596
Path: /sys/fs/bpf/tc/globals/cilium_policy_00596

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6006596   60970     0        
Allow    Ingress     1          ANY          NONE         disabled    5631061   59585     0        
Allow    Egress      0          ANY          NONE         disabled    7667108   74845     0        


Endpoint ID: 691
Path: /sys/fs/bpf/tc/globals/cilium_policy_00691

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 778
Path: /sys/fs/bpf/tc/globals/cilium_policy_00778

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1993
Path: /sys/fs/bpf/tc/globals/cilium_policy_01993

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4442     49        0        
Allow    Ingress     1          ANY          NONE         disabled    165321   1903      0        
Allow    Egress      0          ANY          NONE         disabled    21477    241       0        


Endpoint ID: 2329
Path: /sys/fs/bpf/tc/globals/cilium_policy_02329

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3913
Path: /sys/fs/bpf/tc/globals/cilium_policy_03913

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4829     39        0        
Allow    Ingress     1          ANY          NONE         disabled    375754   4380      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


