[
  {
    "containers": [
      {
        "cgroup-id": 7488,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podee30bebb_d69c_4850_afbf_c6e1a689ff8c.slice/cri-containerd-4d13b92bd49e5482136d16c3aafe4add55d8014d66d958736fbb6236a77110c6.scope"
      }
    ],
    "ips": [
      "10.20.0.90"
    ],
    "name": "coredns-cc6ccd49c-68c9x",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc315bfe1_1ed5_45fd_9d64_4a66e4b0c825.slice/cri-containerd-97649a4ddf7957f4fec7009697edd78e8daf8f1a6be5c3368f0ec6b7a3f89b54.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc315bfe1_1ed5_45fd_9d64_4a66e4b0c825.slice/cri-containerd-0b603f9272d79def529addc747400dafc9bbc96e7b012a633fe8f753e9ffbd15.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc315bfe1_1ed5_45fd_9d64_4a66e4b0c825.slice/cri-containerd-b98a3524452ca0cdafc729d7ce5accd4e106c600bfe9c6a0fe78e8e06e22ccea.scope"
      }
    ],
    "ips": [
      "10.20.0.25"
    ],
    "name": "clustermesh-apiserver-6f6cff888f-57vv2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6dbf114_7f2a_43ad_9ef0_00a61d693b32.slice/cri-containerd-659ed5a32f172a07be3156622f3cf49eb6402a652f98414f39e08e9110ddbeb3.scope"
      }
    ],
    "ips": [
      "10.20.0.191"
    ],
    "name": "client-974f6c69d-2ckqd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4abd2834_1764_40ec_aa09_6d429acd3488.slice/cri-containerd-9141f947a31c346d3ad0d878e63fdc4c75d795bb15194b766d151f1857fbc782.scope"
      }
    ],
    "ips": [
      "10.20.0.84"
    ],
    "name": "coredns-cc6ccd49c-lhbbh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f3ac361_6f2d_4422_b95b_4e17cd23aab7.slice/cri-containerd-93e953d779f246362e3566427cfa44ac66c06136010bf7474f1867aafe513395.scope"
      }
    ],
    "ips": [
      "10.20.0.67"
    ],
    "name": "client2-57cf4468f-bscww",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda536a482_6772_4b00_aef0_04ed6735ec23.slice/cri-containerd-3500ae9dc6850eb827828e10a3f247abf4fe4a6c675c36ed728d577fa3ee1a0f.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda536a482_6772_4b00_aef0_04ed6735ec23.slice/cri-containerd-1ad944fd19583d8df7b0af4a7a6c054274fed32d925ed25727cf937f28f41ef5.scope"
      }
    ],
    "ips": [
      "10.20.0.124"
    ],
    "name": "echo-same-node-86d9cc975c-7cfzb",
    "namespace": "cilium-test-1"
  }
]

