{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.135Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.171Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.610Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.618Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.693Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.725Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.784Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.977Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.996Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.034Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.071Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.076Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.490Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.494Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.543Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.548Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.581Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.798Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.808Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.866Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.876Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.906Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.295Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.359Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.372Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.398Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.415Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.441Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.667Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.687Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.817Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.829Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.867Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.250Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.278Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.304Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.335Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.361Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.380Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.631Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.644Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.704Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.716Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.749Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.153Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.214Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.225Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.260Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.268Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.299Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.503Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.519Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.563Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.585Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.607Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.872Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.952Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.972Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.029Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.030Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.036Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.221Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.224Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.279Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.302Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.325Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.606Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.644Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.657Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.707Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.708Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.746Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.998Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.009Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.018Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.033Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.048Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.691Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.694Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.728Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.752Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.777Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.044Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.050Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.758Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.771Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:40.331Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:47.229Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:47.526Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:54.399Z",
  "value": "id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:54.707Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:54.711Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:54.739Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:01.607Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:01.655Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:01.673Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:01.974Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:01.978Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:01.987Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:08.797Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:08.836Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:08.866Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:09.198Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:09.202Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:09.211Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:22.230Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:22.289Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:22.296Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:22.610Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:22.627Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:22.633Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:35.638Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:35.673Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:35.688Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:36.050Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:36.060Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:36.063Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:49.100Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:49.134Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:49.151Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:49.569Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:52:49.577Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:53:06.560Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:53:06.562Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:53:06.859Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:53:06.865Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:53:19.980Z",
  "value": "id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:53:20.015Z",
  "value": "id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60"
}

