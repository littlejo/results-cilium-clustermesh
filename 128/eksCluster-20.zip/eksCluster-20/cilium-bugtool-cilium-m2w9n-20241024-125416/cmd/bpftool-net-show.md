xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 562
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 539
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 573
lxcb3a7e883356f(12) clsact/ingress cil_from_container-lxcb3a7e883356f id 521
lxc33dcd1dee812(14) clsact/ingress cil_from_container-lxc33dcd1dee812 id 591
lxcd751748a2944(18) clsact/ingress cil_from_container-lxcd751748a2944 id 642
lxcecd058b34828(20) clsact/ingress cil_from_container-lxcecd058b34828 id 3713
lxc743964c7e5f6(22) clsact/ingress cil_from_container-lxc743964c7e5f6 id 3404
lxca7e3694c04d7(24) clsact/ingress cil_from_container-lxca7e3694c04d7 id 3699

flow_dissector:

netfilter:

