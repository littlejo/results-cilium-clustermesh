 12:54:17 up 33 min,  0 users,  load average: 0.25, 0.54, 0.32
