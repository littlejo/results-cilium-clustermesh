IP ADDRESS         LOCAL ENDPOINT INFO
10.20.0.76:0       (localhost)                                                                                        
10.20.0.67:0       id=2329  sec_id=1380324 flags=0x0000 ifindex=24  mac=06:9D:3E:18:D0:23 nodemac=1E:B4:73:D7:0C:60   
172.31.181.235:0   (localhost)                                                                                        
10.20.0.191:0      id=691   sec_id=1415818 flags=0x0000 ifindex=20  mac=96:CC:BB:81:3C:1F nodemac=CE:EB:22:2D:82:77   
10.20.0.124:0      id=3913  sec_id=1405423 flags=0x0000 ifindex=22  mac=DE:FD:8B:5E:83:0B nodemac=AA:A7:A5:A4:22:E2   
10.20.0.84:0       id=16    sec_id=1415661 flags=0x0000 ifindex=14  mac=E2:08:9C:EC:70:CB nodemac=0E:DC:1C:17:18:7E   
172.31.129.74:0    (localhost)                                                                                        
10.20.0.90:0       id=1993  sec_id=1415661 flags=0x0000 ifindex=12  mac=56:96:82:2E:19:F2 nodemac=46:12:89:35:E4:C6   
10.20.0.232:0      id=389   sec_id=4     flags=0x0000 ifindex=10  mac=E6:E5:89:E6:12:16 nodemac=52:36:37:01:96:50     
10.20.0.25:0       id=596   sec_id=1419885 flags=0x0000 ifindex=18  mac=5A:37:C7:39:CD:83 nodemac=AE:58:6C:87:62:AA   
