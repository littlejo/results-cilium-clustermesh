Total: 559
TCP:   1190 (estab 301, closed 870, orphaned 0, timewait 405)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  320       310       10       
INET	  330       316       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.129.74%ens5:68         0.0.0.0:*    uid:192 ino:89061 sk:227 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:28220 sk:228 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15641 sk:229 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:39959      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:29577 sk:22a fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:28219 sk:22b cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15642 sk:22c cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::418:b5ff:fe6f:35c7]%ens5:546           [::]:*    uid:192 ino:15254 sk:22d cgroup:unreachable:bd0 v6only:1 <->                   
