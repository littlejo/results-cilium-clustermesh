top - 12:54:17 up 33 min,  0 users,  load average: 0.25, 0.54, 0.32
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 29.6 us, 37.0 sy,  0.0 ni, 29.6 id,  0.0 wa,  0.0 hi,  3.7 si,  0.0 st
MiB Mem :   3836.2 total,    281.9 free,   1058.2 used,   2496.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2596.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   2901 root      20   0 1243828  20724  14524 S  13.3   0.5   0:00.02 hubble
      1 root      20   0 1538804 294948  81092 S   6.7   7.5   1:00.16 cilium-+
    394 root      20   0 1229744   8984   3052 S   0.0   0.2   0:04.15 cilium-+
   2828 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   2834 root      20   0 1240432  16576  11292 S   0.0   0.4   0:00.02 cilium-+
   2867 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   2872 root      20   0    2208    776    696 S   0.0   0.0   0:00.00 timeout
   2896 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
