alloc: 108.49MB (113761080 bytes)
total-alloc: 2.72GB (2916246840 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 69073266
frees: 67883848
heap-alloc: 108.49MB (113761080 bytes)
heap-sys: 176.45MB (185016320 bytes)
heap-idle: 47.86MB (50184192 bytes)
heap-in-use: 128.59MB (134832128 bytes)
heap-released: 9.24MB (9691136 bytes)
heap-objects: 1189418
stack-in-use: 35.53MB (37257216 bytes)
stack-sys: 35.53MB (37257216 bytes)
stack-mspan-inuse: 2.14MB (2247680 bytes)
stack-mspan-sys: 2.66MB (2790720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 853.89KB (874385 bytes)
gc-sys: 5.52MB (5784696 bytes)
next-gc: when heap-alloc >= 152.04MB (159429416 bytes)
last-gc: 2024-10-24 12:54:18.540181051 +0000 UTC
gc-pause-total: 11.346661ms
gc-pause: 208930
gc-pause-end: 1729774458540181051
num-gc: 95
num-forced-gc: 0
gc-cpu-fraction: 0.0005104790668598718
enable-gc: true
debug-gc: false
