key: 10 00 00 00  value: 4b 02 00 00
key: 85 01 00 00  value: 35 02 00 00
key: 54 02 00 00  value: 84 02 00 00
key: b3 02 00 00  value: 78 0e 00 00
key: c9 07 00 00  value: 16 02 00 00
key: 19 09 00 00  value: 83 0e 00 00
key: 49 0f 00 00  value: 4f 0d 00 00
Found 7 elements
