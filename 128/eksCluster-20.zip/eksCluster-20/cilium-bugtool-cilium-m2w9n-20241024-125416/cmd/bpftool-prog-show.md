32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:20:58+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:20:59+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:20:59+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:20:59+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:59+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:03+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
107: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
110: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag 61f8660ce54258b4  gpl
	loaded_at 2024-10-24T12:25:55+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:25:55+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
483: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:25:55+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:25:55+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
515: sched_cls  name tail_ipv4_to_endpoint  tag 2aba60dec3345b11  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 164
517: sched_cls  name tail_ipv4_ct_egress  tag 060f51580d5234e4  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 166
519: sched_cls  name tail_handle_ipv4_cont  tag 67cbdbffe7f3eaa3  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 168
521: sched_cls  name cil_from_container  tag 44a80a9c2886b636  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 171
522: sched_cls  name tail_handle_arp  tag 73dd60f8efa60909  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 172
523: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 173
526: sched_cls  name tail_ipv4_ct_ingress  tag 8177ba9ea6ce34a7  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 174
529: sched_cls  name tail_handle_ipv4  tag 5b62f3552fb6adf0  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 176
530: sched_cls  name __send_drop_notify  tag 31a56ced92133517  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
534: sched_cls  name handle_policy  tag 8dc1babce1463e70  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 181
535: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,114
	btf_id 186
538: sched_cls  name tail_handle_ipv4_from_host  tag a56af7e557c08490  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,114
	btf_id 190
539: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,114
	btf_id 191
540: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
541: sched_cls  name __send_drop_notify  tag 14dd4e0a5a8552a7  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
542: sched_cls  name tail_handle_ipv4  tag ebe9e11aee2b4db1  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 188
544: sched_cls  name tail_handle_ipv4_from_host  tag a56af7e557c08490  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 197
546: sched_cls  name tail_ipv4_ct_ingress  tag 655c0eff3ae748f0  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,117,84
	btf_id 194
547: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 199
548: sched_cls  name __send_drop_notify  tag 14dd4e0a5a8552a7  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 201
553: sched_cls  name __send_drop_notify  tag 14dd4e0a5a8552a7  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
554: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 207
555: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 208
557: sched_cls  name tail_handle_ipv4_from_host  tag a56af7e557c08490  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 210
560: sched_cls  name __send_drop_notify  tag 14dd4e0a5a8552a7  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 215
562: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 216
564: sched_cls  name tail_handle_ipv4_from_host  tag a56af7e557c08490  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 218
565: sched_cls  name handle_policy  tag 526c64d56742f11f  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,116,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 219
566: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,117,84
	btf_id 220
567: sched_cls  name __send_drop_notify  tag e268725ed0ff666a  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 221
568: sched_cls  name tail_handle_ipv4_cont  tag d4974d8f14245c2b  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,116,40,37,38,81
	btf_id 222
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 223
571: sched_cls  name tail_handle_arp  tag 7a45870e73a98326  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 225
572: sched_cls  name tail_ipv4_to_endpoint  tag 4c173fa70deb58d6  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,116,40,37,38
	btf_id 226
573: sched_cls  name cil_from_container  tag 9b873e7352015fed  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 116,76
	btf_id 227
574: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
577: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
578: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
581: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
582: sched_cls  name tail_handle_arp  tag e81247b459f97029  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,128
	btf_id 229
583: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,128
	btf_id 230
584: sched_cls  name tail_ipv4_ct_egress  tag 060f51580d5234e4  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 231
585: sched_cls  name tail_handle_ipv4_cont  tag ed8e94aa95d43573  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,127,41,126,82,83,39,76,74,77,128,40,37,38,81
	btf_id 232
586: sched_cls  name tail_handle_ipv4  tag 777b08225ad7c135  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,128
	btf_id 233
587: sched_cls  name handle_policy  tag e505f24b1a48e823  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,128,82,83,127,41,80,126,39,84,75,40,37,38
	btf_id 234
588: sched_cls  name __send_drop_notify  tag 19b1071d410dba12  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
589: sched_cls  name tail_ipv4_to_endpoint  tag 42d35917e9a9e5a1  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,127,41,82,83,80,126,39,128,40,37,38
	btf_id 236
591: sched_cls  name cil_from_container  tag 26c196c28588c0a6  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,76
	btf_id 238
592: sched_cls  name tail_ipv4_ct_ingress  tag b20833b023daed8d  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 239
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_ipv4_ct_ingress  tag bc940f52695d1f3d  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 253
641: sched_cls  name tail_handle_ipv4  tag f115cdc815fcf1e8  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 254
642: sched_cls  name cil_from_container  tag 755dc6ab06aa1365  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 255
643: sched_cls  name __send_drop_notify  tag d95ed931e38d7301  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 256
644: sched_cls  name handle_policy  tag c651f5086804f6d2  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 257
645: sched_cls  name tail_ipv4_ct_egress  tag f3d349f4421e8992  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 258
647: sched_cls  name tail_handle_arp  tag 53efd25e6fd4d2e4  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 260
648: sched_cls  name tail_handle_ipv4_cont  tag 79441a0d9645f1e0  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 261
649: sched_cls  name tail_ipv4_to_endpoint  tag 374c36cc7e791df8  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 262
650: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
712: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
715: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
720: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
723: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
724: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
727: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
728: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
731: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
732: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
735: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
736: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
739: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3402: sched_cls  name tail_handle_ipv4  tag 45d07cb426964341  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,651
	btf_id 3205
3403: sched_cls  name tail_handle_arp  tag e877821da65510bc  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,651
	btf_id 3206
3404: sched_cls  name cil_from_container  tag f43c7d4b40dfc9d9  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 651,76
	btf_id 3207
3405: sched_cls  name tail_ipv4_ct_ingress  tag 9b31d0f2361e4c67  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,651,82,83,652,84
	btf_id 3208
3406: sched_cls  name tail_ipv4_to_endpoint  tag 7eee875082dcf388  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,652,41,82,83,80,154,39,651,40,37,38
	btf_id 3209
3407: sched_cls  name handle_policy  tag 6f09a41009b1e606  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,651,82,83,652,41,80,154,39,84,75,40,37,38
	btf_id 3210
3408: sched_cls  name tail_handle_ipv4_cont  tag f217e187a4598f59  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,652,41,154,82,83,39,76,74,77,651,40,37,38,81
	btf_id 3211
3409: sched_cls  name tail_ipv4_ct_egress  tag 5232d3baa6ca18ff  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,651,82,83,652,84
	btf_id 3212
3411: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,651
	btf_id 3214
3412: sched_cls  name __send_drop_notify  tag d7524c33af5da451  gpl
	loaded_at 2024-10-24T12:51:54+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3215
3699: sched_cls  name cil_from_container  tag 4f97fc7f102d0d19  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 706,76
	btf_id 3529
3701: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,708
	btf_id 3532
3702: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,706
	btf_id 3533
3703: sched_cls  name tail_handle_ipv4  tag da3c5fa8160f99eb  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,706
	btf_id 3535
3704: sched_cls  name handle_policy  tag 6767172230600721  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,708,82,83,707,41,80,151,39,84,75,40,37,38
	btf_id 3534
3705: sched_cls  name tail_ipv4_ct_egress  tag f22fdf9df513460f  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,708,82,83,707,84
	btf_id 3537
3706: sched_cls  name tail_ipv4_ct_ingress  tag d4f00210aa046279  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,706,82,83,705,84
	btf_id 3536
3707: sched_cls  name tail_handle_ipv4  tag 96c8bf7729e81e9e  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,708
	btf_id 3538
3708: sched_cls  name __send_drop_notify  tag 53318276d5b95057  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3540
3709: sched_cls  name tail_ipv4_to_endpoint  tag 20b62a6e09cd4bd1  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,707,41,82,83,80,151,39,708,40,37,38
	btf_id 3541
3710: sched_cls  name tail_handle_ipv4_cont  tag 5de555d037479510  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,707,41,151,82,83,39,76,74,77,708,40,37,38,81
	btf_id 3542
3711: sched_cls  name tail_handle_arp  tag 8a4e0dbc6b81a9b6  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,708
	btf_id 3543
3713: sched_cls  name cil_from_container  tag 379fe7b836545332  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 708,76
	btf_id 3545
3714: sched_cls  name tail_ipv4_ct_ingress  tag 4f3ddd20861d3f58  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,708,82,83,707,84
	btf_id 3546
3715: sched_cls  name handle_policy  tag 0e8f8f0d29a1022e  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,706,82,83,705,41,80,157,39,84,75,40,37,38
	btf_id 3539
3716: sched_cls  name __send_drop_notify  tag dd7822ed6dd06f20  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3547
3717: sched_cls  name tail_handle_ipv4_cont  tag 7733c809a013577c  gpl
	loaded_at 2024-10-24T12:53:19+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,705,41,157,82,83,39,76,74,77,706,40,37,38,81
	btf_id 3548
3718: sched_cls  name tail_handle_arp  tag b4202741ba323b68  gpl
	loaded_at 2024-10-24T12:53:20+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,706
	btf_id 3549
3719: sched_cls  name tail_ipv4_to_endpoint  tag 93420b6e2cf5b2fe  gpl
	loaded_at 2024-10-24T12:53:20+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,705,41,82,83,80,157,39,706,40,37,38
	btf_id 3550
3720: sched_cls  name tail_ipv4_ct_egress  tag b4c47a4f40b6c032  gpl
	loaded_at 2024-10-24T12:53:20+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,706,82,83,705,84
	btf_id 3551
