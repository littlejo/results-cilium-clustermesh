REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     536621    235332778   1132   bpf_host.c
Interface                   INGRESS     90500     7297534     677    bpf_overlay.c
Policy denied               EGRESS      137       10138       1325   bpf_lxc.c
Policy denied               INGRESS     27        2070        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      13600     1068628     1694   bpf_host.c
Success                     EGRESS      155282    20215435    1308   bpf_lxc.c
Success                     EGRESS      708       170303      86     l3.h
Success                     EGRESS      73257     5911442     53     encap.h
Success                     INGRESS     178941    20705766    86     l3.h
Success                     INGRESS     257068    27133441    235    trace.h
Unsupported L3 protocol     EGRESS      76        5756        1492   bpf_lxc.c
