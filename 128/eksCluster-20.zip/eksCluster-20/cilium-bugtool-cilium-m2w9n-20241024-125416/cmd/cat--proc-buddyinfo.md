Node 0, zone      DMA     22    100     37     22     18      8      4      3      1      3     42 
Node 0, zone   Normal     71     14     11      0      6      6      1      2      3      6      6 
