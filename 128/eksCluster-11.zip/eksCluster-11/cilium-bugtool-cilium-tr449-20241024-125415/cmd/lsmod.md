Module                  Size  Used by
udp_diag               16384  0
tcp_diag               16384  0
inet_diag              28672  2 tcp_diag,udp_diag
xt_TPROXY              16384  2
nf_tproxy_ipv6         20480  1 xt_TPROXY
nf_tproxy_ipv4         20480  1 xt_TPROXY
cls_bpf                24576  14
sch_ingress            16384  12
vxlan                  98304  0
ip6_udp_tunnel         16384  1 vxlan
udp_tunnel             28672  1 vxlan
xt_CT                  16384  5
ip_set                 61440  0
xt_socket              16384  1
nf_socket_ipv4         16384  1 xt_socket
nf_socket_ipv6         20480  1 xt_socket
ip6table_filter        16384  0
ip6table_raw           16384  0
ip6table_mangle        16384  0
iptable_filter         16384  0
iptable_raw            16384  0
iptable_mangle         16384  0
iptable_nat            16384  0
xfrm_user              53248  1
xfrm_algo              20480  1 xfrm_user
nf_conntrack_netlink    53248  0
veth                   32768  0
xt_state               16384  0
xt_connmark            16384  4
xt_addrtype            16384  3
xt_nat                 16384  14
xt_statistic           16384  4
xt_MASQUERADE          20480  3
xt_mark                16384  10
ipt_REJECT             16384  0
nf_reject_ipv4         16384  1 ipt_REJECT
nft_chain_nat          16384  8
nf_nat                 53248  4 xt_nat,nft_chain_nat,iptable_nat,xt_MASQUERADE
xt_conntrack           16384  20
nf_conntrack          184320  8 xt_conntrack,nf_nat,xt_state,xt_nat,nf_conntrack_netlink,xt_connmark,xt_CT,xt_MASQUERADE
nf_defrag_ipv6         24576  3 nf_conntrack,xt_socket,xt_TPROXY
nf_defrag_ipv4         16384  3 nf_conntrack,xt_socket,xt_TPROXY
xt_comment             16384  112
nft_compat             20480  198
nf_tables             258048  404 nft_compat,nft_chain_nat
nfnetlink              24576  5 nft_compat,nf_conntrack_netlink,nf_tables,ip_set
overlay               147456  23
nls_ascii              16384  1
nls_cp437              20480  1
vfat                   24576  1
fat                    90112  1 vfat
sunrpc                643072  1
aes_ce_blk             32768  0
ena                   159744  0
aes_ce_cipher          16384  1 aes_ce_blk
button                 20480  0
ghash_ce               20480  0
sha1_ce                16384  0
fuse                  155648  1
sch_fq_codel           24576  5
configfs               61440  1
loop                   40960  0
dm_mod                172032  0
dax                    45056  1 dm_mod
dmi_sysfs              24576  0
sha2_ce                16384  0
sha256_arm64           24576  1 sha2_ce
efivarfs               24576  1
