CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9bcd90b_2058_46d1_9d1f_1b2e165e4237.slice/cri-containerd-d56bc311b93a0afbef046054e56f2a595aefaa84032bf0aeaac4c56f7897755c.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9bcd90b_2058_46d1_9d1f_1b2e165e4237.slice/cri-containerd-2c864013407f7b5b7b67efd972639360692f526b5d34aa019a55ad63d3bbaacd.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7a47d43_9ea4_4cb8_b1aa_2361fd6df598.slice/cri-containerd-22a8ef846ad350ec56a0fd88682e5a479cf6ef55c55a5ca3917cf72e44a627fb.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7a47d43_9ea4_4cb8_b1aa_2361fd6df598.slice/cri-containerd-798acb659375fe109bde5a403d94f8ffb9c92c93b376021608244fedfe50f55e.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4b7a5ae_1fa5_4805_97de_570054763e50.slice/cri-containerd-8daf3de06cb9be90050e6d7b5289367bd7398692107ed63eaf26363e734ef9fe.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4b7a5ae_1fa5_4805_97de_570054763e50.slice/cri-containerd-a8c322462a632119b222c972cc84d0aa2bc7f72d50edf2c51c649688d949fa95.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8caf52c6_b947_4cf6_b8ad_bb8db82c8104.slice/cri-containerd-531c7cf588c7cd408cb857a518c1948683ef53a8e8c22544506f8cee70da2a42.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8caf52c6_b947_4cf6_b8ad_bb8db82c8104.slice/cri-containerd-d7bff0d0f7f51d69483a57cd4de8e0e258f3e40a759af972128e23dbf5364d20.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0c9f6a8e_2e96_4074_be22_9dae647e22e8.slice/cri-containerd-456a807bdfd1b2c1fd5dd98e1ff023a30957c64fe6239ac757a346d9177e19f2.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0c9f6a8e_2e96_4074_be22_9dae647e22e8.slice/cri-containerd-4c38639f4e9fe973ed7300c58cfc22be7e7a19cea6cf66729c40163164c4fdb9.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0c9f6a8e_2e96_4074_be22_9dae647e22e8.slice/cri-containerd-e5b41fadf7d29d6685403813cacb68299681caad3c1995eaa2eb44727afbd8a2.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a122249_99ff_464c_8b12_9c0c601adafe.slice/cri-containerd-ae9a0dc5fb6c7ed04c9808a5079ff3f014d453d2578ae1f7b29f3d66326aeb70.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a122249_99ff_464c_8b12_9c0c601adafe.slice/cri-containerd-5ecdda38f4b712ca954e5359b397567effe44c13baaa2866f8d9cd5f1d65c9ac.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0846460_f30a_4c23_b293_d11b65034eb2.slice/cri-containerd-38e9e00981b9c46c867020b475c8072789fdc775c07a6412b2baa60dbd16f69e.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0846460_f30a_4c23_b293_d11b65034eb2.slice/cri-containerd-0fc8e763dc560852e225c81feee0395c86fcf72ddf84fec147e7e048804358f6.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0846460_f30a_4c23_b293_d11b65034eb2.slice/cri-containerd-1340a63b07dec07756ebad02de45832c93718d4ab09e2d7874da14796ea718b0.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0846460_f30a_4c23_b293_d11b65034eb2.slice/cri-containerd-3a249e475325b318f37a938cba83a7717e9f890f1f0ef18b2728809bf422c6a4.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14c614d7_6d63_4e82_a9da_4fb3225c084a.slice/cri-containerd-9a297d5461b3f022f319b6adcfcbea1eda1e7eefee2f6eae14a2021a0ee46799.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14c614d7_6d63_4e82_a9da_4fb3225c084a.slice/cri-containerd-4db3397432a07f224fc831dbac9df86f2ada7d45516dd307cd696852a5091fa1.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb8a0883_e460_48b1_96e1_e2798dab9e9d.slice/cri-containerd-44f7e3623d48db52d381072823cd3bd007366c67ca4644d1ebb5a21089467623.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb8a0883_e460_48b1_96e1_e2798dab9e9d.slice/cri-containerd-291def4cba003b23a01ba17cbcf324a820cde7730f15452157c1752cd6db3610.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57570fce_8bcd_4bb6_b93f_df687a3bfb8c.slice/cri-containerd-66df8edaa89cbc4e65cdb99565befddfbede3a59459588e4304bcf026274d191.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57570fce_8bcd_4bb6_b93f_df687a3bfb8c.slice/cri-containerd-ee9fea74951aa73d8b69e72620792e6ae29a8a538aa68fbcd2d4f3a77d307c14.scope
    734      cgroup_device   multi                                          
