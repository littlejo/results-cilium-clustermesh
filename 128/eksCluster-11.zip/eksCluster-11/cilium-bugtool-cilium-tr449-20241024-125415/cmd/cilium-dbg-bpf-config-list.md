KEY             VALUE
AgentLiveness   2046706719650
UTimeOffset     3378461796875000
