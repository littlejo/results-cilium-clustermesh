IP ADDRESS         LOCAL ENDPOINT INFO
10.11.0.144:0      id=3498  sec_id=809439 flags=0x0000 ifindex=18  mac=86:12:57:0A:B0:80 nodemac=2A:22:04:4C:7E:62   
10.11.0.246:0      id=903   sec_id=834000 flags=0x0000 ifindex=12  mac=BA:F8:95:B4:8D:4C nodemac=E2:A1:22:F5:DA:07   
10.11.0.137:0      id=333   sec_id=4     flags=0x0000 ifindex=10  mac=26:01:9E:69:64:45 nodemac=8A:87:18:36:1C:B8    
10.11.0.3:0        id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2   
10.11.0.2:0        (localhost)                                                                                       
10.11.0.36:0       id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2   
10.11.0.123:0      id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF   
172.31.228.141:0   (localhost)                                                                                       
172.31.243.27:0    (localhost)                                                                                       
10.11.0.187:0      id=12    sec_id=834000 flags=0x0000 ifindex=14  mac=DA:B1:38:E5:B4:AB nodemac=BA:30:35:04:CC:AC   
