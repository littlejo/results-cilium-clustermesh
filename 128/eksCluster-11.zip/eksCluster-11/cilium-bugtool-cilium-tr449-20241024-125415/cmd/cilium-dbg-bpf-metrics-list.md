REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     133143    10791981    677    bpf_overlay.c
Interface                   INGRESS     667937    246844449   1132   bpf_host.c
Policy denied               EGRESS      61        4514        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      133561    10823075    53     encap.h
Success                     EGRESS      144939    19468529    1308   bpf_lxc.c
Success                     EGRESS      57055     4624429     1694   bpf_host.c
Success                     EGRESS      596       156223      86     l3.h
Success                     INGRESS     169136    19223795    86     l3.h
Success                     INGRESS     246451    25590040    235    trace.h
Unsupported L3 protocol     EGRESS      72        5424        1492   bpf_lxc.c
