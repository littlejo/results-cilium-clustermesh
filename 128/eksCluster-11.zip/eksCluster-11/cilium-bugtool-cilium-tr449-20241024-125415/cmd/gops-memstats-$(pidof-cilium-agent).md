alloc: 90.90MB (95319072 bytes)
total-alloc: 3.12GB (3347365328 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75430187
frees: 74760325
heap-alloc: 90.90MB (95319072 bytes)
heap-sys: 176.80MB (185384960 bytes)
heap-idle: 46.86MB (49135616 bytes)
heap-in-use: 129.94MB (136249344 bytes)
heap-released: 9.91MB (10395648 bytes)
heap-objects: 669862
stack-in-use: 35.16MB (36864000 bytes)
stack-sys: 35.16MB (36864000 bytes)
stack-mspan-inuse: 2.02MB (2113120 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1014.27KB (1038609 bytes)
gc-sys: 5.52MB (5784648 bytes)
next-gc: when heap-alloc >= 150.17MB (157466808 bytes)
last-gc: 2024-10-24 12:54:34.543778512 +0000 UTC
gc-pause-total: 16.904502ms
gc-pause: 82938
gc-pause-end: 1729774474543778512
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.0005452202577904987
enable-gc: true
debug-gc: false
