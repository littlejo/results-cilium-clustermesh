xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 562
ens6(5) clsact/ingress cil_from_netdev-ens6 id 568
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 540
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 582
lxc4f7f16d05b47(12) clsact/ingress cil_from_container-lxc4f7f16d05b47 id 520
lxc2de2a4b3c68d(14) clsact/ingress cil_from_container-lxc2de2a4b3c68d id 546
lxc1dd7d8f23607(18) clsact/ingress cil_from_container-lxc1dd7d8f23607 id 650
lxc999e925b4e23(20) clsact/ingress cil_from_container-lxc999e925b4e23 id 3389
lxcdcc9d83bb300(22) clsact/ingress cil_from_container-lxcdcc9d83bb300 id 3399
lxc57a306986333(24) clsact/ingress cil_from_container-lxc57a306986333 id 3333

flow_dissector:

netfilter:

