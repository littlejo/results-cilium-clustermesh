Endpoint ID: 12
Path: /sys/fs/bpf/tc/globals/cilium_policy_00012

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2700     29        0        
Allow    Ingress     1          ANY          NONE         disabled    168083   1929      0        
Allow    Egress      0          ANY          NONE         disabled    21776    246       0        


Endpoint ID: 333
Path: /sys/fs/bpf/tc/globals/cilium_policy_00333

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6212874   76755     0        
Allow    Ingress     1          ANY          NONE         disabled    67830     817       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 642
Path: /sys/fs/bpf/tc/globals/cilium_policy_00642

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 903
Path: /sys/fs/bpf/tc/globals/cilium_policy_00903

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3196     31        0        
Allow    Ingress     1          ANY          NONE         disabled    166961   1912      0        
Allow    Egress      0          ANY          NONE         disabled    22259    252       0        


Endpoint ID: 1774
Path: /sys/fs/bpf/tc/globals/cilium_policy_01774

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1851
Path: /sys/fs/bpf/tc/globals/cilium_policy_01851

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3171
Path: /sys/fs/bpf/tc/globals/cilium_policy_03171

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    375648   4403      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3498
Path: /sys/fs/bpf/tc/globals/cilium_policy_03498

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6032455   59697     0        
Allow    Ingress     1          ANY          NONE         disabled    5181491   54533     0        
Allow    Egress      0          ANY          NONE         disabled    5913569   59222     0        


