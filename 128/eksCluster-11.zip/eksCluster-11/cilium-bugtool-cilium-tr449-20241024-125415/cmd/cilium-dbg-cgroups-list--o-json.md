[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8caf52c6_b947_4cf6_b8ad_bb8db82c8104.slice/cri-containerd-531c7cf588c7cd408cb857a518c1948683ef53a8e8c22544506f8cee70da2a42.scope"
      }
    ],
    "ips": [
      "10.11.0.187"
    ],
    "name": "coredns-cc6ccd49c-bzzlw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a122249_99ff_464c_8b12_9c0c601adafe.slice/cri-containerd-ae9a0dc5fb6c7ed04c9808a5079ff3f014d453d2578ae1f7b29f3d66326aeb70.scope"
      }
    ],
    "ips": [
      "10.11.0.123"
    ],
    "name": "client-974f6c69d-gfnvn",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57570fce_8bcd_4bb6_b93f_df687a3bfb8c.slice/cri-containerd-ee9fea74951aa73d8b69e72620792e6ae29a8a538aa68fbcd2d4f3a77d307c14.scope"
      }
    ],
    "ips": [
      "10.11.0.36"
    ],
    "name": "client2-57cf4468f-cj84s",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0c9f6a8e_2e96_4074_be22_9dae647e22e8.slice/cri-containerd-4c38639f4e9fe973ed7300c58cfc22be7e7a19cea6cf66729c40163164c4fdb9.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0c9f6a8e_2e96_4074_be22_9dae647e22e8.slice/cri-containerd-456a807bdfd1b2c1fd5dd98e1ff023a30957c64fe6239ac757a346d9177e19f2.scope"
      }
    ],
    "ips": [
      "10.11.0.3"
    ],
    "name": "echo-same-node-86d9cc975c-kvzgg",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0846460_f30a_4c23_b293_d11b65034eb2.slice/cri-containerd-0fc8e763dc560852e225c81feee0395c86fcf72ddf84fec147e7e048804358f6.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0846460_f30a_4c23_b293_d11b65034eb2.slice/cri-containerd-38e9e00981b9c46c867020b475c8072789fdc775c07a6412b2baa60dbd16f69e.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0846460_f30a_4c23_b293_d11b65034eb2.slice/cri-containerd-1340a63b07dec07756ebad02de45832c93718d4ab09e2d7874da14796ea718b0.scope"
      }
    ],
    "ips": [
      "10.11.0.144"
    ],
    "name": "clustermesh-apiserver-647d7fbf64-s5j69",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9bcd90b_2058_46d1_9d1f_1b2e165e4237.slice/cri-containerd-d56bc311b93a0afbef046054e56f2a595aefaa84032bf0aeaac4c56f7897755c.scope"
      }
    ],
    "ips": [
      "10.11.0.246"
    ],
    "name": "coredns-cc6ccd49c-l4nmh",
    "namespace": "kube-system"
  }
]

