top - 12:54:16 up 33 min,  0 users,  load average: 0.45, 0.43, 0.25
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 14.3 us, 17.9 sy,  0.0 ni, 67.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    305.5 free,   1033.5 used,   2497.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2621.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3278 root      20   0 1240432  16744  11548 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1539060 285196  78904 S   0.0   7.3   1:08.94 cilium-+
    414 root      20   0 1229744   8984   3052 S   0.0   0.2   0:04.45 cilium-+
   3233 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3249 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3255 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3267 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3273 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3313 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3331 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
