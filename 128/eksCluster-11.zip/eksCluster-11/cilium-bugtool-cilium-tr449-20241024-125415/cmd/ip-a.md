1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:61:7d:1d:95:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.243.27/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3398sec preferred_lft 3398sec
    inet6 fe80::861:7dff:fe1d:953d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:59:52:40:6b:1d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.228.141/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::859:52ff:fe40:6b1d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:57:a7:b3:49:42 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::457:a7ff:feb3:4942/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:c8:9f:e0:ab:61 brd ff:ff:ff:ff:ff:ff
    inet 10.11.0.2/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::24c8:9fff:fee0:ab61/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 76:46:4f:d6:54:b6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7446:4fff:fed6:54b6/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:87:18:36:1c:b8 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8887:18ff:fe36:1cb8/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4f7f16d05b47@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:a1:22:f5:da:07 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e0a1:22ff:fef5:da07/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc2de2a4b3c68d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:30:35:04:cc:ac brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::b830:35ff:fe04:ccac/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc1dd7d8f23607@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:22:04:4c:7e:62 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2822:4ff:fe4c:7e62/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc999e925b4e23@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:e9:da:3c:e0:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c8e9:daff:fe3c:e0a2/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcdcc9d83bb300@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:00:e7:f0:f9:af brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::9000:e7ff:fef0:f9af/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc57a306986333@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:84:08:0d:38:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::2484:8ff:fe0d:38a2/64 scope link 
       valid_lft forever preferred_lft forever
