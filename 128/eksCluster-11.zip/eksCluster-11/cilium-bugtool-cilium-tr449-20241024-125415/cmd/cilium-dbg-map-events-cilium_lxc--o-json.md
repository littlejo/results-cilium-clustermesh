{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.434Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.436Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.991Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.055Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.077Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.112Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.126Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.150Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.409Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.414Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.491Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.491Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.548Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.145Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.165Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.198Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.223Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.241Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.479Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.494Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.555Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.593Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.627Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.266Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.273Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.314Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.328Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.352Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.589Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.589Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.631Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.644Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.663Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.690Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.342Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.346Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.382Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.388Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.442Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.446Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.479Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.714Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.732Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.793Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.844Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.903Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.303Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.335Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.368Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.380Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.407Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.637Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.648Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.701Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.707Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.746Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.167Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.170Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.225Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.242Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.267Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.538Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.545Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.585Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.621Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.642Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.076Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.137Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.206Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.206Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.273Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.283Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.477Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.485Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.533Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.544Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.595Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.043Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.055Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.099Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.109Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.137Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.354Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.377Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.392Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.431Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.444Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.489Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.947Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.967Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.010Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.013Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.048Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.308Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.334Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.399Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.413Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.464Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.794Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.802Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.843Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.860Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.860Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.896Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.903Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.176Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.189Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.232Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.263Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.280Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.612Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.622Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.693Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.694Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.737Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.953Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.986Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.991Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.008Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.834Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.837Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.871Z",
  "value": "id=3171  sec_id=792630 flags=0x0000 ifindex=24  mac=36:24:02:EA:0D:31 nodemac=26:84:08:0D:38:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.901Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.921Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.202Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.210Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.856Z",
  "value": "id=1851  sec_id=840783 flags=0x0000 ifindex=20  mac=72:9C:B6:76:B7:98 nodemac=CA:E9:DA:3C:E0:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.871Z",
  "value": "id=642   sec_id=787235 flags=0x0000 ifindex=22  mac=8E:BB:8E:DB:BB:0F nodemac=92:00:E7:F0:F9:AF"
}

