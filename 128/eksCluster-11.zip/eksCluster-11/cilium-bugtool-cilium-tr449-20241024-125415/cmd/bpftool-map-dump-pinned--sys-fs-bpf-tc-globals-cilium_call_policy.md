key: 0c 00 00 00  value: 41 02 00 00
key: 4d 01 00 00  value: 45 02 00 00
key: 82 02 00 00  value: 43 0d 00 00
key: 87 03 00 00  value: 17 02 00 00
key: 3b 07 00 00  value: 40 0d 00 00
key: 63 0c 00 00  value: 01 0d 00 00
key: aa 0d 00 00  value: 88 02 00 00
Found 7 elements
