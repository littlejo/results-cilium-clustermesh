Node 0, zone      DMA    181    107     45     46     21      5      5      1      1      1     45 
Node 0, zone   Normal    293      2      2      2      1      3      3      5      7      1      7 
