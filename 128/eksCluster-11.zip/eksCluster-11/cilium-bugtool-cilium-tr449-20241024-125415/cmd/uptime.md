 12:54:16 up 33 min,  0 users,  load average: 0.45, 0.43, 0.25
