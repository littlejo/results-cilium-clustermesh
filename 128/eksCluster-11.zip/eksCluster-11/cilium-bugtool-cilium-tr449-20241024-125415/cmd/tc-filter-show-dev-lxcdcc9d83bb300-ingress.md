filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcdcc9d83bb300 direct-action not_in_hw id 3399 tag c8ad2b5da14d67ca jited 
