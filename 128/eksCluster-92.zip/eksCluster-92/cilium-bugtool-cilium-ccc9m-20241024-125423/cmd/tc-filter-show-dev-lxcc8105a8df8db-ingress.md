filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc8105a8df8db direct-action not_in_hw id 3377 tag 73547bc2e0fe2210 jited 
