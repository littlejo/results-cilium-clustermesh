key: 2a 03 00 00  value: 34 02 00 00
key: f3 05 00 00  value: 2e 0d 00 00
key: e4 07 00 00  value: 24 0d 00 00
key: 74 08 00 00  value: 35 02 00 00
key: af 09 00 00  value: 14 02 00 00
key: 72 0c 00 00  value: f2 0c 00 00
key: 8d 0e 00 00  value: 82 02 00 00
Found 7 elements
