Endpoint ID: 810
Path: /sys/fs/bpf/tc/globals/cilium_policy_00810

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6226206   76929     0        
Allow    Ingress     1          ANY          NONE         disabled    65504     796       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1508
Path: /sys/fs/bpf/tc/globals/cilium_policy_01508

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1523
Path: /sys/fs/bpf/tc/globals/cilium_policy_01523

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2020
Path: /sys/fs/bpf/tc/globals/cilium_policy_02020

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2164
Path: /sys/fs/bpf/tc/globals/cilium_policy_02164

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1234     14        0        
Allow    Ingress     1          ANY          NONE         disabled    135293   1561      0        
Allow    Egress      0          ANY          NONE         disabled    19409    214       0        


Endpoint ID: 2479
Path: /sys/fs/bpf/tc/globals/cilium_policy_02479

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4662     46        0        
Allow    Ingress     1          ANY          NONE         disabled    134567   1550      0        
Allow    Egress      0          ANY          NONE         disabled    18490    205       0        


Endpoint ID: 3186
Path: /sys/fs/bpf/tc/globals/cilium_policy_03186

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379904   4429      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3725
Path: /sys/fs/bpf/tc/globals/cilium_policy_03725

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6140332   61830     0        
Allow    Ingress     1          ANY          NONE         disabled    5441223   57552     0        
Allow    Egress      0          ANY          NONE         disabled    7029395   69280     0        


