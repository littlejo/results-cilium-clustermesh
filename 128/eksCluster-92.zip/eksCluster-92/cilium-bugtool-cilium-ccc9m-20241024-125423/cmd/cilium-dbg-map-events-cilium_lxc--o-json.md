{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.685Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.795Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.795Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.828Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.978Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.982Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.023Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.024Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.118Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.127Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.576Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.578Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.627Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.633Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.670Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.696Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.713Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.939Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.942Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.993Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.999Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.052Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.557Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.560Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.594Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.603Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.689Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.696Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.736Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.941Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.951Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.008Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.024Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.050Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.659Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.668Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.696Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.717Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.747Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.759Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.783Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.017Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.024Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.078Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.095Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.119Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.594Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.601Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.641Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.658Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.678Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.931Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.940Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.020Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.026Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.063Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.446Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.497Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.506Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.554Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.560Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.593Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.800Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.834Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.848Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.892Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.911Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.371Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.418Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.466Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.540Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.560Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.840Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.844Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.963Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.985Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.031Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.415Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.475Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.536Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.547Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.547Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.572Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.780Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.790Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.834Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.877Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.888Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.317Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.371Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.391Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.424Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.436Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.463Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.687Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.705Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.739Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.764Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.790Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.106Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.106Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.156Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.162Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.196Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.404Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.483Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.537Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.590Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.606Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.899Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.935Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.964Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.984Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.015Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.027Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.253Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.274Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.282Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.314Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.008Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.011Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.052Z",
  "value": "id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.092Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.107Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.394Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.395Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.076Z",
  "value": "id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.083Z",
  "value": "id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB"
}

