 12:54:25 up 31 min,  0 users,  load average: 0.26, 0.56, 0.33
