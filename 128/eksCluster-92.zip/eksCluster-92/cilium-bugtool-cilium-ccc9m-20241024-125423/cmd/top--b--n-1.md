top - 12:54:25 up 31 min,  0 users,  load average: 0.26, 0.56, 0.33
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 31.0 us, 31.0 sy,  0.0 ni, 37.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    283.9 free,   1057.2 used,   2495.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2597.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 294024  78460 S  40.0   7.5   1:04.58 cilium-+
   3293 root      20   0 1240432  16720  11484 S   6.7   0.4   0:00.03 cilium-+
    395 root      20   0 1229744  10052   3836 S   0.0   0.3   0:04.35 cilium-+
   3251 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3255 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3269 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3320 root      20   0    6576   2396   2072 R   0.0   0.1   0:00.00 top
   3340 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
