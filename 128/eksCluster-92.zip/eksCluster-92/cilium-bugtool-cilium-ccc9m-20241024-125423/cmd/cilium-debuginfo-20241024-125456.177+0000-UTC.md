# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.92.0.0/24, 
Allocated addresses:
  10.92.0.114 (cilium-test-1/echo-same-node-86d9cc975c-rlcml)
  10.92.0.213 (health)
  10.92.0.226 (cilium-test-1/client2-57cf4468f-2tmtl)
  10.92.0.230 (router)
  10.92.0.248 (cilium-test-1/client-974f6c69d-cxfg9)
  10.92.0.36 (kube-system/coredns-cc6ccd49c-db6rj)
  10.92.0.64 (kube-system/coredns-cc6ccd49c-kdr79)
  10.92.0.87 (kube-system/clustermesh-apiserver-868d4f7654-8ggf4)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13dade1a01b7d619
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      177/177 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    37s ago        never        0       no error   
  ct-map-pressure                                                     8s ago         never        0       no error   
  daemon-validate-config                                              15s ago        never        0       no error   
  dns-garbage-collector-job                                           40s ago        never        0       no error   
  endpoint-1508-regeneration-recovery                                 never          never        0       no error   
  endpoint-1523-regeneration-recovery                                 never          never        0       no error   
  endpoint-2020-regeneration-recovery                                 never          never        0       no error   
  endpoint-2164-regeneration-recovery                                 never          never        0       no error   
  endpoint-2479-regeneration-recovery                                 never          never        0       no error   
  endpoint-3186-regeneration-recovery                                 never          never        0       no error   
  endpoint-3725-regeneration-recovery                                 never          never        0       no error   
  endpoint-810-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         3m41s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                8s ago         never        0       no error   
  ipcache-inject-labels                                               38s ago        never        0       no error   
  k8s-heartbeat                                                       11s ago        never        0       no error   
  link-cache                                                          8s ago         never        0       no error   
  local-identity-checkpoint                                           3m10s ago      never        0       no error   
  node-neighbor-link-updater                                          8s ago         never        0       no error   
  remote-etcd-cmesh1                                                  12m22s ago     never        0       no error   
  remote-etcd-cmesh10                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh100                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh101                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh102                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh103                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh104                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh105                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh106                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh107                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh108                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh109                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh11                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh110                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh111                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh112                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh113                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh114                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh115                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh116                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh117                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh118                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh119                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh12                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh120                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh121                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh122                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh123                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh124                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh125                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh126                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh127                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh128                                                12m22s ago     never        0       no error   
  remote-etcd-cmesh13                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh14                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh15                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh16                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh17                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh18                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh19                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh2                                                  12m22s ago     never        0       no error   
  remote-etcd-cmesh20                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh21                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh22                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh23                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh24                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh25                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh26                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh27                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh28                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh29                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh3                                                  12m22s ago     never        0       no error   
  remote-etcd-cmesh30                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh31                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh32                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh33                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh34                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh35                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh36                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh37                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh38                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh39                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh4                                                  12m22s ago     never        0       no error   
  remote-etcd-cmesh40                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh41                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh42                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh43                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh44                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh45                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh46                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh47                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh48                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh49                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh5                                                  12m22s ago     never        0       no error   
  remote-etcd-cmesh50                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh51                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh52                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh53                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh54                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh55                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh56                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh57                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh58                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh59                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh6                                                  12m22s ago     never        0       no error   
  remote-etcd-cmesh60                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh61                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh62                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh63                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh64                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh65                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh66                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh67                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh68                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh69                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh7                                                  12m22s ago     never        0       no error   
  remote-etcd-cmesh70                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh71                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh72                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh73                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh74                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh75                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh76                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh77                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh78                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh79                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh8                                                  12m22s ago     never        0       no error   
  remote-etcd-cmesh80                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh81                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh82                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh83                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh84                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh85                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh86                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh87                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh88                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh89                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh9                                                  12m22s ago     never        0       no error   
  remote-etcd-cmesh90                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh91                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh92                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh94                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh95                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh96                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh97                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh98                                                 12m22s ago     never        0       no error   
  remote-etcd-cmesh99                                                 12m22s ago     never        0       no error   
  resolve-identity-1508                                               3m38s ago      never        0       no error   
  resolve-identity-1523                                               1m32s ago      never        0       no error   
  resolve-identity-2020                                               1m30s ago      never        0       no error   
  resolve-identity-2164                                               3m36s ago      never        0       no error   
  resolve-identity-2479                                               3m36s ago      never        0       no error   
  resolve-identity-3186                                               1m30s ago      never        0       no error   
  resolve-identity-3725                                               3m15s ago      never        0       no error   
  resolve-identity-810                                                3m37s ago      never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-cxfg9                 6m32s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-2tmtl                6m30s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-rlcml        6m30s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-868d4f7654-8ggf4   13m15s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-db6rj                  23m36s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-kdr79                  23m36s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      23m38s ago     never        0       no error   
  sync-policymap-1508                                                 8m37s ago      never        0       no error   
  sync-policymap-1523                                                 6m32s ago      never        0       no error   
  sync-policymap-2020                                                 6m30s ago      never        0       no error   
  sync-policymap-2164                                                 8m34s ago      never        0       no error   
  sync-policymap-2479                                                 8m34s ago      never        0       no error   
  sync-policymap-3186                                                 6m30s ago      never        0       no error   
  sync-policymap-3725                                                 13m15s ago     never        0       no error   
  sync-policymap-810                                                  8m34s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1523)                                   12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2020)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2164)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2479)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3186)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3725)                                   5s ago         never        0       no error   
  sync-utime                                                          38s ago        never        0       no error   
  write-cni-file                                                      23m41s ago     never        0       no error   
Proxy Status:            OK, ip 10.92.0.230, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 6094848, max 6160383
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 197.45   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                      
810        Disabled           Disabled          4          reserved:health                                                                       10.92.0.213   ready   
1508       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                     ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                       
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                 
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                  
                                                           reserved:host                                                                                               
1523       Disabled           Disabled          6153838    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.92.0.248   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh93                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                              
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client                                                                                             
2020       Disabled           Disabled          6123850    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.92.0.226   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh93                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client2                                                                                            
                                                           k8s:other=client                                                                                            
2164       Disabled           Disabled          6149363    k8s:eks.amazonaws.com/component=coredns                                               10.92.0.64    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh93                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
2479       Disabled           Disabled          6149363    k8s:eks.amazonaws.com/component=coredns                                               10.92.0.36    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh93                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
3186       Disabled           Disabled          6119752    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.92.0.114   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh93                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                      
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=echo                                                                                               
                                                           k8s:name=echo-same-node                                                                                     
                                                           k8s:other=echo                                                                                              
3725       Disabled           Disabled          6125384    k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.92.0.87    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh93                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                               
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=clustermesh-apiserver                                                                           
```

#### BPF Policy Get 810

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6221518   76872     0        
Allow    Ingress     1          ANY          NONE         disabled    65504     796       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 810

```
Invalid argument: unknown type 810
```


#### Endpoint Get 810

```
[
  {
    "id": 810,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-810-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "19da6766-793d-496c-9c49-79781c628f77"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-810",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:18.902Z",
            "success-count": 5
          },
          "uuid": "da9618c0-70b6-4d49-8421-4b28041c333d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-810",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:46:22.093Z",
            "success-count": 2
          },
          "uuid": "4263f06e-941a-4d93-8ee0-fcbce9427d86"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.92.0.213",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "26:68:d5:12:16:16",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "ce:08:ca:f5:7e:ba"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 810

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 810

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:35Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:31:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:31:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:31:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:31:22Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:31:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:31:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:31:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:31:18Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:31:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:31:18Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:31:17Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1508

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1508

```
Invalid argument: unknown type 1508
```


#### Endpoint Get 1508

```
[
  {
    "id": 1508,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1508-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "77cc148a-8deb-4f37-afc4-d4142d0c6bea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1508",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:17.831Z",
            "success-count": 5
          },
          "uuid": "2193cf81-d3de-4328-82b0-a416d090f2c0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1508",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:46:18.905Z",
            "success-count": 2
          },
          "uuid": "501faffd-4eb0-4e07-a53c-461639173408"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "8a:2f:4c:19:4a:3e",
        "interface-name": "cilium_host",
        "mac": "8a:2f:4c:19:4a:3e"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1508

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1508

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:35Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:31:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T12:31:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:31:22Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T12:31:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:31:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:31:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T12:31:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:31:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:31:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:31:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:31:17Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:31:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:31:17Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:31:17Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1523

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1523

```
Invalid argument: unknown type 1523
```


#### Endpoint Get 1523

```
[
  {
    "id": 1523,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1523-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2e067cde-b975-4526-9998-e4188a102c3e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1523",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:24.037Z",
            "success-count": 2
          },
          "uuid": "f5588b02-8d54-4460-8e1c-6d131a6045ed"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-cxfg9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:24.033Z",
            "success-count": 1
          },
          "uuid": "881b5a2a-e4cb-4769-b9d3-912307df2fa3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1523",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:24.071Z",
            "success-count": 1
          },
          "uuid": "eaf5ac29-a17c-42fc-a323-bd315e92e884"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1523)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:54.068Z",
            "success-count": 41
          },
          "uuid": "49ce31ae-c1ed-4306-b898-e449624e046c"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "c50268e15cd36a6bb7d317a176e11370f423387686471fac692069cae3ffb243:eth0",
        "container-id": "c50268e15cd36a6bb7d317a176e11370f423387686471fac692069cae3ffb243",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-cxfg9",
        "pod-name": "cilium-test-1/client-974f6c69d-cxfg9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6153838,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:29Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.92.0.248",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3a:97:f8:f6:17:ab",
        "interface-index": 20,
        "interface-name": "lxcc8105a8df8db",
        "mac": "c2:93:bb:1c:d5:cc"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6153838,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6153838,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1523

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1523

```
Timestamp              Status   State                   Message
2024-10-24T12:51:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 6153838

```
ID        LABELS
6153838   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh93
          k8s:io.cilium.k8s.policy.serviceaccount=client
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client

```


#### BPF Policy Get 2020

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2020

```
Invalid argument: unknown type 2020
```


#### Endpoint Get 2020

```
[
  {
    "id": 2020,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2020-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "daf6f95c-9993-4655-840d-d87f250d13c3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2020",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:25.475Z",
            "success-count": 2
          },
          "uuid": "8e28fa9e-4315-4f4f-b271-befdbf9e02f5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-2tmtl",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:25.473Z",
            "success-count": 1
          },
          "uuid": "d4e9cd27-6273-404c-a87f-5fb9ffeee29d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2020",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:25.559Z",
            "success-count": 1
          },
          "uuid": "05c33163-00e3-4f9e-88a0-b406f468c7cb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2020)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:55.571Z",
            "success-count": 41
          },
          "uuid": "1ad66145-b1e1-417b-8080-56cbf0f3d0e6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "94f2dae417b95aef5892e7e39a69200e9ee131cb035f758d8dbfb5e3821c8c6f:eth0",
        "container-id": "94f2dae417b95aef5892e7e39a69200e9ee131cb035f758d8dbfb5e3821c8c6f",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-2tmtl",
        "pod-name": "cilium-test-1/client2-57cf4468f-2tmtl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6123850,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:29Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.92.0.226",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "52:7e:b3:f6:01:11",
        "interface-index": 22,
        "interface-name": "lxc56b0c14b3ff2",
        "mac": "42:00:72:c1:dc:e3"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6123850,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6123850,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2020

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2020

```
Timestamp              Status   State                   Message
2024-10-24T12:51:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 6123850

```
ID        LABELS
6123850   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh93
          k8s:io.cilium.k8s.policy.serviceaccount=client2
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client2
          k8s:other=client

```


#### BPF Policy Get 2164

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1234     14        0        
Allow    Ingress     1          ANY          NONE         disabled    135293   1561      0        
Allow    Egress      0          ANY          NONE         disabled    19409    214       0        

```


#### BPF CT List 2164

```
Invalid argument: unknown type 2164
```


#### Endpoint Get 2164

```
[
  {
    "id": 2164,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2164-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9b2f29e9-b57f-475d-86e4-9b52c43af557"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2164",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:19.490Z",
            "success-count": 5
          },
          "uuid": "92740f35-12be-4195-a6d1-f4b7e26a2d8d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-kdr79",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:31:19.488Z",
            "success-count": 1
          },
          "uuid": "3497b985-101d-40d0-ae02-9e6912f2199c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2164",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:46:22.166Z",
            "success-count": 2
          },
          "uuid": "ea7e39be-e8e7-4ef1-a189-6c4d119495f2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2164)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:49.593Z",
            "success-count": 143
          },
          "uuid": "9e69a208-57d3-4fe0-8dfc-d617e85ed113"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "9e1b4150c6979a0a9ffded025ad758cfb6e9b7d71a0335011ce696408d679714:eth0",
        "container-id": "9e1b4150c6979a0a9ffded025ad758cfb6e9b7d71a0335011ce696408d679714",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-kdr79",
        "pod-name": "kube-system/coredns-cc6ccd49c-kdr79"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6149363,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.92.0.64",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "e6:2a:ff:86:f0:47",
        "interface-index": 14,
        "interface-name": "lxc63e94aabbb5b",
        "mac": "9e:1d:05:1e:e0:d5"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6149363,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6149363,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2164

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2164

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:35Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:31:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:31:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:31:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:31:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:31:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:31:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:31:19Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:31:19Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6149363

```
ID        LABELS
6149363   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh93
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2479

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4662     46        0        
Allow    Ingress     1          ANY          NONE         disabled    134567   1550      0        
Allow    Egress      0          ANY          NONE         disabled    18490    205       0        

```


#### BPF CT List 2479

```
Invalid argument: unknown type 2479
```


#### Endpoint Get 2479

```
[
  {
    "id": 2479,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2479-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b0fa6964-f8b9-4cd6-871a-abf3b972a28d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2479",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:19.402Z",
            "success-count": 5
          },
          "uuid": "87ee1eee-57a7-4936-9a8d-0c869f18ea04"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-db6rj",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:31:19.398Z",
            "success-count": 1
          },
          "uuid": "46fae814-035c-4cc7-8872-4a55ee840e84"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2479",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:46:22.091Z",
            "success-count": 2
          },
          "uuid": "f8341eda-3d24-42fd-9c11-b0bd57ecf891"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2479)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:49.507Z",
            "success-count": 143
          },
          "uuid": "434cc369-2786-4400-8e06-fffdc55e3ce2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0cf044dffb51f52a4ad757e8dc6e6ea0e3b883da7b8f9819c361a5d7652d071c:eth0",
        "container-id": "0cf044dffb51f52a4ad757e8dc6e6ea0e3b883da7b8f9819c361a5d7652d071c",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-db6rj",
        "pod-name": "kube-system/coredns-cc6ccd49c-db6rj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6149363,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.92.0.36",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "7a:7b:9b:f1:b7:cd",
        "interface-index": 12,
        "interface-name": "lxc3b7e4c39c10b",
        "mac": "e2:4c:8e:e9:d6:3b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6149363,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6149363,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2479

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2479

```
Timestamp              Status    State                   Message
2024-10-24T12:48:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:35Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:42:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:08Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:08Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:08Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:07Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:07Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:07Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:07Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:31:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:31:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:31:20Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:31:20Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:31:19Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:31:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:31:19Z   OK        ready                   Set identity for this endpoint
2024-10-24T12:31:19Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:31:19Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 6149363

```
ID        LABELS
6149363   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh93
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3186

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379904   4429      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3186

```
Invalid argument: unknown type 3186
```


#### Endpoint Get 3186

```
[
  {
    "id": 3186,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3186-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b7bd0efb-e884-43fe-9c71-d64ff77566aa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3186",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:25.571Z",
            "success-count": 2
          },
          "uuid": "fcb58670-9e10-4b39-89e9-3512da027c97"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-rlcml",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:25.570Z",
            "success-count": 1
          },
          "uuid": "94700d4b-4877-48b0-bde5-17861b218175"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3186",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:25.630Z",
            "success-count": 1
          },
          "uuid": "5e2bca5e-d8ca-4730-bf95-533bf2cc38d3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3186)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:55.631Z",
            "success-count": 41
          },
          "uuid": "152b42dd-ca0f-4867-b709-f8d927240232"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "5623736f828392208526b57a6d1c5c5babbf8b2a7530616ce2809fcea5d691d9:eth0",
        "container-id": "5623736f828392208526b57a6d1c5c5babbf8b2a7530616ce2809fcea5d691d9",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-rlcml",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-rlcml"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6119752,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:20Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.92.0.114",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "06:b6:1f:ed:d8:62",
        "interface-index": 24,
        "interface-name": "lxc4d019ce28594",
        "mac": "7a:f0:6c:01:31:8f"
      },
      "policy": {
        "proxy-policy-revision": 126,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6119752,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 126,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6119752,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 126
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3186

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3186

```
Timestamp              Status   State                   Message
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:53Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 6119752

```
ID        LABELS
6119752   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh93
          k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=echo
          k8s:name=echo-same-node
          k8s:other=echo

```


#### BPF Policy Get 3725

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6149238   61930     0        
Allow    Ingress     1          ANY          NONE         disabled    5441223   57552     0        
Allow    Egress      0          ANY          NONE         disabled    7031619   69304     0        

```


#### BPF CT List 3725

```
Invalid argument: unknown type 3725
```


#### Endpoint Get 3725

```
[
  {
    "id": 3725,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3725-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c966a89a-d140-4bf4-96de-b5ba89349386"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3725",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:40.785Z",
            "success-count": 3
          },
          "uuid": "5e829f12-7606-4550-86ea-a0b270e9ed85"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-868d4f7654-8ggf4",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:40.783Z",
            "success-count": 1
          },
          "uuid": "effec354-fb63-4b0f-b561-f0e27c78cbcf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3725",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:40.819Z",
            "success-count": 1
          },
          "uuid": "ad5b63af-b5ea-4160-8b33-17da0a56c16f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3725)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:50.852Z",
            "success-count": 81
          },
          "uuid": "a6e55472-afa2-4d1d-87ce-24c110bac6bb"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "5ff24c04a3fd2257a2f5e766f579f2071e2ab88ea611e72c391cae0cc3cd70f1:eth0",
        "container-id": "5ff24c04a3fd2257a2f5e766f579f2071e2ab88ea611e72c391cae0cc3cd70f1",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-868d4f7654-8ggf4",
        "pod-name": "kube-system/clustermesh-apiserver-868d4f7654-8ggf4"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6125384,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=868d4f7654"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh93",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.92.0.87",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "46:3a:55:71:a2:63",
        "interface-index": 18,
        "interface-name": "lxc785f65126f86",
        "mac": "36:2d:fe:cc:11:2d"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6125384,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6125384,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3725

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3725

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:35Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:41:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:40Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:41:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:41:40Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:41:40Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6125384

```
ID        LABELS
6125384   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh93
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.162.189:443 (active)    
                                          2 => 172.31.196.152:443 (active)    
2    10.100.170.248:443    ClusterIP      1 => 172.31.142.217:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.92.0.64:9153 (active)       
                                          2 => 10.92.0.36:9153 (active)       
4    10.100.0.10:53        ClusterIP      1 => 10.92.0.64:53 (active)         
                                          2 => 10.92.0.36:53 (active)         
5    10.100.186.218:2379   ClusterIP      1 => 10.92.0.87:2379 (active)       
6    10.100.235.26:8080    ClusterIP      1 => 10.92.0.114:8080 (active)      
```

#### Policy get

```
:
 []
Revision: 129

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 35712430                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 35712430                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 35712430                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d800000 rw-p 00000000 00:00 0 
400d800000-4010000000 ---p 00000000 00:00 0 
ffff55421000-ffff556d6000 rw-p 00000000 00:00 0 
ffff556dd000-ffff557bf000 rw-p 00000000 00:00 0 
ffff557bf000-ffff55800000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff55800000-ffff55841000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff55841000-ffff55881000 rw-p 00000000 00:00 0 
ffff55881000-ffff55883000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff55883000-ffff55885000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff55885000-ffff55e4c000 rw-p 00000000 00:00 0 
ffff55e4c000-ffff55f4c000 rw-p 00000000 00:00 0 
ffff55f4c000-ffff55f5d000 rw-p 00000000 00:00 0 
ffff55f5d000-ffff57f5d000 rw-p 00000000 00:00 0 
ffff57f5d000-ffff57fdd000 ---p 00000000 00:00 0 
ffff57fdd000-ffff57fde000 rw-p 00000000 00:00 0 
ffff57fde000-ffff77fdd000 ---p 00000000 00:00 0 
ffff77fdd000-ffff77fde000 rw-p 00000000 00:00 0 
ffff77fde000-ffff97f6d000 ---p 00000000 00:00 0 
ffff97f6d000-ffff97f6e000 rw-p 00000000 00:00 0 
ffff97f6e000-ffff9bf5f000 ---p 00000000 00:00 0 
ffff9bf5f000-ffff9bf60000 rw-p 00000000 00:00 0 
ffff9bf60000-ffff9c75d000 ---p 00000000 00:00 0 
ffff9c75d000-ffff9c75e000 rw-p 00000000 00:00 0 
ffff9c75e000-ffff9c85d000 ---p 00000000 00:00 0 
ffff9c85d000-ffff9c8bd000 rw-p 00000000 00:00 0 
ffff9c8bd000-ffff9c8bf000 r--p 00000000 00:00 0                          [vvar]
ffff9c8bf000-ffff9c8c0000 r-xp 00000000 00:00 0                          [vdso]
fffffe956000-fffffe977000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
kvstore:
enable-route-mtu-for-cni-chaining:false
enable-health-check-loadbalancer-ip:false
cluster-id:93
mke-cgroup-mount:
controller-group-metrics:
unmanaged-pod-watcher-interval:15
preallocate-bpf-maps:false
proxy-admin-port:0
bpf-ct-global-tcp-max:524288
cgroup-root:/run/cilium/cgroupv2
enable-well-known-identities:false
enable-encryption-strict-mode:false
mesh-auth-queue-size:1024
agent-liveness-update-interval:1s
bpf-policy-map-max:16384
lib-dir:/var/lib/cilium
encryption-strict-mode-allow-remote-node-identities:false
http-retry-count:3
agent-labels:
cni-exclusive:true
wireguard-persistent-keepalive:0s
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-active-connection-tracking:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
node-port-mode:snat
enable-stale-cilium-endpoint-cleanup:true
egress-multi-home-ip-rule-compat:false
bgp-announce-pod-cidr:false
config-dir:/tmp/cilium/config-map
proxy-portrange-max:20000
proxy-idle-timeout-seconds:60
enable-masquerade-to-route-source:false
kube-proxy-replacement-healthz-bind-address:
ipv6-service-range:auto
bpf-lb-acceleration:disabled
labels:
enable-external-ips:false
hubble-redact-http-userinfo:true
disable-endpoint-crd:false
log-driver:
custom-cni-conf:false
max-connected-clusters:255
endpoint-gc-interval:5m0s
hubble-drop-events-reasons:auth_required,policy_denied
ingress-secrets-namespace:
pprof-address:localhost
k8s-client-connection-keep-alive:30s
proxy-prometheus-port:0
proxy-portrange-min:10000
enable-ipsec-encrypted-overlay:false
enable-k8s-endpoint-slice:true
enable-svc-source-range-check:true
cluster-name:cmesh93
enable-vtep:false
endpoint-queue-size:25
arping-refresh-period:30s
disable-external-ip-mitigation:false
enable-bpf-tproxy:false
ipsec-key-file:
k8s-kubeconfig-path:
max-controller-interval:0
enable-endpoint-routes:false
enable-ipv4-fragment-tracking:true
crd-wait-timeout:5m0s
cluster-pool-ipv4-cidr:10.92.0.0/16
enable-srv6:false
allow-icmp-frag-needed:true
force-device-detection:false
proxy-connect-timeout:2
enable-ipv4-masquerade:true
enable-icmp-rules:true
bpf-ct-timeout-service-tcp-grace:1m0s
ipv4-service-range:auto
policy-trigger-interval:1s
operator-prometheus-serve-addr::9963
enable-health-check-nodeport:true
clustermesh-ip-identities-sync-timeout:1m0s
log-system-load:false
hubble-event-buffer-capacity:4095
node-port-bind-protection:true
bpf-auth-map-max:524288
enable-runtime-device-detection:true
enable-policy:default
config:
srv6-encap-mode:reduced
bpf-map-event-buffers:
k8s-service-proxy-name:
enable-k8s:true
tofqdns-endpoint-max-ip-per-hostname:50
node-port-acceleration:disabled
kvstore-periodic-sync:5m0s
hubble-export-file-compress:false
iptables-random-fully:false
http-idle-timeout:0
hubble-redact-http-headers-deny:
enable-hubble-recorder-api:true
enable-service-topology:false
enable-xdp-prefilter:false
enable-ingress-controller:false
state-dir:/var/run/cilium
enable-ipv6-masquerade:true
mesh-auth-enabled:true
agent-health-port:9879
hubble-export-file-max-backups:5
enable-host-firewall:false
dns-policy-unload-on-shutdown:false
install-no-conntrack-iptables-rules:false
clustermesh-sync-timeout:1m0s
derive-masq-ip-addr-from-device:
nodeport-addresses:
kvstore-connectivity-timeout:2m0s
mesh-auth-spire-admin-socket:
enable-monitor:true
l2-announcements-retry-period:2s
enable-bgp-control-plane:false
http-max-grpc-timeout:0
dnsproxy-insecure-skip-transparent-mode-check:false
l2-pod-announcements-interface:
tunnel-port:0
bpf-lb-dsr-dispatch:opt
k8s-api-server:
hubble-flowlogs-config-path:
bpf-node-map-max:16384
enable-l2-pod-announcements:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-lb-sock-hostns-only:false
enable-l2-announcements:false
join-cluster:false
tofqdns-proxy-port:0
bpf-lb-mode:snat
egress-gateway-policy-map-max:16384
enable-tcx:true
policy-audit-mode:false
bpf-lb-service-backend-map-max:0
hubble-disable-tls:false
exclude-local-address:
label-prefix-file:
bpf-lb-maglev-table-size:16381
hubble-socket-path:/var/run/cilium/hubble.sock
bpf-ct-timeout-regular-tcp-syn:1m0s
ipv6-range:auto
enable-k8s-networkpolicy:true
hubble-export-file-path:
dnsproxy-lock-count:131
bpf-lb-maglev-map-max:0
route-metric:0
bpf-lb-rev-nat-map-max:0
monitor-queue-size:0
disable-iptables-feeder-rules:
operator-api-serve-addr:127.0.0.1:9234
k8s-client-qps:10
mesh-auth-mutual-listener-port:0
node-labels:
enable-identity-mark:true
enable-pmtu-discovery:false
vtep-mask:
dns-max-ips-per-restored-rule:1000
http-request-timeout:3600
enable-recorder:false
mesh-auth-signal-backoff-duration:1s
max-internal-timer-delay:0s
local-router-ipv6:
enable-endpoint-health-checking:true
encrypt-interface:
k8s-service-cache-size:128
hubble-recorder-storage-path:/var/run/cilium/pcaps
ipv4-pod-subnets:
exclude-node-label-patterns:
bypass-ip-availability-upon-restore:false
nodes-gc-interval:5m0s
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-ipv6-big-tcp:false
policy-cidr-match-mode:
monitor-aggregation-flags:all
external-envoy-proxy:true
keep-config:false
config-sources:config-map:kube-system/cilium-config
dnsproxy-lock-timeout:500ms
proxy-max-requests-per-connection:0
policy-accounting:true
certificates-directory:/var/run/cilium/certs
container-ip-local-reserved-ports:auto
hubble-redact-http-headers-allow:
bpf-lb-sock-terminate-pod-connections:false
cflags:
proxy-max-connection-duration-seconds:0
use-cilium-internal-ip-for-ipsec:false
enable-ipsec:false
dnsproxy-concurrency-limit:0
identity-allocation-mode:crd
hubble-monitor-events:
restore:true
enable-k8s-api-discovery:false
routing-mode:tunnel
dnsproxy-concurrency-processing-grace-period:0s
metrics:
bpf-policy-map-full-reconciliation-interval:15m0s
tofqdns-proxy-response-max-delay:100ms
cmdref:
mesh-auth-gc-interval:5m0s
bpf-events-policy-verdict-enabled:true
node-port-range:
hubble-listen-address::4244
enable-ipv4-big-tcp:false
enable-high-scale-ipcache:false
tunnel-protocol:vxlan
kvstore-opt:
l2-announcements-lease-duration:15s
bpf-ct-timeout-service-tcp:2h13m20s
hubble-export-file-max-size-mb:10
proxy-xff-num-trusted-hops-ingress:0
direct-routing-skip-unreachable:false
enable-node-selector-labels:false
hubble-metrics:
egress-gateway-reconciliation-trigger-interval:1s
identity-gc-interval:15m0s
enable-gateway-api:false
enable-ipv4-egress-gateway:false
ipv6-mcast-device:
bpf-ct-timeout-regular-tcp:2h13m20s
gateway-api-secrets-namespace:
hubble-skip-unknown-cgroup-ids:true
enable-ipv4:true
iptables-lock-timeout:5s
cni-log-file:/var/run/cilium/cilium-cni.log
allow-localhost:auto
pprof-port:6060
tofqdns-idle-connection-grace-period:0s
cluster-pool-ipv4-mask-size:24
l2-announcements-renew-deadline:5s
envoy-config-timeout:2m0s
nat-map-stats-interval:30s
ipsec-key-rotation-duration:5m0s
enable-cilium-api-server-access:
enable-ipv6-ndp:false
bpf-lb-source-range-map-max:0
api-rate-limit:
mtu:0
disable-envoy-version-check:false
hubble-export-allowlist:
cilium-endpoint-gc-interval:5m0s
nat-map-stats-entries:32
bpf-events-drop-enabled:true
http-normalize-path:true
direct-routing-device:
read-cni-conf:
fqdn-regex-compile-lru-size:1024
enable-ipv6:false
synchronize-k8s-nodes:true
identity-heartbeat-timeout:30m0s
enable-host-port:false
bpf-filter-priority:1
tofqdns-min-ttl:0
clustermesh-config:/var/lib/cilium/clustermesh/
ipv4-service-loopback-address:169.254.42.1
bpf-lb-service-map-max:0
ip-masq-agent-config-path:/etc/config/ip-masq-agent
cni-external-routing:false
hubble-metrics-server:
bpf-fragments-map-max:8192
envoy-keep-cap-netbindservice:false
conntrack-gc-max-interval:0s
monitor-aggregation:medium
enable-wireguard:false
version:false
bpf-lb-algorithm:random
hubble-export-denylist:
use-full-tls-context:false
k8s-sync-timeout:3m0s
prometheus-serve-addr:
hubble-redact-http-urlquery:false
gops-port:9890
tofqdns-max-deferred-connection-deletes:10000
encryption-strict-mode-cidr:
enable-sctp:false
identity-change-grace-period:5s
ipv4-node:auto
bpf-root:/sys/fs/bpf
k8s-client-burst:20
bpf-lb-rss-ipv6-src-cidr:
policy-queue-size:100
datapath-mode:veth
ipv6-pod-subnets:
debug-verbose:
enable-local-redirect-policy:false
bpf-lb-dsr-l4-xlate:frontend
proxy-xff-num-trusted-hops-egress:0
clustermesh-enable-endpoint-sync:false
vtep-cidr:
enable-ipsec-key-watcher:true
proxy-gid:1337
annotate-k8s-node:false
enable-k8s-terminating-endpoint:true
k8s-require-ipv4-pod-cidr:false
bpf-lb-affinity-map-max:0
debug:false
monitor-aggregation-interval:5s
enable-cilium-endpoint-slice:false
ipv6-node:auto
local-max-addr-scope:252
vtep-mac:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
kube-proxy-replacement:false
enable-bpf-masquerade:false
enable-auto-protect-node-port-range:true
ipam:cluster-pool
bpf-ct-timeout-regular-tcp-fin:10s
multicast-enabled:false
conntrack-gc-interval:0s
enable-health-checking:true
hubble-export-fieldmask:
local-router-ipv4:
bpf-map-dynamic-size-ratio:0.0025
bpf-ct-timeout-regular-any:1m0s
enable-l7-proxy:true
set-cilium-is-up-condition:true
enable-tracing:false
devices:
bpf-lb-map-max:65536
ipv4-native-routing-cidr:
enable-bbr:false
hubble-recorder-sink-queue-size:1024
kvstore-max-consecutive-quorum-errors:2
vtep-endpoint:
envoy-config-retry-interval:15s
enable-host-legacy-routing:false
ipam-multi-pool-pre-allocation:
trace-payloadlen:128
enable-ipip-termination:false
enable-custom-calls:false
k8s-heartbeat-timeout:30s
bpf-lb-external-clusterip:false
tofqdns-dns-reject-response-code:refused
clustermesh-enable-mcs-api:false
enable-hubble:true
encrypt-node:false
enable-nat46x64-gateway:false
cni-chaining-target:
enable-bandwidth-manager:false
static-cnp-path:
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-unreachable-routes:false
bpf-ct-timeout-service-any:1m0s
node-port-algorithm:random
bpf-lb-sock:false
prepend-iptables-chains:true
enable-cilium-health-api-server-access:
bpf-ct-global-any-max:262144
enable-wireguard-userspace-fallback:false
enable-session-affinity:false
enable-ipsec-xfrm-state-caching:true
cni-chaining-mode:none
bgp-config-path:/var/lib/cilium/bgp/config.yaml
bpf-sock-rev-map-max:262144
auto-create-cilium-node-resource:true
mesh-auth-rotated-identities-queue-size:1024
cluster-health-port:4240
set-cilium-node-taints:true
enable-envoy-config:false
bpf-lb-rss-ipv4-src-cidr:
bpf-neigh-global-max:524288
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
envoy-secrets-namespace:
hubble-drop-events-interval:2m0s
hubble-redact-kafka-apikey:false
enable-ip-masq-agent:false
enable-bpf-clock-probe:false
envoy-base-id:0
procfs:/host/proc
kvstore-lease-ttl:15m0s
remove-cilium-node-taints:true
bpf-nat-global-max:524288
enable-local-node-route:true
tofqdns-enable-dns-compression:true
fixed-identity-mapping:
vlan-bpf-bypass:
socket-path:/var/run/cilium/cilium.sock
service-no-backend-response:reject
pprof:false
egress-masquerade-interfaces:ens+
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
ipv6-cluster-alloc-cidr:f00d::/64
endpoint-bpf-prog-watchdog-interval:30s
install-iptables-rules:true
dnsproxy-enable-transparent-mode:true
enable-node-port:false
identity-restore-grace-period:30s
http-retry-timeout:0
mesh-auth-mutual-connect-timeout:5s
hubble-redact-enabled:false
enable-l2-neigh-discovery:true
dnsproxy-socket-linger-timeout:10
trace-sock:true
bpf-events-trace-enabled:true
k8s-namespace:kube-system
tofqdns-pre-cache:
ipam-cilium-node-update-rate:15s
allocator-list-timeout:3m0s
ipam-default-ip-pool:default
auto-direct-node-routes:false
bgp-announce-lb-ip:false
enable-mke:false
k8s-client-connection-timeout:30s
enable-xt-socket-fallback:true
log-opt:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-metrics:true
envoy-log:
k8s-require-ipv6-pod-cidr:false
hubble-prefer-ipv6:false
ipv4-range:auto
ipv6-native-routing-cidr:
hubble-drop-events:false
hubble-event-queue-size:0
```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001928630)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001b86c60,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001b86c60,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40021686e0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002168790)(frontends:[10.100.170.248]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002168840)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40036b26e0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40021691e0)(frontends:[10.100.186.218]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x40068493f0)(frontends:[10.100.235.26]/ports=[http]/selector=map[name:echo-same-node])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001783e40)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-vrv9m": (*k8s.Endpoints)(0x4001ceba00)(172.31.142.217:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001783e48)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-l5x8v": (*k8s.Endpoints)(0x40013552b0)(10.92.0.36:53/TCP[eu-west-3a],10.92.0.36:53/UDP[eu-west-3a],10.92.0.36:9153/TCP[eu-west-3a],10.92.0.64:53/TCP[eu-west-3a],10.92.0.64:53/UDP[eu-west-3a],10.92.0.64:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001709140)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-bpnpj": (*k8s.Endpoints)(0x40023fc0d0)(10.92.0.87:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x4001bde2f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-bgvw7": (*k8s.Endpoints)(0x40073ce8f0)(10.92.0.114:8080/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001783e38)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4001361380)(172.31.162.189:443/TCP,172.31.196.152:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001a88000)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000619450)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400a0782b8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001a72e40,
  gcExited: (chan struct {}) 0x4001a72ea0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40023b8f00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001c4af28)({
      MetricVec: (*prometheus.MetricVec)(0x4001a4eba0)({
       metricMap: (*prometheus.metricMap)(0x4001a4ebd0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f4e000)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40023b8f80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001c4af30)({
      MetricVec: (*prometheus.MetricVec)(0x4001a4ec30)({
       metricMap: (*prometheus.metricMap)(0x4001a4ec60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f4e060)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40023b9000)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c4af38)({
      MetricVec: (*prometheus.MetricVec)(0x4001a4ecc0)({
       metricMap: (*prometheus.metricMap)(0x4001a4ecf0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f4e0c0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40023b9080)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c4af40)({
      MetricVec: (*prometheus.MetricVec)(0x4001a4ed50)({
       metricMap: (*prometheus.metricMap)(0x4001a4ed80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f4e120)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40023b9100)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c4af48)({
      MetricVec: (*prometheus.MetricVec)(0x4001a4ede0)({
       metricMap: (*prometheus.metricMap)(0x4001a4ee10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f4e180)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40023b9180)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c4af50)({
      MetricVec: (*prometheus.MetricVec)(0x4001a4ee70)({
       metricMap: (*prometheus.metricMap)(0x4001a4eea0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f4e1e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40023b9200)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c4af58)({
      MetricVec: (*prometheus.MetricVec)(0x4001a4ef00)({
       metricMap: (*prometheus.metricMap)(0x4001a4ef30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f4e240)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40023b9280)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c4af60)({
      MetricVec: (*prometheus.MetricVec)(0x4001a4ef90)({
       metricMap: (*prometheus.metricMap)(0x4001a4efc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f4e2a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40023b9300)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001c4af68)({
      MetricVec: (*prometheus.MetricVec)(0x4001a4f020)({
       metricMap: (*prometheus.metricMap)(0x4001a4f050)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f4e300)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001a88000)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001a89180)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001a47560)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 262ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=11) "10.92.0.226": (string) (len=37) "cilium-test-1/client2-57cf4468f-2tmtl",
  (string) (len=11) "10.92.0.114": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-rlcml",
  (string) (len=11) "10.92.0.230": (string) (len=6) "router",
  (string) (len=11) "10.92.0.213": (string) (len=6) "health",
  (string) (len=10) "10.92.0.36": (string) (len=35) "kube-system/coredns-cc6ccd49c-db6rj",
  (string) (len=10) "10.92.0.64": (string) (len=35) "kube-system/coredns-cc6ccd49c-kdr79",
  (string) (len=11) "10.92.0.248": (string) (len=36) "cilium-test-1/client-974f6c69d-cxfg9",
  (string) (len=10) "10.92.0.87": (string) (len=50) "kube-system/clustermesh-apiserver-868d4f7654-8ggf4"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.142.217": (string) (len=7) "node-ip"
}

```

