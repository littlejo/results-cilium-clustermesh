markdown output at /tmp/cilium-bugtool-20241024-125425.276+0000-UTC-3747743169/cmd/cilium-debuginfo-20241024-125456.177+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125425.276+0000-UTC-3747743169/cmd/cilium-debuginfo-20241024-125456.177+0000-UTC.json
