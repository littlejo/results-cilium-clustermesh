[
  {
    "containers": [
      {
        "cgroup-id": 9142,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5df084cc_fc40_487d_b007_ec4684be62e5.slice/cri-containerd-5f2289525e610f7ba41fba43a362a9ad82aa1deb4be26c219aea2f06bc8d0f53.scope"
      },
      {
        "cgroup-id": 9058,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5df084cc_fc40_487d_b007_ec4684be62e5.slice/cri-containerd-a500a9346d3c098407194097b83fd1114b5130a62097ad8dea4c6d0e30fbc8c4.scope"
      },
      {
        "cgroup-id": 9226,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5df084cc_fc40_487d_b007_ec4684be62e5.slice/cri-containerd-391ded0b30213f291fd074de05c7845ac7616e599a6d8a73be315f55bd5adc16.scope"
      }
    ],
    "ips": [
      "10.92.0.87"
    ],
    "name": "clustermesh-apiserver-868d4f7654-8ggf4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7582,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76d70b1d_f88e_4093_a084_f4e96c0c6880.slice/cri-containerd-6b197a53494c81d1b9f22427976e2e3df4b42f9de6d334e0614d44b73aed6729.scope"
      }
    ],
    "ips": [
      "10.92.0.36"
    ],
    "name": "coredns-cc6ccd49c-db6rj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9814,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2a1edf6_c8d7_483a_81ee_d77c0ed6a6e7.slice/cri-containerd-bdfb6d52c53c2438ee6489cc8670fdd3aba1d2b12afc26988eb13c6a1f3b3e17.scope"
      }
    ],
    "ips": [
      "10.92.0.248"
    ],
    "name": "client-974f6c69d-cxfg9",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10066,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74106bf6_8167_4f9b_833e_8a37b8f7cb41.slice/cri-containerd-3bf1acf19fc17b7c83890f807ebab498e73870083ac95ccff6a2120f8f94742f.scope"
      },
      {
        "cgroup-id": 9982,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74106bf6_8167_4f9b_833e_8a37b8f7cb41.slice/cri-containerd-be166dfc5beea3e2b198a97504c5b94eba0e2b30d16a8b992d1f7224ac09b5b8.scope"
      }
    ],
    "ips": [
      "10.92.0.114"
    ],
    "name": "echo-same-node-86d9cc975c-rlcml",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9898,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf3406461_6d8a_447a_8ff5_54ac2c5aa554.slice/cri-containerd-58d3416b98aed99cd1c6b0ac0a9ec5ae4b06950f1502e4a72d804921ad4073bf.scope"
      }
    ],
    "ips": [
      "10.92.0.226"
    ],
    "name": "client2-57cf4468f-2tmtl",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7666,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6cbe81b_50f5_4ff3_94b7_94d01802ad5f.slice/cri-containerd-0c0c59c0d9f0941a834a85bfc1a4fc2ce29d28591c686c50b33129ba7b5ef26c.scope"
      }
    ],
    "ips": [
      "10.92.0.64"
    ],
    "name": "coredns-cc6ccd49c-kdr79",
    "namespace": "kube-system"
  }
]

