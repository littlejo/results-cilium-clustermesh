IP ADDRESS         LOCAL ENDPOINT INFO
10.92.0.87:0       id=3725  sec_id=6125384 flags=0x0000 ifindex=18  mac=36:2D:FE:CC:11:2D nodemac=46:3A:55:71:A2:63   
10.92.0.226:0      id=2020  sec_id=6123850 flags=0x0000 ifindex=22  mac=42:00:72:C1:DC:E3 nodemac=52:7E:B3:F6:01:11   
10.92.0.36:0       id=2479  sec_id=6149363 flags=0x0000 ifindex=12  mac=E2:4C:8E:E9:D6:3B nodemac=7A:7B:9B:F1:B7:CD   
10.92.0.114:0      id=3186  sec_id=6119752 flags=0x0000 ifindex=24  mac=7A:F0:6C:01:31:8F nodemac=06:B6:1F:ED:D8:62   
172.31.156.125:0   (localhost)                                                                                        
10.92.0.213:0      id=810   sec_id=4     flags=0x0000 ifindex=10  mac=CE:08:CA:F5:7E:BA nodemac=26:68:D5:12:16:16     
10.92.0.64:0       id=2164  sec_id=6149363 flags=0x0000 ifindex=14  mac=9E:1D:05:1E:E0:D5 nodemac=E6:2A:FF:86:F0:47   
172.31.142.217:0   (localhost)                                                                                        
10.92.0.248:0      id=1523  sec_id=6153838 flags=0x0000 ifindex=20  mac=C2:93:BB:1C:D5:CC nodemac=3A:97:F8:F6:17:AB   
10.92.0.230:0      (localhost)                                                                                        
