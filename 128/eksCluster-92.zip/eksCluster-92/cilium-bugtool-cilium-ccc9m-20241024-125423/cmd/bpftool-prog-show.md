32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:46+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:46+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:47+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:47+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:47+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:47+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:51+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:00+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:31:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
482: sched_cls  name tail_handle_ipv4  tag 36285999d58e83b9  gpl
	loaded_at 2024-10-24T12:31:19+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
483: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:31:19+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:31:19+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
515: sched_cls  name tail_ipv4_ct_egress  tag 0ea3eef69980cd86  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 165
516: sched_cls  name tail_ipv4_ct_ingress  tag e514dc15f392bfe1  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 166
517: sched_cls  name __send_drop_notify  tag ce5ab5fcf9d148d9  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 167
518: sched_cls  name cil_from_container  tag cfb4a55d1b70e6e1  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 168
519: sched_cls  name tail_handle_ipv4  tag 23a760235d1fcc56  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 169
523: sched_cls  name tail_handle_arp  tag 3bf07fa54112b46e  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 172
524: sched_cls  name tail_handle_ipv4_cont  tag 5343fce18c15da03  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 174
526: sched_cls  name tail_ipv4_to_endpoint  tag a4e7c18427a1c10c  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 175
527: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 177
532: sched_cls  name handle_policy  tag 9b6ad063829c0554  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 178
536: sched_cls  name __send_drop_notify  tag 62c611794e7cb664  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
537: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,116
	btf_id 187
538: sched_cls  name tail_handle_ipv4_from_host  tag 2087c1dfa6793787  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,116
	btf_id 188
539: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,116
	btf_id 189
541: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
542: sched_cls  name __send_drop_notify  tag 62c611794e7cb664  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 194
544: sched_cls  name tail_handle_ipv4_from_host  tag 2087c1dfa6793787  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 196
547: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 203
550: sched_cls  name tail_handle_ipv4_from_host  tag 2087c1dfa6793787  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 204
554: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 208
555: sched_cls  name __send_drop_notify  tag 62c611794e7cb664  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 209
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 211
557: sched_cls  name tail_handle_ipv4_from_host  tag 2087c1dfa6793787  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 212
561: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 216
562: sched_cls  name __send_drop_notify  tag 62c611794e7cb664  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 217
563: sched_cls  name tail_ipv4_ct_ingress  tag 77eb6c566b1eaba2  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 197
564: sched_cls  name handle_policy  tag 8439db1ce12ba0ca  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 219
565: sched_cls  name handle_policy  tag 7c7d911f0c7f83af  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,119,82,83,120,41,80,114,39,84,75,40,37,38
	btf_id 220
566: sched_cls  name cil_from_container  tag c58440fc5c7b4e96  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 119,76
	btf_id 222
567: sched_cls  name tail_handle_ipv4  tag 0bd39a35eac1b100  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 221
568: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 224
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,119
	btf_id 223
571: sched_cls  name tail_ipv4_to_endpoint  tag 75f2ee982e4b311a  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 226
572: sched_cls  name tail_ipv4_to_endpoint  tag 731b5b287d539335  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,120,41,82,83,80,114,39,119,40,37,38
	btf_id 227
573: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 228
574: sched_cls  name tail_ipv4_ct_egress  tag 0ea3eef69980cd86  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 229
575: sched_cls  name tail_handle_ipv4_cont  tag 1dfd64c19a9bf7dc  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 230
577: sched_cls  name tail_handle_arp  tag be2c5a4d5f6913cc  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,119
	btf_id 232
578: sched_cls  name tail_handle_ipv4_cont  tag 52d42756e918dca1  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,120,41,114,82,83,39,76,74,77,119,40,37,38,81
	btf_id 233
579: sched_cls  name __send_drop_notify  tag 9cf6af46b93ab841  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
580: sched_cls  name tail_ipv4_ct_ingress  tag 0b2119dd12790cec  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 234
581: sched_cls  name __send_drop_notify  tag ce9bb38318a9b694  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 237
582: sched_cls  name cil_from_container  tag 845e0187dbf14aa7  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 238
583: sched_cls  name tail_handle_arp  tag 61ebb246fdfd6df5  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 239
584: sched_cls  name tail_handle_ipv4  tag 664ed442bed5900d  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,119
	btf_id 236
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_ipv4_to_endpoint  tag 3cabc02aa93ce14c  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 253
641: sched_cls  name tail_ipv4_ct_egress  tag e39a9b5e7b3913f7  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 254
642: sched_cls  name handle_policy  tag b6a11ac408adba21  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 255
643: sched_cls  name cil_from_container  tag 4c4d84027c15f104  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 256
645: sched_cls  name tail_ipv4_ct_ingress  tag f682483cb21c9885  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 258
646: sched_cls  name __send_drop_notify  tag 7bc9cf28f52203a7  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 259
647: sched_cls  name tail_handle_ipv4  tag dbfe5e10d84a3b5f  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 260
648: sched_cls  name tail_handle_ipv4_cont  tag f99e5d21cd38eade  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 261
649: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 262
650: sched_cls  name tail_handle_arp  tag 88965cdaab90c8a0  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
690: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
693: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
720: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
723: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
724: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
727: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
728: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
731: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
732: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
735: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
736: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
739: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3303: sched_cls  name tail_ipv4_to_endpoint  tag f645a734fc97629b  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,633,41,82,83,80,158,39,634,40,37,38
	btf_id 3097
3304: sched_cls  name tail_ipv4_ct_ingress  tag 0d28f41beb5f5d59  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3098
3305: sched_cls  name tail_handle_arp  tag 665ac4b4348d48bc  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,634
	btf_id 3099
3308: sched_cls  name tail_handle_ipv4  tag ce4b4d33d0ce8c7e  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,634
	btf_id 3100
3314: sched_cls  name handle_policy  tag d20a88f0f5508c68  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,634,82,83,633,41,80,158,39,84,75,40,37,38
	btf_id 3105
3315: sched_cls  name __send_drop_notify  tag 781c1c086a3e90d5  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3111
3316: sched_cls  name tail_ipv4_ct_egress  tag 26498b2375ccd4ef  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3112
3318: sched_cls  name tail_handle_ipv4_cont  tag 290dc03de0e21df9  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,633,41,158,82,83,39,76,74,77,634,40,37,38,81
	btf_id 3114
3320: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,634
	btf_id 3115
3321: sched_cls  name cil_from_container  tag 0a2bc724e567d90b  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,76
	btf_id 3117
3358: sched_cls  name tail_handle_arp  tag 85169cab2f2eb76c  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,644
	btf_id 3158
3359: sched_cls  name tail_ipv4_ct_ingress  tag 98513c8f47c07027  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,645,84
	btf_id 3159
3360: sched_cls  name tail_ipv4_ct_ingress  tag 3252f57cfdda24d9  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,646,84
	btf_id 3160
3361: sched_cls  name tail_handle_arp  tag 052059d665e61117  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,643
	btf_id 3161
3362: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,643
	btf_id 3163
3363: sched_cls  name tail_ipv4_to_endpoint  tag e9061fae7a790cbc  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,646,41,82,83,80,151,39,644,40,37,38
	btf_id 3162
3364: sched_cls  name handle_policy  tag 298e1c57147ea569  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,643,82,83,645,41,80,155,39,84,75,40,37,38
	btf_id 3164
3365: sched_cls  name cil_from_container  tag 8742579bee9f7dd4  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 643,76
	btf_id 3166
3367: sched_cls  name __send_drop_notify  tag e42eaf9e4b45e11a  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3168
3368: sched_cls  name tail_handle_ipv4  tag be572cba8f21f162  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,644
	btf_id 3165
3369: sched_cls  name tail_ipv4_ct_egress  tag 05acd02372c18039  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,646,84
	btf_id 3170
3370: sched_cls  name tail_handle_ipv4_cont  tag e23f881e5350f59d  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,645,41,155,82,83,39,76,74,77,643,40,37,38,81
	btf_id 3169
3371: sched_cls  name tail_ipv4_to_endpoint  tag 66196176c871d993  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,645,41,82,83,80,155,39,643,40,37,38
	btf_id 3171
3372: sched_cls  name tail_handle_ipv4  tag 2c312555ef26b829  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,643
	btf_id 3173
3373: sched_cls  name tail_ipv4_ct_egress  tag a99a503f733cfb0e  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,645,84
	btf_id 3174
3374: sched_cls  name handle_policy  tag d6335a686433a877  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,644,82,83,646,41,80,151,39,84,75,40,37,38
	btf_id 3172
3376: sched_cls  name __send_drop_notify  tag fc4ec9aaa2663208  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3176
3377: sched_cls  name cil_from_container  tag 73547bc2e0fe2210  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 644,76
	btf_id 3177
3378: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,644
	btf_id 3178
3379: sched_cls  name tail_handle_ipv4_cont  tag 468b3cbe95246283  gpl
	loaded_at 2024-10-24T12:51:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,646,41,151,82,83,39,76,74,77,644,40,37,38,81
	btf_id 3179
