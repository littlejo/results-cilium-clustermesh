Node 0, zone      DMA    290    136     30     36     13      9     27     22      7      6     33 
Node 0, zone   Normal     98      9      1      2      8     13      1      8      5      1      7 
