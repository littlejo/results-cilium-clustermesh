USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3293  0.0  0.4 1240432 16720 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3308  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3310  0.0  0.4 1240432 16720 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3269  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3255  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3251  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3245  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.6  7.3 1538804 289276 ?      Ssl  12:31   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.3  0.2 1229744 10052 ?       Sl   12:31   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
