alloc: 123.66MB (129666480 bytes)
total-alloc: 3.11GB (3340385288 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 75541133
frees: 74299412
heap-alloc: 123.66MB (129666480 bytes)
heap-sys: 176.39MB (184958976 bytes)
heap-idle: 30.23MB (31703040 bytes)
heap-in-use: 146.16MB (153255936 bytes)
heap-released: 8.45MB (8863744 bytes)
heap-objects: 1241721
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.31MB (2423360 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 778.80KB (797489 bytes)
gc-sys: 5.77MB (6048840 bytes)
next-gc: when heap-alloc >= 157.55MB (165202408 bytes)
last-gc: 2024-10-24 12:54:25.488957583 +0000 UTC
gc-pause-total: 18.343758ms
gc-pause: 6565641
gc-pause-end: 1729774465488957583
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006535282141876386
enable-gc: true
debug-gc: false
