xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 554
ens6(5) clsact/ingress cil_from_netdev-ens6 id 561
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 539
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 582
lxc3b7e4c39c10b(12) clsact/ingress cil_from_container-lxc3b7e4c39c10b id 518
lxc63e94aabbb5b(14) clsact/ingress cil_from_container-lxc63e94aabbb5b id 566
lxc785f65126f86(18) clsact/ingress cil_from_container-lxc785f65126f86 id 643
lxcc8105a8df8db(20) clsact/ingress cil_from_container-lxcc8105a8df8db id 3377
lxc56b0c14b3ff2(22) clsact/ingress cil_from_container-lxc56b0c14b3ff2 id 3365
lxc4d019ce28594(24) clsact/ingress cil_from_container-lxc4d019ce28594 id 3321

flow_dissector:

netfilter:

