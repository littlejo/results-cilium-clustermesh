1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:f1:c7:0a:d1:bb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.142.217/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3507sec preferred_lft 3507sec
    inet6 fe80::4f1:c7ff:fe0a:d1bb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:6e:0f:9f:83:e3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.156.125/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::46e:fff:fe9f:83e3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:81:15:5b:1a:0c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6881:15ff:fe5b:1a0c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:2f:4c:19:4a:3e brd ff:ff:ff:ff:ff:ff
    inet 10.92.0.230/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::882f:4cff:fe19:4a3e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ca:8c:03:bf:8c:45 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c88c:3ff:febf:8c45/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:68:d5:12:16:16 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2468:d5ff:fe12:1616/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3b7e4c39c10b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:7b:9b:f1:b7:cd brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::787b:9bff:fef1:b7cd/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc63e94aabbb5b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:2a:ff:86:f0:47 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e42a:ffff:fe86:f047/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc785f65126f86@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:3a:55:71:a2:63 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::443a:55ff:fe71:a263/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcc8105a8df8db@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:97:f8:f6:17:ab brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::3897:f8ff:fef6:17ab/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc56b0c14b3ff2@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:7e:b3:f6:01:11 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::507e:b3ff:fef6:111/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc4d019ce28594@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:b6:1f:ed:d8:62 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::4b6:1fff:feed:d862/64 scope link 
       valid_lft forever preferred_lft forever
