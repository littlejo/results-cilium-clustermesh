KEY             VALUE
AgentLiveness   1933214597815
UTimeOffset     3378462037109375
