CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6cbe81b_50f5_4ff3_94b7_94d01802ad5f.slice/cri-containerd-0c0c59c0d9f0941a834a85bfc1a4fc2ce29d28591c686c50b33129ba7b5ef26c.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6cbe81b_50f5_4ff3_94b7_94d01802ad5f.slice/cri-containerd-9e1b4150c6979a0a9ffded025ad758cfb6e9b7d71a0335011ce696408d679714.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d6bfb6c_09d4_48b5_8156_12bed5988c59.slice/cri-containerd-e7493d549e0cf1cac2bfeba1c012b0bc60cbed33aa60bac09890169ba94cab03.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d6bfb6c_09d4_48b5_8156_12bed5988c59.slice/cri-containerd-6cab20e476051b177295f3f0ddfccf716755ece090253f8781a225238c18b183.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76d70b1d_f88e_4093_a084_f4e96c0c6880.slice/cri-containerd-0cf044dffb51f52a4ad757e8dc6e6ea0e3b883da7b8f9819c361a5d7652d071c.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76d70b1d_f88e_4093_a084_f4e96c0c6880.slice/cri-containerd-6b197a53494c81d1b9f22427976e2e3df4b42f9de6d334e0614d44b73aed6729.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod01112b5f_83a7_48c0_bcc8_efc94e24898d.slice/cri-containerd-26e1eb4d0c8be542359cfb3776895eba026c258cc03906c0ec71cd764e5f0a55.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod01112b5f_83a7_48c0_bcc8_efc94e24898d.slice/cri-containerd-790ba2df818214ae8a01a3473d439561949d5973958f73d928da13050a391e12.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3cba22a5_5d85_45aa_8b51_2a19253d6111.slice/cri-containerd-0975be2796f06e76bd00cc94801b8c23e57de64f25f35764b046477e0e2ad3d0.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3cba22a5_5d85_45aa_8b51_2a19253d6111.slice/cri-containerd-879dcbf87d11f36dfed61a93d212692f6cfefadb9ecf3996265bc87e21cd9f9d.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2a1edf6_c8d7_483a_81ee_d77c0ed6a6e7.slice/cri-containerd-c50268e15cd36a6bb7d317a176e11370f423387686471fac692069cae3ffb243.scope
    693      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2a1edf6_c8d7_483a_81ee_d77c0ed6a6e7.slice/cri-containerd-bdfb6d52c53c2438ee6489cc8670fdd3aba1d2b12afc26988eb13c6a1f3b3e17.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf3406461_6d8a_447a_8ff5_54ac2c5aa554.slice/cri-containerd-58d3416b98aed99cd1c6b0ac0a9ec5ae4b06950f1502e4a72d804921ad4073bf.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf3406461_6d8a_447a_8ff5_54ac2c5aa554.slice/cri-containerd-94f2dae417b95aef5892e7e39a69200e9ee131cb035f758d8dbfb5e3821c8c6f.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74106bf6_8167_4f9b_833e_8a37b8f7cb41.slice/cri-containerd-3bf1acf19fc17b7c83890f807ebab498e73870083ac95ccff6a2120f8f94742f.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74106bf6_8167_4f9b_833e_8a37b8f7cb41.slice/cri-containerd-5623736f828392208526b57a6d1c5c5babbf8b2a7530616ce2809fcea5d691d9.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74106bf6_8167_4f9b_833e_8a37b8f7cb41.slice/cri-containerd-be166dfc5beea3e2b198a97504c5b94eba0e2b30d16a8b992d1f7224ac09b5b8.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda59b142e_ac8f_4867_85de_82632b75ecd1.slice/cri-containerd-5a4dcc582c90c5331eda1bbfc2f727f4b3563bf328c7fe66e2d5d1d58318e5a2.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda59b142e_ac8f_4867_85de_82632b75ecd1.slice/cri-containerd-86d28041b5e6f83a3448db3498901c607665c55d2daa372edd2b34a45f6578d4.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5df084cc_fc40_487d_b007_ec4684be62e5.slice/cri-containerd-5ff24c04a3fd2257a2f5e766f579f2071e2ab88ea611e72c391cae0cc3cd70f1.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5df084cc_fc40_487d_b007_ec4684be62e5.slice/cri-containerd-391ded0b30213f291fd074de05c7845ac7616e599a6d8a73be315f55bd5adc16.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5df084cc_fc40_487d_b007_ec4684be62e5.slice/cri-containerd-a500a9346d3c098407194097b83fd1114b5130a62097ad8dea4c6d0e30fbc8c4.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5df084cc_fc40_487d_b007_ec4684be62e5.slice/cri-containerd-5f2289525e610f7ba41fba43a362a9ad82aa1deb4be26c219aea2f06bc8d0f53.scope
    674      cgroup_device   multi                                          
