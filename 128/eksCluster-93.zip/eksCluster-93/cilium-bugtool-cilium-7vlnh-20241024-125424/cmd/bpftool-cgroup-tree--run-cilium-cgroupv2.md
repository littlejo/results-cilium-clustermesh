CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9698f1ea_faaa_4d05_9e00_6b39c7222b63.slice/cri-containerd-ba290ab60b81212f1d6ba6d59221c1aea24f18e582e9c9fe16678a9d53285afb.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9698f1ea_faaa_4d05_9e00_6b39c7222b63.slice/cri-containerd-c50f78d5bff609c02cf5fbd894d9195e38e4138ce22ce6a2edcc566dc10b9f68.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c731268_a30e_4f21_9a84_ca4d714b1d8b.slice/cri-containerd-05b5be1f850904182b5217a292a69e8360b3ecf32cc41a4f4ca55a5b65ab8f20.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c731268_a30e_4f21_9a84_ca4d714b1d8b.slice/cri-containerd-455a862b2e907cde49b16d72927d0684c2b13f85ec569a447dcd9a78253e001c.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e02574d_4d69_4ea5_bec6_b562d97b0a04.slice/cri-containerd-ab563e893437a3cbd82f0ebafa9032df6e2dc625c759d6212fc701d81dd48986.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e02574d_4d69_4ea5_bec6_b562d97b0a04.slice/cri-containerd-ae2a8f90ac75880d5a5d5491ba53c26236184faf9228887f373485b06bb615df.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e951eb9_3b7e_4d4e_8b81_c752dcc3ed72.slice/cri-containerd-94264c71431c11cf6ff03e2453b8750e39067128d8aeaf9e19b064ca7628004d.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e951eb9_3b7e_4d4e_8b81_c752dcc3ed72.slice/cri-containerd-3ba410a5f629e476ad05877a814d7b66065be6517959e1f6407397ce894e04b2.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf312c1fb_efaf_494c_b8b2_f831efc54e60.slice/cri-containerd-6eb3fc4ca5e5b351ab375b17893a5dacb1fb0f82642231178d1d430bd4d17ab5.scope
    712      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf312c1fb_efaf_494c_b8b2_f831efc54e60.slice/cri-containerd-f260a125db05c5e019cf23e3119592e6eab9a02c00a2e94259aed08f31bcebec.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4f862f14_fb7f_43eb_8f92_eea231ccf70b.slice/cri-containerd-e8ad3bea52ab3c1fc09087ad6a375f53d2e6aff08d49c589185849b2aa1f083e.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4f862f14_fb7f_43eb_8f92_eea231ccf70b.slice/cri-containerd-92622f8ac34df945b5e2f31c59f390d322d66b8c07875775c6e655d346606bee.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a461f98_3895_41cd_b0b4_796567f8cedd.slice/cri-containerd-0b61e0bf42382cf762870df24e294bdf3d6a8c3264c5fa72ae4b2ed52cc52daf.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a461f98_3895_41cd_b0b4_796567f8cedd.slice/cri-containerd-787322dabce8ea74f71b493f444a83e5146b8227dec323db931eee64b6bb722c.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb496f82_7b1d_4f3d_a4a5_e474e2b26dda.slice/cri-containerd-05f3fc2a9a8be44fb253c5253163344f29df87f6869723b600034c5bf9792833.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb496f82_7b1d_4f3d_a4a5_e474e2b26dda.slice/cri-containerd-538795fd3ebf11d024a48584470a7b2a41c5182e1c157b998c2d77459c5bb1e5.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod312d7663_d8ab_4232_99fc_8c765f63a7bb.slice/cri-containerd-437594d46739177ac0ddc72bffb8437e193c6f8203436280bf086e2d6fc51254.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod312d7663_d8ab_4232_99fc_8c765f63a7bb.slice/cri-containerd-8877a673f4b6d5663f3e208b87c778a7fd2044c8b112b63733368c9b22efebb8.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod312d7663_d8ab_4232_99fc_8c765f63a7bb.slice/cri-containerd-cf0426ad72bf0f8b1ff88eebc2b076fca9c155aa3f6d0714227fc2bd2c95d4a8.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod312d7663_d8ab_4232_99fc_8c765f63a7bb.slice/cri-containerd-a732b53f849d7b2929888ed58a3329996355d3a3a725d07504cf48175819fff8.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode50050d4_b356_461f_88b5_10b1a2b89620.slice/cri-containerd-f2a9d4fb951dee8bf8b3ee6920ead76e4b10bca6198fd329a4b177e423c6843a.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode50050d4_b356_461f_88b5_10b1a2b89620.slice/cri-containerd-39683af91a4729adfade50519795cff6927e591fd26d62368680702ddc3573fb.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode50050d4_b356_461f_88b5_10b1a2b89620.slice/cri-containerd-885c65f10af63199f708cc57e54c42925fcce65d0bd80866ce0208a4c50624f4.scope
    736      cgroup_device   multi                                          
