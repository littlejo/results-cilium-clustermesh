 12:54:25 up 31 min,  0 users,  load average: 1.15, 0.77, 0.41
