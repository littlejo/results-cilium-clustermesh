KEY             VALUE
AgentLiveness   1901214457030
UTimeOffset     3378462042968750
