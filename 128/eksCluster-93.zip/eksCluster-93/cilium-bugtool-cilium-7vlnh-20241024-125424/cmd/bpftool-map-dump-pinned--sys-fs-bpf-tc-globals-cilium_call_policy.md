key: ab 01 00 00  value: 37 02 00 00
key: ac 01 00 00  value: 0f 02 00 00
key: cc 03 00 00  value: 2a 0d 00 00
key: 42 04 00 00  value: 1f 0d 00 00
key: e3 05 00 00  value: 45 02 00 00
key: fc 06 00 00  value: 83 02 00 00
key: 5a 0c 00 00  value: e4 0c 00 00
Found 7 elements
