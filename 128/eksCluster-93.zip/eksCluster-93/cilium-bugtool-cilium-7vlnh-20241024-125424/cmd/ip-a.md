1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:7f:61:d9:1b:65 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.237.87/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3510sec preferred_lft 3510sec
    inet6 fe80::87f:61ff:fed9:1b65/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:33:ab:45:92:47 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.203.108/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::833:abff:fe45:9247/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:c7:24:6f:7e:61 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c7:24ff:fe6f:7e61/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:56:6f:c5:20:96 brd ff:ff:ff:ff:ff:ff
    inet 10.93.0.39/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f456:6fff:fec5:2096/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:15:17:48:a0:ca brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f415:17ff:fe48:a0ca/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:2b:e9:49:df:2f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::82b:e9ff:fe49:df2f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcffb818775372@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:17:6d:70:f0:03 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::dc17:6dff:fe70:f003/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc2d21cf318223@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:8b:43:7b:e8:8e brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6c8b:43ff:fe7b:e88e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc78686588284c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:ae:61:88:3a:af brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5cae:61ff:fe88:3aaf/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc273019ff4032@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:67:f3:60:9c:25 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9867:f3ff:fe60:9c25/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc2cd38e42b400@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:80:99:7b:18:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::6c80:99ff:fe7b:18a3/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc57c9a4ca6aa5@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:92:75:60:5a:f4 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::2492:75ff:fe60:5af4/64 scope link 
       valid_lft forever preferred_lft forever
