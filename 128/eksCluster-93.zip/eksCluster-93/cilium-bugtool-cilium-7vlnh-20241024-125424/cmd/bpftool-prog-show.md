29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:53+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
104: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
107: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:31:29+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
479: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:31:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
480: sched_cls  name tail_handle_ipv4  tag 0db624fb61afd775  gpl
	loaded_at 2024-10-24T12:31:29+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:31:29+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
510: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 163
511: sched_cls  name tail_ipv4_ct_egress  tag 72b07dbc81cb8c5b  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 164
517: sched_cls  name tail_handle_ipv4  tag 7a4eba2b391e95d9  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 166
519: sched_cls  name tail_handle_arp  tag 2e52550b09588002  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 172
520: sched_cls  name tail_ipv4_ct_ingress  tag 63519e20974af033  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 173
521: sched_cls  name __send_drop_notify  tag 840db5aff420a6e8  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
522: sched_cls  name cil_from_container  tag 5c430d1210f9872a  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 175
525: sched_cls  name tail_handle_ipv4_cont  tag 230563d5710fa89c  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 178
527: sched_cls  name handle_policy  tag 6c6588321ce5b308  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 179
530: sched_cls  name tail_ipv4_to_endpoint  tag 385fba7ed7693b40  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 181
532: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,115
	btf_id 185
533: sched_cls  name tail_handle_ipv4_from_host  tag a1b30d358d547aa5  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,115
	btf_id 187
535: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 190
537: sched_cls  name __send_drop_notify  tag 2041010056bdce8c  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
538: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,115
	btf_id 193
539: sched_cls  name tail_handle_ipv4_from_host  tag a1b30d358d547aa5  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 195
541: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 197
543: sched_cls  name __send_drop_notify  tag 2041010056bdce8c  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
544: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 200
546: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 203
547: sched_cls  name __send_drop_notify  tag 2041010056bdce8c  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 204
548: sched_cls  name tail_ipv4_to_endpoint  tag cc275d7806729a06  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,118,41,82,83,80,114,39,117,40,37,38
	btf_id 188
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 205
552: sched_cls  name tail_handle_ipv4_from_host  tag a1b30d358d547aa5  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
555: sched_cls  name __send_drop_notify  tag 2041010056bdce8c  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 214
557: sched_cls  name tail_ipv4_ct_egress  tag 72b07dbc81cb8c5b  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 208
559: sched_cls  name tail_handle_arp  tag 5f159d04d2344034  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 216
560: sched_cls  name tail_handle_ipv4_from_host  tag a1b30d358d547aa5  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 217
563: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 221
564: sched_cls  name tail_handle_ipv4  tag c8201f23c465e27b  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 218
565: sched_cls  name tail_handle_ipv4_cont  tag 00355227ac3f218c  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,118,41,114,82,83,39,76,74,77,117,40,37,38,81
	btf_id 224
566: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 225
567: sched_cls  name handle_policy  tag b713301e8d1cc6af  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,117,82,83,118,41,80,114,39,84,75,40,37,38
	btf_id 226
568: sched_cls  name tail_ipv4_to_endpoint  tag 3f880eceeeafaa72  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 223
569: sched_cls  name cil_from_container  tag e2a1fa7b24f1c25f  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 117,76
	btf_id 227
570: sched_cls  name __send_drop_notify  tag 13e7de2bb64afa9b  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 229
571: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 228
572: sched_cls  name tail_ipv4_ct_ingress  tag 096fa4bb38009c22  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 230
573: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 231
574: sched_cls  name tail_handle_ipv4  tag 58d40efcea8570cd  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 232
575: sched_cls  name cil_from_container  tag e66bd90ebe5c323f  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 233
576: sched_cls  name tail_ipv4_ct_ingress  tag 3ff2365cf694bd09  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 234
577: sched_cls  name tail_handle_ipv4_cont  tag eff411fc2be4d09c  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 235
578: sched_cls  name __send_drop_notify  tag 15ffafc1c9989013  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 236
579: sched_cls  name tail_handle_arp  tag 6a09ea7c65ce942e  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 237
581: sched_cls  name handle_policy  tag e493fa68dafc1eb4  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 239
582: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
585: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
589: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
594: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
597: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: sched_cls  name tail_handle_arp  tag 7f518eb48cc44e0d  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 253
638: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 254
639: sched_cls  name tail_ipv4_ct_egress  tag c2c84ef094c21199  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 255
640: sched_cls  name tail_ipv4_ct_ingress  tag 1394e3b7a30131a4  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 256
642: sched_cls  name __send_drop_notify  tag 482843ee103f798c  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 258
643: sched_cls  name handle_policy  tag 59aa3fe54f2e4ed3  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 259
644: sched_cls  name tail_ipv4_to_endpoint  tag e1e5f0f15eab9cf7  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 260
645: sched_cls  name cil_from_container  tag 4b2be8b5b2747bd3  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 261
646: sched_cls  name tail_handle_ipv4_cont  tag 826aa42c84b62d8c  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 262
647: sched_cls  name tail_handle_ipv4  tag f97049f838ae67ba  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 263
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
709: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
712: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
713: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
716: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
717: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
720: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
721: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
724: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
725: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
728: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
729: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
732: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
733: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
736: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3300: sched_cls  name handle_policy  tag 031a85b237063d3b  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,154,39,84,75,40,37,38
	btf_id 3097
3302: sched_cls  name tail_handle_ipv4_cont  tag 3126d2fbdced2e65  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,154,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3100
3303: sched_cls  name tail_handle_arp  tag 379871e0948ce72c  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3102
3304: sched_cls  name tail_ipv4_ct_ingress  tag 517927d9f553954b  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3103
3306: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3104
3307: sched_cls  name __send_drop_notify  tag 057ec929d6b98acd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3106
3309: sched_cls  name tail_ipv4_ct_egress  tag 3514ad041105bf76  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3107
3313: sched_cls  name tail_handle_ipv4  tag fc5096d1c2381d8d  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3109
3315: sched_cls  name cil_from_container  tag b2de76d217451d9c  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3113
3317: sched_cls  name tail_ipv4_to_endpoint  tag 8833a6d06e6c5560  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,154,39,633,40,37,38
	btf_id 3115
3355: sched_cls  name __send_drop_notify  tag 274b233ee14dbdb9  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3158
3356: sched_cls  name tail_handle_arp  tag c3d6af82b72796c5  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,644
	btf_id 3160
3357: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,646
	btf_id 3159
3358: sched_cls  name tail_ipv4_ct_ingress  tag d7fa878edd7c9a29  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3161
3359: sched_cls  name handle_policy  tag 403b8ed41b8b9896  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,646,82,83,645,41,80,151,39,84,75,40,37,38
	btf_id 3162
3360: sched_cls  name tail_ipv4_to_endpoint  tag 86805f9546b72598  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,643,41,82,83,80,157,39,644,40,37,38
	btf_id 3163
3361: sched_cls  name tail_ipv4_ct_egress  tag eac87e9170cefe14  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3164
3363: sched_cls  name __send_drop_notify  tag 0db7367f68919199  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3167
3364: sched_cls  name cil_from_container  tag 42649ec0d271f167  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 646,76
	btf_id 3168
3365: sched_cls  name tail_handle_ipv4  tag d74712cedec3f9db  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,644
	btf_id 3165
3367: sched_cls  name tail_ipv4_ct_ingress  tag 73cd3d181d08b08f  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3169
3368: sched_cls  name tail_handle_arp  tag c4002da95a406ee1  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,646
	btf_id 3172
3369: sched_cls  name tail_ipv4_to_endpoint  tag 293e8f7faa7dfca1  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,645,41,82,83,80,151,39,646,40,37,38
	btf_id 3173
3370: sched_cls  name handle_policy  tag 9a17b17517524e4c  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,644,82,83,643,41,80,157,39,84,75,40,37,38
	btf_id 3171
3371: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,644
	btf_id 3175
3372: sched_cls  name tail_handle_ipv4_cont  tag 2fd36fd477ff263e  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,645,41,151,82,83,39,76,74,77,646,40,37,38,81
	btf_id 3174
3373: sched_cls  name tail_handle_ipv4_cont  tag 5be54afb89c3d689  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,643,41,157,82,83,39,76,74,77,644,40,37,38,81
	btf_id 3176
3374: sched_cls  name cil_from_container  tag 3e5ac7bd490032cd  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 644,76
	btf_id 3177
3375: sched_cls  name tail_ipv4_ct_egress  tag 23c3b2587e90f0ee  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3179
3376: sched_cls  name tail_handle_ipv4  tag 491f7df9c86a901e  gpl
	loaded_at 2024-10-24T12:51:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,646
	btf_id 3178
