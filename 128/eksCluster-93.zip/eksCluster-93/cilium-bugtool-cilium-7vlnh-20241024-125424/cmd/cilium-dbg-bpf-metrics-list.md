REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     129363    10481965    677    bpf_overlay.c
Interface                   INGRESS     628136    241827944   1132   bpf_host.c
Policy denied               EGRESS      61        4514        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      128327    10397680    53     encap.h
Success                     EGRESS      139064    18336204    1308   bpf_lxc.c
Success                     EGRESS      53269     4317539     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     161174    18122584    86     l3.h
Success                     INGRESS     238495    24485779    235    trace.h
Unsupported L3 protocol     EGRESS      74        5600        1492   bpf_lxc.c
