Endpoint ID: 427
Path: /sys/fs/bpf/tc/globals/cilium_policy_00427

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2406     27        0        
Allow    Ingress     1          ANY          NONE         disabled    129939   1494      0        
Allow    Egress      0          ANY          NONE         disabled    18510    203       0        


Endpoint ID: 428
Path: /sys/fs/bpf/tc/globals/cilium_policy_00428

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3490     33        0        
Allow    Ingress     1          ANY          NONE         disabled    131763   1514      0        
Allow    Egress      0          ANY          NONE         disabled    18951    210       0        


Endpoint ID: 972
Path: /sys/fs/bpf/tc/globals/cilium_policy_00972

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1090
Path: /sys/fs/bpf/tc/globals/cilium_policy_01090

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1507
Path: /sys/fs/bpf/tc/globals/cilium_policy_01507

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6209696   76762     0        
Allow    Ingress     1          ANY          NONE         disabled    59030     711       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1788
Path: /sys/fs/bpf/tc/globals/cilium_policy_01788

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5489405   56642     0        
Allow    Ingress     1          ANY          NONE         disabled    5140954   54069     0        
Allow    Egress      0          ANY          NONE         disabled    5996508   61207     0        


Endpoint ID: 2155
Path: /sys/fs/bpf/tc/globals/cilium_policy_02155

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3162
Path: /sys/fs/bpf/tc/globals/cilium_policy_03162

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    352341   4112      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


