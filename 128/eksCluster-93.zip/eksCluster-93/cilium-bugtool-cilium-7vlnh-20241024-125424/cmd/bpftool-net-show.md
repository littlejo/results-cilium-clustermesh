xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 546
ens6(5) clsact/ingress cil_from_netdev-ens6 id 563
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 541
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 535
cilium_host(7) clsact/egress cil_from_host-cilium_host id 532
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 575
lxcffb818775372(12) clsact/ingress cil_from_container-lxcffb818775372 id 522
lxc2d21cf318223(14) clsact/ingress cil_from_container-lxc2d21cf318223 id 569
lxc78686588284c(18) clsact/ingress cil_from_container-lxc78686588284c id 645
lxc273019ff4032(20) clsact/ingress cil_from_container-lxc273019ff4032 id 3364
lxc2cd38e42b400(22) clsact/ingress cil_from_container-lxc2cd38e42b400 id 3315
lxc57c9a4ca6aa5(24) clsact/ingress cil_from_container-lxc57c9a4ca6aa5 id 3374

flow_dissector:

netfilter:

