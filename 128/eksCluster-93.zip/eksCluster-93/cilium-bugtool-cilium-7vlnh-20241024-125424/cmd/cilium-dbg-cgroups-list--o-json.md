[
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf312c1fb_efaf_494c_b8b2_f831efc54e60.slice/cri-containerd-f260a125db05c5e019cf23e3119592e6eab9a02c00a2e94259aed08f31bcebec.scope"
      }
    ],
    "ips": [
      "10.93.0.5"
    ],
    "name": "client-974f6c69d-jxwd2",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9698f1ea_faaa_4d05_9e00_6b39c7222b63.slice/cri-containerd-c50f78d5bff609c02cf5fbd894d9195e38e4138ce22ce6a2edcc566dc10b9f68.scope"
      }
    ],
    "ips": [
      "10.93.0.136"
    ],
    "name": "coredns-cc6ccd49c-lz6p5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb496f82_7b1d_4f3d_a4a5_e474e2b26dda.slice/cri-containerd-538795fd3ebf11d024a48584470a7b2a41c5182e1c157b998c2d77459c5bb1e5.scope"
      }
    ],
    "ips": [
      "10.93.0.7"
    ],
    "name": "client2-57cf4468f-hfpt5",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod312d7663_d8ab_4232_99fc_8c765f63a7bb.slice/cri-containerd-8877a673f4b6d5663f3e208b87c778a7fd2044c8b112b63733368c9b22efebb8.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod312d7663_d8ab_4232_99fc_8c765f63a7bb.slice/cri-containerd-a732b53f849d7b2929888ed58a3329996355d3a3a725d07504cf48175819fff8.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod312d7663_d8ab_4232_99fc_8c765f63a7bb.slice/cri-containerd-437594d46739177ac0ddc72bffb8437e193c6f8203436280bf086e2d6fc51254.scope"
      }
    ],
    "ips": [
      "10.93.0.130"
    ],
    "name": "clustermesh-apiserver-fb78d679c-l2p6s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c731268_a30e_4f21_9a84_ca4d714b1d8b.slice/cri-containerd-455a862b2e907cde49b16d72927d0684c2b13f85ec569a447dcd9a78253e001c.scope"
      }
    ],
    "ips": [
      "10.93.0.75"
    ],
    "name": "coredns-cc6ccd49c-xvptt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode50050d4_b356_461f_88b5_10b1a2b89620.slice/cri-containerd-885c65f10af63199f708cc57e54c42925fcce65d0bd80866ce0208a4c50624f4.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode50050d4_b356_461f_88b5_10b1a2b89620.slice/cri-containerd-39683af91a4729adfade50519795cff6927e591fd26d62368680702ddc3573fb.scope"
      }
    ],
    "ips": [
      "10.93.0.171"
    ],
    "name": "echo-same-node-86d9cc975c-v66lc",
    "namespace": "cilium-test-1"
  }
]

