filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2d21cf318223 direct-action not_in_hw id 569 tag e2a1fa7b24f1c25f jited 
