{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.884Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.904Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.941Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.546Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.550Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.598Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.603Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.639Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.854Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.861Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.915Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.930Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.974Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.652Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.669Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.744Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.787Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.789Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.999Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.007Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.055Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.073Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.107Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.671Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.675Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.712Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.717Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.759Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.773Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.795Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.017Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.024Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.077Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.083Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.127Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.690Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.694Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.731Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.738Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.787Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.791Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.821Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.119Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.156Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.218Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.231Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.259Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.673Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.680Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.726Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.737Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.763Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.026Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.038Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.094Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.117Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.136Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.586Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.622Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.627Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.670Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.696Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.711Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.921Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.965Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.979Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.048Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.067Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.594Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.607Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.698Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.704Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.751Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.900Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.931Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.975Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.992Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.020Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.431Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.467Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.475Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.521Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.531Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.560Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.795Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.803Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.845Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.888Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.941Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.341Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.351Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.395Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.402Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.434Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.691Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.695Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.751Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.758Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.792Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.106Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.108Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.164Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.178Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.204Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.434Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.437Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.492Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.499Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.542Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.838Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.878Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.890Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.943Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.959Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.982Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.224Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.225Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.240Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.280Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.996Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.999Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.030Z",
  "value": "id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.065Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.072Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.385Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.389Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.089Z",
  "value": "id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.091Z",
  "value": "id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25"
}

