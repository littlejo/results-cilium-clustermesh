Total: 567
TCP:   2769 (estab 299, closed 2451, orphaned 0, timewait 1985)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  318       309       9        
INET	  328       315       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.237.87%ens5:68         0.0.0.0:*    uid:192 ino:135633 sk:8f7 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33597 sk:8f8 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15426 sk:8f9 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:33749      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=38)) ino:34311 sk:8fa fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33596 sk:8fb cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15427 sk:8fc cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::87f:61ff:fed9:1b65]%ens5:546           [::]:*    uid:192 ino:15360 sk:8fd cgroup:unreachable:bd0 v6only:1 <->                   
