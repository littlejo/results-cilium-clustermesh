Node 0, zone      DMA      2      1      4     11     20     12     12      4      1      3     46 
Node 0, zone   Normal    122     14     18     15     26     19      8      3      5      2      6 
