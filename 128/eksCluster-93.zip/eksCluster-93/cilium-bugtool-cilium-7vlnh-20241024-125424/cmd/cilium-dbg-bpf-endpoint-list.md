IP ADDRESS         LOCAL ENDPOINT INFO
10.93.0.75:0       id=427   sec_id=6197257 flags=0x0000 ifindex=14  mac=C6:15:17:3F:EA:5E nodemac=6E:8B:43:7B:E8:8E   
10.93.0.136:0      id=428   sec_id=6197257 flags=0x0000 ifindex=12  mac=56:39:6B:D2:FC:1E nodemac=DE:17:6D:70:F0:03   
10.93.0.171:0      id=3162  sec_id=6198630 flags=0x0000 ifindex=22  mac=5E:87:6D:40:94:F6 nodemac=6E:80:99:7B:18:A3   
172.31.203.108:0   (localhost)                                                                                        
10.93.0.7:0        id=972   sec_id=6170583 flags=0x0000 ifindex=24  mac=6A:8F:47:01:5A:58 nodemac=26:92:75:60:5A:F4   
10.93.0.130:0      id=1788  sec_id=6204177 flags=0x0000 ifindex=18  mac=AA:AC:38:F9:D8:6A nodemac=5E:AE:61:88:3A:AF   
10.93.0.170:0      id=1507  sec_id=4     flags=0x0000 ifindex=10  mac=9A:C2:53:C3:33:9F nodemac=0A:2B:E9:49:DF:2F     
10.93.0.5:0        id=1090  sec_id=6204610 flags=0x0000 ifindex=20  mac=42:AD:A6:E2:10:B4 nodemac=9A:67:F3:60:9C:25   
172.31.237.87:0    (localhost)                                                                                        
10.93.0.39:0       (localhost)                                                                                        
