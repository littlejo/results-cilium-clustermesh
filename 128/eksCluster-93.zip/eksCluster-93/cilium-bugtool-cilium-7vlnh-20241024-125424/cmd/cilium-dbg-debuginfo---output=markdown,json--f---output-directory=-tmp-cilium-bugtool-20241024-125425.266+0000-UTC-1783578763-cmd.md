markdown output at /tmp/cilium-bugtool-20241024-125425.266+0000-UTC-1783578763/cmd/cilium-debuginfo-20241024-125426.258+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125425.266+0000-UTC-1783578763/cmd/cilium-debuginfo-20241024-125426.258+0000-UTC.json
