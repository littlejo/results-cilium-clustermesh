alloc: 142.36MB (149274480 bytes)
total-alloc: 3.00GB (3220947232 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 73724162
frees: 72159546
heap-alloc: 142.36MB (149274480 bytes)
heap-sys: 174.29MB (182755328 bytes)
heap-idle: 18.64MB (19546112 bytes)
heap-in-use: 155.65MB (163209216 bytes)
heap-released: 11.73MB (12296192 bytes)
heap-objects: 1564616
stack-in-use: 37.44MB (39256064 bytes)
stack-sys: 37.44MB (39256064 bytes)
stack-mspan-inuse: 2.50MB (2625760 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 991.80KB (1015601 bytes)
gc-sys: 5.76MB (6042792 bytes)
next-gc: when heap-alloc >= 145.27MB (152331304 bytes)
last-gc: 2024-10-24 12:53:32.185621235 +0000 UTC
gc-pause-total: 17.343022ms
gc-pause: 175729
gc-pause-end: 1729774412185621235
num-gc: 97
num-forced-gc: 0
gc-cpu-fraction: 0.0006575214982295839
enable-gc: true
debug-gc: false
