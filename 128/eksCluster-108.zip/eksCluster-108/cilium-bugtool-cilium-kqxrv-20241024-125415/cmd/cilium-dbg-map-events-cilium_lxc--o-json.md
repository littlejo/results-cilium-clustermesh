{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.361Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.378Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.405Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.071Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.075Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.123Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.130Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.162Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.385Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.391Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.460Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.483Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.545Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.167Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.198Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.220Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.238Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.267Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.542Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.544Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.606Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.619Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.653Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.186Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.188Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.252Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.262Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.299Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.310Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.340Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.539Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.555Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.606Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.614Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.660Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.251Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.275Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.352Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.406Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.424Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.464Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.467Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.639Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.660Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.706Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.737Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.749Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.182Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.188Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.252Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.277Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.288Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.498Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.507Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.555Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.559Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.605Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.060Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.063Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.116Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.121Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.153Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.414Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.485Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.523Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.576Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.578Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.955Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.986Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.998Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.038Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.059Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.082Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.282Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.292Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.347Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.367Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.385Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.732Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.769Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.772Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.821Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.839Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.860Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.074Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.084Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.160Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.165Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.210Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.624Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.628Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.670Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.692Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.710Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.941Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.959Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.998Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.030Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.041Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.372Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.378Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.428Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.428Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.466Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.679Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.689Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.738Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.746Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.790Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.154Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.162Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.256Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.277Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.302Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.510Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.531Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.538Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.545Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.568Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.270Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.274Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.305Z",
  "value": "id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.328Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.350Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.589Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.603Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.244Z",
  "value": "id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.261Z",
  "value": "id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14"
}

