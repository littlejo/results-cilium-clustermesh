top - 12:54:16 up 31 min,  0 users,  load average: 0.37, 0.62, 0.37
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 24.1 us, 41.4 sy,  0.0 ni, 34.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    281.1 free,   1058.5 used,   2496.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2596.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539132 299440  79936 S   0.0   7.6   1:04.75 cilium-+
    404 root      20   0 1229744   8856   2924 S   0.0   0.2   0:04.36 cilium-+
   3245 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
   3247 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3272 root      20   0 1240432  16172  11228 S   0.0   0.4   0:00.03 cilium-+
   3278 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3314 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
   3346 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
