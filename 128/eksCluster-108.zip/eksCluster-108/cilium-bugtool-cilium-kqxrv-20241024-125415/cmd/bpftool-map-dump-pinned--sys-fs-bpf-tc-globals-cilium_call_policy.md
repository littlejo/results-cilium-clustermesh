key: ec 00 00 00  value: fe 01 00 00
key: 4b 01 00 00  value: 1a 0d 00 00
key: a5 01 00 00  value: 12 0d 00 00
key: c5 01 00 00  value: e0 0c 00 00
key: 21 04 00 00  value: 70 02 00 00
key: 55 04 00 00  value: 19 02 00 00
key: 62 07 00 00  value: 09 02 00 00
Found 7 elements
