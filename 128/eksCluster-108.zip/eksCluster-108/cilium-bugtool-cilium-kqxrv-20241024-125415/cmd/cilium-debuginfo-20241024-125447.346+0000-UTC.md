# Cilium debug information

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=12) "10.108.0.118": (string) (len=6) "router",
  (string) (len=12) "10.108.0.239": (string) (len=6) "health",
  (string) (len=11) "10.108.0.26": (string) (len=35) "kube-system/coredns-cc6ccd49c-kw8jg",
  (string) (len=12) "10.108.0.121": (string) (len=35) "kube-system/coredns-cc6ccd49c-8cj8l",
  (string) (len=12) "10.108.0.188": (string) (len=36) "cilium-test-1/client-974f6c69d-7g5vs",
  (string) (len=11) "10.108.0.22": (string) (len=50) "kube-system/clustermesh-apiserver-57884d66d4-gnlpm",
  (string) (len=11) "10.108.0.47": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-tjsnq",
  (string) (len=11) "10.108.0.72": (string) (len=37) "cilium-test-1/client2-57cf4468f-dcl8m"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.187.16": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x400127f290)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x400069cde0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x400069cde0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x4009620420)(frontends:[10.100.250.99]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002cda160)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002cda210)(frontends:[10.100.120.16]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002cda370)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x400127e6e0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x400127e840)(frontends:[10.100.44.238]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001689e98)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-6qjf6": (*k8s.Endpoints)(0x40013aa680)(10.108.0.121:53/TCP[eu-west-3a],10.108.0.121:53/UDP[eu-west-3a],10.108.0.121:9153/TCP[eu-west-3a],10.108.0.26:53/TCP[eu-west-3a],10.108.0.26:53/UDP[eu-west-3a],10.108.0.26:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40013e3278)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-25bz6": (*k8s.Endpoints)(0x40070f1ad0)(10.108.0.22:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x400190eab0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-n5rs2": (*k8s.Endpoints)(0x400384af70)(10.108.0.47:8080/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001689e88)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002c67110)(172.31.154.244:443/TCP,172.31.225.106:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001689e90)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-2mmjw": (*k8s.Endpoints)(0x4002ff7380)(172.31.187.16:4244/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40018dc150)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000869270)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4009c0e498
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4000698cc0,
  gcExited: (chan struct {}) 0x4000698d20,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001785680)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000cfc978)({
      MetricVec: (*prometheus.MetricVec)(0x4001ad54a0)({
       metricMap: (*prometheus.metricMap)(0x4001ad54d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400182b140)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001785700)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000cfc980)({
      MetricVec: (*prometheus.MetricVec)(0x4001ad5530)({
       metricMap: (*prometheus.metricMap)(0x4001ad5560)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400182b1a0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001785780)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000cfc988)({
      MetricVec: (*prometheus.MetricVec)(0x4001ad55c0)({
       metricMap: (*prometheus.metricMap)(0x4001ad55f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400182b200)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001785800)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000cfc990)({
      MetricVec: (*prometheus.MetricVec)(0x4001ad5650)({
       metricMap: (*prometheus.metricMap)(0x4001ad5680)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400182b260)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001785880)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000cfc998)({
      MetricVec: (*prometheus.MetricVec)(0x4001ad56e0)({
       metricMap: (*prometheus.metricMap)(0x4001ad5710)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400182b2c0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001785900)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000cfc9a0)({
      MetricVec: (*prometheus.MetricVec)(0x4001ad5770)({
       metricMap: (*prometheus.metricMap)(0x4001ad57a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400182b320)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001785980)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000cfc9a8)({
      MetricVec: (*prometheus.MetricVec)(0x4001ad5800)({
       metricMap: (*prometheus.metricMap)(0x4001ad5830)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400182b380)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001785a00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000cfc9b0)({
      MetricVec: (*prometheus.MetricVec)(0x4001ad5890)({
       metricMap: (*prometheus.metricMap)(0x4001ad58c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400182b3e0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001785a80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000cfc9b8)({
      MetricVec: (*prometheus.MetricVec)(0x4001ad5920)({
       metricMap: (*prometheus.metricMap)(0x4001ad5950)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400182b440)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40018dc150)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001362cb0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001cae0d8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 303ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.108.0.0/24, 
Allocated addresses:
  10.108.0.118 (router)
  10.108.0.121 (kube-system/coredns-cc6ccd49c-8cj8l)
  10.108.0.188 (cilium-test-1/client-974f6c69d-7g5vs)
  10.108.0.22 (kube-system/clustermesh-apiserver-57884d66d4-gnlpm)
  10.108.0.239 (health)
  10.108.0.26 (kube-system/coredns-cc6ccd49c-kw8jg)
  10.108.0.47 (cilium-test-1/echo-same-node-86d9cc975c-tjsnq)
  10.108.0.72 (cilium-test-1/client2-57cf4468f-dcl8m)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m35s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: a43671ab00a2b82c
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      177/177 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    13s ago        never        0       no error   
  ct-map-pressure                                                     14s ago        never        0       no error   
  daemon-validate-config                                              53s ago        never        0       no error   
  dns-garbage-collector-job                                           17s ago        never        0       no error   
  endpoint-1057-regeneration-recovery                                 never          never        0       no error   
  endpoint-1109-regeneration-recovery                                 never          never        0       no error   
  endpoint-1890-regeneration-recovery                                 never          never        0       no error   
  endpoint-236-regeneration-recovery                                  never          never        0       no error   
  endpoint-331-regeneration-recovery                                  never          never        0       no error   
  endpoint-421-regeneration-recovery                                  never          never        0       no error   
  endpoint-453-regeneration-recovery                                  never          never        0       no error   
  endpoint-94-regeneration-recovery                                   never          never        0       no error   
  endpoint-gc                                                         2m17s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                14s ago        never        0       no error   
  ipcache-inject-labels                                               14s ago        never        0       no error   
  k8s-heartbeat                                                       17s ago        never        0       no error   
  link-cache                                                          14s ago        never        0       no error   
  local-identity-checkpoint                                           2m59s ago      never        0       no error   
  node-neighbor-link-updater                                          4s ago         never        0       no error   
  remote-etcd-cmesh1                                                  11m36s ago     never        0       no error   
  remote-etcd-cmesh10                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh100                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh101                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh102                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh103                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh104                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh105                                                11m34s ago     never        0       no error   
  remote-etcd-cmesh106                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh107                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh108                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh11                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh110                                                11m36s ago     never        0       no error   
  remote-etcd-cmesh111                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh112                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh113                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh114                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh115                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh116                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh117                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh118                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh119                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh12                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh120                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh121                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh122                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh123                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh124                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh125                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh126                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh127                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh128                                                11m35s ago     never        0       no error   
  remote-etcd-cmesh13                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh14                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh15                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh16                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh17                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh18                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh19                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh2                                                  11m35s ago     never        0       no error   
  remote-etcd-cmesh20                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh21                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh22                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh23                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh24                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh25                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh26                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh27                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh28                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh29                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh3                                                  11m35s ago     never        0       no error   
  remote-etcd-cmesh30                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh31                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh32                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh33                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh34                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh35                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh36                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh37                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh38                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh39                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh4                                                  11m35s ago     never        0       no error   
  remote-etcd-cmesh40                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh41                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh42                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh43                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh44                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh45                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh46                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh47                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh48                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh49                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh5                                                  11m35s ago     never        0       no error   
  remote-etcd-cmesh50                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh51                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh52                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh53                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh54                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh55                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh56                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh57                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh58                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh59                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh6                                                  11m36s ago     never        0       no error   
  remote-etcd-cmesh60                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh61                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh62                                                 11m34s ago     never        0       no error   
  remote-etcd-cmesh63                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh64                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh65                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh66                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh67                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh68                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh69                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh7                                                  11m35s ago     never        0       no error   
  remote-etcd-cmesh70                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh71                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh72                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh73                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh74                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh75                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh76                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh77                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh78                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh79                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh8                                                  11m35s ago     never        0       no error   
  remote-etcd-cmesh80                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh81                                                 11m34s ago     never        0       no error   
  remote-etcd-cmesh82                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh83                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh84                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh85                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh86                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh87                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh88                                                 11m34s ago     never        0       no error   
  remote-etcd-cmesh89                                                 11m36s ago     never        0       no error   
  remote-etcd-cmesh9                                                  11m35s ago     never        0       no error   
  remote-etcd-cmesh90                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh91                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh92                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh93                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh94                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh95                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh96                                                 11m34s ago     never        0       no error   
  remote-etcd-cmesh97                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh98                                                 11m35s ago     never        0       no error   
  remote-etcd-cmesh99                                                 11m34s ago     never        0       no error   
  resolve-identity-1057                                               1m47s ago      never        0       no error   
  resolve-identity-1109                                               2m13s ago      never        0       no error   
  resolve-identity-1890                                               2m13s ago      never        0       no error   
  resolve-identity-236                                                2m13s ago      never        0       no error   
  resolve-identity-331                                                1m28s ago      never        0       no error   
  resolve-identity-421                                                1m26s ago      never        0       no error   
  resolve-identity-453                                                1m26s ago      never        0       no error   
  resolve-identity-94                                                 2m14s ago      never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-7g5vs                 6m28s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-dcl8m                6m26s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-tjsnq        6m26s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-57884d66d4-gnlpm   11m47s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-8cj8l                  22m13s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-kw8jg                  22m13s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      22m14s ago     never        0       no error   
  sync-policymap-1057                                                 11m47s ago     never        0       no error   
  sync-policymap-1109                                                 7m10s ago      never        0       no error   
  sync-policymap-1890                                                 7m10s ago      never        0       no error   
  sync-policymap-236                                                  7m10s ago      never        0       no error   
  sync-policymap-331                                                  6m28s ago      never        0       no error   
  sync-policymap-421                                                  6m26s ago      never        0       no error   
  sync-policymap-453                                                  6m26s ago      never        0       no error   
  sync-policymap-94                                                   7m13s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1057)                                   7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1109)                                   13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (236)                                    12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (331)                                    8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (421)                                    6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (453)                                    6s ago         never        0       no error   
  sync-utime                                                          14s ago        never        0       no error   
  write-cni-file                                                      22m17s ago     never        0       no error   
Proxy Status:            OK, ip 10.108.0.118, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 7143424, max 7208959
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 207.07   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
labels:
clustermesh-enable-endpoint-sync:false
enable-local-node-route:true
ipsec-key-rotation-duration:5m0s
procfs:/host/proc
bpf-lb-external-clusterip:false
enable-pmtu-discovery:false
enable-monitor:true
hubble-redact-http-urlquery:false
proxy-connect-timeout:2
bgp-config-path:/var/lib/cilium/bgp/config.yaml
bpf-lb-sock:false
bpf-map-dynamic-size-ratio:0.0025
hubble-export-file-max-size-mb:10
kvstore:
ipv6-node:auto
vlan-bpf-bypass:
debug:false
tunnel-protocol:vxlan
enable-k8s-api-discovery:false
enable-ipv4-fragment-tracking:true
disable-iptables-feeder-rules:
k8s-client-qps:10
enable-bpf-clock-probe:false
k8s-heartbeat-timeout:30s
enable-host-firewall:false
l2-announcements-retry-period:2s
bgp-announce-pod-cidr:false
hubble-flowlogs-config-path:
k8s-client-burst:20
l2-announcements-lease-duration:15s
auto-direct-node-routes:false
monitor-queue-size:0
k8s-namespace:kube-system
cni-chaining-target:
dnsproxy-concurrency-processing-grace-period:0s
dnsproxy-insecure-skip-transparent-mode-check:false
bpf-lb-sock-hostns-only:false
log-opt:
enable-ipip-termination:false
l2-pod-announcements-interface:
enable-service-topology:false
enable-ingress-controller:false
node-labels:
enable-custom-calls:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
bpf-ct-timeout-regular-tcp-syn:1m0s
max-internal-timer-delay:0s
local-router-ipv4:
dns-policy-unload-on-shutdown:false
bpf-ct-timeout-regular-tcp:2h13m20s
enable-ipv6-ndp:false
bpf-lb-maglev-table-size:16381
service-no-backend-response:reject
allocator-list-timeout:3m0s
policy-accounting:true
enable-ipsec-key-watcher:true
keep-config:false
hubble-redact-kafka-apikey:false
bpf-lb-map-max:65536
hubble-drop-events-interval:2m0s
http-retry-count:3
ipam-default-ip-pool:default
config:
enable-icmp-rules:true
identity-heartbeat-timeout:30m0s
egress-gateway-policy-map-max:16384
enable-well-known-identities:false
egress-multi-home-ip-rule-compat:false
enable-wireguard-userspace-fallback:false
static-cnp-path:
enable-hubble-recorder-api:true
bpf-ct-timeout-service-tcp:2h13m20s
enable-ipsec:false
certificates-directory:/var/run/cilium/certs
http-request-timeout:3600
enable-hubble:true
kvstore-lease-ttl:15m0s
hubble-redact-enabled:false
enable-l2-announcements:false
route-metric:0
bpf-sock-rev-map-max:262144
enable-endpoint-routes:false
enable-endpoint-health-checking:true
crd-wait-timeout:5m0s
conntrack-gc-max-interval:0s
gateway-api-secrets-namespace:
ipv4-service-loopback-address:169.254.42.1
ingress-secrets-namespace:
enable-srv6:false
disable-endpoint-crd:false
bpf-ct-timeout-regular-any:1m0s
lib-dir:/var/lib/cilium
encrypt-node:false
enable-health-check-nodeport:true
enable-route-mtu-for-cni-chaining:false
k8s-sync-timeout:3m0s
ipv6-cluster-alloc-cidr:f00d::/64
socket-path:/var/run/cilium/cilium.sock
monitor-aggregation-interval:5s
exclude-node-label-patterns:
ipv4-service-range:auto
node-port-acceleration:disabled
config-sources:config-map:kube-system/cilium-config
enable-k8s:true
agent-health-port:9879
k8s-client-connection-timeout:30s
hubble-prefer-ipv6:false
bpf-lb-rss-ipv4-src-cidr:
hubble-socket-path:/var/run/cilium/hubble.sock
enable-bbr:false
bpf-node-map-max:16384
enable-ipv4-egress-gateway:false
bpf-ct-global-tcp-max:524288
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-filter-priority:1
envoy-base-id:0
hubble-skip-unknown-cgroup-ids:true
cni-exclusive:true
operator-prometheus-serve-addr::9963
enable-encryption-strict-mode:false
http-normalize-path:true
envoy-log:
hubble-export-denylist:
unmanaged-pod-watcher-interval:15
hubble-redact-http-headers-allow:
bpf-ct-global-any-max:262144
max-connected-clusters:255
tofqdns-max-deferred-connection-deletes:10000
bpf-events-trace-enabled:true
nat-map-stats-interval:30s
enable-xdp-prefilter:false
enable-health-checking:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
dnsproxy-lock-timeout:500ms
ipv6-range:auto
trace-payloadlen:128
enable-ipsec-xfrm-state-caching:true
enable-ipv4-big-tcp:false
enable-nat46x64-gateway:false
wireguard-persistent-keepalive:0s
synchronize-k8s-nodes:true
allow-localhost:auto
ipv4-native-routing-cidr:
node-port-range:
bpf-policy-map-full-reconciliation-interval:15m0s
bpf-lb-dsr-l4-xlate:frontend
cilium-endpoint-gc-interval:5m0s
operator-api-serve-addr:127.0.0.1:9234
ipv4-range:auto
bypass-ip-availability-upon-restore:false
enable-ipv6-big-tcp:false
auto-create-cilium-node-resource:true
proxy-portrange-max:20000
http-retry-timeout:0
remove-cilium-node-taints:true
vtep-cidr:
bpf-ct-timeout-regular-tcp-fin:10s
use-full-tls-context:false
enable-bgp-control-plane:false
proxy-xff-num-trusted-hops-ingress:0
ipam:cluster-pool
enable-ipsec-encrypted-overlay:false
enable-k8s-terminating-endpoint:true
bpf-lb-source-range-map-max:0
prometheus-serve-addr:
enable-high-scale-ipcache:false
enable-cilium-health-api-server-access:
kvstore-opt:
policy-cidr-match-mode:
disable-external-ip-mitigation:false
enable-mke:false
kvstore-connectivity-timeout:2m0s
routing-mode:tunnel
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
clustermesh-enable-mcs-api:false
vtep-mac:
cluster-id:109
cluster-pool-ipv4-cidr:10.108.0.0/16
fixed-identity-mapping:
devices:
dns-max-ips-per-restored-rule:1000
iptables-random-fully:false
arping-refresh-period:30s
identity-change-grace-period:5s
mesh-auth-queue-size:1024
enable-bpf-masquerade:false
cluster-pool-ipv4-mask-size:24
endpoint-gc-interval:5m0s
clustermesh-config:/var/lib/cilium/clustermesh/
join-cluster:false
mtu:0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
policy-trigger-interval:1s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
force-device-detection:false
hubble-monitor-events:
cgroup-root:/run/cilium/cgroupv2
derive-masq-ip-addr-from-device:
endpoint-bpf-prog-watchdog-interval:30s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
bpf-fragments-map-max:8192
ipv6-native-routing-cidr:
ipv6-mcast-device:
exclude-local-address:
bpf-nat-global-max:524288
pprof:false
enable-runtime-device-detection:true
vtep-mask:
enable-svc-source-range-check:true
enable-tcx:true
bpf-lb-service-map-max:0
tofqdns-idle-connection-grace-period:0s
clustermesh-ip-identities-sync-timeout:1m0s
encryption-strict-mode-cidr:
hubble-metrics:
enable-sctp:false
bpf-lb-rev-nat-map-max:0
version:false
enable-policy:default
ipv6-pod-subnets:
mesh-auth-rotated-identities-queue-size:1024
tofqdns-endpoint-max-ip-per-hostname:50
bpf-map-event-buffers:
hubble-export-file-path:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-drop-events:false
hubble-event-buffer-capacity:4095
annotate-k8s-node:false
cluster-health-port:4240
controller-group-metrics:
dnsproxy-lock-count:131
cmdref:
enable-wireguard:false
enable-identity-mark:true
tofqdns-pre-cache:
enable-ipv4:true
state-dir:/var/run/cilium
ipam-multi-pool-pre-allocation:
cflags:
enable-node-port:false
k8s-service-proxy-name:
bpf-ct-timeout-service-any:1m0s
hubble-drop-events-reasons:auth_required,policy_denied
dnsproxy-socket-linger-timeout:10
proxy-portrange-min:10000
kube-proxy-replacement:false
enable-vtep:false
external-envoy-proxy:true
enable-gateway-api:false
k8s-api-server:
hubble-export-file-max-backups:5
direct-routing-device:
local-max-addr-scope:252
enable-session-affinity:false
bpf-lb-dsr-dispatch:opt
endpoint-queue-size:25
dnsproxy-concurrency-limit:0
proxy-prometheus-port:0
tofqdns-dns-reject-response-code:refused
api-rate-limit:
ipv4-node:auto
egress-masquerade-interfaces:ens+
k8s-client-connection-keep-alive:30s
read-cni-conf:
hubble-redact-http-headers-deny:
enable-stale-cilium-endpoint-cleanup:true
label-prefix-file:
hubble-redact-http-userinfo:true
tofqdns-proxy-port:0
mke-cgroup-mount:
identity-restore-grace-period:30s
enable-ipv4-masquerade:true
trace-sock:true
bgp-announce-lb-ip:false
container-ip-local-reserved-ports:auto
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
multicast-enabled:false
log-system-load:false
tofqdns-min-ttl:0
enable-external-ips:false
enable-recorder:false
enable-tracing:false
monitor-aggregation-flags:all
agent-labels:
mesh-auth-mutual-connect-timeout:5s
datapath-mode:veth
enable-xt-socket-fallback:true
bpf-lb-rss-ipv6-src-cidr:
l2-announcements-renew-deadline:5s
bpf-lb-service-backend-map-max:0
encryption-strict-mode-allow-remote-node-identities:false
enable-cilium-api-server-access:
envoy-secrets-namespace:
mesh-auth-gc-interval:5m0s
use-cilium-internal-ip-for-ipsec:false
hubble-export-allowlist:
bpf-lb-affinity-map-max:0
enable-l7-proxy:true
srv6-encap-mode:reduced
enable-bandwidth-manager:false
envoy-keep-cap-netbindservice:false
log-driver:
enable-health-check-loadbalancer-ip:false
proxy-max-connection-duration-seconds:0
tofqdns-proxy-response-max-delay:100ms
fqdn-regex-compile-lru-size:1024
identity-gc-interval:15m0s
egress-gateway-reconciliation-trigger-interval:1s
enable-host-port:false
envoy-config-retry-interval:15s
proxy-max-requests-per-connection:0
max-controller-interval:0
cni-chaining-mode:none
mesh-auth-enabled:true
identity-allocation-mode:crd
k8s-kubeconfig-path:
iptables-lock-timeout:5s
proxy-admin-port:0
enable-masquerade-to-route-source:false
node-port-mode:snat
ipam-cilium-node-update-rate:15s
ipsec-key-file:
agent-liveness-update-interval:1s
disable-envoy-version-check:false
bpf-root:/sys/fs/bpf
kube-proxy-replacement-healthz-bind-address:
preallocate-bpf-maps:false
kvstore-max-consecutive-quorum-errors:2
enable-ipv6:false
pprof-port:6060
cni-external-routing:false
enable-local-redirect-policy:false
hubble-event-queue-size:0
k8s-require-ipv4-pod-cidr:false
restore:true
cluster-name:cmesh109
proxy-xff-num-trusted-hops-egress:0
tofqdns-enable-dns-compression:true
bpf-lb-sock-terminate-pod-connections:false
prepend-iptables-chains:true
enable-unreachable-routes:false
cni-log-file:/var/run/cilium/cilium-cni.log
bpf-lb-maglev-map-max:0
ipv4-pod-subnets:
enable-auto-protect-node-port-range:true
mesh-auth-spire-admin-socket:
enable-l2-pod-announcements:false
envoy-config-timeout:2m0s
node-port-algorithm:random
policy-audit-mode:false
bpf-lb-acceleration:disabled
bpf-policy-map-max:16384
enable-envoy-config:false
enable-node-selector-labels:false
set-cilium-node-taints:true
local-router-ipv6:
kvstore-periodic-sync:5m0s
node-port-bind-protection:true
enable-k8s-networkpolicy:true
enable-metrics:true
hubble-metrics-server:
mesh-auth-mutual-listener-port:0
k8s-service-cache-size:128
enable-l2-neigh-discovery:true
enable-host-legacy-routing:false
encrypt-interface:
dnsproxy-enable-transparent-mode:true
bpf-events-drop-enabled:true
proxy-gid:1337
enable-active-connection-tracking:false
bpf-auth-map-max:524288
hubble-listen-address::4244
http-max-grpc-timeout:0
enable-k8s-endpoint-slice:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-neigh-global-max:524288
set-cilium-is-up-condition:true
k8s-require-ipv6-pod-cidr:false
ipv6-service-range:auto
gops-port:9890
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
policy-queue-size:100
direct-routing-skip-unreachable:false
debug-verbose:
nat-map-stats-entries:32
bpf-lb-mode:snat
install-no-conntrack-iptables-rules:false
enable-ipv6-masquerade:true
monitor-aggregation:medium
vtep-endpoint:
pprof-address:localhost
enable-ip-masq-agent:false
config-dir:/tmp/cilium/config-map
allow-icmp-frag-needed:true
hubble-export-fieldmask:
custom-cni-conf:false
mesh-auth-signal-backoff-duration:1s
conntrack-gc-interval:0s
http-idle-timeout:0
hubble-export-file-compress:false
hubble-disable-tls:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-cilium-endpoint-slice:false
tunnel-port:0
proxy-idle-timeout-seconds:60
nodeport-addresses:
install-iptables-rules:true
enable-bpf-tproxy:false
nodes-gc-interval:5m0s
metrics:
bpf-lb-algorithm:random
hubble-recorder-sink-queue-size:1024
clustermesh-sync-timeout:1m0s
bpf-events-policy-verdict-enabled:true
```


#### Policy get

```
:
 []
Revision: 129

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33635194                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33635194                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33635194                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400dc00000 rw-p 00000000 00:00 0 
400dc00000-4010000000 ---p 00000000 00:00 0 
ffff76716000-ffff7692d000 rw-p 00000000 00:00 0 
ffff76931000-ffff76a22000 rw-p 00000000 00:00 0 
ffff76a2a000-ffff76b0b000 rw-p 00000000 00:00 0 
ffff76b0b000-ffff76b4c000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff76b4c000-ffff76b8d000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff76b8d000-ffff76bcd000 rw-p 00000000 00:00 0 
ffff76bcd000-ffff76bcf000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff76bcf000-ffff76bd1000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff76bd1000-ffff77198000 rw-p 00000000 00:00 0 
ffff77198000-ffff77298000 rw-p 00000000 00:00 0 
ffff77298000-ffff772a9000 rw-p 00000000 00:00 0 
ffff772a9000-ffff792a9000 rw-p 00000000 00:00 0 
ffff792a9000-ffff79329000 ---p 00000000 00:00 0 
ffff79329000-ffff7932a000 rw-p 00000000 00:00 0 
ffff7932a000-ffff99329000 ---p 00000000 00:00 0 
ffff99329000-ffff9932a000 rw-p 00000000 00:00 0 
ffff9932a000-ffffb92b9000 ---p 00000000 00:00 0 
ffffb92b9000-ffffb92ba000 rw-p 00000000 00:00 0 
ffffb92ba000-ffffbd2ab000 ---p 00000000 00:00 0 
ffffbd2ab000-ffffbd2ac000 rw-p 00000000 00:00 0 
ffffbd2ac000-ffffbdaa9000 ---p 00000000 00:00 0 
ffffbdaa9000-ffffbdaaa000 rw-p 00000000 00:00 0 
ffffbdaaa000-ffffbdba9000 ---p 00000000 00:00 0 
ffffbdba9000-ffffbdc09000 rw-p 00000000 00:00 0 
ffffbdc09000-ffffbdc0b000 r--p 00000000 00:00 0                          [vvar]
ffffbdc0b000-ffffbdc0c000 r-xp 00000000 00:00 0                          [vdso]
ffffdbcf4000-ffffdbd15000 rw-p 00000000 00:00 0                          [stack]

```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                       
94         Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                      ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                        
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                  
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                   
                                                           reserved:host                                                                                                
236        Disabled           Disabled          7167986    k8s:eks.amazonaws.com/component=coredns                                               10.108.0.121   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                   
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh109                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                  
                                                           k8s:k8s-app=kube-dns                                                                                         
331        Disabled           Disabled          7146304    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.108.0.188   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh109                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                               
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                                
                                                           k8s:kind=client                                                                                              
                                                           k8s:name=client                                                                                              
421        Disabled           Disabled          7204632    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.108.0.72    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh109                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                              
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                                
                                                           k8s:kind=client                                                                                              
                                                           k8s:name=client2                                                                                             
                                                           k8s:other=client                                                                                             
453        Disabled           Disabled          7192456    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.108.0.47    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh109                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                       
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                                
                                                           k8s:kind=echo                                                                                                
                                                           k8s:name=echo-same-node                                                                                      
                                                           k8s:other=echo                                                                                               
1057       Disabled           Disabled          7162827    k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.108.0.22    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                         
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                   
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh109                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                                
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                  
                                                           k8s:k8s-app=clustermesh-apiserver                                                                            
1109       Disabled           Disabled          7167986    k8s:eks.amazonaws.com/component=coredns                                               10.108.0.26    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                   
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh109                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                  
                                                           k8s:k8s-app=kube-dns                                                                                         
1890       Disabled           Disabled          4          reserved:health                                                                       10.108.0.239   ready   
```

#### BPF Policy Get 94

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 94

```
Invalid argument: unknown type 94
```


#### Endpoint Get 94

```
[
  {
    "id": 94,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-94-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6fb50da5-0303-4fc8-addb-41c06ebdedae"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-94",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:32.832Z",
            "success-count": 5
          },
          "uuid": "4ff8ef50-7066-4f59-abf7-63da4b5f592c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-94",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:47:33.845Z",
            "success-count": 2
          },
          "uuid": "6d08e485-f576-4659-b415-cbe4eb136d01"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "62:19:47:14:54:68",
        "interface-name": "cilium_host",
        "mac": "62:19:47:14:54:68"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 94

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 94

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:14Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:32:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:32:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:32:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:32:35Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:32:34Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:32:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:32:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:32:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:32:32Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:32:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:32:32Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:32:32Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 236

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3124     32        0        
Allow    Ingress     1          ANY          NONE         disabled    126823   1453      0        
Allow    Egress      0          ANY          NONE         disabled    19173    212       0        

```


#### BPF CT List 236

```
Invalid argument: unknown type 236
```


#### Endpoint Get 236

```
[
  {
    "id": 236,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-236-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ddd4c838-faaa-46e8-ad80-121a3af6cc05"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-236",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:34.270Z",
            "success-count": 5
          },
          "uuid": "08076eb6-24be-4714-bb15-0664465f76f8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-8cj8l",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:32:34.267Z",
            "success-count": 1
          },
          "uuid": "4ed5a9d6-8a79-466f-9c72-ba78aacf82b0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-236",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:47:36.964Z",
            "success-count": 2
          },
          "uuid": "30216642-3ae7-4bd3-87da-97fef2fe16c9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (236)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:44.403Z",
            "success-count": 135
          },
          "uuid": "f4798718-dea7-4ba7-a572-95bba899198a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "a76a68f553e8cef6e56eb4fce86689e92f0daae3dbf874f3827ff779adb277fa:eth0",
        "container-id": "a76a68f553e8cef6e56eb4fce86689e92f0daae3dbf874f3827ff779adb277fa",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-8cj8l",
        "pod-name": "kube-system/coredns-cc6ccd49c-8cj8l"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7167986,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.121",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "be:9d:e7:b8:1c:c7",
        "interface-index": 14,
        "interface-name": "lxcf30b3f528d08",
        "mac": "6e:a8:08:0c:6c:db"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7167986,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7167986,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 236

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 236

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:14Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:32:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:32:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:32:36Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:32:35Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:32:34Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:32:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:32:34Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:32:34Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7167986

```
ID        LABELS
7167986   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh109
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 331

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 331

```
Invalid argument: unknown type 331
```


#### Endpoint Get 331

```
[
  {
    "id": 331,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-331-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "10242816-6214-4c75-830a-733aecc522f6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-331",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:19.149Z",
            "success-count": 2
          },
          "uuid": "da312291-8d74-4f23-a6c2-b752913dc779"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-7g5vs",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:19.148Z",
            "success-count": 1
          },
          "uuid": "2501a25f-d3b5-468e-a6ee-ac9825bfd16f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-331",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:19.197Z",
            "success-count": 1
          },
          "uuid": "e4b75b10-c9e1-4f59-a834-87350db7443c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (331)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:39.197Z",
            "success-count": 40
          },
          "uuid": "250d8ebd-49f9-4d57-ab67-5ed5183045c4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "2ee5393b9fcbb5e680ec15b24d4a3334a8572a5e4864c9a7fc566ef64dfc7d6c:eth0",
        "container-id": "2ee5393b9fcbb5e680ec15b24d4a3334a8572a5e4864c9a7fc566ef64dfc7d6c",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-7g5vs",
        "pod-name": "cilium-test-1/client-974f6c69d-7g5vs"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7146304,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:31Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.188",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "72:6b:9e:ed:77:33",
        "interface-index": 20,
        "interface-name": "lxc28e5034e325b",
        "mac": "8e:1d:16:9c:be:fa"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7146304,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7146304,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 331

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 331

```
Timestamp              Status   State                   Message
2024-10-24T12:51:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 7146304

```
ID        LABELS
7146304   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh109
          k8s:io.cilium.k8s.policy.serviceaccount=client
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client

```


#### BPF Policy Get 421

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 421

```
Invalid argument: unknown type 421
```


#### Endpoint Get 421

```
[
  {
    "id": 421,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-421-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7c7ce9b4-536a-4f68-aa90-7e2391d88c5c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-421",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:20.482Z",
            "success-count": 2
          },
          "uuid": "619adad0-97c4-4202-9439-a0a705c8a187"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-dcl8m",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.480Z",
            "success-count": 1
          },
          "uuid": "c0be240b-2ffc-407e-9e11-9e7353bcda34"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-421",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.529Z",
            "success-count": 1
          },
          "uuid": "a2c80a35-762e-45b8-a722-82d48e5fdfe3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (421)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.518Z",
            "success-count": 40
          },
          "uuid": "790d104b-b039-4395-81f2-a73f2e3973f1"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fd10af92edf212bdb012a909ce2c0c9a570536b1b877f6e634e360c553497612:eth0",
        "container-id": "fd10af92edf212bdb012a909ce2c0c9a570536b1b877f6e634e360c553497612",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-dcl8m",
        "pod-name": "cilium-test-1/client2-57cf4468f-dcl8m"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7204632,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:31Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.72",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "96:8d:90:b6:08:14",
        "interface-index": 24,
        "interface-name": "lxc04fff7bb4525",
        "mac": "0e:16:c9:ac:fb:67"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7204632,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7204632,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 421

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 421

```
Timestamp              Status   State                   Message
2024-10-24T12:51:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 7204632

```
ID        LABELS
7204632   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh109
          k8s:io.cilium.k8s.policy.serviceaccount=client2
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client2
          k8s:other=client

```


#### BPF Policy Get 453

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377501   4403      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 453

```
Invalid argument: unknown type 453
```


#### Endpoint Get 453

```
[
  {
    "id": 453,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-453-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a0eefb09-5c12-45ae-a4a4-3d46d7a5365c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-453",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:20.368Z",
            "success-count": 2
          },
          "uuid": "d2a48103-b3f4-4181-b08e-9b46aa21668c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-tjsnq",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.367Z",
            "success-count": 1
          },
          "uuid": "65630c15-fc39-4555-8c63-4b79554f1789"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-453",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.472Z",
            "success-count": 1
          },
          "uuid": "fbd4fee0-d1c4-44d2-875c-697a218f96e6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (453)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.408Z",
            "success-count": 40
          },
          "uuid": "07c0ac17-5fcb-4506-9fc1-68b1baf29931"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "6f9d1206bdfe743bd6ee0e9677ead98885b65523e6aa5f90d997ef4017f1a627:eth0",
        "container-id": "6f9d1206bdfe743bd6ee0e9677ead98885b65523e6aa5f90d997ef4017f1a627",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-tjsnq",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-tjsnq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7192456,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:22Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.47",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3e:cc:e9:0f:02:d6",
        "interface-index": 22,
        "interface-name": "lxcdbda85652d4e",
        "mac": "d2:e6:01:42:31:53"
      },
      "policy": {
        "proxy-policy-revision": 126,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7192456,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 126,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7192456,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 126
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 453

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 453

```
Timestamp              Status   State                   Message
2024-10-24T12:51:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 7192456

```
ID        LABELS
7192456   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh109
          k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=echo
          k8s:name=echo-same-node
          k8s:other=echo

```


#### BPF Policy Get 1057

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6070993   59809     0        
Allow    Ingress     1          ANY          NONE         disabled    5476112   55973     0        
Allow    Egress      0          ANY          NONE         disabled    5677107   57253     0        

```


#### BPF CT List 1057

```
Invalid argument: unknown type 1057
```


#### Endpoint Get 1057

```
[
  {
    "id": 1057,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1057-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "abb4a081-5a81-4576-b93d-c0e8c7999f15"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1057",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:00.191Z",
            "success-count": 3
          },
          "uuid": "4fb1ea8e-46fc-4f2e-bf5f-350585f2471f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-57884d66d4-gnlpm",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:43:00.189Z",
            "success-count": 1
          },
          "uuid": "5450186f-31ec-4521-8a9d-2ebd30b40a92"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1057",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:43:00.234Z",
            "success-count": 1
          },
          "uuid": "2a0f6bdb-f8ca-41bf-b0cf-8030f3eb53ce"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1057)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:40.244Z",
            "success-count": 72
          },
          "uuid": "4352ebec-a512-4105-a464-020733cabd84"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "4790006b18af0e815499c6d849e6970d7452f85be4076c97480b82189e5ea091:eth0",
        "container-id": "4790006b18af0e815499c6d849e6970d7452f85be4076c97480b82189e5ea091",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-57884d66d4-gnlpm",
        "pod-name": "kube-system/clustermesh-apiserver-57884d66d4-gnlpm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7162827,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57884d66d4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.22",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3e:16:41:61:fe:6c",
        "interface-index": 18,
        "interface-name": "lxc776042cb78bb",
        "mac": "ba:4d:ff:9b:3b:f3"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7162827,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7162827,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1057

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1057

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:14Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:43:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:43:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:43:00Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:43:00Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7162827

```
ID        LABELS
7162827   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh109
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1109

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2772     28        0        
Allow    Ingress     1          ANY          NONE         disabled    126298   1449      0        
Allow    Egress      0          ANY          NONE         disabled    17875    196       0        

```


#### BPF CT List 1109

```
Invalid argument: unknown type 1109
```


#### Endpoint Get 1109

```
[
  {
    "id": 1109,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1109-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6415ff3a-30ae-4a9a-8c9e-f4a5c7df781c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1109",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:34.178Z",
            "success-count": 5
          },
          "uuid": "a6a5fd5f-1d50-42e1-a6b0-9a7cf6dd9ff8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-kw8jg",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:32:34.176Z",
            "success-count": 1
          },
          "uuid": "7d2f3644-f303-4ed5-a29a-df85fda2f65a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1109",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:47:36.926Z",
            "success-count": 2
          },
          "uuid": "046e66dd-9f4f-4872-9250-bf89cc41916d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1109)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:44.286Z",
            "success-count": 135
          },
          "uuid": "195c411f-cd12-4a31-838c-4f27e10dfc17"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "49549f6e0b121bf42283561be8d18fef6d5dce4bed854a5178b1522e6473ef62:eth0",
        "container-id": "49549f6e0b121bf42283561be8d18fef6d5dce4bed854a5178b1522e6473ef62",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-kw8jg",
        "pod-name": "kube-system/coredns-cc6ccd49c-kw8jg"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7167986,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.26",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "0a:94:95:e2:47:1f",
        "interface-index": 12,
        "interface-name": "lxc61472e6a5403",
        "mac": "d6:38:e1:fe:09:2d"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7167986,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7167986,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1109

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1109

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:14Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:32:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T12:32:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:32:37Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T12:32:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:32:35Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:32:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T12:32:34Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:32:34Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:32:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:32:34Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:32:34Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7167986

```
ID        LABELS
7167986   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh109
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1890

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6238243   76957     0        
Allow    Ingress     1          ANY          NONE         disabled    61748     744       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 1890

```
Invalid argument: unknown type 1890
```


#### Endpoint Get 1890

```
[
  {
    "id": 1890,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1890-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "534c9019-e5ee-4e10-a96e-10f439de6c0a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1890",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:33.893Z",
            "success-count": 5
          },
          "uuid": "5b037e42-c575-4268-86c0-cdf988593daf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1890",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:47:36.914Z",
            "success-count": 2
          },
          "uuid": "29305be1-72e1-47c4-ae24-aac9b472d601"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.239",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "5a:96:50:c9:a0:b6",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "5e:7b:c5:a9:bd:8e"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1890

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1890

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:14Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:38:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:38:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:38:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:38:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:32:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:32:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:32:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:32:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:32:35Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:32:34Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:32:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:32:33Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:32:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:32:33Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:32:32Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.225.106:443 (active)   
                                         2 => 172.31.154.244:443 (active)   
2    10.100.120.16:443    ClusterIP      1 => 172.31.187.16:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.108.0.121:53 (active)      
                                         2 => 10.108.0.26:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.108.0.121:9153 (active)    
                                         2 => 10.108.0.26:9153 (active)     
5    10.100.44.238:2379   ClusterIP      1 => 10.108.0.22:2379 (active)     
6    10.100.250.99:8080   ClusterIP      1 => 10.108.0.47:8080 (active)     
```

#### Cilium encryption


