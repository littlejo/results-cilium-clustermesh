Endpoint ID: 94
Path: /sys/fs/bpf/tc/globals/cilium_policy_00094

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 236
Path: /sys/fs/bpf/tc/globals/cilium_policy_00236

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3124     32        0        
Allow    Ingress     1          ANY          NONE         disabled    126823   1453      0        
Allow    Egress      0          ANY          NONE         disabled    19173    212       0        


Endpoint ID: 331
Path: /sys/fs/bpf/tc/globals/cilium_policy_00331

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 421
Path: /sys/fs/bpf/tc/globals/cilium_policy_00421

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 453
Path: /sys/fs/bpf/tc/globals/cilium_policy_00453

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378324   4412      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1057
Path: /sys/fs/bpf/tc/globals/cilium_policy_01057

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6070809   59807     0        
Allow    Ingress     1          ANY          NONE         disabled    5476112   55973     0        
Allow    Egress      0          ANY          NONE         disabled    5677107   57253     0        


Endpoint ID: 1109
Path: /sys/fs/bpf/tc/globals/cilium_policy_01109

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2772     28        0        
Allow    Ingress     1          ANY          NONE         disabled    126298   1449      0        
Allow    Egress      0          ANY          NONE         disabled    17875    196       0        


Endpoint ID: 1890
Path: /sys/fs/bpf/tc/globals/cilium_policy_01890

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6236379   76935     0        
Allow    Ingress     1          ANY          NONE         disabled    61748     744       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


