1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:88:de:f2:3d:4b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.187.16/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3543sec preferred_lft 3543sec
    inet6 fe80::488:deff:fef2:3d4b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ca:73:31:2e:ed brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.142.108/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ca:73ff:fe31:2eed/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:e5:68:58:fb:42 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::20e5:68ff:fe58:fb42/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:19:47:14:54:68 brd ff:ff:ff:ff:ff:ff
    inet 10.108.0.118/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6019:47ff:fe14:5468/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 32:ad:70:9a:65:28 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::30ad:70ff:fe9a:6528/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:96:50:c9:a0:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5896:50ff:fec9:a0b6/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc61472e6a5403@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:94:95:e2:47:1f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::894:95ff:fee2:471f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf30b3f528d08@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:9d:e7:b8:1c:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::bc9d:e7ff:feb8:1cc7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc776042cb78bb@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:16:41:61:fe:6c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3c16:41ff:fe61:fe6c/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc28e5034e325b@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:6b:9e:ed:77:33 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::706b:9eff:feed:7733/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcdbda85652d4e@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:cc:e9:0f:02:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::3ccc:e9ff:fe0f:2d6/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc04fff7bb4525@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:8d:90:b6:08:14 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::948d:90ff:feb6:814/64 scope link 
       valid_lft forever preferred_lft forever
