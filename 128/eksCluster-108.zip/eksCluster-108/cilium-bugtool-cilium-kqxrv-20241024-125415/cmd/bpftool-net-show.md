xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 560
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 524
lxc61472e6a5403(12) clsact/ingress cil_from_container-lxc61472e6a5403 id 534
lxcf30b3f528d08(14) clsact/ingress cil_from_container-lxcf30b3f528d08 id 508
lxc776042cb78bb(18) clsact/ingress cil_from_container-lxc776042cb78bb id 633
lxc28e5034e325b(20) clsact/ingress cil_from_container-lxc28e5034e325b id 3351
lxcdbda85652d4e(22) clsact/ingress cil_from_container-lxcdbda85652d4e id 3290
lxc04fff7bb4525(24) clsact/ingress cil_from_container-lxc04fff7bb4525 id 3361

flow_dissector:

netfilter:

