CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod72a31558_9fe6_49e8_92fd_608f47396bd8.slice/cri-containerd-def836af8ed433998526bbbd7ee5348dd26f755052a4bf51fd266354b4a6a93f.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod72a31558_9fe6_49e8_92fd_608f47396bd8.slice/cri-containerd-1f58ed5bfd680f442622e97b7d9c2f98a417b43a8a728f97692bd59a14531f16.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca193583_9391_4bfe_8500_d57e6ccd735a.slice/cri-containerd-ab39e1484fcacc1d677f3c2480f0db008090287b3772270c39b8de6b95b06ca7.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca193583_9391_4bfe_8500_d57e6ccd735a.slice/cri-containerd-afd8ac630432faedfcc8af18a8baa3031dd773cdfaa1e604d687c9b579ab3173.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4e0bdbb7_cfa8_43ff_9ded_c2b7ad2a1c58.slice/cri-containerd-a564037ae520a32270c29e8aa8a6f9d4936f0c98723c847a253a039c20fa634e.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4e0bdbb7_cfa8_43ff_9ded_c2b7ad2a1c58.slice/cri-containerd-a76a68f553e8cef6e56eb4fce86689e92f0daae3dbf874f3827ff779adb277fa.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63286a4d_68f7_4ae3_bb9c_d6600152f2c4.slice/cri-containerd-49549f6e0b121bf42283561be8d18fef6d5dce4bed854a5178b1522e6473ef62.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63286a4d_68f7_4ae3_bb9c_d6600152f2c4.slice/cri-containerd-78850d1781517d218e7473f4343e23cea98a8bc84226793849f6f14a5de5c4ea.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8883b883_0b27_41ea_8909_94f9a2bba731.slice/cri-containerd-ca15999220a9c54affaae416d16fffba446c4c5434aa81bfc338bc7c9a469028.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8883b883_0b27_41ea_8909_94f9a2bba731.slice/cri-containerd-2ee5393b9fcbb5e680ec15b24d4a3334a8572a5e4864c9a7fc566ef64dfc7d6c.scope
    676      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e7fefbd_bcbc_45d5_8a9f_10cee451b436.slice/cri-containerd-4790006b18af0e815499c6d849e6970d7452f85be4076c97480b82189e5ea091.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e7fefbd_bcbc_45d5_8a9f_10cee451b436.slice/cri-containerd-6d54e4bc25b938bed7ea447dcca1c87779202fdd38a7a74d53ca4f2a2020418c.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e7fefbd_bcbc_45d5_8a9f_10cee451b436.slice/cri-containerd-23eb8c950635d7ec6e76bf56cf9f5c90ec7d93e431d33a8d7b2fca72b0757cc4.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e7fefbd_bcbc_45d5_8a9f_10cee451b436.slice/cri-containerd-8410dc635198ea01223f579ee6ec72cbbc721402df565a985186b6ff18b4da7e.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb859b205_c5ba_4a2e_9304_26f31dc43660.slice/cri-containerd-95d79a0c6229bee5b8a2d3fb976dc32f80252332746fe35418f46f66ccd881ac.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb859b205_c5ba_4a2e_9304_26f31dc43660.slice/cri-containerd-4d9d47b2ff0692accd2df223c9986fd0a014a0fd4a4fbd38c57f5e91670fedaf.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb859b205_c5ba_4a2e_9304_26f31dc43660.slice/cri-containerd-6f9d1206bdfe743bd6ee0e9677ead98885b65523e6aa5f90d997ef4017f1a627.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3c4e6962_5f87_4731_9671_561d2984c9d7.slice/cri-containerd-843ebc8832d61d92c4bd5b7cdeca87b9fac2aa15f764ebaad6c40a0e879ab4e5.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3c4e6962_5f87_4731_9671_561d2984c9d7.slice/cri-containerd-442fb140e33228c1de71518f31ac60386aa5f65fdbf74a0b0865d3989775d53f.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03a06127_3758_4a4d_8edd_02189c44984a.slice/cri-containerd-fd10af92edf212bdb012a909ce2c0c9a570536b1b877f6e634e360c553497612.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03a06127_3758_4a4d_8edd_02189c44984a.slice/cri-containerd-a27adce65d98f21661c3545bcf7aeae94394412d60645a31a79aaeaa35bca33a.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb380f8e_db01_47d8_bbd3_3848705bbec8.slice/cri-containerd-a9fef3126726838495ffc4ce0d27b1259924f6f7d491fa324d2178f1ec1f0ef4.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb380f8e_db01_47d8_bbd3_3848705bbec8.slice/cri-containerd-bb824716eab597c70f66141b9ede798689be5d23dc1b2fc7aeeab2184dc0e6a5.scope
    106      cgroup_device   multi                                          
