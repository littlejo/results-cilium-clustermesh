key: 02 00 00 00  value: ac 1f 9a f4 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 6c 00 1a 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 6c 00 79 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f bb 10 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f e1 6a 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 6c 00 79 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 6c 00 16 09 4b 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 6c 00 2f 1f 90 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 6c 00 1a 00 35 00 00  00 00 00 00
Found 9 elements
