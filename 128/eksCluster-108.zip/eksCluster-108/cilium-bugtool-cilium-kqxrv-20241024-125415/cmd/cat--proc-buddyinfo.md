Node 0, zone      DMA     12      0     14     31     18     12      7      2      3      3     38 
Node 0, zone   Normal    192     42      8     12     26     10      2      2      2      1      8 
