Total: 570
TCP:   4111 (estab 299, closed 3793, orphaned 0, timewait 3334)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  318       308       10       
INET	  328       314       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:41371      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:34539 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.187.16%ens5:68         0.0.0.0:*    uid:192 ino:150039 sk:2 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35094 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15545 sk:4 cgroup:unreachable:e8e <->                                    
UNCONN 0      0      [fe80::488:deff:fef2:3d4b]%ens5:546           [::]:*    uid:192 ino:15291 sk:5 cgroup:unreachable:bd0 v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35093 sk:6 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15546 sk:7 cgroup:unreachable:e8e v6only:1 <->                           
