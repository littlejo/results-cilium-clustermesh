 12:54:16 up 31 min,  0 users,  load average: 0.37, 0.62, 0.37
