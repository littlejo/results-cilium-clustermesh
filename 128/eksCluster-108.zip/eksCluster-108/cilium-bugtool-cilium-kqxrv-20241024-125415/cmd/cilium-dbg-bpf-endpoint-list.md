IP ADDRESS         LOCAL ENDPOINT INFO
172.31.187.16:0    (localhost)                                                                                        
10.108.0.118:0     (localhost)                                                                                        
10.108.0.72:0      id=421   sec_id=7204632 flags=0x0000 ifindex=24  mac=0E:16:C9:AC:FB:67 nodemac=96:8D:90:B6:08:14   
10.108.0.26:0      id=1109  sec_id=7167986 flags=0x0000 ifindex=12  mac=D6:38:E1:FE:09:2D nodemac=0A:94:95:E2:47:1F   
172.31.142.108:0   (localhost)                                                                                        
10.108.0.121:0     id=236   sec_id=7167986 flags=0x0000 ifindex=14  mac=6E:A8:08:0C:6C:DB nodemac=BE:9D:E7:B8:1C:C7   
10.108.0.22:0      id=1057  sec_id=7162827 flags=0x0000 ifindex=18  mac=BA:4D:FF:9B:3B:F3 nodemac=3E:16:41:61:FE:6C   
10.108.0.188:0     id=331   sec_id=7146304 flags=0x0000 ifindex=20  mac=8E:1D:16:9C:BE:FA nodemac=72:6B:9E:ED:77:33   
10.108.0.239:0     id=1890  sec_id=4     flags=0x0000 ifindex=10  mac=5E:7B:C5:A9:BD:8E nodemac=5A:96:50:C9:A0:B6     
10.108.0.47:0      id=453   sec_id=7192456 flags=0x0000 ifindex=22  mac=D2:E6:01:42:31:53 nodemac=3E:CC:E9:0F:02:D6   
