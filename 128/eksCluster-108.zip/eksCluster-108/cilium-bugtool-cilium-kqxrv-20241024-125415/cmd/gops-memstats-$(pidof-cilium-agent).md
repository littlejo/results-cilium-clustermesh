alloc: 76.76MB (80488304 bytes)
total-alloc: 3.13GB (3364227616 bytes)
sys: 223.39MB (234243412 bytes)
lookups: 0
mallocs: 75612706
frees: 75109033
heap-alloc: 76.76MB (80488304 bytes)
heap-sys: 177.48MB (186097664 bytes)
heap-idle: 47.81MB (50135040 bytes)
heap-in-use: 129.66MB (135962624 bytes)
heap-released: 3.67MB (3850240 bytes)
heap-objects: 503673
stack-in-use: 34.50MB (36175872 bytes)
stack-sys: 34.50MB (36175872 bytes)
stack-mspan-inuse: 2.10MB (2203200 bytes)
stack-mspan-sys: 2.83MB (2970240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1001.74KB (1025785 bytes)
gc-sys: 5.49MB (5760048 bytes)
next-gc: when heap-alloc >= 149.52MB (156783032 bytes)
last-gc: 2024-10-24 12:54:43.631441924 +0000 UTC
gc-pause-total: 18.599713ms
gc-pause: 70648
gc-pause-end: 1729774483631441924
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006991523059515385
enable-gc: true
debug-gc: false
