[
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e7fefbd_bcbc_45d5_8a9f_10cee451b436.slice/cri-containerd-23eb8c950635d7ec6e76bf56cf9f5c90ec7d93e431d33a8d7b2fca72b0757cc4.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e7fefbd_bcbc_45d5_8a9f_10cee451b436.slice/cri-containerd-8410dc635198ea01223f579ee6ec72cbbc721402df565a985186b6ff18b4da7e.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e7fefbd_bcbc_45d5_8a9f_10cee451b436.slice/cri-containerd-6d54e4bc25b938bed7ea447dcca1c87779202fdd38a7a74d53ca4f2a2020418c.scope"
      }
    ],
    "ips": [
      "10.108.0.22"
    ],
    "name": "clustermesh-apiserver-57884d66d4-gnlpm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb859b205_c5ba_4a2e_9304_26f31dc43660.slice/cri-containerd-95d79a0c6229bee5b8a2d3fb976dc32f80252332746fe35418f46f66ccd881ac.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb859b205_c5ba_4a2e_9304_26f31dc43660.slice/cri-containerd-4d9d47b2ff0692accd2df223c9986fd0a014a0fd4a4fbd38c57f5e91670fedaf.scope"
      }
    ],
    "ips": [
      "10.108.0.47"
    ],
    "name": "echo-same-node-86d9cc975c-tjsnq",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63286a4d_68f7_4ae3_bb9c_d6600152f2c4.slice/cri-containerd-78850d1781517d218e7473f4343e23cea98a8bc84226793849f6f14a5de5c4ea.scope"
      }
    ],
    "ips": [
      "10.108.0.26"
    ],
    "name": "coredns-cc6ccd49c-kw8jg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8883b883_0b27_41ea_8909_94f9a2bba731.slice/cri-containerd-ca15999220a9c54affaae416d16fffba446c4c5434aa81bfc338bc7c9a469028.scope"
      }
    ],
    "ips": [
      "10.108.0.188"
    ],
    "name": "client-974f6c69d-7g5vs",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03a06127_3758_4a4d_8edd_02189c44984a.slice/cri-containerd-a27adce65d98f21661c3545bcf7aeae94394412d60645a31a79aaeaa35bca33a.scope"
      }
    ],
    "ips": [
      "10.108.0.72"
    ],
    "name": "client2-57cf4468f-dcl8m",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4e0bdbb7_cfa8_43ff_9ded_c2b7ad2a1c58.slice/cri-containerd-a564037ae520a32270c29e8aa8a6f9d4936f0c98723c847a253a039c20fa634e.scope"
      }
    ],
    "ips": [
      "10.108.0.121"
    ],
    "name": "coredns-cc6ccd49c-8cj8l",
    "namespace": "kube-system"
  }
]

