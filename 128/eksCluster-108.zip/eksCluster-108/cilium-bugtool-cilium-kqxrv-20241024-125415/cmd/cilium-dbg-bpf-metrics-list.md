REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     133182    10806064    677    bpf_overlay.c
Interface                   INGRESS     672814    246683956   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      133521    10820649    53     encap.h
Success                     EGRESS      153161    20678806    1308   bpf_lxc.c
Success                     EGRESS      56909     4614457     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     177591    20238556    86     l3.h
Success                     INGRESS     255091    26628932    235    trace.h
Unsupported L3 protocol     EGRESS      70        5264        1492   bpf_lxc.c
