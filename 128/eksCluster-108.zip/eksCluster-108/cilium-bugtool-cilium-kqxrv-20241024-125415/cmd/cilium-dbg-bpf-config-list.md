KEY             VALUE
AgentLiveness   1898221297424
UTimeOffset     3378462087890625
