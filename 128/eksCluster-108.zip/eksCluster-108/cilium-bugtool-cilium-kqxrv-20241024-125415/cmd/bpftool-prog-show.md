32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:12+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:12+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:13+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:13+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:13+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:17+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:32:34+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
482: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:32:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
483: sched_cls  name tail_handle_ipv4  tag 6c1286b7d7a71512  gpl
	loaded_at 2024-10-24T12:32:34+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:32:34+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
507: sched_cls  name tail_ipv4_ct_ingress  tag 82c249fd034f1c2b  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 153
508: sched_cls  name cil_from_container  tag 273e257861213e8e  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 154
509: sched_cls  name tail_handle_arp  tag 9f5fff5a438108f6  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 155
510: sched_cls  name handle_policy  tag bef9199569f37261  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 156
511: sched_cls  name tail_ipv4_ct_egress  tag 1ed3cd8af4451f0c  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 157
512: sched_cls  name tail_handle_ipv4  tag bacbf2695c6b771b  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 158
513: sched_cls  name __send_drop_notify  tag e976cc88d08b3bbc  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
515: sched_cls  name tail_ipv4_to_endpoint  tag 7e899bf9c6b24d17  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 161
516: sched_cls  name tail_handle_ipv4_cont  tag 03f199b2f3fa0089  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 162
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 163
518: sched_cls  name tail_handle_arp  tag 8a11af090a087297  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 165
519: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 166
521: sched_cls  name handle_policy  tag 4c1497c830f99e2b  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,109,82,83,110,41,80,101,39,84,75,40,37,38
	btf_id 168
522: sched_cls  name __send_drop_notify  tag 1a166f216bc99cd5  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 169
523: sched_cls  name tail_ipv4_ct_ingress  tag 11de9d88535265f5  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 170
524: sched_cls  name cil_from_container  tag 05923d2d0499dea2  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 109,76
	btf_id 171
525: sched_cls  name tail_handle_ipv4  tag 77158d46004b31fa  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 172
526: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 173
527: sched_cls  name tail_handle_ipv4_cont  tag cbd4c9b4cf67ca35  gpl
	loaded_at 2024-10-24T12:32:36+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,110,41,101,82,83,39,76,74,77,109,40,37,38,81
	btf_id 174
528: sched_cls  name tail_ipv4_to_endpoint  tag 8954aba4ea37b9d0  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,110,41,82,83,80,101,39,109,40,37,38
	btf_id 175
529: sched_cls  name tail_ipv4_ct_ingress  tag b41df35597478597  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 177
530: sched_cls  name tail_handle_ipv4_cont  tag 87338e6412d0dd44  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,111,41,100,82,83,39,76,74,77,112,40,37,38,81
	btf_id 178
531: sched_cls  name tail_handle_arp  tag 8764b7deed75182c  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 179
532: sched_cls  name tail_handle_ipv4  tag 3b035295e219b39a  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 180
533: sched_cls  name tail_ipv4_ct_egress  tag 1ed3cd8af4451f0c  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 181
534: sched_cls  name cil_from_container  tag 72dc4fa73873ce46  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 182
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 183
536: sched_cls  name tail_ipv4_to_endpoint  tag 7fcaa6d5797b0385  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,100,39,112,40,37,38
	btf_id 184
537: sched_cls  name handle_policy  tag ff3510e59518e1a5  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,100,39,84,75,40,37,38
	btf_id 185
539: sched_cls  name __send_drop_notify  tag 969cfc927bf74a7d  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
540: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
543: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
544: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
547: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
557: sched_cls  name tail_handle_ipv4_from_host  tag e8a2e2a2edc9ba64  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 190
558: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 191
559: sched_cls  name __send_drop_notify  tag 65386a52aa948233  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
560: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 193
562: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 195
564: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
566: sched_cls  name tail_handle_ipv4_from_host  tag e8a2e2a2edc9ba64  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 200
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 201
568: sched_cls  name __send_drop_notify  tag 65386a52aa948233  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
570: sched_cls  name __send_drop_notify  tag 65386a52aa948233  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
574: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 209
575: sched_cls  name tail_handle_ipv4_from_host  tag e8a2e2a2edc9ba64  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 210
576: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 211
580: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 216
581: sched_cls  name tail_handle_ipv4_from_host  tag e8a2e2a2edc9ba64  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 217
582: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 218
583: sched_cls  name __send_drop_notify  tag 65386a52aa948233  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
623: sched_cls  name __send_drop_notify  tag ca8a1d46bf5f001b  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
624: sched_cls  name handle_policy  tag 0c7977efda57d5b1  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 234
625: sched_cls  name tail_handle_ipv4_cont  tag f3856b18c7efdd52  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 235
626: sched_cls  name tail_handle_arp  tag 7cc788b8653e8516  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 236
627: sched_cls  name tail_ipv4_ct_ingress  tag f1efc65f3b0f0a4e  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 237
629: sched_cls  name tail_ipv4_to_endpoint  tag 939103fc6164def8  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 239
630: sched_cls  name tail_ipv4_ct_egress  tag fc557a7f38916463  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 240
631: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 241
632: sched_cls  name tail_handle_ipv4  tag e35103c673abb851  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 242
633: sched_cls  name cil_from_container  tag 857907d444c1569b  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 243
634: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
637: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
673: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
676: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3286: sched_cls  name __send_drop_notify  tag 3cf920cb75d5658a  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3077
3287: sched_cls  name tail_ipv4_ct_ingress  tag 140b5bab5b5a6690  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3078
3288: sched_cls  name tail_ipv4_ct_egress  tag ee0cdbad63355e46  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3079
3290: sched_cls  name cil_from_container  tag 93b68f2538eaa041  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3081
3291: sched_cls  name tail_handle_arp  tag d60a04cd3e3c621f  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3082
3293: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3083
3296: sched_cls  name handle_policy  tag a2a015b0f57ae251  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,149,39,84,75,40,37,38
	btf_id 3087
3302: sched_cls  name tail_ipv4_to_endpoint  tag aa529d9e1f366b25  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,149,39,627,40,37,38
	btf_id 3090
3303: sched_cls  name tail_handle_ipv4_cont  tag 5f938b1e8171d36e  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,149,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3096
3304: sched_cls  name tail_handle_ipv4  tag 235771f51ed2baf7  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3097
3341: sched_cls  name tail_ipv4_ct_ingress  tag dcc317efc731b592  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3137
3342: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3140
3343: sched_cls  name tail_handle_ipv4  tag 5af0b8bace55b223  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3141
3344: sched_cls  name tail_handle_arp  tag ea96791a74eba014  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3142
3346: sched_cls  name handle_policy  tag 02c5274429278271  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,152,39,84,75,40,37,38
	btf_id 3139
3347: sched_cls  name __send_drop_notify  tag 649d24134a30f44e  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3145
3348: sched_cls  name tail_handle_ipv4  tag 7153afca0ee07fa6  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3146
3349: sched_cls  name tail_ipv4_to_endpoint  tag bf2a102722ece266  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,145,39,637,40,37,38
	btf_id 3144
3350: sched_cls  name tail_ipv4_ct_egress  tag 914bc206f507f085  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3147
3351: sched_cls  name cil_from_container  tag 07885cbf4b33fa5e  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3148
3352: sched_cls  name tail_handle_ipv4_cont  tag 6384fe8712013a73  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,145,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3149
3353: sched_cls  name __send_drop_notify  tag dfa7ffc3d9141638  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3150
3354: sched_cls  name handle_policy  tag 5a4250e3f7c3e7ec  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,145,39,84,75,40,37,38
	btf_id 3151
3355: sched_cls  name tail_ipv4_to_endpoint  tag 44968cb497bcd4c7  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,152,39,639,40,37,38
	btf_id 3152
3356: sched_cls  name tail_ipv4_ct_ingress  tag cafc92586b5b53bb  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3153
3358: sched_cls  name tail_handle_ipv4_cont  tag 294cac8589aeec6a  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,152,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3155
3359: sched_cls  name tail_handle_arp  tag 3f1978c22e30370b  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3156
3360: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3157
3361: sched_cls  name cil_from_container  tag bc880a73f5cdc56a  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3158
3362: sched_cls  name tail_ipv4_ct_egress  tag b7f7b4836e212697  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3159
