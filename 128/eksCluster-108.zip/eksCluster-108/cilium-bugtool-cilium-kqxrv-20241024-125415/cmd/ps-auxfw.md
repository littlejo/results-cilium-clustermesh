USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3278  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3272  0.0  0.4 1240432 16172 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3303  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3304  0.0  0.0   3852  1292 ?        R    12:54   0:00  \_ bash -c hostname
root        3247  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3245  0.0  0.0 1228744 3656 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.9  7.6 1539132 299440 ?      Ssl  12:32   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         404  0.3  0.2 1229744 8856 ?        Sl   12:32   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
