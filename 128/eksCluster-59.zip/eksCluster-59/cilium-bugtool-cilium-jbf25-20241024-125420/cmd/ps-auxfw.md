USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3273  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3266  0.0  0.4 1240432 16388 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3296  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3254  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3248  0.0  0.0 1228744 3780 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.2  7.2 1539060 285660 ?      Ssl  12:28   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         401  0.2  0.2 1229744 9880 ?        Sl   12:28   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
