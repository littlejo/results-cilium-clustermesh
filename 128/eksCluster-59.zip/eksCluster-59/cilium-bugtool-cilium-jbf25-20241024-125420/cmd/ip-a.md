1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:47:97:27:e8:f1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.194.250/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3464sec preferred_lft 3464sec
    inet6 fe80::847:97ff:fe27:e8f1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c0:b0:20:30:33 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.251.223/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8c0:b0ff:fe20:3033/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:9f:a3:17:4e:6a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::249f:a3ff:fe17:4e6a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:42:bd:30:4b:da brd ff:ff:ff:ff:ff:ff
    inet 10.59.0.123/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::42:bdff:fe30:4bda/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ca:32:fb:15:c7:3a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c832:fbff:fe15:c73a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:27:86:b1:eb:2e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c27:86ff:feb1:eb2e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc895e340a8a53@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:26:57:36:4c:e7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9826:57ff:fe36:4ce7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7944d8cae84e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:d5:ab:06:a7:91 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::4d5:abff:fe06:a791/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6016a4ff6305@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:07:b1:f7:b2:4d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::407:b1ff:fef7:b24d/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc2e386e520327@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:4a:3c:47:ae:f9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::744a:3cff:fe47:aef9/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc61a7ab14a2e6@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:23:42:7f:37:0b brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::5423:42ff:fe7f:370b/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc61ed06c81e4f@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:56:7b:cf:9a:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::fc56:7bff:fecf:9ac6/64 scope link 
       valid_lft forever preferred_lft forever
