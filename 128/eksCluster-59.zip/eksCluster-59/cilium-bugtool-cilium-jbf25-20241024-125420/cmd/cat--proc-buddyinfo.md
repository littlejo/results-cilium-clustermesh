Node 0, zone      DMA     22    142      6     19      3      6      9      1      3      3     41 
Node 0, zone   Normal     68      3      2      2     11      7      2      3      2      4      7 
