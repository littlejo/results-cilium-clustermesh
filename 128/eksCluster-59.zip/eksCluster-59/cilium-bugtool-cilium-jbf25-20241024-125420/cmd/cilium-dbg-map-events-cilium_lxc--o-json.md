{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.662Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.265Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.318Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.330Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.368Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.372Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.404Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.624Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.630Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.684Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.721Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.750Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.357Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.373Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.412Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.414Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.454Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.781Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.789Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.937Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.938Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.976Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.550Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.565Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.601Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.611Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.643Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.860Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.871Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.916Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.962Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.966Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.589Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.596Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.632Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.650Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.683Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.692Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.723Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.950Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.969Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.023Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.054Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.064Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.503Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.559Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.573Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.612Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.630Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.651Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.917Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.923Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.977Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.985Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.020Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.455Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.504Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.511Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.564Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.572Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.604Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.843Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.872Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.896Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.918Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.956Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.345Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.377Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.390Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.441Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.442Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.444Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.712Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.722Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.762Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.795Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.809Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.303Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.311Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.362Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.372Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.398Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.654Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.658Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.707Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.730Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.759Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.192Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.230Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.250Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.337Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.338Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.369Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.582Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.584Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.640Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.646Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.690Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.980Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.015Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.022Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.066Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.066Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.103Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.360Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.377Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.413Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.437Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.477Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.729Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.764Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.771Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.806Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.839Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.851Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.111Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.111Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.139Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.225Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.963Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.966Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.995Z",
  "value": "id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.022Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.037Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.332Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.340Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.050Z",
  "value": "id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.068Z",
  "value": "id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B"
}

