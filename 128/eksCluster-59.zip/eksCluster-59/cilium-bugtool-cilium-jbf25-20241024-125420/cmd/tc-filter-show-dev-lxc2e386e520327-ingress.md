filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2e386e520327 direct-action not_in_hw id 3339 tag f9ed1bc094468bb6 jited 
