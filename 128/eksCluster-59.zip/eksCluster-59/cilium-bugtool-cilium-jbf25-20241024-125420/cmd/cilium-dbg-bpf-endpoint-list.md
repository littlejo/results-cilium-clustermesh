IP ADDRESS         LOCAL ENDPOINT INFO
10.59.0.123:0      (localhost)                                                                                        
10.59.0.106:0      id=589   sec_id=3962633 flags=0x0000 ifindex=18  mac=72:15:DC:BF:CA:F7 nodemac=06:07:B1:F7:B2:4D   
10.59.0.151:0      id=2682  sec_id=3991775 flags=0x0000 ifindex=12  mac=0A:9D:D9:89:D3:DF nodemac=9A:26:57:36:4C:E7   
10.59.0.3:0        id=2026  sec_id=3985316 flags=0x0000 ifindex=20  mac=FA:D2:83:50:0D:9D nodemac=76:4A:3C:47:AE:F9   
172.31.194.250:0   (localhost)                                                                                        
10.59.0.193:0      id=2816  sec_id=4     flags=0x0000 ifindex=10  mac=4A:0A:F3:C0:13:4D nodemac=0E:27:86:B1:EB:2E     
172.31.251.223:0   (localhost)                                                                                        
10.59.0.124:0      id=871   sec_id=3996401 flags=0x0000 ifindex=22  mac=4E:7F:E4:4F:D4:18 nodemac=56:23:42:7F:37:0B   
10.59.0.232:0      id=203   sec_id=3991775 flags=0x0000 ifindex=14  mac=DE:A0:51:C4:13:59 nodemac=06:D5:AB:06:A7:91   
10.59.0.88:0       id=858   sec_id=3950362 flags=0x0000 ifindex=24  mac=0E:C7:5E:F7:05:11 nodemac=FE:56:7B:CF:9A:C6   
