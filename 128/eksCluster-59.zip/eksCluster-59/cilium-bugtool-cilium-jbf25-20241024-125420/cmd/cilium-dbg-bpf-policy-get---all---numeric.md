Endpoint ID: 203
Path: /sys/fs/bpf/tc/globals/cilium_policy_00203

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4456     44        0        
Allow    Ingress     1          ANY          NONE         disabled    148284   1702      0        
Allow    Egress      0          ANY          NONE         disabled    19808    221       0        


Endpoint ID: 313
Path: /sys/fs/bpf/tc/globals/cilium_policy_00313

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 589
Path: /sys/fs/bpf/tc/globals/cilium_policy_00589

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6113859   60385     0        
Allow    Ingress     1          ANY          NONE         disabled    4861531   51062     0        
Allow    Egress      0          ANY          NONE         disabled    5736095   57889     0        


Endpoint ID: 858
Path: /sys/fs/bpf/tc/globals/cilium_policy_00858

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377922   4414      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 871
Path: /sys/fs/bpf/tc/globals/cilium_policy_00871

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2026
Path: /sys/fs/bpf/tc/globals/cilium_policy_02026

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2682
Path: /sys/fs/bpf/tc/globals/cilium_policy_02682

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1440     16        0        
Allow    Ingress     1          ANY          NONE         disabled    148467   1703      0        
Allow    Egress      0          ANY          NONE         disabled    19563    217       0        


Endpoint ID: 2816
Path: /sys/fs/bpf/tc/globals/cilium_policy_02816

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6224868   76917     0        
Allow    Ingress     1          ANY          NONE         disabled    64702     779       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


