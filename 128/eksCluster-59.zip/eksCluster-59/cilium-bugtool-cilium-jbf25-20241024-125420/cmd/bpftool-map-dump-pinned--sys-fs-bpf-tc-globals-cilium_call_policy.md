key: cb 00 00 00  value: 4b 02 00 00
key: 4d 02 00 00  value: 81 02 00 00
key: 5a 03 00 00  value: d6 0c 00 00
key: 67 03 00 00  value: 1b 0d 00 00
key: ea 07 00 00  value: 13 0d 00 00
key: 7a 0a 00 00  value: 08 02 00 00
key: 00 0b 00 00  value: 3a 02 00 00
Found 7 elements
