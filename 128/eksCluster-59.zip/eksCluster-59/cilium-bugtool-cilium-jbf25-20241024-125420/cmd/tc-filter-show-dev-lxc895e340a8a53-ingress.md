filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc895e340a8a53 direct-action not_in_hw id 525 tag 4e11a70e0b4768d7 jited 
