top - 12:54:22 up 32 min,  0 users,  load average: 0.59, 0.66, 0.35
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.7 us, 26.7 sy,  0.0 ni, 66.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    312.2 free,   1026.7 used,   2497.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2628.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 285660  78644 S   6.7   7.3   1:05.77 cilium-+
   3266 root      20   0 1240432  16388  11420 S   6.7   0.4   0:00.03 cilium-+
    401 root      20   0 1229744   9880   3836 S   0.0   0.3   0:04.53 cilium-+
   3248 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3254 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3273 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3307 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3325 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
