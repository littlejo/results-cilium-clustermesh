markdown output at /tmp/cilium-bugtool-20241024-125422.531+0000-UTC-2837064369/cmd/cilium-debuginfo-20241024-125453.32+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125422.531+0000-UTC-2837064369/cmd/cilium-debuginfo-20241024-125453.32+0000-UTC.json
