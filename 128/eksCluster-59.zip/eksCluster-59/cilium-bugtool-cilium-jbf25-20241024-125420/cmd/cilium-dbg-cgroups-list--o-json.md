[
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf202b5c_ca49_400a_b89d_6cdbdb9cf29a.slice/cri-containerd-83c6b95cabf0e1189caf24052545206485f4cfd03302636595a6cc16a1e650f9.scope"
      }
    ],
    "ips": [
      "10.59.0.3"
    ],
    "name": "client-974f6c69d-h267v",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7493,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod919c5e77_6573_4bb1_9e1e_a0ea6669dc62.slice/cri-containerd-f9b834d0f9c2fc0059603f0f253fc2272019a05e43df398d3ed85547eb6bc724.scope"
      }
    ],
    "ips": [
      "10.59.0.151"
    ],
    "name": "coredns-cc6ccd49c-tr5xn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podded483b0_5f98_4560_9f57_7a9ac3b9a515.slice/cri-containerd-c5402b2a392bbad5c57fc53e679e58b8a323fdf33658251e9f0e63dbcd590467.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podded483b0_5f98_4560_9f57_7a9ac3b9a515.slice/cri-containerd-ce6cf2e9c5994ee7e2a7b8033dcbfb312e3907c49a1ae1063a1306b7a96e02f4.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podded483b0_5f98_4560_9f57_7a9ac3b9a515.slice/cri-containerd-02b5bd2227e5be758df2cb0156998c3e14bbdbbf4abda295f8ffba649d8547c0.scope"
      }
    ],
    "ips": [
      "10.59.0.106"
    ],
    "name": "clustermesh-apiserver-54c674759b-wp44q",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9e631d22_4f0b_4313_a2b6_00c86e60919d.slice/cri-containerd-3f7c1cc609d4f2bc92888b43a9a27fffc4bcd9a9cd9fa12b8e20a5161fb7c00b.scope"
      }
    ],
    "ips": [
      "10.59.0.124"
    ],
    "name": "client2-57cf4468f-fs557",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda10b39d8_8900_4ad3_8043_f7c0e582308e.slice/cri-containerd-7cea188e9f235666434f0dcaf86439acf8e2b66b648a2ce58307e8138cd7de20.scope"
      }
    ],
    "ips": [
      "10.59.0.232"
    ],
    "name": "coredns-cc6ccd49c-dqsjs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a88850b_e9d4_4333_bf44_e694d33ba573.slice/cri-containerd-0d72ffcd585b14d952126b39a3f92f38c0a8798e5e97c572f7c65c5d8cf23100.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a88850b_e9d4_4333_bf44_e694d33ba573.slice/cri-containerd-6f6711361bf38db2a55657a066769e189ec3cdf05947260fc49d908e265b3b4f.scope"
      }
    ],
    "ips": [
      "10.59.0.88"
    ],
    "name": "echo-same-node-86d9cc975c-ds5m8",
    "namespace": "cilium-test-1"
  }
]

