CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod997bd24f_5ff9_4815_bee2_03cbee84f064.slice/cri-containerd-82985f76ad8a921c7a891d37986c79671ef46da354ea72c196258fcf28f0e8cc.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod997bd24f_5ff9_4815_bee2_03cbee84f064.slice/cri-containerd-aad6bde5fae3ab6428ed4ecaa3c64ca80f191eea03fbb3055bd390cc41466af6.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod919c5e77_6573_4bb1_9e1e_a0ea6669dc62.slice/cri-containerd-f9b834d0f9c2fc0059603f0f253fc2272019a05e43df398d3ed85547eb6bc724.scope
    581      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod919c5e77_6573_4bb1_9e1e_a0ea6669dc62.slice/cri-containerd-e62c062211e0e8d76f1a672779af913d9a579625ca46f3afd67e777fa8b1ac9f.scope
    577      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda10b39d8_8900_4ad3_8043_f7c0e582308e.slice/cri-containerd-a38727351535ad3a8266ace095ccde7e15322730eacd4e5749eb4dad08c9a466.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda10b39d8_8900_4ad3_8043_f7c0e582308e.slice/cri-containerd-7cea188e9f235666434f0dcaf86439acf8e2b66b648a2ce58307e8138cd7de20.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2188e99_c811_4977_ad32_21f40424ae5f.slice/cri-containerd-9046b843936b4151e8eecaabed397791f41d80493a833289da11917be1170edb.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2188e99_c811_4977_ad32_21f40424ae5f.slice/cri-containerd-cb9dcee8e57b463c5cef9e007779a31a9c231c52cabfaf8ae5d9c6be4d8536a3.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podded483b0_5f98_4560_9f57_7a9ac3b9a515.slice/cri-containerd-c5402b2a392bbad5c57fc53e679e58b8a323fdf33658251e9f0e63dbcd590467.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podded483b0_5f98_4560_9f57_7a9ac3b9a515.slice/cri-containerd-02b5bd2227e5be758df2cb0156998c3e14bbdbbf4abda295f8ffba649d8547c0.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podded483b0_5f98_4560_9f57_7a9ac3b9a515.slice/cri-containerd-ce6cf2e9c5994ee7e2a7b8033dcbfb312e3907c49a1ae1063a1306b7a96e02f4.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podded483b0_5f98_4560_9f57_7a9ac3b9a515.slice/cri-containerd-e745ee5ab8c24a267a647f63080e9b8f1de442a5337876bdef5da878c6e7dcc4.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9e631d22_4f0b_4313_a2b6_00c86e60919d.slice/cri-containerd-0e9b697f01ce99db759ecd14bf6950809f149c31195313b32cfe84a19025a086.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9e631d22_4f0b_4313_a2b6_00c86e60919d.slice/cri-containerd-3f7c1cc609d4f2bc92888b43a9a27fffc4bcd9a9cd9fa12b8e20a5161fb7c00b.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a88850b_e9d4_4333_bf44_e694d33ba573.slice/cri-containerd-3b2cc5e5448d90661415b5a78ad24df82987253c1d10ec133f1a644cfe09dacb.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a88850b_e9d4_4333_bf44_e694d33ba573.slice/cri-containerd-6f6711361bf38db2a55657a066769e189ec3cdf05947260fc49d908e265b3b4f.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a88850b_e9d4_4333_bf44_e694d33ba573.slice/cri-containerd-0d72ffcd585b14d952126b39a3f92f38c0a8798e5e97c572f7c65c5d8cf23100.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d441656_deab_4700_a182_da9828886344.slice/cri-containerd-d58ef7f576c9741996cef00abfaad69fa52a3c097577894b5cb8d11833feaca1.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d441656_deab_4700_a182_da9828886344.slice/cri-containerd-a8b38434a7d2e119068404e43f7183daad8eb79755898d2a886a050e5d7e9bf1.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec3be299_72b2_4888_a417_04814cd632a3.slice/cri-containerd-24f6d2d8ef9e095579f66fa7aa1ab0d1b43c5b3e097e39ccd6f637edf6d2c75a.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec3be299_72b2_4888_a417_04814cd632a3.slice/cri-containerd-6cd9aa149573c90b4c547f4c642f4372ca07c03a52d166b2ad77205349755b93.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf202b5c_ca49_400a_b89d_6cdbdb9cf29a.slice/cri-containerd-82faf9466ed3bc57b6d81160c3dbeaefc9c59ac3295cf5bd1c048f5149301022.scope
    693      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf202b5c_ca49_400a_b89d_6cdbdb9cf29a.slice/cri-containerd-83c6b95cabf0e1189caf24052545206485f4cfd03302636595a6cc16a1e650f9.scope
    727      cgroup_device   multi                                          
