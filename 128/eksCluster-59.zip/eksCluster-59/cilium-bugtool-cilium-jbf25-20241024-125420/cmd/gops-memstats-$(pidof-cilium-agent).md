alloc: 120.19MB (126027264 bytes)
total-alloc: 3.05GB (3276630760 bytes)
sys: 211.32MB (221586772 bytes)
lookups: 0
mallocs: 74638787
frees: 73401428
heap-alloc: 120.19MB (126027264 bytes)
heap-sys: 164.52MB (172507136 bytes)
heap-idle: 21.63MB (22683648 bytes)
heap-in-use: 142.88MB (149823488 bytes)
heap-released: 1.63MB (1712128 bytes)
heap-objects: 1237359
stack-in-use: 35.44MB (37158912 bytes)
stack-sys: 35.44MB (37158912 bytes)
stack-mspan-inuse: 2.32MB (2432000 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1005.06KB (1029185 bytes)
gc-sys: 5.52MB (5788744 bytes)
next-gc: when heap-alloc >= 152.88MB (160309272 bytes)
last-gc: 2024-10-24 12:54:24.020656335 +0000 UTC
gc-pause-total: 22.541223ms
gc-pause: 92472
gc-pause-end: 1729774464020656335
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0005684311512581889
enable-gc: true
debug-gc: false
