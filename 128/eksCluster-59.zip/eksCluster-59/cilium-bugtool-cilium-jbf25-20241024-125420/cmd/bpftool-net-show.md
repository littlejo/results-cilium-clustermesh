xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 563
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 543
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 538
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 573
lxc895e340a8a53(12) clsact/ingress cil_from_container-lxc895e340a8a53 id 525
lxc7944d8cae84e(14) clsact/ingress cil_from_container-lxc7944d8cae84e id 584
lxc6016a4ff6305(18) clsact/ingress cil_from_container-lxc6016a4ff6305 id 640
lxc2e386e520327(20) clsact/ingress cil_from_container-lxc2e386e520327 id 3339
lxc61a7ab14a2e6(22) clsact/ingress cil_from_container-lxc61a7ab14a2e6 id 3356
lxc61ed06c81e4f(24) clsact/ingress cil_from_container-lxc61ed06c81e4f id 3293

flow_dissector:

netfilter:

