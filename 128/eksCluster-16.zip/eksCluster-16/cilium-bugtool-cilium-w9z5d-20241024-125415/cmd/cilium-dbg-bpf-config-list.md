KEY             VALUE
AgentLiveness   2038614101389
UTimeOffset     3378461814453125
