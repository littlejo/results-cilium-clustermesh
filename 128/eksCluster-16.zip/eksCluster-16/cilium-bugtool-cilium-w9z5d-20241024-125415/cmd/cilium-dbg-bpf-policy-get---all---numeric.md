Endpoint ID: 337
Path: /sys/fs/bpf/tc/globals/cilium_policy_00337

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6224396   76929     0        
Allow    Ingress     1          ANY          NONE         disabled    69778     842       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 692
Path: /sys/fs/bpf/tc/globals/cilium_policy_00692

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1109
Path: /sys/fs/bpf/tc/globals/cilium_policy_01109

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6109132   61243     0        
Allow    Ingress     1          ANY          NONE         disabled    5336001   56252     0        
Allow    Egress      0          ANY          NONE         disabled    6654542   65851     0        


Endpoint ID: 1588
Path: /sys/fs/bpf/tc/globals/cilium_policy_01588

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3488     34        0        
Allow    Ingress     1          ANY          NONE         disabled    168000   1933      0        
Allow    Egress      0          ANY          NONE         disabled    22394    253       0        


Endpoint ID: 1720
Path: /sys/fs/bpf/tc/globals/cilium_policy_01720

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2053
Path: /sys/fs/bpf/tc/globals/cilium_policy_02053

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2408     26        0        
Allow    Ingress     1          ANY          NONE         disabled    167555   1921      0        
Allow    Egress      0          ANY          NONE         disabled    22414    253       0        


Endpoint ID: 2186
Path: /sys/fs/bpf/tc/globals/cilium_policy_02186

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3031
Path: /sys/fs/bpf/tc/globals/cilium_policy_03031

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378872   4422      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


