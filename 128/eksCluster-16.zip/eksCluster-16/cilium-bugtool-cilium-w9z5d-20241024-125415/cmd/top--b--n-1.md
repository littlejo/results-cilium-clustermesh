top - 12:54:17 up 33 min,  0 users,  load average: 0.53, 0.46, 0.24
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 22.2 us, 44.4 sy,  0.0 ni, 33.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    285.5 free,   1053.4 used,   2497.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2601.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 295328  80568 S  13.3   7.5   1:05.43 cilium-+
   3282 root      20   0 1240432  16100  11356 S   6.7   0.4   0:00.03 cilium-+
    400 root      20   0 1229744   9992   3836 S   0.0   0.3   0:04.38 cilium-+
   3268 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3295 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3301 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3335 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3360 root      20   0 1228744   4032   3392 S   0.0   0.1   0:00.00 gops
