markdown output at /tmp/cilium-bugtool-20241024-125417.007+0000-UTC-3750101504/cmd/cilium-debuginfo-20241024-125447.813+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.007+0000-UTC-3750101504/cmd/cilium-debuginfo-20241024-125447.813+0000-UTC.json
