[
  {
    "containers": [
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e8fe4b3_c40d_416b_b6e4_178885309b95.slice/cri-containerd-192502ae91d9a614c359ffce8e1ae659f99ee204aa226fd42dacd35f629c4d8b.scope"
      },
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e8fe4b3_c40d_416b_b6e4_178885309b95.slice/cri-containerd-c07acb001d5f42dce7f8731431e8870dc8c0f5e121b3c9ef5629e1578783f16d.scope"
      },
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e8fe4b3_c40d_416b_b6e4_178885309b95.slice/cri-containerd-e30d94bff9e0078a507c27232917003c2f352dcba9b4e470386b69faad2507e6.scope"
      }
    ],
    "ips": [
      "10.16.0.8"
    ],
    "name": "clustermesh-apiserver-6954d5d586-rsn97",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc7a748a_54d4_4391_8aa0_ea216167cd8b.slice/cri-containerd-9ccf58b4e88bee33d76ebe036adc1c753905c354d0807ce9412a1b675059ff85.scope"
      }
    ],
    "ips": [
      "10.16.0.14"
    ],
    "name": "coredns-cc6ccd49c-4ppll",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod169b50db_c43b_4c64_8ebe_096b7b131794.slice/cri-containerd-28d13b46d51cc9cfa289de3a03b275f10f5d6201771dcde8287d719b1196cef0.scope"
      }
    ],
    "ips": [
      "10.16.0.237"
    ],
    "name": "coredns-cc6ccd49c-4sn2k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067fe44b_11d1_46df_b840_763be33f2d46.slice/cri-containerd-aaf6726171757a076359e4970990cdf3e59143b2c03ca13d4fef78d301bbec3c.scope"
      }
    ],
    "ips": [
      "10.16.0.131"
    ],
    "name": "client-974f6c69d-qjbph",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod374bc1e3_fea9_4e6a_b0cb_32081b574205.slice/cri-containerd-6e728be0273ff3502f608c97bb2fc84966bb3d9d5505551c921d2dfab5c2bc55.scope"
      },
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod374bc1e3_fea9_4e6a_b0cb_32081b574205.slice/cri-containerd-3437f583a8d452fad40c5255414221949399a410c4b3723275ad109e5ae96f82.scope"
      }
    ],
    "ips": [
      "10.16.0.196"
    ],
    "name": "echo-same-node-86d9cc975c-5bcbb",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2711fb24_b4d4_4ca6_bfc9_f224df172ce1.slice/cri-containerd-5d932c8ac8d7366ef6c65d3920def36e460b5dd64319374162f2e69378ed508f.scope"
      }
    ],
    "ips": [
      "10.16.0.183"
    ],
    "name": "client2-57cf4468f-vrmrg",
    "namespace": "cilium-test-1"
  }
]

