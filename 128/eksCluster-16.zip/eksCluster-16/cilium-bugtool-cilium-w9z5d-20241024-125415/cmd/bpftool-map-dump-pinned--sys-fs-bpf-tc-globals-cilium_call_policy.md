key: 51 01 00 00  value: 45 02 00 00
key: 55 04 00 00  value: 85 02 00 00
key: 34 06 00 00  value: 0e 02 00 00
key: b8 06 00 00  value: 28 0d 00 00
key: 05 08 00 00  value: 27 02 00 00
key: 8a 08 00 00  value: 24 0d 00 00
key: d7 0b 00 00  value: fd 0c 00 00
Found 7 elements
