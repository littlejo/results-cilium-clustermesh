{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.501Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.549Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.553Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.598Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.611Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.635Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.848Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.859Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.926Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.938Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.967Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.576Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.596Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.622Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.649Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.671Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.907Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.912Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.978Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.995Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.037Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.569Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.577Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.600Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.628Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.647Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.680Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.691Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.916Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.929Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.975Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.003Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.032Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.597Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.605Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.632Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.656Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.701Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.716Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.740Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.986Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.000Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.039Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.079Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.094Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.649Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.669Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.728Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.742Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.767Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.960Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.964Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.013Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.032Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.053Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.453Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.488Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.494Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.538Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.540Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.577Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.787Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.800Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.842Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.874Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.895Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.324Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.357Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.384Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.415Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.465Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.688Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.705Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.758Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.776Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.809Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.190Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.193Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.235Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.251Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.276Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.553Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.569Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.596Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.624Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.652Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.059Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.109Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.112Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.154Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.179Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.194Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.469Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.476Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.534Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.573Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.585Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.851Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.893Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.914Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.960Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.963Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.005Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.240Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.251Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.280Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.317Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.335Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.642Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.680Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.696Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.741Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.746Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.778Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.996Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.010Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.017Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.023Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.038Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.805Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.807Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.869Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.881Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.903Z",
  "value": "id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.175Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.180Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.827Z",
  "value": "id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.852Z",
  "value": "id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC"
}

