filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd433246242e6 direct-action not_in_hw id 569 tag 2781e0e8eaec0fcd jited 
