32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:52+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:20:52+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:53+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:20:56+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:09+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
482: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
483: sched_cls  name tail_handle_ipv4  tag ae5c5ad31fe9fd6e  gpl
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:25:26+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 163
516: sched_cls  name tail_handle_ipv4  tag f763d42b3535c2b7  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 164
518: sched_cls  name tail_ipv4_to_endpoint  tag dacc68b6da1c0fcb  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 167
521: sched_cls  name tail_handle_ipv4_cont  tag e8b1447e6023774c  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 169
522: sched_cls  name tail_ipv4_ct_egress  tag 928904c5dbced7c5  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 172
526: sched_cls  name handle_policy  tag 1106539884283c47  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 173
530: sched_cls  name tail_ipv4_ct_ingress  tag 733bce71136cda1f  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 177
532: sched_cls  name __send_drop_notify  tag 209a39a68a44dfbc  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 181
533: sched_cls  name tail_handle_arp  tag 727061c725549a65  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 183
534: sched_cls  name cil_from_container  tag 5ed12dc6c1eeec4e  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 185
535: sched_cls  name tail_handle_ipv4_cont  tag e252302d49286b59  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 184
536: sched_cls  name tail_handle_arp  tag f18dc130d1f25463  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 188
537: sched_cls  name tail_handle_ipv4_from_host  tag fc78c422f33c28c3  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 187
539: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
540: sched_cls  name __send_drop_notify  tag 90b4a9566963df6e  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
542: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 194
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 195
545: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
546: sched_cls  name __send_drop_notify  tag 90b4a9566963df6e  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
550: sched_cls  name tail_handle_ipv4_from_host  tag fc78c422f33c28c3  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 203
551: sched_cls  name handle_policy  tag 301c7b071e3da2b9  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 189
552: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 204
554: sched_cls  name __send_drop_notify  tag 90b4a9566963df6e  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 208
555: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 209
557: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 211
558: sched_cls  name tail_handle_ipv4_from_host  tag fc78c422f33c28c3  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 212
562: sched_cls  name tail_handle_ipv4  tag f1d1a54f6676596f  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 207
563: sched_cls  name __send_drop_notify  tag 90b4a9566963df6e  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
564: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 219
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 221
567: sched_cls  name tail_handle_ipv4_from_host  tag fc78c422f33c28c3  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 222
568: sched_cls  name tail_ipv4_to_endpoint  tag 3216eb4838a0980a  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 217
569: sched_cls  name cil_from_container  tag 2781e0e8eaec0fcd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 225
570: sched_cls  name tail_ipv4_ct_egress  tag 928904c5dbced7c5  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 226
571: sched_cls  name __send_drop_notify  tag 4ee0a2899da812f0  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 227
572: sched_cls  name tail_handle_ipv4  tag d178200b3540ba3d  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 224
573: sched_cls  name __send_drop_notify  tag d7725cddd6e8d9b6  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 229
574: sched_cls  name tail_ipv4_ct_ingress  tag a5b36d5c69644604  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 228
576: sched_cls  name tail_ipv4_ct_ingress  tag be646dfb573730a1  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 230
578: sched_cls  name cil_from_container  tag 797a1da89b0b2731  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 233
579: sched_cls  name tail_handle_ipv4_cont  tag d72186b57e395728  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 234
580: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 235
581: sched_cls  name handle_policy  tag f65094517d11171a  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 236
582: sched_cls  name tail_ipv4_to_endpoint  tag a969d825c8008347  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 237
583: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 238
584: sched_cls  name tail_handle_arp  tag 55983b16f02a1994  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 253
641: sched_cls  name tail_handle_arp  tag 78376dfeb77bad6d  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 254
642: sched_cls  name tail_handle_ipv4  tag cf1ba10a786f1936  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 255
643: sched_cls  name tail_ipv4_ct_egress  tag e3fb3a0ea2db334a  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 256
644: sched_cls  name tail_ipv4_ct_ingress  tag c13297dcaccb1136  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 257
645: sched_cls  name handle_policy  tag 8f3c45bc44656f27  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 258
646: sched_cls  name tail_ipv4_to_endpoint  tag 4d2a36be3f33f3e5  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 259
647: sched_cls  name cil_from_container  tag 8216b75c24bf9ab6  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 260
648: sched_cls  name tail_handle_ipv4_cont  tag c3e7aa3fe87de0ab  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 261
649: sched_cls  name __send_drop_notify  tag 969cfc927bf74a7d  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 262
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
701: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
704: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
705: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
708: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
720: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
723: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
724: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
727: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
728: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
731: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
732: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
735: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
736: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
739: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3325: sched_cls  name handle_policy  tag 42c42898a5a98114  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,638,82,83,637,41,80,159,39,84,75,40,37,38
	btf_id 3120
3326: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,638
	btf_id 3122
3327: sched_cls  name tail_handle_ipv4  tag 42947213e7c5e0a7  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,638
	btf_id 3123
3329: sched_cls  name tail_ipv4_ct_egress  tag cf4cda6408d022e6  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3125
3330: sched_cls  name tail_handle_arp  tag aaab204fa6b20583  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,638
	btf_id 3126
3331: sched_cls  name tail_handle_ipv4_cont  tag 8724d81615217d55  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,637,41,159,82,83,39,76,74,77,638,40,37,38,81
	btf_id 3127
3332: sched_cls  name tail_ipv4_ct_ingress  tag 9bb5b13c0466cb34  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3128
3333: sched_cls  name cil_from_container  tag 52ccd3b2a6324ca9  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,76
	btf_id 3129
3334: sched_cls  name __send_drop_notify  tag f198fafc66c9401f  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3130
3335: sched_cls  name tail_ipv4_to_endpoint  tag 861136d4883cdf84  gpl
	loaded_at 2024-10-24T12:51:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,637,41,82,83,80,159,39,638,40,37,38
	btf_id 3131
3358: sched_cls  name __send_drop_notify  tag 0b51d1ecafe15990  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3157
3359: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,643
	btf_id 3158
3361: sched_cls  name tail_ipv4_ct_ingress  tag c484b4d9582e7e49  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3161
3362: sched_cls  name tail_handle_ipv4  tag eb3249b9bda4e9f1  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,643
	btf_id 3163
3363: sched_cls  name cil_from_container  tag ff72147296c4990f  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 643,76
	btf_id 3164
3364: sched_cls  name handle_policy  tag 4746bc943aa5b210  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,646,82,83,645,41,80,154,39,84,75,40,37,38
	btf_id 3162
3365: sched_cls  name tail_handle_ipv4_cont  tag e5270bc61577d67d  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,645,41,154,82,83,39,76,74,77,646,40,37,38,81
	btf_id 3166
3366: sched_cls  name tail_handle_arp  tag a9c75be7771437bb  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,646
	btf_id 3167
3367: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,646
	btf_id 3168
3368: sched_cls  name handle_policy  tag 2aa77bd4bf9dca1d  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,643,82,83,644,41,80,151,39,84,75,40,37,38
	btf_id 3165
3369: sched_cls  name tail_ipv4_ct_ingress  tag d13a95da6c103663  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3169
3370: sched_cls  name tail_ipv4_to_endpoint  tag c18d2d0a0482a721  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,644,41,82,83,80,151,39,643,40,37,38
	btf_id 3170
3371: sched_cls  name tail_handle_ipv4_cont  tag 5b9940e4c6a3f306  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,644,41,151,82,83,39,76,74,77,643,40,37,38,81
	btf_id 3172
3372: sched_cls  name tail_ipv4_ct_egress  tag 7dc4d1ca367ec0e1  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3173
3374: sched_cls  name tail_handle_arp  tag 3e12eb7e883c4d56  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,643
	btf_id 3175
3375: sched_cls  name tail_handle_ipv4  tag fcd3142f6637ace2  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,646
	btf_id 3171
3376: sched_cls  name tail_ipv4_to_endpoint  tag 1f93dd9487afa54c  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,645,41,82,83,80,154,39,646,40,37,38
	btf_id 3176
3377: sched_cls  name __send_drop_notify  tag 509da993eb9f1c2e  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3177
3378: sched_cls  name tail_ipv4_ct_egress  tag 26009dfcb4a88830  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3178
3379: sched_cls  name cil_from_container  tag 9ccc6660aa450293  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 646,76
	btf_id 3179
