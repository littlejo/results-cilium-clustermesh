Node 0, zone      DMA     99    109     14     12      9      3      2      9      5      5     40 
Node 0, zone   Normal    106     21     17     19     16      7      4      1      3      3      7 
