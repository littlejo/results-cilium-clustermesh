alloc: 116.86MB (122535096 bytes)
total-alloc: 3.15GB (3383874416 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 76021394
frees: 74742574
heap-alloc: 116.86MB (122535096 bytes)
heap-sys: 172.51MB (180887552 bytes)
heap-idle: 34.70MB (36388864 bytes)
heap-in-use: 137.80MB (144498688 bytes)
heap-released: 4.77MB (5005312 bytes)
heap-objects: 1278820
stack-in-use: 35.47MB (37191680 bytes)
stack-sys: 35.47MB (37191680 bytes)
stack-mspan-inuse: 2.29MB (2406240 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 961.31KB (984377 bytes)
gc-sys: 5.50MB (5770336 bytes)
next-gc: when heap-alloc >= 150.88MB (158209336 bytes)
last-gc: 2024-10-24 12:54:17.950730547 +0000 UTC
gc-pause-total: 12.291192ms
gc-pause: 983671
gc-pause-end: 1729774457950730547
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.000520311355506673
enable-gc: true
debug-gc: false
