IP ADDRESS        LOCAL ENDPOINT INFO
10.16.0.14:0      id=1588  sec_id=1160272 flags=0x0000 ifindex=12  mac=A2:26:75:42:59:64 nodemac=2A:A8:13:07:52:E3   
10.16.0.187:0     (localhost)                                                                                        
10.16.0.148:0     id=337   sec_id=4     flags=0x0000 ifindex=10  mac=C2:07:2D:EF:56:F2 nodemac=BA:EC:6E:F7:D1:2E     
172.31.142.66:0   (localhost)                                                                                        
10.16.0.196:0     id=3031  sec_id=1156521 flags=0x0000 ifindex=24  mac=C2:72:FE:F1:0B:75 nodemac=9A:17:0D:DE:A4:6A   
10.16.0.8:0       id=1109  sec_id=1153254 flags=0x0000 ifindex=18  mac=FE:30:06:09:E8:16 nodemac=26:3F:01:24:62:EC   
10.16.0.237:0     id=2053  sec_id=1160272 flags=0x0000 ifindex=14  mac=42:5C:59:93:C6:B2 nodemac=EE:1C:EF:68:25:72   
10.16.0.131:0     id=1720  sec_id=1157009 flags=0x0000 ifindex=20  mac=42:B7:B9:F0:AE:BC nodemac=76:DF:6C:F5:4D:BC   
10.16.0.183:0     id=2186  sec_id=1129712 flags=0x0000 ifindex=22  mac=D2:93:DF:7E:0B:42 nodemac=FE:B8:DE:5E:A3:BC   
172.31.151.43:0   (localhost)                                                                                        
