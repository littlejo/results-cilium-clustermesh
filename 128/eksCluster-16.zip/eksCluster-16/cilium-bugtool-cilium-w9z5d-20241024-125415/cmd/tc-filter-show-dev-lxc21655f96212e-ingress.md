filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc21655f96212e direct-action not_in_hw id 3333 tag 52ccd3b2a6324ca9 jited 
