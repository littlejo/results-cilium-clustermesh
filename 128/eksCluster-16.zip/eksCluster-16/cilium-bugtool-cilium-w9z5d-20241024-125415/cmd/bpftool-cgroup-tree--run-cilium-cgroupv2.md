CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc7a748a_54d4_4391_8aa0_ea216167cd8b.slice/cri-containerd-9ccf58b4e88bee33d76ebe036adc1c753905c354d0807ce9412a1b675059ff85.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc7a748a_54d4_4391_8aa0_ea216167cd8b.slice/cri-containerd-41b0c25f99b95c2240ebeaa1a835e69db41ee9a3da106f7ed84dc6853b2351bc.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod23cb9244_d010_4953_b701_d5c2d0663359.slice/cri-containerd-8acea1b576b785dda1c9bdd795b9052b7fd5ffc134df741a9af515e9e62b6e61.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod23cb9244_d010_4953_b701_d5c2d0663359.slice/cri-containerd-0881ef3a2a43c8ef149e1d8618e9b1f0babf2484b6533486e475e185ddeecd7b.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb7d1459e_66d9_41ba_bd14_0d8444aa97de.slice/cri-containerd-602d09ecfb6f8433440ed64f7a3a749d467095ed02d41834d40d12752808d93b.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb7d1459e_66d9_41ba_bd14_0d8444aa97de.slice/cri-containerd-8dea84304aa00309efa046477db4f59b4f147430e530986fbf4d3dc70c12d9aa.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod169b50db_c43b_4c64_8ebe_096b7b131794.slice/cri-containerd-40c91c53cf3003d00188ae35c016016bb65c73e8ca59b8cea1e3c8e9f44b3ce4.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod169b50db_c43b_4c64_8ebe_096b7b131794.slice/cri-containerd-28d13b46d51cc9cfa289de3a03b275f10f5d6201771dcde8287d719b1196cef0.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067fe44b_11d1_46df_b840_763be33f2d46.slice/cri-containerd-11a2962d320cbadee0eb60f4e0973bff7a4f03f00a3be57d0ada13646e48f975.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod067fe44b_11d1_46df_b840_763be33f2d46.slice/cri-containerd-aaf6726171757a076359e4970990cdf3e59143b2c03ca13d4fef78d301bbec3c.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e8fe4b3_c40d_416b_b6e4_178885309b95.slice/cri-containerd-192502ae91d9a614c359ffce8e1ae659f99ee204aa226fd42dacd35f629c4d8b.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e8fe4b3_c40d_416b_b6e4_178885309b95.slice/cri-containerd-e30d94bff9e0078a507c27232917003c2f352dcba9b4e470386b69faad2507e6.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e8fe4b3_c40d_416b_b6e4_178885309b95.slice/cri-containerd-c07acb001d5f42dce7f8731431e8870dc8c0f5e121b3c9ef5629e1578783f16d.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e8fe4b3_c40d_416b_b6e4_178885309b95.slice/cri-containerd-e2684a07991656d07cab0ef6b3fe71ba17c69b76db307689269951c1c1350573.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod374bc1e3_fea9_4e6a_b0cb_32081b574205.slice/cri-containerd-50d1c2650943fa240a1a33830390a976c7f30d18c764e72c6143fc900fc2ab15.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod374bc1e3_fea9_4e6a_b0cb_32081b574205.slice/cri-containerd-3437f583a8d452fad40c5255414221949399a410c4b3723275ad109e5ae96f82.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod374bc1e3_fea9_4e6a_b0cb_32081b574205.slice/cri-containerd-6e728be0273ff3502f608c97bb2fc84966bb3d9d5505551c921d2dfab5c2bc55.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07058472_6a2e_4538_b03a_b1748b038e93.slice/cri-containerd-c4f91f71021645ea8cf6aa0bfd1425a564caca10f003480ff333b293292c4ff3.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07058472_6a2e_4538_b03a_b1748b038e93.slice/cri-containerd-4e0eeb6f38aa1477659cab52ce47c5548da2345997e7e9c3c5cd078d7a3b43a6.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2711fb24_b4d4_4ca6_bfc9_f224df172ce1.slice/cri-containerd-5d932c8ac8d7366ef6c65d3920def36e460b5dd64319374162f2e69378ed508f.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2711fb24_b4d4_4ca6_bfc9_f224df172ce1.slice/cri-containerd-8b3893e91da2f8f7ef2a9479111f06661c59933af6966ae679bed73041c10cc6.scope
    708      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode259b5ca_7c6b_4fe3_a763_7ec7aa31abb8.slice/cri-containerd-b978185b7d09411f0e4756fd90517095755d335d2d1b90a6b88e93437fcba3c4.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode259b5ca_7c6b_4fe3_a763_7ec7aa31abb8.slice/cri-containerd-072ac4b686d6286de6458726d18b87d85bea7e7fb55fbe9799294a49f3df4e37.scope
    98       cgroup_device   multi                                          
