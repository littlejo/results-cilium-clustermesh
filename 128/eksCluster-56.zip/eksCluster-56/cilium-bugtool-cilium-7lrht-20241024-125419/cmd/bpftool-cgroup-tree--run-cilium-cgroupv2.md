CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbaaf44f5_f75d_4bc3_bd9e_4acd1e6cc3c2.slice/cri-containerd-a898386638f48d165e42d6c50b606ec67f7d02530dba1010a442e416c9659440.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbaaf44f5_f75d_4bc3_bd9e_4acd1e6cc3c2.slice/cri-containerd-5fa2050319e4669587d7339100e182aabefacc67fa6566602b1b28bdd81a76e4.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6b871993_ecbf_4e27_88d7_39cfaa573970.slice/cri-containerd-999d4c4f94bf4bf1f1038465956cf7220c787a14047cf2c1a37b72a1e6edb730.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6b871993_ecbf_4e27_88d7_39cfaa573970.slice/cri-containerd-416f16bc6fd9d3889bf81b2605a7ffc6bea0ef262542b46008dc3b8e3d26262a.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b6418bd_0c22_4e02_93f1_42a8ad779aac.slice/cri-containerd-af75e028963c05072de8f3fb252078ade11d47bf2d1811b736f1d2d730102450.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b6418bd_0c22_4e02_93f1_42a8ad779aac.slice/cri-containerd-f2c64fb4e45de67a102419a57177cc7765eb6ee2e1b2d5767af4cf284726dd38.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c497d95_e8c9_46e6_b122_cd1d01332d4c.slice/cri-containerd-d066cd8d72640f1b55f1f06e44b9e7a8a08f5ad47aa2e847c49a8af09ae4db84.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c497d95_e8c9_46e6_b122_cd1d01332d4c.slice/cri-containerd-a0e9b88c1456762bb3b04a73ae02aa4befb1fd44e4f3a8f3bdb8214dd79c96ab.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c331a2b_a09e_45c8_b500_a00e3190b018.slice/cri-containerd-e313dc029cec17b75a0d6c0977e3fed78a0daf117e9fc1da1c1573a84bb725c7.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c331a2b_a09e_45c8_b500_a00e3190b018.slice/cri-containerd-c968639c85fbc52a0173823a341e1661e261fec5053720ef4979febaa5106972.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c331a2b_a09e_45c8_b500_a00e3190b018.slice/cri-containerd-6de5cd40320acec35e362784407ad7e1ae4b4a718ec706cb1749afeb0af829ca.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c331a2b_a09e_45c8_b500_a00e3190b018.slice/cri-containerd-a70fcaf31326712afa2ee8068a52dcc75cfcf8bd09f559124dd653d31fa12f08.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c03f224_8520_4f12_8f7d_6feabd703138.slice/cri-containerd-ac56e6799ca1002f8425e53c7dec6e1d0c437dfc5958db1ab0cb2238cfbd16f3.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c03f224_8520_4f12_8f7d_6feabd703138.slice/cri-containerd-1181effdd59ace5dd56168a522fe8060ef744b63266a4d35774b462d9ef9d194.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2efce4e0_79bf_46b6_a8e2_705eb80bc18f.slice/cri-containerd-ca0479e3eb77df20a21aa7d3989787c01005c88945e85823dafaf0f8dac7c80f.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2efce4e0_79bf_46b6_a8e2_705eb80bc18f.slice/cri-containerd-c0e05aca20dbe48c5beafeaa1ac7f9fa350fe5415551d9eb9ff4c8bee33a260b.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod316898f1_aeee_4c3c_ad99_eb3346269676.slice/cri-containerd-7e36cd785664934f3a2112f8c9b4b35c3bea923c1c5f630d1b56ce46e2b95995.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod316898f1_aeee_4c3c_ad99_eb3346269676.slice/cri-containerd-45f83f96067ad6b9ae19ffa49608c91b7e85d17849f048aeea103ac2430515f8.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7f13ecbf_f1c8_4a7e_9779_9ed8a63b4b8b.slice/cri-containerd-fe9546857e5538e01fc00191b993e000cda078ec0644cdef949023c78319fac8.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7f13ecbf_f1c8_4a7e_9779_9ed8a63b4b8b.slice/cri-containerd-9f4eb1abb03ac88616f1ab9a7c876ac6a1e398050aeefdf5b58d7491426f0164.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38ffc62b_6ea5_4a34_9cd9_aa2b75b6ede3.slice/cri-containerd-96c7c82ea1107165fe347754c3ad2880c315c8f39da31c70b37fdb433b01c163.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38ffc62b_6ea5_4a34_9cd9_aa2b75b6ede3.slice/cri-containerd-618203022bab63a910f2d6156d29e33216221ea2918665a0f0bbe11b9a85fa28.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38ffc62b_6ea5_4a34_9cd9_aa2b75b6ede3.slice/cri-containerd-8c039f307ff8ea26423a95505283577f1966c332423225a886fa18faefa4e543.scope
    698      cgroup_device   multi                                          
