USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3197  0.0  0.3 1240432 15596 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3215  0.0  0.0   1748     4 ?        R    12:54   0:00  \_ bash -c cat /proc/net/xfrm_stat
root        3216  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3191  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.1  7.3 1538804 290652 ?      Ssl  12:28   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.2  0.2 1229744 10012 ?       Sl   12:28   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
