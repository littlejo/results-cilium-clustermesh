Endpoint ID: 671
Path: /sys/fs/bpf/tc/globals/cilium_policy_00671

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    351552   4109      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 940
Path: /sys/fs/bpf/tc/globals/cilium_policy_00940

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    219496   1979      0        
Allow    Ingress     1          ANY          NONE         disabled    148100   1701      0        
Allow    Egress      0          ANY          NONE         disabled    65709    651       0        


Endpoint ID: 1125
Path: /sys/fs/bpf/tc/globals/cilium_policy_01125

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    228920   2069      0        
Allow    Ingress     1          ANY          NONE         disabled    148496   1707      0        
Allow    Egress      0          ANY          NONE         disabled    66441    656       0        


Endpoint ID: 1216
Path: /sys/fs/bpf/tc/globals/cilium_policy_01216

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1929
Path: /sys/fs/bpf/tc/globals/cilium_policy_01929

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2103
Path: /sys/fs/bpf/tc/globals/cilium_policy_02103

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6196374   76571     0        
Allow    Ingress     1          ANY          NONE         disabled    61374     735       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2141
Path: /sys/fs/bpf/tc/globals/cilium_policy_02141

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5462158   55998     0        
Allow    Ingress     1          ANY          NONE         disabled    4877468   51047     0        
Allow    Egress      0          ANY          NONE         disabled    5334258   55295     0        


Endpoint ID: 2567
Path: /sys/fs/bpf/tc/globals/cilium_policy_02567

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


