1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3f:fe:c0:4a:8d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.140.56/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3453sec preferred_lft 3453sec
    inet6 fe80::43f:feff:fec0:4a8d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c5:1c:e7:86:8b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.165.63/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4c5:1cff:fee7:868b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:27:42:37:db:9a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9027:42ff:fe37:db9a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:a0:ca:eb:0a:18 brd ff:ff:ff:ff:ff:ff
    inet 10.56.0.114/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::30a0:caff:feeb:a18/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5e:fb:f9:23:b2:b7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5cfb:f9ff:fe23:b2b7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:c9:81:66:9b:a1 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::78c9:81ff:fe66:9ba1/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf99868b35f56@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:9f:bd:80:f2:0f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d09f:bdff:fe80:f20f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5df766119889@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:d7:fe:7f:4e:fd brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::8cd7:feff:fe7f:4efd/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc41ce9629617e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:1a:96:85:51:05 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::701a:96ff:fe85:5105/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcca38fa78d8a9@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:60:85:31:01:bc brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::e860:85ff:fe31:1bc/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc2b09d873a8bf@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:41:63:3d:ac:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::1841:63ff:fe3d:acc6/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc621df824794a@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:7a:20:28:86:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::87a:20ff:fe28:86b6/64 scope link 
       valid_lft forever preferred_lft forever
