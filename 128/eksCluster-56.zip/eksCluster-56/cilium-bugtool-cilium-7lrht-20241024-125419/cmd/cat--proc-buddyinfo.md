Node 0, zone      DMA     15      3      2      2      1      2      5      2      0      2     50 
Node 0, zone   Normal    251     91     19     20     18      7      1      2      4      4      6 
