top - 12:54:21 up 32 min,  0 users,  load average: 0.74, 0.53, 0.29
Tasks:   7 total,   3 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.0 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 10.0 si,  0.0 st
MiB Mem :   3836.2 total,    290.2 free,   1050.6 used,   2495.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2604.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 294348  78368 S  20.0   7.5   1:04.13 cilium-+
   3197 root      20   0 1240432  16516  11420 S   6.7   0.4   0:00.03 cilium-+
    415 root      20   0 1229744  10012   3900 S   0.0   0.3   0:04.27 cilium-+
   3227 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3256 root      20   0 1228488   1756   1456 S   0.0   0.0   0:00.00 gops
   3262 root      20   0 1484936   8032   5920 R   0.0   0.2   0:00.00 runc:[2+
   3268 root      20   0    3452   2108   1856 R   0.0   0.1   0:00.00 ip6tabl+
