key: 9f 02 00 00  value: d0 0c 00 00
key: ac 03 00 00  value: 22 02 00 00
key: 65 04 00 00  value: 10 02 00 00
key: c0 04 00 00  value: 04 0d 00 00
key: 89 07 00 00  value: f1 0c 00 00
key: 37 08 00 00  value: 2b 02 00 00
key: 5d 08 00 00  value: 67 02 00 00
Found 7 elements
