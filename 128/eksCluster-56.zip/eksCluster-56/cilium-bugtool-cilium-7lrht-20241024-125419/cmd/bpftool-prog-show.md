35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:51+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name tail_handle_ipv4  tag 61f00531e09b3510  gpl
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
487: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:28:31+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
489: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 130
491: sched_cls  name __send_drop_notify  tag 8b343425c5d9c534  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 132
492: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,101
	btf_id 133
493: sched_cls  name tail_handle_ipv4_from_host  tag dc88c81f8caad1bc  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 134
494: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 135
495: sched_cls  name __send_drop_notify  tag 8b343425c5d9c534  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 137
497: sched_cls  name tail_handle_ipv4_from_host  tag dc88c81f8caad1bc  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 139
498: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 140
500: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 142
502: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 145
505: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 148
506: sched_cls  name __send_drop_notify  tag 8b343425c5d9c534  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 149
508: sched_cls  name tail_handle_ipv4_from_host  tag dc88c81f8caad1bc  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 151
511: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 155
512: sched_cls  name __send_drop_notify  tag 8b343425c5d9c534  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 156
514: sched_cls  name tail_handle_ipv4_from_host  tag dc88c81f8caad1bc  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 158
515: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 159
517: sched_cls  name tail_ipv4_to_endpoint  tag 31941a95f4211f45  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 163
524: sched_cls  name tail_ipv4_ct_ingress  tag b0eca660628d4026  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 169
525: sched_cls  name tail_handle_ipv4_cont  tag bc5c5326099a11a0  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 172
528: sched_cls  name handle_policy  tag e21afc3869d96900  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 173
529: sched_cls  name tail_handle_arp  tag a62d88a45a29fdaf  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 176
532: sched_cls  name tail_ipv4_ct_egress  tag fb8e51badb2e073d  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 177
534: sched_cls  name tail_handle_ipv4  tag 9289c49303c9a5d2  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 180
535: sched_cls  name __send_drop_notify  tag e19faa92f849c292  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 183
536: sched_cls  name cil_from_container  tag 0e1cd8e6e2b9576b  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 184
537: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 185
538: sched_cls  name tail_handle_ipv4  tag c2f0eca02c7c863c  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 182
539: sched_cls  name __send_drop_notify  tag 48f2294a18f85ce3  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
540: sched_cls  name cil_from_container  tag e525772cb43dd39d  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 188
541: sched_cls  name tail_handle_ipv4_cont  tag 1352fe931be4846a  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 190
542: sched_cls  name tail_ipv4_ct_ingress  tag cf1ed1564bf864c5  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 189
543: sched_cls  name tail_handle_ipv4_cont  tag 2e7633b25d929c83  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,117,40,37,38,81
	btf_id 191
544: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 193
546: sched_cls  name handle_policy  tag 14621fac9cee8c14  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 192
547: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 196
548: sched_cls  name tail_handle_ipv4  tag a55696bfb3bd52e1  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 195
549: sched_cls  name cil_from_container  tag e49ae62afbdcc067  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 197
550: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 198
551: sched_cls  name tail_ipv4_ct_ingress  tag 7991e2e8bff79cde  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 199
552: sched_cls  name tail_ipv4_to_endpoint  tag f0fe80c3008dd638  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 201
553: sched_cls  name __send_drop_notify  tag f9c9ece2f6d66780  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
554: sched_cls  name tail_handle_arp  tag c80c65f479f1c4de  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 203
555: sched_cls  name handle_policy  tag c2359235bcdefe3f  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 200
556: sched_cls  name tail_ipv4_ct_egress  tag fb8e51badb2e073d  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 204
558: sched_cls  name tail_ipv4_to_endpoint  tag 35d29ace436db1d4  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,117,40,37,38
	btf_id 205
559: sched_cls  name tail_handle_arp  tag b7d1d4b8599d7c89  gpl
	loaded_at 2024-10-24T12:28:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 207
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
567: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
575: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
615: sched_cls  name handle_policy  tag a261c40342ee426e  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 221
616: sched_cls  name tail_ipv4_ct_ingress  tag 448b92aad88c98a3  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 222
617: sched_cls  name tail_handle_ipv4  tag feb06a3088f93e79  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 223
618: sched_cls  name tail_ipv4_to_endpoint  tag 6b620c530571b9eb  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 224
619: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 225
620: sched_cls  name __send_drop_notify  tag 6a1704eb0efbe8c9  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 226
621: sched_cls  name tail_handle_ipv4_cont  tag 7b3d0a071b9b7e1b  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 227
622: sched_cls  name cil_from_container  tag 01d672c8116458d8  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 228
624: sched_cls  name tail_handle_arp  tag 460953f49203d578  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 230
625: sched_cls  name tail_ipv4_ct_egress  tag e22855b87fdf922d  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 231
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
665: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
668: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
691: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
694: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
695: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
698: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
700: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
703: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3273: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,625
	btf_id 3060
3274: sched_cls  name tail_ipv4_ct_egress  tag e3ffefc8c332d149  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,625,82,83,626,84
	btf_id 3061
3275: sched_cls  name __send_drop_notify  tag 7654ec0d83fc46e3  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3063
3276: sched_cls  name tail_handle_ipv4_cont  tag 15befb3674ea2c32  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,626,41,150,82,83,39,76,74,77,625,40,37,38,81
	btf_id 3064
3280: sched_cls  name handle_policy  tag 04f92bee5b3bc1b2  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,625,82,83,626,41,80,150,39,84,75,40,37,38
	btf_id 3065
3281: sched_cls  name tail_handle_arp  tag c460f9d41de1517d  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,625
	btf_id 3069
3283: sched_cls  name tail_handle_ipv4  tag e22f350cc59f4c45  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,625
	btf_id 3071
3284: sched_cls  name cil_from_container  tag a0dced208c97063f  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 625,76
	btf_id 3072
3285: sched_cls  name tail_ipv4_ct_ingress  tag ce0bb675321322c9  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,625,82,83,626,84
	btf_id 3073
3288: sched_cls  name tail_ipv4_to_endpoint  tag be28b28ab5ffd889  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,626,41,82,83,80,150,39,625,40,37,38
	btf_id 3074
3312: sched_cls  name tail_ipv4_to_endpoint  tag b6adb1f4503a47f6  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,633,41,82,83,80,143,39,634,40,37,38
	btf_id 3103
3313: sched_cls  name handle_policy  tag b1ca32a5dc83d961  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,632,82,83,631,41,80,147,39,84,75,40,37,38
	btf_id 3104
3314: sched_cls  name tail_ipv4_ct_egress  tag 6b8e81754c7deb95  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3105
3315: sched_cls  name cil_from_container  tag b596ec016693aeb1  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,76
	btf_id 3107
3316: sched_cls  name tail_handle_arp  tag 40faf69529ef9e9c  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,634
	btf_id 3108
3317: sched_cls  name tail_ipv4_ct_ingress  tag d502236084b5c444  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3106
3318: sched_cls  name __send_drop_notify  tag 2e131032279cbf69  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3110
3319: sched_cls  name tail_ipv4_ct_ingress  tag 67ebc9ee7cc1db40  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3109
3320: sched_cls  name tail_ipv4_ct_egress  tag f3e40b754b55585d  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3111
3321: sched_cls  name tail_handle_ipv4_cont  tag 15bebfb97bd1a5a5  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,633,41,143,82,83,39,76,74,77,634,40,37,38,81
	btf_id 3112
3322: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,632
	btf_id 3113
3323: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,634
	btf_id 3114
3324: sched_cls  name __send_drop_notify  tag 417933ff41b5408f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3115
3326: sched_cls  name tail_handle_arp  tag 9594f9fa9ae4ab05  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,632
	btf_id 3117
3327: sched_cls  name tail_ipv4_to_endpoint  tag fae323a664681407  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,631,41,82,83,80,147,39,632,40,37,38
	btf_id 3119
3328: sched_cls  name tail_handle_ipv4  tag 9d938e85b0799806  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,634
	btf_id 3118
3329: sched_cls  name tail_handle_ipv4  tag 8ce1715a9c81c901  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,632
	btf_id 3120
3330: sched_cls  name tail_handle_ipv4_cont  tag fa1e1acf01fcca6f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,631,41,147,82,83,39,76,74,77,632,40,37,38,81
	btf_id 3121
3331: sched_cls  name cil_from_container  tag bfa81ba0884b82c4  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 632,76
	btf_id 3122
3332: sched_cls  name handle_policy  tag 11b2f6fd206c8a22  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,634,82,83,633,41,80,143,39,84,75,40,37,38
	btf_id 3123
