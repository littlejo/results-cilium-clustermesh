alloc: 86.45MB (90648008 bytes)
total-alloc: 3.04GB (3259309384 bytes)
sys: 219.07MB (229713236 bytes)
lookups: 0
mallocs: 74436677
frees: 73724320
heap-alloc: 86.45MB (90648008 bytes)
heap-sys: 172.72MB (181108736 bytes)
heap-idle: 45.05MB (47243264 bytes)
heap-in-use: 127.66MB (133865472 bytes)
heap-released: 4.29MB (4497408 bytes)
heap-objects: 712357
stack-in-use: 35.28MB (36995072 bytes)
stack-sys: 35.28MB (36995072 bytes)
stack-mspan-inuse: 2.05MB (2150880 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 700.89KB (717713 bytes)
gc-sys: 5.48MB (5743736 bytes)
next-gc: when heap-alloc >= 148.07MB (155267064 bytes)
last-gc: 2024-10-24 12:54:05.861346584 +0000 UTC
gc-pause-total: 11.672469ms
gc-pause: 79567
gc-pause-end: 1729774445861346584
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005524361051982952
enable-gc: true
debug-gc: false
