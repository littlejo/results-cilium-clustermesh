[
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38ffc62b_6ea5_4a34_9cd9_aa2b75b6ede3.slice/cri-containerd-96c7c82ea1107165fe347754c3ad2880c315c8f39da31c70b37fdb433b01c163.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38ffc62b_6ea5_4a34_9cd9_aa2b75b6ede3.slice/cri-containerd-618203022bab63a910f2d6156d29e33216221ea2918665a0f0bbe11b9a85fa28.scope"
      }
    ],
    "ips": [
      "10.56.0.10"
    ],
    "name": "echo-same-node-86d9cc975c-4zhsj",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c497d95_e8c9_46e6_b122_cd1d01332d4c.slice/cri-containerd-a0e9b88c1456762bb3b04a73ae02aa4befb1fd44e4f3a8f3bdb8214dd79c96ab.scope"
      }
    ],
    "ips": [
      "10.56.0.217"
    ],
    "name": "coredns-cc6ccd49c-jrl94",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbaaf44f5_f75d_4bc3_bd9e_4acd1e6cc3c2.slice/cri-containerd-5fa2050319e4669587d7339100e182aabefacc67fa6566602b1b28bdd81a76e4.scope"
      }
    ],
    "ips": [
      "10.56.0.224"
    ],
    "name": "coredns-cc6ccd49c-pq8j5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod316898f1_aeee_4c3c_ad99_eb3346269676.slice/cri-containerd-45f83f96067ad6b9ae19ffa49608c91b7e85d17849f048aeea103ac2430515f8.scope"
      }
    ],
    "ips": [
      "10.56.0.157"
    ],
    "name": "client-974f6c69d-7x7cz",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2efce4e0_79bf_46b6_a8e2_705eb80bc18f.slice/cri-containerd-ca0479e3eb77df20a21aa7d3989787c01005c88945e85823dafaf0f8dac7c80f.scope"
      }
    ],
    "ips": [
      "10.56.0.21"
    ],
    "name": "client2-57cf4468f-z7cdl",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c331a2b_a09e_45c8_b500_a00e3190b018.slice/cri-containerd-a70fcaf31326712afa2ee8068a52dcc75cfcf8bd09f559124dd653d31fa12f08.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c331a2b_a09e_45c8_b500_a00e3190b018.slice/cri-containerd-c968639c85fbc52a0173823a341e1661e261fec5053720ef4979febaa5106972.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c331a2b_a09e_45c8_b500_a00e3190b018.slice/cri-containerd-e313dc029cec17b75a0d6c0977e3fed78a0daf117e9fc1da1c1573a84bb725c7.scope"
      }
    ],
    "ips": [
      "10.56.0.184"
    ],
    "name": "clustermesh-apiserver-7c54b86b59-2mrvz",
    "namespace": "kube-system"
  }
]

