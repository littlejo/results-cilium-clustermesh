IP ADDRESS        LOCAL ENDPOINT INFO
172.31.165.63:0   (localhost)                                                                                        
10.56.0.10:0      id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6   
10.56.0.224:0     id=940   sec_id=3741607 flags=0x0000 ifindex=14  mac=56:2F:F2:90:34:49 nodemac=8E:D7:FE:7F:4E:FD   
10.56.0.114:0     (localhost)                                                                                        
10.56.0.21:0      id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6   
10.56.0.184:0     id=2141  sec_id=3757139 flags=0x0000 ifindex=18  mac=FE:5B:54:9B:89:55 nodemac=72:1A:96:85:51:05   
172.31.140.56:0   (localhost)                                                                                        
10.56.0.157:0     id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC   
10.56.0.158:0     id=2103  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FD:B7:24:F4:06 nodemac=7A:C9:81:66:9B:A1     
10.56.0.217:0     id=1125  sec_id=3741607 flags=0x0000 ifindex=12  mac=CA:BC:CB:7D:28:A4 nodemac=D2:9F:BD:80:F2:0F   
