{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.644Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.644Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.648Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.188Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.191Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.239Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.253Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.276Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.487Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.508Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.558Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.573Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.616Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.259Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.259Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.299Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.327Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.337Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.571Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.594Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.638Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.644Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.739Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.268Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.276Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.305Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.322Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.373Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.397Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.408Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.634Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.658Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.712Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.727Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.765Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.295Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.340Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.384Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.424Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.429Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.679Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.685Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.737Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.770Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.856Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.254Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.260Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.312Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.334Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.355Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.598Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.616Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.669Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.680Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.710Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.096Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.137Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.145Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.183Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.209Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.231Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.459Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.485Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.514Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.543Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.570Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.964Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.052Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.093Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.126Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.168Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.180Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.373Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.402Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.423Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.467Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.472Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.855Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.872Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.905Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.924Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.951Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.194Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.203Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.253Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.273Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.291Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.675Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.710Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.719Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.762Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.777Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.826Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.087Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.092Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.142Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.181Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.184Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.509Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.530Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.548Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.580Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.597Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.853Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.855Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.901Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.914Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.956Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.283Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.311Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.344Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.361Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.362Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.386Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.640Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.651Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.683Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.690Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.729Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.364Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.366Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.420Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.455Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.460Z",
  "value": "id=671   sec_id=3764218 flags=0x0000 ifindex=24  mac=A2:C7:28:E3:A7:8D nodemac=0A:7A:20:28:86:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.766Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.770Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.438Z",
  "value": "id=1929  sec_id=3765653 flags=0x0000 ifindex=22  mac=B2:04:77:56:1E:47 nodemac=1A:41:63:3D:AC:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.450Z",
  "value": "id=1216  sec_id=3742167 flags=0x0000 ifindex=20  mac=6A:5D:EB:3B:D5:F2 nodemac=EA:60:85:31:01:BC"
}

