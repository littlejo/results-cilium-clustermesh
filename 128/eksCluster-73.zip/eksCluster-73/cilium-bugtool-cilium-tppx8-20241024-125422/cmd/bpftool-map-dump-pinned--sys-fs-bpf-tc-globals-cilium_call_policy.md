key: 78 00 00 00  value: 10 02 00 00
key: da 00 00 00  value: 1e 02 00 00
key: 78 01 00 00  value: be 0c 00 00
key: 84 09 00 00  value: 87 02 00 00
key: 43 0b 00 00  value: 48 02 00 00
key: 32 0c 00 00  value: 04 0d 00 00
key: 65 0e 00 00  value: 00 0d 00 00
Found 7 elements
