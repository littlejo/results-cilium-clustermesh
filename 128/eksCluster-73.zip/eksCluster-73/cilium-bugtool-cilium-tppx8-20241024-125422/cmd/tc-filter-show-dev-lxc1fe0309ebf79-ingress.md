filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc1fe0309ebf79 direct-action not_in_hw id 3272 tag f95cabc2e85528b1 jited 
