{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:39.256Z",
  "value": "ANY://172.31.165.109"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:39.256Z",
  "value": "ANY://172.31.211.83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:39.256Z",
  "value": "ANY://172.31.199.174"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:39.256Z",
  "value": "ANY://172.31.199.174"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:42.791Z",
  "value": "ANY://172.31.193.203"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:44.537Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:44.537Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:47.103Z",
  "value": "ANY://10.73.0.211"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:47.103Z",
  "value": "ANY://10.73.0.211"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:47.132Z",
  "value": "ANY://10.73.0.183"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:29:47.132Z",
  "value": "ANY://10.73.0.183"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:37:27.930Z",
  "value": "ANY://10.73.0.62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "11",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:38.888Z",
  "value": "ANY://10.73.0.215"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:38.982Z",
  "value": "ANY://10.73.0.62"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:39.537Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "12",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:35.172Z",
  "value": "ANY://10.73.0.114"
}

