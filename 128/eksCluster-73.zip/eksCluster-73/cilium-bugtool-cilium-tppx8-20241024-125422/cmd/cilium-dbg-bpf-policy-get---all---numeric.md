Endpoint ID: 107
Path: /sys/fs/bpf/tc/globals/cilium_policy_00107

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 120
Path: /sys/fs/bpf/tc/globals/cilium_policy_00120

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2528     27        0        
Allow    Ingress     1          ANY          NONE         disabled    142210   1626      0        
Allow    Egress      0          ANY          NONE         disabled    19047    210       0        


Endpoint ID: 218
Path: /sys/fs/bpf/tc/globals/cilium_policy_00218

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3368     33        0        
Allow    Ingress     1          ANY          NONE         disabled    142474   1630      0        
Allow    Egress      0          ANY          NONE         disabled    20022    222       0        


Endpoint ID: 376
Path: /sys/fs/bpf/tc/globals/cilium_policy_00376

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    380483   4436      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2436
Path: /sys/fs/bpf/tc/globals/cilium_policy_02436

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6130194   61825     0        
Allow    Ingress     1          ANY          NONE         disabled    6095205   62947     0        
Allow    Egress      0          ANY          NONE         disabled    7166867   70495     0        


Endpoint ID: 2883
Path: /sys/fs/bpf/tc/globals/cilium_policy_02883

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6221072   77188     0        
Allow    Ingress     1          ANY          NONE         disabled    62858     761       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3122
Path: /sys/fs/bpf/tc/globals/cilium_policy_03122

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3685
Path: /sys/fs/bpf/tc/globals/cilium_policy_03685

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


