Total: 601
TCP:   3079 (estab 324, closed 2736, orphaned 0, timewait 2265)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  343       330       13       
INET	  353       336       17       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:44181      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:31528 sk:a24 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.193.203%ens5:68         0.0.0.0:*    uid:192 ino:118643 sk:a25 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31571 sk:a26 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15744 sk:a27 cgroup:unreachable:e8e <->                                    
UNCONN 0      0      [fe80::87e:48ff:fe3e:5a61]%ens5:546           [::]:*    uid:192 ino:15975 sk:a28 cgroup:unreachable:bd0 v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31570 sk:a29 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15745 sk:a2a cgroup:unreachable:e8e v6only:1 <->                           
