{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.799Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.293Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.344Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.356Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.391Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.392Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.431Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.649Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.664Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.725Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.730Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.782Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.377Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.394Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.441Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.444Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.494Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.755Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.774Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.810Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.838Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.870Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.415Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.454Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.472Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.502Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.524Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.550Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.791Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.794Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.841Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.911Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.921Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.466Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.473Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.514Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.530Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.566Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.764Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.774Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.927Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.928Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.962Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.318Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.326Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.369Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.371Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.405Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.658Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.666Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.716Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.724Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.756Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.168Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.197Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.213Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.264Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.265Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.266Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.493Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.534Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.556Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.603Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.614Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.017Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.094Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.096Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.097Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.164Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.182Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.415Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.418Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.477Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.477Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.524Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.886Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.926Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.929Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.976Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.981Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.014Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.214Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.216Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.272Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.311Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.316Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.664Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.705Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.721Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.751Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.770Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.787Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.027Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.032Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.108Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.178Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.210Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.454Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.483Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.494Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.530Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.531Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.552Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.800Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.815Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.853Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.864Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.902Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.198Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.226Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.246Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.290Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.290Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.301Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.548Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.554Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.561Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.567Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.590Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.280Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.283Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.315Z",
  "value": "id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.330Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.356Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.681Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.686Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.370Z",
  "value": "id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:35.379Z",
  "value": "id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3"
}

