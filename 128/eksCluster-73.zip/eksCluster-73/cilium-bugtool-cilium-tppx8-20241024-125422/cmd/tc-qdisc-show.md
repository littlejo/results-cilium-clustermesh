qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxcda02478d0b24 root refcnt 2 
qdisc clsact ffff: dev lxcda02478d0b24 parent ffff:fff1 
qdisc noqueue 0: dev lxc2ccc6dc8f91c root refcnt 2 
qdisc clsact ffff: dev lxc2ccc6dc8f91c parent ffff:fff1 
qdisc noqueue 0: dev lxcbcf0e207b39a root refcnt 2 
qdisc clsact ffff: dev lxcbcf0e207b39a parent ffff:fff1 
qdisc noqueue 0: dev lxc6917ca261a5f root refcnt 2 
qdisc clsact ffff: dev lxc6917ca261a5f parent ffff:fff1 
qdisc noqueue 0: dev lxc001c2f3e1e22 root refcnt 2 
qdisc clsact ffff: dev lxc001c2f3e1e22 parent ffff:fff1 
qdisc noqueue 0: dev lxc1fe0309ebf79 root refcnt 2 
qdisc clsact ffff: dev lxc1fe0309ebf79 parent ffff:fff1 
