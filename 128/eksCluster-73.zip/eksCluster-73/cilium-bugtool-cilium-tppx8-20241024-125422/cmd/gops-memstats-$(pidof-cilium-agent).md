alloc: 100.42MB (105295616 bytes)
total-alloc: 3.20GB (3436439760 bytes)
sys: 231.64MB (242894164 bytes)
lookups: 0
mallocs: 76839665
frees: 76045666
heap-alloc: 100.42MB (105295616 bytes)
heap-sys: 183.39MB (192299008 bytes)
heap-idle: 41.03MB (43024384 bytes)
heap-in-use: 142.36MB (149274624 bytes)
heap-released: 9.15MB (9592832 bytes)
heap-objects: 793999
stack-in-use: 36.56MB (38338560 bytes)
stack-sys: 36.56MB (38338560 bytes)
stack-mspan-inuse: 2.24MB (2349600 bytes)
stack-mspan-sys: 2.88MB (3019200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.18MB (1236209 bytes)
gc-sys: 5.52MB (5786672 bytes)
next-gc: when heap-alloc >= 152.01MB (159395496 bytes)
last-gc: 2024-10-24 12:54:41.896562312 +0000 UTC
gc-pause-total: 9.453791ms
gc-pause: 69934
gc-pause-end: 1729774481896562312
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006302982274888589
enable-gc: true
debug-gc: false
