[
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f9be0ef_faa3_4b65_a384_fb599ecda94c.slice/cri-containerd-0f13135f875e0577490438aefee5245caf2cad53c859f635bf641f10d88b8a13.scope"
      }
    ],
    "ips": [
      "10.73.0.211"
    ],
    "name": "coredns-cc6ccd49c-z4qsb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb7e5e28_5e0a_40ab_9f61_a229250b87a0.slice/cri-containerd-87c5d192aca1271ab1f9128229c80d01c7e5ad47c8b8541ddb03bfc0f283699b.scope"
      }
    ],
    "ips": [
      "10.73.0.183"
    ],
    "name": "coredns-cc6ccd49c-tk9mg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23c48f24_ce40_4c85_81a0_479feb396053.slice/cri-containerd-7de042e595de1cf3a3c138cf64175eefabd925ebb1026bdf6388c718a1efa1e8.scope"
      }
    ],
    "ips": [
      "10.73.0.49"
    ],
    "name": "client2-57cf4468f-p9fq8",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83be0f47_9d0a_4b0b_8054_ee0708dfb909.slice/cri-containerd-3ad45a0678fc92f3b199955abd81e634f8ee6b2968adcde504e15f75910a23e0.scope"
      }
    ],
    "ips": [
      "10.73.0.86"
    ],
    "name": "client-974f6c69d-bhfqh",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5ddba67_0e3f_4b5b_a7cb_75570974cabc.slice/cri-containerd-c2c63dd2873a1bf66d8ed4d09db6e1ddf0856e3a5f53e0f7060d5cca6e8568da.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5ddba67_0e3f_4b5b_a7cb_75570974cabc.slice/cri-containerd-53065d1f583393da457d7f7159e55fe344bb457bd7f09588d02e95afd9d1bac8.scope"
      }
    ],
    "ips": [
      "10.73.0.114"
    ],
    "name": "echo-same-node-86d9cc975c-2llhc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab1b437_74d1_4f3c_9d59_08730c86cb6d.slice/cri-containerd-cd7f31a830704a42c5cc99a64012dff075ebabf2a1a643256d68081c0958b783.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab1b437_74d1_4f3c_9d59_08730c86cb6d.slice/cri-containerd-954f736f81bf15bec3143e6d9578a548a848a6f8c164d01c6f10547948845e53.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab1b437_74d1_4f3c_9d59_08730c86cb6d.slice/cri-containerd-b8193ae3f219749dec61708b9d25075155e08cf9be870f7f2d946e30d0f3a8d7.scope"
      }
    ],
    "ips": [
      "10.73.0.215"
    ],
    "name": "clustermesh-apiserver-6cc76c4dc8-55snk",
    "namespace": "kube-system"
  }
]

