filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc001c2f3e1e22 direct-action not_in_hw id 3314 tag afefccb50c840b2f jited 
