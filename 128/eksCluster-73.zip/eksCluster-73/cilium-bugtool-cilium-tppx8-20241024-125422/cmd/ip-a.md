1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:7e:48:3e:5a:61 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.193.203/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3476sec preferred_lft 3476sec
    inet6 fe80::87e:48ff:fe3e:5a61/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:12:07:74:e4:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.242.63/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::812:7ff:fe74:e475/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:59:95:8f:ca:6b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3459:95ff:fe8f:ca6b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:b2:b5:fb:df:7e brd ff:ff:ff:ff:ff:ff
    inet 10.73.0.20/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::98b2:b5ff:fefb:df7e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b2:46:15:c8:51:62 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b046:15ff:fec8:5162/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:14:4e:ba:3d:30 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6c14:4eff:feba:3d30/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcda02478d0b24@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:18:c7:aa:9b:1e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b418:c7ff:feaa:9b1e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc2ccc6dc8f91c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:d4:0a:9a:79:bd brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::e0d4:aff:fe9a:79bd/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcbcf0e207b39a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:cf:8c:74:bb:ce brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::68cf:8cff:fe74:bbce/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc6917ca261a5f@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:09:5c:36:3a:24 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3409:5cff:fe36:3a24/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc001c2f3e1e22@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:55:32:03:e5:e3 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::1055:32ff:fe03:e5e3/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc1fe0309ebf79@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:4f:eb:1a:9f:79 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::4c4f:ebff:fe1a:9f79/64 scope link 
       valid_lft forever preferred_lft forever
