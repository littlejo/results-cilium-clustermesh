IP ADDRESS         LOCAL ENDPOINT INFO
172.31.242.63:0    (localhost)                                                                                        
10.73.0.215:0      id=2436  sec_id=4864458 flags=0x0000 ifindex=18  mac=8A:6F:5A:61:D8:C5 nodemac=6A:CF:8C:74:BB:CE   
10.73.0.86:0       id=3122  sec_id=4856095 flags=0x0000 ifindex=22  mac=C2:14:1E:F7:8B:3E nodemac=12:55:32:03:E5:E3   
10.73.0.6:0        id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=5E:12:F1:2D:7E:15 nodemac=6E:14:4E:BA:3D:30     
10.73.0.49:0       id=3685  sec_id=4865964 flags=0x0000 ifindex=20  mac=FE:6B:4E:FD:AF:22 nodemac=36:09:5C:36:3A:24   
10.73.0.20:0       (localhost)                                                                                        
10.73.0.114:0      id=376   sec_id=4865196 flags=0x0000 ifindex=24  mac=62:42:86:06:BA:2E nodemac=4E:4F:EB:1A:9F:79   
172.31.193.203:0   (localhost)                                                                                        
10.73.0.211:0      id=120   sec_id=4859017 flags=0x0000 ifindex=12  mac=B6:DE:67:9B:AB:56 nodemac=B6:18:C7:AA:9B:1E   
10.73.0.183:0      id=218   sec_id=4859017 flags=0x0000 ifindex=14  mac=6E:19:E0:3D:51:03 nodemac=E2:D4:0A:9A:79:BD   
