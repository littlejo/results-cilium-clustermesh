KEY             VALUE
AgentLiveness   1964142737093
UTimeOffset     3378461974609375
