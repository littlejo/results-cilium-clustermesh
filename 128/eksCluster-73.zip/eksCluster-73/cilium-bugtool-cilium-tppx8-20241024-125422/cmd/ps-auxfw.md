USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3219  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3218  0.0  0.4 1240176 16716 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3243  0.0  0.0   6408  1632 ?        R    12:54   0:00  \_ ps auxfw
root        3244  0.0  0.0   3852  1292 ?        R    12:54   0:00  \_ bash -c hostname
root        3204  0.0  0.0 1228744 3780 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3198  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3184  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3178  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.3  7.5 1539388 295980 ?      Ssl  12:29   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 9956 ?        Sl   12:29   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
