Node 0, zone      DMA    252     28     40     43     21      9      5      6      3      2     39 
Node 0, zone   Normal    379     47     30     17     15     10      2      1      2      1      8 
