filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6917ca261a5f direct-action not_in_hw id 3330 tag 2fb3a875b9e39256 jited 
