CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f9be0ef_faa3_4b65_a384_fb599ecda94c.slice/cri-containerd-4909a59da42297f72b00ca166fd22c82c242ebb75898dd35624df8d1502c0b18.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f9be0ef_faa3_4b65_a384_fb599ecda94c.slice/cri-containerd-0f13135f875e0577490438aefee5245caf2cad53c859f635bf641f10d88b8a13.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb7e5e28_5e0a_40ab_9f61_a229250b87a0.slice/cri-containerd-b8d537b0640d286235ab8b9bd530d2283866769710f97b2acb2fa60a0d1f684f.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb7e5e28_5e0a_40ab_9f61_a229250b87a0.slice/cri-containerd-87c5d192aca1271ab1f9128229c80d01c7e5ad47c8b8541ddb03bfc0f283699b.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode7211ef7_e0b5_4240_9a40_b8bc55c63cd2.slice/cri-containerd-105e94d8c53c526764edf9823969a4480228a6ae0bdc940df2a1fe9be6eec79a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode7211ef7_e0b5_4240_9a40_b8bc55c63cd2.slice/cri-containerd-9c3747ce7adb8c9c7a32768ce9b750ea6e1437dca696e7b9d9ce9140edfb2e42.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34a41c51_1712_4947_9cd3_1b07584648c2.slice/cri-containerd-c8140b5383014240b8545fb9d7fa884decc5fa038a4ea189372d2b633a26422b.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34a41c51_1712_4947_9cd3_1b07584648c2.slice/cri-containerd-1aff68b2ab2130c5c60f0788d4a8e6a6e69dbd5bec64cbf72faaea135b8ffd64.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23c48f24_ce40_4c85_81a0_479feb396053.slice/cri-containerd-a168103881a0831a15388786ff7409594bc006842306f01ba9b713fa53ad4f52.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23c48f24_ce40_4c85_81a0_479feb396053.slice/cri-containerd-7de042e595de1cf3a3c138cf64175eefabd925ebb1026bdf6388c718a1efa1e8.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab1b437_74d1_4f3c_9d59_08730c86cb6d.slice/cri-containerd-875a845b29ab47932120db03f8486aabd8283c2b84935bfebc21e04fa534d5a4.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab1b437_74d1_4f3c_9d59_08730c86cb6d.slice/cri-containerd-954f736f81bf15bec3143e6d9578a548a848a6f8c164d01c6f10547948845e53.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab1b437_74d1_4f3c_9d59_08730c86cb6d.slice/cri-containerd-cd7f31a830704a42c5cc99a64012dff075ebabf2a1a643256d68081c0958b783.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeab1b437_74d1_4f3c_9d59_08730c86cb6d.slice/cri-containerd-b8193ae3f219749dec61708b9d25075155e08cf9be870f7f2d946e30d0f3a8d7.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5ddba67_0e3f_4b5b_a7cb_75570974cabc.slice/cri-containerd-53065d1f583393da457d7f7159e55fe344bb457bd7f09588d02e95afd9d1bac8.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5ddba67_0e3f_4b5b_a7cb_75570974cabc.slice/cri-containerd-c0570e2dae1c954dd370c11323040f22b16d31882c2aaedec20d20f8f65314b9.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5ddba67_0e3f_4b5b_a7cb_75570974cabc.slice/cri-containerd-c2c63dd2873a1bf66d8ed4d09db6e1ddf0856e3a5f53e0f7060d5cca6e8568da.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83be0f47_9d0a_4b0b_8054_ee0708dfb909.slice/cri-containerd-a42ef776ad4aada401ed97466065f9731f1ca7656201e4ad8dde86eac3a65dba.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83be0f47_9d0a_4b0b_8054_ee0708dfb909.slice/cri-containerd-3ad45a0678fc92f3b199955abd81e634f8ee6b2968adcde504e15f75910a23e0.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dc7d9f5_32a7_4288_b854_7a0fc33e73a8.slice/cri-containerd-c25b3f889efb65b981c0cedcb39027368aaf692e93e6a837925afa8c0a7cf9f5.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dc7d9f5_32a7_4288_b854_7a0fc33e73a8.slice/cri-containerd-7c2ac7f53238af0922f15a822f23abccf393d6dd0e13a5332c33c3e49faeff4d.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36ee19a6_264f_42dd_8a1c_6ec432a7b521.slice/cri-containerd-8dcb59c23bc06b0ec05fbecf0c60d6a3d6fc90b123e3a554f263ec49519bf4f4.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36ee19a6_264f_42dd_8a1c_6ec432a7b521.slice/cri-containerd-ffef597c342f144694dbbc2b0b339b7f5ccb6ad3136af39124e800be220f1095.scope
    90       cgroup_device   multi                                          
