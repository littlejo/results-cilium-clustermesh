[
  {
    "containers": [
      {
        "cgroup-id": 9982,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod348caeae_7698_499a_b263_4b5ad0402d62.slice/cri-containerd-ce90bee387f1509acfef494cedc25463d3e93379bdd157bcf9492d8e87a72e0f.scope"
      },
      {
        "cgroup-id": 10066,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod348caeae_7698_499a_b263_4b5ad0402d62.slice/cri-containerd-a01a8ccffb9f9f1dcf0ce68e0f74d579b1fefd02552ffdd2a1d97522d63a6869.scope"
      }
    ],
    "ips": [
      "10.118.0.99"
    ],
    "name": "echo-same-node-86d9cc975c-mvw6n",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9058,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb9e28f5_da0f_477e_b9a5_a0c1762b608c.slice/cri-containerd-cf8be64abf9c429b6248dc6204c33776c5e8348e391cc932a5a9930d1ec19bf8.scope"
      },
      {
        "cgroup-id": 9226,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb9e28f5_da0f_477e_b9a5_a0c1762b608c.slice/cri-containerd-83a2e46a8b7e3f7156bb724ee88f813a1cfb3ede9d7626773809ba875ac182ac.scope"
      },
      {
        "cgroup-id": 9142,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb9e28f5_da0f_477e_b9a5_a0c1762b608c.slice/cri-containerd-6f52d40bc70f9971c27193b316c5729f54d9eab57b744ff0257dade73e28fa1f.scope"
      }
    ],
    "ips": [
      "10.118.0.92"
    ],
    "name": "clustermesh-apiserver-5865dcb987-98m6t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7666,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2124a059_59b1_4e1b_9b95_a3b878c7c130.slice/cri-containerd-26ec4d2a3287e0ac4ab0a868268d3ba6e876d00df4bab292622d1965b1f036c1.scope"
      }
    ],
    "ips": [
      "10.118.0.158"
    ],
    "name": "coredns-cc6ccd49c-tjj5w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7582,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda95e76a3_d7e8_4984_979e_05eff739554b.slice/cri-containerd-2aadec3b306b45630b0965237a5d5fa87ea43cdf891746d2bccd93f3ef23bee5.scope"
      }
    ],
    "ips": [
      "10.118.0.220"
    ],
    "name": "coredns-cc6ccd49c-bdprt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9898,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7fe0c0b_7b94_4188_800e_c882945b3441.slice/cri-containerd-21c1200b2b7efaf4456b9d93696bedb54c85fe8a2b2f66404d6cfbb00b8a275b.scope"
      }
    ],
    "ips": [
      "10.118.0.210"
    ],
    "name": "client-974f6c69d-89lz5",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9814,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78e131bb_5f03_4775_9a1a_94a423e18ab8.slice/cri-containerd-6de57660aab875ce2beec82292c3789bb0e5c7392a6505d200778eef39191a8d.scope"
      }
    ],
    "ips": [
      "10.118.0.161"
    ],
    "name": "client2-57cf4468f-5tcmd",
    "namespace": "cilium-test-1"
  }
]

