Node 0, zone      DMA    268      6     26      1      0      3      2      3      2      2     42 
Node 0, zone   Normal    734    130     49     10      9      5      1      3      2      2      7 
