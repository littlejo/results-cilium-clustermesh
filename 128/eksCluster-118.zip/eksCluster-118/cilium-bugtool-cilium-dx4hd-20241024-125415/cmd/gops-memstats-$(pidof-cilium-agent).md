alloc: 80.97MB (84904904 bytes)
total-alloc: 3.10GB (3330899832 bytes)
sys: 211.32MB (221586772 bytes)
lookups: 0
mallocs: 75703780
frees: 75015576
heap-alloc: 80.97MB (84904904 bytes)
heap-sys: 164.60MB (172597248 bytes)
heap-idle: 46.84MB (49111040 bytes)
heap-in-use: 117.77MB (123486208 bytes)
heap-released: 6.91MB (7249920 bytes)
heap-objects: 688204
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 1.98MB (2071680 bytes)
stack-mspan-sys: 2.74MB (2872320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1065385 bytes)
gc-sys: 5.51MB (5772456 bytes)
next-gc: when heap-alloc >= 151.11MB (158451416 bytes)
last-gc: 2024-10-24 12:54:32.269995923 +0000 UTC
gc-pause-total: 13.129429ms
gc-pause: 675515
gc-pause-end: 1729774472269995923
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0007175290149102455
enable-gc: true
debug-gc: false
