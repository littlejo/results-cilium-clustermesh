1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e8:6f:2b:3f:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.185.179/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3560sec preferred_lft 3560sec
    inet6 fe80::4e8:6fff:fe2b:3fd3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:26:74:18:a9:57 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.150.174/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::426:74ff:fe18:a957/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:b7:57:c1:ab:be brd ff:ff:ff:ff:ff:ff
    inet6 fe80::28b7:57ff:fec1:abbe/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:e3:7e:de:a4:c2 brd ff:ff:ff:ff:ff:ff
    inet 10.118.0.159/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b0e3:7eff:fede:a4c2/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 92:f8:57:55:0a:bf brd ff:ff:ff:ff:ff:ff
    inet6 fe80::90f8:57ff:fe55:abf/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:63:72:98:df:4b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8063:72ff:fe98:df4b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce72e14a93340@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:bf:a9:02:20:59 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::58bf:a9ff:fe02:2059/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb7164288e8df@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:a5:b9:87:62:95 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::78a5:b9ff:fe87:6295/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8346ab9b66b9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:13:31:e9:59:e3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2813:31ff:fee9:59e3/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc67b5d5066d18@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:14:20:9b:f5:5a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a814:20ff:fe9b:f55a/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc5b8d155926a6@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:97:a1:77:0b:73 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::e097:a1ff:fe77:b73/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc28ca2f59ab47@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:f1:ea:25:fb:2c brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::a0f1:eaff:fe25:fb2c/64 scope link 
       valid_lft forever preferred_lft forever
