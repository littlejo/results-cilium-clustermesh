key: 09 00 00 00  value: 21 0d 00 00
key: fd 00 00 00  value: 24 02 00 00
key: b0 03 00 00  value: 7c 02 00 00
key: d3 03 00 00  value: 13 02 00 00
key: bc 05 00 00  value: ea 0c 00 00
key: d8 0a 00 00  value: 07 02 00 00
key: 4c 0e 00 00  value: 1c 0d 00 00
Found 7 elements
