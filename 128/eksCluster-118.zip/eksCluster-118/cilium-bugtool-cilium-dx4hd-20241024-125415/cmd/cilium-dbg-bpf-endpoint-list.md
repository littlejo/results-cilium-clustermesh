IP ADDRESS         LOCAL ENDPOINT INFO
10.118.0.190:0     id=979   sec_id=4     flags=0x0000 ifindex=10  mac=22:21:0F:CC:63:6C nodemac=82:63:72:98:DF:4B     
10.118.0.220:0     id=253   sec_id=7845983 flags=0x0000 ifindex=12  mac=42:0B:70:A5:B4:02 nodemac=5A:BF:A9:02:20:59   
10.118.0.161:0     id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73   
172.31.185.179:0   (localhost)                                                                                        
10.118.0.92:0      id=944   sec_id=7824060 flags=0x0000 ifindex=18  mac=42:4C:DD:5E:5C:61 nodemac=2A:13:31:E9:59:E3   
172.31.150.174:0   (localhost)                                                                                        
10.118.0.99:0      id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C   
10.118.0.159:0     (localhost)                                                                                        
10.118.0.158:0     id=2776  sec_id=7845983 flags=0x0000 ifindex=14  mac=DE:9D:02:54:2C:11 nodemac=7A:A5:B9:87:62:95   
10.118.0.210:0     id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A   
