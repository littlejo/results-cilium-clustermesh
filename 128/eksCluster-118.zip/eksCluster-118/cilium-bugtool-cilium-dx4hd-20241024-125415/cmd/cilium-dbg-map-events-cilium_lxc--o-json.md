{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.769Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.771Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.804Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.027Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.032Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.093Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.104Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.165Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.781Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.788Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.825Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.829Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.942Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.964Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.014Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.220Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.231Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.288Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.336Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.342Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.873Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.904Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.918Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.958Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.980Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.997Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.245Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.248Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.312Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.340Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.355Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.971Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.975Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.010Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.028Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.086Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.126Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.182Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.398Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.399Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.442Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.447Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.492Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.952Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.982Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.003Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.027Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.048Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.284Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.291Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.346Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.384Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.388Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.788Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.829Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.849Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.896Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.920Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.943Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.257Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.270Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.341Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.353Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.385Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.695Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.733Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.741Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.789Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.796Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.826Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.077Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.102Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.159Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.162Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.211Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.597Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.633Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.641Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.680Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.704Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.717Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.967Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.990Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.038Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.047Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.097Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.493Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.530Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.537Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.570Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.576Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.613Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.865Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.870Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.920Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.946Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.969Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.266Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.305Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.309Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.354Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.375Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.395Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.633Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.641Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.686Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.788Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.799Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.069Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.117Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.128Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.169Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.174Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.209Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.432Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.439Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.461Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.467Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.472Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.137Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.140Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.181Z",
  "value": "id=1468  sec_id=7844352 flags=0x0000 ifindex=24  mac=9A:2E:AE:95:1B:23 nodemac=A2:F1:EA:25:FB:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.191Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.216Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.476Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.486Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.289Z",
  "value": "id=9     sec_id=7805443 flags=0x0000 ifindex=22  mac=8E:57:3A:E3:23:B6 nodemac=E2:97:A1:77:0B:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.289Z",
  "value": "id=3660  sec_id=7826792 flags=0x0000 ifindex=20  mac=AE:E4:75:FE:84:5F nodemac=AA:14:20:9B:F5:5A"
}

