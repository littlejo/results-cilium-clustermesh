filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8346ab9b66b9 direct-action not_in_hw id 630 tag eb10e3867f813a20 jited 
