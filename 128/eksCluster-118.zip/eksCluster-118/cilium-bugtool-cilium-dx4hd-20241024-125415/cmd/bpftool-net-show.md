xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 584
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 572
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 563
cilium_host(7) clsact/egress cil_from_host-cilium_host id 561
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 528
lxce72e14a93340(12) clsact/ingress cil_from_container-lxce72e14a93340 id 550
lxcb7164288e8df(14) clsact/ingress cil_from_container-lxcb7164288e8df id 512
lxc8346ab9b66b9(18) clsact/ingress cil_from_container-lxc8346ab9b66b9 id 630
lxc67b5d5066d18(20) clsact/ingress cil_from_container-lxc67b5d5066d18 id 3352
lxc5b8d155926a6(22) clsact/ingress cil_from_container-lxc5b8d155926a6 id 3349
lxc28ca2f59ab47(24) clsact/ingress cil_from_container-lxc28ca2f59ab47 id 3289

flow_dissector:

netfilter:

