CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79d3ba20_bc21_46d6_9d65_22b60eac2833.slice/cri-containerd-a85c5963afd53f2b2491cf8b075ef9a3346e9a6d247ab0e18605cdbc35ae3998.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79d3ba20_bc21_46d6_9d65_22b60eac2833.slice/cri-containerd-021203404283d056df086546a3ab5724bc67ef2a7dfdbb4fcf42fee6af0ee0a5.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod118340c7_1a4b_42d2_9382_de22ea2f17a0.slice/cri-containerd-17459b2400e31faa8d267c308915b5a0decd66280234da6632588655ca35527f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod118340c7_1a4b_42d2_9382_de22ea2f17a0.slice/cri-containerd-ded1a46d77365671c1cd6f970a99b7fc556ce72d168ec246c8d97725a302f7d7.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda95e76a3_d7e8_4984_979e_05eff739554b.slice/cri-containerd-d8ef2363495cc2ead7c9f1dd235f961a785056c5f342725ea5e88016e3d4f0f8.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda95e76a3_d7e8_4984_979e_05eff739554b.slice/cri-containerd-2aadec3b306b45630b0965237a5d5fa87ea43cdf891746d2bccd93f3ef23bee5.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2124a059_59b1_4e1b_9b95_a3b878c7c130.slice/cri-containerd-493c589a31d05c05fcab5e10672b4f0b38a2157ae594dc6811c1cd75d10f2e83.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2124a059_59b1_4e1b_9b95_a3b878c7c130.slice/cri-containerd-26ec4d2a3287e0ac4ab0a868268d3ba6e876d00df4bab292622d1965b1f036c1.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod348caeae_7698_499a_b263_4b5ad0402d62.slice/cri-containerd-ce90bee387f1509acfef494cedc25463d3e93379bdd157bcf9492d8e87a72e0f.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod348caeae_7698_499a_b263_4b5ad0402d62.slice/cri-containerd-c2d72c35fe76f7fc40442e767b84c03f31cf090442bacde1a27b406a24b9d64b.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod348caeae_7698_499a_b263_4b5ad0402d62.slice/cri-containerd-a01a8ccffb9f9f1dcf0ce68e0f74d579b1fefd02552ffdd2a1d97522d63a6869.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb9e28f5_da0f_477e_b9a5_a0c1762b608c.slice/cri-containerd-6f52d40bc70f9971c27193b316c5729f54d9eab57b744ff0257dade73e28fa1f.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb9e28f5_da0f_477e_b9a5_a0c1762b608c.slice/cri-containerd-cf8be64abf9c429b6248dc6204c33776c5e8348e391cc932a5a9930d1ec19bf8.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb9e28f5_da0f_477e_b9a5_a0c1762b608c.slice/cri-containerd-83a2e46a8b7e3f7156bb724ee88f813a1cfb3ede9d7626773809ba875ac182ac.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb9e28f5_da0f_477e_b9a5_a0c1762b608c.slice/cri-containerd-d9b1653c6d9fa6a32529aaed1b967c7b0cd359a3d8bd0da7693b9f0a014362fd.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78e131bb_5f03_4775_9a1a_94a423e18ab8.slice/cri-containerd-7baa58c5ebb78f36a96b455a66aad989dcb7e9d804a8ee6ac5edeac4c16e5cfe.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78e131bb_5f03_4775_9a1a_94a423e18ab8.slice/cri-containerd-6de57660aab875ce2beec82292c3789bb0e5c7392a6505d200778eef39191a8d.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07875716_9e80_4f30_aa7a_918f09e8bbe5.slice/cri-containerd-d6833fde296bf1f106cfc8b262d7eb394d5bcda68d9ed5c1206fe8f3a4cceb30.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07875716_9e80_4f30_aa7a_918f09e8bbe5.slice/cri-containerd-265a7b794e905296fd5a9e5053993519c0dfb71db451c7fa5e7fcd1e54cd64f7.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod429ba441_2e4b_488a_bebf_ba24b98f86c0.slice/cri-containerd-40fe9f189673b1987060ccb53bc2db910ecbfc77c6ffcb7db93f2b19e125071c.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod429ba441_2e4b_488a_bebf_ba24b98f86c0.slice/cri-containerd-c12927619003eadacbc9adaec1309482e64d17197e3043ec473b453b33882f6c.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7fe0c0b_7b94_4188_800e_c882945b3441.slice/cri-containerd-21c1200b2b7efaf4456b9d93696bedb54c85fe8a2b2f66404d6cfbb00b8a275b.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7fe0c0b_7b94_4188_800e_c882945b3441.slice/cri-containerd-c66cc0c7036c2288d04e0aac121f8fdab6d7ba87bffc8de144d691c2a8853ff6.scope
    701      cgroup_device   multi                                          
