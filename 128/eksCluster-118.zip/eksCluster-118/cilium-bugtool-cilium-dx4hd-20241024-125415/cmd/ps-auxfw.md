USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3248  0.0  0.4 1240432 16324 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3262  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3264  0.0  0.0   3728   488 ?        R    12:54   0:00  \_ bash -c hostname
root        3215  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  5.1  7.2 1539060 282924 ?      Ssl  12:33   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.3  0.2 1229744 9136 ?        Sl   12:33   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
