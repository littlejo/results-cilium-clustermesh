top - 12:54:16 up 30 min,  0 users,  load average: 1.29, 0.57, 0.27
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.6 us, 23.5 sy,  0.0 ni, 50.0 id,  0.0 wa,  0.0 hi,  8.8 si,  0.0 st
MiB Mem :   3836.2 total,    313.9 free,   1026.2 used,   2496.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2628.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 282924  78140 S   6.2   7.2   1:05.04 cilium-+
    393 root      20   0 1229744   9136   2924 S   0.0   0.2   0:04.38 cilium-+
   3215 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3248 root      20   0 1240432  16324  11356 S   0.0   0.4   0:00.02 cilium-+
   3274 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3293 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
