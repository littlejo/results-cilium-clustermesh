REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     133377    10818928    677    bpf_overlay.c
Interface                   INGRESS     673586    247289606   1132   bpf_host.c
Policy denied               EGRESS      61        4514        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      133821    10839907    53     encap.h
Success                     EGRESS      150890    19930910    1308   bpf_lxc.c
Success                     EGRESS      57124     4628959     1694   bpf_host.c
Success                     EGRESS      8380      1386659     86     l3.h
Success                     INGRESS     174534    20082040    86     l3.h
Success                     INGRESS     259798    27701138    235    trace.h
Unsupported L3 protocol     EGRESS      70        5260        1492   bpf_lxc.c
