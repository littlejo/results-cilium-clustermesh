 12:54:16 up 30 min,  0 users,  load average: 1.29, 0.57, 0.27
