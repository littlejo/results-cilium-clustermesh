KEY             VALUE
AgentLiveness   1879942657233
UTimeOffset     3378462123046875
