filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc28ca2f59ab47 direct-action not_in_hw id 3289 tag 8146bff1d695f902 jited 
