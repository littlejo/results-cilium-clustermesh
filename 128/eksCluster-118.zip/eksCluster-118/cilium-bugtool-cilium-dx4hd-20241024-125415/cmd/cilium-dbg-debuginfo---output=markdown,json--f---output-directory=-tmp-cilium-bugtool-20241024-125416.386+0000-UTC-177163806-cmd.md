markdown output at /tmp/cilium-bugtool-20241024-125416.386+0000-UTC-177163806/cmd/cilium-debuginfo-20241024-125447.13+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.386+0000-UTC-177163806/cmd/cilium-debuginfo-20241024-125447.13+0000-UTC.json
