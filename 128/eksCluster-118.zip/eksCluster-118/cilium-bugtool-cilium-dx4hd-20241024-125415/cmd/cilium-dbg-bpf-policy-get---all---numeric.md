Endpoint ID: 9
Path: /sys/fs/bpf/tc/globals/cilium_policy_00009

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 253
Path: /sys/fs/bpf/tc/globals/cilium_policy_00253

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    219633   1978      0        
Allow    Ingress     1          ANY          NONE         disabled    123169   1412      0        
Allow    Egress      0          ANY          NONE         disabled    64100    627       0        


Endpoint ID: 944
Path: /sys/fs/bpf/tc/globals/cilium_policy_00944

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6144967   61816     0        
Allow    Ingress     1          ANY          NONE         disabled    5465728   57746     0        
Allow    Egress      0          ANY          NONE         disabled    6917949   68346     0        


Endpoint ID: 979
Path: /sys/fs/bpf/tc/globals/cilium_policy_00979

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6234654   76912     0        
Allow    Ingress     1          ANY          NONE         disabled    61294     740       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1468
Path: /sys/fs/bpf/tc/globals/cilium_policy_01468

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379776   4434      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1524
Path: /sys/fs/bpf/tc/globals/cilium_policy_01524

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2776
Path: /sys/fs/bpf/tc/globals/cilium_policy_02776

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    218131   1974      0        
Allow    Ingress     1          ANY          NONE         disabled    123499   1417      0        
Allow    Egress      0          ANY          NONE         disabled    65663    644       0        


Endpoint ID: 3660
Path: /sys/fs/bpf/tc/globals/cilium_policy_03660

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


