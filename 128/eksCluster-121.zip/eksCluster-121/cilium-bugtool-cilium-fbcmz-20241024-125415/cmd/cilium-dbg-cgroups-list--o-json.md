[
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54e151f3_1655_4224_85a8_5ad1eb42f816.slice/cri-containerd-ed14243e72902c83074e332bb1f086adcb48537eb5ec233bbeb35114d14a2643.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54e151f3_1655_4224_85a8_5ad1eb42f816.slice/cri-containerd-091af50c90ed2445f800198ebb62bd97cb95cb445e70420a46b1202f1a8d03a2.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54e151f3_1655_4224_85a8_5ad1eb42f816.slice/cri-containerd-c21bc213957f69a714b81887f3a531be5f35d8f05db8c00b04ccaf20a25bd47c.scope"
      }
    ],
    "ips": [
      "10.121.0.72"
    ],
    "name": "clustermesh-apiserver-9c79475fb-7jslb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod302bad3c_3c1e_43b5_b653_c572cf98df79.slice/cri-containerd-0e3dffa4fec70f1b0a55ad54b630a3f2cb5f5e4e56ef85bfd3bee7ed921fd52b.scope"
      }
    ],
    "ips": [
      "10.121.0.101"
    ],
    "name": "coredns-cc6ccd49c-kjvr5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded143d18_be8e_4315_9702_e2079ac14aa4.slice/cri-containerd-7c520f4b3a3b9272f2f4c54cae1256c16471273004da6cc3d34ae09feb1c9636.scope"
      }
    ],
    "ips": [
      "10.121.0.79"
    ],
    "name": "coredns-cc6ccd49c-zzwkm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a569177_2d76_4653_b9f5_732fc87a1508.slice/cri-containerd-8b857d411b76d5f30dff8f6ee6e0b44e4ac115576d68181f5c9cb0a9d58f59a5.scope"
      }
    ],
    "ips": [
      "10.121.0.209"
    ],
    "name": "client-974f6c69d-mr29k",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefc66b2c_fe1c_489a_ad69_35d6499ae6d3.slice/cri-containerd-174682641f0732d85a0acdcb05c886a53a36261704fda189c6a85503a5b362f9.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefc66b2c_fe1c_489a_ad69_35d6499ae6d3.slice/cri-containerd-89110d87debcc710e8d44cef5a72734cb1e20c8e4582d477acb058221a2e0af4.scope"
      }
    ],
    "ips": [
      "10.121.0.57"
    ],
    "name": "echo-same-node-86d9cc975c-gpwsc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf3357ea_4fe5_4c79_8aab_2f47539f3c13.slice/cri-containerd-f272716d7bd1cac26cbbe365b137e434e3aaffee7e3368b3463c7206279882f4.scope"
      }
    ],
    "ips": [
      "10.121.0.219"
    ],
    "name": "client2-57cf4468f-nr8h9",
    "namespace": "cilium-test-1"
  }
]

