USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3272  0.0  0.2 1616264 9244 ?        Rsl  12:54   0:00 /usr/sbin/runc init
root        3253  0.0  0.4 1240432 16132 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3278  0.0  0.0   3852  1276 ?        R    12:54   0:00  \_ bash -c cat /proc/net/xfrm_stat
root        3279  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3216  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3215  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  5.6  7.4 1539060 292784 ?      Ssl  12:33   1:10 cilium-agent --config-dir=/tmp/cilium/config-map
root         419  0.3  0.2 1229744 10184 ?       Sl   12:33   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
