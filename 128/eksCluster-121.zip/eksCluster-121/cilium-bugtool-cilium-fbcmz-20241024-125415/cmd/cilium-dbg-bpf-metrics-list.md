REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     133622    10845196    677    bpf_overlay.c
Interface                   INGRESS     689856    249120853   1132   bpf_host.c
Policy denied               EGRESS      61        4514        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      134475    10895304    53     encap.h
Success                     EGRESS      160706    21233800    1308   bpf_lxc.c
Success                     EGRESS      57494     4663597     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     184948    21400262    86     l3.h
Success                     INGRESS     262303    27780630    235    trace.h
Unsupported L3 protocol     EGRESS      73        5550        1492   bpf_lxc.c
