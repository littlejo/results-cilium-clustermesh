KEY             VALUE
AgentLiveness   1878098956507
UTimeOffset     3378462128906250
