filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc397398a43852 direct-action not_in_hw id 613 tag bd7c99fd9b6dc5e8 jited 
