IP ADDRESS         LOCAL ENDPOINT INFO
10.121.0.57:0      id=1782  sec_id=8043873 flags=0x0000 ifindex=22  mac=FE:4D:44:EC:85:6B nodemac=72:4B:8D:C1:40:A1   
10.121.0.129:0     id=2920  sec_id=4     flags=0x0000 ifindex=10  mac=12:EA:17:2E:BD:1B nodemac=92:02:25:FF:86:18     
172.31.201.135:0   (localhost)                                                                                        
172.31.219.59:0    (localhost)                                                                                        
10.121.0.79:0      id=2993  sec_id=8056198 flags=0x0000 ifindex=12  mac=5A:EA:97:D4:70:1F nodemac=66:E9:D3:B2:CD:69   
10.121.0.219:0     id=1499  sec_id=8015803 flags=0x0000 ifindex=24  mac=26:09:11:7E:D5:B8 nodemac=4E:AA:FE:48:C6:9E   
10.121.0.101:0     id=1393  sec_id=8056198 flags=0x0000 ifindex=14  mac=D6:D4:71:DD:E9:17 nodemac=22:4D:A1:B3:4E:5B   
10.121.0.209:0     id=3121  sec_id=8026903 flags=0x0000 ifindex=20  mac=DA:3A:20:48:4D:2A nodemac=BA:C6:DE:C0:1C:B1   
10.121.0.166:0     (localhost)                                                                                        
10.121.0.72:0      id=366   sec_id=8013752 flags=0x0000 ifindex=18  mac=E2:A2:59:1B:CF:85 nodemac=AA:70:B6:10:96:89   
