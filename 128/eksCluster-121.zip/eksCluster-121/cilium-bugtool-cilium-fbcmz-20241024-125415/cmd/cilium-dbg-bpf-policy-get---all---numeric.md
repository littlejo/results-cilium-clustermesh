Endpoint ID: 203
Path: /sys/fs/bpf/tc/globals/cilium_policy_00203

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 366
Path: /sys/fs/bpf/tc/globals/cilium_policy_00366

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6110276   61607     0        
Allow    Ingress     1          ANY          NONE         disabled    6038131   62302     0        
Allow    Egress      0          ANY          NONE         disabled    7207231   70814     0        


Endpoint ID: 1393
Path: /sys/fs/bpf/tc/globals/cilium_policy_01393

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2542     25        0        
Allow    Ingress     1          ANY          NONE         disabled    118894   1358      0        
Allow    Egress      0          ANY          NONE         disabled    17561    192       0        


Endpoint ID: 1499
Path: /sys/fs/bpf/tc/globals/cilium_policy_01499

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1782
Path: /sys/fs/bpf/tc/globals/cilium_policy_01782

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376348   4389      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2920
Path: /sys/fs/bpf/tc/globals/cilium_policy_02920

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6225835   76782     0        
Allow    Ingress     1          ANY          NONE         disabled    61381     743       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2993
Path: /sys/fs/bpf/tc/globals/cilium_policy_02993

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3354     35        0        
Allow    Ingress     1          ANY          NONE         disabled    117723   1344      0        
Allow    Egress      0          ANY          NONE         disabled    17986    196       0        


Endpoint ID: 3121
Path: /sys/fs/bpf/tc/globals/cilium_policy_03121

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


