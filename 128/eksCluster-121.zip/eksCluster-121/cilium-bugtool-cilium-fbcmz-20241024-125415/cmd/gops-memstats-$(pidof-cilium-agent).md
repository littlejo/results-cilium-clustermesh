alloc: 103.82MB (108866024 bytes)
total-alloc: 3.16GB (3396779728 bytes)
sys: 231.32MB (242558292 bytes)
lookups: 0
mallocs: 76273030
frees: 75259501
heap-alloc: 103.82MB (108866024 bytes)
heap-sys: 183.05MB (191938560 bytes)
heap-idle: 49.43MB (51830784 bytes)
heap-in-use: 133.62MB (140107776 bytes)
heap-released: 13.64MB (14303232 bytes)
heap-objects: 1013529
stack-in-use: 36.91MB (38699008 bytes)
stack-sys: 36.91MB (38699008 bytes)
stack-mspan-inuse: 2.19MB (2294880 bytes)
stack-mspan-sys: 2.82MB (2953920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 950.60KB (973417 bytes)
gc-sys: 5.52MB (5784600 bytes)
next-gc: when heap-alloc >= 151.76MB (159127976 bytes)
last-gc: 2024-10-24 12:54:22.492518158 +0000 UTC
gc-pause-total: 12.079853ms
gc-pause: 99265
gc-pause-end: 1729774462492518158
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.000820210004097872
enable-gc: true
debug-gc: false
