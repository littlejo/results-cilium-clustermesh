top - 12:54:16 up 30 min,  0 users,  load average: 0.63, 0.66, 0.36
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 45.2 us, 25.8 sy,  0.0 ni, 25.8 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   3836.2 total,    271.3 free,   1066.5 used,   2498.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2588.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 297800  78596 S  40.0   7.6   1:10.25 cilium-+
    419 root      20   0 1229744  10184   3836 S   0.0   0.3   0:04.48 cilium-+
   3253 root      20   0 1240432  16132  11164 S   0.0   0.4   0:00.02 cilium-+
   3289 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3295 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3305 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3328 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
