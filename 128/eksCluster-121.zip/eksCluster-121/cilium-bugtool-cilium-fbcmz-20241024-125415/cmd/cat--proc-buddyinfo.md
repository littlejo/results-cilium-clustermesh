Node 0, zone      DMA    155     42     17     20     17      7      5      2      7      2     32 
Node 0, zone   Normal    321    226     92     51     24      4      2      3      2      1      7 
