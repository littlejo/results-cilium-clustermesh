filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6c518510896d direct-action not_in_hw id 3299 tag 1deb7871c0ebb6ec jited 
