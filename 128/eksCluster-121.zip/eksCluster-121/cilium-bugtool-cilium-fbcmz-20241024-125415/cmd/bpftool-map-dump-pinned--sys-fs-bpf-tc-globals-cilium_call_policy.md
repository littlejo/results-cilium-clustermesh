key: 6e 01 00 00  value: 62 02 00 00
key: 71 05 00 00  value: 1f 02 00 00
key: db 05 00 00  value: e9 0c 00 00
key: f6 06 00 00  value: b1 0c 00 00
key: 68 0b 00 00  value: 27 02 00 00
key: b1 0b 00 00  value: 0a 02 00 00
key: 31 0c 00 00  value: ec 0c 00 00
Found 7 elements
