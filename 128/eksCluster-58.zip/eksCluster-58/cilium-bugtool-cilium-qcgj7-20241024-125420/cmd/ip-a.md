1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b1:08:3d:5e:ef brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.169.93/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3460sec preferred_lft 3460sec
    inet6 fe80::4b1:8ff:fe3d:5eef/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:5b:5c:5c:c3:c1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.160.158/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::45b:5cff:fe5c:c3c1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:e1:ee:87:03:ac brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8e1:eeff:fe87:3ac/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:77:6c:21:62:58 brd ff:ff:ff:ff:ff:ff
    inet 10.58.0.94/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3077:6cff:fe21:6258/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 32:8f:fe:57:e8:3d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::308f:feff:fe57:e83d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:71:75:ea:f9:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2871:75ff:feea:f9e4/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd323986c561c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:e8:87:9c:45:25 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c0e8:87ff:fe9c:4525/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5f3c6db5ce89@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:77:54:60:03:48 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::3877:54ff:fe60:348/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc064b28f0d2c8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:09:1f:af:6a:9e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a009:1fff:feaf:6a9e/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc5008ec482fc8@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:c4:de:85:44:e9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6cc4:deff:fe85:44e9/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc5973d7b4c452@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:99:91:ea:5a:23 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::e899:91ff:feea:5a23/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc83bde50db136@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:c0:d8:d1:9a:e9 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::48c0:d8ff:fed1:9ae9/64 scope link 
       valid_lft forever preferred_lft forever
