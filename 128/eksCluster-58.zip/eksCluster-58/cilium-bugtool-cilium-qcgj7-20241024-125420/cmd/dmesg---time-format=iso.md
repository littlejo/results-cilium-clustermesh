2024-10-24T12:21:53,000000+00:00 Booting Linux on physical CPU 0x0000000000 [0x413fd0c1]
2024-10-24T12:21:53,000000+00:00 Linux version 6.1.112-122.189.amzn2023.aarch64 (mockbuild@ip-10-0-39-248) (gcc (GCC) 11.4.1 20230605 (Red Hat 11.4.1-2), GNU ld version 2.39-6.amzn2023.0.10) #1 SMP Tue Oct  8 17:01:34 UTC 2024
2024-10-24T12:21:53,000000+00:00 efi: EFI v2.70 by EDK II
2024-10-24T12:21:53,000000+00:00 efi: SMBIOS=0x7bed0000 SMBIOS 3.0=0x7beb0000 ACPI=0x786e0000 ACPI 2.0=0x786e0014 MEMATTR=0x7aff0a98 RNG=0x74ca0018 MEMRESERVE=0x784d0d98 
2024-10-24T12:21:53,000000+00:00 random: crng init done
2024-10-24T12:21:53,000000+00:00 ACPI: Early table checksum verification disabled
2024-10-24T12:21:53,000000+00:00 ACPI: RSDP 0x00000000786E0014 000024 (v02 AMAZON)
2024-10-24T12:21:53,000000+00:00 ACPI: XSDT 0x00000000786D00E8 000064 (v01 AMAZON AMZNFACP 00000001      01000013)
2024-10-24T12:21:53,000000+00:00 ACPI: FACP 0x00000000786B0000 000114 (v06 AMAZON AMZNFACP 00000001 AMZN 00000001)
2024-10-24T12:21:53,000000+00:00 ACPI: DSDT 0x0000000078640000 00159D (v02 AMAZON AMZNDSDT 00000001 INTL 20160527)
2024-10-24T12:21:53,000000+00:00 ACPI: FACS 0x0000000078630000 000040
2024-10-24T12:21:53,000000+00:00 ACPI: APIC 0x00000000786C0000 000108 (v04 AMAZON AMZNAPIC 00000001 AMZN 00000001)
2024-10-24T12:21:53,000000+00:00 ACPI: SPCR 0x00000000786A0000 000050 (v02 AMAZON AMZNSPCR 00000001 AMZN 00000001)
2024-10-24T12:21:53,000000+00:00 ACPI: GTDT 0x0000000078690000 000060 (v02 AMAZON AMZNGTDT 00000001 AMZN 00000001)
2024-10-24T12:21:53,000000+00:00 ACPI: MCFG 0x0000000078680000 00003C (v02 AMAZON AMZNMCFG 00000001 AMZN 00000001)
2024-10-24T12:21:53,000000+00:00 ACPI: SLIT 0x0000000078670000 00002D (v01 AMAZON AMZNSLIT 00000001 AMZN 00000001)
2024-10-24T12:21:53,000000+00:00 ACPI: IORT 0x0000000078660000 000078 (v01 AMAZON AMZNIORT 00000001 AMZN 00000001)
2024-10-24T12:21:53,000000+00:00 ACPI: PPTT 0x0000000078650000 0000D4 (v02 AMAZON AMZNPPTT 00000001 AMZN 00000001)
2024-10-24T12:21:53,000000+00:00 ACPI: SPCR: console: uart,mmio,0x90a0000,115200
2024-10-24T12:21:53,000000+00:00 NUMA: Failed to initialise from firmware
2024-10-24T12:21:53,000000+00:00 NUMA: Faking a node at [mem 0x0000000040000000-0x00000004bb7fffff]
2024-10-24T12:21:53,000000+00:00 NUMA: NODE_DATA [mem 0x4bb01a7c0-0x4bb01cfff]
2024-10-24T12:21:53,000000+00:00 Zone ranges:
2024-10-24T12:21:53,000000+00:00   DMA      [mem 0x0000000040000000-0x00000000ffffffff]
2024-10-24T12:21:53,000000+00:00   DMA32    empty
2024-10-24T12:21:53,000000+00:00   Normal   [mem 0x0000000100000000-0x00000004bb7fffff]
2024-10-24T12:21:53,000000+00:00   Device   empty
2024-10-24T12:21:53,000000+00:00 Movable zone start for each node
2024-10-24T12:21:53,000000+00:00 Early memory node ranges
2024-10-24T12:21:53,000000+00:00   node   0: [mem 0x0000000040000000-0x000000007862ffff]
2024-10-24T12:21:53,000000+00:00   node   0: [mem 0x0000000078630000-0x000000007863ffff]
2024-10-24T12:21:53,000000+00:00   node   0: [mem 0x0000000078640000-0x00000000786effff]
2024-10-24T12:21:53,000000+00:00   node   0: [mem 0x00000000786f0000-0x000000007872ffff]
2024-10-24T12:21:53,000000+00:00   node   0: [mem 0x0000000078730000-0x000000007bbfffff]
2024-10-24T12:21:53,000000+00:00   node   0: [mem 0x000000007bc00000-0x000000007bfdffff]
2024-10-24T12:21:53,000000+00:00   node   0: [mem 0x000000007bfe0000-0x000000007fffffff]
2024-10-24T12:21:53,000000+00:00   node   0: [mem 0x0000000400000000-0x00000004bb7fffff]
2024-10-24T12:21:53,000000+00:00 Initmem setup node 0 [mem 0x0000000040000000-0x00000004bb7fffff]
2024-10-24T12:21:53,000000+00:00 On node 0, zone Normal: 18432 pages in unavailable ranges
2024-10-24T12:21:53,000000+00:00 cma: Reserved 64 MiB at 0x000000007c000000 on node -1
2024-10-24T12:21:53,000000+00:00 psci: probing for conduit method from ACPI.
2024-10-24T12:21:53,000000+00:00 psci: PSCIv1.0 detected in firmware.
2024-10-24T12:21:53,000000+00:00 psci: Using standard PSCI v0.2 function IDs
2024-10-24T12:21:53,000000+00:00 psci: Trusted OS migration not required
2024-10-24T12:21:53,000000+00:00 psci: SMC Calling Convention v1.1
2024-10-24T12:21:53,000000+00:00 percpu: Embedded 31 pages/cpu s86440 r8192 d32344 u126976
2024-10-24T12:21:53,000000+00:00 pcpu-alloc: s86440 r8192 d32344 u126976 alloc=31*4096
2024-10-24T12:21:53,000000+00:00 pcpu-alloc: [0] 0 [0] 1 
2024-10-24T12:21:53,000000+00:00 Detected PIPT I-cache on CPU0
2024-10-24T12:21:53,000000+00:00 CPU features: detected: GIC system register CPU interface
2024-10-24T12:21:53,000000+00:00 CPU features: detected: Hardware dirty bit management
2024-10-24T12:21:53,000000+00:00 CPU features: detected: Spectre-v4
2024-10-24T12:21:53,000000+00:00 CPU features: detected: Spectre-BHB
2024-10-24T12:21:53,000000+00:00 CPU features: detected: ARM erratum 1418040
2024-10-24T12:21:53,000000+00:00 CPU features: detected: ARM erratum 1542419 (kernel portion)
2024-10-24T12:21:53,000000+00:00 CPU features: detected: SSBS not fully self-synchronizing
2024-10-24T12:21:53,000000+00:00 alternatives: applying boot alternatives
2024-10-24T12:21:53,000000+00:00 Fallback order for Node 0: 0 
2024-10-24T12:21:53,000000+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 1014048
2024-10-24T12:21:53,000000+00:00 Policy zone: Normal
2024-10-24T12:21:53,000000+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64 root=UUID=b5c7fae5-1de8-4038-8408-06c720e69aff ro console=tty0 console=ttyS0,115200n8 nvme_core.io_timeout=4294967295 rd.emergency=poweroff rd.shell=0 selinux=1 security=selinux quiet numa_cma=1:64M
2024-10-24T12:21:53,000000+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64", will be passed to user space.
2024-10-24T12:21:53,000000+00:00 Dentry cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-10-24T12:21:53,000000+00:00 Inode-cache hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2024-10-24T12:21:53,000000+00:00 mem auto-init: stack:off, heap alloc:off, heap free:off
2024-10-24T12:21:53,000000+00:00 software IO TLB: area num 2.
2024-10-24T12:21:53,000000+00:00 software IO TLB: mapped [mem 0x000000006de00000-0x0000000071e00000] (64MB)
2024-10-24T12:21:53,000000+00:00 Memory: 3846296K/4120576K available (12096K kernel code, 8838K rwdata, 8416K rodata, 4480K init, 11359K bss, 208744K reserved, 65536K cma-reserved)
2024-10-24T12:21:53,000000+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-10-24T12:21:53,000000+00:00 ftrace: allocating 40237 entries in 158 pages
2024-10-24T12:21:53,000000+00:00 ftrace: allocated 158 pages with 5 groups
2024-10-24T12:21:53,000000+00:00 trace event string verifier disabled
2024-10-24T12:21:53,000000+00:00 rcu: Hierarchical RCU implementation.
2024-10-24T12:21:53,000000+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=4096 to nr_cpu_ids=2.
2024-10-24T12:21:53,000000+00:00 	Rude variant of Tasks RCU enabled.
2024-10-24T12:21:53,000000+00:00 	Tracing variant of Tasks RCU enabled.
2024-10-24T12:21:53,000000+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 10 jiffies.
2024-10-24T12:21:53,000000+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-10-24T12:21:53,000000+00:00 NR_IRQS: 64, nr_irqs: 64, preallocated irqs: 0
2024-10-24T12:21:53,000000+00:00 GICv3: 96 SPIs implemented
2024-10-24T12:21:53,000000+00:00 GICv3: 0 Extended SPIs implemented
2024-10-24T12:21:53,000000+00:00 Root IRQ handler: gic_handle_irq
2024-10-24T12:21:53,000000+00:00 GICv3: GICv3 features: 16 PPIs
2024-10-24T12:21:53,000000+00:00 GICv3: CPU0: found redistributor 0 region 0:0x0000000010200000
2024-10-24T12:21:53,000000+00:00 ITS [mem 0x10080000-0x1009ffff]
2024-10-24T12:21:53,000000+00:00 ITS@0x0000000010080000: allocated 8192 Devices @4001a0000 (indirect, esz 8, psz 64K, shr 1)
2024-10-24T12:21:53,000000+00:00 ITS@0x0000000010080000: allocated 8192 Interrupt Collections @4001b0000 (flat, esz 8, psz 64K, shr 1)
2024-10-24T12:21:53,000000+00:00 GICv3: using LPI property table @0x00000004001c0000
2024-10-24T12:21:53,000000+00:00 ITS: Using hypervisor restricted LPI range [128]
2024-10-24T12:21:53,000000+00:00 GICv3: CPU0: using allocated LPI pending table @0x00000004001d0000
2024-10-24T12:21:53,000000+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-10-24T12:21:53,000000+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-24T12:21:53,000000+00:00 arch_timer: cp15 timer(s) running at 121.87MHz (virt).
2024-10-24T12:21:53,000000+00:00 clocksource: arch_sys_counter: mask: 0x3ffffffffffffff max_cycles: 0x383759f8ff, max_idle_ns: 881590415659 ns
2024-10-24T12:21:53,000000+00:00 sched_clock: 58 bits at 122MHz, resolution 8ns, wraps every 4398046511103ns
2024-10-24T12:21:53,000019+00:00 arm-pv: using stolen time PV
2024-10-24T12:21:53,000079+00:00 Console: colour dummy device 80x25
2024-10-24T12:21:53,000093+00:00 printk: console [tty0] enabled
2024-10-24T12:21:53,000111+00:00 ACPI: Core revision 20220331
2024-10-24T12:21:53,000144+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 243.75 BogoMIPS (lpj=1218750)
2024-10-24T12:21:53,000147+00:00 pid_max: default: 32768 minimum: 301
2024-10-24T12:21:53,000168+00:00 LSM: Security Framework initializing
2024-10-24T12:21:53,000185+00:00 Yama: becoming mindful.
2024-10-24T12:21:53,000192+00:00 SELinux:  Initializing.
2024-10-24T12:21:53,000207+00:00 LSM support for eBPF active
2024-10-24T12:21:53,000225+00:00 Mount-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-10-24T12:21:53,000229+00:00 Mountpoint-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-10-24T12:21:53,000560+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-24T12:21:53,000561+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-24T12:21:53,000574+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-24T12:21:53,000575+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-24T12:21:53,000615+00:00 rcu: Hierarchical SRCU implementation.
2024-10-24T12:21:53,000616+00:00 rcu: 	Max phase no-delay instances is 1000.
2024-10-24T12:21:53,000808+00:00 Platform MSI: ITS@0x10080000 domain created
2024-10-24T12:21:53,000813+00:00 PCI/MSI: ITS@0x10080000 domain created
2024-10-24T12:21:53,000816+00:00 Remapping and enabling EFI services.
2024-10-24T12:21:53,000920+00:00 smp: Bringing up secondary CPUs ...
2024-10-24T12:21:53,001077+00:00 Detected PIPT I-cache on CPU1
2024-10-24T12:21:53,001106+00:00 GICv3: CPU1: found redistributor 1 region 0:0x0000000010220000
2024-10-24T12:21:53,001135+00:00 GICv3: CPU1: using allocated LPI pending table @0x00000004001e0000
2024-10-24T12:21:53,001150+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-24T12:21:53,001164+00:00 CPU1: Booted secondary processor 0x0000000001 [0x413fd0c1]
2024-10-24T12:21:53,001242+00:00 smp: Brought up 1 node, 2 CPUs
2024-10-24T12:21:53,001247+00:00 SMP: Total of 2 processors activated.
2024-10-24T12:21:53,001249+00:00 CPU features: detected: 32-bit EL0 Support
2024-10-24T12:21:53,001250+00:00 CPU features: detected: Instruction cache invalidation not required for I/D coherence
2024-10-24T12:21:53,001251+00:00 CPU features: detected: Data cache clean to the PoU not required for I/D coherence
2024-10-24T12:21:53,001252+00:00 CPU features: detected: Common not Private translations
2024-10-24T12:21:53,001253+00:00 CPU features: detected: CRC32 instructions
2024-10-24T12:21:53,001255+00:00 CPU features: detected: RCpc load-acquire (LDAPR)
2024-10-24T12:21:53,001256+00:00 CPU features: detected: LSE atomic instructions
2024-10-24T12:21:53,001257+00:00 CPU features: detected: Privileged Access Never
2024-10-24T12:21:53,001258+00:00 CPU features: detected: RAS Extension Support
2024-10-24T12:21:53,001260+00:00 CPU features: detected: Speculative Store Bypassing Safe (SSBS)
2024-10-24T12:21:53,001304+00:00 CPU: All CPU(s) started at EL1
2024-10-24T12:21:53,001307+00:00 alternatives: applying system-wide alternatives
2024-10-24T12:21:53,003459+00:00 devtmpfs: initialized
2024-10-24T12:21:53,003923+00:00 Registered cp15_barrier emulation handler
2024-10-24T12:21:53,003933+00:00 Registered setend emulation handler
2024-10-24T12:21:53,003968+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604462750000 ns
2024-10-24T12:21:53,003971+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-10-24T12:21:53,004189+00:00 pinctrl core: initialized pinctrl subsystem
2024-10-24T12:21:53,004233+00:00 SMBIOS 3.0.0 present.
2024-10-24T12:21:53,004236+00:00 DMI: Amazon EC2 t4g.medium/, BIOS 1.0 11/1/2018
2024-10-24T12:21:53,004334+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-10-24T12:21:53,004502+00:00 DMA: preallocated 512 KiB GFP_KERNEL pool for atomic allocations
2024-10-24T12:21:53,004525+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-10-24T12:21:53,004556+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-10-24T12:21:53,004565+00:00 audit: initializing netlink subsys (disabled)
2024-10-24T12:21:53,004615+00:00 audit: type=2000 audit(0.000:1): state=initialized audit_enabled=0 res=1
2024-10-24T12:21:53,004668+00:00 thermal_sys: Registered thermal governor 'fair_share'
2024-10-24T12:21:53,004670+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-10-24T12:21:53,004671+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-10-24T12:21:53,004679+00:00 cpuidle: using governor ladder
2024-10-24T12:21:53,004682+00:00 cpuidle: using governor menu
2024-10-24T12:21:53,004718+00:00 hw-breakpoint: found 6 breakpoint and 4 watchpoint registers.
2024-10-24T12:21:53,004750+00:00 ASID allocator initialised with 65536 entries
2024-10-24T12:21:53,004755+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-10-24T12:21:53,004767+00:00 Serial: AMBA PL011 UART driver
2024-10-24T12:21:53,010194+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2024-10-24T12:21:53,010197+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 1.00 GiB page
2024-10-24T12:21:53,010198+00:00 HugeTLB: registered 32.0 MiB page size, pre-allocated 0 pages
2024-10-24T12:21:53,010199+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 32.0 MiB page
2024-10-24T12:21:53,010200+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-10-24T12:21:53,010201+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 2.00 MiB page
2024-10-24T12:21:53,010202+00:00 HugeTLB: registered 64.0 KiB page size, pre-allocated 0 pages
2024-10-24T12:21:53,010203+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 64.0 KiB page
2024-10-24T12:21:53,010888+00:00 ACPI: Added _OSI(Module Device)
2024-10-24T12:21:53,010891+00:00 ACPI: Added _OSI(Processor Device)
2024-10-24T12:21:53,010892+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-10-24T12:21:53,010893+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-10-24T12:21:53,011471+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-10-24T12:21:53,011853+00:00 ACPI: Interpreter enabled
2024-10-24T12:21:53,011855+00:00 ACPI: Using GIC for interrupt routing
2024-10-24T12:21:53,011864+00:00 ACPI: MCFG table detected, 1 entries
2024-10-24T12:21:53,013310+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-0f])
2024-10-24T12:21:53,013320+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-10-24T12:21:53,013359+00:00 acpi PNP0A08:00: _OSC: platform does not support [SHPCHotplug LTR]
2024-10-24T12:21:53,013410+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug PME PCIeCapability]
2024-10-24T12:21:53,013485+00:00 acpi PNP0A08:00: ECAM area [mem 0x20000000-0x20ffffff] reserved by PNP0C02:00
2024-10-24T12:21:53,013491+00:00 acpi PNP0A08:00: ECAM at [mem 0x20000000-0x20ffffff] for [bus 00-0f]
2024-10-24T12:21:53,013505+00:00 ACPI: Remapped I/O 0x000000001fff0000 to [io  0x0000-0xffff window]
2024-10-24T12:21:53,013752+00:00 acpiphp: Slot [1] registered
2024-10-24T12:21:53,013763+00:00 acpiphp: Slot [2] registered
2024-10-24T12:21:53,013773+00:00 acpiphp: Slot [3] registered
2024-10-24T12:21:53,013783+00:00 acpiphp: Slot [4] registered
2024-10-24T12:21:53,013793+00:00 acpiphp: Slot [5] registered
2024-10-24T12:21:53,013802+00:00 acpiphp: Slot [6] registered
2024-10-24T12:21:53,013813+00:00 acpiphp: Slot [7] registered
2024-10-24T12:21:53,013822+00:00 acpiphp: Slot [8] registered
2024-10-24T12:21:53,013831+00:00 acpiphp: Slot [9] registered
2024-10-24T12:21:53,013840+00:00 acpiphp: Slot [10] registered
2024-10-24T12:21:53,013857+00:00 acpiphp: Slot [11] registered
2024-10-24T12:21:53,013866+00:00 acpiphp: Slot [12] registered
2024-10-24T12:21:53,013876+00:00 acpiphp: Slot [13] registered
2024-10-24T12:21:53,013886+00:00 acpiphp: Slot [14] registered
2024-10-24T12:21:53,013896+00:00 acpiphp: Slot [15] registered
2024-10-24T12:21:53,013905+00:00 acpiphp: Slot [16] registered
2024-10-24T12:21:53,013915+00:00 acpiphp: Slot [17] registered
2024-10-24T12:21:53,013925+00:00 acpiphp: Slot [18] registered
2024-10-24T12:21:53,013934+00:00 acpiphp: Slot [19] registered
2024-10-24T12:21:53,013944+00:00 acpiphp: Slot [20] registered
2024-10-24T12:21:53,013954+00:00 acpiphp: Slot [21] registered
2024-10-24T12:21:53,013963+00:00 acpiphp: Slot [22] registered
2024-10-24T12:21:53,013972+00:00 acpiphp: Slot [23] registered
2024-10-24T12:21:53,013982+00:00 acpiphp: Slot [24] registered
2024-10-24T12:21:53,013992+00:00 acpiphp: Slot [25] registered
2024-10-24T12:21:53,014002+00:00 acpiphp: Slot [26] registered
2024-10-24T12:21:53,014012+00:00 acpiphp: Slot [27] registered
2024-10-24T12:21:53,014022+00:00 acpiphp: Slot [28] registered
2024-10-24T12:21:53,014031+00:00 acpiphp: Slot [29] registered
2024-10-24T12:21:53,014041+00:00 acpiphp: Slot [30] registered
2024-10-24T12:21:53,014050+00:00 acpiphp: Slot [31] registered
2024-10-24T12:21:53,014065+00:00 PCI host bridge to bus 0000:00
2024-10-24T12:21:53,014067+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xffffffff window]
2024-10-24T12:21:53,014069+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0xffff window]
2024-10-24T12:21:53,014071+00:00 pci_bus 0000:00: root bus resource [mem 0x400000000000-0x407fffffffff window]
2024-10-24T12:21:53,014072+00:00 pci_bus 0000:00: root bus resource [bus 00-0f]
2024-10-24T12:21:53,014108+00:00 pci 0000:00:00.0: [1d0f:0200] type 00 class 0x060000
2024-10-24T12:21:53,014347+00:00 pci 0000:00:01.0: [1d0f:8250] type 00 class 0x070003
2024-10-24T12:21:53,014395+00:00 pci 0000:00:01.0: reg 0x10: [mem 0x80008000-0x80008fff]
2024-10-24T12:21:53,014598+00:00 pci 0000:00:04.0: [1d0f:8061] type 00 class 0x010802
2024-10-24T12:21:53,016068+00:00 pci 0000:00:04.0: reg 0x10: [mem 0x80004000-0x80007fff]
2024-10-24T12:21:53,022140+00:00 pci 0000:00:04.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T12:21:53,022333+00:00 pci 0000:00:05.0: [1d0f:ec20] type 00 class 0x020000
2024-10-24T12:21:53,022374+00:00 pci 0000:00:05.0: reg 0x10: [mem 0x80000000-0x80003fff]
2024-10-24T12:21:53,022568+00:00 pci 0000:00:05.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T12:21:53,022728+00:00 pci 0000:00:04.0: BAR 0: assigned [mem 0x80000000-0x80003fff]
2024-10-24T12:21:53,023293+00:00 pci 0000:00:05.0: BAR 0: assigned [mem 0x80004000-0x80007fff]
2024-10-24T12:21:53,023301+00:00 pci 0000:00:01.0: BAR 0: assigned [mem 0x80008000-0x80008fff]
2024-10-24T12:21:53,023310+00:00 pci_bus 0000:00: resource 4 [mem 0x80000000-0xffffffff window]
2024-10-24T12:21:53,023312+00:00 pci_bus 0000:00: resource 5 [io  0x0000-0xffff window]
2024-10-24T12:21:53,023314+00:00 pci_bus 0000:00: resource 6 [mem 0x400000000000-0x407fffffffff window]
2024-10-24T12:21:53,023346+00:00 ACPI: PCI: Interrupt link GSI0 configured for IRQ 35
2024-10-24T12:21:53,023353+00:00 ACPI: PCI: Interrupt link GSI1 configured for IRQ 36
2024-10-24T12:21:53,023358+00:00 ACPI: PCI: Interrupt link GSI2 configured for IRQ 37
2024-10-24T12:21:53,023364+00:00 ACPI: PCI: Interrupt link GSI3 configured for IRQ 38
2024-10-24T12:21:53,023735+00:00 iommu: Default domain type: Translated 
2024-10-24T12:21:53,023737+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2024-10-24T12:21:53,023775+00:00 pps_core: LinuxPPS API ver. 1 registered
2024-10-24T12:21:53,023777+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2024-10-24T12:21:53,023779+00:00 PTP clock support registered
2024-10-24T12:21:53,023809+00:00 EDAC MC: Ver: 3.0.0
2024-10-24T12:21:53,023986+00:00 Registered efivars operations
2024-10-24T12:21:53,024208+00:00 NetLabel: Initializing
2024-10-24T12:21:53,024210+00:00 NetLabel:  domain hash size = 128
2024-10-24T12:21:53,024211+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-10-24T12:21:53,024221+00:00 NetLabel:  unlabeled traffic allowed by default
2024-10-24T12:21:53,024266+00:00 vgaarb: loaded
2024-10-24T12:21:53,024374+00:00 clocksource: Switched to clocksource arch_sys_counter
2024-10-24T12:21:53,024446+00:00 VFS: Disk quotas dquot_6.6.0
2024-10-24T12:21:53,024455+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-10-24T12:21:53,024509+00:00 pnp: PnP ACPI init
2024-10-24T12:21:53,024585+00:00 system 00:00: [mem 0x20000000-0x2fffffff] could not be reserved
2024-10-24T12:21:53,024596+00:00 pnp: PnP ACPI: found 1 devices
2024-10-24T12:21:53,030914+00:00 NET: Registered PF_INET protocol family
2024-10-24T12:21:53,030949+00:00 IP idents hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-10-24T12:21:53,031685+00:00 tcp_listen_portaddr_hash hash table entries: 2048 (order: 3, 32768 bytes, linear)
2024-10-24T12:21:53,031698+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-10-24T12:21:53,031702+00:00 TCP established hash table entries: 32768 (order: 6, 262144 bytes, linear)
2024-10-24T12:21:53,031813+00:00 TCP bind hash table entries: 32768 (order: 8, 1048576 bytes, linear)
2024-10-24T12:21:53,032136+00:00 TCP: Hash tables configured (established 32768 bind 32768)
2024-10-24T12:21:53,032173+00:00 MPTCP token hash table entries: 4096 (order: 4, 98304 bytes, linear)
2024-10-24T12:21:53,032189+00:00 UDP hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-10-24T12:21:53,032220+00:00 UDP-Lite hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-10-24T12:21:53,032275+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-10-24T12:21:53,032283+00:00 NET: Registered PF_XDP protocol family
2024-10-24T12:21:53,032328+00:00 PCI: CLS 0 bytes, default 64
2024-10-24T12:21:53,032454+00:00 Trying to unpack rootfs image as initramfs...
2024-10-24T12:21:53,044708+00:00 hw perfevents: enabled with armv8_pmuv3_0 PMU driver, 3 counters available
2024-10-24T12:21:53,044730+00:00 kvm [1]: HYP mode not available
2024-10-24T12:21:53,044943+00:00 Initialise system trusted keyrings
2024-10-24T12:21:53,044949+00:00 Key type blacklist registered
2024-10-24T12:21:53,045143+00:00 workingset: timestamp_bits=44 max_order=20 bucket_order=0
2024-10-24T12:21:53,046140+00:00 zbud: loaded
2024-10-24T12:21:53,046301+00:00 SGI XFS with ACLs, security attributes, quota, no debug enabled
2024-10-24T12:21:53,046757+00:00 integrity: Platform Keyring initialized
2024-10-24T12:21:53,053776+00:00 Key type asymmetric registered
2024-10-24T12:21:53,053778+00:00 Asymmetric key parser 'x509' registered
2024-10-24T12:21:53,053797+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 248)
2024-10-24T12:21:53,053832+00:00 io scheduler mq-deadline registered
2024-10-24T12:21:53,053834+00:00 io scheduler kyber registered
2024-10-24T12:21:53,053859+00:00 io scheduler bfq registered
2024-10-24T12:21:53,055535+00:00 pl061_gpio ARMH0061:00: PL061 GPIO chip registered
2024-10-24T12:21:53,055581+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2024-10-24T12:21:53,056799+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing disabled
2024-10-24T12:21:53,057266+00:00 ACPI: \_SB_.PCI0.GSI2: Enabled at IRQ 37
2024-10-24T12:21:53,057294+00:00 serial 0000:00:01.0: enabling device (0010 -> 0012)
2024-10-24T12:21:53,057575+00:00 printk: console [ttyS0] disabled
2024-10-24T12:21:53,057721+00:00 0000:00:01.0: ttyS0 at MMIO 0x80008000 (irq = 14, base_baud = 115200) is a 16550A
2024-10-24T12:21:53,057826+00:00 printk: console [ttyS0] enabled
2024-10-24T12:21:53,058511+00:00 ACPI: \_SB_.PCI0.GSI0: Enabled at IRQ 35
2024-10-24T12:21:53,058829+00:00 nvme nvme0: pci function 0000:00:04.0
2024-10-24T12:21:53,059625+00:00 rtc-efi rtc-efi.0: registered as rtc0
2024-10-24T12:21:53,059677+00:00 rtc-efi rtc-efi.0: setting system clock to 2024-10-24T12:21:53 UTC (1729772513)
2024-10-24T12:21:53,059746+00:00 pstore: Registered efi as persistent store backend
2024-10-24T12:21:53,059759+00:00 hid: raw HID events driver (C) Jiri Kosina
2024-10-24T12:21:53,065066+00:00 nvme nvme0: 2/0/0 default/read/poll queues
2024-10-24T12:21:53,069323+00:00 NET: Registered PF_INET6 protocol family
2024-10-24T12:21:53,070275+00:00  nvme0n1: p1 p128
2024-10-24T12:21:53,145286+00:00 Freeing initrd memory: 11908K
2024-10-24T12:21:53,150733+00:00 Segment Routing with IPv6
2024-10-24T12:21:53,150747+00:00 In-situ OAM (IOAM) with IPv6
2024-10-24T12:21:53,150778+00:00 NET: Registered PF_PACKET protocol family
2024-10-24T12:21:53,151000+00:00 registered taskstats version 1
2024-10-24T12:21:53,151008+00:00 Loading compiled-in X.509 certificates
2024-10-24T12:21:53,162793+00:00 Loaded X.509 cert 'Amazon.com: Amazon Linux Kernel Signing Key: 3c3163dcb84c1049cf8b75ca4bcf01c5583dbccb'
2024-10-24T12:21:53,162930+00:00 zswap: loaded using pool lzo/zbud
2024-10-24T12:21:53,163072+00:00 Key type .fscrypt registered
2024-10-24T12:21:53,163074+00:00 Key type fscrypt-provisioning registered
2024-10-24T12:21:53,163261+00:00 pstore: Using crash dump compression: deflate
2024-10-24T12:21:53,163570+00:00 ima: secureboot mode disabled
2024-10-24T12:21:53,163573+00:00 ima: No TPM chip found, activating TPM-bypass!
2024-10-24T12:21:53,163577+00:00 ima: Allocated hash algorithm: sha256
2024-10-24T12:21:53,163587+00:00 ima: No architecture policies found
2024-10-24T12:21:53,305107+00:00 clk: Disabling unused clocks
2024-10-24T12:21:53,306321+00:00 Freeing unused kernel memory: 4480K
2024-10-24T12:21:53,306341+00:00 Run /init as init process
2024-10-24T12:21:53,306343+00:00   with arguments:
2024-10-24T12:21:53,306345+00:00     /init
2024-10-24T12:21:53,306346+00:00   with environment:
2024-10-24T12:21:53,306347+00:00     HOME=/
2024-10-24T12:21:53,306348+00:00     TERM=linux
2024-10-24T12:21:53,306349+00:00     BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64
2024-10-24T12:21:53,331991+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-24T12:21:53,331997+00:00 systemd[1]: Detected virtualization amazon.
2024-10-24T12:21:53,332000+00:00 systemd[1]: Detected architecture arm64.
2024-10-24T12:21:53,332002+00:00 systemd[1]: Running in initrd.
2024-10-24T12:21:53,332091+00:00 systemd[1]: No hostname configured, using default hostname.
2024-10-24T12:21:53,332130+00:00 systemd[1]: Hostname set to <localhost>.
2024-10-24T12:21:53,332199+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-24T12:21:53,430948+00:00 systemd[1]: Queued start job for default target initrd.target.
2024-10-24T12:21:53,445041+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-24T12:21:53,445090+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-b5c7fae5\x2d1de8\x2d4038\x2d8408\x2d06c720e69aff.device - /dev/disk/by-uuid/b5c7fae5-1de8-4038-8408-06c720e69aff...
2024-10-24T12:21:53,445121+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2024-10-24T12:21:53,445137+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2024-10-24T12:21:53,445148+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-24T12:21:53,445167+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-24T12:21:53,445182+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-24T12:21:53,445195+00:00 systemd[1]: Reached target timers.target - Timer Units.
2024-10-24T12:21:53,445481+00:00 systemd[1]: Listening on systemd-journald-audit.socket - Journal Audit Socket.
2024-10-24T12:21:53,445588+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2024-10-24T12:21:53,445664+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Socket.
2024-10-24T12:21:53,445755+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-24T12:21:53,445815+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-24T12:21:53,445831+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2024-10-24T12:21:53,445891+00:00 systemd[1]: kmod-static-nodes.service - Create List of Static Device Nodes was skipped because of an unmet condition check (ConditionFileNotEmpty=/lib/modules/6.1.112-122.189.amzn2023.aarch64/modules.devname).
2024-10-24T12:21:53,446743+00:00 systemd[1]: Started rngd.service - Hardware RNG Entropy Gatherer Daemon.
2024-10-24T12:21:53,447978+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-24T12:21:53,448101+00:00 systemd[1]: systemd-modules-load.service - Load Kernel Modules was skipped because no trigger condition checks were met.
2024-10-24T12:21:53,448781+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-24T12:21:53,449475+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2024-10-24T12:21:53,450182+00:00 systemd[1]: Starting systemd-vconsole-setup.service - Setup Virtual Console...
2024-10-24T12:21:53,458461+00:00 systemd[1]: Finished systemd-vconsole-setup.service - Setup Virtual Console.
2024-10-24T12:21:53,458599+00:00 systemd[1]: dracut-cmdline-ask.service - dracut ask for additional cmdline parameters was skipped because no trigger condition checks were met.
2024-10-24T12:21:53,459393+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2024-10-24T12:21:53,462603+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2024-10-24T12:21:53,477212+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-24T12:21:53,478416+00:00 audit: type=1130 audit(1729772513.909:2): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-journald comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:21:53,487567+00:00 audit: type=1130 audit(1729772513.919:3): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-sysctl comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:21:53,487940+00:00 audit: type=1130 audit(1729772513.919:4): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-tmpfiles-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:21:53,526193+00:00 audit: type=1130 audit(1729772513.959:5): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=dracut-cmdline comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:21:53,526200+00:00 audit: type=1334 audit(1729772513.959:6): prog-id=6 op=LOAD
2024-10-24T12:21:53,526202+00:00 audit: type=1334 audit(1729772513.959:7): prog-id=7 op=LOAD
2024-10-24T12:21:53,581236+00:00 audit: type=1130 audit(1729772514.009:8): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udevd comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:21:53,627744+00:00 audit: type=1130 audit(1729772514.049:9): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udev-trigger comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:21:53,865495+00:00 XFS (nvme0n1p1): Mounting V5 Filesystem
2024-10-24T12:21:53,928886+00:00 XFS (nvme0n1p1): Ending clean mount
2024-10-24T12:21:53,978130+00:00 audit: type=1130 audit(1729772514.409:10): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=initrd-parse-etc comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:21:54,126476+00:00 systemd-journald[325]: Received SIGTERM from PID 1 (systemd).
2024-10-24T12:21:54,318268+00:00 SELinux:  Class user_namespace not defined in policy.
2024-10-24T12:21:54,318274+00:00 SELinux: the above unknown classes and permissions will be allowed
2024-10-24T12:21:54,321215+00:00 SELinux:  policy capability network_peer_controls=1
2024-10-24T12:21:54,321220+00:00 SELinux:  policy capability open_perms=1
2024-10-24T12:21:54,321221+00:00 SELinux:  policy capability extended_socket_class=1
2024-10-24T12:21:54,321222+00:00 SELinux:  policy capability always_check_network=0
2024-10-24T12:21:54,321223+00:00 SELinux:  policy capability cgroup_seclabel=1
2024-10-24T12:21:54,321224+00:00 SELinux:  policy capability nnp_nosuid_transition=1
2024-10-24T12:21:54,321225+00:00 SELinux:  policy capability genfs_seclabel_symlinks=1
2024-10-24T12:21:54,321226+00:00 SELinux:  policy capability ioctl_skip_cloexec=0
2024-10-24T12:21:54,420832+00:00 systemd[1]: Successfully loaded SELinux policy in 146.311ms.
2024-10-24T12:21:54,484276+00:00 systemd[1]: Relabelled /dev, /dev/shm, /run, /sys/fs/cgroup in 23.633ms.
2024-10-24T12:21:54,494310+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-24T12:21:54,494316+00:00 systemd[1]: Detected virtualization amazon.
2024-10-24T12:21:54,494329+00:00 systemd[1]: Detected architecture arm64.
2024-10-24T12:21:54,497905+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-24T12:21:54,497980+00:00 systemd[1]: Installed transient /etc/machine-id file.
2024-10-24T12:21:54,581271+00:00 systemd[1]: bpf-lsm: Failed to link program; assuming BPF LSM is not available
2024-10-24T12:21:54,623775+00:00 zram_generator::config[821]: zram0: system has too much memory (3836MB), limit is 800MB, ignoring.
2024-10-24T12:21:54,719103+00:00 systemd[1]: /usr/lib/systemd/system/update-motd.service:40: Invalid CPU quota '25', ignoring.
2024-10-24T12:21:54,878342+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2024-10-24T12:21:54,878492+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2024-10-24T12:21:54,879014+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2024-10-24T12:21:54,879458+00:00 systemd[1]: Created slice system-getty.slice - Slice /system/getty.
2024-10-24T12:21:54,879792+00:00 systemd[1]: Created slice system-modprobe.slice - Slice /system/modprobe.
2024-10-24T12:21:54,880115+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2024-10-24T12:21:54,880438+00:00 systemd[1]: Created slice system-sshd\x2dkeygen.slice - Slice /system/sshd-keygen.
2024-10-24T12:21:54,880764+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2024-10-24T12:21:54,880918+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-24T12:21:54,881012+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2024-10-24T12:21:54,881451+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2024-10-24T12:21:54,881473+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2024-10-24T12:21:54,881500+00:00 systemd[1]: Reached target cryptsetup.target - Local Encrypted Volumes.
2024-10-24T12:21:54,881537+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2024-10-24T12:21:54,881555+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2024-10-24T12:21:54,881566+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2024-10-24T12:21:54,881579+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2024-10-24T12:21:54,881619+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-24T12:21:54,881646+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-24T12:21:54,881668+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-24T12:21:54,881686+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2024-10-24T12:21:54,882189+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2024-10-24T12:21:54,884096+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2024-10-24T12:21:54,885768+00:00 systemd[1]: Listening on systemd-coredump.socket - Process Core Dump Socket.
2024-10-24T12:21:54,885918+00:00 systemd[1]: Listening on systemd-initctl.socket - initctl Compatibility Named Pipe.
2024-10-24T12:21:54,886193+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Service Netlink Socket.
2024-10-24T12:21:54,887362+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-24T12:21:54,887734+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-24T12:21:54,888057+00:00 systemd[1]: Listening on systemd-userdbd.socket - User Database Manager Socket.
2024-10-24T12:21:54,889434+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2024-10-24T12:21:54,891138+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2024-10-24T12:21:54,893130+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2024-10-24T12:21:54,894406+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2024-10-24T12:21:54,895721+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2024-10-24T12:21:54,895818+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS was skipped because of an unmet condition check (ConditionPathExists=/etc/krb5.keytab).
2024-10-24T12:21:54,899438+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2024-10-24T12:21:54,900641+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2024-10-24T12:21:54,903027+00:00 systemd[1]: Starting modprobe@configfs.service - Load Kernel Module configfs...
2024-10-24T12:21:54,905487+00:00 systemd[1]: Starting modprobe@dm_mod.service - Load Kernel Module dm_mod...
2024-10-24T12:21:54,906929+00:00 systemd[1]: Starting modprobe@drm.service - Load Kernel Module drm...
2024-10-24T12:21:54,908307+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2024-10-24T12:21:54,909643+00:00 systemd[1]: Starting modprobe@fuse.service - Load Kernel Module fuse...
2024-10-24T12:21:54,911207+00:00 systemd[1]: Starting modprobe@loop.service - Load Kernel Module loop...
2024-10-24T12:21:54,913512+00:00 systemd[1]: Starting nfs-convert.service - Preprocess NFS configuration convertion...
2024-10-24T12:21:54,916119+00:00 systemd[1]: Starting systemd-fsck-root.service - File System Check on Root Device...
2024-10-24T12:21:54,916213+00:00 systemd[1]: Stopped systemd-journald.service - Journal Service.
2024-10-24T12:21:54,921031+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-24T12:21:54,924980+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2024-10-24T12:21:54,926346+00:00 systemd[1]: Starting systemd-network-generator.service - Generate network units from Kernel command line...
2024-10-24T12:21:54,927840+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2024-10-24T12:21:54,929725+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2024-10-24T12:21:54,929883+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2024-10-24T12:21:54,929972+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2024-10-24T12:21:54,930051+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2024-10-24T12:21:54,930122+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2024-10-24T12:21:54,930364+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2024-10-24T12:21:54,932033+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-10-24T12:21:54,932204+00:00 systemd[1]: Finished modprobe@drm.service - Load Kernel Module drm.
2024-10-24T12:21:54,932923+00:00 systemd[1]: nfs-convert.service: Deactivated successfully.
2024-10-24T12:21:54,933099+00:00 systemd[1]: Finished nfs-convert.service - Preprocess NFS configuration convertion.
2024-10-24T12:21:54,943661+00:00 systemd[1]: Finished systemd-network-generator.service - Generate network units from Kernel command line.
2024-10-24T12:21:54,944722+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2024-10-24T12:21:54,945023+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-10-24T12:21:54,945168+00:00 systemd[1]: Finished modprobe@efi_pstore.service - Load Kernel Module efi_pstore.
2024-10-24T12:21:54,946722+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-24T12:21:54,947624+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-10-24T12:21:54,947795+00:00 systemd[1]: Finished modprobe@configfs.service - Load Kernel Module configfs.
2024-10-24T12:21:54,949362+00:00 systemd[1]: Mounting sys-kernel-config.mount - Kernel Configuration File System...
2024-10-24T12:21:54,952236+00:00 systemd[1]: Mounted sys-kernel-config.mount - Kernel Configuration File System.
2024-10-24T12:21:54,969766+00:00 fuse: init (API version 7.38)
2024-10-24T12:21:54,975588+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2024-10-24T12:21:54,976677+00:00 device-mapper: uevent: version 1.0.3
2024-10-24T12:21:54,977368+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-24T12:21:54,982085+00:00 device-mapper: ioctl: 4.47.0-ioctl (2022-07-28) initialised: dm-devel@redhat.com
2024-10-24T12:21:54,992779+00:00 loop: module loaded
2024-10-24T12:21:55,065714+00:00 systemd-journald[844]: Received client request to flush runtime journal.
2024-10-24T12:21:55,344591+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input0
2024-10-24T12:21:55,346198+00:00 ACPI: button: Power Button [PWRB]
2024-10-24T12:21:55,346651+00:00 input: Sleep Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0E:00/input/input1
2024-10-24T12:21:55,348344+00:00 ACPI: button: Sleep Button [SLPB]
2024-10-24T12:21:55,371053+00:00 ACPI: \_SB_.PCI0.GSI1: Enabled at IRQ 36
2024-10-24T12:21:55,371533+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) v2.13.0g
2024-10-24T12:21:55,372118+00:00 ena 0000:00:05.0: enabling device (0010 -> 0012)
2024-10-24T12:21:55,423477+00:00 ena 0000:00:05.0: ENA device version: 0.10
2024-10-24T12:21:55,423953+00:00 ena 0000:00:05.0: ENA controller version: 0.0.1 implementation version 1
2024-10-24T12:21:55,504425+00:00 ena 0000:00:05.0: LLQ is not supported Fallback to host mode policy.
2024-10-24T12:21:55,515808+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) found at mem 80004000, mac addr 06:b1:08:3d:5e:ef
2024-10-24T12:21:55,604564+00:00 ena 0000:00:05.0 ens5: renamed from eth0
2024-10-24T12:21:56,005595+00:00 RPC: Registered named UNIX socket transport module.
2024-10-24T12:21:56,006138+00:00 RPC: Registered udp transport module.
2024-10-24T12:21:56,006536+00:00 RPC: Registered tcp transport module.
2024-10-24T12:21:56,006935+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2024-10-24T12:21:56,249878+00:00 ena 0000:00:05.0 ens5: Local page cache is disabled for less than 16 channels
2024-10-24T12:22:18,802769+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:22:18,803355+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:22:19,818516+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eni996a1b21394: link becomes ready
2024-10-24T12:22:22,689741+00:00 pci 0000:00:06.0: [1d0f:ec20] type 00 class 0x020000
2024-10-24T12:22:22,690378+00:00 pci 0000:00:06.0: reg 0x10: [mem 0x00000000-0x00003fff]
2024-10-24T12:22:22,691150+00:00 pci 0000:00:06.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T12:22:22,691905+00:00 pci 0000:00:06.0: BAR 0: assigned [mem 0x8000c000-0x8000ffff]
2024-10-24T12:22:22,692685+00:00 ena 0000:00:06.0: enabling device (0000 -> 0002)
2024-10-24T12:22:22,704217+00:00 ena 0000:00:06.0: ENA device version: 0.10
2024-10-24T12:22:22,704677+00:00 ena 0000:00:06.0: ENA controller version: 0.0.1 implementation version 1
2024-10-24T12:22:22,778515+00:00 ena 0000:00:06.0: LLQ is not supported Fallback to host mode policy.
2024-10-24T12:22:22,789912+00:00 ena 0000:00:06.0: Elastic Network Adapter (ENA) found at mem 8000c000, mac addr 06:5b:5c:5c:c3:c1
2024-10-24T12:22:22,848733+00:00 ena 0000:00:06.0 ens6: renamed from eth0
2024-10-24T12:22:23,139094+00:00 ena 0000:00:06.0 ens6: Local page cache is disabled for less than 16 channels
2024-10-24T12:22:23,140535+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): ens6: link becomes ready
2024-10-24T12:28:35,139990+00:00 Initializing XFRM netlink socket
2024-10-24T12:28:35,697308+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2024-10-24T12:28:36,768624+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2024-10-24T12:28:37,794706+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-10-24T12:28:38,693017+00:00 eth0: renamed from tmp368df
2024-10-24T12:28:38,742726+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcd323986c561c: link becomes ready
2024-10-24T12:28:38,814303+00:00 eth0: renamed from tmp35ac6
2024-10-24T12:28:38,863102+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:28:38,863888+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc5f3c6db5ce89: link becomes ready
2024-10-24T12:36:27,334062+00:00 eth0: renamed from tmpb66ad
2024-10-24T12:36:27,374458+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:36:27,375070+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcbcbd794b92e8: link becomes ready
2024-10-24T12:42:15,207768+00:00 eth0: renamed from tmpd313f
2024-10-24T12:42:15,257824+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:42:15,258401+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc064b28f0d2c8: link becomes ready
2024-10-24T12:48:21,721603+00:00 eth0: renamed from tmpcee92
2024-10-24T12:48:21,777860+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:48:21,778473+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc5008ec482fc8: link becomes ready
2024-10-24T12:48:22,921567+00:00 eth0: renamed from tmp8602b
2024-10-24T12:48:22,972475+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:48:22,973064+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc5973d7b4c452: link becomes ready
2024-10-24T12:48:23,026522+00:00 eth0: renamed from tmp55baa
2024-10-24T12:48:23,072161+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc83bde50db136: link becomes ready
2024-10-24T12:54:21,741793+00:00 printk: dmesg (15924): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
