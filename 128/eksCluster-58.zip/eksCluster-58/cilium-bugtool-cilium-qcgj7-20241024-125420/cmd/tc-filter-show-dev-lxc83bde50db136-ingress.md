filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc83bde50db136 direct-action not_in_hw id 3273 tag 233c4d05ad68ba15 jited 
