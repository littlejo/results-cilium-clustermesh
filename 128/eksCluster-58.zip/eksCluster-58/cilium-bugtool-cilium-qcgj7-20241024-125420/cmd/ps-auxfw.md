USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3276  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3266  0.0  0.4 1240432 15852 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3288  0.0  0.0   2340   780 ?        R    12:54   0:00  \_ cat /proc/net/xfrm_stat
root        3289  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root           1  4.1  7.3 1539060 287616 ?      Ssl  12:28   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         406  0.2  0.2 1229744 10204 ?       Sl   12:28   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
