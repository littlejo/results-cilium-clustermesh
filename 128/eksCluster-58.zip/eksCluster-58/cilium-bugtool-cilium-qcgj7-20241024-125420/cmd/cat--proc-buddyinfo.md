Node 0, zone      DMA     84    103     16     18      9      6      2      2      1      3     49 
Node 0, zone   Normal    541    316      9     14     12     10      5      1      3      1      7 
