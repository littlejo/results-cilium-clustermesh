CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a42c2fc_2b15_4cbb_ae45_a2881537b09a.slice/cri-containerd-48c4078fdb4050c3264064003abee6633032cfe08e2fc13499b5af3aefd5e87f.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a42c2fc_2b15_4cbb_ae45_a2881537b09a.slice/cri-containerd-35ac6badac4766c86f6f90f787916135347edb894a3f138de5c24c69b8332fde.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7dc7f873_457f_4e35_bb4d_ce812509468a.slice/cri-containerd-5b187e7d73683e00da9228cd4788b2afe570a4a6135082dbb4aeae52ece32f30.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7dc7f873_457f_4e35_bb4d_ce812509468a.slice/cri-containerd-60a2272856eea3be62dd9f14b3d77ebb522902b42862b6b5f38f9146e347c388.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf0535653_bbc5_487d_9cb9_001d5b5f7ae2.slice/cri-containerd-1e9ac8c210a7c1ee68069309b5e74474748f7af97ff7607726a1266520aa271e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf0535653_bbc5_487d_9cb9_001d5b5f7ae2.slice/cri-containerd-88105889f84ef76ee454e4f19574468213c6019c82aa6bf4c55cad3988c8a604.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod55e48f3b_de10_441c_82dc_f5d5060d3e79.slice/cri-containerd-368df7f8e653dee71b44e9ffd6c30fa85be8820b554c62a27911b5fd7bf50da4.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod55e48f3b_de10_441c_82dc_f5d5060d3e79.slice/cri-containerd-f5b6c6435b1136f8ef660da724ea61825eab2046803f1dfbc75d273c27570b83.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f755674_a50d_4d6f_8f63_10249144ded7.slice/cri-containerd-acfbccaf78eb829aee94ed917f4ba982e20582ef8251538f086a32312a0b2007.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f755674_a50d_4d6f_8f63_10249144ded7.slice/cri-containerd-70d8a7b7a0e2757ea17316bbd47ad805ce196b9ce98dccf585c2f8155b2446c7.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f755674_a50d_4d6f_8f63_10249144ded7.slice/cri-containerd-d313f492fa7c2e5c8563fdfd7eaa4fa111e6bbda1cf6098bb52b2cf5b356ba08.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f755674_a50d_4d6f_8f63_10249144ded7.slice/cri-containerd-954166d4b248a060bdcdcbd9de42944693ff859726089032930606b812e5f693.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2676b18f_a8f6_4c8d_b8d7_54e6d0a5b72b.slice/cri-containerd-88922ace9feb0b52604fd44e23864399c2f2eb8ac92768f5d23d47e5c30751c3.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2676b18f_a8f6_4c8d_b8d7_54e6d0a5b72b.slice/cri-containerd-2e55d0d62ff3f9604edc6baf56802a9e7f4867eb0de9cb4d839bf8af042b44c1.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5238390_d27e_440d_8ca2_2f7b7e722d57.slice/cri-containerd-8e4d745c147b5c873f93478bc30d3a42512adaca3abed569b8bb97b7b9db8448.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5238390_d27e_440d_8ca2_2f7b7e722d57.slice/cri-containerd-0c459387c1224c04050da259145d8a28596c9a5822b088044a553aa53df97e00.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5238390_d27e_440d_8ca2_2f7b7e722d57.slice/cri-containerd-55baa0d6523ff2c8ecc95f4eebf5f67cb12e02bd3505533d9ee85eb4fe3d5fd6.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9b035f7_0dff_4c84_8b73_608a79149d57.slice/cri-containerd-fc1e6ebfbaf65cb09240e393eecc0f790a758e2cb41b66aedf248d3552f0bd90.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9b035f7_0dff_4c84_8b73_608a79149d57.slice/cri-containerd-cee9296bf31ac88f45da0b914e7ebba2ee49173ebd0edf68e4c00e5c1651658b.scope
    676      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e2e8fee_d40d_4755_a0f2_45dc731b4ec1.slice/cri-containerd-9ac4a4cae6209d69a2e2a4ae88277e2fb1d67aa473c5b60d59997b2a4b989105.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e2e8fee_d40d_4755_a0f2_45dc731b4ec1.slice/cri-containerd-8602bde9740084141123ae173f7450132883da59aac5515d571ef16fb767d4d5.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79c8c1da_fe6a_4438_90e3_9dc8fa27d4b6.slice/cri-containerd-2e1dc6220872f50989e18e37a76d2bafd2c8de733c33a6be4b3815a46f4c83e5.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79c8c1da_fe6a_4438_90e3_9dc8fa27d4b6.slice/cri-containerd-77d1872e24cb4d681bdab69d8678afc9505db584d85f999ad78a9e449511d124.scope
    106      cgroup_device   multi                                          
