 12:54:22 up 32 min,  0 users,  load average: 0.28, 0.37, 0.22
