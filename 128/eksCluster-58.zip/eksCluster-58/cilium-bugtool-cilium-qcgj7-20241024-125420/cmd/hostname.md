ip-172-31-169-93.eu-west-3.compute.internal
