top - 12:54:22 up 32 min,  0 users,  load average: 0.28, 0.37, 0.22
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 40.0 sy,  0.0 ni,  3.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    293.1 free,   1046.4 used,   2496.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2608.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 294804  80516 S  80.0   7.5   1:04.80 cilium-+
   3276 root      20   0 1229640  18264   4004 S  13.3   0.5   0:00.02 gops
    406 root      20   0 1229744  10204   3900 S   0.0   0.3   0:04.24 cilium-+
   3266 root      20   0 1240432  15852  10844 S   0.0   0.4   0:00.02 cilium-+
   3301 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3326 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
