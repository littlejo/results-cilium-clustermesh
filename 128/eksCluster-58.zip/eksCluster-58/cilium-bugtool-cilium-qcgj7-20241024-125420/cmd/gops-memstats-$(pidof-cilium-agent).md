alloc: 83.03MB (87063400 bytes)
total-alloc: 3.06GB (3288019384 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74710636
frees: 74128825
heap-alloc: 83.03MB (87063400 bytes)
heap-sys: 172.70MB (181084160 bytes)
heap-idle: 41.76MB (43786240 bytes)
heap-in-use: 130.94MB (137297920 bytes)
heap-released: 6.45MB (6758400 bytes)
heap-objects: 581811
stack-in-use: 35.28MB (36995072 bytes)
stack-sys: 35.28MB (36995072 bytes)
stack-mspan-inuse: 2.11MB (2208640 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1022.68KB (1047225 bytes)
gc-sys: 5.50MB (5764168 bytes)
next-gc: when heap-alloc >= 149.34MB (156593352 bytes)
last-gc: 2024-10-24 12:54:18.305945141 +0000 UTC
gc-pause-total: 14.894532ms
gc-pause: 132934
gc-pause-end: 1729774458305945141
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005815667473613296
enable-gc: true
debug-gc: false
