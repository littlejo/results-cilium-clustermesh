IP ADDRESS         LOCAL ENDPOINT INFO
10.58.0.94:0       (localhost)                                                                                        
10.58.0.131:0      id=2929  sec_id=4     flags=0x0000 ifindex=10  mac=B2:C4:7B:83:4A:74 nodemac=2A:71:75:EA:F9:E4     
172.31.160.158:0   (localhost)                                                                                        
10.58.0.141:0      id=3291  sec_id=3893154 flags=0x0000 ifindex=20  mac=FA:62:BE:B4:13:B9 nodemac=6E:C4:DE:85:44:E9   
10.58.0.186:0      id=438   sec_id=3876061 flags=0x0000 ifindex=14  mac=9E:E9:4A:66:5B:24 nodemac=3A:77:54:60:03:48   
10.58.0.247:0      id=119   sec_id=3876061 flags=0x0000 ifindex=12  mac=CA:7A:3D:84:EB:6A nodemac=C2:E8:87:9C:45:25   
10.58.0.151:0      id=312   sec_id=3887242 flags=0x0000 ifindex=22  mac=AE:BA:AC:90:25:13 nodemac=EA:99:91:EA:5A:23   
10.58.0.29:0       id=996   sec_id=3920945 flags=0x0000 ifindex=24  mac=32:7F:A5:CB:F0:2E nodemac=4A:C0:D8:D1:9A:E9   
10.58.0.196:0      id=22    sec_id=3889032 flags=0x0000 ifindex=18  mac=16:00:37:5D:07:BC nodemac=A2:09:1F:AF:6A:9E   
172.31.169.93:0    (localhost)                                                                                        
