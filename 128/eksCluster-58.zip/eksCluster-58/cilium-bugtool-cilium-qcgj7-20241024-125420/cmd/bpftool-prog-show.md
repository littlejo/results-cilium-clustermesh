32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:55+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:55+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:56+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:56+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:56+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:56+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:00+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag 84d0e001a79cbf0f  gpl
	loaded_at 2024-10-24T12:28:40+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:28:40+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
483: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:28:40+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:28:40+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
500: sched_cls  name tail_handle_arp  tag febc5124ea30a236  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 147
501: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 148
502: sched_cls  name tail_ipv4_to_endpoint  tag d2adc645b3a07064  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 149
504: sched_cls  name tail_ipv4_ct_ingress  tag bc6c37079e0c2416  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 151
505: sched_cls  name cil_from_container  tag f8182cfa0a42a78c  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,76
	btf_id 152
506: sched_cls  name tail_handle_ipv4  tag 60dadc1aadae7de7  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 153
508: sched_cls  name tail_handle_ipv4_cont  tag 801354cd0f9c58b7  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 154
512: sched_cls  name handle_policy  tag 54c228d115847593  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 156
514: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 160
515: sched_cls  name __send_drop_notify  tag 43ad0a6f59815480  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 161
518: sched_cls  name tail_handle_arp  tag 420a8233043eaa7a  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 165
519: sched_cls  name tail_ipv4_ct_ingress  tag 4232650ca74031e5  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 166
520: sched_cls  name tail_handle_ipv4  tag 9f1e616d21dfa556  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 167
521: sched_cls  name cil_from_container  tag 68f148abd905f89e  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 168
522: sched_cls  name tail_handle_ipv4_cont  tag cb7aef14b6cb575c  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,109,41,101,82,83,39,76,74,77,110,40,37,38,81
	btf_id 169
523: sched_cls  name handle_policy  tag ae63055e176a1278  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,101,39,84,75,40,37,38
	btf_id 170
524: sched_cls  name tail_ipv4_to_endpoint  tag 98bba781fdc91339  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,101,39,110,40,37,38
	btf_id 171
525: sched_cls  name __send_drop_notify  tag 952a42b5d5cdfe2e  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 172
526: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 173
528: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
531: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
532: sched_cls  name tail_ipv4_ct_egress  tag 7b38e1d8400879fe  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 175
533: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
536: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
537: sched_cls  name tail_ipv4_to_endpoint  tag a5e8e1ae8a61cdcc  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,114,41,82,83,80,100,39,113,40,37,38
	btf_id 177
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 178
539: sched_cls  name tail_handle_ipv4_cont  tag a7461ead10f39ad6  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,114,41,100,82,83,39,76,74,77,113,40,37,38,81
	btf_id 179
540: sched_cls  name __send_drop_notify  tag 3d31500869c37246  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 180
541: sched_cls  name tail_ipv4_ct_ingress  tag b206560e7d3152cf  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 181
542: sched_cls  name tail_handle_ipv4  tag 82a330af32100578  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 182
543: sched_cls  name tail_ipv4_ct_egress  tag 7b38e1d8400879fe  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 183
544: sched_cls  name cil_from_container  tag a1439ecbf4410d25  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 184
545: sched_cls  name tail_handle_arp  tag 751b31513403c1ac  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 185
547: sched_cls  name handle_policy  tag 2132692ed1dedd28  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,114,41,80,100,39,84,75,40,37,38
	btf_id 187
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 189
559: sched_cls  name __send_drop_notify  tag 62f9c380b67113f5  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
560: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 193
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 194
562: sched_cls  name tail_handle_ipv4_from_host  tag 4c4981aa3e441826  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 195
563: sched_cls  name tail_handle_ipv4_from_host  tag 4c4981aa3e441826  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 197
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 198
567: sched_cls  name __send_drop_notify  tag 62f9c380b67113f5  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
569: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
571: sched_cls  name tail_handle_ipv4_from_host  tag 4c4981aa3e441826  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 206
572: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 207
573: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 208
575: sched_cls  name __send_drop_notify  tag 62f9c380b67113f5  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
577: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 213
579: sched_cls  name __send_drop_notify  tag 62f9c380b67113f5  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
582: sched_cls  name tail_handle_ipv4_from_host  tag 4c4981aa3e441826  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 218
583: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 219
623: sched_cls  name tail_ipv4_to_endpoint  tag 3f47f8af681943d8  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 233
624: sched_cls  name cil_from_container  tag 9d1699b53eec22a2  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 234
625: sched_cls  name handle_policy  tag a617a8bd64ca53c5  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 235
626: sched_cls  name tail_ipv4_ct_egress  tag 24e8bf26812f64cd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 236
628: sched_cls  name __send_drop_notify  tag fc15958038b6fbe8  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 238
629: sched_cls  name tail_handle_arp  tag 4c1534f9e3963987  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 239
630: sched_cls  name tail_ipv4_ct_ingress  tag 781d3866aab8459f  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 240
631: sched_cls  name tail_handle_ipv4  tag 78451c263c141f71  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 241
632: sched_cls  name tail_handle_ipv4_cont  tag 4f3b0b271e2a5bc0  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 242
633: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 243
634: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
637: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
673: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
676: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3264: sched_cls  name tail_handle_arp  tag 34aada3f3d4fe782  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,623
	btf_id 3053
3265: sched_cls  name __send_drop_notify  tag ee88b883320e61f8  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3054
3267: sched_cls  name tail_handle_ipv4  tag ba09179886b87f61  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,623
	btf_id 3055
3269: sched_cls  name tail_ipv4_to_endpoint  tag e4170cf63c2dc993  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,624,41,82,83,80,152,39,623,40,37,38
	btf_id 3059
3272: sched_cls  name tail_handle_ipv4_cont  tag 53536236f74753ca  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,624,41,152,82,83,39,76,74,77,623,40,37,38,81
	btf_id 3061
3273: sched_cls  name cil_from_container  tag 233c4d05ad68ba15  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 623,76
	btf_id 3064
3277: sched_cls  name handle_policy  tag bb53b7e336e82b06  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,623,82,83,624,41,80,152,39,84,75,40,37,38
	btf_id 3065
3282: sched_cls  name tail_ipv4_ct_ingress  tag 3366cd72d583f546  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,623,82,83,624,84
	btf_id 3070
3284: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,623
	btf_id 3074
3286: sched_cls  name tail_ipv4_ct_egress  tag 5683ab8ca05ab24e  gpl
	loaded_at 2024-10-24T12:51:18+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,623,82,83,624,84
	btf_id 3075
3320: sched_cls  name tail_handle_ipv4_cont  tag bc2cb21984ab3b43  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,145,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3116
3321: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3117
3322: sched_cls  name __send_drop_notify  tag 29bad39551e68d28  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3118
3323: sched_cls  name cil_from_container  tag 473add937efb9267  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3119
3324: sched_cls  name tail_handle_arp  tag efc692d3f2ff44f4  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3120
3325: sched_cls  name tail_handle_ipv4  tag a3771e79a68acd59  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3115
3326: sched_cls  name cil_from_container  tag 34192eb2beadba84  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3122
3327: sched_cls  name __send_drop_notify  tag 609b981ddc837c08  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3123
3328: sched_cls  name tail_ipv4_ct_ingress  tag 0457c511922e870c  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3121
3329: sched_cls  name tail_handle_ipv4_cont  tag e0ae4b2ecd2b722c  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,149,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3124
3330: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3126
3331: sched_cls  name tail_handle_ipv4  tag ead61a382dead9de  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3125
3333: sched_cls  name tail_ipv4_to_endpoint  tag ce234d8b0391610c  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,145,39,633,40,37,38
	btf_id 3128
3334: sched_cls  name tail_ipv4_ct_egress  tag a2f16e3490205bf0  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3129
3335: sched_cls  name tail_handle_arp  tag e05c8ab7964a477e  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3131
3336: sched_cls  name handle_policy  tag 09247bf525afecd3  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,145,39,84,75,40,37,38
	btf_id 3130
3337: sched_cls  name tail_ipv4_ct_egress  tag ceff36a9680c5ff0  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3133
3338: sched_cls  name tail_ipv4_to_endpoint  tag c0c881c2aa681cd4  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,149,39,636,40,37,38
	btf_id 3132
3339: sched_cls  name tail_ipv4_ct_ingress  tag 81d8b7d420918262  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3134
3340: sched_cls  name handle_policy  tag d5de764cd55ba2b4  gpl
	loaded_at 2024-10-24T12:51:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,149,39,84,75,40,37,38
	btf_id 3135
