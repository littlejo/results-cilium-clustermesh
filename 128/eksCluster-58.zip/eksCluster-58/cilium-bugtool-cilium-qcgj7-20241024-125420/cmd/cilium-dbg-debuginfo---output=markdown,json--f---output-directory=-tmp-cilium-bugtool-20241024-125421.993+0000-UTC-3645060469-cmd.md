markdown output at /tmp/cilium-bugtool-20241024-125421.993+0000-UTC-3645060469/cmd/cilium-debuginfo-20241024-125422.938+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125421.993+0000-UTC-3645060469/cmd/cilium-debuginfo-20241024-125422.938+0000-UTC.json
