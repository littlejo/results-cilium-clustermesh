Endpoint ID: 22
Path: /sys/fs/bpf/tc/globals/cilium_policy_00022

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5506192   56659     0        
Allow    Ingress     1          ANY          NONE         disabled    4983577   52360     0        
Allow    Egress      0          ANY          NONE         disabled    5713714   58899     0        


Endpoint ID: 119
Path: /sys/fs/bpf/tc/globals/cilium_policy_00119

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3928     39        0        
Allow    Ingress     1          ANY          NONE         disabled    147271   1692      0        
Allow    Egress      0          ANY          NONE         disabled    19899    221       0        


Endpoint ID: 312
Path: /sys/fs/bpf/tc/globals/cilium_policy_00312

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 438
Path: /sys/fs/bpf/tc/globals/cilium_policy_00438

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1968     21        0        
Allow    Ingress     1          ANY          NONE         disabled    147469   1695      0        
Allow    Egress      0          ANY          NONE         disabled    20337    226       0        


Endpoint ID: 996
Path: /sys/fs/bpf/tc/globals/cilium_policy_00996

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    350401   4095      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1234
Path: /sys/fs/bpf/tc/globals/cilium_policy_01234

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2929
Path: /sys/fs/bpf/tc/globals/cilium_policy_02929

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6190278   76494     0        
Allow    Ingress     1          ANY          NONE         disabled    65580     791       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3291
Path: /sys/fs/bpf/tc/globals/cilium_policy_03291

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


