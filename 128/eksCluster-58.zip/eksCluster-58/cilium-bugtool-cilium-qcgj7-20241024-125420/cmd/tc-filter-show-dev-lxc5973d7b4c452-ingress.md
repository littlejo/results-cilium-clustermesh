filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5973d7b4c452 direct-action not_in_hw id 3326 tag 34192eb2beadba84 jited 
