[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod55e48f3b_de10_441c_82dc_f5d5060d3e79.slice/cri-containerd-f5b6c6435b1136f8ef660da724ea61825eab2046803f1dfbc75d273c27570b83.scope"
      }
    ],
    "ips": [
      "10.58.0.247"
    ],
    "name": "coredns-cc6ccd49c-8c2zr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e2e8fee_d40d_4755_a0f2_45dc731b4ec1.slice/cri-containerd-9ac4a4cae6209d69a2e2a4ae88277e2fb1d67aa473c5b60d59997b2a4b989105.scope"
      }
    ],
    "ips": [
      "10.58.0.151"
    ],
    "name": "client2-57cf4468f-89fm9",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9b035f7_0dff_4c84_8b73_608a79149d57.slice/cri-containerd-fc1e6ebfbaf65cb09240e393eecc0f790a758e2cb41b66aedf248d3552f0bd90.scope"
      }
    ],
    "ips": [
      "10.58.0.141"
    ],
    "name": "client-974f6c69d-xrkt4",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a42c2fc_2b15_4cbb_ae45_a2881537b09a.slice/cri-containerd-48c4078fdb4050c3264064003abee6633032cfe08e2fc13499b5af3aefd5e87f.scope"
      }
    ],
    "ips": [
      "10.58.0.186"
    ],
    "name": "coredns-cc6ccd49c-sxlsm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f755674_a50d_4d6f_8f63_10249144ded7.slice/cri-containerd-70d8a7b7a0e2757ea17316bbd47ad805ce196b9ce98dccf585c2f8155b2446c7.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f755674_a50d_4d6f_8f63_10249144ded7.slice/cri-containerd-954166d4b248a060bdcdcbd9de42944693ff859726089032930606b812e5f693.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f755674_a50d_4d6f_8f63_10249144ded7.slice/cri-containerd-acfbccaf78eb829aee94ed917f4ba982e20582ef8251538f086a32312a0b2007.scope"
      }
    ],
    "ips": [
      "10.58.0.196"
    ],
    "name": "clustermesh-apiserver-bf59f86c-72l2b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5238390_d27e_440d_8ca2_2f7b7e722d57.slice/cri-containerd-8e4d745c147b5c873f93478bc30d3a42512adaca3abed569b8bb97b7b9db8448.scope"
      },
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5238390_d27e_440d_8ca2_2f7b7e722d57.slice/cri-containerd-0c459387c1224c04050da259145d8a28596c9a5822b088044a553aa53df97e00.scope"
      }
    ],
    "ips": [
      "10.58.0.29"
    ],
    "name": "echo-same-node-86d9cc975c-4ntm4",
    "namespace": "cilium-test-1"
  }
]

