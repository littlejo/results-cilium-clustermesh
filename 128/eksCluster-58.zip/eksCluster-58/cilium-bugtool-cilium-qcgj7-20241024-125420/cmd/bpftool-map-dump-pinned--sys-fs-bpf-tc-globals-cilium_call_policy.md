key: 16 00 00 00  value: 71 02 00 00
key: 77 00 00 00  value: 23 02 00 00
key: 38 01 00 00  value: 0c 0d 00 00
key: b6 01 00 00  value: 0b 02 00 00
key: e4 03 00 00  value: cd 0c 00 00
key: 71 0b 00 00  value: 00 02 00 00
key: db 0c 00 00  value: 08 0d 00 00
Found 7 elements
