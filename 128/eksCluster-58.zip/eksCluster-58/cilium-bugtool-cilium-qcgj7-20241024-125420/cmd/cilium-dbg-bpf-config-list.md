KEY             VALUE
AgentLiveness   1951421962974
UTimeOffset     3378461939453125
