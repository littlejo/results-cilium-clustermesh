CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc5623c4d_42f3_48ee_9f3f_59fa225d3df6.slice/cri-containerd-2b04179d52cf2e0fe81d0bca500f654d7464399874a2c127ccf877669ee9e5a2.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc5623c4d_42f3_48ee_9f3f_59fa225d3df6.slice/cri-containerd-61c33d54ab33f7126c1485d3691170f1cf6fbbb9ad6e5f4c6f22354aee680bbf.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4018b679_fb66_41b5_8a87_0a0e61a6e4ea.slice/cri-containerd-1783f139e24920137ca4310d9a8f7ce473769e52555180c5d2fb98ee0275421e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4018b679_fb66_41b5_8a87_0a0e61a6e4ea.slice/cri-containerd-739399ac8af54c6f3e5073b1995d33146c723b9fa79979284cc4fc4de3f308c4.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod756929be_2655_4c68_a9af_d08ab832f77f.slice/cri-containerd-10355291097a5b93502ddf39db0072b848ecef0ed59b8c23ecca225f3fe8f12d.scope
    566      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod756929be_2655_4c68_a9af_d08ab832f77f.slice/cri-containerd-77ea0a7ee9ffbd22d39cea07dd0480adb2adc57ceb9ad9b4a07f854456e8e84d.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30b6ad00_9006_4212_910a_8c83c3a7a686.slice/cri-containerd-bfadc46608e26b3a94743804b3d1943a55851479842cf7d4e6180e9dee7a6c08.scope
    495      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30b6ad00_9006_4212_910a_8c83c3a7a686.slice/cri-containerd-5548d109df389a030a0ed5c7df653fc2425b1d7173a32cc6b4c65ec6be9d993d.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode20c53e8_9c63_4c8b_a401_c8364894a041.slice/cri-containerd-d3337fcae9d42ac1a22140c3e25fddc398b6f7023bf3bad5f71541f6ae39cd8a.scope
    648      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode20c53e8_9c63_4c8b_a401_c8364894a041.slice/cri-containerd-42b441ff45164ad11a387e745ca1a65d89395e3376d34c845465751c82ce420d.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode20c53e8_9c63_4c8b_a401_c8364894a041.slice/cri-containerd-bbec4a0adbebf94369d8740ec8613c01077245415fbe1e11845bbd91d711c478.scope
    672      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode20c53e8_9c63_4c8b_a401_c8364894a041.slice/cri-containerd-ab44b70ca9deafd83804576069b0d1209d594fe02fd284a50384304c0ce60ce6.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda587e955_52f1_4d8f_b8a0_1c867f512cbc.slice/cri-containerd-d497b444e9da14f5ab8e85cafbc1297cc65aeb3c1658af9d29528a66cb7cfbfe.scope
    712      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda587e955_52f1_4d8f_b8a0_1c867f512cbc.slice/cri-containerd-95cfbf5761b277d955d3f4fcb7721b67c254cbc327200da637bef42ed7de8950.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46c8a503_9c39_4e92_bfa8_b1896ea61480.slice/cri-containerd-5a35f062fd243adbe04f6eb7000e3e56123065c49828248aea4e74e3947a9aac.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46c8a503_9c39_4e92_bfa8_b1896ea61480.slice/cri-containerd-9b7939d23218f1ec1739096fb3f41c84a961f2969c0a96e3b606f6d891e0828d.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ba004a3_8bcf_4dbe_a0e6_e1c07d8ad4fe.slice/cri-containerd-82efdc035bbe1ce6abe1812bcef0ca02d533ca45c023f6f915e730a1c0b0ce29.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ba004a3_8bcf_4dbe_a0e6_e1c07d8ad4fe.slice/cri-containerd-2961337b2bda48c364b2a9c38b6e56a4c0d25ca62fe82e7bbec1a2b0d84710ef.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda64094ed_c4dc_4203_9a5f_80731b7d7e63.slice/cri-containerd-ab526f07f9d80618a0e4c34fb8698d33379fd224750517dc6cb8addc021db938.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda64094ed_c4dc_4203_9a5f_80731b7d7e63.slice/cri-containerd-ca708a6556358d26e01660947862e312922fb4c5a156d5e2aebb0347d6a445d6.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod359d938c_57ac_4a95_b3e2_a1cb16f59956.slice/cri-containerd-fa84360803906eb562261f02a8a8c95e0de97bd53981aff1d9e2c3a1f03cb646.scope
    729      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod359d938c_57ac_4a95_b3e2_a1cb16f59956.slice/cri-containerd-d66e1b4c294b3072b9b2866d0a3d43bce18bcd4b255a2cea50c1e41294b81ca7.scope
    733      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod359d938c_57ac_4a95_b3e2_a1cb16f59956.slice/cri-containerd-7c80cc2392cc231ee20aac8f1a75237ef235d5fb61ea638b203cecbb79040992.scope
    713      cgroup_device   multi                                          
