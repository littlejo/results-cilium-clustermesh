32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:07+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:07+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:08+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:08+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:08+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:08+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:12+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
492: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
495: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
496: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
499: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
500: sched_cls  name tail_handle_ipv4  tag 336a4b82b1b9a7bc  gpl
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 136
501: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 137
502: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 138
503: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:32:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 139
526: sched_cls  name handle_policy  tag a329848e32b83067  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,91,39,84,75,40,37,38
	btf_id 165
527: sched_cls  name tail_ipv4_ct_ingress  tag 88149400279846ae  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 166
528: sched_cls  name tail_handle_ipv4_cont  tag 84eac0f53b47f1cd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,111,41,91,82,83,39,76,74,77,112,40,37,38,81
	btf_id 167
529: sched_cls  name tail_ipv4_ct_egress  tag 8a1bda7b542b0319  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 168
530: sched_cls  name tail_handle_arp  tag 5142384094dd1733  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 169
531: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 170
533: sched_cls  name __send_drop_notify  tag 2622f86580ccdba8  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 172
534: sched_cls  name cil_from_container  tag b73845def9fbe236  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 173
535: sched_cls  name tail_handle_ipv4  tag e2a37c1afa0bafab  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 174
536: sched_cls  name tail_ipv4_to_endpoint  tag 167ec0e4378724ff  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,91,39,112,40,37,38
	btf_id 175
537: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
540: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
541: sched_cls  name tail_handle_ipv4  tag 59b0d8cd44cea35b  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 177
542: sched_cls  name tail_ipv4_ct_ingress  tag 6257f38adb854c67  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 178
543: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 179
544: sched_cls  name tail_ipv4_to_endpoint  tag ce90d7657fd5068f  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,113,41,82,83,80,105,39,114,40,37,38
	btf_id 180
546: sched_cls  name __send_drop_notify  tag 203c16d8ac822d88  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 182
547: sched_cls  name tail_handle_arp  tag b3dc452c92d9d948  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 183
548: sched_cls  name tail_handle_ipv4_cont  tag 50ddac9cd6444cc6  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,113,41,105,82,83,39,76,74,77,114,40,37,38,81
	btf_id 184
549: sched_cls  name cil_from_container  tag 8a819bbed13559d2  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 114,76
	btf_id 185
550: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 186
551: sched_cls  name handle_policy  tag 33afff9129260a7f  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,114,82,83,113,41,80,105,39,84,75,40,37,38
	btf_id 187
552: sched_cls  name tail_handle_ipv4  tag 362f738d9465f0ca  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 189
553: sched_cls  name tail_ipv4_ct_egress  tag 8a1bda7b542b0319  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 190
554: sched_cls  name tail_handle_arp  tag c01ac791a8033c93  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 191
555: sched_cls  name handle_policy  tag d259ee8a8bbcbebc  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,117,82,83,116,41,80,106,39,84,75,40,37,38
	btf_id 192
556: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 193
558: sched_cls  name tail_handle_ipv4_cont  tag 036a9ec4f0cd86b3  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,106,82,83,39,76,74,77,117,40,37,38,81
	btf_id 195
559: sched_cls  name tail_ipv4_ct_ingress  tag 098a793c0e00b43c  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 196
560: sched_cls  name tail_ipv4_to_endpoint  tag 927827afe9358455  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,106,39,117,40,37,38
	btf_id 197
561: sched_cls  name __send_drop_notify  tag 840db5aff420a6e8  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
562: sched_cls  name cil_from_container  tag fb2832ae24677b9a  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 117,76
	btf_id 199
563: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
566: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
567: sched_cls  name __send_drop_notify  tag aeab84dbc4e45d23  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
568: sched_cls  name tail_handle_ipv4_from_host  tag 88ba745f37043331  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 202
569: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,119
	btf_id 203
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 204
573: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 207
575: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 210
576: sched_cls  name __send_drop_notify  tag aeab84dbc4e45d23  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
577: sched_cls  name tail_handle_ipv4_from_host  tag 88ba745f37043331  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 212
579: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 214
581: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 217
582: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 218
585: sched_cls  name __send_drop_notify  tag aeab84dbc4e45d23  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 221
586: sched_cls  name tail_handle_ipv4_from_host  tag 88ba745f37043331  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 222
588: sched_cls  name tail_handle_ipv4_from_host  tag 88ba745f37043331  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,126
	btf_id 225
590: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,126
	btf_id 227
591: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,126,75
	btf_id 228
594: sched_cls  name __send_drop_notify  tag aeab84dbc4e45d23  gpl
	loaded_at 2024-10-24T12:32:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 231
634: sched_cls  name tail_ipv4_ct_egress  tag 4448f3b096426fcb  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 245
635: sched_cls  name __send_drop_notify  tag bce7a1dbfa72df62  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 246
637: sched_cls  name tail_ipv4_to_endpoint  tag 73279a6f38f9a714  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,138,41,82,83,80,137,39,139,40,37,38
	btf_id 248
638: sched_cls  name handle_policy  tag edf3f3f4dd53bb9d  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,139,82,83,138,41,80,137,39,84,75,40,37,38
	btf_id 249
639: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,139
	btf_id 250
640: sched_cls  name tail_handle_ipv4_cont  tag 89738de1226c1098  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,138,41,137,82,83,39,76,74,77,139,40,37,38,81
	btf_id 251
641: sched_cls  name cil_from_container  tag 4d6b257d9874c474  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 139,76
	btf_id 252
642: sched_cls  name tail_ipv4_ct_ingress  tag 6d5cd91ee9185b0e  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 253
643: sched_cls  name tail_handle_arp  tag a3c2a801c8971a95  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,139
	btf_id 254
644: sched_cls  name tail_handle_ipv4  tag ad0d8cc8d66655e7  gpl
	loaded_at 2024-10-24T12:41:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,139
	btf_id 255
645: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
648: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
665: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
668: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
669: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
672: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
712: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
726: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
729: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
730: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
733: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3287: sched_cls  name tail_ipv4_ct_egress  tag 82fb382deda623c4  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,630,82,83,629,84
	btf_id 3079
3289: sched_cls  name __send_drop_notify  tag 586b1a747a93baae  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3082
3290: sched_cls  name cil_from_container  tag e6351d70eef25319  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 630,76
	btf_id 3083
3291: sched_cls  name tail_ipv4_ct_ingress  tag 9491fcebbd487175  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,630,82,83,629,84
	btf_id 3084
3292: sched_cls  name tail_handle_arp  tag ae64f810542e04db  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,630
	btf_id 3085
3296: sched_cls  name tail_handle_ipv4  tag e5ded2e0b97c3119  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,630
	btf_id 3086
3301: sched_cls  name tail_ipv4_to_endpoint  tag d6bfbf0f9e00da44  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,629,41,82,83,80,150,39,630,40,37,38
	btf_id 3090
3305: sched_cls  name tail_handle_ipv4_cont  tag 72dfce1d7ec16636  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,629,41,150,82,83,39,76,74,77,630,40,37,38,81
	btf_id 3095
3307: sched_cls  name handle_policy  tag 079866cd755e0125  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,630,82,83,629,41,80,150,39,84,75,40,37,38
	btf_id 3098
3309: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,630
	btf_id 3102
3342: sched_cls  name tail_handle_arp  tag 21cb370d468d6471  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3139
3343: sched_cls  name __send_drop_notify  tag 4c52253bcf33b0e1  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3140
3344: sched_cls  name __send_drop_notify  tag 28ebce00bf7259f0  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3141
3345: sched_cls  name tail_handle_ipv4_cont  tag 4a493320d7eeb7f0  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,147,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3142
3346: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3144
3347: sched_cls  name cil_from_container  tag 5402c0619df29e0e  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3145
3348: sched_cls  name tail_handle_ipv4  tag 9038d0c0852cdf92  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 5952B  jited 4400B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3143
3349: sched_cls  name tail_handle_ipv4_cont  tag a54ccaf5027ca76f  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 9672B  jited 6312B  memlock 12288B  map_ids 75,639,41,153,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3147
3350: sched_cls  name tail_handle_arp  tag 5a2397ab60d4aacf  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 1432B  jited 1120B  memlock 4096B  map_ids 76,637
	btf_id 3148
3351: sched_cls  name tail_ipv4_ct_ingress  tag 7c13802515ce3088  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6168B  jited 4696B  memlock 8192B  map_ids 76,637,82,83,639,84
	btf_id 3149
3352: sched_cls  name handle_policy  tag b651f15ba605934b  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,638,41,80,147,39,84,75,40,37,38
	btf_id 3146
3353: sched_cls  name tail_handle_ipv4  tag 2c3cfc44df6e1685  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3151
3354: sched_cls  name handle_policy  tag 41627d7887714611  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 14680B  jited 10056B  memlock 16384B  map_ids 76,637,82,83,639,41,80,153,39,84,75,40,37,38
	btf_id 3150
3355: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 4624B  jited 3144B  memlock 8192B  map_ids 76,637
	btf_id 3152
3356: sched_cls  name cil_from_container  tag 660bd3d3f9a7377a  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 728B  jited 744B  memlock 4096B  map_ids 637,76
	btf_id 3153
3357: sched_cls  name tail_ipv4_to_endpoint  tag e1f67895264b46d8  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 8744B  jited 5752B  memlock 12288B  map_ids 75,76,639,41,82,83,80,153,39,637,40,37,38
	btf_id 3154
3358: sched_cls  name tail_ipv4_ct_egress  tag 75c668d11d8620e6  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6128B  jited 4696B  memlock 8192B  map_ids 76,637,82,83,639,84
	btf_id 3155
3359: sched_cls  name tail_ipv4_to_endpoint  tag 11833e384502eaf7  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,147,39,640,40,37,38
	btf_id 3156
3360: sched_cls  name tail_ipv4_ct_egress  tag 91da8a32f14e2f39  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,638,84
	btf_id 3157
3362: sched_cls  name tail_ipv4_ct_ingress  tag 490496a3c95cc68e  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,638,84
	btf_id 3159
