filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6ae2d5fda967 direct-action not_in_hw id 534 tag b73845def9fbe236 jited 
