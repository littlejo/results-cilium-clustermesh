xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 582
ens6(5) clsact/ingress cil_from_netdev-ens6 id 591
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 575
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 573
cilium_host(7) clsact/egress cil_from_host-cilium_host id 569
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 502
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 501
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 549
lxc6ae2d5fda967(12) clsact/ingress cil_from_container-lxc6ae2d5fda967 id 534
lxcc5ebaf185b2b(14) clsact/ingress cil_from_container-lxcc5ebaf185b2b id 562
lxc1e481bd63cb0(18) clsact/ingress cil_from_container-lxc1e481bd63cb0 id 641
lxcf00911fbcaa4(20) clsact/ingress cil_from_container-lxcf00911fbcaa4 id 3347
lxcb8ca73062e9b(22) clsact/ingress cil_from_container-lxcb8ca73062e9b id 3290
lxcbe365d2aa45b(24) clsact/ingress cil_from_container-lxcbe365d2aa45b id 3356

flow_dissector:

netfilter:

