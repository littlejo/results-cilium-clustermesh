key: 02 00 00 00  value: ac 1f cb e6 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 6a 00 b7 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 84 db 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 6a 00 3c 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 6a 00 3c 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 9d c8 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 6a 00 a5 00 35 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 6a 00 10 1f 90 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 6a 00 a5 23 c1 00 00  00 00 00 00
Found 9 elements
