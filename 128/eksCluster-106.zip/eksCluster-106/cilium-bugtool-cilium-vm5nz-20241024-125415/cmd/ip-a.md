1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a1:d5:eb:2b:5b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.157.200/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3537sec preferred_lft 3537sec
    inet6 fe80::4a1:d5ff:feeb:2b5b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3c:4d:b2:fd:a9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.132.63/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::43c:4dff:feb2:fda9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:83:eb:72:98:df brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f483:ebff:fe72:98df/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:85:32:3f:ef:23 brd ff:ff:ff:ff:ff:ff
    inet 10.106.0.179/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a085:32ff:fe3f:ef23/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8a:28:e0:5f:c8:08 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8828:e0ff:fe5f:c808/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:5a:51:26:2a:25 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e05a:51ff:fe26:2a25/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6ae2d5fda967@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:23:c1:3a:da:5f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::6c23:c1ff:fe3a:da5f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcc5ebaf185b2b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:10:a1:3c:c1:ce brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c410:a1ff:fe3c:c1ce/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc1e481bd63cb0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:c0:7d:24:fc:ed brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::24c0:7dff:fe24:fced/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcf00911fbcaa4@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:41:db:14:a7:ba brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b041:dbff:fe14:a7ba/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcb8ca73062e9b@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:f2:74:e9:42:4f brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::f4f2:74ff:fee9:424f/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcbe365d2aa45b@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:be:d8:0f:07:81 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::b0be:d8ff:fe0f:781/64 scope link 
       valid_lft forever preferred_lft forever
