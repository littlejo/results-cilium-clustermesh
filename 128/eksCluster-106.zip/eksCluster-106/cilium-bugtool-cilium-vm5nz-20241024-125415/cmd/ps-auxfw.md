USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3383  0.0  0.4 1240432 15896 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3398  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3399  0.0  0.0   3852  1296 ?        R    12:54   0:00  \_ bash -c hostname
root        3373  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3359  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3353  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3315  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.9  7.5 1539060 295344 ?      Ssl  12:31   1:06 cilium-agent --config-dir=/tmp/cilium/config-map
root         399  0.3  0.2 1229744 9892 ?        Sl   12:32   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
