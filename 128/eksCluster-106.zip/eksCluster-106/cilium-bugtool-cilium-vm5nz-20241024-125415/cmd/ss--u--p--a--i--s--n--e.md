Total: 595
TCP:   4920 (estab 303, closed 4598, orphaned 0, timewait 4140)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  322       311       11       
INET	  332       317       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.157.200%ens5:68         0.0.0.0:*    uid:192 ino:149096 sk:d56 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35041 sk:d57 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15563 sk:d58 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:33175      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=30)) ino:34301 sk:d59 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35040 sk:d5a cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15564 sk:d5b cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::4a1:d5ff:feeb:2b5b]%ens5:546           [::]:*    uid:192 ino:15755 sk:d5c cgroup:unreachable:bd0 v6only:1 <->                   
