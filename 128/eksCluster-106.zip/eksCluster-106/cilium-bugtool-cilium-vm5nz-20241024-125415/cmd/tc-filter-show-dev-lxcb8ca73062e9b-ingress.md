filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb8ca73062e9b direct-action not_in_hw id 3290 tag e6351d70eef25319 jited 
