{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:27.618Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:27.640Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.240Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.272Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.300Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.311Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.334Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.558Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.571Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.606Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.646Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.675Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.186Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.187Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.238Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.239Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.281Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.304Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.317Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.560Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.566Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.619Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.643Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.670Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.314Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.321Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.362Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.362Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.412Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.580Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.582Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.641Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.643Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.686Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.248Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.284Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.298Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.345Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.361Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.380Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.658Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.710Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.766Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.781Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.811Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.171Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.200Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.224Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.247Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.271Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.506Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.542Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.556Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.607Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.627Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.955Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.987Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.006Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.042Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.066Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.087Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.338Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.346Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.411Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.429Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.458Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.827Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.832Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.878Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.889Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.916Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.150Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.155Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.217Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.249Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.264Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.622Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.675Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.687Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.727Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.745Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.766Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.981Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.009Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.038Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.076Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.092Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.468Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.490Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.523Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.546Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.561Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.818Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.841Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.907Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.915Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.961Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.213Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.247Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.257Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.295Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.331Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.332Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.571Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.571Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.622Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.632Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.707Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.965Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.013Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.033Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.034Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.064Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.078Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.313Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.313Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.337Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.343Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.364Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.090Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.092Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.149Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.162Z",
  "value": "id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.193Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.490Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.492Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.177Z",
  "value": "id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.190Z",
  "value": "id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA"
}

