REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     138245    11215432    677    bpf_overlay.c
Interface                   INGRESS     688817    248640674   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      140625    11391723    53     encap.h
Success                     EGRESS      149136    19850233    1308   bpf_lxc.c
Success                     EGRESS      596       156299      86     l3.h
Success                     EGRESS      61947     5023013     1694   bpf_host.c
Success                     INGRESS     172657    19855296    86     l3.h
Success                     INGRESS     250182    26246484    235    trace.h
Unsupported L3 protocol     EGRESS      72        5440        1492   bpf_lxc.c
