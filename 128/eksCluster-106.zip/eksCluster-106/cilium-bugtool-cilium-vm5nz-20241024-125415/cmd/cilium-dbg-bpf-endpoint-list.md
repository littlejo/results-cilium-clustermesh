IP ADDRESS         LOCAL ENDPOINT INFO
10.106.0.165:0     id=428   sec_id=7035581 flags=0x0000 ifindex=14  mac=6E:DE:1F:C0:85:E3 nodemac=C6:10:A1:3C:C1:CE   
10.106.0.183:0     id=1401  sec_id=7046801 flags=0x0000 ifindex=18  mac=EE:85:50:1D:6F:61 nodemac=26:C0:7D:24:FC:ED   
172.31.132.63:0    (localhost)                                                                                        
172.31.157.200:0   (localhost)                                                                                        
10.106.0.179:0     (localhost)                                                                                        
10.106.0.16:0      id=812   sec_id=7027176 flags=0x0000 ifindex=22  mac=E2:EA:5B:8B:EB:81 nodemac=F6:F2:74:E9:42:4F   
10.106.0.60:0      id=1968  sec_id=7035581 flags=0x0000 ifindex=12  mac=0A:43:E3:01:48:28 nodemac=6E:23:C1:3A:DA:5F   
10.106.0.187:0     id=3489  sec_id=7066777 flags=0x0000 ifindex=20  mac=6E:AB:FB:CF:2C:AA nodemac=B2:41:DB:14:A7:BA   
10.106.0.206:0     id=377   sec_id=7042127 flags=0x0000 ifindex=24  mac=9A:8C:E3:D9:1B:7A nodemac=B2:BE:D8:0F:07:81   
10.106.0.232:0     id=2974  sec_id=4     flags=0x0000 ifindex=10  mac=DE:95:F8:0E:24:6B nodemac=E2:5A:51:26:2A:25     
