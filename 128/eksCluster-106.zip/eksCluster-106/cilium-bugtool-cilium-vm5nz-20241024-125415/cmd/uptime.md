 12:54:16 up 31 min,  0 users,  load average: 0.71, 0.58, 0.33
