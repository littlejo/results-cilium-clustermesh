top - 12:54:16 up 31 min,  0 users,  load average: 0.71, 0.58, 0.33
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.2 us, 24.1 sy,  0.0 ni, 58.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    282.9 free,   1055.6 used,   2497.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2599.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 295344  79224 S   6.7   7.5   1:06.24 cilium-+
   3383 root      20   0 1240432  15896  11164 S   6.7   0.4   0:00.03 cilium-+
    399 root      20   0 1229744   9892   3836 S   0.0   0.3   0:04.36 cilium-+
   3315 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3353 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3359 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3373 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3411 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3429 root      20   0 1228744   3976   3328 S   0.0   0.1   0:00.00 gops
