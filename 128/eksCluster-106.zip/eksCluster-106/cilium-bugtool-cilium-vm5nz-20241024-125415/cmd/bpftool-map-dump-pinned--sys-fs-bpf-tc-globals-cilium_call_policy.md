key: 79 01 00 00  value: 1a 0d 00 00
key: ac 01 00 00  value: 2b 02 00 00
key: 2c 03 00 00  value: eb 0c 00 00
key: 79 05 00 00  value: 7e 02 00 00
key: b0 07 00 00  value: 0e 02 00 00
key: 9e 0b 00 00  value: 27 02 00 00
key: a1 0d 00 00  value: 18 0d 00 00
Found 7 elements
