Endpoint ID: 377
Path: /sys/fs/bpf/tc/globals/cilium_policy_00377

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 428
Path: /sys/fs/bpf/tc/globals/cilium_policy_00428

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3044     31        0        
Allow    Ingress     1          ANY          NONE         disabled    128815   1476      0        
Allow    Egress      0          ANY          NONE         disabled    19128    210       0        


Endpoint ID: 812
Path: /sys/fs/bpf/tc/globals/cilium_policy_00812

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378903   4419      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1401
Path: /sys/fs/bpf/tc/globals/cilium_policy_01401

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6093846   61293     0        
Allow    Ingress     1          ANY          NONE         disabled    5323484   56176     0        
Allow    Egress      0          ANY          NONE         disabled    6916236   68113     0        


Endpoint ID: 1968
Path: /sys/fs/bpf/tc/globals/cilium_policy_01968

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2852     29        0        
Allow    Ingress     1          ANY          NONE         disabled    128814   1480      0        
Allow    Egress      0          ANY          NONE         disabled    18110    198       0        


Endpoint ID: 2974
Path: /sys/fs/bpf/tc/globals/cilium_policy_02974

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6237434   76962     0        
Allow    Ingress     1          ANY          NONE         disabled    67472     818       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3489
Path: /sys/fs/bpf/tc/globals/cilium_policy_03489

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3974
Path: /sys/fs/bpf/tc/globals/cilium_policy_03974

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


