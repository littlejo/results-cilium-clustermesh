alloc: 76.23MB (79937376 bytes)
total-alloc: 3.14GB (3373554480 bytes)
sys: 215.32MB (225781076 bytes)
lookups: 0
mallocs: 76015029
frees: 75476481
heap-alloc: 76.23MB (79937376 bytes)
heap-sys: 170.73MB (179027968 bytes)
heap-idle: 45.71MB (47931392 bytes)
heap-in-use: 125.02MB (131096576 bytes)
heap-released: 592.00KB (606208 bytes)
heap-objects: 538548
stack-in-use: 33.22MB (34832384 bytes)
stack-sys: 33.22MB (34832384 bytes)
stack-mspan-inuse: 2.08MB (2180480 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1009.56KB (1033793 bytes)
gc-sys: 5.51MB (5774312 bytes)
next-gc: when heap-alloc >= 151.10MB (158440504 bytes)
last-gc: 2024-10-24 12:54:44.029950832 +0000 UTC
gc-pause-total: 9.163124ms
gc-pause: 77056
gc-pause-end: 1729774484029950832
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0006374400931836226
enable-gc: true
debug-gc: false
