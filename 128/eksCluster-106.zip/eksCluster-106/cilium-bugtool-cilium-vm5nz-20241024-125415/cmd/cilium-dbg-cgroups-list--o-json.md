[
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda587e955_52f1_4d8f_b8a0_1c867f512cbc.slice/cri-containerd-95cfbf5761b277d955d3f4fcb7721b67c254cbc327200da637bef42ed7de8950.scope"
      }
    ],
    "ips": [
      "10.106.0.187"
    ],
    "name": "client-974f6c69d-xzj95",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod756929be_2655_4c68_a9af_d08ab832f77f.slice/cri-containerd-10355291097a5b93502ddf39db0072b848ecef0ed59b8c23ecca225f3fe8f12d.scope"
      }
    ],
    "ips": [
      "10.106.0.165"
    ],
    "name": "coredns-cc6ccd49c-khxf6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ba004a3_8bcf_4dbe_a0e6_e1c07d8ad4fe.slice/cri-containerd-2961337b2bda48c364b2a9c38b6e56a4c0d25ca62fe82e7bbec1a2b0d84710ef.scope"
      }
    ],
    "ips": [
      "10.106.0.206"
    ],
    "name": "client2-57cf4468f-s7f65",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode20c53e8_9c63_4c8b_a401_c8364894a041.slice/cri-containerd-bbec4a0adbebf94369d8740ec8613c01077245415fbe1e11845bbd91d711c478.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode20c53e8_9c63_4c8b_a401_c8364894a041.slice/cri-containerd-42b441ff45164ad11a387e745ca1a65d89395e3376d34c845465751c82ce420d.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode20c53e8_9c63_4c8b_a401_c8364894a041.slice/cri-containerd-ab44b70ca9deafd83804576069b0d1209d594fe02fd284a50384304c0ce60ce6.scope"
      }
    ],
    "ips": [
      "10.106.0.183"
    ],
    "name": "clustermesh-apiserver-6d64fdffc8-4sgk5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7493,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30b6ad00_9006_4212_910a_8c83c3a7a686.slice/cri-containerd-5548d109df389a030a0ed5c7df653fc2425b1d7173a32cc6b4c65ec6be9d993d.scope"
      }
    ],
    "ips": [
      "10.106.0.60"
    ],
    "name": "coredns-cc6ccd49c-svj56",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod359d938c_57ac_4a95_b3e2_a1cb16f59956.slice/cri-containerd-d66e1b4c294b3072b9b2866d0a3d43bce18bcd4b255a2cea50c1e41294b81ca7.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod359d938c_57ac_4a95_b3e2_a1cb16f59956.slice/cri-containerd-fa84360803906eb562261f02a8a8c95e0de97bd53981aff1d9e2c3a1f03cb646.scope"
      }
    ],
    "ips": [
      "10.106.0.16"
    ],
    "name": "echo-same-node-86d9cc975c-qd42j",
    "namespace": "cilium-test-1"
  }
]

