Node 0, zone      DMA     20     27      3     11      6      6      5      1      2      2     41 
Node 0, zone   Normal    501     59     14     31     24     11      2      2      2      2      7 
