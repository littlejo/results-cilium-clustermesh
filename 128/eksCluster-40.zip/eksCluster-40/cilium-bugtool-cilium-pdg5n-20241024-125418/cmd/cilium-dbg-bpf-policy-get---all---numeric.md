Endpoint ID: 499
Path: /sys/fs/bpf/tc/globals/cilium_policy_00499

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1086
Path: /sys/fs/bpf/tc/globals/cilium_policy_01086

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2021
Path: /sys/fs/bpf/tc/globals/cilium_policy_02021

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378677   4422      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2456
Path: /sys/fs/bpf/tc/globals/cilium_policy_02456

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6219132   76843     0        
Allow    Ingress     1          ANY          NONE         disabled    65974     794       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2800
Path: /sys/fs/bpf/tc/globals/cilium_policy_02800

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3292     34        0        
Allow    Ingress     1          ANY          NONE         disabled    157776   1812      0        
Allow    Egress      0          ANY          NONE         disabled    20451    227       0        


Endpoint ID: 2864
Path: /sys/fs/bpf/tc/globals/cilium_policy_02864

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2965
Path: /sys/fs/bpf/tc/globals/cilium_policy_02965

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2604     26        0        
Allow    Ingress     1          ANY          NONE         disabled    157781   1817      0        
Allow    Egress      0          ANY          NONE         disabled    20742    232       0        


Endpoint ID: 2976
Path: /sys/fs/bpf/tc/globals/cilium_policy_02976

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6033520   59565     0        
Allow    Ingress     1          ANY          NONE         disabled    5045820   53001     0        
Allow    Egress      0          ANY          NONE         disabled    5872622   58910     0        


