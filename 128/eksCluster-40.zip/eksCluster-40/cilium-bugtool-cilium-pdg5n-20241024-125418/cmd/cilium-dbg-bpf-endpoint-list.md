IP ADDRESS         LOCAL ENDPOINT INFO
10.40.0.74:0       (localhost)                                                                                        
10.40.0.18:0       id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA   
10.40.0.39:0       id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A   
10.40.0.48:0       id=2965  sec_id=2737634 flags=0x0000 ifindex=14  mac=BA:9A:F6:EC:BC:49 nodemac=6E:17:8E:48:9E:8F   
172.31.148.47:0    (localhost)                                                                                        
10.40.0.116:0      id=2800  sec_id=2737634 flags=0x0000 ifindex=12  mac=EE:DD:C9:76:E0:D7 nodemac=9E:80:81:66:95:18   
10.40.0.10:0       id=2976  sec_id=2749417 flags=0x0000 ifindex=18  mac=7A:94:77:FE:37:F1 nodemac=32:33:EC:10:2E:E2   
172.31.142.138:0   (localhost)                                                                                        
10.40.0.210:0      id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6   
10.40.0.174:0      id=2456  sec_id=4     flags=0x0000 ifindex=10  mac=C2:99:F1:5A:D9:6B nodemac=D2:DC:2F:A6:A4:BB     
