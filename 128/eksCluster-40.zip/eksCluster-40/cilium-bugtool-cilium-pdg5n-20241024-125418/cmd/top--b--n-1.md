top - 12:54:19 up 33 min,  0 users,  load average: 0.34, 0.54, 0.30
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.2 us, 31.2 sy,  0.0 ni, 12.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    293.3 free,   1047.2 used,   2495.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2607.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 299172  79876 S  46.7   7.6   1:03.50 cilium-+
   3283 root      20   0 1240432  15904  10640 S   6.7   0.4   0:00.04 cilium-+
    392 root      20   0 1229744   8808   2864 S   0.0   0.2   0:04.08 cilium-+
   3309 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3310 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3315 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3351 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
