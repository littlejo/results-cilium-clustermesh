1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d5:2c:d3:17:23 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.148.47/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3430sec preferred_lft 3430sec
    inet6 fe80::4d5:2cff:fed3:1723/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e5:0f:40:d2:57 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.142.138/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4e5:fff:fe40:d257/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:77:e8:32:3f:af brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b877:e8ff:fe32:3faf/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:e8:e7:cd:25:55 brd ff:ff:ff:ff:ff:ff
    inet 10.40.0.74/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::70e8:e7ff:fecd:2555/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a6:0c:73:a5:e9:98 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a40c:73ff:fea5:e998/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:dc:2f:a6:a4:bb brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d0dc:2fff:fea6:a4bb/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcbb6104e89dff@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:80:81:66:95:18 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9c80:81ff:fe66:9518/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc1dbcff737296@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:17:8e:48:9e:8f brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6c17:8eff:fe48:9e8f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7dd9973333d4@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:33:ec:10:2e:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3033:ecff:fe10:2ee2/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc5f52767ca8b1@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:d2:fe:7f:a7:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::28d2:feff:fe7f:a7d6/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc69cef4617134@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:f7:76:e9:b2:fa brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::b8f7:76ff:fee9:b2fa/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc203affcc0357@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:23:a1:b2:e5:2a brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::5023:a1ff:feb2:e52a/64 scope link 
       valid_lft forever preferred_lft forever
