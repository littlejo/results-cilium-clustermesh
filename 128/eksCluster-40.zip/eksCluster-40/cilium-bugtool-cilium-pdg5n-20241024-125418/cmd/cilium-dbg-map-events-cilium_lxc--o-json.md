{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.691Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.962Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.964Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.003Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.004Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.051Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.669Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.676Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.792Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.803Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.829Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.014Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.024Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.080Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.093Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.138Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.775Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.781Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.820Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.841Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.861Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.060Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.064Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.132Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.145Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.171Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.762Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.777Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.804Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.826Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.849Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.157Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.198Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.271Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.311Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.321Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.905Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.937Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.959Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.983Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.002Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.229Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.233Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.302Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.304Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.341Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.733Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.743Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.789Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.795Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.822Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.064Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.097Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.105Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.164Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.172Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.597Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.693Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.697Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.739Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.763Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.778Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.963Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.975Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.023Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.036Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.059Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.462Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.468Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.516Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.520Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.548Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.781Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.795Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.831Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.861Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.867Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.302Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.359Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.368Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.412Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.415Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.453Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.676Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.697Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.809Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.846Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.867Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.216Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.220Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.260Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.276Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.302Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.324Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.572Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.579Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.627Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.633Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.674Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.031Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.046Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.089Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.100Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.128Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.335Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.343Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.383Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.401Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.435Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.739Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.771Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.777Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.815Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.831Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.847Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.101Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.106Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.120Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.152Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.824Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.827Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.864Z",
  "value": "id=2021  sec_id=2737364 flags=0x0000 ifindex=22  mac=82:D7:C7:44:A5:35 nodemac=BA:F7:76:E9:B2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.884Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.907Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.152Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.152Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.797Z",
  "value": "id=2864  sec_id=2705687 flags=0x0000 ifindex=20  mac=5E:1D:2B:C5:22:22 nodemac=2A:D2:FE:7F:A7:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.804Z",
  "value": "id=1086  sec_id=2723172 flags=0x0000 ifindex=24  mac=82:D1:E4:1F:F4:4D nodemac=52:23:A1:B2:E5:2A"
}

