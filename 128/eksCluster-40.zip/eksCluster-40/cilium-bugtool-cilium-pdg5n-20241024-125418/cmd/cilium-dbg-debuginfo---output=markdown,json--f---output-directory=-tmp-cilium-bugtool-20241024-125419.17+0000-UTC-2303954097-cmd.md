markdown output at /tmp/cilium-bugtool-20241024-125419.17+0000-UTC-2303954097/cmd/cilium-debuginfo-20241024-125450.09+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125419.17+0000-UTC-2303954097/cmd/cilium-debuginfo-20241024-125450.09+0000-UTC.json
