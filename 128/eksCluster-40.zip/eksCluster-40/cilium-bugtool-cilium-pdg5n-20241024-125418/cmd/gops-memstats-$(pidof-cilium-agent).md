alloc: 95.02MB (99637936 bytes)
total-alloc: 3.09GB (3319248056 bytes)
sys: 227.07MB (238101844 bytes)
lookups: 0
mallocs: 75086511
frees: 74159633
heap-alloc: 95.02MB (99637936 bytes)
heap-sys: 180.54MB (189308928 bytes)
heap-idle: 54.77MB (57434112 bytes)
heap-in-use: 125.77MB (131874816 bytes)
heap-released: 9.53MB (9994240 bytes)
heap-objects: 926878
stack-in-use: 35.44MB (37158912 bytes)
stack-sys: 35.44MB (37158912 bytes)
stack-mspan-inuse: 2.09MB (2195040 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 736.63KB (754305 bytes)
gc-sys: 5.50MB (5764144 bytes)
next-gc: when heap-alloc >= 152.66MB (160078200 bytes)
last-gc: 2024-10-24 12:54:26.315349805 +0000 UTC
gc-pause-total: 10.962778ms
gc-pause: 65527
gc-pause-end: 1729774466315349805
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005365716014885381
enable-gc: true
debug-gc: false
