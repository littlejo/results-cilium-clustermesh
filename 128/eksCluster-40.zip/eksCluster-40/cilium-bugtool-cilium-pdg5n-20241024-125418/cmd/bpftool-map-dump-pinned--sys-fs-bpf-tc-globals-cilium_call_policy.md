key: 3e 04 00 00  value: 34 0d 00 00
key: e5 07 00 00  value: fa 0c 00 00
key: 98 09 00 00  value: 47 02 00 00
key: f0 0a 00 00  value: 0c 02 00 00
key: 30 0b 00 00  value: 37 0d 00 00
key: 95 0b 00 00  value: 43 02 00 00
key: a0 0b 00 00  value: 84 02 00 00
Found 7 elements
