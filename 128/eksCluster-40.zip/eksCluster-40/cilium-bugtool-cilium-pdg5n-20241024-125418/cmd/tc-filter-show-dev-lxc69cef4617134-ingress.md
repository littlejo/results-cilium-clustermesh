filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc69cef4617134 direct-action not_in_hw id 3332 tag 649ee32a169a1d93 jited 
