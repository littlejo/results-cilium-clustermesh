 12:54:19 up 32 min,  0 users,  load average: 0.34, 0.54, 0.30
