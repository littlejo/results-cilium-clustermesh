CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddba80fa3_834c_45d7_8ce5_d6774230500b.slice/cri-containerd-63ec2e751b63bba4dc43e4e0d875c0125e122b63c372d7256d2ccfb4431fd255.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddba80fa3_834c_45d7_8ce5_d6774230500b.slice/cri-containerd-e32ac309af422a350e55ff09f8f97a64a49a70003b568d5668dfd37d66145b93.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd65acd62_6120_4f89_a106_1e6a92fa3a9e.slice/cri-containerd-4d5e8976697daaf2aba06a9c6a3f37e6712873cf09c310d9c77d2a176e8acafc.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd65acd62_6120_4f89_a106_1e6a92fa3a9e.slice/cri-containerd-a64f0f49fcdf1e36c98af4fecefb28aeb99a3784a4594ed0b56b5cf20ad819a6.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ac8c093_4870_45d3_a6e8_cdfadc1ec1d0.slice/cri-containerd-ddba2dbe6195122f2eeb29ca3412ec9164ae0ad287cc21a2c432c28bdce4e59a.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ac8c093_4870_45d3_a6e8_cdfadc1ec1d0.slice/cri-containerd-f66151215bb4d1522feb6fa56f15530e08287696bba2cad716fedbe268d60ccc.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc30b1b74_ab10_4fa3_bc4a_22162288216f.slice/cri-containerd-514534fa4fb06c69a5f10e6acae04ae2d81a0a5569e677d52df808904a67fbdb.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc30b1b74_ab10_4fa3_bc4a_22162288216f.slice/cri-containerd-aea8ed6275efa6e3d4dc6ec1f946f2b52108e6284b32c0ad9942981a06e3344a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4c329c4_71d8_455e_aa97_8d64dd83e91f.slice/cri-containerd-b9f29203ea9bd56149d012afb9f2f2f3372eab57e5e67027a6b0544235450286.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4c329c4_71d8_455e_aa97_8d64dd83e91f.slice/cri-containerd-c92edf065a885d567b6530bf6fc3d30e4170d361945f74544cc32694c0c2313e.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4c329c4_71d8_455e_aa97_8d64dd83e91f.slice/cri-containerd-1ecec99f9393d4e4c697740b7b1da69d611562034d147cb6d742f99e3aeeaeb1.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4c329c4_71d8_455e_aa97_8d64dd83e91f.slice/cri-containerd-f6852122f26a2df9aef774bc6ff05d1f72388ff8afaca83ac4f4bc08874dcf99.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb2c890_526f_402d_8adc_b6c40f4ad988.slice/cri-containerd-3c1a3b35b7fb76a215a958b00be69a56bcaa678ec0dc45d1c51fddea9e571b44.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb2c890_526f_402d_8adc_b6c40f4ad988.slice/cri-containerd-3b79e8bf1b09f29de1041ee0a5cce27a825b6cb66263c1d512c46271b8cbbb47.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb2c890_526f_402d_8adc_b6c40f4ad988.slice/cri-containerd-7caae03351ba84ebdbd2de0834edbacdd9ff69c38233aa9b5aded69f1e1dad51.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef89d49d_6942_4694_bf40_5a7b459314a8.slice/cri-containerd-744ba255cd95cb1e9d64b04a0afcf1d62525ffc9b561a3d8164dca4eb637a29c.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef89d49d_6942_4694_bf40_5a7b459314a8.slice/cri-containerd-1f6543f1765701565492db5965b5b26d045a9a9d69b2e54f692fa423251aa438.scope
    696      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf73ca93e_8b7a_434d_a18c_66b6b863311b.slice/cri-containerd-e179b79f6511f9286fa4e209b0987c1fd7b203889328060271f300cd5beff2bb.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf73ca93e_8b7a_434d_a18c_66b6b863311b.slice/cri-containerd-d5f32f22cc0eedd55f83d487b696c5d013f91165e301efa8fdd8cd14134d3dd0.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4773096_5eca_469e_8ca2_c83111e44179.slice/cri-containerd-4fc44448d8f7b010050d5b09302ac684ee7e5448f19c007e4a4a5bb96e660049.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4773096_5eca_469e_8ca2_c83111e44179.slice/cri-containerd-bca7e1e16bf318ab2ff9cde8df9a894c8e4eafcc3abaa190af91ed360a84a3a7.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5db4951d_2925_4e33_baca_c2c3e0431e76.slice/cri-containerd-7da5bc009b4a63fbebb0acb34ef705525577bd9ab44dfde5516e2a60d28e1618.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5db4951d_2925_4e33_baca_c2c3e0431e76.slice/cri-containerd-db5d34edfa3f76cf33eeb7ebc7f6577c7db41e6ecf1f19dd8d53c56604b736c8.scope
    734      cgroup_device   multi                                          
