filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7dd9973333d4 direct-action not_in_hw id 646 tag bd7d440f1c8e9cc5 jited 
