KEY             VALUE
AgentLiveness   2010897185584
UTimeOffset     3378461873046875
