filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc203affcc0357 direct-action not_in_hw id 3381 tag 8bca6a2aa1337c57 jited 
