Node 0, zone      DMA      1      2     13     47     14     10      5      5      3      5     42 
Node 0, zone   Normal    174     32      9      1      1      7      2      3      2      4      7 
