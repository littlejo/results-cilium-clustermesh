[
  {
    "containers": [
      {
        "cgroup-id": 7611,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd65acd62_6120_4f89_a106_1e6a92fa3a9e.slice/cri-containerd-a64f0f49fcdf1e36c98af4fecefb28aeb99a3784a4594ed0b56b5cf20ad819a6.scope"
      }
    ],
    "ips": [
      "10.40.0.116"
    ],
    "name": "coredns-cc6ccd49c-w54rr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9843,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef89d49d_6942_4694_bf40_5a7b459314a8.slice/cri-containerd-744ba255cd95cb1e9d64b04a0afcf1d62525ffc9b561a3d8164dca4eb637a29c.scope"
      }
    ],
    "ips": [
      "10.40.0.210"
    ],
    "name": "client-974f6c69d-w9wqc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9927,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5db4951d_2925_4e33_baca_c2c3e0431e76.slice/cri-containerd-db5d34edfa3f76cf33eeb7ebc7f6577c7db41e6ecf1f19dd8d53c56604b736c8.scope"
      }
    ],
    "ips": [
      "10.40.0.39"
    ],
    "name": "client2-57cf4468f-kmcfv",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7695,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddba80fa3_834c_45d7_8ce5_d6774230500b.slice/cri-containerd-e32ac309af422a350e55ff09f8f97a64a49a70003b568d5668dfd37d66145b93.scope"
      }
    ],
    "ips": [
      "10.40.0.48"
    ],
    "name": "coredns-cc6ccd49c-wl596",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10095,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb2c890_526f_402d_8adc_b6c40f4ad988.slice/cri-containerd-3b79e8bf1b09f29de1041ee0a5cce27a825b6cb66263c1d512c46271b8cbbb47.scope"
      },
      {
        "cgroup-id": 10011,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeeb2c890_526f_402d_8adc_b6c40f4ad988.slice/cri-containerd-7caae03351ba84ebdbd2de0834edbacdd9ff69c38233aa9b5aded69f1e1dad51.scope"
      }
    ],
    "ips": [
      "10.40.0.18"
    ],
    "name": "echo-same-node-86d9cc975c-rgfh8",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9255,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4c329c4_71d8_455e_aa97_8d64dd83e91f.slice/cri-containerd-f6852122f26a2df9aef774bc6ff05d1f72388ff8afaca83ac4f4bc08874dcf99.scope"
      },
      {
        "cgroup-id": 9171,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4c329c4_71d8_455e_aa97_8d64dd83e91f.slice/cri-containerd-1ecec99f9393d4e4c697740b7b1da69d611562034d147cb6d742f99e3aeeaeb1.scope"
      },
      {
        "cgroup-id": 9087,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4c329c4_71d8_455e_aa97_8d64dd83e91f.slice/cri-containerd-c92edf065a885d567b6530bf6fc3d30e4170d361945f74544cc32694c0c2313e.scope"
      }
    ],
    "ips": [
      "10.40.0.10"
    ],
    "name": "clustermesh-apiserver-9f64dd9bd-qnndn",
    "namespace": "kube-system"
  }
]

