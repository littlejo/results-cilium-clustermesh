{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.189Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.762Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.800Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.829Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.864Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.887Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.092Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.114Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.187Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.208Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.300Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.797Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.842Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.843Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.888Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.891Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.114Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.133Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.177Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.196Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.237Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.738Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.739Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.797Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.805Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.838Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.863Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.882Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.074Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.104Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.166Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.196Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.214Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.709Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.716Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.751Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.765Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.808Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.809Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.841Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.056Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.069Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.118Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.165Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.185Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.614Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.614Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.649Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.657Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.693Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.947Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.951Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.002Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.020Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.042Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.530Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.549Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.656Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.664Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.712Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.724Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.907Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.910Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.967Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.995Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.004Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.412Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.475Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.486Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.534Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.547Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.576Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.767Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.781Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.823Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.847Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.865Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.244Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.250Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.304Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.322Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.349Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.602Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.649Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.694Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.720Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.735Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.083Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.092Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.138Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.141Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.195Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.405Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.424Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.456Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.476Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.513Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.794Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.833Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.850Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.887Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.905Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.928Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.138Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.144Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.189Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.227Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.231Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.525Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.557Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.563Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.600Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.626Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.639Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.659Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.934Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.946Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.951Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.984Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.640Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.640Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.695Z",
  "value": "id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.714Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.733Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.980Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.993Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.772Z",
  "value": "id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:34.788Z",
  "value": "id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4"
}

