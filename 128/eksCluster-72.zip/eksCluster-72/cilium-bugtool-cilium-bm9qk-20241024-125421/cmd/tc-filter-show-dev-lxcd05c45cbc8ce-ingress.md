filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd05c45cbc8ce direct-action not_in_hw id 3391 tag 7941a7c15dc1c901 jited 
