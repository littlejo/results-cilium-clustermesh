Node 0, zone      DMA      0      1      2      2      8      8      4      1      3      2     43 
Node 0, zone   Normal    747    122     38     18     25     15      6      4      4      1      6 
