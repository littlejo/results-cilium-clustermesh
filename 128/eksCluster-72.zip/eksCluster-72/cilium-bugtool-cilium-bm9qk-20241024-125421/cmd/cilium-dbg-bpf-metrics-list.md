REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     131708    10674087    677    bpf_overlay.c
Interface                   INGRESS     639273    242939042   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      131669    10669510    53     encap.h
Success                     EGRESS      136409    17974479    1308   bpf_lxc.c
Success                     EGRESS      55751     4519371     1694   bpf_host.c
Success                     EGRESS      596       156261      86     l3.h
Success                     INGRESS     160064    17860121    86     l3.h
Success                     INGRESS     237248    24213568    235    trace.h
Unsupported L3 protocol     EGRESS      72        5424        1492   bpf_lxc.c
