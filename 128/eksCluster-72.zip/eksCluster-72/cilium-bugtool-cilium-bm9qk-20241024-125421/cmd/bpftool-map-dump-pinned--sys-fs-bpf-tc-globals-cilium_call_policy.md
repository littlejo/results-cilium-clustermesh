key: f7 00 00 00  value: 34 02 00 00
key: d2 02 00 00  value: 3f 02 00 00
key: 63 03 00 00  value: 46 0d 00 00
key: 83 04 00 00  value: 04 0d 00 00
key: 4c 06 00 00  value: 7d 02 00 00
key: 3a 09 00 00  value: 3d 0d 00 00
key: f3 0c 00 00  value: 12 02 00 00
Found 7 elements
