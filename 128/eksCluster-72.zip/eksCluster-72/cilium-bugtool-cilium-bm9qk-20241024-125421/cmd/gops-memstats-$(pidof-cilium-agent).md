alloc: 127.79MB (134000288 bytes)
total-alloc: 3.04GB (3261720328 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74407204
frees: 73038387
heap-alloc: 127.79MB (134000288 bytes)
heap-sys: 172.84MB (181239808 bytes)
heap-idle: 27.30MB (28622848 bytes)
heap-in-use: 145.55MB (152616960 bytes)
heap-released: 7.87MB (8249344 bytes)
heap-objects: 1368817
stack-in-use: 35.16MB (36864000 bytes)
stack-sys: 35.16MB (36864000 bytes)
stack-mspan-inuse: 2.34MB (2456320 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 986.92KB (1010609 bytes)
gc-sys: 5.50MB (5768360 bytes)
next-gc: when heap-alloc >= 144.09MB (151089976 bytes)
last-gc: 2024-10-24 12:53:34.525877134 +0000 UTC
gc-pause-total: 18.556601ms
gc-pause: 91891
gc-pause-end: 1729774414525877134
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.000594051871264511
enable-gc: true
debug-gc: false
