xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 551
ens6(5) clsact/ingress cil_from_netdev-ens6 id 558
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 545
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 536
cilium_host(7) clsact/egress cil_from_host-cilium_host id 538
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 579
lxc880a520dcd43(12) clsact/ingress cil_from_container-lxc880a520dcd43 id 519
lxc69669d059057(14) clsact/ingress cil_from_container-lxc69669d059057 id 572
lxc698fefb5448e(18) clsact/ingress cil_from_container-lxc698fefb5448e id 646
lxcd05c45cbc8ce(20) clsact/ingress cil_from_container-lxcd05c45cbc8ce id 3391
lxc97af789d4be9(22) clsact/ingress cil_from_container-lxc97af789d4be9 id 3397
lxc40da8b2f3bcd(24) clsact/ingress cil_from_container-lxc40da8b2f3bcd id 3322

flow_dissector:

netfilter:

