 12:54:23 up 32 min,  0 users,  load average: 0.71, 0.61, 0.34
