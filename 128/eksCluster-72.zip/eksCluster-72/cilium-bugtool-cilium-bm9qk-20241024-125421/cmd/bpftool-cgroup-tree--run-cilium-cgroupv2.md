CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb964fae3_ca05_4ab2_8efa_d8e570c6a947.slice/cri-containerd-069f4510ec44213e546054fed7fd36d11eb6118d758c450224fb872eb0223809.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb964fae3_ca05_4ab2_8efa_d8e570c6a947.slice/cri-containerd-df17fac9386a4e47f9ff7797ff48c8221615035871cdcf3e141d7408e14dc084.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13569b38_d88a_4208_925d_66313abe9894.slice/cri-containerd-ea65aa87dcd67b36ce8aed83ec188c5b398c7a3aeae7971db6bd8d1e140f3ad1.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13569b38_d88a_4208_925d_66313abe9894.slice/cri-containerd-c315022fab06b897b3889728f8bae179061f8d25689dbbad2a983f01a0a430b9.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd1daae4_9967_455f_bfca_c9e140f510ac.slice/cri-containerd-ebfdbcb983432b58f899a79b4227d17336e161ed3fae910762126fb2d768dad9.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd1daae4_9967_455f_bfca_c9e140f510ac.slice/cri-containerd-af15532dcfb90b418b038422d4472448fece2d562d05cd60b3d0405288871a74.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddcfecba3_b7ab_4359_96ef_251175fd6909.slice/cri-containerd-0a87aed8ffea8dc2fa81fcd4cdcca1bdd366e32aecd096b80cb3dae05b5a55b8.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddcfecba3_b7ab_4359_96ef_251175fd6909.slice/cri-containerd-41ca9e7a21961044e012977c155d75529efadeabdf6ab3bd400234531cf0f8e2.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode87d8f56_7d3a_4c4c_b992_aab0e01edd2f.slice/cri-containerd-e6ee9a7233f315fa635eca3a1bf3b66d8810b34ba38e19dbbcbfbc285f0beba4.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode87d8f56_7d3a_4c4c_b992_aab0e01edd2f.slice/cri-containerd-bf58af0a9c4144c1ad514c579b68be6423a43f07f8895908cb00c3e3f4699a66.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode87d8f56_7d3a_4c4c_b992_aab0e01edd2f.slice/cri-containerd-b64f3f17312d58815ba2e8f9ca7236285d7cdb0005f322cfec11783d6228e4a6.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbbcbf9a_14ab_4675_8834_a634c287146c.slice/cri-containerd-329bdc08f796a5e6e0cb008d7292ec7b17ef2b85b165e554e95dba01f8fd888f.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbbcbf9a_14ab_4675_8834_a634c287146c.slice/cri-containerd-3f5129f2ae7d8f1e834c69a94499e2f59496c10c5e1f591726f9f8436a9cdfeb.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3a5bcee_7e81_4eb1_8de3_082c0570f1fa.slice/cri-containerd-297a947bb6dc73ab82abf5a070758f3442cab72885d73375d35530dd2a02737b.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3a5bcee_7e81_4eb1_8de3_082c0570f1fa.slice/cri-containerd-cf11364614376be66a31df69ed6cb47fcdc468578cf9a8094542e03a023fb006.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3654193f_9e2a_43be_a8b7_9d6fa45e82b2.slice/cri-containerd-49c82c6098b3a6bc208edf9ad3b6f39e3a32904dcb71ff10f07e6e66af4d6633.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3654193f_9e2a_43be_a8b7_9d6fa45e82b2.slice/cri-containerd-d3311891e6ddd38562e2e6d313c78fd8164f75cc15caaae9d215f4c6cbacbcdb.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75b2c843_c6ce_4529_86ea_590127ea9a94.slice/cri-containerd-eb2193f088ce7a563fef96155ebf980b9411d1380f50906dcdd41a91e4bdfaeb.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75b2c843_c6ce_4529_86ea_590127ea9a94.slice/cri-containerd-2f735c5955dce8989a17430bafb3d157e0b26ff62ef914014d7395a43acad726.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75b2c843_c6ce_4529_86ea_590127ea9a94.slice/cri-containerd-4503c8e6c58343f95bcb490f758b3402c9515625c16dd21032adf004f77492ad.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75b2c843_c6ce_4529_86ea_590127ea9a94.slice/cri-containerd-e11cbef0ebc88ae5831c05c19f43bb79ea29d912de943155b0d5c80022d326ec.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8f29016_0cf2_4b72_9cb4_93994f39863b.slice/cri-containerd-66fb9371293e5c5de09fea4240591aafb08b1bc6c51f9fa52d8d2e4fbe69f850.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8f29016_0cf2_4b72_9cb4_93994f39863b.slice/cri-containerd-266ece33c24d0a24615f45906415905a85dd6a5e4663a89d2d5e66bd00fe830f.scope
    728      cgroup_device   multi                                          
