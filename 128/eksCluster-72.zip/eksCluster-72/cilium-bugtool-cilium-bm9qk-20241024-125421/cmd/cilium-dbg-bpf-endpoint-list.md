IP ADDRESS         LOCAL ENDPOINT INFO
10.72.0.198:0      id=867   sec_id=4784981 flags=0x0000 ifindex=22  mac=5A:22:1D:22:60:89 nodemac=F2:C5:94:FD:51:C4   
10.72.0.150:0      id=3315  sec_id=4819744 flags=0x0000 ifindex=12  mac=8E:26:A6:EF:50:53 nodemac=12:79:C5:FF:58:1A   
10.72.0.168:0      id=2362  sec_id=4826836 flags=0x0000 ifindex=20  mac=5A:62:4C:88:35:C7 nodemac=D2:8E:5A:0B:BD:58   
10.72.0.232:0      id=1612  sec_id=4797414 flags=0x0000 ifindex=18  mac=92:F6:94:9E:CD:11 nodemac=3A:4D:0C:60:D1:5C   
10.72.0.57:0       id=1155  sec_id=4789649 flags=0x0000 ifindex=24  mac=92:9D:32:05:C2:1E nodemac=B6:93:8A:4F:64:2E   
10.72.0.66:0       (localhost)                                                                                        
10.72.0.152:0      id=247   sec_id=4819744 flags=0x0000 ifindex=14  mac=C6:5B:89:2A:F3:57 nodemac=B6:12:5F:65:DB:26   
172.31.146.114:0   (localhost)                                                                                        
172.31.159.220:0   (localhost)                                                                                        
10.72.0.118:0      id=722   sec_id=4     flags=0x0000 ifindex=10  mac=36:5A:95:92:52:33 nodemac=36:A3:DE:1D:E5:BC     
