top - 12:54:23 up 32 min,  0 users,  load average: 0.71, 0.61, 0.34
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 43.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    292.1 free,   1048.3 used,   2495.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2606.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 286712  78016 S  46.7   7.3   1:03.61 cilium-+
   3182 root      20   0 1240432  16128  11164 S   6.7   0.4   0:00.03 cilium-+
    396 root      20   0 1229744   9912   3836 S   0.0   0.3   0:04.30 cilium-+
   3208 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3231 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3232 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3273 root      20   0       0      0      0 R   0.0   0.0   0:00.00 ip
