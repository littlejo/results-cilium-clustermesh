Endpoint ID: 247
Path: /sys/fs/bpf/tc/globals/cilium_policy_00247

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2720     29        0        
Allow    Ingress     1          ANY          NONE         disabled    140977   1618      0        
Allow    Egress      0          ANY          NONE         disabled    19205    214       0        


Endpoint ID: 581
Path: /sys/fs/bpf/tc/globals/cilium_policy_00581

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 722
Path: /sys/fs/bpf/tc/globals/cilium_policy_00722

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6201188   76640     0        
Allow    Ingress     1          ANY          NONE         disabled    62756     757       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 867
Path: /sys/fs/bpf/tc/globals/cilium_policy_00867

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1155
Path: /sys/fs/bpf/tc/globals/cilium_policy_01155

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    353590   4133      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1612
Path: /sys/fs/bpf/tc/globals/cilium_policy_01612

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5495486   56386     0        
Allow    Ingress     1          ANY          NONE         disabled    5062983   53287     0        
Allow    Egress      0          ANY          NONE         disabled    5487255   56725     0        


Endpoint ID: 2362
Path: /sys/fs/bpf/tc/globals/cilium_policy_02362

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3315
Path: /sys/fs/bpf/tc/globals/cilium_policy_03315

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3176     31        0        
Allow    Ingress     1          ANY          NONE         disabled    140647   1613      0        
Allow    Egress      0          ANY          NONE         disabled    19142    211       0        


