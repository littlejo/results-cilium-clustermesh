KEY             VALUE
AgentLiveness   1926974839507
UTimeOffset     3378461990234375
