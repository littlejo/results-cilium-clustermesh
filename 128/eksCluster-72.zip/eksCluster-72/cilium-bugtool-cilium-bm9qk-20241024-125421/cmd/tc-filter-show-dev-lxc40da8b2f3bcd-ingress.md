filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc40da8b2f3bcd direct-action not_in_hw id 3322 tag 21b0a35374c870e4 jited 
