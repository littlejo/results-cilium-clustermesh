[
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9a8106f_1402_4155_89f6_4e43bc250728.slice/cri-containerd-1d4d1fed8f5ac2bceb0534cf7121f69bbd7928d9ed01446524b974d57c619f6e.scope"
      }
    ],
    "ips": [
      "10.81.0.22"
    ],
    "name": "client2-57cf4468f-tmcx4",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8316c4e_4e05_4730_81a5_dbbb97362c5c.slice/cri-containerd-28253c17d71fdf7ff48430c773b3d42876164e34384c295f6d8c89d607704f8c.scope"
      }
    ],
    "ips": [
      "10.81.0.59"
    ],
    "name": "coredns-cc6ccd49c-5nqz2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bad5210_c3dc_448f_bcc6_e176a1b75e6c.slice/cri-containerd-7a091cc5698c6a45334c7a5de7fcc7123fc6b33cbf5afa16fbfe8c70f06b4ad8.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bad5210_c3dc_448f_bcc6_e176a1b75e6c.slice/cri-containerd-fd38703b37f1ea3e0a63c40cfc8c292e31124ac9fe5ad4660a7beca024d2eed9.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bad5210_c3dc_448f_bcc6_e176a1b75e6c.slice/cri-containerd-b179e805f119584ba72919fde09de26e5603d5f7229f65a381779c64b3341ef8.scope"
      }
    ],
    "ips": [
      "10.81.0.104"
    ],
    "name": "clustermesh-apiserver-56b6f687c8-hlxld",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8500896_c36a_466c_93dc_8547f4039a35.slice/cri-containerd-477e01d6308610173dac8003a8671199a5209f5f91ade17be44ef8c30dfde474.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8500896_c36a_466c_93dc_8547f4039a35.slice/cri-containerd-79e872bbb8ea5b151592c14245fc2ddb025687d3e7a9dbe1d1e5cc48dfdec616.scope"
      }
    ],
    "ips": [
      "10.81.0.230"
    ],
    "name": "echo-same-node-86d9cc975c-p66wf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8490ab27_e6e6_4e9e_bbbd_c6ab18b167c3.slice/cri-containerd-df6759309b9775c164510af94e295ebcaa06293f4688d9b09cbcaa70a8180414.scope"
      }
    ],
    "ips": [
      "10.81.0.58"
    ],
    "name": "coredns-cc6ccd49c-bc6vz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb01422c_9098_4886_a544_e98c3b10b924.slice/cri-containerd-1e7c8d5bea0f1f4dd4016a3a5bc525928b392ecd6e88d43dde237ff5a1541812.scope"
      }
    ],
    "ips": [
      "10.81.0.185"
    ],
    "name": "client-974f6c69d-9dp7z",
    "namespace": "cilium-test-1"
  }
]

