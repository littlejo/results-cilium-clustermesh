CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9899b30a_a7cf_4f48_b7c6_0a64c3a93347.slice/cri-containerd-0a418a41db3a60e44ab2165ab3bef4dcb3a0b8981ad2f165ba3f6e62bbdf346d.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9899b30a_a7cf_4f48_b7c6_0a64c3a93347.slice/cri-containerd-585c8cc608e28c0789ad3877075997b8a23acb85a7b80cbb47b2427c043d7baa.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8490ab27_e6e6_4e9e_bbbd_c6ab18b167c3.slice/cri-containerd-df6759309b9775c164510af94e295ebcaa06293f4688d9b09cbcaa70a8180414.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8490ab27_e6e6_4e9e_bbbd_c6ab18b167c3.slice/cri-containerd-ebd36c8dfcafe078b4f79a5240cbfb248e9952487a5d46e6425c29f98f8d4910.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4053b83_9781_4c30_a2ed_f6114fb00fb7.slice/cri-containerd-d1a2d3a1c2ddf7bd9ecdd93392a02705ed89bc4dc3f010707147b6908122031c.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4053b83_9781_4c30_a2ed_f6114fb00fb7.slice/cri-containerd-a015efc0d61fe0ed158914488212703b59ea0a0704eb1cefa49aadf4f758c2c4.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8316c4e_4e05_4730_81a5_dbbb97362c5c.slice/cri-containerd-b3e64b3ba2016122112ec2bf7233e9d5452828389996a29b2a48943f018a2d9f.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8316c4e_4e05_4730_81a5_dbbb97362c5c.slice/cri-containerd-28253c17d71fdf7ff48430c773b3d42876164e34384c295f6d8c89d607704f8c.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bad1559_0304_40a4_b759_4f8a53d6c68d.slice/cri-containerd-cbba8be3e9ebbd5640e2d6c6d5a9413dfa8664d5a25d8f3eccda1f105fde82ba.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bad1559_0304_40a4_b759_4f8a53d6c68d.slice/cri-containerd-8e68ba12236b4355bb802871465911befde8021c4aa7c12137f91b816fc7fbca.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb01422c_9098_4886_a544_e98c3b10b924.slice/cri-containerd-3aef516f7952c0b5629f62b48808e4d832ce6fa5f8d5b29a9cd2757bd53b483f.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb01422c_9098_4886_a544_e98c3b10b924.slice/cri-containerd-1e7c8d5bea0f1f4dd4016a3a5bc525928b392ecd6e88d43dde237ff5a1541812.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37bc2511_3a97_481b_8b7c_d3ddf35e2532.slice/cri-containerd-d31d860b8116207a073f7a0e86939b0029802f4181cc9a85f3f616549cdd47b8.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37bc2511_3a97_481b_8b7c_d3ddf35e2532.slice/cri-containerd-5ecdb4e5be1d27a87941b8fb78fb12cbf241205a179aded39d7545e4da0e037e.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9a8106f_1402_4155_89f6_4e43bc250728.slice/cri-containerd-26f7701c718535e61a4f083f8fc9943809b74320bf3976d7ff7ed4e3225d0c53.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9a8106f_1402_4155_89f6_4e43bc250728.slice/cri-containerd-1d4d1fed8f5ac2bceb0534cf7121f69bbd7928d9ed01446524b974d57c619f6e.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8500896_c36a_466c_93dc_8547f4039a35.slice/cri-containerd-36bcbe3cca42db10d122fca37a8f821d6953f2e498c9e98602fafb477afe2eff.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8500896_c36a_466c_93dc_8547f4039a35.slice/cri-containerd-477e01d6308610173dac8003a8671199a5209f5f91ade17be44ef8c30dfde474.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8500896_c36a_466c_93dc_8547f4039a35.slice/cri-containerd-79e872bbb8ea5b151592c14245fc2ddb025687d3e7a9dbe1d1e5cc48dfdec616.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bad5210_c3dc_448f_bcc6_e176a1b75e6c.slice/cri-containerd-7a091cc5698c6a45334c7a5de7fcc7123fc6b33cbf5afa16fbfe8c70f06b4ad8.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bad5210_c3dc_448f_bcc6_e176a1b75e6c.slice/cri-containerd-47fc4080e0d81a58f14ed717551b858380bd8afab84a8f618fbda0e41102bae5.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bad5210_c3dc_448f_bcc6_e176a1b75e6c.slice/cri-containerd-fd38703b37f1ea3e0a63c40cfc8c292e31124ac9fe5ad4660a7beca024d2eed9.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bad5210_c3dc_448f_bcc6_e176a1b75e6c.slice/cri-containerd-b179e805f119584ba72919fde09de26e5603d5f7229f65a381779c64b3341ef8.scope
    653      cgroup_device   multi                                          
