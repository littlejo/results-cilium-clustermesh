xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 505
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 495
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 491
cilium_host(7) clsact/egress cil_from_host-cilium_host id 494
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 551
lxc673a5272fbd0(12) clsact/ingress cil_from_container-lxc673a5272fbd0 id 540
lxc5beb4e4453c7(14) clsact/ingress cil_from_container-lxc5beb4e4453c7 id 524
lxcad478bd4a00a(18) clsact/ingress cil_from_container-lxcad478bd4a00a id 621
lxc2e6fb60dcd22(20) clsact/ingress cil_from_container-lxc2e6fb60dcd22 id 3306
lxcab3ddaa7c01c(22) clsact/ingress cil_from_container-lxcab3ddaa7c01c id 3358
lxc195e1dc400bf(24) clsact/ingress cil_from_container-lxc195e1dc400bf id 3350

flow_dissector:

netfilter:

