35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:29+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:29+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:30+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:30+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:30+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:30+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:34+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
110: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
113: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:30:21+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:30:21+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:30:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag 65095b04778ee217  gpl
	loaded_at 2024-10-24T12:30:21+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
489: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 130
491: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 132
492: sched_cls  name __send_drop_notify  tag 3d236430639c48c9  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 133
493: sched_cls  name tail_handle_ipv4_from_host  tag 37f1b8921d4c3296  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 134
494: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,101
	btf_id 135
495: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 137
496: sched_cls  name __send_drop_notify  tag 3d236430639c48c9  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 138
497: sched_cls  name tail_handle_ipv4_from_host  tag 37f1b8921d4c3296  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 139
500: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 142
504: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 147
505: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 148
507: sched_cls  name __send_drop_notify  tag 3d236430639c48c9  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 150
508: sched_cls  name tail_handle_ipv4_from_host  tag 37f1b8921d4c3296  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 151
511: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 155
512: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 156
514: sched_cls  name __send_drop_notify  tag 3d236430639c48c9  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 158
515: sched_cls  name tail_handle_ipv4_from_host  tag 37f1b8921d4c3296  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 159
522: sched_cls  name handle_policy  tag ec1d2292b38ed218  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 165
523: sched_cls  name tail_ipv4_ct_ingress  tag a35e8ba4ba996ff4  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 170
524: sched_cls  name cil_from_container  tag 7898173138dfa6d0  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 171
529: sched_cls  name tail_ipv4_to_endpoint  tag 3f12c6539d2c1278  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 172
530: sched_cls  name tail_handle_ipv4_cont  tag 2c5f4dc7c717d5e9  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 177
532: sched_cls  name __send_drop_notify  tag d4e2b35a3fbba7d9  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
533: sched_cls  name tail_handle_arp  tag efab612078e93903  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 180
535: sched_cls  name tail_ipv4_ct_egress  tag d205280989038b2f  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 181
536: sched_cls  name __send_drop_notify  tag 85e6cfd591e6d03e  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 184
537: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 182
538: sched_cls  name tail_handle_ipv4_cont  tag a404dde24ba35a23  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 185
539: sched_cls  name tail_handle_arp  tag b03fca39e3c5f2ad  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 187
540: sched_cls  name cil_from_container  tag 3794cc7e783613d9  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 188
541: sched_cls  name tail_handle_ipv4  tag cad3fe362bd4511c  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 186
542: sched_cls  name tail_handle_ipv4  tag 60c9444479f42964  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 189
543: sched_cls  name tail_ipv4_ct_ingress  tag 23a163cdf9c7c28c  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 192
545: sched_cls  name handle_policy  tag 6b7978b6c87f8174  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 191
546: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 195
547: sched_cls  name tail_handle_arp  tag 2f1dfed28bbff988  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 196
548: sched_cls  name tail_handle_ipv4  tag 56513d20252d8201  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 197
549: sched_cls  name tail_ipv4_to_endpoint  tag e6bc6cbaefffbd92  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 194
550: sched_cls  name tail_ipv4_ct_ingress  tag 794ffd94c9a3ba10  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 198
551: sched_cls  name cil_from_container  tag e4548ea2a6358ccc  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 199
553: sched_cls  name __send_drop_notify  tag 1637518bf225122e  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
554: sched_cls  name tail_handle_ipv4_cont  tag bdea8bf1834b03ab  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,117,40,37,38,81
	btf_id 202
555: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 203
556: sched_cls  name tail_ipv4_to_endpoint  tag fa6276df56bdd5cd  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,117,40,37,38
	btf_id 204
557: sched_cls  name handle_policy  tag a7205937b29f803e  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 205
558: sched_cls  name tail_ipv4_ct_egress  tag d205280989038b2f  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 206
559: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 207
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
567: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
575: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
615: sched_cls  name tail_ipv4_ct_egress  tag a960a45c1dcd87b7  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 221
616: sched_cls  name tail_handle_ipv4  tag 86cac3ce52ddf7fd  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 222
617: sched_cls  name tail_handle_ipv4_cont  tag 813fe6af305ad3c4  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 223
618: sched_cls  name tail_handle_arp  tag e98c35deee1e601e  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 224
619: sched_cls  name __send_drop_notify  tag 920c2f3805de750d  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 225
620: sched_cls  name tail_ipv4_ct_ingress  tag b4b489734bdca22a  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 226
621: sched_cls  name cil_from_container  tag 895c41642a02b128  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 227
623: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 229
624: sched_cls  name tail_ipv4_to_endpoint  tag 295a6b54929900ee  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 230
625: sched_cls  name handle_policy  tag 6524af00dc5610ca  gpl
	loaded_at 2024-10-24T12:42:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 231
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
687: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
690: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
691: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
694: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
695: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
698: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3289: sched_cls  name __send_drop_notify  tag b42261eedf04181b  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3077
3290: sched_cls  name tail_ipv4_ct_egress  tag d596b88c41fc18c5  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3078
3291: sched_cls  name tail_handle_arp  tag 771022e348570570  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3079
3298: sched_cls  name handle_policy  tag 51de304d78b22d50  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,143,39,84,75,40,37,38
	btf_id 3081
3299: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3089
3301: sched_cls  name tail_ipv4_ct_ingress  tag 907bf0eda708fb64  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3090
3304: sched_cls  name tail_handle_ipv4  tag 027468d43f4d2e19  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3091
3305: sched_cls  name tail_ipv4_to_endpoint  tag 78104e5167ccc975  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,143,39,627,40,37,38
	btf_id 3095
3306: sched_cls  name cil_from_container  tag 83485cb7c9a5ae14  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3096
3309: sched_cls  name tail_handle_ipv4_cont  tag 25746b0fec2da96c  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,143,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3098
3345: sched_cls  name tail_ipv4_ct_egress  tag 34941c4fd99bfaaf  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3139
3346: sched_cls  name tail_handle_ipv4_cont  tag 7e7eb39dced89395  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,149,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3140
3347: sched_cls  name tail_handle_arp  tag 9d7ea6f101addfd4  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3141
3348: sched_cls  name __send_drop_notify  tag 11bacd80211bec8a  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3142
3349: sched_cls  name tail_ipv4_ct_ingress  tag 0db946aa4ae34d90  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3144
3350: sched_cls  name cil_from_container  tag 25b99e0db5de60e5  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3145
3351: sched_cls  name tail_handle_ipv4  tag c12f97f0fe5443ed  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3143
3352: sched_cls  name tail_handle_ipv4  tag f02cb2941e3a3c88  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3146
3353: sched_cls  name tail_ipv4_to_endpoint  tag 636a6c443e3528ce  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,146,39,640,40,37,38
	btf_id 3147
3354: sched_cls  name tail_ipv4_ct_egress  tag d1047a6db384b029  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3148
3355: sched_cls  name tail_handle_arp  tag 0347f7c2f99f94ac  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3149
3356: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3151
3357: sched_cls  name handle_policy  tag ceee97837a95fcab  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,639,41,80,146,39,84,75,40,37,38
	btf_id 3150
3358: sched_cls  name cil_from_container  tag a455ee1840409c06  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3153
3360: sched_cls  name tail_ipv4_to_endpoint  tag c83ed4ae7a09cebe  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,149,39,637,40,37,38
	btf_id 3152
3361: sched_cls  name tail_handle_ipv4_cont  tag 81b04fa52472fc9a  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,146,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3155
3362: sched_cls  name __send_drop_notify  tag 032f11ae54d58751  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3157
3363: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3158
3364: sched_cls  name tail_ipv4_ct_ingress  tag 30d7fe981fc3e737  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3159
3365: sched_cls  name handle_policy  tag da51762478313fad  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,149,39,84,75,40,37,38
	btf_id 3156
