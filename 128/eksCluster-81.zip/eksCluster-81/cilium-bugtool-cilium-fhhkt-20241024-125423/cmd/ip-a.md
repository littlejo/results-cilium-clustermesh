1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:25:f2:a1:dc:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.255.56/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3491sec preferred_lft 3491sec
    inet6 fe80::825:f2ff:fea1:dcd7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:37:f8:a8:be:3f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.222.127/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::837:f8ff:fea8:be3f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:9d:4e:f2:2b:c3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::909d:4eff:fef2:2bc3/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:70:d4:b9:b7:86 brd ff:ff:ff:ff:ff:ff
    inet 10.81.0.173/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::dc70:d4ff:feb9:b786/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:6a:33:26:f8:b3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d86a:33ff:fe26:f8b3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:cd:73:26:8b:15 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d8cd:73ff:fe26:8b15/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc673a5272fbd0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:87:ad:4d:14:7b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c87:adff:fe4d:147b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5beb4e4453c7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:d1:1f:2b:65:d8 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::3cd1:1fff:fe2b:65d8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcad478bd4a00a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:ee:fa:f0:76:34 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::10ee:faff:fef0:7634/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc2e6fb60dcd22@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:77:de:e0:d1:28 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7877:deff:fee0:d128/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcab3ddaa7c01c@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:6e:cb:38:89:06 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::306e:cbff:fe38:8906/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc195e1dc400bf@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:13:3e:de:5e:12 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::5013:3eff:fede:5e12/64 scope link 
       valid_lft forever preferred_lft forever
