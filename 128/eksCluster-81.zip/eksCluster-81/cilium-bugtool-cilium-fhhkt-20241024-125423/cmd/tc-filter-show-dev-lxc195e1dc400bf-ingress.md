filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc195e1dc400bf direct-action not_in_hw id 3350 tag 25b99e0db5de60e5 jited 
