markdown output at /tmp/cilium-bugtool-20241024-125426.217+0000-UTC-1951137126/cmd/cilium-debuginfo-20241024-125456.341+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125426.217+0000-UTC-1951137126/cmd/cilium-debuginfo-20241024-125456.341+0000-UTC.json
