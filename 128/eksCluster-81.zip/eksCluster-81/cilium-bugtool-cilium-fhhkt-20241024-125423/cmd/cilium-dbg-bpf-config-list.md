KEY             VALUE
AgentLiveness   1950404890233
UTimeOffset     3378462003906250
