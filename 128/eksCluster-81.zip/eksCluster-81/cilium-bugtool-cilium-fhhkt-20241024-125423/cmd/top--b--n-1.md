top - 12:54:26 up 32 min,  0 users,  load average: 0.39, 0.47, 0.28
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.7 us, 46.7 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,    236.5 free,   1104.2 used,   2495.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2550.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 296404  79040 S   6.7   7.5   1:05.71 cilium-+
   3264 root      20   0 1243764  19128  13564 S   6.7   0.5   0:00.01 hubble
    394 root      20   0 1229744   8952   2924 S   0.0   0.2   0:04.47 cilium-+
   3181 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3207 root      20   0 1240432  16128  11164 S   0.0   0.4   0:00.02 cilium-+
   3244 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
   3250 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3275 root      20   0 1240432  16128  11164 R   0.0   0.4   0:00.00 cilium-+
