alloc: 127.68MB (133878568 bytes)
total-alloc: 3.08GB (3305034768 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 74971410
frees: 73711969
heap-alloc: 127.68MB (133878568 bytes)
heap-sys: 176.58MB (185155584 bytes)
heap-idle: 27.57MB (28909568 bytes)
heap-in-use: 149.01MB (156246016 bytes)
heap-released: 3.49MB (3661824 bytes)
heap-objects: 1259441
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.31MB (2422240 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 998.02KB (1021969 bytes)
gc-sys: 5.52MB (5788720 bytes)
next-gc: when heap-alloc >= 155.50MB (163057336 bytes)
last-gc: 2024-10-24 12:54:25.797053581 +0000 UTC
gc-pause-total: 11.223627ms
gc-pause: 105574
gc-pause-end: 1729774465797053581
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006164154990322962
enable-gc: true
debug-gc: false
