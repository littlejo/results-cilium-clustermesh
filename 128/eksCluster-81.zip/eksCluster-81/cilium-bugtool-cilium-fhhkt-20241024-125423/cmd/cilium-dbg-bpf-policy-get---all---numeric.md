Endpoint ID: 334
Path: /sys/fs/bpf/tc/globals/cilium_policy_00334

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6162019   61467     0        
Allow    Ingress     1          ANY          NONE         disabled    5190033   54707     0        
Allow    Egress      0          ANY          NONE         disabled    6376457   63663     0        


Endpoint ID: 362
Path: /sys/fs/bpf/tc/globals/cilium_policy_00362

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 480
Path: /sys/fs/bpf/tc/globals/cilium_policy_00480

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382657   4462      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 767
Path: /sys/fs/bpf/tc/globals/cilium_policy_00767

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6229282   77136     0        
Allow    Ingress     1          ANY          NONE         disabled    63333     770       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1429
Path: /sys/fs/bpf/tc/globals/cilium_policy_01429

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1499
Path: /sys/fs/bpf/tc/globals/cilium_policy_01499

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3014     31        0        
Allow    Ingress     1          ANY          NONE         disabled    139595   1605      0        
Allow    Egress      0          ANY          NONE         disabled    19776    218       0        


Endpoint ID: 2044
Path: /sys/fs/bpf/tc/globals/cilium_policy_02044

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2122
Path: /sys/fs/bpf/tc/globals/cilium_policy_02122

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2882     29        0        
Allow    Ingress     1          ANY          NONE         disabled    140453   1618      0        
Allow    Egress      0          ANY          NONE         disabled    18512    205       0        


