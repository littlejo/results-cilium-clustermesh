Node 0, zone      DMA    151    148     40     62    210     87     50     13      4      3     33 
Node 0, zone   Normal    250    104     14      5     27      6      7      3      6      2      6 
