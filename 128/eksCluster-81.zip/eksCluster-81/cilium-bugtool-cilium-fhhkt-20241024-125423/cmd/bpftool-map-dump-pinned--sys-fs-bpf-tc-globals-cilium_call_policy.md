key: 4e 01 00 00  value: 71 02 00 00
key: e0 01 00 00  value: e2 0c 00 00
key: ff 02 00 00  value: 21 02 00 00
key: 95 05 00 00  value: 25 0d 00 00
key: db 05 00 00  value: 0a 02 00 00
key: fc 07 00 00  value: 1d 0d 00 00
key: 4a 08 00 00  value: 2d 02 00 00
Found 7 elements
