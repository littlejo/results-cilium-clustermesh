{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.394Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.402Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.407Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.995Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.046Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.047Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.085Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.103Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.123Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.355Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.376Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.408Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.463Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.473Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.160Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.182Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.227Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.258Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.273Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.522Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.524Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.580Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.667Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.705Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.274Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.310Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.317Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.358Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.374Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.428Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.637Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.647Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.712Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.738Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.761Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.414Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.423Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.455Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.467Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.506Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.520Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.545Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.791Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.797Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.847Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.856Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.896Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.315Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.316Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.374Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.387Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.414Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.661Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.674Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.726Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.754Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.785Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.164Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.189Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.241Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.286Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.326Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.541Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.546Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.605Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.612Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.644Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.079Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.089Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.132Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.156Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.180Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.456Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.483Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.523Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.528Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.577Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.977Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.007Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.018Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.056Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.070Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.096Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.340Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.343Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.446Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.455Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.541Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.903Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.917Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.947Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.966Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.010Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.013Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.287Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.290Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.337Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.354Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.386Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.731Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.734Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.788Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.800Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.826Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.063Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.069Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.121Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.144Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.175Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.440Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.473Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.481Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.549Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.586Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.638Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.831Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.836Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.852Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.892Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.590Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.593Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.631Z",
  "value": "id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.637Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.670Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.925Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.928Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.620Z",
  "value": "id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.626Z",
  "value": "id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12"
}

