Total: 570
TCP:   2854 (estab 308, closed 2527, orphaned 0, timewait 2064)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  327       314       13       
INET	  337       320       17       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.255.56%ens5:68         0.0.0.0:*    uid:192 ino:125912 sk:94d cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33842 sk:94e cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15694 sk:94f cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:37701      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32698 sk:950 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33841 sk:951 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15695 sk:952 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::825:f2ff:fea1:dcd7]%ens5:546           [::]:*    uid:192 ino:15062 sk:953 cgroup:unreachable:bd0 v6only:1 <->                   
