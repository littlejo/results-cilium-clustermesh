IP ADDRESS         LOCAL ENDPOINT INFO
10.81.0.185:0      id=2044  sec_id=5390982 flags=0x0000 ifindex=22  mac=5A:35:CD:1E:EE:77 nodemac=32:6E:CB:38:89:06   
172.31.222.127:0   (localhost)                                                                                        
10.81.0.173:0      (localhost)                                                                                        
10.81.0.11:0       id=767   sec_id=4     flags=0x0000 ifindex=10  mac=D2:AC:D2:77:61:EA nodemac=DA:CD:73:26:8B:15     
10.81.0.230:0      id=480   sec_id=5378577 flags=0x0000 ifindex=20  mac=1A:3E:01:EE:EA:7C nodemac=7A:77:DE:E0:D1:28   
10.81.0.58:0       id=2122  sec_id=5434940 flags=0x0000 ifindex=12  mac=92:49:EF:04:15:31 nodemac=0E:87:AD:4D:14:7B   
172.31.255.56:0    (localhost)                                                                                        
10.81.0.104:0      id=334   sec_id=5377889 flags=0x0000 ifindex=18  mac=7E:BD:B9:38:F5:98 nodemac=12:EE:FA:F0:76:34   
10.81.0.22:0       id=1429  sec_id=5410215 flags=0x0000 ifindex=24  mac=D2:7B:1B:F7:F2:6D nodemac=52:13:3E:DE:5E:12   
10.81.0.59:0       id=1499  sec_id=5434940 flags=0x0000 ifindex=14  mac=CA:DB:92:D2:4E:BB nodemac=3E:D1:1F:2B:65:D8   
