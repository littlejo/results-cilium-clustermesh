 12:54:19 up 33 min,  0 users,  load average: 1.59, 0.74, 0.36
