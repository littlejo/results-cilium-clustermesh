KEY             VALUE
AgentLiveness   2016173430955
UTimeOffset     3378461863281250
