xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 552
ens6(5) clsact/ingress cil_from_netdev-ens6 id 560
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 544
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(7) clsact/egress cil_from_host-cilium_host id 535
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 574
lxc64d709764b3b(12) clsact/ingress cil_from_container-lxc64d709764b3b id 517
lxc12d6cffbbc07(14) clsact/ingress cil_from_container-lxc12d6cffbbc07 id 565
lxcf4b664e07316(18) clsact/ingress cil_from_container-lxcf4b664e07316 id 649
lxca2eff7b3dde6(20) clsact/ingress cil_from_container-lxca2eff7b3dde6 id 3357
lxc650f9256e0ae(22) clsact/ingress cil_from_container-lxc650f9256e0ae id 3348
lxc1a442c7ce5de(24) clsact/ingress cil_from_container-lxc1a442c7ce5de id 3292

flow_dissector:

netfilter:

