IP ADDRESS         LOCAL ENDPOINT INFO
10.30.0.15:0       id=4049  sec_id=2051297 flags=0x0000 ifindex=22  mac=F6:29:E6:2B:F2:52 nodemac=3A:2B:13:1B:CB:41   
10.30.0.202:0      id=425   sec_id=2056851 flags=0x0000 ifindex=18  mac=6A:F7:48:7C:06:50 nodemac=CE:C5:86:D5:55:BC   
172.31.154.75:0    (localhost)                                                                                        
172.31.181.129:0   (localhost)                                                                                        
10.30.0.42:0       id=3727  sec_id=4     flags=0x0000 ifindex=10  mac=66:CF:05:42:C9:BB nodemac=AE:7C:24:B9:32:25     
10.30.0.47:0       (localhost)                                                                                        
10.30.0.164:0      id=1096  sec_id=2043040 flags=0x0000 ifindex=14  mac=72:48:56:F7:14:1D nodemac=6A:38:F1:D7:25:C7   
10.30.0.51:0       id=2839  sec_id=2032030 flags=0x0000 ifindex=24  mac=4E:2E:0D:32:78:CF nodemac=EE:1B:B1:7A:13:0C   
10.30.0.188:0      id=633   sec_id=2096434 flags=0x0000 ifindex=20  mac=2E:A2:34:DE:A3:E7 nodemac=3E:8C:41:41:E7:3F   
10.30.0.184:0      id=792   sec_id=2043040 flags=0x0000 ifindex=12  mac=76:6F:3D:78:76:7B nodemac=6E:CF:6D:93:4F:A2   
