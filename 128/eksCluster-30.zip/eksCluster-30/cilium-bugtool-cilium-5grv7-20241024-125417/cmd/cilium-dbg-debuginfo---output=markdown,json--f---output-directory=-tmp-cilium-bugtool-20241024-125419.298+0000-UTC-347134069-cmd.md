markdown output at /tmp/cilium-bugtool-20241024-125419.298+0000-UTC-347134069/cmd/cilium-debuginfo-20241024-125449.95+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125419.298+0000-UTC-347134069/cmd/cilium-debuginfo-20241024-125449.95+0000-UTC.json
