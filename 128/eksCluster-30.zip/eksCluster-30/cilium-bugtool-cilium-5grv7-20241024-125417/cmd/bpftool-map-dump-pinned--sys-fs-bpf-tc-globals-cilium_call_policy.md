key: a9 01 00 00  value: 86 02 00 00
key: 79 02 00 00  value: 18 0d 00 00
key: 18 03 00 00  value: 0b 02 00 00
key: 48 04 00 00  value: 2b 02 00 00
key: 17 0b 00 00  value: e0 0c 00 00
key: 8f 0e 00 00  value: 42 02 00 00
key: d1 0f 00 00  value: 1e 0d 00 00
Found 7 elements
