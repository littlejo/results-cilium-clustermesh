Endpoint ID: 52
Path: /sys/fs/bpf/tc/globals/cilium_policy_00052

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 425
Path: /sys/fs/bpf/tc/globals/cilium_policy_00425

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6115877   61643     0        
Allow    Ingress     1          ANY          NONE         disabled    5448771   57556     0        
Allow    Egress      0          ANY          NONE         disabled    6941140   68382     0        


Endpoint ID: 633
Path: /sys/fs/bpf/tc/globals/cilium_policy_00633

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 792
Path: /sys/fs/bpf/tc/globals/cilium_policy_00792

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2812     25        0        
Allow    Ingress     1          ANY          NONE         disabled    161018   1854      0        
Allow    Egress      0          ANY          NONE         disabled    20951    235       0        


Endpoint ID: 1096
Path: /sys/fs/bpf/tc/globals/cilium_policy_01096

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3084     35        0        
Allow    Ingress     1          ANY          NONE         disabled    160094   1840      0        
Allow    Egress      0          ANY          NONE         disabled    21491    241       0        


Endpoint ID: 2839
Path: /sys/fs/bpf/tc/globals/cilium_policy_02839

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376792   4402      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3727
Path: /sys/fs/bpf/tc/globals/cilium_policy_03727

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6220981   77036     0        
Allow    Ingress     1          ANY          NONE         disabled    65743     795       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 4049
Path: /sys/fs/bpf/tc/globals/cilium_policy_04049

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


