1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7b:25:61:ff:23 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.181.129/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3425sec preferred_lft 3425sec
    inet6 fe80::47b:25ff:fe61:ff23/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ac:b1:24:a4:ff brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.154.75/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ac:b1ff:fe24:a4ff/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:5d:9b:16:0f:92 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::605d:9bff:fe16:f92/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:3a:f3:b4:7a:e6 brd ff:ff:ff:ff:ff:ff
    inet 10.30.0.47/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::83a:f3ff:feb4:7ae6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 22:b1:f3:d3:5d:82 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::20b1:f3ff:fed3:5d82/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:7c:24:b9:32:25 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ac7c:24ff:feb9:3225/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc64d709764b3b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:cf:6d:93:4f:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::6ccf:6dff:fe93:4fa2/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc12d6cffbbc07@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:38:f1:d7:25:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6838:f1ff:fed7:25c7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf4b664e07316@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:c5:86:d5:55:bc brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ccc5:86ff:fed5:55bc/64 scope link 
       valid_lft forever preferred_lft forever
20: lxca2eff7b3dde6@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:8c:41:41:e7:3f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3c8c:41ff:fe41:e73f/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc650f9256e0ae@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:2b:13:1b:cb:41 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::382b:13ff:fe1b:cb41/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc1a442c7ce5de@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:1b:b1:7a:13:0c brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::ec1b:b1ff:fe7a:130c/64 scope link 
       valid_lft forever preferred_lft forever
