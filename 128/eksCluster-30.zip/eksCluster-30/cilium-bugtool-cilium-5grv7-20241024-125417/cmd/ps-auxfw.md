USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3236  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3229  0.0  0.4 1240176 16080 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3255  0.0  0.0   6408  1640 ?        R    12:54   0:00  \_ ps auxfw
root        3257  0.0  0.0      0     0 ?        Z    12:54   0:00  \_ [hostname] <defunct>
root           1  3.9  7.4 1538804 292536 ?      Ssl  12:26   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 10208 ?       Sl   12:26   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
