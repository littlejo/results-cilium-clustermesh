filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc1a442c7ce5de direct-action not_in_hw id 3292 tag f611c1075ef1b909 jited 
