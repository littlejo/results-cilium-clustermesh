[
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod105fb1b5_897d_4969_a12d_9331a5e7e908.slice/cri-containerd-bea4c17afd86ecbf8afb7b9d51dd65412cbf29690639a1f51e6a5166d3b60d27.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod105fb1b5_897d_4969_a12d_9331a5e7e908.slice/cri-containerd-74f090539dd79ed8d232c992a0dc8f9e8467454090879e8b48701269e36e1f3f.scope"
      }
    ],
    "ips": [
      "10.30.0.51"
    ],
    "name": "echo-same-node-86d9cc975c-4kcqw",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4db846c_016d_40d7_b55d_1fe8d7a2d80b.slice/cri-containerd-3e64db6f6d155ca47411d062f4bb384e14263184acbccc3026be650af8140e95.scope"
      }
    ],
    "ips": [
      "10.30.0.15"
    ],
    "name": "client2-57cf4468f-rqcsm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podad8b64a8_d35e_4fb0_bf89_0fd562e051a9.slice/cri-containerd-0ea4da7c75d26bf56018b548ffde39804793e1f1b11856335d812344c4ae5ad6.scope"
      }
    ],
    "ips": [
      "10.30.0.188"
    ],
    "name": "client-974f6c69d-2l8nb",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b847811_fc2e_4c90_b452_ed7756838246.slice/cri-containerd-1cc7ecef28025058ac220f9374b37277b600bcc09f6f2d4f7dcba01003ec720a.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b847811_fc2e_4c90_b452_ed7756838246.slice/cri-containerd-1dca8793bfed62573dd5761cc27850d3a6097361007f741435d78d03b9964d80.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b847811_fc2e_4c90_b452_ed7756838246.slice/cri-containerd-0de2d853d7beb67385afb4031a7b1682ceb748f4eb138cebe01ab5a1163eb8be.scope"
      }
    ],
    "ips": [
      "10.30.0.202"
    ],
    "name": "clustermesh-apiserver-5cd5f6c769-jfm2m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda92d490a_5ffc_49c6_b3c1_3259b4cab111.slice/cri-containerd-2a9b54ad82ea47783b99457b3efb91495f1a57428f724958d5ce3d422dab2a7a.scope"
      }
    ],
    "ips": [
      "10.30.0.164"
    ],
    "name": "coredns-cc6ccd49c-nvf9f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd897b8bd_e4b7_4e68_a0b3_63cfa61c96c4.slice/cri-containerd-c5ca77cb90255ab9d5353403972891e478f3a8c5049f51bf1b27c2b265211fd7.scope"
      }
    ],
    "ips": [
      "10.30.0.184"
    ],
    "name": "coredns-cc6ccd49c-f2cbz",
    "namespace": "kube-system"
  }
]

