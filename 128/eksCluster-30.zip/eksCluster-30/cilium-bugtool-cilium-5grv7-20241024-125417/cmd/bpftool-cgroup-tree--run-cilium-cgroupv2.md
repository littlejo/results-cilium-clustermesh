CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda92d490a_5ffc_49c6_b3c1_3259b4cab111.slice/cri-containerd-777100cc13dd7117cc3383c8faae81036c594b5a2ca034233b88d1d008096424.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda92d490a_5ffc_49c6_b3c1_3259b4cab111.slice/cri-containerd-2a9b54ad82ea47783b99457b3efb91495f1a57428f724958d5ce3d422dab2a7a.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68dbabc7_5b77_49ac_9363_87f0090b8c2d.slice/cri-containerd-59f46e178fd48bd7d97c9a5656d02faa3221cfc2fda86ea2e25d179efa7dae9d.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68dbabc7_5b77_49ac_9363_87f0090b8c2d.slice/cri-containerd-ef021f980e8e11272dcf4320987edaaa985c727b2fca78c5dc2b1c11401ddc54.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd897b8bd_e4b7_4e68_a0b3_63cfa61c96c4.slice/cri-containerd-9e54e02649d5307f684ea7dd122daa6da2c87731129616faa711cef85fe6baef.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd897b8bd_e4b7_4e68_a0b3_63cfa61c96c4.slice/cri-containerd-c5ca77cb90255ab9d5353403972891e478f3a8c5049f51bf1b27c2b265211fd7.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7428196e_b4fc_465f_89b9_52683f2ab49d.slice/cri-containerd-16aa76bcf1ee70a94a557b0cab5c0e09e86bb3fa367a53ccf830380c7e0b5f06.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7428196e_b4fc_465f_89b9_52683f2ab49d.slice/cri-containerd-578dc6ad6156f4ad0aa2b7a1713f8c0c80a018fed3e462d302ebe54663c31669.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podad8b64a8_d35e_4fb0_bf89_0fd562e051a9.slice/cri-containerd-0ea4da7c75d26bf56018b548ffde39804793e1f1b11856335d812344c4ae5ad6.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podad8b64a8_d35e_4fb0_bf89_0fd562e051a9.slice/cri-containerd-ac1404023427eb95291308455426cb4f8744d7f0a24e3898bdfab0ec95d7e79e.scope
    693      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod105fb1b5_897d_4969_a12d_9331a5e7e908.slice/cri-containerd-bea4c17afd86ecbf8afb7b9d51dd65412cbf29690639a1f51e6a5166d3b60d27.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod105fb1b5_897d_4969_a12d_9331a5e7e908.slice/cri-containerd-74f090539dd79ed8d232c992a0dc8f9e8467454090879e8b48701269e36e1f3f.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod105fb1b5_897d_4969_a12d_9331a5e7e908.slice/cri-containerd-35e1960a9ce843c8a9bacb82da5ffc0a899909fd7fba057df1f44111a7d379ac.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4db846c_016d_40d7_b55d_1fe8d7a2d80b.slice/cri-containerd-6bbfd17b345d6b8b102a36cf2d6bb11e5afa0d927a32c7532244c508c56d4bcc.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4db846c_016d_40d7_b55d_1fe8d7a2d80b.slice/cri-containerd-3e64db6f6d155ca47411d062f4bb384e14263184acbccc3026be650af8140e95.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc366190_9e4f_4f00_9526_47259f09126c.slice/cri-containerd-5a5541b0eb3b4c1ab10cdb52df855ffefad4ad1701a6c967f7034e650766c5a8.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc366190_9e4f_4f00_9526_47259f09126c.slice/cri-containerd-9c14e0e7d7f7ae7968e9eaa6cfcc64d0a5037a7f9fa4e67b45911c5d3aadf3fd.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b847811_fc2e_4c90_b452_ed7756838246.slice/cri-containerd-1cc7ecef28025058ac220f9374b37277b600bcc09f6f2d4f7dcba01003ec720a.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b847811_fc2e_4c90_b452_ed7756838246.slice/cri-containerd-0de2d853d7beb67385afb4031a7b1682ceb748f4eb138cebe01ab5a1163eb8be.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b847811_fc2e_4c90_b452_ed7756838246.slice/cri-containerd-0d9b176096875ec51c73af28f54b6fd1c7b6183f3c6741ef469b29f07305697a.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b847811_fc2e_4c90_b452_ed7756838246.slice/cri-containerd-1dca8793bfed62573dd5761cc27850d3a6097361007f741435d78d03b9964d80.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabad364f_65e9_4c7e_90fa_3cda811acca2.slice/cri-containerd-58a111eeca9a100835c245bba273f29e2d5571a6c5299b6941c0495d83b9ad9f.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabad364f_65e9_4c7e_90fa_3cda811acca2.slice/cri-containerd-fe8d1e4ea953b5f7196c7e72d4bf6cd1148b28dc0f47d5a02a57f47b0846ab10.scope
    94       cgroup_device   multi                                          
