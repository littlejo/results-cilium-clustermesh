alloc: 124.31MB (130343960 bytes)
total-alloc: 3.11GB (3343668096 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 75525545
frees: 74268909
heap-alloc: 124.31MB (130343960 bytes)
heap-sys: 176.48MB (185057280 bytes)
heap-idle: 27.59MB (28925952 bytes)
heap-in-use: 148.90MB (156131328 bytes)
heap-released: 10.60MB (11116544 bytes)
heap-objects: 1256636
stack-in-use: 35.47MB (37191680 bytes)
stack-sys: 35.47MB (37191680 bytes)
stack-mspan-inuse: 2.37MB (2488480 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 741.81KB (759609 bytes)
gc-sys: 5.54MB (5807272 bytes)
next-gc: when heap-alloc >= 154.56MB (162069080 bytes)
last-gc: 2024-10-24 12:54:18.736809758 +0000 UTC
gc-pause-total: 17.876874ms
gc-pause: 84489
gc-pause-end: 1729774458736809758
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005316258421640545
enable-gc: true
debug-gc: false
