Node 0, zone      DMA    251     30      4     26     26     13      8     16      5      6     37 
Node 0, zone   Normal    121    154      2      3      9     13      6      9      4      2      6 
