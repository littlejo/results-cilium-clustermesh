top - 12:54:21 up 32 min,  0 users,  load average: 0.38, 0.56, 0.34
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 14.3 us, 25.0 sy,  0.0 ni, 57.1 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   3836.2 total,    296.7 free,   1041.6 used,   2497.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2613.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 283360  78200 S   6.7   7.2   1:07.56 cilium-+
   3157 root      20   0 1240432  16328  11356 S   6.7   0.4   0:00.02 cilium-+
    402 root      20   0 1229744   9124   3052 S   0.0   0.2   0:04.48 cilium-+
   3159 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3182 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3183 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3193 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3231 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3250 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
