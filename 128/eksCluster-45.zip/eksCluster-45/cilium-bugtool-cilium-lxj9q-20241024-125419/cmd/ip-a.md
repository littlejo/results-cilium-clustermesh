1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5f:cd:53:1b:0b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.217.21/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3437sec preferred_lft 3437sec
    inet6 fe80::85f:cdff:fe53:1b0b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ff:9d:a7:db:e1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.201.203/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8ff:9dff:fea7:dbe1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:1c:17:6c:e6:de brd ff:ff:ff:ff:ff:ff
    inet6 fe80::801c:17ff:fe6c:e6de/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:37:2f:13:71:28 brd ff:ff:ff:ff:ff:ff
    inet 10.45.0.10/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7837:2fff:fe13:7128/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9e:89:63:8d:f5:27 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9c89:63ff:fe8d:f527/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:88:0c:0d:ea:4b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4088:cff:fe0d:ea4b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd750312792a8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:c8:a8:36:b7:8a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5cc8:a8ff:fe36:b78a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7d35cfc7487b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:6b:10:5f:a3:0c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a46b:10ff:fe5f:a30c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce0cb502e5c54@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:9b:1e:20:be:0f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e49b:1eff:fe20:be0f/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc780746fa2691@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:8d:be:b0:be:37 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::148d:beff:feb0:be37/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcfece270c54dd@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:b3:7b:e2:66:b8 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::f0b3:7bff:fee2:66b8/64 scope link 
       valid_lft forever preferred_lft forever
24: lxce704cde44157@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:5f:c0:26:c8:57 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::3c5f:c0ff:fe26:c857/64 scope link 
       valid_lft forever preferred_lft forever
