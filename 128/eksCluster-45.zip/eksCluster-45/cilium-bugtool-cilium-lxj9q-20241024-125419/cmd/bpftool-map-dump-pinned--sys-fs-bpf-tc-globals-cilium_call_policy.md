key: 99 00 00 00  value: 45 0d 00 00
key: f6 01 00 00  value: 3f 0d 00 00
key: da 03 00 00  value: 05 02 00 00
key: cd 04 00 00  value: 14 02 00 00
key: 9b 05 00 00  value: 77 02 00 00
key: b5 05 00 00  value: 26 02 00 00
key: c3 0e 00 00  value: 0c 0d 00 00
Found 7 elements
