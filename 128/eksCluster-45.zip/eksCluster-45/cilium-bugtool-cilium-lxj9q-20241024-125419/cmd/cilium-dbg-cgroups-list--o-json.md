[
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88ac3015_9eff_43fd_884b_e6e6c533e99a.slice/cri-containerd-9ba2dd26c0a01992b9d307e4a5e7c41e1f1320a13973aa766f20e6aa87e3fa2b.scope"
      }
    ],
    "ips": [
      "10.45.0.168"
    ],
    "name": "client2-57cf4468f-mpllk",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3547a0c9_b217_4b9f_8886_335f101acf05.slice/cri-containerd-2c670a30bcc1ec1afbbfe00d0b3bef73a8dfd23ae8a81b6c6f2c7bb159bae363.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3547a0c9_b217_4b9f_8886_335f101acf05.slice/cri-containerd-9406660a17409648bb988f93f6c9d5f2088a80786cabc2c8172a02414f9ab866.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3547a0c9_b217_4b9f_8886_335f101acf05.slice/cri-containerd-14c2159abccac994a4c8a602d2fafc08a3f49407004bdc8e4eadf4c487e51f78.scope"
      }
    ],
    "ips": [
      "10.45.0.241"
    ],
    "name": "clustermesh-apiserver-96659879d-lsvfj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab734bc8_d8f3_4b62_9444_98a1e3980232.slice/cri-containerd-bf2a298990c52f1a416a16d8b67ab8843db6f0567c49c1e0af8f59beaabc0fd5.scope"
      }
    ],
    "ips": [
      "10.45.0.34"
    ],
    "name": "coredns-cc6ccd49c-jv8bx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dc4dd81_dbfd_49c7_8a90_37a18f11eb95.slice/cri-containerd-d1324520a35c2b69a4eb3174e5532a0f797760acad499126e832eedcf40e07b8.scope"
      }
    ],
    "ips": [
      "10.45.0.218"
    ],
    "name": "coredns-cc6ccd49c-zb6k7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9adc4599_4c82_4a0b_8e86_aa7d160f40d7.slice/cri-containerd-b3df041ed80a4d552b55a1c8a035768002c31abbc6fc766fbb8b2510ffb04476.scope"
      }
    ],
    "ips": [
      "10.45.0.79"
    ],
    "name": "client-974f6c69d-wnvk4",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7ab0fba_4ab2_48d2_a6cf_80077555d0d7.slice/cri-containerd-76d0a345bc62bec52394b8a77bed6259fb12511c4cc30608e52dc7c4159eaf5c.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7ab0fba_4ab2_48d2_a6cf_80077555d0d7.slice/cri-containerd-835e82427fb5c443349578d3f8879794ccc0c52d8bf33bf2561252a2183b125e.scope"
      }
    ],
    "ips": [
      "10.45.0.30"
    ],
    "name": "echo-same-node-86d9cc975c-6582k",
    "namespace": "cilium-test-1"
  }
]

