USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3193  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3183  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3182  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3159  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3157  0.0  0.4 1240176 15892 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3220  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3221  0.0  0.0   3852  1292 ?        R    12:54   0:00  \_ bash -c hostname
root           1  4.1  7.2 1538804 283360 ?      Ssl  12:27   1:07 cilium-agent --config-dir=/tmp/cilium/config-map
root         402  0.2  0.2 1229744 9124 ?        Sl   12:27   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
