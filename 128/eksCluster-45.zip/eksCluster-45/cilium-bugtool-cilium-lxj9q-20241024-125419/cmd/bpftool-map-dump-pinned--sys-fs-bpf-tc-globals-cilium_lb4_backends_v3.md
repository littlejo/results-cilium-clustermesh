key: 02 00 00 00  value: ac 1f c3 44 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 2d 00 22 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f d9 15 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 9d 55 01 bb 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 2d 00 1e 1f 90 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 2d 00 f1 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 2d 00 da 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 2d 00 da 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 2d 00 22 00 35 00 00  00 00 00 00
Found 9 elements
