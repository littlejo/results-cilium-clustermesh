Node 0, zone      DMA    183     98     20     23      3      8     10      3      3      2     39 
Node 0, zone   Normal    162     31      2      3      6      6      5      3      3      5      6 
