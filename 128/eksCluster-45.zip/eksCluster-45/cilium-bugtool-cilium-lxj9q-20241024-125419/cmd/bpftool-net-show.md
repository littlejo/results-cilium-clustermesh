xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 579
ens6(5) clsact/ingress cil_from_netdev-ens6 id 585
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 565
cilium_host(7) clsact/egress cil_from_host-cilium_host id 563
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 538
lxcd750312792a8(12) clsact/ingress cil_from_container-lxcd750312792a8 id 522
lxc7d35cfc7487b(14) clsact/ingress cil_from_container-lxc7d35cfc7487b id 511
lxce0cb502e5c54(18) clsact/ingress cil_from_container-lxce0cb502e5c54 id 635
lxc780746fa2691(20) clsact/ingress cil_from_container-lxc780746fa2691 id 3377
lxcfece270c54dd(22) clsact/ingress cil_from_container-lxcfece270c54dd id 3395
lxce704cde44157(24) clsact/ingress cil_from_container-lxce704cde44157 id 3336

flow_dissector:

netfilter:

