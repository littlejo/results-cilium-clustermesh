markdown output at /tmp/cilium-bugtool-20241024-125420.87+0000-UTC-3553314188/cmd/cilium-debuginfo-20241024-125451.782+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125420.87+0000-UTC-3553314188/cmd/cilium-debuginfo-20241024-125451.782+0000-UTC.json
