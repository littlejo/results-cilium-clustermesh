IP ADDRESS         LOCAL ENDPOINT INFO
172.31.201.203:0   (localhost)                                                                                        
172.31.217.21:0    (localhost)                                                                                        
10.45.0.241:0      id=1435  sec_id=3024311 flags=0x0000 ifindex=18  mac=BE:6B:E8:CD:69:DF nodemac=E6:9B:1E:20:BE:0F   
10.45.0.168:0      id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37   
10.45.0.59:0       id=1461  sec_id=4     flags=0x0000 ifindex=10  mac=DE:79:7F:23:BF:B0 nodemac=42:88:0C:0D:EA:4B     
10.45.0.34:0       id=986   sec_id=3055637 flags=0x0000 ifindex=14  mac=46:31:64:BD:20:50 nodemac=A6:6B:10:5F:A3:0C   
10.45.0.30:0       id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57   
10.45.0.79:0       id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8   
10.45.0.10:0       (localhost)                                                                                        
10.45.0.218:0      id=1229  sec_id=3055637 flags=0x0000 ifindex=12  mac=1A:48:F8:90:4E:5C nodemac=5E:C8:A8:36:B7:8A   
