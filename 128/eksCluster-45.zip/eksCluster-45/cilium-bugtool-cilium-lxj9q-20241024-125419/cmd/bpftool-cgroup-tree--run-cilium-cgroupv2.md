CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab734bc8_d8f3_4b62_9444_98a1e3980232.slice/cri-containerd-bf2a298990c52f1a416a16d8b67ab8843db6f0567c49c1e0af8f59beaabc0fd5.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab734bc8_d8f3_4b62_9444_98a1e3980232.slice/cri-containerd-ef010ca8c0741ecb13e2179761f8a42907ac4c10f9d44291d5d522a7f3fdff9d.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dc4dd81_dbfd_49c7_8a90_37a18f11eb95.slice/cri-containerd-4bb249a2017358c83a4863f090143e6e39f431bc1d319d4fba7ccd55203d7689.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dc4dd81_dbfd_49c7_8a90_37a18f11eb95.slice/cri-containerd-d1324520a35c2b69a4eb3174e5532a0f797760acad499126e832eedcf40e07b8.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podacbf0a44_28dd_430d_ab64_f5de997db45e.slice/cri-containerd-b67a9d13870dbaf8b51ac5fc833010287524273bbcefaf8b908a046c61df411e.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podacbf0a44_28dd_430d_ab64_f5de997db45e.slice/cri-containerd-b68ec6be76a0eeb5b524b6ea3743448a64e7ebb3b5b46fb11672a35419d794cf.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4be9aaf1_d381_435a_b207_a300224d249b.slice/cri-containerd-2791651d55afcccd3c4267e6af0a3aa8efd17ae2cdb32f77bc84e2706488b2f2.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4be9aaf1_d381_435a_b207_a300224d249b.slice/cri-containerd-3a2a971415666ddb454850f1e412e57b6aae80c76a87f79b9bd33e2652e9bf26.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69397615_ce96_4bb6_a863_c35682c73595.slice/cri-containerd-939c987c8d60942192c0f7b08c691752960842e820393baf33561517971236d3.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69397615_ce96_4bb6_a863_c35682c73595.slice/cri-containerd-3bb802dd8707bd6bfbbe436cdcec2f06e25f19de1ee9e53e68e99d585929c249.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3547a0c9_b217_4b9f_8886_335f101acf05.slice/cri-containerd-9406660a17409648bb988f93f6c9d5f2088a80786cabc2c8172a02414f9ab866.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3547a0c9_b217_4b9f_8886_335f101acf05.slice/cri-containerd-2c670a30bcc1ec1afbbfe00d0b3bef73a8dfd23ae8a81b6c6f2c7bb159bae363.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3547a0c9_b217_4b9f_8886_335f101acf05.slice/cri-containerd-14c2159abccac994a4c8a602d2fafc08a3f49407004bdc8e4eadf4c487e51f78.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3547a0c9_b217_4b9f_8886_335f101acf05.slice/cri-containerd-b57ce4cef890ebbad3c4a6ddbd07f953da44388d66c37a140139c6058951c600.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88ac3015_9eff_43fd_884b_e6e6c533e99a.slice/cri-containerd-9ba2dd26c0a01992b9d307e4a5e7c41e1f1320a13973aa766f20e6aa87e3fa2b.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88ac3015_9eff_43fd_884b_e6e6c533e99a.slice/cri-containerd-eed53828be9de3aa5cce9f96d470f51b39f8b1b0d20decd444a3c280ce41d97e.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7ab0fba_4ab2_48d2_a6cf_80077555d0d7.slice/cri-containerd-76d0a345bc62bec52394b8a77bed6259fb12511c4cc30608e52dc7c4159eaf5c.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7ab0fba_4ab2_48d2_a6cf_80077555d0d7.slice/cri-containerd-b405f99b4096d4bb247581b9dcec251442e2da29040d1eff76882ac7b5c99fed.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7ab0fba_4ab2_48d2_a6cf_80077555d0d7.slice/cri-containerd-835e82427fb5c443349578d3f8879794ccc0c52d8bf33bf2561252a2183b125e.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9adc4599_4c82_4a0b_8e86_aa7d160f40d7.slice/cri-containerd-079570367255b735bae276012f2e761f8466951d8ecaf72ecdfccd4a5e27abce.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9adc4599_4c82_4a0b_8e86_aa7d160f40d7.slice/cri-containerd-b3df041ed80a4d552b55a1c8a035768002c31abbc6fc766fbb8b2510ffb04476.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod428d0066_34cb_41c9_8e46_07aad5fea538.slice/cri-containerd-e6a35f3731cf7994c906453feaf6a01eaac4b1f963d5d4ab972f6399125498d5.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod428d0066_34cb_41c9_8e46_07aad5fea538.slice/cri-containerd-77c669161982894a85a8c40e54de6ff719b54dc0546b9a7174a2ce23126874e9.scope
    97       cgroup_device   multi                                          
