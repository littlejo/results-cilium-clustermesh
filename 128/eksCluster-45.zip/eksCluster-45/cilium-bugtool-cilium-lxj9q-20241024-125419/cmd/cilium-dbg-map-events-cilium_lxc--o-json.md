{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.442Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.452Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.479Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.724Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.760Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.814Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.849Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.880Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.450Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.515Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.580Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.594Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.615Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.829Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.860Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.907Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.914Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.959Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.594Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.604Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.634Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.649Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.686Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.697Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.723Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.953Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.959Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.019Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.024Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.075Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.645Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.670Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.689Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.721Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.739Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.764Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.780Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.079Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.135Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.189Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.197Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.229Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.556Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.595Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.604Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.644Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.662Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.685Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.955Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.975Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.014Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.027Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.067Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.458Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.495Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.499Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.546Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.549Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.583Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.856Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.861Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.914Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.921Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.953Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.402Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.429Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.445Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.483Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.493Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.531Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.537Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.814Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.827Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.863Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.908Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.930Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.301Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.340Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.345Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.400Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.408Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.437Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.702Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.705Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.757Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.766Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.807Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.245Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.254Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.294Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.310Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.353Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.361Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.609Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.634Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.670Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.688Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.718Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.080Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.117Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.118Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.158Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.173Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.203Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.443Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.451Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.506Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.517Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.548Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.906Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.937Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.986Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.019Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.025Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.245Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.275Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.298Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.300Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.305Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.054Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.054Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.106Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.122Z",
  "value": "id=3779  sec_id=3043607 flags=0x0000 ifindex=24  mac=DA:FE:B4:84:B7:41 nodemac=3E:5F:C0:26:C8:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.147Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.417Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.417Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.068Z",
  "value": "id=502   sec_id=3014925 flags=0x0000 ifindex=22  mac=9E:36:DA:F2:66:CB nodemac=F2:B3:7B:E2:66:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.075Z",
  "value": "id=153   sec_id=3039129 flags=0x0000 ifindex=20  mac=AA:E6:1E:18:7C:FB nodemac=16:8D:BE:B0:BE:37"
}

