alloc: 127.55MB (133742528 bytes)
total-alloc: 3.07GB (3299772064 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 74784957
frees: 73504632
heap-alloc: 127.55MB (133742528 bytes)
heap-sys: 176.52MB (185090048 bytes)
heap-idle: 29.78MB (31227904 bytes)
heap-in-use: 146.73MB (153862144 bytes)
heap-released: 10.13MB (10625024 bytes)
heap-objects: 1280325
stack-in-use: 35.44MB (37158912 bytes)
stack-sys: 35.44MB (37158912 bytes)
stack-mspan-inuse: 2.29MB (2405600 bytes)
stack-mspan-sys: 2.74MB (2872320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 775.60KB (794217 bytes)
gc-sys: 5.54MB (5805200 bytes)
next-gc: when heap-alloc >= 150.38MB (157686920 bytes)
last-gc: 2024-10-24 12:54:22.803210838 +0000 UTC
gc-pause-total: 14.975288ms
gc-pause: 97945
gc-pause-end: 1729774462803210838
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0005394426574018718
enable-gc: true
debug-gc: false
