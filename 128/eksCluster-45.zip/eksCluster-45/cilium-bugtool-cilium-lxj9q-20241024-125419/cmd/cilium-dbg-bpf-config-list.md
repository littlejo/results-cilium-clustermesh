KEY             VALUE
AgentLiveness   2004213463659
UTimeOffset     3378461888671875
