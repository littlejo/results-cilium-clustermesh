Endpoint ID: 61
Path: /sys/fs/bpf/tc/globals/cilium_policy_00061

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 153
Path: /sys/fs/bpf/tc/globals/cilium_policy_00153

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 502
Path: /sys/fs/bpf/tc/globals/cilium_policy_00502

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 986
Path: /sys/fs/bpf/tc/globals/cilium_policy_00986

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2928     30        0        
Allow    Ingress     1          ANY          NONE         disabled    156325   1802      0        
Allow    Egress      0          ANY          NONE         disabled    20041    222       0        


Endpoint ID: 1229
Path: /sys/fs/bpf/tc/globals/cilium_policy_01229

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2968     30        0        
Allow    Ingress     1          ANY          NONE         disabled    155788   1789      0        
Allow    Egress      0          ANY          NONE         disabled    20577    230       0        


Endpoint ID: 1435
Path: /sys/fs/bpf/tc/globals/cilium_policy_01435

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6147611   61080     0        
Allow    Ingress     1          ANY          NONE         disabled    5323802   56220     0        
Allow    Egress      0          ANY          NONE         disabled    6078499   60850     0        


Endpoint ID: 1461
Path: /sys/fs/bpf/tc/globals/cilium_policy_01461

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6215826   76953     0        
Allow    Ingress     1          ANY          NONE         disabled    62878     759       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3779
Path: /sys/fs/bpf/tc/globals/cilium_policy_03779

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378545   4420      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


