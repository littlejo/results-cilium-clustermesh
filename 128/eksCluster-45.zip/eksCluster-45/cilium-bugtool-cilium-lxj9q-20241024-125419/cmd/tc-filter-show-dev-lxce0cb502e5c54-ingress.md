filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce0cb502e5c54 direct-action not_in_hw id 635 tag d6e7fa2fa4c5bca1 jited 
