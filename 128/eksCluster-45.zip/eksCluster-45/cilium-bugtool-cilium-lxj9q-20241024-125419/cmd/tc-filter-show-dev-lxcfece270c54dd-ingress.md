filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcfece270c54dd direct-action not_in_hw id 3395 tag ddce6b45009ed351 jited 
