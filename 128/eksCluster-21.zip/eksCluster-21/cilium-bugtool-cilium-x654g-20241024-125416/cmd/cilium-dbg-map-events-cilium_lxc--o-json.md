{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.718Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.761Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.766Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.419Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.446Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.474Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.487Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.518Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.738Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.767Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.809Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.828Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.877Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.493Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.500Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.565Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.565Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.571Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.821Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.839Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.896Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.925Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.971Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.571Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.572Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.663Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.675Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.703Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.893Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.931Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.991Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.021Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.070Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.669Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.670Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.726Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.749Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.790Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.790Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.825Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.063Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.100Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.113Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.172Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.192Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.619Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.623Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.699Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.703Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.776Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.974Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.004Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.041Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.067Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.100Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.505Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.551Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.573Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.617Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.629Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.851Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.868Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.949Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.974Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.004Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.386Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.423Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.461Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.482Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.520Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.522Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.822Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.831Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.937Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.941Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.973Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.256Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.293Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.306Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.351Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.358Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.392Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.654Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.658Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.697Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.725Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.750Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.122Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.146Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.193Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.205Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.234Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.545Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.567Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.602Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.653Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.677Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.028Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.122Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.166Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.192Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.193Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.205Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.362Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.398Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.458Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.489Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.504Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.769Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.830Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.859Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.912Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.961Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.967Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.243Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.267Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.275Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.285Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.287Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.041Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.041Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.100Z",
  "value": "id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.132Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.183Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.458Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.461Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:45.122Z",
  "value": "id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:45.141Z",
  "value": "id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23"
}

