[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfead1cea_1477_41c4_8b79_314b5bd3892d.slice/cri-containerd-e6335392593c5988bb2103ed59ec21b423e472f16ba786d62bb2bd602b439005.scope"
      }
    ],
    "ips": [
      "10.21.0.99"
    ],
    "name": "coredns-cc6ccd49c-wqtft",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26790b1a_e318_4f8a_ae7c_51b792526cc0.slice/cri-containerd-14f5f306350dd93d7fa59c91b40e83ff4a79c0a51c213e66724bdad8fdbbbff5.scope"
      }
    ],
    "ips": [
      "10.21.0.244"
    ],
    "name": "client2-57cf4468f-5z6fg",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4df4e154_b78f_4887_aac7_5299a5fef13c.slice/cri-containerd-8e72a6421d10b6cd2182517a5a4fd310a29268547c6a246b992b60799a7d28d2.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4df4e154_b78f_4887_aac7_5299a5fef13c.slice/cri-containerd-dbf21cf71c21fa69a26e5581bdcf110a5651ee3ccb8902511e2af5948b721fe2.scope"
      }
    ],
    "ips": [
      "10.21.0.154"
    ],
    "name": "echo-same-node-86d9cc975c-7zrzk",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a6f4c58_8e4a_4a44_b395_bf741386022d.slice/cri-containerd-c4f7e82fe58e8903e50fcb24b10c8559e82e384f58291bf4d21788b0bb415b8e.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a6f4c58_8e4a_4a44_b395_bf741386022d.slice/cri-containerd-7a6d8a00e12f21d5df8d086ee49ed330488f2d15f4da8ba30c8ad663b429820b.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a6f4c58_8e4a_4a44_b395_bf741386022d.slice/cri-containerd-3e7bc3d01ae25e0d31f5ad55a40fe79f6de2a705c43e22dd1f9677aead382db4.scope"
      }
    ],
    "ips": [
      "10.21.0.10"
    ],
    "name": "clustermesh-apiserver-57bbd4cd68-jqmgs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded7f9939_9a57_49a5_9e36_217274fbd7ef.slice/cri-containerd-da794960c428264e6fa07851dfb4603dc689e092b4c180e49f4b449bb28f1693.scope"
      }
    ],
    "ips": [
      "10.21.0.40"
    ],
    "name": "coredns-cc6ccd49c-5zxfr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc6b2181_3abb_43d8_862c_2b66dfeb2feb.slice/cri-containerd-078a21fd448e553c71e6de8a7e9ae6a3aba5c4529bca50ef0391d240efabde00.scope"
      }
    ],
    "ips": [
      "10.21.0.1"
    ],
    "name": "client-974f6c69d-9nhrr",
    "namespace": "cilium-test-1"
  }
]

