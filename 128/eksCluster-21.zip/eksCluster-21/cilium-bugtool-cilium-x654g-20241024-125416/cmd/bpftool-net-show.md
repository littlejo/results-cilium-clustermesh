xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 559
ens6(5) clsact/ingress cil_from_netdev-ens6 id 561
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 543
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 539
cilium_host(7) clsact/egress cil_from_host-cilium_host id 537
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 572
lxc9c1d790eb1fc(12) clsact/ingress cil_from_container-lxc9c1d790eb1fc id 523
lxc7af86ba0f692(14) clsact/ingress cil_from_container-lxc7af86ba0f692 id 546
lxc61f1fa60620f(18) clsact/ingress cil_from_container-lxc61f1fa60620f id 641
lxcb288e183f0aa(20) clsact/ingress cil_from_container-lxcb288e183f0aa id 3337
lxc7d6cf8a8e5e4(22) clsact/ingress cil_from_container-lxc7d6cf8a8e5e4 id 3280
lxc31d00e443b3d(24) clsact/ingress cil_from_container-lxc31d00e443b3d id 3328

flow_dissector:

netfilter:

