top - 12:54:17 up 33 min,  0 users,  load average: 0.64, 0.85, 0.46
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 26.7 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi, 16.7 si,  0.0 st
MiB Mem :   3836.2 total,    269.0 free,   1068.9 used,   2498.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2586.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3140 root      20   0 1244596  22876  14528 S  53.3   0.6   0:00.08 hubble
      1 root      20   0 1539060 298076  80312 S  13.3   7.6   1:21.24 cilium-+
    394 root      20   0 1229744  10056   3904 S   0.0   0.3   0:04.72 cilium-+
   3054 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3094 root      20   0 1240432  16352  11164 S   0.0   0.4   0:00.02 cilium-+
   3124 root      20   0    2208    772    696 S   0.0   0.0   0:00.00 timeout
   3146 root      20   0    6576   2432   2104 R   0.0   0.1   0:00.00 top
   3161 root      20   0    3852   1288   1136 R   0.0   0.0   0:00.00 bash
