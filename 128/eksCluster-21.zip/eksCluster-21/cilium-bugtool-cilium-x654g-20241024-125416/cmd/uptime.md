 12:54:17 up 33 min,  0 users,  load average: 0.64, 0.85, 0.46
