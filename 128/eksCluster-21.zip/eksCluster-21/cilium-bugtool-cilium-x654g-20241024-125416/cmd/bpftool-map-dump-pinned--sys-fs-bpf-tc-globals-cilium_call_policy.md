key: 46 00 00 00  value: 0a 02 00 00
key: 08 04 00 00  value: 2c 02 00 00
key: 4f 07 00 00  value: d6 0c 00 00
key: 20 08 00 00  value: 0d 0d 00 00
key: 60 09 00 00  value: 85 02 00 00
key: 2d 0d 00 00  value: 04 0d 00 00
key: c6 0e 00 00  value: 40 02 00 00
Found 7 elements
