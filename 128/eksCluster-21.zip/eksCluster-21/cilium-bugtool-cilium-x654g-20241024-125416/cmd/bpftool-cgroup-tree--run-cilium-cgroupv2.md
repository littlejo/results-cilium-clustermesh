CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded7f9939_9a57_49a5_9e36_217274fbd7ef.slice/cri-containerd-da794960c428264e6fa07851dfb4603dc689e092b4c180e49f4b449bb28f1693.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded7f9939_9a57_49a5_9e36_217274fbd7ef.slice/cri-containerd-faa834a28dff15b73ecf67946c9069d8009ef16d9882595c19e27193898aa045.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6e31b9aa_4aac_4c0d_bd49_f0ae6e6e1966.slice/cri-containerd-cc2019d60758ff0b352876cd1b889c9d2bb2d947c529b063adf5ad423c55926c.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6e31b9aa_4aac_4c0d_bd49_f0ae6e6e1966.slice/cri-containerd-b03df8c633da83fb7701d44226eb896f170d2b2104a92a40c78154fd7c791dbe.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfead1cea_1477_41c4_8b79_314b5bd3892d.slice/cri-containerd-e6335392593c5988bb2103ed59ec21b423e472f16ba786d62bb2bd602b439005.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfead1cea_1477_41c4_8b79_314b5bd3892d.slice/cri-containerd-d08bbcc68fcf13a7187a2f68ccc4081f3c9442821c5f8d2bbab259be33bb2a5d.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6b13c402_f5f0_4d08_8b06_788b34b226e0.slice/cri-containerd-e6506728ec3d1201ce2d37d70db7b78a232d8c0752625c52b94a32ccbe7a8140.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6b13c402_f5f0_4d08_8b06_788b34b226e0.slice/cri-containerd-d004a1fdf0575b541b9ca90be7a0cd5bc9210e780b0ceae35edcaae7aa54e3c7.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod327608e2_6416_4146_bc1c_82d613a0013f.slice/cri-containerd-918d222557f1a6e3da2063e54931787041d8541bc2ebd6d9c951a24d0ce95b3f.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod327608e2_6416_4146_bc1c_82d613a0013f.slice/cri-containerd-ca80d23fc010343d2e23193636504021354b854a25cf8a928fbaa911e2f54e13.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc6b2181_3abb_43d8_862c_2b66dfeb2feb.slice/cri-containerd-078a21fd448e553c71e6de8a7e9ae6a3aba5c4529bca50ef0391d240efabde00.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc6b2181_3abb_43d8_862c_2b66dfeb2feb.slice/cri-containerd-ea5517c68b5ffbbff3169015db8042b75906e34654b946db6cf07376e025e469.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26790b1a_e318_4f8a_ae7c_51b792526cc0.slice/cri-containerd-14f5f306350dd93d7fa59c91b40e83ff4a79c0a51c213e66724bdad8fdbbbff5.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26790b1a_e318_4f8a_ae7c_51b792526cc0.slice/cri-containerd-f91e9dc6fedbdc959da1f1d6271b864ac68e0f0ac604035a11e223c806740dee.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda8cc25d6_1d6a_4b8d_95c8_21146ca9ce9a.slice/cri-containerd-045c7bb737183734fa165946d281e2a3b7724715685867812054671a34226977.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda8cc25d6_1d6a_4b8d_95c8_21146ca9ce9a.slice/cri-containerd-f3c812dea0ad1cfba98ec8bb188e952899dd7153f085659005c8c8764e16b4e5.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a6f4c58_8e4a_4a44_b395_bf741386022d.slice/cri-containerd-7a6d8a00e12f21d5df8d086ee49ed330488f2d15f4da8ba30c8ad663b429820b.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a6f4c58_8e4a_4a44_b395_bf741386022d.slice/cri-containerd-3e7bc3d01ae25e0d31f5ad55a40fe79f6de2a705c43e22dd1f9677aead382db4.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a6f4c58_8e4a_4a44_b395_bf741386022d.slice/cri-containerd-c4f7e82fe58e8903e50fcb24b10c8559e82e384f58291bf4d21788b0bb415b8e.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a6f4c58_8e4a_4a44_b395_bf741386022d.slice/cri-containerd-fef9c58ed19c3bf69de824501a719271c6ace19fc21f38376dd8cc9f527f442f.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4df4e154_b78f_4887_aac7_5299a5fef13c.slice/cri-containerd-3b966a675ec8640af8827bbc4fcb3606f82a2c6e4fdf04f9ce2cfcc15b61994d.scope
    701      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4df4e154_b78f_4887_aac7_5299a5fef13c.slice/cri-containerd-dbf21cf71c21fa69a26e5581bdcf110a5651ee3ccb8902511e2af5948b721fe2.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4df4e154_b78f_4887_aac7_5299a5fef13c.slice/cri-containerd-8e72a6421d10b6cd2182517a5a4fd310a29268547c6a246b992b60799a7d28d2.scope
    736      cgroup_device   multi                                          
