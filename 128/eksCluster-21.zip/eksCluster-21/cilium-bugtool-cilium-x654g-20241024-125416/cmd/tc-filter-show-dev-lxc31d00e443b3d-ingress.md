filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc31d00e443b3d direct-action not_in_hw id 3328 tag b57aa574161b67ac jited 
