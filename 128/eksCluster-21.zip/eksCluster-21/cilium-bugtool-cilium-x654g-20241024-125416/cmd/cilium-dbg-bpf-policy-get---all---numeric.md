Endpoint ID: 70
Path: /sys/fs/bpf/tc/globals/cilium_policy_00070

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2816     30        0        
Allow    Ingress     1          ANY          NONE         disabled    163671   1878      0        
Allow    Egress      0          ANY          NONE         disabled    19361    215       0        


Endpoint ID: 259
Path: /sys/fs/bpf/tc/globals/cilium_policy_00259

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1032
Path: /sys/fs/bpf/tc/globals/cilium_policy_01032

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3080     30        0        
Allow    Ingress     1          ANY          NONE         disabled    165717   1909      0        
Allow    Egress      0          ANY          NONE         disabled    22388    252       0        


Endpoint ID: 1871
Path: /sys/fs/bpf/tc/globals/cilium_policy_01871

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    380203   4437      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2080
Path: /sys/fs/bpf/tc/globals/cilium_policy_02080

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2400
Path: /sys/fs/bpf/tc/globals/cilium_policy_02400

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6124298   61166     0        
Allow    Ingress     1          ANY          NONE         disabled    5365947   56664     0        
Allow    Egress      0          ANY          NONE         disabled    6430590   63946     0        


Endpoint ID: 3373
Path: /sys/fs/bpf/tc/globals/cilium_policy_03373

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3782
Path: /sys/fs/bpf/tc/globals/cilium_policy_03782

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6214156   76761     0        
Allow    Ingress     1          ANY          NONE         disabled    62056     749       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


