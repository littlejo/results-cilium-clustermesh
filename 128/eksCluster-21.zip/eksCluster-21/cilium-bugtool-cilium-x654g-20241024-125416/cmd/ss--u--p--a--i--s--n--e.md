Total: 554
TCP:   4159 (estab 291, closed 3849, orphaned 0, timewait 3394)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  310       300       10       
INET	  320       306       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:29412 sk:1 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15439 sk:2 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:45617      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:27961 sk:3 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.194.30%ens5:68         0.0.0.0:*    uid:192 ino:88170 sk:4 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                                 [::]:8472          [::]:*    ino:29411 sk:343 cgroup:/ v6only:1 <->                                       
UNCONN 0      0                                [::1]:323           [::]:*    ino:15440 sk:344 cgroup:unreachable:e8e v6only:1 <->                         
UNCONN 0      0      [fe80::852:d1ff:fe36:cb11]%ens5:546           [::]:*    uid:192 ino:16424 sk:345 cgroup:unreachable:bd0 v6only:1 <->                 
