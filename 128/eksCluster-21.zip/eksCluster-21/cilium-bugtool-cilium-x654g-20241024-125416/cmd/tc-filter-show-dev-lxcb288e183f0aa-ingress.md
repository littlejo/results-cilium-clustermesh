filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb288e183f0aa direct-action not_in_hw id 3337 tag aaa6f15465e3c1a9 jited 
