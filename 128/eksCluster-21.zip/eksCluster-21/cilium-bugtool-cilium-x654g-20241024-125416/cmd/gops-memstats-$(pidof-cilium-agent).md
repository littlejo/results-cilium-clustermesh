alloc: 102.76MB (107754568 bytes)
total-alloc: 3.05GB (3279030432 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 74407280
frees: 73436944
heap-alloc: 102.76MB (107754568 bytes)
heap-sys: 176.60MB (185180160 bytes)
heap-idle: 47.52MB (49831936 bytes)
heap-in-use: 129.08MB (135348224 bytes)
heap-released: 5.88MB (6168576 bytes)
heap-objects: 970336
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.03MB (2127040 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 965.91KB (989089 bytes)
gc-sys: 5.49MB (5760072 bytes)
next-gc: when heap-alloc >= 149.59MB (156855688 bytes)
last-gc: 2024-10-24 12:54:24.72207683 +0000 UTC
gc-pause-total: 27.588852ms
gc-pause: 77692
gc-pause-end: 1729774464722076830
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0006037533197979425
enable-gc: true
debug-gc: false
