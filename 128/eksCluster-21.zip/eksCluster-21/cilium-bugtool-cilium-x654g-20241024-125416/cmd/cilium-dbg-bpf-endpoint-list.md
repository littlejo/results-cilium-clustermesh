IP ADDRESS        LOCAL ENDPOINT INFO
10.21.0.99:0      id=1032  sec_id=1455196 flags=0x0000 ifindex=14  mac=6E:4C:AD:89:77:6B nodemac=1A:C6:24:3F:1E:58   
10.21.0.40:0      id=70    sec_id=1455196 flags=0x0000 ifindex=12  mac=F2:44:59:22:6D:61 nodemac=16:B5:26:B2:C7:1B   
172.31.194.30:0   (localhost)                                                                                        
10.21.0.154:0     id=1871  sec_id=1471490 flags=0x0000 ifindex=22  mac=AE:9F:16:C8:48:29 nodemac=6A:9F:18:91:6A:7A   
10.21.0.241:0     (localhost)                                                                                        
10.21.0.10:0      id=2400  sec_id=1455559 flags=0x0000 ifindex=18  mac=02:32:D4:61:3E:69 nodemac=E2:32:71:99:0D:0A   
172.31.237.47:0   (localhost)                                                                                        
10.21.0.1:0       id=3373  sec_id=1452138 flags=0x0000 ifindex=20  mac=DA:AC:8C:06:92:ED nodemac=02:02:2A:6A:9A:1F   
10.21.0.244:0     id=2080  sec_id=1483778 flags=0x0000 ifindex=24  mac=36:FE:58:3A:63:C6 nodemac=0A:4B:FC:B1:85:23   
10.21.0.146:0     id=3782  sec_id=4     flags=0x0000 ifindex=10  mac=F6:1E:F6:A4:DD:2A nodemac=06:97:6D:49:AC:48     
