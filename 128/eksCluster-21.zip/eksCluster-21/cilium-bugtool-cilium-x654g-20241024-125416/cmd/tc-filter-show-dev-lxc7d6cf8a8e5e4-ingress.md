filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7d6cf8a8e5e4 direct-action not_in_hw id 3280 tag 98ed69e53a5db40d jited 
