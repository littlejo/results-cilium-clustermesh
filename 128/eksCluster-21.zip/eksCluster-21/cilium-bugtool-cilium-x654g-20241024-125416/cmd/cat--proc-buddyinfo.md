Node 0, zone      DMA     57     76     35     51     18      6      5      3      2      3     40 
Node 0, zone   Normal    220     36      5      3      4      4      1      5      5      2      7 
