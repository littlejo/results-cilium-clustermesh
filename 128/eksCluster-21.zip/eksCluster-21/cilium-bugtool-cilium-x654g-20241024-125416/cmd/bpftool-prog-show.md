29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:05+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:05+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:06+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:06+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:06+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:11+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name tail_handle_ipv4  tag 71a2ff02c3b0e08b  gpl
	loaded_at 2024-10-24T12:25:57+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
479: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:25:57+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
480: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:25:57+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:25:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
511: sched_cls  name tail_ipv4_ct_egress  tag e9c00bd36fe99bb4  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 163
515: sched_cls  name tail_handle_ipv4  tag 4dab59878ccde129  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 165
517: sched_cls  name tail_ipv4_ct_ingress  tag 182607b7a0e64740  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 169
518: sched_cls  name tail_handle_arp  tag cdb1791654b8f5b5  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 171
522: sched_cls  name handle_policy  tag 7a526d17743224f0  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 172
523: sched_cls  name cil_from_container  tag dbab0c909b0c4e9d  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 175
525: sched_cls  name __send_drop_notify  tag 8e5dfe4b3dfc428e  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
526: sched_cls  name tail_handle_ipv4_cont  tag a460006021d19425  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 179
527: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 180
530: sched_cls  name tail_ipv4_to_endpoint  tag 3a0654bfcc46d95a  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 181
532: sched_cls  name __send_drop_notify  tag b12174837fef07ee  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 185
533: sched_cls  name tail_ipv4_ct_ingress  tag aa97f74e2fd3f762  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 186
534: sched_cls  name tail_ipv4_ct_egress  tag e9c00bd36fe99bb4  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 187
535: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 189
537: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 192
539: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 194
540: sched_cls  name tail_handle_ipv4  tag 703050b49499b1dd  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 190
541: sched_cls  name tail_handle_ipv4_from_host  tag 9e95e8caad764b24  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 195
542: sched_cls  name __send_drop_notify  tag 39f5ff9e5557d625  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 196
543: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
544: sched_cls  name tail_handle_ipv4_from_host  tag 9e95e8caad764b24  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 200
545: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 199
546: sched_cls  name cil_from_container  tag 352cf1fd5256a3f2  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 201
547: sched_cls  name __send_drop_notify  tag 39f5ff9e5557d625  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
548: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 203
549: sched_cls  name tail_handle_arp  tag d0d5f70795230eb6  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 204
555: sched_cls  name tail_handle_ipv4_from_host  tag 9e95e8caad764b24  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 212
556: sched_cls  name handle_policy  tag 1e83dc9edba154a5  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 206
557: sched_cls  name __send_drop_notify  tag 39f5ff9e5557d625  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
558: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 214
559: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 215
561: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 218
565: sched_cls  name tail_handle_ipv4_from_host  tag 9e95e8caad764b24  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 222
566: sched_cls  name __send_drop_notify  tag 39f5ff9e5557d625  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 224
568: sched_cls  name tail_handle_ipv4_cont  tag 1048bcffdebe6a52  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 226
569: sched_cls  name tail_handle_ipv4_cont  tag 9e267ceafff90cfb  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 228
570: sched_cls  name tail_ipv4_to_endpoint  tag fe8350c95eca2931  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 229
571: sched_cls  name tail_ipv4_to_endpoint  tag a301575b7e1be244  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 227
572: sched_cls  name cil_from_container  tag 9be587f4cbc8881f  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 230
573: sched_cls  name __send_drop_notify  tag a4b07aa81c388c35  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 231
574: sched_cls  name tail_ipv4_ct_ingress  tag 27fb46a8174ef387  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 232
576: sched_cls  name handle_policy  tag e087836cc65bf655  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 233
577: sched_cls  name tail_handle_arp  tag f3e9ffa3cd87a2b0  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 235
578: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 236
579: sched_cls  name tail_handle_ipv4  tag 3a6fe7e85a9727fd  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 237
581: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 239
582: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
585: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
589: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
594: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
597: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: sched_cls  name tail_handle_ipv4_cont  tag 406d2afd396c34a9  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 253
638: sched_cls  name tail_ipv4_to_endpoint  tag d9efab059a722ef4  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 254
639: sched_cls  name tail_ipv4_ct_ingress  tag d0dd9c51291765e7  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 255
640: sched_cls  name __send_drop_notify  tag a29a91ed3addc768  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 256
641: sched_cls  name cil_from_container  tag 43bdda2dd1f124ff  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 257
642: sched_cls  name tail_handle_arp  tag a12219869d4f9d86  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 258
643: sched_cls  name tail_ipv4_ct_egress  tag 994cd95180b76699  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 259
644: sched_cls  name tail_handle_ipv4  tag 0fa165350d822576  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 260
645: sched_cls  name handle_policy  tag 29857e967810a967  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 261
647: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 263
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
698: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
701: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
717: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
720: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
721: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
724: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
725: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
728: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
729: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
732: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
733: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
736: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3267: sched_cls  name tail_handle_ipv4_cont  tag 7dd30854257b0f1d  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,627,41,154,82,83,39,76,74,77,628,40,37,38,81
	btf_id 3061
3273: sched_cls  name tail_ipv4_ct_egress  tag bb6f2145eee85cb1  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3062
3275: sched_cls  name tail_ipv4_ct_ingress  tag a0a650daae634ce1  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3070
3277: sched_cls  name tail_handle_ipv4  tag 0cabd9eb92d414c3  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,628
	btf_id 3072
3278: sched_cls  name __send_drop_notify  tag f19f5683b74f2787  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3074
3279: sched_cls  name tail_ipv4_to_endpoint  tag 4bc0c568bafef98c  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,627,41,82,83,80,154,39,628,40,37,38
	btf_id 3075
3280: sched_cls  name cil_from_container  tag 98ed69e53a5db40d  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 628,76
	btf_id 3076
3281: sched_cls  name tail_handle_arp  tag 011e481dc3cafb29  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,628
	btf_id 3077
3283: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,628
	btf_id 3079
3286: sched_cls  name handle_policy  tag 48c805bc3c6e73a2  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,628,82,83,627,41,80,154,39,84,75,40,37,38
	btf_id 3080
3322: sched_cls  name tail_handle_arp  tag bc421e65d0080c05  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3121
3323: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3124
3324: sched_cls  name tail_ipv4_ct_ingress  tag 6acface10365855b  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3122
3325: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3126
3326: sched_cls  name __send_drop_notify  tag be25c5af95593b4d  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3127
3327: sched_cls  name tail_ipv4_ct_egress  tag 2ad9906aba4a458d  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3125
3328: sched_cls  name cil_from_container  tag b57aa574161b67ac  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3129
3329: sched_cls  name tail_handle_ipv4  tag 4fb4e8d3b406a8d4  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3128
3331: sched_cls  name tail_ipv4_ct_ingress  tag d6893c5483f4c695  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3130
3332: sched_cls  name handle_policy  tag e947e60a172d5697  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,151,39,84,75,40,37,38
	btf_id 3132
3333: sched_cls  name tail_ipv4_to_endpoint  tag 00c175024ebd1d21  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,159,39,639,40,37,38
	btf_id 3133
3334: sched_cls  name tail_handle_ipv4_cont  tag f4acb31f3d353109  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,151,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3134
3335: sched_cls  name tail_ipv4_ct_egress  tag be05c976c136ed8c  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3136
3336: sched_cls  name __send_drop_notify  tag 849f87d927ad9184  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3135
3337: sched_cls  name cil_from_container  tag aaa6f15465e3c1a9  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3137
3338: sched_cls  name tail_handle_arp  tag e9af3f7b7e0f7612  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3139
3339: sched_cls  name tail_handle_ipv4_cont  tag 7e10202448b309f8  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,159,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3140
3340: sched_cls  name tail_ipv4_to_endpoint  tag 3b80ffcec4eff1dc  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,151,39,637,40,37,38
	btf_id 3138
3341: sched_cls  name handle_policy  tag 6a39d765177e239d  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,159,39,84,75,40,37,38
	btf_id 3141
3342: sched_cls  name tail_handle_ipv4  tag 7f38d0ec27775e46  gpl
	loaded_at 2024-10-24T12:51:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3142
