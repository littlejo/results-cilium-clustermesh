markdown output at /tmp/cilium-bugtool-20241024-125417.631+0000-UTC-1648751291/cmd/cilium-debuginfo-20241024-125448.213+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.631+0000-UTC-1648751291/cmd/cilium-debuginfo-20241024-125448.213+0000-UTC.json
