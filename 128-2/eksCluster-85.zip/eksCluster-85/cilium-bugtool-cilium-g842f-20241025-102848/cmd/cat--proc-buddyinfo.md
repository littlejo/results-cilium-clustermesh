Node 0, zone      DMA      1      2      2      1     17     28     23     15      5      8    160 
Node 0, zone   Normal    403    179     18      3      9      3      3      6      2      2      7 
