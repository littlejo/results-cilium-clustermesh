markdown output at /tmp/cilium-bugtool-20241025-102850.482+0000-UTC-1057103159/cmd/cilium-debuginfo-20241025-102920.966+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102850.482+0000-UTC-1057103159/cmd/cilium-debuginfo-20241025-102920.966+0000-UTC.json
