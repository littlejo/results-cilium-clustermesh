key: d6 01 00 00  value: 72 02 00 00
key: 3d 05 00 00  value: 12 02 00 00
key: 9c 0d 00 00  value: 14 02 00 00
key: 1c 0f 00 00  value: 06 02 00 00
Found 4 elements
