# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.85.0.0/24, 
Allocated addresses:
  10.85.0.105 (kube-system/coredns-cc6ccd49c-x4krt)
  10.85.0.106 (kube-system/clustermesh-apiserver-6cbfd85b78-p6d8g)
  10.85.0.154 (router)
  10.85.0.194 (kube-system/coredns-cc6ccd49c-bl8bf)
  10.85.0.63 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 780d725847732ae0
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    37s ago        never        0       no error   
  ct-map-pressure                                                     9s ago         never        0       no error   
  daemon-validate-config                                              26s ago        never        0       no error   
  dns-garbage-collector-job                                           42s ago        never        0       no error   
  endpoint-1341-regeneration-recovery                                 never          never        0       no error   
  endpoint-2568-regeneration-recovery                                 never          never        0       no error   
  endpoint-3484-regeneration-recovery                                 never          never        0       no error   
  endpoint-3868-regeneration-recovery                                 never          never        0       no error   
  endpoint-470-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         3m43s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                9s ago         never        0       no error   
  ipcache-inject-labels                                               39s ago        never        0       no error   
  k8s-heartbeat                                                       13s ago        never        0       no error   
  link-cache                                                          9s ago         never        0       no error   
  local-identity-checkpoint                                           13m39s ago     never        0       no error   
  node-neighbor-link-updater                                          9s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m3s ago       never        0       no error   
  remote-etcd-cmesh10                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh100                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh101                                                6m4s ago       never        0       no error   
  remote-etcd-cmesh102                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh103                                                6m4s ago       never        0       no error   
  remote-etcd-cmesh104                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh105                                                6m4s ago       never        0       no error   
  remote-etcd-cmesh106                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh107                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh108                                                6m4s ago       never        0       no error   
  remote-etcd-cmesh109                                                6m4s ago       never        0       no error   
  remote-etcd-cmesh11                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh110                                                6m4s ago       never        0       no error   
  remote-etcd-cmesh111                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh112                                                6m4s ago       never        0       no error   
  remote-etcd-cmesh113                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh114                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh115                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh116                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh117                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh118                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh119                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh12                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh120                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh121                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh122                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh123                                                6m4s ago       never        0       no error   
  remote-etcd-cmesh124                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh125                                                6m4s ago       never        0       no error   
  remote-etcd-cmesh126                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh127                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh128                                                6m3s ago       never        0       no error   
  remote-etcd-cmesh13                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh14                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh15                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh16                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh17                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh18                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh19                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh2                                                  6m3s ago       never        0       no error   
  remote-etcd-cmesh20                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh21                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh22                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh23                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh24                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh25                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh26                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh27                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh28                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh29                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh3                                                  6m3s ago       never        0       no error   
  remote-etcd-cmesh30                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh31                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh32                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh33                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh34                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh35                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh36                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh37                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh38                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh39                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh4                                                  6m4s ago       never        0       no error   
  remote-etcd-cmesh40                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh41                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh42                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh43                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh44                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh45                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh46                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh47                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh48                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh49                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh5                                                  6m3s ago       never        0       no error   
  remote-etcd-cmesh50                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh51                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh52                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh53                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh54                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh55                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh56                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh57                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh58                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh59                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh6                                                  6m3s ago       never        0       no error   
  remote-etcd-cmesh60                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh61                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh62                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh63                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh64                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh65                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh66                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh67                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh68                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh69                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh7                                                  6m3s ago       never        0       no error   
  remote-etcd-cmesh70                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh71                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh72                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh73                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh74                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh75                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh76                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh77                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh78                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh79                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh8                                                  6m4s ago       never        0       no error   
  remote-etcd-cmesh80                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh81                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh82                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh83                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh84                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh85                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh87                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh88                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh89                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh9                                                  6m3s ago       never        0       no error   
  remote-etcd-cmesh90                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh91                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh92                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh93                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh94                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh95                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh96                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh97                                                 6m3s ago       never        0       no error   
  remote-etcd-cmesh98                                                 6m4s ago       never        0       no error   
  remote-etcd-cmesh99                                                 6m4s ago       never        0       no error   
  resolve-identity-1341                                               3m37s ago      never        0       no error   
  resolve-identity-2568                                               3m39s ago      never        0       no error   
  resolve-identity-3484                                               3m38s ago      never        0       no error   
  resolve-identity-3868                                               3m37s ago      never        0       no error   
  resolve-identity-470                                                2m6s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6cbfd85b78-p6d8g   7m6s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-bl8bf                  13m37s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-x4krt                  13m37s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      13m39s ago     never        0       no error   
  sync-policymap-1341                                                 13m34s ago     never        0       no error   
  sync-policymap-2568                                                 13m38s ago     never        0       no error   
  sync-policymap-3484                                                 13m34s ago     never        0       no error   
  sync-policymap-3868                                                 13m34s ago     never        0       no error   
  sync-policymap-470                                                  7m6s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (1341)                                   7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3868)                                   7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (470)                                    6s ago         never        0       no error   
  sync-utime                                                          39s ago        never        0       no error   
  write-cni-file                                                      13m43s ago     never        0       no error   
Proxy Status:            OK, ip 10.85.0.154, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 5636096, max 5701631
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 76.22   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
enable-ip-masq-agent:false
cluster-pool-ipv4-cidr:10.85.0.0/16
identity-gc-interval:15m0s
mesh-auth-enabled:true
hubble-prefer-ipv6:false
proxy-max-requests-per-connection:0
enable-bbr:false
mesh-auth-mutual-connect-timeout:5s
bpf-ct-timeout-service-tcp:2h13m20s
max-controller-interval:0
enable-unreachable-routes:false
use-full-tls-context:false
enable-ipsec-encrypted-overlay:false
bpf-sock-rev-map-max:262144
enable-cilium-endpoint-slice:false
clustermesh-config:/var/lib/cilium/clustermesh/
enable-bandwidth-manager:false
kvstore-periodic-sync:5m0s
bpf-filter-priority:1
prepend-iptables-chains:true
hubble-metrics-server:
disable-iptables-feeder-rules:
l2-announcements-renew-deadline:5s
mesh-auth-rotated-identities-queue-size:1024
bpf-lb-map-max:65536
bpf-lb-sock-terminate-pod-connections:false
enable-host-port:false
kube-proxy-replacement:false
nat-map-stats-entries:32
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-srv6:false
encrypt-interface:
bpf-fragments-map-max:8192
bpf-lb-rev-nat-map-max:0
mesh-auth-mutual-listener-port:0
vlan-bpf-bypass:
enable-metrics:true
clustermesh-enable-endpoint-sync:false
restore:true
state-dir:/var/run/cilium
k8s-client-qps:10
ipv6-native-routing-cidr:
external-envoy-proxy:true
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
pprof-port:6060
wireguard-persistent-keepalive:0s
local-max-addr-scope:252
bgp-config-path:/var/lib/cilium/bgp/config.yaml
kvstore:
enable-masquerade-to-route-source:false
service-no-backend-response:reject
hubble-redact-http-headers-deny:
l2-announcements-retry-period:2s
kvstore-lease-ttl:15m0s
bpf-ct-timeout-regular-any:1m0s
ipsec-key-file:
enable-service-topology:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-auto-protect-node-port-range:true
enable-envoy-config:false
bpf-node-map-max:16384
bpf-lb-service-map-max:0
enable-host-firewall:false
direct-routing-skip-unreachable:false
bpf-ct-timeout-service-tcp-grace:1m0s
enable-k8s-networkpolicy:true
clustermesh-sync-timeout:1m0s
policy-cidr-match-mode:
bpf-map-event-buffers:
dnsproxy-lock-count:131
enable-monitor:true
envoy-log:
dnsproxy-concurrency-processing-grace-period:0s
encrypt-node:false
set-cilium-node-taints:true
ipv6-mcast-device:
kvstore-opt:
trace-payloadlen:128
node-labels:
enable-vtep:false
enable-ingress-controller:false
synchronize-k8s-nodes:true
install-no-conntrack-iptables-rules:false
k8s-heartbeat-timeout:30s
lib-dir:/var/lib/cilium
hubble-socket-path:/var/run/cilium/hubble.sock
k8s-client-connection-keep-alive:30s
tofqdns-enable-dns-compression:true
enable-tcx:true
datapath-mode:veth
enable-svc-source-range-check:true
controller-group-metrics:
endpoint-bpf-prog-watchdog-interval:30s
procfs:/host/proc
hubble-drop-events-interval:2m0s
enable-ipv4-big-tcp:false
tunnel-port:0
api-rate-limit:
vtep-mask:
bpf-lb-sock-hostns-only:false
read-cni-conf:
enable-k8s-terminating-endpoint:true
cni-exclusive:true
enable-custom-calls:false
pprof-address:localhost
label-prefix-file:
dnsproxy-socket-linger-timeout:10
derive-masq-ip-addr-from-device:
bpf-lb-mode:snat
enable-l2-pod-announcements:false
ipv6-range:auto
cluster-pool-ipv4-mask-size:24
certificates-directory:/var/run/cilium/certs
http-retry-timeout:0
proxy-xff-num-trusted-hops-ingress:0
k8s-service-cache-size:128
bpf-ct-timeout-service-any:1m0s
bpf-ct-global-tcp-max:524288
bpf-policy-map-full-reconciliation-interval:15m0s
enable-icmp-rules:true
fixed-identity-mapping:
hubble-listen-address::4244
proxy-connect-timeout:2
policy-queue-size:100
unmanaged-pod-watcher-interval:15
cni-external-routing:false
envoy-config-timeout:2m0s
tofqdns-dns-reject-response-code:refused
enable-high-scale-ipcache:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
srv6-encap-mode:reduced
bpf-lb-rss-ipv6-src-cidr:
enable-l7-proxy:true
node-port-algorithm:random
encryption-strict-mode-cidr:
mtu:0
cmdref:
enable-stale-cilium-endpoint-cleanup:true
tofqdns-proxy-port:0
pprof:false
enable-xt-socket-fallback:true
clustermesh-ip-identities-sync-timeout:1m0s
vtep-mac:
ipsec-key-rotation-duration:5m0s
bpf-lb-acceleration:disabled
keep-config:false
enable-ipsec-xfrm-state-caching:true
tofqdns-endpoint-max-ip-per-hostname:50
agent-health-port:9879
mke-cgroup-mount:
gateway-api-secrets-namespace:
agent-labels:
enable-endpoint-routes:false
enable-l2-announcements:false
cilium-endpoint-gc-interval:5m0s
config-dir:/tmp/cilium/config-map
cni-chaining-target:
k8s-require-ipv4-pod-cidr:false
enable-recorder:false
allow-icmp-frag-needed:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
egress-gateway-policy-map-max:16384
vtep-cidr:
enable-well-known-identities:false
envoy-base-id:0
bpf-lb-service-backend-map-max:0
proxy-xff-num-trusted-hops-egress:0
envoy-secrets-namespace:
http-retry-count:3
bpf-lb-external-clusterip:false
enable-pmtu-discovery:false
enable-host-legacy-routing:false
enable-health-check-loadbalancer-ip:false
prometheus-serve-addr:
local-router-ipv4:
k8s-namespace:kube-system
enable-ipv6:false
enable-health-checking:true
enable-wireguard-userspace-fallback:false
dnsproxy-concurrency-limit:0
ip-masq-agent-config-path:/etc/config/ip-masq-agent
proxy-admin-port:0
http-normalize-path:true
monitor-aggregation-interval:5s
enable-policy:default
enable-local-node-route:true
enable-ipv4:true
envoy-config-retry-interval:15s
conntrack-gc-max-interval:0s
set-cilium-is-up-condition:true
identity-change-grace-period:5s
ipv4-service-loopback-address:169.254.42.1
node-port-bind-protection:true
bpf-root:/sys/fs/bpf
monitor-aggregation-flags:all
enable-sctp:false
hubble-redact-enabled:false
cluster-health-port:4240
auto-direct-node-routes:false
iptables-lock-timeout:5s
mesh-auth-gc-interval:5m0s
endpoint-queue-size:25
hubble-redact-kafka-apikey:false
monitor-queue-size:0
bpf-events-drop-enabled:true
join-cluster:false
ingress-secrets-namespace:
trace-sock:true
hubble-export-file-path:
socket-path:/var/run/cilium/cilium.sock
enable-bpf-tproxy:false
ipv4-service-range:auto
proxy-idle-timeout-seconds:60
local-router-ipv6:
clustermesh-enable-mcs-api:false
crd-wait-timeout:5m0s
bpf-lb-algorithm:random
enable-route-mtu-for-cni-chaining:false
allocator-list-timeout:3m0s
hubble-flowlogs-config-path:
bpf-neigh-global-max:524288
enable-node-selector-labels:false
custom-cni-conf:false
enable-node-port:false
enable-mke:false
enable-nat46x64-gateway:false
enable-ipsec:false
enable-local-redirect-policy:false
dns-policy-unload-on-shutdown:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
log-driver:
hubble-event-buffer-capacity:4095
enable-hubble-recorder-api:true
bpf-lb-rss-ipv4-src-cidr:
preallocate-bpf-maps:false
enable-tracing:false
cluster-id:86
policy-audit-mode:false
ipam-multi-pool-pre-allocation:
agent-liveness-update-interval:1s
enable-gateway-api:false
enable-l2-neigh-discovery:true
remove-cilium-node-taints:true
l2-pod-announcements-interface:
enable-cilium-api-server-access:
tofqdns-min-ttl:0
hubble-export-fieldmask:
encryption-strict-mode-allow-remote-node-identities:false
enable-hubble:true
enable-ipv4-masquerade:true
ipam:cluster-pool
auto-create-cilium-node-resource:true
enable-ipv6-big-tcp:false
bpf-policy-map-max:16384
mesh-auth-spire-admin-socket:
config:
kvstore-max-consecutive-quorum-errors:2
bpf-ct-global-any-max:262144
ipam-default-ip-pool:default
tunnel-protocol:vxlan
disable-envoy-version-check:false
enable-ipv4-egress-gateway:false
hubble-disable-tls:false
hubble-redact-http-userinfo:true
disable-external-ip-mitigation:false
http-request-timeout:3600
proxy-prometheus-port:0
enable-xdp-prefilter:false
fqdn-regex-compile-lru-size:1024
operator-prometheus-serve-addr::9963
enable-cilium-health-api-server-access:
enable-identity-mark:true
nodes-gc-interval:5m0s
hubble-redact-http-urlquery:false
enable-wireguard:false
bpf-map-dynamic-size-ratio:0.0025
arping-refresh-period:30s
use-cilium-internal-ip-for-ipsec:false
node-port-mode:snat
dnsproxy-lock-timeout:500ms
egress-multi-home-ip-rule-compat:false
bgp-announce-lb-ip:false
enable-ipip-termination:false
dnsproxy-insecure-skip-transparent-mode-check:false
egress-gateway-reconciliation-trigger-interval:1s
bpf-lb-dsr-dispatch:opt
enable-bpf-masquerade:false
hubble-recorder-sink-queue-size:1024
cni-log-file:/var/run/cilium/cilium-cni.log
hubble-export-file-max-backups:5
disable-endpoint-crd:false
enable-k8s-endpoint-slice:true
hubble-skip-unknown-cgroup-ids:true
config-sources:config-map:kube-system/cilium-config
operator-api-serve-addr:127.0.0.1:9234
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
dnsproxy-enable-transparent-mode:true
enable-ipv4-fragment-tracking:true
debug-verbose:
enable-active-connection-tracking:false
enable-runtime-device-detection:true
hubble-export-file-compress:false
proxy-portrange-min:10000
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
monitor-aggregation:medium
identity-restore-grace-period:30s
bpf-lb-affinity-map-max:0
cflags:
hubble-export-allowlist:
kvstore-connectivity-timeout:2m0s
k8s-service-proxy-name:
mesh-auth-queue-size:1024
enable-bgp-control-plane:false
hubble-monitor-events:
log-system-load:false
mesh-auth-signal-backoff-duration:1s
devices:
allow-localhost:auto
proxy-max-connection-duration-seconds:0
k8s-sync-timeout:3m0s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
ipv4-pod-subnets:
node-port-range:
max-connected-clusters:255
multicast-enabled:false
log-opt:
tofqdns-proxy-response-max-delay:100ms
annotate-k8s-node:false
policy-accounting:true
k8s-api-server:
hubble-recorder-storage-path:/var/run/cilium/pcaps
endpoint-gc-interval:5m0s
nat-map-stats-interval:30s
bpf-events-policy-verdict-enabled:true
container-ip-local-reserved-ports:auto
hubble-export-denylist:
ipv4-range:auto
exclude-node-label-patterns:
kube-proxy-replacement-healthz-bind-address:
conntrack-gc-interval:0s
bpf-lb-source-range-map-max:0
enable-k8s:true
labels:
iptables-random-fully:false
hubble-event-queue-size:0
exclude-local-address:
ipv4-node:auto
tofqdns-pre-cache:
cluster-name:cmesh86
ipv6-service-range:auto
k8s-client-burst:20
hubble-metrics:
direct-routing-device:
http-idle-timeout:0
enable-encryption-strict-mode:false
bpf-ct-timeout-regular-tcp:2h13m20s
force-device-detection:false
bpf-auth-map-max:524288
route-metric:0
hubble-export-file-max-size-mb:10
enable-ipv6-ndp:false
enable-session-affinity:false
ipv6-pod-subnets:
enable-health-check-nodeport:true
cgroup-root:/run/cilium/cgroupv2
enable-k8s-api-discovery:false
ipv4-native-routing-cidr:
bpf-lb-maglev-map-max:0
dns-max-ips-per-restored-rule:1000
hubble-redact-http-headers-allow:
hubble-drop-events:false
identity-allocation-mode:crd
debug:false
install-iptables-rules:true
bpf-lb-sock:false
k8s-require-ipv6-pod-cidr:false
bpf-lb-dsr-l4-xlate:frontend
routing-mode:tunnel
bypass-ip-availability-upon-restore:false
bpf-nat-global-max:524288
tofqdns-idle-connection-grace-period:0s
k8s-kubeconfig-path:
enable-external-ips:false
envoy-keep-cap-netbindservice:false
proxy-gid:1337
max-internal-timer-delay:0s
ipv6-cluster-alloc-cidr:f00d::/64
tofqdns-max-deferred-connection-deletes:10000
bpf-lb-maglev-table-size:16381
http-max-grpc-timeout:0
enable-endpoint-health-checking:true
nodeport-addresses:
ipam-cilium-node-update-rate:15s
bpf-ct-timeout-regular-tcp-syn:1m0s
version:false
vtep-endpoint:
gops-port:9890
bgp-announce-pod-cidr:false
node-port-acceleration:disabled
enable-ipsec-key-watcher:true
enable-bpf-clock-probe:false
hubble-drop-events-reasons:auth_required,policy_denied
metrics:
proxy-portrange-max:20000
enable-ipv6-masquerade:true
bpf-events-trace-enabled:true
ipv6-node:auto
egress-masquerade-interfaces:ens+
policy-trigger-interval:1s
identity-heartbeat-timeout:30m0s
k8s-client-connection-timeout:30s
bpf-ct-timeout-regular-tcp-fin:10s
static-cnp-path:
cni-chaining-mode:none
l2-announcements-lease-duration:15s
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
470        Disabled           Disabled          5643711    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.85.0.106   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh86                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1341       Disabled           Disabled          5670699    k8s:eks.amazonaws.com/component=coredns                                             10.85.0.194   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh86                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2568       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
3484       Disabled           Disabled          4          reserved:health                                                                     10.85.0.63    ready   
3868       Disabled           Disabled          5670699    k8s:eks.amazonaws.com/component=coredns                                             10.85.0.105   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh86                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 470

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3931815   36864     0        
Allow    Ingress     1          ANY          NONE         disabled    2976145   29970     0        
Allow    Egress      0          ANY          NONE         disabled    4502892   41755     0        

```


#### BPF CT List 470

```
Invalid argument: unknown type 470
```


#### Endpoint Get 470

```
[
  {
    "id": 470,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-470-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2da86543-8756-46ca-8721-15a48f0075ce"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-470",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:14.317Z",
            "success-count": 2
          },
          "uuid": "5cdbcdd8-f1f5-499e-b587-3d8d18aadfc9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6cbfd85b78-p6d8g",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:14.316Z",
            "success-count": 1
          },
          "uuid": "0d5e7ad9-b96d-4306-a7b5-d909a3753ffd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-470",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:14.348Z",
            "success-count": 1
          },
          "uuid": "0d69872f-eea2-4c0c-9684-09fa5b6ff09a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (470)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.385Z",
            "success-count": 44
          },
          "uuid": "b95cff05-5b17-4a88-a52d-3abb86099b4c"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0b4b7c8a799647ef8c2e6041393828b1b6609dea1c05e99b18fc8629b480acea:eth0",
        "container-id": "0b4b7c8a799647ef8c2e6041393828b1b6609dea1c05e99b18fc8629b480acea",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6cbfd85b78-p6d8g",
        "pod-name": "kube-system/clustermesh-apiserver-6cbfd85b78-p6d8g"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5643711,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh86",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6cbfd85b78"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh86",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:18Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.85.0.106",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ea:aa:58:1d:da:20",
        "interface-index": 18,
        "interface-name": "lxcc20faabdd781",
        "mac": "46:b3:f0:21:3e:3f"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5643711,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5643711,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 470

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 470

```
Timestamp              Status   State                   Message
2024-10-25T10:23:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:18Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:14Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:14Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:14Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5643711

```
ID        LABELS
5643711   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh86
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1341

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76656   882       0        
Allow    Egress      0          ANY          NONE         disabled    12643   129       0        

```


#### BPF CT List 1341

```
Invalid argument: unknown type 1341
```


#### Endpoint Get 1341

```
[
  {
    "id": 1341,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1341-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f72336eb-817d-4e21-90e1-bd31b197f880"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1341",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:43.287Z",
            "success-count": 3
          },
          "uuid": "16ee6110-a114-4431-b96b-1a9f4feac8f5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-bl8bf",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:43.286Z",
            "success-count": 1
          },
          "uuid": "9bb24478-1f1b-4810-a537-0d7d54467bfd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1341",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:46.189Z",
            "success-count": 1
          },
          "uuid": "e818efe4-891b-42f6-a6a7-856de0da15d2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1341)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.361Z",
            "success-count": 83
          },
          "uuid": "8443c6fb-9542-4766-a819-c19c1a620a0e"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0062ec3aca9d446d167f8537b969270b0507edc7d58f21596d6ac88f5a953035:eth0",
        "container-id": "0062ec3aca9d446d167f8537b969270b0507edc7d58f21596d6ac88f5a953035",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-bl8bf",
        "pod-name": "kube-system/coredns-cc6ccd49c-bl8bf"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5670699,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh86",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh86",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:18Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.85.0.194",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "8a:e2:e1:5c:90:59",
        "interface-index": 12,
        "interface-name": "lxc55bd9bd99be9",
        "mac": "ae:b5:a9:3c:0a:d0"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5670699,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5670699,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1341

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1341

```
Timestamp              Status    State                   Message
2024-10-25T10:23:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:18Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:23:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:17Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:17Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:17Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:24Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:46Z   OK        ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:15:46Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:46Z   OK        regenerating            Regenerating endpoint: devices changed
2024-10-25T10:15:46Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:44Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:15:43Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:43Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:15:43Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:43Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 5670699

```
ID        LABELS
5670699   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh86
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2568

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2568

```
Invalid argument: unknown type 2568
```


#### Endpoint Get 2568

```
[
  {
    "id": 2568,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2568-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4d4b2995-f31a-4a91-ace4-056a4cd8a5ea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2568",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:41.506Z",
            "success-count": 3
          },
          "uuid": "b55b311a-28b1-4e39-828f-8d2310f8dff8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2568",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:42.829Z",
            "success-count": 1
          },
          "uuid": "5fae2fb6-2338-4939-b4c0-841e415dd565"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:18Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "fe:7d:5b:03:11:a9",
        "interface-name": "cilium_host",
        "mac": "fe:7d:5b:03:11:a9"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2568

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2568

```
Timestamp              Status   State                   Message
2024-10-25T10:23:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:18Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:46Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:41Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:41Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:41Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3484

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    443128   5661      0        
Allow    Ingress     1          ANY          NONE         disabled    10812    125       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3484

```
Invalid argument: unknown type 3484
```


#### Endpoint Get 3484

```
[
  {
    "id": 3484,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3484-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "96528028-513a-47df-aba0-ead232a4a273"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3484",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:42.556Z",
            "success-count": 3
          },
          "uuid": "710db5c6-5ceb-4683-ac42-c38c900d3b59"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3484",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:46.198Z",
            "success-count": 1
          },
          "uuid": "d6ad097a-4549-4326-99a9-0683f9859a87"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:18Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.85.0.63",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "72:f2:1f:16:b3:ce",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "92:8f:b0:b4:e0:de"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3484

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3484

```
Timestamp              Status   State                   Message
2024-10-25T10:23:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:18Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:46Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:42Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:42Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:41Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 3868

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    75930   871       0        
Allow    Egress      0          ANY          NONE         disabled    12776   131       0        

```


#### BPF CT List 3868

```
Invalid argument: unknown type 3868
```


#### Endpoint Get 3868

```
[
  {
    "id": 3868,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3868-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "40f16f8c-8424-4274-ac5a-e18a052f922c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3868",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:43.390Z",
            "success-count": 3
          },
          "uuid": "ee9814ab-d129-4bd9-a2d9-4094d6226888"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-x4krt",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:43.388Z",
            "success-count": 1
          },
          "uuid": "5b8e06a6-3d9f-4c95-ad78-b574c7674b33"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3868",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:46.253Z",
            "success-count": 1
          },
          "uuid": "90ea9da8-0bd2-4518-866f-165291e12f34"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3868)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.453Z",
            "success-count": 83
          },
          "uuid": "33e28766-79e8-4638-a37a-1483ad4808a6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "c5d4ae059c6836b2e5b9a2928e81874f64e370a0109eadc6b7a836fdda12c7bb:eth0",
        "container-id": "c5d4ae059c6836b2e5b9a2928e81874f64e370a0109eadc6b7a836fdda12c7bb",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-x4krt",
        "pod-name": "kube-system/coredns-cc6ccd49c-x4krt"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5670699,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh86",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh86",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:18Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.85.0.105",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ae:69:5e:f6:54:73",
        "interface-index": 14,
        "interface-name": "lxc70f0a38dc636",
        "mac": "ae:ca:5c:51:5a:11"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5670699,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5670699,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3868

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3868

```
Timestamp              Status   State                   Message
2024-10-25T10:23:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:18Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:46Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:43Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5670699

```
ID        LABELS
5670699   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh86
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.134.79:443 (active)    
                                         2 => 172.31.230.120:443 (active)   
2    10.100.154.99:443    ClusterIP      1 => 172.31.228.79:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.85.0.194:53 (active)       
                                         2 => 10.85.0.105:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.85.0.194:9153 (active)     
                                         2 => 10.85.0.105:9153 (active)     
5    10.100.20.105:2379   ClusterIP      1 => 10.85.0.106:2379 (active)     
```

#### Policy get

```
:
 []
Revision: 1

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.85.0.194": (string) (len=35) "kube-system/coredns-cc6ccd49c-bl8bf",
  (string) (len=11) "10.85.0.105": (string) (len=35) "kube-system/coredns-cc6ccd49c-x4krt",
  (string) (len=11) "10.85.0.106": (string) (len=50) "kube-system/clustermesh-apiserver-6cbfd85b78-p6d8g",
  (string) (len=11) "10.85.0.154": (string) (len=6) "router",
  (string) (len=10) "10.85.0.63": (string) (len=6) "health"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.228.79": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x400243d600)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001808420,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001808420,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x400243c0b0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x400243c160)(frontends:[10.100.154.99]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x400243c210)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001c8e9a0)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001a314a0)(frontends:[10.100.20.105]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40008328f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-5flnz": (*k8s.Endpoints)(0x40033d71e0)(10.85.0.105:53/TCP[eu-west-3b],10.85.0.105:53/UDP[eu-west-3b],10.85.0.105:9153/TCP[eu-west-3b],10.85.0.194:53/TCP[eu-west-3b],10.85.0.194:53/UDP[eu-west-3b],10.85.0.194:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40019af088)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-r8jl5": (*k8s.Endpoints)(0x4003400ea0)(10.85.0.106:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40008328e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002bc20d0)(172.31.134.79:443/TCP,172.31.230.120:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40008328f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-b2748": (*k8s.Endpoints)(0x4001648f70)(172.31.228.79:4244/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4000a79ea0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000c4f810)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40078ab3f8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40010ffb00,
  gcExited: (chan struct {}) 0x40010ffc20,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4000d33880)({
     ObserverVec: (*prometheus.HistogramVec)(0x400079c140)({
      MetricVec: (*prometheus.MetricVec)(0x4002258c30)({
       metricMap: (*prometheus.metricMap)(0x4002258c60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b7d740)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4000d33900)({
     ObserverVec: (*prometheus.HistogramVec)(0x400079c158)({
      MetricVec: (*prometheus.MetricVec)(0x4002258cc0)({
       metricMap: (*prometheus.metricMap)(0x4002258cf0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b7d7a0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4000d33980)({
     GaugeVec: (*prometheus.GaugeVec)(0x400079c178)({
      MetricVec: (*prometheus.MetricVec)(0x4002258d50)({
       metricMap: (*prometheus.metricMap)(0x4002258d80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b7d800)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4000d33a00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400079c188)({
      MetricVec: (*prometheus.MetricVec)(0x4002258de0)({
       metricMap: (*prometheus.metricMap)(0x4002258e10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b7d860)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4000d33a80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400079c190)({
      MetricVec: (*prometheus.MetricVec)(0x4002258e70)({
       metricMap: (*prometheus.metricMap)(0x4002258ea0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b7d8c0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4000d33b00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400079c198)({
      MetricVec: (*prometheus.MetricVec)(0x4002258f00)({
       metricMap: (*prometheus.metricMap)(0x4002258f30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b7d920)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4000d33b80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400079c1a0)({
      MetricVec: (*prometheus.MetricVec)(0x4002258f90)({
       metricMap: (*prometheus.metricMap)(0x4002258fc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b7d980)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4000d33c00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400079c1a8)({
      MetricVec: (*prometheus.MetricVec)(0x4002259020)({
       metricMap: (*prometheus.metricMap)(0x4002259050)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b7d9e0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4000d33c80)({
     ObserverVec: (*prometheus.HistogramVec)(0x400079c1b0)({
      MetricVec: (*prometheus.MetricVec)(0x40022590b0)({
       metricMap: (*prometheus.metricMap)(0x40022590e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b7da40)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4000a79ea0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40016d90a0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4000d6f050)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 402ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33636762                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33636762                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33636762                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c000000 rw-p 00000000 00:00 0 
ffff4abec000-ffff4ade1000 rw-p 00000000 00:00 0 
ffff4ade9000-ffff4aeca000 rw-p 00000000 00:00 0 
ffff4aeca000-ffff4af0b000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff4af0b000-ffff4af4c000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff4af4c000-ffff4af8c000 rw-p 00000000 00:00 0 
ffff4af8c000-ffff4af8e000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff4af8e000-ffff4af90000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff4af90000-ffff4b557000 rw-p 00000000 00:00 0 
ffff4b557000-ffff4b657000 rw-p 00000000 00:00 0 
ffff4b657000-ffff4b668000 rw-p 00000000 00:00 0 
ffff4b668000-ffff4d668000 rw-p 00000000 00:00 0 
ffff4d668000-ffff4d6e8000 ---p 00000000 00:00 0 
ffff4d6e8000-ffff4d6e9000 rw-p 00000000 00:00 0 
ffff4d6e9000-ffff6d6e8000 ---p 00000000 00:00 0 
ffff6d6e8000-ffff6d6e9000 rw-p 00000000 00:00 0 
ffff6d6e9000-ffff8d678000 ---p 00000000 00:00 0 
ffff8d678000-ffff8d679000 rw-p 00000000 00:00 0 
ffff8d679000-ffff9166a000 ---p 00000000 00:00 0 
ffff9166a000-ffff9166b000 rw-p 00000000 00:00 0 
ffff9166b000-ffff91e68000 ---p 00000000 00:00 0 
ffff91e68000-ffff91e69000 rw-p 00000000 00:00 0 
ffff91e69000-ffff91f68000 ---p 00000000 00:00 0 
ffff91f68000-ffff91fc8000 rw-p 00000000 00:00 0 
ffff91fc8000-ffff91fca000 r--p 00000000 00:00 0                          [vvar]
ffff91fca000-ffff91fcb000 r-xp 00000000 00:00 0                          [vdso]
fffff1aba000-fffff1adb000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption


