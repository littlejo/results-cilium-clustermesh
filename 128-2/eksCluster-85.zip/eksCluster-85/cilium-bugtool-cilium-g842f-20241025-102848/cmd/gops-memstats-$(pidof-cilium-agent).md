alloc: 90.27MB (94660040 bytes)
total-alloc: 1.33GB (1425862824 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 47733096
frees: 46858270
heap-alloc: 90.27MB (94660040 bytes)
heap-sys: 157.38MB (165027840 bytes)
heap-idle: 39.08MB (40976384 bytes)
heap-in-use: 118.30MB (124051456 bytes)
heap-released: 1.44MB (1507328 bytes)
heap-objects: 874826
stack-in-use: 34.59MB (36274176 bytes)
stack-sys: 34.59MB (36274176 bytes)
stack-mspan-inuse: 1.97MB (2064000 bytes)
stack-mspan-sys: 2.46MB (2578560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 937.14KB (959633 bytes)
gc-sys: 5.05MB (5297248 bytes)
next-gc: when heap-alloc >= 148.25MB (155451544 bytes)
last-gc: 2024-10-25 10:28:55.457447314 +0000 UTC
gc-pause-total: 20.946753ms
gc-pause: 61571
gc-pause-end: 1729852135457447314
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00037166184482080773
enable-gc: true
debug-gc: false
