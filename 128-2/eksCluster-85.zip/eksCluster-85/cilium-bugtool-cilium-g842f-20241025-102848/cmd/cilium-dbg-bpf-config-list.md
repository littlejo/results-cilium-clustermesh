KEY             VALUE
AgentLiveness   904892857682
UTimeOffset     3378615734375000
