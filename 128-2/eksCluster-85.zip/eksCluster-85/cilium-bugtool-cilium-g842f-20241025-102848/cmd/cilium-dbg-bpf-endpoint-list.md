IP ADDRESS         LOCAL ENDPOINT INFO
10.85.0.154:0      (localhost)                                                                                        
172.31.248.108:0   (localhost)                                                                                        
10.85.0.194:0      id=1341  sec_id=5670699 flags=0x0000 ifindex=12  mac=AE:B5:A9:3C:0A:D0 nodemac=8A:E2:E1:5C:90:59   
172.31.228.79:0    (localhost)                                                                                        
10.85.0.63:0       id=3484  sec_id=4     flags=0x0000 ifindex=10  mac=92:8F:B0:B4:E0:DE nodemac=72:F2:1F:16:B3:CE     
10.85.0.105:0      id=3868  sec_id=5670699 flags=0x0000 ifindex=14  mac=AE:CA:5C:51:5A:11 nodemac=AE:69:5E:F6:54:73   
10.85.0.106:0      id=470   sec_id=5643711 flags=0x0000 ifindex=18  mac=46:B3:F0:21:3E:3F nodemac=EA:AA:58:1D:DA:20   
