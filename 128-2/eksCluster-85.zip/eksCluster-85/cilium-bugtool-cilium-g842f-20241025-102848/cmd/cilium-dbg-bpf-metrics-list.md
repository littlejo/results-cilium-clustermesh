REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     219907    84771017   1132   bpf_host.c
Interface                 INGRESS     9700      755978     677    bpf_overlay.c
Success                   EGRESS      4696      357385     1694   bpf_host.c
Success                   EGRESS      91769     12255498   1308   bpf_lxc.c
Success                   EGRESS      9513      742819     53     encap.h
Success                   INGRESS     102104    12548184   86     l3.h
Success                   INGRESS     107757    12990683   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
