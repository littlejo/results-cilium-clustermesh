Endpoint ID: 470
Path: /sys/fs/bpf/tc/globals/cilium_policy_00470

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3945525   37016     0        
Allow    Ingress     1          ANY          NONE         disabled    2976145   29970     0        
Allow    Egress      0          ANY          NONE         disabled    4505722   41786     0        


Endpoint ID: 1341
Path: /sys/fs/bpf/tc/globals/cilium_policy_01341

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76656   882       0        
Allow    Egress      0          ANY          NONE         disabled    12643   129       0        


Endpoint ID: 2568
Path: /sys/fs/bpf/tc/globals/cilium_policy_02568

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3484
Path: /sys/fs/bpf/tc/globals/cilium_policy_03484

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    443260   5663      0        
Allow    Ingress     1          ANY          NONE         disabled    10812    125       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3868
Path: /sys/fs/bpf/tc/globals/cilium_policy_03868

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    75930   871       0        
Allow    Egress      0          ANY          NONE         disabled    12776   131       0        


