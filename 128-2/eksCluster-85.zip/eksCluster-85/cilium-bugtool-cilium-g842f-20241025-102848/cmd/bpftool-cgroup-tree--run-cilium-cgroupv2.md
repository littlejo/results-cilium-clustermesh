CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd835a965_6481_4445_ba44_dd43bddf787d.slice/cri-containerd-885aa5860fecc2e93833435aae71254ff45bc371cab8eca3facf1537dde16198.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd835a965_6481_4445_ba44_dd43bddf787d.slice/cri-containerd-87602071d7dd742417ddd503c1e96ee947069773fb7aadc258e321cfd5cd8ee6.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0fb5bec5_6610_4cc1_b9c1_3b764a0c1d4c.slice/cri-containerd-1fd5e6b520ec53811c4927cbf8622921e9dd380156d4e8828504a96a5017c762.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0fb5bec5_6610_4cc1_b9c1_3b764a0c1d4c.slice/cri-containerd-fafc15c9daa7577bc7522e05d0b2baf835e91234f3b390f943582faae1cd0538.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca531419_d694_4160_8f3a_8397aba37785.slice/cri-containerd-0062ec3aca9d446d167f8537b969270b0507edc7d58f21596d6ac88f5a953035.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca531419_d694_4160_8f3a_8397aba37785.slice/cri-containerd-416d72c08e18114f99a248d9edadf84542a595411fdfe39355b4bd43b11b430c.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podec42bb8a_5e4f_44fb_8b88_7cf491c5293a.slice/cri-containerd-c5d4ae059c6836b2e5b9a2928e81874f64e370a0109eadc6b7a836fdda12c7bb.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podec42bb8a_5e4f_44fb_8b88_7cf491c5293a.slice/cri-containerd-2af8843c948bc3d9b2392fc95e6e96cb277f82fb8e97c223df683aac508d9d13.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeac4a307_ebff_4099_bbe6_775698b5a142.slice/cri-containerd-b3954eb7e3c6b29366491d0cfebc12895199d63f24600d4bcf503c2ee46418f7.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeac4a307_ebff_4099_bbe6_775698b5a142.slice/cri-containerd-61939acd93547052a353a2f8f3c14fdf14edabe51e410e5d6959f1086781f3dc.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbde3904c_5a44_4d6d_b234_d21a7d457845.slice/cri-containerd-9a6cccc34de206d29acc76376635009adc7aa938b308b8de55686207b7a40447.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbde3904c_5a44_4d6d_b234_d21a7d457845.slice/cri-containerd-0b4b7c8a799647ef8c2e6041393828b1b6609dea1c05e99b18fc8629b480acea.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbde3904c_5a44_4d6d_b234_d21a7d457845.slice/cri-containerd-df561d248a643b0d56b4618fb6d3af881b8bd44ffbbe04dcc78a3b628eb583d6.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbde3904c_5a44_4d6d_b234_d21a7d457845.slice/cri-containerd-61e987429d9c467000dec93c6ed420d7e8ad26e3a5e408be15c9eb9721c57214.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6cb4610_a8ef_4300_9af8_ad3d9e175e80.slice/cri-containerd-ff8f03c725e6e720865c0cfc87fd174232f3c8332d539b3698a504e901841dfe.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6cb4610_a8ef_4300_9af8_ad3d9e175e80.slice/cri-containerd-b2ea84d6d7fb4cee8f37e3cf3e0511da6f5a70124e1d98c5da8e98f381b581a0.scope
    109      cgroup_device   multi                                          
