[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca531419_d694_4160_8f3a_8397aba37785.slice/cri-containerd-416d72c08e18114f99a248d9edadf84542a595411fdfe39355b4bd43b11b430c.scope"
      }
    ],
    "ips": [
      "10.85.0.194"
    ],
    "name": "coredns-cc6ccd49c-bl8bf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbde3904c_5a44_4d6d_b234_d21a7d457845.slice/cri-containerd-9a6cccc34de206d29acc76376635009adc7aa938b308b8de55686207b7a40447.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbde3904c_5a44_4d6d_b234_d21a7d457845.slice/cri-containerd-df561d248a643b0d56b4618fb6d3af881b8bd44ffbbe04dcc78a3b628eb583d6.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbde3904c_5a44_4d6d_b234_d21a7d457845.slice/cri-containerd-61e987429d9c467000dec93c6ed420d7e8ad26e3a5e408be15c9eb9721c57214.scope"
      }
    ],
    "ips": [
      "10.85.0.106"
    ],
    "name": "clustermesh-apiserver-6cbfd85b78-p6d8g",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podec42bb8a_5e4f_44fb_8b88_7cf491c5293a.slice/cri-containerd-2af8843c948bc3d9b2392fc95e6e96cb277f82fb8e97c223df683aac508d9d13.scope"
      }
    ],
    "ips": [
      "10.85.0.105"
    ],
    "name": "coredns-cc6ccd49c-x4krt",
    "namespace": "kube-system"
  }
]

