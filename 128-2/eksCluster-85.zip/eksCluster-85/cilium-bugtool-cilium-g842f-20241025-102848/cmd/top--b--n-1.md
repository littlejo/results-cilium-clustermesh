top - 10:28:50 up 14 min,  0 users,  load average: 0.08, 0.14, 0.12
Tasks:   8 total,   3 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.0 us, 53.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,    777.6 free,    916.6 used,   2141.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2750.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    717 root      20   0 1244340  23092  14528 R  60.0   0.6   0:00.15 hubble
      1 root      20   0 1472496 276736  77260 S   6.7   7.0   0:23.30 cilium-+
    693 root      20   0 1240432  16772  11292 S   6.7   0.4   0:00.02 cilium-+
    418 root      20   0 1228848   6952   3900 S   0.0   0.2   0:00.27 cilium-+
    683 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    710 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    739 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    763 root      20   0 1240432  16772  11292 R   0.0   0.4   0:00.00 cilium-+
