ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.134.79:443 (active)    
                                         2 => 172.31.230.120:443 (active)   
2    10.100.154.99:443    ClusterIP      1 => 172.31.228.79:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.85.0.194:53 (active)       
                                         2 => 10.85.0.105:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.85.0.194:9153 (active)     
                                         2 => 10.85.0.105:9153 (active)     
5    10.100.20.105:2379   ClusterIP      1 => 10.85.0.106:2379 (active)     
