{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.327Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.228.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.327Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.248.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.327Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:46.189Z",
  "value": "id=1341  sec_id=5670699 flags=0x0000 ifindex=12  mac=AE:B5:A9:3C:0A:D0 nodemac=8A:E2:E1:5C:90:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:46.197Z",
  "value": "id=3484  sec_id=4     flags=0x0000 ifindex=10  mac=92:8F:B0:B4:E0:DE nodemac=72:F2:1F:16:B3:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:46.250Z",
  "value": "id=3868  sec_id=5670699 flags=0x0000 ifindex=14  mac=AE:CA:5C:51:5A:11 nodemac=AE:69:5E:F6:54:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:46.332Z",
  "value": "id=1341  sec_id=5670699 flags=0x0000 ifindex=12  mac=AE:B5:A9:3C:0A:D0 nodemac=8A:E2:E1:5C:90:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:46.416Z",
  "value": "id=3484  sec_id=4     flags=0x0000 ifindex=10  mac=92:8F:B0:B4:E0:DE nodemac=72:F2:1F:16:B3:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.041Z",
  "value": "id=3484  sec_id=4     flags=0x0000 ifindex=10  mac=92:8F:B0:B4:E0:DE nodemac=72:F2:1F:16:B3:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.041Z",
  "value": "id=1341  sec_id=5670699 flags=0x0000 ifindex=12  mac=AE:B5:A9:3C:0A:D0 nodemac=8A:E2:E1:5C:90:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.042Z",
  "value": "id=3868  sec_id=5670699 flags=0x0000 ifindex=14  mac=AE:CA:5C:51:5A:11 nodemac=AE:69:5E:F6:54:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.072Z",
  "value": "id=2371  sec_id=5643711 flags=0x0000 ifindex=16  mac=02:44:72:E7:55:43 nodemac=1A:F1:97:A0:6D:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:24.041Z",
  "value": "id=2371  sec_id=5643711 flags=0x0000 ifindex=16  mac=02:44:72:E7:55:43 nodemac=1A:F1:97:A0:6D:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:24.041Z",
  "value": "id=3868  sec_id=5670699 flags=0x0000 ifindex=14  mac=AE:CA:5C:51:5A:11 nodemac=AE:69:5E:F6:54:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:24.041Z",
  "value": "id=1341  sec_id=5670699 flags=0x0000 ifindex=12  mac=AE:B5:A9:3C:0A:D0 nodemac=8A:E2:E1:5C:90:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:24.041Z",
  "value": "id=3484  sec_id=4     flags=0x0000 ifindex=10  mac=92:8F:B0:B4:E0:DE nodemac=72:F2:1F:16:B3:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.347Z",
  "value": "id=470   sec_id=5643711 flags=0x0000 ifindex=18  mac=46:B3:F0:21:3E:3F nodemac=EA:AA:58:1D:DA:20"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.85.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.734Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.800Z",
  "value": "id=3484  sec_id=4     flags=0x0000 ifindex=10  mac=92:8F:B0:B4:E0:DE nodemac=72:F2:1F:16:B3:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.801Z",
  "value": "id=1341  sec_id=5670699 flags=0x0000 ifindex=12  mac=AE:B5:A9:3C:0A:D0 nodemac=8A:E2:E1:5C:90:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.801Z",
  "value": "id=470   sec_id=5643711 flags=0x0000 ifindex=18  mac=46:B3:F0:21:3E:3F nodemac=EA:AA:58:1D:DA:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.801Z",
  "value": "id=3868  sec_id=5670699 flags=0x0000 ifindex=14  mac=AE:CA:5C:51:5A:11 nodemac=AE:69:5E:F6:54:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.799Z",
  "value": "id=470   sec_id=5643711 flags=0x0000 ifindex=18  mac=46:B3:F0:21:3E:3F nodemac=EA:AA:58:1D:DA:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.800Z",
  "value": "id=3868  sec_id=5670699 flags=0x0000 ifindex=14  mac=AE:CA:5C:51:5A:11 nodemac=AE:69:5E:F6:54:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.800Z",
  "value": "id=1341  sec_id=5670699 flags=0x0000 ifindex=12  mac=AE:B5:A9:3C:0A:D0 nodemac=8A:E2:E1:5C:90:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.800Z",
  "value": "id=3484  sec_id=4     flags=0x0000 ifindex=10  mac=92:8F:B0:B4:E0:DE nodemac=72:F2:1F:16:B3:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.801Z",
  "value": "id=470   sec_id=5643711 flags=0x0000 ifindex=18  mac=46:B3:F0:21:3E:3F nodemac=EA:AA:58:1D:DA:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.801Z",
  "value": "id=3868  sec_id=5670699 flags=0x0000 ifindex=14  mac=AE:CA:5C:51:5A:11 nodemac=AE:69:5E:F6:54:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.801Z",
  "value": "id=3484  sec_id=4     flags=0x0000 ifindex=10  mac=92:8F:B0:B4:E0:DE nodemac=72:F2:1F:16:B3:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.801Z",
  "value": "id=1341  sec_id=5670699 flags=0x0000 ifindex=12  mac=AE:B5:A9:3C:0A:D0 nodemac=8A:E2:E1:5C:90:59"
}

