REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10049     787571      677    bpf_overlay.c
Interface                 INGRESS     223755    101253837   1132   bpf_host.c
Success                   EGRESS      10265     803329      53     encap.h
Success                   EGRESS      5137      396365      1694   bpf_host.c
Success                   EGRESS      7798      1232711     86     l3.h
Success                   EGRESS      93156     12468116    1308   bpf_lxc.c
Success                   INGRESS     105076    12848336    86     l3.h
Success                   INGRESS     118435    14516159    235    trace.h
Unsupported L3 protocol   EGRESS      38        2832        1492   bpf_lxc.c
