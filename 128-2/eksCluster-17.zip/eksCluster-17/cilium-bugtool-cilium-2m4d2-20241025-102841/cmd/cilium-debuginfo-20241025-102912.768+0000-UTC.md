# Cilium debug information

#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.17.0.0/24, 
Allocated addresses:
  10.17.0.178 (health)
  10.17.0.179 (kube-system/clustermesh-apiserver-7dcfc8984-vrrpx)
  10.17.0.190 (kube-system/coredns-cc6ccd49c-mztsg)
  10.17.0.248 (kube-system/coredns-cc6ccd49c-n6wz9)
  10.17.0.65 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9303beca5d298ce5
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   27s ago        never        0       no error   
  ct-map-pressure                                                    28s ago        never        0       no error   
  daemon-validate-config                                             13s ago        never        0       no error   
  dns-garbage-collector-job                                          30s ago        never        0       no error   
  endpoint-183-regeneration-recovery                                 never          never        0       no error   
  endpoint-1839-regeneration-recovery                                never          never        0       no error   
  endpoint-2120-regeneration-recovery                                never          never        0       no error   
  endpoint-400-regeneration-recovery                                 never          never        0       no error   
  endpoint-762-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        30s ago        never        0       no error   
  ep-bpf-prog-watchdog                                               28s ago        never        0       no error   
  ipcache-inject-labels                                              28s ago        never        0       no error   
  k8s-heartbeat                                                      31s ago        never        0       no error   
  link-cache                                                         13s ago        never        0       no error   
  local-identity-checkpoint                                          15m15s ago     never        0       no error   
  node-neighbor-link-updater                                         8s ago         never        0       no error   
  remote-etcd-cmesh1                                                 6m36s ago      never        0       no error   
  remote-etcd-cmesh10                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh100                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh101                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh102                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh103                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh104                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh105                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh106                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh107                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh108                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh109                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh11                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh110                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh111                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh112                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh113                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh114                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh115                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh116                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh117                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh118                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh119                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh12                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh120                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh121                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh122                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh123                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh124                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh125                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh126                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh127                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh128                                               6m36s ago      never        0       no error   
  remote-etcd-cmesh13                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh14                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh15                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh16                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh17                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh19                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh2                                                 6m36s ago      never        0       no error   
  remote-etcd-cmesh20                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh21                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh22                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh23                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh24                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh25                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh26                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh27                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh28                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh29                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh3                                                 6m36s ago      never        0       no error   
  remote-etcd-cmesh30                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh31                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh32                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh33                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh34                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh35                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh36                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh37                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh38                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh39                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh4                                                 6m36s ago      never        0       no error   
  remote-etcd-cmesh40                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh41                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh42                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh43                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh44                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh45                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh46                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh47                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh48                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh49                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh5                                                 6m36s ago      never        0       no error   
  remote-etcd-cmesh50                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh51                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh52                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh53                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh54                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh55                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh56                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh57                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh58                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh59                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh6                                                 6m36s ago      never        0       no error   
  remote-etcd-cmesh60                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh61                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh62                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh63                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh64                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh65                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh66                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh67                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh68                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh69                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh7                                                 6m36s ago      never        0       no error   
  remote-etcd-cmesh70                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh71                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh72                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh73                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh74                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh75                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh76                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh77                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh78                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh79                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh8                                                 6m36s ago      never        0       no error   
  remote-etcd-cmesh80                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh81                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh82                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh83                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh84                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh85                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh86                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh87                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh88                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh89                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh9                                                 6m36s ago      never        0       no error   
  remote-etcd-cmesh90                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh91                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh92                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh93                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh94                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh95                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh96                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh97                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh98                                                6m36s ago      never        0       no error   
  remote-etcd-cmesh99                                                6m36s ago      never        0       no error   
  resolve-identity-183                                               27s ago        never        0       no error   
  resolve-identity-1839                                              2m0s ago       never        0       no error   
  resolve-identity-2120                                              25s ago        never        0       no error   
  resolve-identity-400                                               28s ago        never        0       no error   
  resolve-identity-762                                               25s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7dcfc8984-vrrpx   7m0s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-mztsg                 15m25s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-n6wz9                 15m25s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     15m28s ago     never        0       no error   
  sync-policymap-183                                                 23s ago        never        0       no error   
  sync-policymap-1839                                                7m0s ago       never        0       no error   
  sync-policymap-2120                                                23s ago        never        0       no error   
  sync-policymap-400                                                 27s ago        never        0       no error   
  sync-policymap-762                                                 23s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1839)                                  10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2120)                                  5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (762)                                   5s ago         never        0       no error   
  sync-utime                                                         28s ago        never        0       no error   
  write-cni-file                                                     15m30s ago     never        0       no error   
Proxy Status:            OK, ip 10.17.0.65, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 1179648, max 1245183
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 77.22   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.169.143:443 (active)    
                                          2 => 172.31.193.169:443 (active)    
2    10.100.236.197:443    ClusterIP      1 => 172.31.247.244:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.17.0.248:9153 (active)      
                                          2 => 10.17.0.190:9153 (active)      
4    10.100.0.10:53        ClusterIP      1 => 10.17.0.248:53 (active)        
                                          2 => 10.17.0.190:53 (active)        
5    10.100.255.224:2379   ClusterIP      1 => 10.17.0.179:2379 (active)      
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 16815128                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 16815128                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 16815128                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c400000 rw-p 00000000 00:00 0 
400c400000-4010000000 ---p 00000000 00:00 0 
ffff53fea000-ffff541e0000 rw-p 00000000 00:00 0 
ffff541e8000-ffff542c9000 rw-p 00000000 00:00 0 
ffff542c9000-ffff5430a000 rw-s 00000000 00:0d 30                         anon_inode:[perf_event]
ffff5430a000-ffff5434b000 rw-s 00000000 00:0d 30                         anon_inode:[perf_event]
ffff5434b000-ffff5438b000 rw-p 00000000 00:00 0 
ffff5438b000-ffff5438d000 rw-s 00000000 00:0d 30                         anon_inode:[perf_event]
ffff5438d000-ffff5438f000 rw-s 00000000 00:0d 30                         anon_inode:[perf_event]
ffff5438f000-ffff54926000 rw-p 00000000 00:00 0 
ffff54926000-ffff54a26000 rw-p 00000000 00:00 0 
ffff54a26000-ffff54a37000 rw-p 00000000 00:00 0 
ffff54a37000-ffff56a37000 rw-p 00000000 00:00 0 
ffff56a37000-ffff56ab7000 ---p 00000000 00:00 0 
ffff56ab7000-ffff56ab8000 rw-p 00000000 00:00 0 
ffff56ab8000-ffff76ab7000 ---p 00000000 00:00 0 
ffff76ab7000-ffff76ab8000 rw-p 00000000 00:00 0 
ffff76ab8000-ffff96a47000 ---p 00000000 00:00 0 
ffff96a47000-ffff96a48000 rw-p 00000000 00:00 0 
ffff96a48000-ffff9aa39000 ---p 00000000 00:00 0 
ffff9aa39000-ffff9aa3a000 rw-p 00000000 00:00 0 
ffff9aa3a000-ffff9b237000 ---p 00000000 00:00 0 
ffff9b237000-ffff9b238000 rw-p 00000000 00:00 0 
ffff9b238000-ffff9b337000 ---p 00000000 00:00 0 
ffff9b337000-ffff9b397000 rw-p 00000000 00:00 0 
ffff9b397000-ffff9b399000 r--p 00000000 00:00 0                          [vvar]
ffff9b399000-ffff9b39a000 r-xp 00000000 00:00 0                          [vdso]
ffffe003f000-ffffe0060000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium environment keys

```
bgp-announce-pod-cidr:false
bpf-lb-service-map-max:0
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
http-max-grpc-timeout:0
enable-bpf-clock-probe:false
srv6-encap-mode:reduced
tofqdns-min-ttl:0
bpf-lb-mode:snat
iptables-lock-timeout:5s
monitor-aggregation-interval:5s
k8s-api-server:
enable-policy:default
config:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-node-selector-labels:false
hubble-drop-events-interval:2m0s
ipv4-service-range:auto
bpf-ct-timeout-regular-tcp:2h13m20s
hubble-export-file-path:
ipv6-node:auto
enable-hubble:true
set-cilium-node-taints:true
ipv6-mcast-device:
cni-chaining-mode:none
hubble-monitor-events:
egress-masquerade-interfaces:ens+
enable-icmp-rules:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
kvstore-lease-ttl:15m0s
kvstore-connectivity-timeout:2m0s
enable-bpf-masquerade:false
dnsproxy-socket-linger-timeout:10
dns-policy-unload-on-shutdown:false
disable-endpoint-crd:false
synchronize-k8s-nodes:true
enable-pmtu-discovery:false
dnsproxy-lock-count:131
vlan-bpf-bypass:
pprof:false
socket-path:/var/run/cilium/cilium.sock
clustermesh-ip-identities-sync-timeout:1m0s
cflags:
external-envoy-proxy:true
enable-node-port:false
dnsproxy-lock-timeout:500ms
hubble-recorder-sink-queue-size:1024
policy-queue-size:100
enable-xdp-prefilter:false
bpf-ct-timeout-regular-tcp-syn:1m0s
bpf-lb-source-range-map-max:0
container-ip-local-reserved-ports:auto
enable-metrics:true
prometheus-serve-addr:
bpf-lb-maglev-table-size:16381
node-port-acceleration:disabled
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
bpf-lb-maglev-map-max:0
enable-service-topology:false
gops-port:9890
enable-local-node-route:true
direct-routing-skip-unreachable:false
enable-mke:false
wireguard-persistent-keepalive:0s
devices:
proxy-xff-num-trusted-hops-egress:0
trace-payloadlen:128
mesh-auth-spiffe-trust-domain:spiffe.cilium
lib-dir:/var/lib/cilium
ipam-multi-pool-pre-allocation:
node-port-mode:snat
enable-svc-source-range-check:true
mesh-auth-signal-backoff-duration:1s
hubble-flowlogs-config-path:
log-system-load:false
enable-ipsec-key-watcher:true
k8s-require-ipv4-pod-cidr:false
tofqdns-enable-dns-compression:true
hubble-export-file-compress:false
ipv4-native-routing-cidr:
read-cni-conf:
fixed-identity-mapping:
enable-sctp:false
cni-external-routing:false
metrics:
enable-ip-masq-agent:false
enable-srv6:false
use-full-tls-context:false
enable-host-legacy-routing:false
log-opt:
hubble-export-file-max-size-mb:10
allow-localhost:auto
enable-l2-announcements:false
enable-bpf-tproxy:false
mesh-auth-mutual-connect-timeout:5s
cni-chaining-target:
nodes-gc-interval:5m0s
bpf-lb-rss-ipv4-src-cidr:
allocator-list-timeout:3m0s
bpf-lb-affinity-map-max:0
ipv4-range:auto
proxy-portrange-min:10000
bpf-ct-global-any-max:262144
direct-routing-device:
enable-custom-calls:false
proxy-gid:1337
enable-ipsec:false
monitor-aggregation:medium
dnsproxy-enable-transparent-mode:true
http-retry-timeout:0
hubble-recorder-storage-path:/var/run/cilium/pcaps
bpf-sock-rev-map-max:262144
preallocate-bpf-maps:false
enable-ipsec-xfrm-state-caching:true
enable-ingress-controller:false
kvstore:
bpf-ct-timeout-regular-any:1m0s
k8s-heartbeat-timeout:30s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
k8s-client-connection-timeout:30s
local-max-addr-scope:252
config-dir:/tmp/cilium/config-map
hubble-prefer-ipv6:false
enable-health-checking:true
vtep-endpoint:
vtep-mac:
ipv4-node:auto
hubble-metrics-server:
bpf-node-map-max:16384
bpf-neigh-global-max:524288
hubble-skip-unknown-cgroup-ids:true
mesh-auth-enabled:true
clustermesh-config:/var/lib/cilium/clustermesh/
envoy-log:
hubble-export-fieldmask:
ipsec-key-rotation-duration:5m0s
enable-k8s-endpoint-slice:true
bypass-ip-availability-upon-restore:false
debug:false
monitor-queue-size:0
identity-change-grace-period:5s
enable-cilium-health-api-server-access:
envoy-secrets-namespace:
ipv6-pod-subnets:
hubble-drop-events-reasons:auth_required,policy_denied
tunnel-port:0
ipv6-service-range:auto
config-sources:config-map:kube-system/cilium-config
enable-active-connection-tracking:false
bpf-filter-priority:1
hubble-export-file-max-backups:5
tofqdns-dns-reject-response-code:refused
policy-audit-mode:false
bpf-ct-global-tcp-max:524288
gateway-api-secrets-namespace:
mesh-auth-mutual-listener-port:0
k8s-sync-timeout:3m0s
enable-bandwidth-manager:false
disable-envoy-version-check:false
enable-k8s-terminating-endpoint:true
l2-pod-announcements-interface:
bpf-auth-map-max:524288
nodeport-addresses:
enable-envoy-config:false
mesh-auth-spire-admin-socket:
hubble-socket-path:/var/run/cilium/hubble.sock
enable-well-known-identities:false
enable-session-affinity:false
state-dir:/var/run/cilium
kube-proxy-replacement-healthz-bind-address:
enable-l2-pod-announcements:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-tracing:false
endpoint-queue-size:25
proxy-connect-timeout:2
egress-gateway-policy-map-max:16384
force-device-detection:false
l2-announcements-retry-period:2s
static-cnp-path:
enable-ipv4-egress-gateway:false
bpf-ct-timeout-service-tcp:2h13m20s
crd-wait-timeout:5m0s
local-router-ipv4:
procfs:/host/proc
mtu:0
bpf-lb-acceleration:disabled
bpf-lb-rev-nat-map-max:0
envoy-keep-cap-netbindservice:false
vtep-mask:
tofqdns-idle-connection-grace-period:0s
endpoint-bpf-prog-watchdog-interval:30s
ipam:cluster-pool
mesh-auth-gc-interval:5m0s
bpf-ct-timeout-service-tcp-grace:1m0s
k8s-client-burst:20
encryption-strict-mode-allow-remote-node-identities:false
labels:
multicast-enabled:false
bpf-ct-timeout-regular-tcp-fin:10s
ipsec-key-file:
envoy-base-id:0
clustermesh-enable-mcs-api:false
certificates-directory:/var/run/cilium/certs
derive-masq-ip-addr-from-device:
mesh-auth-rotated-identities-queue-size:1024
l2-announcements-renew-deadline:5s
hubble-redact-http-userinfo:true
k8s-service-cache-size:128
proxy-admin-port:0
tofqdns-max-deferred-connection-deletes:10000
enable-ipv6:false
policy-accounting:true
nat-map-stats-entries:32
bpf-ct-timeout-service-any:1m0s
proxy-max-requests-per-connection:0
enable-wireguard-userspace-fallback:false
hubble-redact-http-headers-allow:
agent-health-port:9879
ipam-cilium-node-update-rate:15s
clustermesh-sync-timeout:1m0s
enable-gateway-api:false
enable-ipv4:true
route-metric:0
enable-external-ips:false
enable-route-mtu-for-cni-chaining:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
dnsproxy-concurrency-limit:0
enable-masquerade-to-route-source:false
agent-labels:
enable-local-redirect-policy:false
bpf-lb-rss-ipv6-src-cidr:
bpf-lb-service-backend-map-max:0
api-rate-limit:
endpoint-gc-interval:5m0s
enable-k8s:true
ipv6-range:auto
tofqdns-pre-cache:
enable-cilium-api-server-access:
routing-mode:tunnel
enable-ipv4-fragment-tracking:true
bpf-lb-external-clusterip:false
policy-trigger-interval:1s
bpf-events-trace-enabled:true
proxy-idle-timeout-seconds:60
hubble-event-buffer-capacity:4095
arping-refresh-period:30s
hubble-listen-address::4244
egress-gateway-reconciliation-trigger-interval:1s
tunnel-protocol:vxlan
conntrack-gc-max-interval:0s
proxy-portrange-max:20000
pprof-port:6060
mesh-auth-queue-size:1024
exclude-local-address:
policy-cidr-match-mode:
http-retry-count:3
k8s-kubeconfig-path:
enable-bgp-control-plane:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-ipip-termination:false
install-no-conntrack-iptables-rules:false
egress-multi-home-ip-rule-compat:false
cluster-pool-ipv4-mask-size:24
hubble-event-queue-size:0
hubble-export-denylist:
hubble-redact-http-headers-deny:
kube-proxy-replacement:false
kvstore-opt:
enable-health-check-nodeport:true
hubble-redact-http-urlquery:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-encryption-strict-mode:false
bpf-lb-sock-terminate-pod-connections:false
keep-config:false
envoy-config-timeout:2m0s
enable-ipv4-big-tcp:false
enable-k8s-networkpolicy:true
cluster-name:cmesh18
k8s-client-qps:10
enable-cilium-endpoint-slice:false
pprof-address:localhost
exclude-node-label-patterns:
disable-external-ip-mitigation:false
enable-ipv4-masquerade:true
identity-heartbeat-timeout:30m0s
enable-health-check-loadbalancer-ip:false
clustermesh-enable-endpoint-sync:false
ipv6-cluster-alloc-cidr:f00d::/64
enable-endpoint-routes:false
enable-recorder:false
enable-host-firewall:false
enable-identity-mark:true
dns-max-ips-per-restored-rule:1000
enable-vtep:false
http-normalize-path:true
label-prefix-file:
debug-verbose:
cluster-id:18
hubble-drop-events:false
unmanaged-pod-watcher-interval:15
bpf-map-event-buffers:
enable-stale-cilium-endpoint-cleanup:true
restore:true
node-port-bind-protection:true
bpf-root:/sys/fs/bpf
enable-ipv6-masquerade:true
proxy-prometheus-port:0
k8s-service-proxy-name:
enable-host-port:false
kvstore-periodic-sync:5m0s
hubble-redact-kafka-apikey:false
tofqdns-endpoint-max-ip-per-hostname:50
hubble-disable-tls:false
identity-allocation-mode:crd
cluster-pool-ipv4-cidr:10.17.0.0/16
tofqdns-proxy-response-max-delay:100ms
enable-endpoint-health-checking:true
bpf-events-policy-verdict-enabled:true
enable-tcx:true
ipv4-pod-subnets:
kvstore-max-consecutive-quorum-errors:2
trace-sock:true
node-port-range:
custom-cni-conf:false
bpf-lb-dsr-l4-xlate:frontend
max-controller-interval:0
enable-high-scale-ipcache:false
encryption-strict-mode-cidr:
identity-gc-interval:15m0s
hubble-redact-enabled:false
install-iptables-rules:true
k8s-client-connection-keep-alive:30s
http-idle-timeout:0
cni-log-file:/var/run/cilium/cilium-cni.log
encrypt-node:false
bpf-nat-global-max:524288
vtep-cidr:
bpf-lb-sock:false
l2-announcements-lease-duration:15s
enable-k8s-api-discovery:false
dnsproxy-concurrency-processing-grace-period:0s
hubble-metrics:
mke-cgroup-mount:
ipam-default-ip-pool:default
version:false
cilium-endpoint-gc-interval:5m0s
monitor-aggregation-flags:all
allow-icmp-frag-needed:true
bpf-lb-sock-hostns-only:false
conntrack-gc-interval:0s
node-port-algorithm:random
enable-unreachable-routes:false
prepend-iptables-chains:true
bpf-map-dynamic-size-ratio:0.0025
k8s-namespace:kube-system
enable-hubble-recorder-api:true
enable-xt-socket-fallback:true
cni-exclusive:true
bpf-lb-map-max:65536
bpf-lb-dsr-dispatch:opt
enable-ipsec-encrypted-overlay:false
bpf-lb-algorithm:random
controller-group-metrics:
remove-cilium-node-taints:true
identity-restore-grace-period:30s
iptables-random-fully:false
annotate-k8s-node:false
bpf-fragments-map-max:8192
enable-ipv6-big-tcp:false
fqdn-regex-compile-lru-size:1024
enable-wireguard:false
max-internal-timer-delay:0s
cgroup-root:/run/cilium/cgroupv2
hubble-export-allowlist:
node-labels:
operator-api-serve-addr:127.0.0.1:9234
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bgp-announce-lb-ip:false
disable-iptables-feeder-rules:
nat-map-stats-interval:30s
cmdref:
datapath-mode:veth
local-router-ipv6:
ipv4-service-loopback-address:169.254.42.1
join-cluster:false
cluster-health-port:4240
dnsproxy-insecure-skip-transparent-mode-check:false
service-no-backend-response:reject
enable-runtime-device-detection:true
ingress-secrets-namespace:
bpf-policy-map-max:16384
proxy-max-connection-duration-seconds:0
auto-direct-node-routes:false
enable-l2-neigh-discovery:true
agent-liveness-update-interval:1s
set-cilium-is-up-condition:true
enable-l7-proxy:true
auto-create-cilium-node-resource:true
http-request-timeout:3600
enable-bbr:false
enable-ipv6-ndp:false
enable-nat46x64-gateway:false
tofqdns-proxy-port:0
encrypt-interface:
k8s-require-ipv6-pod-cidr:false
bpf-policy-map-full-reconciliation-interval:15m0s
use-cilium-internal-ip-for-ipsec:false
max-connected-clusters:255
envoy-config-retry-interval:15s
enable-monitor:true
ipv6-native-routing-cidr:
log-driver:
bpf-events-drop-enabled:true
operator-prometheus-serve-addr::9963
proxy-xff-num-trusted-hops-ingress:0
enable-auto-protect-node-port-range:true
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
183        Disabled           Disabled          4          reserved:health                                                                     10.17.0.178   ready   
400        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
762        Disabled           Disabled          1203169    k8s:eks.amazonaws.com/component=coredns                                             10.17.0.248   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh18                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1839       Disabled           Disabled          1187483    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.17.0.179   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh18                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2120       Disabled           Disabled          1203169    k8s:eks.amazonaws.com/component=coredns                                             10.17.0.190   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh18                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 183

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434988   5559      0        
Allow    Ingress     1          ANY          NONE         disabled    13226    155       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 183

```
Invalid argument: unknown type 183
```


#### Endpoint Get 183

```
[
  {
    "id": 183,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-183-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "98301575-4bd2-46f6-b3a1-d9b2e5f8b85f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-183",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:45.628Z",
            "success-count": 4
          },
          "uuid": "3e12dfbc-182e-4d97-98c1-71f17293d614"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-183",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:48.942Z",
            "success-count": 2
          },
          "uuid": "2ca3bba6-f5e1-4500-b8df-457a03bf5d4c"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:38Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.17.0.178",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "be:cc:61:ad:14:a3",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "96:d4:a8:5c:b3:a9"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 183

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 183

```
Timestamp              Status   State                   Message
2024-10-25T10:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:38Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:48Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:45Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:45Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:44Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 400

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 400

```
Invalid argument: unknown type 400
```


#### Endpoint Get 400

```
[
  {
    "id": 400,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-400-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "26694385-40a7-42cd-aafd-416c8dd41659"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-400",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:44.565Z",
            "success-count": 4
          },
          "uuid": "b641b112-2def-4aa8-8386-9c155a63ed9b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-400",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:45.630Z",
            "success-count": 2
          },
          "uuid": "db731f78-488a-4f26-9080-eb033659d8f0"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:38Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "7a:56:d3:07:b4:a7",
        "interface-name": "cilium_host",
        "mac": "7a:56:d3:07:b4:a7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 400

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 400

```
Timestamp              Status   State                   Message
2024-10-25T10:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:38Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:44Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:44Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 762

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    215973   1946      0        
Allow    Ingress     1          ANY          NONE         disabled    87227    1003      0        
Allow    Egress      0          ANY          NONE         disabled    62843    606       0        

```


#### BPF CT List 762

```
Invalid argument: unknown type 762
```


#### Endpoint Get 762

```
[
  {
    "id": 762,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-762-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2e04c881-8b40-4b4f-bc12-87d190e92d00"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-762",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:46.812Z",
            "success-count": 4
          },
          "uuid": "33965bd0-dc0e-42cb-b4d1-5022a79f5c6a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-n6wz9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:46.810Z",
            "success-count": 1
          },
          "uuid": "eba7ea3e-39e4-4805-964c-ecbe4fdb103d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-762",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:48.948Z",
            "success-count": 2
          },
          "uuid": "c597a4c0-b957-4054-9640-b978ebf5fdbb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (762)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:06.889Z",
            "success-count": 94
          },
          "uuid": "25428de8-53b3-4829-8609-f45055d453b2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "521a1e8a1e2d3274ef3f35de36e4bdf8a9ebe025cec5d8edc4e166dcae6d0b62:eth0",
        "container-id": "521a1e8a1e2d3274ef3f35de36e4bdf8a9ebe025cec5d8edc4e166dcae6d0b62",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-n6wz9",
        "pod-name": "kube-system/coredns-cc6ccd49c-n6wz9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1203169,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh18",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh18",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:38Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.17.0.248",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ae:8e:8d:81:2d:12",
        "interface-index": 9,
        "interface-name": "lxce649021f445a",
        "mac": "ca:5e:99:de:9d:ee"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1203169,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1203169,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 762

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 762

```
Timestamp              Status    State                   Message
2024-10-25T10:22:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:38Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:37Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:36Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:36Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:36Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:13Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:13Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:13Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:13Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:12Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:12Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:12Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:12Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:48Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:48Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:48Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:48Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:47Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:47Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:46Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:46Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:13:46Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 1203169

```
ID        LABELS
1203169   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh18
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1839

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3888333   36482     0        
Allow    Ingress     1          ANY          NONE         disabled    3136604   31823     0        
Allow    Egress      0          ANY          NONE         disabled    4448844   41153     0        

```


#### BPF CT List 1839

```
Invalid argument: unknown type 1839
```


#### Endpoint Get 1839

```
[
  {
    "id": 1839,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1839-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c0029081-11be-46cc-9aa9-d73487220f3d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1839",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:12.485Z",
            "success-count": 2
          },
          "uuid": "051da88d-9c70-40cb-a6ce-b06a67d3ee45"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7dcfc8984-vrrpx",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:12.483Z",
            "success-count": 1
          },
          "uuid": "0049c154-b208-44b4-b2e8-ce33bf58e860"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1839",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:12.517Z",
            "success-count": 1
          },
          "uuid": "1efaee24-5b58-494d-9d8c-6498cc58afe5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1839)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.529Z",
            "success-count": 44
          },
          "uuid": "2f787377-c966-470f-aa76-a2253ce4dac8"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7ad2a8af05dcd6d9de7050d0b5af75e85a6a39a067a6488bf823b0c550657581:eth0",
        "container-id": "7ad2a8af05dcd6d9de7050d0b5af75e85a6a39a067a6488bf823b0c550657581",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7dcfc8984-vrrpx",
        "pod-name": "kube-system/clustermesh-apiserver-7dcfc8984-vrrpx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1187483,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh18",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7dcfc8984"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh18",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:38Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.17.0.179",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "36:62:80:b3:82:d5",
        "interface-index": 15,
        "interface-name": "lxcb8ecd50dfa37",
        "mac": "3a:eb:00:e5:e1:a4"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1187483,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1187483,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1839

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1839

```
Timestamp              Status   State                   Message
2024-10-25T10:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:38Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:12Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:12Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:12Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1187483

```
ID        LABELS
1187483   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh18
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2120

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    216724   1953      0        
Allow    Ingress     1          ANY          NONE         disabled    87491    1007      0        
Allow    Egress      0          ANY          NONE         disabled    61864    595       0        

```


#### BPF CT List 2120

```
Invalid argument: unknown type 2120
```


#### Endpoint Get 2120

```
[
  {
    "id": 2120,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2120-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5f0894a6-ea0f-4021-96bc-cb0257170bc4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2120",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:46.911Z",
            "success-count": 4
          },
          "uuid": "37e1b298-0787-4650-9908-0d069f82e973"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-mztsg",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:46.906Z",
            "success-count": 1
          },
          "uuid": "359ad8a3-13f2-46cf-92e3-40a0a7c923ea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2120",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:48.992Z",
            "success-count": 2
          },
          "uuid": "9bcdcb19-deff-4f4d-9f33-038d804141c4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2120)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:06.984Z",
            "success-count": 94
          },
          "uuid": "f589f219-7562-4919-8e88-ef3b3c5d0e7b"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "e8778bcc34916efd47f5abd14a0ddee1c244dc999eafded5784c3e0eda021bd6:eth0",
        "container-id": "e8778bcc34916efd47f5abd14a0ddee1c244dc999eafded5784c3e0eda021bd6",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-mztsg",
        "pod-name": "kube-system/coredns-cc6ccd49c-mztsg"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1203169,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh18",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh18",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:38Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.17.0.190",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a2:f5:c1:50:1a:1a",
        "interface-index": 11,
        "interface-name": "lxc7f33fa3cac47",
        "mac": "1a:1f:bf:54:00:fd"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1203169,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1203169,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2120

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2120

```
Timestamp              Status   State                   Message
2024-10-25T10:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:38Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:48Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:46Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:46Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1203169

```
ID        LABELS
1203169   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh18
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Policy get

```
:
 []
Revision: 1

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.17.0.65": (string) (len=6) "router",
  (string) (len=11) "10.17.0.178": (string) (len=6) "health",
  (string) (len=11) "10.17.0.248": (string) (len=35) "kube-system/coredns-cc6ccd49c-n6wz9",
  (string) (len=11) "10.17.0.190": (string) (len=35) "kube-system/coredns-cc6ccd49c-mztsg",
  (string) (len=11) "10.17.0.179": (string) (len=49) "kube-system/clustermesh-apiserver-7dcfc8984-vrrpx"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.247.244": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x400129f130)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4000e97740,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4000e97740,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40023f86e0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40023f8790)(frontends:[10.100.236.197]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40023f8840)(frontends:[10.100.0.10]/ports=[dns-tcp metrics dns]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001f16d10)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001d50dc0)(frontends:[10.100.255.224]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000f640a0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4001e001a0)(172.31.169.143:443/TCP,172.31.193.169:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000f640a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-tbcsz": (*k8s.Endpoints)(0x4001f57e10)(172.31.247.244:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000f640b0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-496k6": (*k8s.Endpoints)(0x40033b7e10)(10.17.0.190:53/TCP[eu-west-3b],10.17.0.190:53/UDP[eu-west-3b],10.17.0.190:9153/TCP[eu-west-3b],10.17.0.248:53/TCP[eu-west-3b],10.17.0.248:53/UDP[eu-west-3b],10.17.0.248:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001446ba8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-dsgt6": (*k8s.Endpoints)(0x40015fe750)(10.17.0.179:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40017b71f0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400084e320)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4009c0c870
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001c69320,
  gcExited: (chan struct {}) 0x4001c69380,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40017ad980)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000edeef8)({
      MetricVec: (*prometheus.MetricVec)(0x4001bcb7d0)({
       metricMap: (*prometheus.metricMap)(0x4001bcb800)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001956960)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40017ada00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000edef00)({
      MetricVec: (*prometheus.MetricVec)(0x4001bcb860)({
       metricMap: (*prometheus.metricMap)(0x4001bcb890)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019569c0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40017ada80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000edef08)({
      MetricVec: (*prometheus.MetricVec)(0x4001bcb8f0)({
       metricMap: (*prometheus.metricMap)(0x4001bcb920)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001956a20)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40017adb00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000edef10)({
      MetricVec: (*prometheus.MetricVec)(0x4001bcb980)({
       metricMap: (*prometheus.metricMap)(0x4001bcb9b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001956a80)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40017adb80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000edef18)({
      MetricVec: (*prometheus.MetricVec)(0x4001bcba10)({
       metricMap: (*prometheus.metricMap)(0x4001bcba40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001956ae0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40017adc00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000edef20)({
      MetricVec: (*prometheus.MetricVec)(0x4001bcbaa0)({
       metricMap: (*prometheus.metricMap)(0x4001bcbad0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001956b40)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40017adc80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000edef28)({
      MetricVec: (*prometheus.MetricVec)(0x4001bcbb30)({
       metricMap: (*prometheus.metricMap)(0x4001bcbb60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001956ba0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40017add00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000edef30)({
      MetricVec: (*prometheus.MetricVec)(0x4001bcbbc0)({
       metricMap: (*prometheus.metricMap)(0x4001bcbbf0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001956c00)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40017add80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000edef38)({
      MetricVec: (*prometheus.MetricVec)(0x4001bcbc50)({
       metricMap: (*prometheus.metricMap)(0x4001bcbc80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001956c60)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40017b71f0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40012e1dc0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d12918)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 468ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations

