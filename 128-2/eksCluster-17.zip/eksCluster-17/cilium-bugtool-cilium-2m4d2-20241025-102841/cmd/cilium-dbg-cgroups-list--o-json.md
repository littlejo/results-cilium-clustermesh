[
  {
    "containers": [
      {
        "cgroup-id": 8543,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62e205f4_a180_4ac0_ada0_794c9174f5bc.slice/cri-containerd-7b214154c2cfb26483bc9c7e19498834d815eef9c82aa75acb48cdcfb4314afc.scope"
      },
      {
        "cgroup-id": 8459,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62e205f4_a180_4ac0_ada0_794c9174f5bc.slice/cri-containerd-38eefe6040be34b1d4bcd524f94faab93f288eaa58ae37795a1501d3946c3a9f.scope"
      },
      {
        "cgroup-id": 8627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62e205f4_a180_4ac0_ada0_794c9174f5bc.slice/cri-containerd-c1e23d209e136a2a8b07fc451e3742e8e95acd582b01e3bbaa0a32bba2184055.scope"
      }
    ],
    "ips": [
      "10.17.0.179"
    ],
    "name": "clustermesh-apiserver-7dcfc8984-vrrpx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7031,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e4f774f_7fc5_4289_bdf5_62cc1d3a19bd.slice/cri-containerd-f4f9bc91c540382f5b67e8f0c781bf55a8dee6b7b2578e7512248c991cf6f17c.scope"
      }
    ],
    "ips": [
      "10.17.0.190"
    ],
    "name": "coredns-cc6ccd49c-mztsg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7115,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1dadeec6_5646_494e_b49c_7cba907a9387.slice/cri-containerd-9f9f4c0fef20c006300f3bc53a21b9a2fb6ffe368516d93ebea6503a9eee8c94.scope"
      }
    ],
    "ips": [
      "10.17.0.248"
    ],
    "name": "coredns-cc6ccd49c-n6wz9",
    "namespace": "kube-system"
  }
]

