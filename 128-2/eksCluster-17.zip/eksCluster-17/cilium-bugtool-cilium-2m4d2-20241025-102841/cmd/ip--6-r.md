fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxce649021f445a proto kernel metric 256 pref medium
fe80::/64 dev lxc7f33fa3cac47 proto kernel metric 256 pref medium
fe80::/64 dev lxcb8ecd50dfa37 proto kernel metric 256 pref medium
