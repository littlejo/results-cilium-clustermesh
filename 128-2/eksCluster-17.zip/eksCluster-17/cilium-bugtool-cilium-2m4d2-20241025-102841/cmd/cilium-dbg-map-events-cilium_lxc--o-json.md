{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:44.353Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.247.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:44.353Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.940Z",
  "value": "id=183   sec_id=4     flags=0x0000 ifindex=7   mac=96:D4:A8:5C:B3:A9 nodemac=BE:CC:61:AD:14:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.942Z",
  "value": "id=762   sec_id=1203169 flags=0x0000 ifindex=9   mac=CA:5E:99:DE:9D:EE nodemac=AE:8E:8D:81:2D:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.985Z",
  "value": "id=2120  sec_id=1203169 flags=0x0000 ifindex=11  mac=1A:1F:BF:54:00:FD nodemac=A2:F5:C1:50:1A:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.986Z",
  "value": "id=762   sec_id=1203169 flags=0x0000 ifindex=9   mac=CA:5E:99:DE:9D:EE nodemac=AE:8E:8D:81:2D:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.992Z",
  "value": "id=183   sec_id=4     flags=0x0000 ifindex=7   mac=96:D4:A8:5C:B3:A9 nodemac=BE:CC:61:AD:14:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:12.176Z",
  "value": "id=762   sec_id=1203169 flags=0x0000 ifindex=9   mac=CA:5E:99:DE:9D:EE nodemac=AE:8E:8D:81:2D:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:12.177Z",
  "value": "id=183   sec_id=4     flags=0x0000 ifindex=7   mac=96:D4:A8:5C:B3:A9 nodemac=BE:CC:61:AD:14:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:12.177Z",
  "value": "id=2120  sec_id=1203169 flags=0x0000 ifindex=11  mac=1A:1F:BF:54:00:FD nodemac=A2:F5:C1:50:1A:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:12.207Z",
  "value": "id=3873  sec_id=1187483 flags=0x0000 ifindex=13  mac=32:06:5E:BA:D3:B7 nodemac=F2:7F:DA:D8:3D:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:13.177Z",
  "value": "id=183   sec_id=4     flags=0x0000 ifindex=7   mac=96:D4:A8:5C:B3:A9 nodemac=BE:CC:61:AD:14:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:13.177Z",
  "value": "id=2120  sec_id=1203169 flags=0x0000 ifindex=11  mac=1A:1F:BF:54:00:FD nodemac=A2:F5:C1:50:1A:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:13.177Z",
  "value": "id=3873  sec_id=1187483 flags=0x0000 ifindex=13  mac=32:06:5E:BA:D3:B7 nodemac=F2:7F:DA:D8:3D:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:13.177Z",
  "value": "id=762   sec_id=1203169 flags=0x0000 ifindex=9   mac=CA:5E:99:DE:9D:EE nodemac=AE:8E:8D:81:2D:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.517Z",
  "value": "id=1839  sec_id=1187483 flags=0x0000 ifindex=15  mac=3A:EB:00:E5:E1:A4 nodemac=36:62:80:B3:82:D5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.17.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.927Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.262Z",
  "value": "id=1839  sec_id=1187483 flags=0x0000 ifindex=15  mac=3A:EB:00:E5:E1:A4 nodemac=36:62:80:B3:82:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.264Z",
  "value": "id=183   sec_id=4     flags=0x0000 ifindex=7   mac=96:D4:A8:5C:B3:A9 nodemac=BE:CC:61:AD:14:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.264Z",
  "value": "id=762   sec_id=1203169 flags=0x0000 ifindex=9   mac=CA:5E:99:DE:9D:EE nodemac=AE:8E:8D:81:2D:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.264Z",
  "value": "id=2120  sec_id=1203169 flags=0x0000 ifindex=11  mac=1A:1F:BF:54:00:FD nodemac=A2:F5:C1:50:1A:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.248Z",
  "value": "id=183   sec_id=4     flags=0x0000 ifindex=7   mac=96:D4:A8:5C:B3:A9 nodemac=BE:CC:61:AD:14:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.248Z",
  "value": "id=1839  sec_id=1187483 flags=0x0000 ifindex=15  mac=3A:EB:00:E5:E1:A4 nodemac=36:62:80:B3:82:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.248Z",
  "value": "id=762   sec_id=1203169 flags=0x0000 ifindex=9   mac=CA:5E:99:DE:9D:EE nodemac=AE:8E:8D:81:2D:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.248Z",
  "value": "id=2120  sec_id=1203169 flags=0x0000 ifindex=11  mac=1A:1F:BF:54:00:FD nodemac=A2:F5:C1:50:1A:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:38.248Z",
  "value": "id=1839  sec_id=1187483 flags=0x0000 ifindex=15  mac=3A:EB:00:E5:E1:A4 nodemac=36:62:80:B3:82:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:38.249Z",
  "value": "id=183   sec_id=4     flags=0x0000 ifindex=7   mac=96:D4:A8:5C:B3:A9 nodemac=BE:CC:61:AD:14:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:38.249Z",
  "value": "id=762   sec_id=1203169 flags=0x0000 ifindex=9   mac=CA:5E:99:DE:9D:EE nodemac=AE:8E:8D:81:2D:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:38.249Z",
  "value": "id=2120  sec_id=1203169 flags=0x0000 ifindex=11  mac=1A:1F:BF:54:00:FD nodemac=A2:F5:C1:50:1A:1A"
}

