Endpoint ID: 183
Path: /sys/fs/bpf/tc/globals/cilium_policy_00183

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    436248   5575      0        
Allow    Ingress     1          ANY          NONE         disabled    13226    155       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 400
Path: /sys/fs/bpf/tc/globals/cilium_policy_00400

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 762
Path: /sys/fs/bpf/tc/globals/cilium_policy_00762

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    215973   1946      0        
Allow    Ingress     1          ANY          NONE         disabled    87227    1003      0        
Allow    Egress      0          ANY          NONE         disabled    62843    606       0        


Endpoint ID: 1839
Path: /sys/fs/bpf/tc/globals/cilium_policy_01839

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3889103   36490     0        
Allow    Ingress     1          ANY          NONE         disabled    3136604   31823     0        
Allow    Egress      0          ANY          NONE         disabled    4469421   41371     0        


Endpoint ID: 2120
Path: /sys/fs/bpf/tc/globals/cilium_policy_02120

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    216724   1953      0        
Allow    Ingress     1          ANY          NONE         disabled    87491    1007      0        
Allow    Egress      0          ANY          NONE         disabled    61864    595       0        


