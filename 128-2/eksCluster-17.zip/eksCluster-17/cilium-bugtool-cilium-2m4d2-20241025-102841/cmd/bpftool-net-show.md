xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 475
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 468
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 458
cilium_host(4) clsact/egress cil_from_host-cilium_host id 460
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 454
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 455
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 514
lxce649021f445a(9) clsact/ingress cil_from_container-lxce649021f445a id 488
lxc7f33fa3cac47(11) clsact/ingress cil_from_container-lxc7f33fa3cac47 id 521
lxcb8ecd50dfa37(15) clsact/ingress cil_from_container-lxcb8ecd50dfa37 id 587

flow_dissector:

netfilter:

