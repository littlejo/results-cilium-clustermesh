alloc: 97.45MB (102184072 bytes)
total-alloc: 1.38GB (1481299456 bytes)
sys: 206.13MB (216147284 bytes)
lookups: 0
mallocs: 48615729
frees: 47611151
heap-alloc: 97.45MB (102184072 bytes)
heap-sys: 161.66MB (169517056 bytes)
heap-idle: 44.45MB (46612480 bytes)
heap-in-use: 117.21MB (122904576 bytes)
heap-released: 1.69MB (1769472 bytes)
heap-objects: 1004578
stack-in-use: 34.31MB (35979264 bytes)
stack-sys: 34.31MB (35979264 bytes)
stack-mspan-inuse: 1.95MB (2046720 bytes)
stack-mspan-sys: 2.38MB (2496960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 739.87KB (757625 bytes)
gc-sys: 5.15MB (5404952 bytes)
next-gc: when heap-alloc >= 147.80MB (154984456 bytes)
last-gc: 2024-10-25 10:28:46.965564013 +0000 UTC
gc-pause-total: 9.925819ms
gc-pause: 79706
gc-pause-end: 1729852126965564013
num-gc: 75
num-forced-gc: 0
gc-cpu-fraction: 0.0003063383969503158
enable-gc: true
debug-gc: false
