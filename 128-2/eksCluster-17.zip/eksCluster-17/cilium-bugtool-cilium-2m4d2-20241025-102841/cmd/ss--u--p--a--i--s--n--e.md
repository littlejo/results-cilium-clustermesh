Total: 552
TCP:   1071 (estab 306, closed 746, orphaned 0, timewait 289)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  325       313       12       
INET	  335       319       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:36779      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:22554 sk:25a fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.247.244%ens5:68         0.0.0.0:*    uid:192 ino:15265 sk:25b cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:22019 sk:25c cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15595 sk:25d cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:22018 sk:25e cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15596 sk:25f cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8a2:99ff:fe25:9987]%ens5:546           [::]:*    uid:192 ino:15263 sk:260 cgroup:unreachable:c4e v6only:1 <->                   
