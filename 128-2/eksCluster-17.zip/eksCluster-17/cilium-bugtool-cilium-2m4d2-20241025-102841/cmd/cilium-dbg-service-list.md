ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.169.143:443 (active)    
                                          2 => 172.31.193.169:443 (active)    
2    10.100.236.197:443    ClusterIP      1 => 172.31.247.244:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.17.0.248:9153 (active)      
                                          2 => 10.17.0.190:9153 (active)      
4    10.100.0.10:53        ClusterIP      1 => 10.17.0.248:53 (active)        
                                          2 => 10.17.0.190:53 (active)        
5    10.100.255.224:2379   ClusterIP      1 => 10.17.0.179:2379 (active)      
