KEY             VALUE
AgentLiveness   976914250757
UTimeOffset     3378615578125000
