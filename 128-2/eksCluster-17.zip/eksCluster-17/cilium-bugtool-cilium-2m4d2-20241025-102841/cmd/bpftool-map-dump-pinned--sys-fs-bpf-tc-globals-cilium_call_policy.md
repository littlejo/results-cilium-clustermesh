key: b7 00 00 00  value: 0a 02 00 00
key: fa 02 00 00  value: ee 01 00 00
key: 2f 07 00 00  value: 48 02 00 00
key: 48 08 00 00  value: f9 01 00 00
Found 4 elements
