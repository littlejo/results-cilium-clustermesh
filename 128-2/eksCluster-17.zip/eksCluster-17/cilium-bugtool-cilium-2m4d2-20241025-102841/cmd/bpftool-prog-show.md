35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:00+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
67: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
70: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
74: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
78: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
79: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
82: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
83: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
86: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
110: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
113: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
454: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 112
455: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 113
456: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 114
457: sched_cls  name tail_handle_ipv4  tag b670183025f31482  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 115
458: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 117
459: sched_cls  name tail_handle_ipv4_from_host  tag 3a8a395f0e0c9649  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,94
	btf_id 118
460: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,94
	btf_id 119
462: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,94
	btf_id 121
463: sched_cls  name __send_drop_notify  tag d984ef77994c2510  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 122
465: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,95
	btf_id 125
466: sched_cls  name __send_drop_notify  tag d984ef77994c2510  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 126
468: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 128
469: sched_cls  name tail_handle_ipv4_from_host  tag 3a8a395f0e0c9649  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,95
	btf_id 129
473: sched_cls  name tail_handle_ipv4_from_host  tag 3a8a395f0e0c9649  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,98
	btf_id 134
475: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,98,69
	btf_id 136
476: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,98
	btf_id 137
477: sched_cls  name __send_drop_notify  tag d984ef77994c2510  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 138
481: sched_cls  name tail_ipv4_to_endpoint  tag 103c8100de5febf7  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,102,35,76,77,74,99,33,103,34,31,32
	btf_id 144
485: sched_cls  name tail_ipv4_ct_ingress  tag 2cc1154c6ed27dc5  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,102,78
	btf_id 147
487: sched_cls  name tail_ipv4_ct_egress  tag 83a890d75a205be9  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,102,78
	btf_id 150
488: sched_cls  name cil_from_container  tag 2d9844b1dd30c8b9  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,70
	btf_id 152
489: sched_cls  name __send_drop_notify  tag fcee1f80900b1e3d  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 153
492: sched_cls  name tail_handle_ipv4  tag 35145ea8d7348863  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,103
	btf_id 154
494: sched_cls  name handle_policy  tag d2b0750e3babcdf0  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,103,76,77,102,35,74,99,33,78,69,34,31,32
	btf_id 157
496: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,103
	btf_id 159
499: sched_cls  name tail_handle_ipv4_cont  tag 5734c14ac3daef50  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,102,35,99,76,77,33,70,68,71,103,34,31,32,75
	btf_id 161
500: sched_cls  name tail_handle_arp  tag 8ac9f1e1dac979b6  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,103
	btf_id 163
501: sched_cls  name tail_ipv4_to_endpoint  tag b633028a83ae6e48  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,105,35,76,77,74,104,33,106,34,31,32
	btf_id 165
502: sched_cls  name tail_handle_ipv4  tag 11e3bb56deb70581  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,108
	btf_id 167
503: sched_cls  name tail_handle_ipv4_cont  tag 37ed37ef14ef2587  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,107,35,92,76,77,33,70,68,71,108,34,31,32,75
	btf_id 169
504: sched_cls  name tail_ipv4_ct_ingress  tag 2b711d8c5976924b  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,108,76,77,107,78
	btf_id 170
505: sched_cls  name handle_policy  tag 0c0f9cd11a4ac71f  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,106,76,77,105,35,74,104,33,78,69,34,31,32
	btf_id 168
506: sched_cls  name tail_ipv4_to_endpoint  tag b50ba45710b9041d  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,107,35,76,77,74,92,33,108,34,31,32
	btf_id 171
507: sched_cls  name tail_handle_ipv4  tag e2410f5c01be859c  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,106
	btf_id 172
508: sched_cls  name tail_handle_ipv4_cont  tag d167d2f0c09a929b  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,105,35,104,76,77,33,70,68,71,106,34,31,32,75
	btf_id 173
509: sched_cls  name __send_drop_notify  tag e2deb9db80d56eaf  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 174
511: sched_cls  name tail_handle_arp  tag 50b9d668b851e967  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,108
	btf_id 177
512: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,108,76,77,107,78
	btf_id 178
513: sched_cls  name __send_drop_notify  tag 8b4a5fba42beaae1  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 179
514: sched_cls  name cil_from_container  tag 08a7c2e6f1f97bb2  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 108,70
	btf_id 180
515: sched_cls  name tail_ipv4_ct_egress  tag 83a890d75a205be9  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,106,76,77,105,78
	btf_id 175
516: sched_cls  name tail_handle_arp  tag 0b0607613efa4509  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,106
	btf_id 182
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,108
	btf_id 181
519: sched_cls  name tail_ipv4_ct_ingress  tag c6c530ad11761f9a  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,106,76,77,105,78
	btf_id 185
520: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,106
	btf_id 186
521: sched_cls  name cil_from_container  tag 79e7536882bb93d9  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 106,70
	btf_id 187
522: sched_cls  name handle_policy  tag 11de11d5386f6a41  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,108,76,77,107,35,74,92,33,78,69,34,31,32
	btf_id 184
523: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
526: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
527: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
530: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
578: sched_cls  name __send_drop_notify  tag b0e0ccd3f0214f7c  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 203
579: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,125
	btf_id 204
580: sched_cls  name tail_handle_ipv4  tag 7338a3058f2dcaa6  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,125
	btf_id 205
581: sched_cls  name tail_ipv4_ct_ingress  tag 4bb5307489364b5b  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,125,76,77,124,78
	btf_id 206
582: sched_cls  name tail_ipv4_to_endpoint  tag 755f8cf2cb2f01ce  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,124,35,76,77,74,123,33,125,34,31,32
	btf_id 207
584: sched_cls  name handle_policy  tag 01e9b600628ac714  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,125,76,77,124,35,74,123,33,78,69,34,31,32
	btf_id 209
585: sched_cls  name tail_handle_arp  tag 20f14f1a90074f06  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,125
	btf_id 210
586: sched_cls  name tail_handle_ipv4_cont  tag b215af51c2a9f54c  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,124,35,123,76,77,33,70,68,71,125,34,31,32,75
	btf_id 211
587: sched_cls  name cil_from_container  tag 8fcf56083fdf3482  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 125,70
	btf_id 212
588: sched_cls  name tail_ipv4_ct_egress  tag e0d8e4625678ef55  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,125,76,77,124,78
	btf_id 213
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
605: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
608: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
612: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
