CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1dadeec6_5646_494e_b49c_7cba907a9387.slice/cri-containerd-9f9f4c0fef20c006300f3bc53a21b9a2fb6ffe368516d93ebea6503a9eee8c94.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1dadeec6_5646_494e_b49c_7cba907a9387.slice/cri-containerd-521a1e8a1e2d3274ef3f35de36e4bdf8a9ebe025cec5d8edc4e166dcae6d0b62.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e4f774f_7fc5_4289_bdf5_62cc1d3a19bd.slice/cri-containerd-e8778bcc34916efd47f5abd14a0ddee1c244dc999eafded5784c3e0eda021bd6.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e4f774f_7fc5_4289_bdf5_62cc1d3a19bd.slice/cri-containerd-f4f9bc91c540382f5b67e8f0c781bf55a8dee6b7b2578e7512248c991cf6f17c.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bbf1cee_32e3_4d27_87d8_30a8be75fea2.slice/cri-containerd-8974476d8d530820b60abcdaed0e1a1c84dd11c745c9ca1b48901168ab0f291d.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bbf1cee_32e3_4d27_87d8_30a8be75fea2.slice/cri-containerd-f27a442fe3a3a8d38a0f09cb5b576b2427227ee916d3976915396655adc623bf.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a86dd34_66da_4081_9c26_97d13c17bd8c.slice/cri-containerd-d3c357ffdd6c54985db9981c75ac9f9d820570ac2a3fae56ffc8fa6d91b45625.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a86dd34_66da_4081_9c26_97d13c17bd8c.slice/cri-containerd-ac5d30d83b14dbff54836418479f88b5916e4bc32be7dc64caebbbadea8d0c20.scope
    78       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d2e3d3f_0df6_4d09_8f7f_0a93ac9a865d.slice/cri-containerd-f9cfe6c2e7d7735d6e8a62876329858fde8fcfcf6731683998459e4457f00edb.scope
    82       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d2e3d3f_0df6_4d09_8f7f_0a93ac9a865d.slice/cri-containerd-8f7c969f4501eb6ee60bcaba99587685c417a86c782e8c15ca868624ede18034.scope
    70       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62e205f4_a180_4ac0_ada0_794c9174f5bc.slice/cri-containerd-38eefe6040be34b1d4bcd524f94faab93f288eaa58ae37795a1501d3946c3a9f.scope
    608      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62e205f4_a180_4ac0_ada0_794c9174f5bc.slice/cri-containerd-7ad2a8af05dcd6d9de7050d0b5af75e85a6a39a067a6488bf823b0c550657581.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62e205f4_a180_4ac0_ada0_794c9174f5bc.slice/cri-containerd-c1e23d209e136a2a8b07fc451e3742e8e95acd582b01e3bbaa0a32bba2184055.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62e205f4_a180_4ac0_ada0_794c9174f5bc.slice/cri-containerd-7b214154c2cfb26483bc9c7e19498834d815eef9c82aa75acb48cdcfb4314afc.scope
    612      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5be6c6f9_2620_4be4_9125_885ae9a02475.slice/cri-containerd-f059be7b666fd9cc3239fb6d29a81f04dc04e8c8f4b8660c5c53c0143df4f4a1.scope
    86       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5be6c6f9_2620_4be4_9125_885ae9a02475.slice/cri-containerd-728b75ddff0bf8c2379722a8f52980f27fb104770563b7ca3a3d94a4797cab8b.scope
    74       cgroup_device   multi                                          
