markdown output at /tmp/cilium-bugtool-20241025-102842.991+0000-UTC-782681464/cmd/cilium-debuginfo-20241025-102913.58+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.991+0000-UTC-782681464/cmd/cilium-debuginfo-20241025-102913.58+0000-UTC.json
