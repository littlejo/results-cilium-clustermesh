IP ADDRESS        LOCAL ENDPOINT INFO
10.18.0.160:0     (localhost)                                                                                        
10.18.0.205:0     id=2860  sec_id=1252286 flags=0x0000 ifindex=15  mac=22:E6:2E:49:B0:AE nodemac=1E:95:85:AA:E2:C0   
10.18.0.61:0      id=458   sec_id=1282951 flags=0x0000 ifindex=11  mac=02:4B:E9:3F:F8:28 nodemac=7A:F3:A6:96:76:D9   
172.31.161.89:0   (localhost)                                                                                        
10.18.0.213:0     id=792   sec_id=4     flags=0x0000 ifindex=7   mac=F2:1E:CA:52:48:A5 nodemac=CE:1B:6F:85:D6:21     
10.18.0.187:0     id=2134  sec_id=1282951 flags=0x0000 ifindex=9   mac=FA:28:F5:FA:0F:02 nodemac=AA:13:45:7E:72:E4   
