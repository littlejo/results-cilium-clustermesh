key: ca 01 00 00  value: 03 02 00 00
key: 18 03 00 00  value: 28 02 00 00
key: 56 08 00 00  value: 33 02 00 00
key: 2c 0b 00 00  value: 6a 02 00 00
Found 4 elements
