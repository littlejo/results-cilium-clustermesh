KEY             VALUE
AgentLiveness   944755823494
UTimeOffset     3378615642578125
