1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ee:08:da:79:95 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.161.89/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2696sec preferred_lft 2696sec
    inet6 fe80::4ee:8ff:feda:7995/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:5c:94:3e:a3:25 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::685c:94ff:fe3e:a325/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:34:0c:3f:46:05 brd ff:ff:ff:ff:ff:ff
    inet 10.18.0.160/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3034:cff:fe3f:4605/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b2:4e:11:96:02:2b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b04e:11ff:fe96:22b/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:1b:6f:85:d6:21 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::cc1b:6fff:fe85:d621/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc115e46717728@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:13:45:7e:72:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a813:45ff:fe7e:72e4/64 scope link 
       valid_lft forever preferred_lft forever
11: lxccaac667841dc@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:f3:a6:96:76:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::78f3:a6ff:fe96:76d9/64 scope link 
       valid_lft forever preferred_lft forever
15: lxce9094c6adc0b@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:95:85:aa:e2:c0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1c95:85ff:feaa:e2c0/64 scope link 
       valid_lft forever preferred_lft forever
