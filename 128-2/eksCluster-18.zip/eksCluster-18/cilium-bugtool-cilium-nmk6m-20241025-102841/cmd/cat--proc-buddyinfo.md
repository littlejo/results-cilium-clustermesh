Node 0, zone      DMA      0      3      0      2      1     14      2      2      1      3    171 
Node 0, zone   Normal      2      4      5      4      4      4      2      1      2      1      9 
