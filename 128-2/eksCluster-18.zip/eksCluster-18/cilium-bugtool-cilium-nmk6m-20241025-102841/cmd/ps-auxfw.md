USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         689  0.0  0.4 1240176 15968 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         712  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         713  0.0  0.4 1240176 15972 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         687  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.5  7.4 1538228 294280 ?      Ssl  10:14   0:21 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1228848 6900 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
