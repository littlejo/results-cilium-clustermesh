alloc: 93.54MB (98083032 bytes)
total-alloc: 1.30GB (1395286936 bytes)
sys: 218.51MB (229123412 bytes)
lookups: 0
mallocs: 47183204
frees: 46240001
heap-alloc: 93.54MB (98083032 bytes)
heap-sys: 173.51MB (181936128 bytes)
heap-idle: 55.61MB (58310656 bytes)
heap-in-use: 117.90MB (123625472 bytes)
heap-released: 9.31MB (9764864 bytes)
heap-objects: 943203
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 1.96MB (2051040 bytes)
stack-mspan-sys: 2.51MB (2627520 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 850.19KB (870593 bytes)
gc-sys: 5.28MB (5531928 bytes)
next-gc: when heap-alloc >= 145.92MB (153008760 bytes)
last-gc: 2024-10-25 10:28:48.453546046 +0000 UTC
gc-pause-total: 8.550015ms
gc-pause: 82897
gc-pause-end: 1729852128453546046
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00032068886727557293
enable-gc: true
debug-gc: false
