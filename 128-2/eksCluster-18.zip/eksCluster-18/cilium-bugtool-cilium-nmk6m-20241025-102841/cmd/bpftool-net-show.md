xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 546
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 538
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 524
cilium_host(4) clsact/egress cil_from_host-cilium_host id 529
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 475
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 476
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 557
lxc115e46717728(9) clsact/ingress cil_from_container-lxc115e46717728 id 566
lxccaac667841dc(11) clsact/ingress cil_from_container-lxccaac667841dc id 506
lxce9094c6adc0b(15) clsact/ingress cil_from_container-lxce9094c6adc0b id 622

flow_dissector:

netfilter:

