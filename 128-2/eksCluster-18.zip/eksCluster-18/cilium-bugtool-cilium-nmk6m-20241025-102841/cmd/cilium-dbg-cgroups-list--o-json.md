[
  {
    "containers": [
      {
        "cgroup-id": 8627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d274aef_a66e_492b_a3af_76f4f58f93fa.slice/cri-containerd-e459081ce1fe3f6043ce5ec586d485e0bcfb59f7e774bd97e48a03141cd808bd.scope"
      },
      {
        "cgroup-id": 8795,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d274aef_a66e_492b_a3af_76f4f58f93fa.slice/cri-containerd-0c296bd28c8ce0d7a97983063916d4089b34c57cb3f0e2cc358e8a2c1c87a7dc.scope"
      },
      {
        "cgroup-id": 8711,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d274aef_a66e_492b_a3af_76f4f58f93fa.slice/cri-containerd-668dc845274327a03a973e8e23823d69cc70b65ed48973c385000ab0ca41099d.scope"
      }
    ],
    "ips": [
      "10.18.0.205"
    ],
    "name": "clustermesh-apiserver-5d768676b9-4r6mj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7115,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00f8589d_f2ff_4375_9126_880eeec543a3.slice/cri-containerd-4af2fd66459853f59f29bd14a3d6fafb66734bf719f2fc8e8dd255447b390f18.scope"
      }
    ],
    "ips": [
      "10.18.0.187"
    ],
    "name": "coredns-cc6ccd49c-xghjx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7283,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod724e0ef9_7e1a_4f69_957d_fc03d3b380d2.slice/cri-containerd-4161c6b987e5b39d8912404e3fc5a1ce82a8fcf039c218ffd35c1269d6cc29bf.scope"
      }
    ],
    "ips": [
      "10.18.0.61"
    ],
    "name": "coredns-cc6ccd49c-cpgvv",
    "namespace": "kube-system"
  }
]

