{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.196Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.161.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.196Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:27.634Z",
  "value": "id=2134  sec_id=1282951 flags=0x0000 ifindex=9   mac=FA:28:F5:FA:0F:02 nodemac=AA:13:45:7E:72:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.260Z",
  "value": "id=458   sec_id=1282951 flags=0x0000 ifindex=11  mac=02:4B:E9:3F:F8:28 nodemac=7A:F3:A6:96:76:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.262Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=7   mac=F2:1E:CA:52:48:A5 nodemac=CE:1B:6F:85:D6:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.358Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=7   mac=F2:1E:CA:52:48:A5 nodemac=CE:1B:6F:85:D6:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.360Z",
  "value": "id=2134  sec_id=1282951 flags=0x0000 ifindex=9   mac=FA:28:F5:FA:0F:02 nodemac=AA:13:45:7E:72:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:10.254Z",
  "value": "id=2134  sec_id=1282951 flags=0x0000 ifindex=9   mac=FA:28:F5:FA:0F:02 nodemac=AA:13:45:7E:72:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:10.254Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=7   mac=F2:1E:CA:52:48:A5 nodemac=CE:1B:6F:85:D6:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:10.254Z",
  "value": "id=458   sec_id=1282951 flags=0x0000 ifindex=11  mac=02:4B:E9:3F:F8:28 nodemac=7A:F3:A6:96:76:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:10.285Z",
  "value": "id=2187  sec_id=1252286 flags=0x0000 ifindex=13  mac=42:CE:1D:1E:F7:9A nodemac=52:E6:5B:61:5C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:11.254Z",
  "value": "id=2187  sec_id=1252286 flags=0x0000 ifindex=13  mac=42:CE:1D:1E:F7:9A nodemac=52:E6:5B:61:5C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:11.255Z",
  "value": "id=458   sec_id=1282951 flags=0x0000 ifindex=11  mac=02:4B:E9:3F:F8:28 nodemac=7A:F3:A6:96:76:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:11.255Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=7   mac=F2:1E:CA:52:48:A5 nodemac=CE:1B:6F:85:D6:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:11.255Z",
  "value": "id=2134  sec_id=1282951 flags=0x0000 ifindex=9   mac=FA:28:F5:FA:0F:02 nodemac=AA:13:45:7E:72:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.706Z",
  "value": "id=2860  sec_id=1252286 flags=0x0000 ifindex=15  mac=22:E6:2E:49:B0:AE nodemac=1E:95:85:AA:E2:C0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.18.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.854Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:11.603Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=7   mac=F2:1E:CA:52:48:A5 nodemac=CE:1B:6F:85:D6:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:11.603Z",
  "value": "id=2134  sec_id=1282951 flags=0x0000 ifindex=9   mac=FA:28:F5:FA:0F:02 nodemac=AA:13:45:7E:72:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:11.604Z",
  "value": "id=458   sec_id=1282951 flags=0x0000 ifindex=11  mac=02:4B:E9:3F:F8:28 nodemac=7A:F3:A6:96:76:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:11.605Z",
  "value": "id=2860  sec_id=1252286 flags=0x0000 ifindex=15  mac=22:E6:2E:49:B0:AE nodemac=1E:95:85:AA:E2:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:12.601Z",
  "value": "id=2860  sec_id=1252286 flags=0x0000 ifindex=15  mac=22:E6:2E:49:B0:AE nodemac=1E:95:85:AA:E2:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:12.601Z",
  "value": "id=2134  sec_id=1282951 flags=0x0000 ifindex=9   mac=FA:28:F5:FA:0F:02 nodemac=AA:13:45:7E:72:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:12.601Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=7   mac=F2:1E:CA:52:48:A5 nodemac=CE:1B:6F:85:D6:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:12.601Z",
  "value": "id=458   sec_id=1282951 flags=0x0000 ifindex=11  mac=02:4B:E9:3F:F8:28 nodemac=7A:F3:A6:96:76:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:13.601Z",
  "value": "id=458   sec_id=1282951 flags=0x0000 ifindex=11  mac=02:4B:E9:3F:F8:28 nodemac=7A:F3:A6:96:76:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:13.602Z",
  "value": "id=2860  sec_id=1252286 flags=0x0000 ifindex=15  mac=22:E6:2E:49:B0:AE nodemac=1E:95:85:AA:E2:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:13.602Z",
  "value": "id=2134  sec_id=1282951 flags=0x0000 ifindex=9   mac=FA:28:F5:FA:0F:02 nodemac=AA:13:45:7E:72:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:13.602Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=7   mac=F2:1E:CA:52:48:A5 nodemac=CE:1B:6F:85:D6:21"
}

