REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     204063    98395588   1132   bpf_host.c
Interface                 INGRESS     8903      692622     677    bpf_overlay.c
Success                   EGRESS      3951      298658     1694   bpf_host.c
Success                   EGRESS      8354      652752     53     encap.h
Success                   EGRESS      84668     11718373   1308   bpf_lxc.c
Success                   INGRESS     100319    11973090   235    trace.h
Success                   INGRESS     94718     11535220   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
