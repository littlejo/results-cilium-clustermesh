CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00f8589d_f2ff_4375_9126_880eeec543a3.slice/cri-containerd-4af2fd66459853f59f29bd14a3d6fafb66734bf719f2fc8e8dd255447b390f18.scope
    480      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00f8589d_f2ff_4375_9126_880eeec543a3.slice/cri-containerd-fe4eb0fe123d09bf5599dd1937ca00648edb3533eedd876cad02fd9ba8023853.scope
    472      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod428b4165_5124_4078_abc0_e71343514218.slice/cri-containerd-d8bc87fb4cb3319603bc11aba6080083ad5feef4552b82d828f524130e96c5a9.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod428b4165_5124_4078_abc0_e71343514218.slice/cri-containerd-de687f0284d929ccfa0a945629d72d188b97594afc7581a1a299015754ed035f.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd9c1c184_65b6_49a1_9e9f_22fb0a1c9099.slice/cri-containerd-330e6ffb3d837c14705bd4601c35a5a3a9de233cd09b0019fb4cc72e348ebecd.scope
    78       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd9c1c184_65b6_49a1_9e9f_22fb0a1c9099.slice/cri-containerd-a906dea7c232765bdb660db66e41394240aa612246ba63c53c743373d5ff0d14.scope
    117      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod724e0ef9_7e1a_4f69_957d_fc03d3b380d2.slice/cri-containerd-41e5d76a31ce15bd70907d488b3ce9cbf59a815f3ca615b90e4ac50aa8387692.scope
    570      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod724e0ef9_7e1a_4f69_957d_fc03d3b380d2.slice/cri-containerd-4161c6b987e5b39d8912404e3fc5a1ce82a8fcf039c218ffd35c1269d6cc29bf.scope
    574      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod506d780f_f9aa_4a48_9f40_d76a33985f6a.slice/cri-containerd-b42db61174c3f911202c5466673fae71f2926a7a81b0b6c3ed6ea753402c21d9.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod506d780f_f9aa_4a48_9f40_d76a33985f6a.slice/cri-containerd-098fbeb479eb2c21789fa79d628070ef2adcb01f47014aad1f461d7886d7f650.scope
    82       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70381d0c_f1de_4f2c_ad01_23cb90ba8dea.slice/cri-containerd-a5f23ca0d6dc6b21f8bccbd474ec1cf73d39305e27eb38a44f69a93ce180c470.scope
    74       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70381d0c_f1de_4f2c_ad01_23cb90ba8dea.slice/cri-containerd-670033e79be17bbcb9e9137cb1d103cc53b877d8cc55a348a8fe8cd637c1eb34.scope
    86       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d274aef_a66e_492b_a3af_76f4f58f93fa.slice/cri-containerd-668dc845274327a03a973e8e23823d69cc70b65ed48973c385000ab0ca41099d.scope
    648      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d274aef_a66e_492b_a3af_76f4f58f93fa.slice/cri-containerd-616e5ddbf31163a7ff269754d952631e8419bfa212f30ea7de6b4cf68ee3d387.scope
    628      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d274aef_a66e_492b_a3af_76f4f58f93fa.slice/cri-containerd-0c296bd28c8ce0d7a97983063916d4089b34c57cb3f0e2cc358e8a2c1c87a7dc.scope
    652      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d274aef_a66e_492b_a3af_76f4f58f93fa.slice/cri-containerd-e459081ce1fe3f6043ce5ec586d485e0bcfb59f7e774bd97e48a03141cd808bd.scope
    644      cgroup_device   multi                                          
