# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.18.0.0/24, 
Allocated addresses:
  10.18.0.160 (router)
  10.18.0.187 (kube-system/coredns-cc6ccd49c-xghjx)
  10.18.0.205 (kube-system/clustermesh-apiserver-5d768676b9-4r6mj)
  10.18.0.213 (health)
  10.18.0.61 (kube-system/coredns-cc6ccd49c-cpgvv)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8c0197a08e52f457
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    47s ago        never        0       no error   
  ct-map-pressure                                                     19s ago        never        0       no error   
  daemon-validate-config                                              35s ago        never        0       no error   
  dns-garbage-collector-job                                           51s ago        never        0       no error   
  endpoint-2015-regeneration-recovery                                 never          never        0       no error   
  endpoint-2134-regeneration-recovery                                 never          never        0       no error   
  endpoint-2860-regeneration-recovery                                 never          never        0       no error   
  endpoint-458-regeneration-recovery                                  never          never        0       no error   
  endpoint-792-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m51s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                19s ago        never        0       no error   
  ipcache-inject-labels                                               49s ago        never        0       no error   
  k8s-heartbeat                                                       22s ago        never        0       no error   
  link-cache                                                          4s ago         never        0       no error   
  local-identity-checkpoint                                           14m39s ago     never        0       no error   
  node-neighbor-link-updater                                          9s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m1s ago       never        0       no error   
  remote-etcd-cmesh10                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh100                                                5m2s ago       never        0       no error   
  remote-etcd-cmesh101                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh102                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh103                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh104                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh105                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh106                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh107                                                5m2s ago       never        0       no error   
  remote-etcd-cmesh108                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh109                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh11                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh110                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh111                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh112                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh113                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh114                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh115                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh116                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh117                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh118                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh119                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh12                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh120                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh121                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh122                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh123                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh124                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh125                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh126                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh127                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh128                                                5m1s ago       never        0       no error   
  remote-etcd-cmesh13                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh14                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh15                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh16                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh17                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh18                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh2                                                  5m1s ago       never        0       no error   
  remote-etcd-cmesh20                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh21                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh22                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh23                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh24                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh25                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh26                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh27                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh28                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh29                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh3                                                  5m1s ago       never        0       no error   
  remote-etcd-cmesh30                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh31                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh32                                                 5m2s ago       never        0       no error   
  remote-etcd-cmesh33                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh34                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh35                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh36                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh37                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh38                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh39                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh4                                                  5m1s ago       never        0       no error   
  remote-etcd-cmesh40                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh41                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh42                                                 5m2s ago       never        0       no error   
  remote-etcd-cmesh43                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh44                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh45                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh46                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh47                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh48                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh49                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh5                                                  5m1s ago       never        0       no error   
  remote-etcd-cmesh50                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh51                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh52                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh53                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh54                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh55                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh56                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh57                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh58                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh59                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh6                                                  5m1s ago       never        0       no error   
  remote-etcd-cmesh60                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh61                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh62                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh63                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh64                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh65                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh66                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh67                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh68                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh69                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh7                                                  5m1s ago       never        0       no error   
  remote-etcd-cmesh70                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh71                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh72                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh73                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh74                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh75                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh76                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh77                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh78                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh79                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh8                                                  5m1s ago       never        0       no error   
  remote-etcd-cmesh80                                                 5m2s ago       never        0       no error   
  remote-etcd-cmesh81                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh82                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh83                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh84                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh85                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh86                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh87                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh88                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh89                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh9                                                  5m1s ago       never        0       no error   
  remote-etcd-cmesh90                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh91                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh92                                                 5m2s ago       never        0       no error   
  remote-etcd-cmesh93                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh94                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh95                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh96                                                 5m2s ago       never        0       no error   
  remote-etcd-cmesh97                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh98                                                 5m1s ago       never        0       no error   
  remote-etcd-cmesh99                                                 5m1s ago       never        0       no error   
  resolve-identity-2015                                               4m49s ago      never        0       no error   
  resolve-identity-2134                                               4m48s ago      never        0       no error   
  resolve-identity-2860                                               57s ago        never        0       no error   
  resolve-identity-458                                                4m46s ago      never        0       no error   
  resolve-identity-792                                                4m48s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-5d768676b9-4r6mj   5m57s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-cpgvv                  14m46s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-xghjx                  14m48s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m49s ago     never        0       no error   
  sync-policymap-2015                                                 14m48s ago     never        0       no error   
  sync-policymap-2134                                                 14m45s ago     never        0       no error   
  sync-policymap-2860                                                 5m57s ago      never        0       no error   
  sync-policymap-458                                                  14m42s ago     never        0       no error   
  sync-policymap-792                                                  14m42s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (2134)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2860)                                   7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (458)                                    6s ago         never        0       no error   
  sync-utime                                                          49s ago        never        0       no error   
  write-cni-file                                                      14m52s ago     never        0       no error   
Proxy Status:            OK, ip 10.18.0.160, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 1245184, max 1310719
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 64.69   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
enable-ipsec-xfrm-state-caching:true
l2-announcements-lease-duration:15s
endpoint-gc-interval:5m0s
exclude-local-address:
cluster-pool-ipv4-mask-size:24
enable-ipv4-egress-gateway:false
ingress-secrets-namespace:
iptables-random-fully:false
mesh-auth-mutual-listener-port:0
bpf-lb-dsr-l4-xlate:frontend
labels:
identity-change-grace-period:5s
enable-gateway-api:false
enable-mke:false
bpf-node-map-max:16384
ipv4-range:auto
dnsproxy-lock-count:131
enable-pmtu-discovery:false
policy-trigger-interval:1s
egress-multi-home-ip-rule-compat:false
config-sources:config-map:kube-system/cilium-config
bpf-events-drop-enabled:true
tofqdns-pre-cache:
bpf-events-trace-enabled:true
enable-bgp-control-plane:false
hubble-recorder-sink-queue-size:1024
synchronize-k8s-nodes:true
enable-health-check-nodeport:true
metrics:
k8s-client-connection-timeout:30s
l2-announcements-retry-period:2s
srv6-encap-mode:reduced
conntrack-gc-interval:0s
log-opt:
hubble-monitor-events:
cluster-name:cmesh19
http-max-grpc-timeout:0
config:
local-router-ipv6:
bpf-ct-global-any-max:262144
bpf-ct-timeout-regular-tcp-syn:1m0s
exclude-node-label-patterns:
join-cluster:false
bpf-lb-sock-hostns-only:false
bpf-lb-dsr-dispatch:opt
ipam-default-ip-pool:default
unmanaged-pod-watcher-interval:15
cni-chaining-mode:none
hubble-redact-http-urlquery:false
policy-audit-mode:false
pprof-address:localhost
auto-create-cilium-node-resource:true
container-ip-local-reserved-ports:auto
bpf-ct-global-tcp-max:524288
bpf-lb-source-range-map-max:0
mesh-auth-gc-interval:5m0s
http-retry-count:3
bgp-announce-pod-cidr:false
state-dir:/var/run/cilium
disable-endpoint-crd:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
vtep-endpoint:
lib-dir:/var/lib/cilium
bpf-root:/sys/fs/bpf
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-lb-sock-terminate-pod-connections:false
max-connected-clusters:255
enable-svc-source-range-check:true
procfs:/host/proc
set-cilium-node-taints:true
bpf-fragments-map-max:8192
tofqdns-endpoint-max-ip-per-hostname:50
kvstore-lease-ttl:15m0s
bpf-lb-algorithm:random
clustermesh-enable-endpoint-sync:false
bpf-sock-rev-map-max:262144
bpf-policy-map-max:16384
crd-wait-timeout:5m0s
monitor-aggregation:medium
cmdref:
hubble-export-file-compress:false
iptables-lock-timeout:5s
enable-stale-cilium-endpoint-cleanup:true
kvstore-max-consecutive-quorum-errors:2
config-dir:/tmp/cilium/config-map
node-labels:
install-iptables-rules:true
bpf-map-dynamic-size-ratio:0.0025
bpf-lb-mode:snat
vtep-mac:
enable-runtime-device-detection:true
ipv6-node:auto
envoy-base-id:0
clustermesh-config:/var/lib/cilium/clustermesh/
proxy-max-connection-duration-seconds:0
identity-gc-interval:15m0s
envoy-secrets-namespace:
bpf-policy-map-full-reconciliation-interval:15m0s
log-driver:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
ipsec-key-rotation-duration:5m0s
hubble-export-file-max-size-mb:10
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
cilium-endpoint-gc-interval:5m0s
bpf-events-policy-verdict-enabled:true
identity-restore-grace-period:30s
k8s-client-burst:20
bpf-ct-timeout-regular-any:1m0s
k8s-service-proxy-name:
proxy-xff-num-trusted-hops-egress:0
enable-bandwidth-manager:false
set-cilium-is-up-condition:true
clustermesh-sync-timeout:1m0s
hubble-redact-http-userinfo:true
ipv6-service-range:auto
kvstore-connectivity-timeout:2m0s
devices:
ipv4-node:auto
enable-local-node-route:true
encryption-strict-mode-allow-remote-node-identities:false
hubble-redact-http-headers-deny:
encrypt-interface:
enable-ipsec:false
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-map-event-buffers:
read-cni-conf:
api-rate-limit:
proxy-xff-num-trusted-hops-ingress:0
static-cnp-path:
bpf-lb-map-max:65536
enable-wireguard:false
nodeport-addresses:
use-full-tls-context:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
hubble-drop-events-interval:2m0s
proxy-admin-port:0
dnsproxy-lock-timeout:500ms
enable-local-redirect-policy:false
allocator-list-timeout:3m0s
bpf-lb-external-clusterip:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
service-no-backend-response:reject
gateway-api-secrets-namespace:
operator-prometheus-serve-addr::9963
fixed-identity-mapping:
enable-high-scale-ipcache:false
envoy-config-retry-interval:15s
dnsproxy-concurrency-limit:0
cni-chaining-target:
vlan-bpf-bypass:
node-port-algorithm:random
hubble-export-fieldmask:
hubble-skip-unknown-cgroup-ids:true
dns-policy-unload-on-shutdown:false
bpf-filter-priority:1
hubble-export-denylist:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-bpf-clock-probe:false
proxy-idle-timeout-seconds:60
bgp-announce-lb-ip:false
enable-health-checking:true
enable-sctp:false
disable-iptables-feeder-rules:
agent-health-port:9879
agent-liveness-update-interval:1s
proxy-portrange-max:20000
enable-active-connection-tracking:false
tofqdns-proxy-port:0
hubble-event-queue-size:0
max-internal-timer-delay:0s
bpf-lb-rss-ipv4-src-cidr:
enable-k8s-endpoint-slice:true
ipsec-key-file:
version:false
enable-route-mtu-for-cni-chaining:false
tofqdns-proxy-response-max-delay:100ms
label-prefix-file:
ipv6-cluster-alloc-cidr:f00d::/64
k8s-kubeconfig-path:
hubble-redact-kafka-apikey:false
arping-refresh-period:30s
enable-well-known-identities:false
bpf-nat-global-max:524288
envoy-keep-cap-netbindservice:false
bpf-lb-rev-nat-map-max:0
hubble-export-file-path:
ipv4-native-routing-cidr:
enable-policy:default
dnsproxy-socket-linger-timeout:10
enable-host-legacy-routing:false
local-router-ipv4:
monitor-aggregation-interval:5s
enable-bbr:false
auto-direct-node-routes:false
monitor-queue-size:0
trace-sock:true
proxy-portrange-min:10000
bgp-config-path:/var/lib/cilium/bgp/config.yaml
bpf-neigh-global-max:524288
policy-cidr-match-mode:
restore:true
enable-nat46x64-gateway:false
endpoint-bpf-prog-watchdog-interval:30s
ipam-multi-pool-pre-allocation:
bpf-lb-rss-ipv6-src-cidr:
hubble-drop-events:false
bpf-lb-acceleration:disabled
enable-l2-announcements:false
k8s-require-ipv4-pod-cidr:false
enable-ingress-controller:false
policy-queue-size:100
hubble-redact-http-headers-allow:
hubble-drop-events-reasons:auth_required,policy_denied
envoy-config-timeout:2m0s
enable-k8s:true
enable-hubble:true
k8s-service-cache-size:128
direct-routing-skip-unreachable:false
trace-payloadlen:128
egress-gateway-reconciliation-trigger-interval:1s
mesh-auth-spire-admin-socket:
external-envoy-proxy:true
enable-ipv6-big-tcp:false
datapath-mode:veth
ipv4-service-range:auto
endpoint-queue-size:25
policy-accounting:true
identity-heartbeat-timeout:30m0s
enable-tracing:false
derive-masq-ip-addr-from-device:
routing-mode:tunnel
socket-path:/var/run/cilium/cilium.sock
enable-ipv6-ndp:false
enable-wireguard-userspace-fallback:false
mesh-auth-mutual-connect-timeout:5s
nodes-gc-interval:5m0s
enable-endpoint-routes:false
http-retry-timeout:0
bpf-auth-map-max:524288
mesh-auth-enabled:true
clustermesh-ip-identities-sync-timeout:1m0s
hubble-event-buffer-capacity:4095
encryption-strict-mode-cidr:
http-idle-timeout:0
bpf-lb-maglev-table-size:16381
enable-l7-proxy:true
mesh-auth-queue-size:1024
hubble-prefer-ipv6:false
proxy-max-requests-per-connection:0
hubble-metrics-server:
bpf-lb-affinity-map-max:0
k8s-api-server:
node-port-mode:snat
proxy-gid:1337
prepend-iptables-chains:true
use-cilium-internal-ip-for-ipsec:false
direct-routing-device:
cni-external-routing:false
enable-xdp-prefilter:false
node-port-acceleration:disabled
enable-node-selector-labels:false
cluster-id:19
ipv4-pod-subnets:
enable-tcx:true
hubble-export-file-max-backups:5
cluster-pool-ipv4-cidr:10.18.0.0/16
tofqdns-dns-reject-response-code:refused
k8s-namespace:kube-system
disable-envoy-version-check:false
local-max-addr-scope:252
tunnel-port:0
enable-l2-neigh-discovery:true
enable-ipv4:true
log-system-load:false
enable-cilium-api-server-access:
pprof:false
encrypt-node:false
dnsproxy-insecure-skip-transparent-mode-check:false
bpf-ct-timeout-service-tcp:2h13m20s
cflags:
tofqdns-idle-connection-grace-period:0s
route-metric:0
tofqdns-max-deferred-connection-deletes:10000
enable-cilium-endpoint-slice:false
enable-node-port:false
ipam-cilium-node-update-rate:15s
kvstore-periodic-sync:5m0s
conntrack-gc-max-interval:0s
disable-external-ip-mitigation:false
mesh-auth-signal-backoff-duration:1s
mke-cgroup-mount:
enable-l2-pod-announcements:false
mesh-auth-rotated-identities-queue-size:1024
hubble-disable-tls:false
enable-host-firewall:false
enable-hubble-recorder-api:true
tofqdns-enable-dns-compression:true
enable-encryption-strict-mode:false
wireguard-persistent-keepalive:0s
debug:false
allow-localhost:auto
proxy-prometheus-port:0
vtep-mask:
enable-cilium-health-api-server-access:
enable-envoy-config:false
max-controller-interval:0
egress-gateway-policy-map-max:16384
mesh-auth-spiffe-trust-domain:spiffe.cilium
certificates-directory:/var/run/cilium/certs
mtu:0
annotate-k8s-node:false
enable-ipsec-key-watcher:true
enable-custom-calls:false
hubble-export-allowlist:
tunnel-protocol:vxlan
enable-ipv4-fragment-tracking:true
enable-service-topology:false
tofqdns-min-ttl:0
ipv4-service-loopback-address:169.254.42.1
enable-bpf-masquerade:false
enable-xt-socket-fallback:true
enable-k8s-api-discovery:false
ipv6-pod-subnets:
enable-bpf-tproxy:false
enable-health-check-loadbalancer-ip:false
custom-cni-conf:false
kube-proxy-replacement:false
l2-announcements-renew-deadline:5s
monitor-aggregation-flags:all
enable-recorder:false
k8s-client-qps:10
install-no-conntrack-iptables-rules:false
enable-srv6:false
cgroup-root:/run/cilium/cgroupv2
enable-external-ips:false
hubble-metrics:
enable-k8s-terminating-endpoint:true
k8s-sync-timeout:3m0s
enable-auto-protect-node-port-range:true
k8s-client-connection-keep-alive:30s
bpf-lb-service-map-max:0
hubble-flowlogs-config-path:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
prometheus-serve-addr:
cluster-health-port:4240
k8s-require-ipv6-pod-cidr:false
remove-cilium-node-taints:true
enable-session-affinity:false
dns-max-ips-per-restored-rule:1000
identity-allocation-mode:crd
http-request-timeout:3600
bpf-ct-timeout-regular-tcp:2h13m20s
preallocate-bpf-maps:false
enable-metrics:true
keep-config:false
kube-proxy-replacement-healthz-bind-address:
kvstore:
ipam:cluster-pool
gops-port:9890
ipv6-mcast-device:
enable-k8s-networkpolicy:true
multicast-enabled:false
dnsproxy-enable-transparent-mode:true
operator-api-serve-addr:127.0.0.1:9234
dnsproxy-concurrency-processing-grace-period:0s
allow-icmp-frag-needed:true
enable-ip-masq-agent:false
hubble-socket-path:/var/run/cilium/hubble.sock
http-normalize-path:true
nat-map-stats-interval:30s
bpf-ct-timeout-regular-tcp-fin:10s
enable-icmp-rules:true
ipv6-range:auto
cni-log-file:/var/run/cilium/cilium-cni.log
enable-unreachable-routes:false
cni-exclusive:true
enable-identity-mark:true
debug-verbose:
clustermesh-enable-mcs-api:false
node-port-range:
enable-ipv4-big-tcp:false
l2-pod-announcements-interface:
enable-ipv6-masquerade:true
controller-group-metrics:
kvstore-opt:
bpf-lb-service-backend-map-max:0
enable-ipsec-encrypted-overlay:false
bpf-lb-sock:false
enable-endpoint-health-checking:true
node-port-bind-protection:true
enable-masquerade-to-route-source:false
enable-host-port:false
force-device-detection:false
vtep-cidr:
enable-vtep:false
envoy-log:
enable-ipv4-masquerade:true
enable-ipip-termination:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-monitor:true
k8s-heartbeat-timeout:30s
egress-masquerade-interfaces:ens+
hubble-redact-enabled:false
bypass-ip-availability-upon-restore:false
bpf-ct-timeout-service-any:1m0s
hubble-listen-address::4244
bpf-lb-maglev-map-max:0
agent-labels:
enable-ipv6:false
nat-map-stats-entries:32
pprof-port:6060
fqdn-regex-compile-lru-size:1024
proxy-connect-timeout:2
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
ipv6-native-routing-cidr:
```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.223.77:443 (active)    
                                         2 => 172.31.190.71:443 (active)    
2    10.100.238.128:443   ClusterIP      1 => 172.31.161.89:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.18.0.187:53 (active)       
                                         2 => 10.18.0.61:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.18.0.187:9153 (active)     
                                         2 => 10.18.0.61:9153 (active)      
5    10.100.165.14:2379   ClusterIP      1 => 10.18.0.205:2379 (active)     
```

#### Policy get

```
:
 []
Revision: 1

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.18.0.205": (string) (len=50) "kube-system/clustermesh-apiserver-5d768676b9-4r6mj",
  (string) (len=11) "10.18.0.160": (string) (len=6) "router",
  (string) (len=11) "10.18.0.213": (string) (len=6) "health",
  (string) (len=11) "10.18.0.187": (string) (len=35) "kube-system/coredns-cc6ccd49c-xghjx",
  (string) (len=10) "10.18.0.61": (string) (len=35) "kube-system/coredns-cc6ccd49c-cpgvv"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.161.89": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4000741d90)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x400067d9e0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x400067d9e0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x400240af20)(frontends:[10.100.0.10]/ports=[dns-tcp metrics dns]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40030820b0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4003082160)(frontends:[10.100.165.14]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x400240adc0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x400240ae70)(frontends:[10.100.238.128]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001527638)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-8tkrg": (*k8s.Endpoints)(0x4003302d00)(10.18.0.187:53/TCP[eu-west-3a],10.18.0.187:53/UDP[eu-west-3a],10.18.0.187:9153/TCP[eu-west-3a],10.18.0.61:53/TCP[eu-west-3a],10.18.0.61:53/UDP[eu-west-3a],10.18.0.61:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001322938)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-7dcff": (*k8s.Endpoints)(0x4002434340)(10.18.0.205:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001527628)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40012c5520)(172.31.190.71:443/TCP,172.31.223.77:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001527630)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-cp6c2": (*k8s.Endpoints)(0x40012fda00)(172.31.161.89:4244/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40002fc000)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000748c30)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4007bd85e8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002347c20,
  gcExited: (chan struct {}) 0x4002347c80,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x400134f580)({
     ObserverVec: (*prometheus.HistogramVec)(0x400180a810)({
      MetricVec: (*prometheus.MetricVec)(0x4000ee6780)({
       metricMap: (*prometheus.metricMap)(0x4000ee67b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018c2000)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x400134f600)({
     ObserverVec: (*prometheus.HistogramVec)(0x400180a818)({
      MetricVec: (*prometheus.MetricVec)(0x4000ee6810)({
       metricMap: (*prometheus.metricMap)(0x4000ee6840)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018c2060)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x400134f680)({
     GaugeVec: (*prometheus.GaugeVec)(0x400180a820)({
      MetricVec: (*prometheus.MetricVec)(0x4000ee68a0)({
       metricMap: (*prometheus.metricMap)(0x4000ee68d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018c20c0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x400134f700)({
     GaugeVec: (*prometheus.GaugeVec)(0x400180a828)({
      MetricVec: (*prometheus.MetricVec)(0x4000ee6930)({
       metricMap: (*prometheus.metricMap)(0x4000ee6960)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018c2120)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x400134f780)({
     GaugeVec: (*prometheus.GaugeVec)(0x400180a830)({
      MetricVec: (*prometheus.MetricVec)(0x4000ee69c0)({
       metricMap: (*prometheus.metricMap)(0x4000ee69f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018c2180)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x400134f800)({
     GaugeVec: (*prometheus.GaugeVec)(0x400180a838)({
      MetricVec: (*prometheus.MetricVec)(0x4000ee6a50)({
       metricMap: (*prometheus.metricMap)(0x4000ee6a80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018c21e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x400134f880)({
     GaugeVec: (*prometheus.GaugeVec)(0x400180a840)({
      MetricVec: (*prometheus.MetricVec)(0x4000ee6ae0)({
       metricMap: (*prometheus.metricMap)(0x4000ee6b10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018c2240)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x400134f900)({
     GaugeVec: (*prometheus.GaugeVec)(0x400180a848)({
      MetricVec: (*prometheus.MetricVec)(0x4000ee6b70)({
       metricMap: (*prometheus.metricMap)(0x4000ee6ba0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018c22a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x400134f980)({
     ObserverVec: (*prometheus.HistogramVec)(0x400180a850)({
      MetricVec: (*prometheus.MetricVec)(0x4000ee6c00)({
       metricMap: (*prometheus.metricMap)(0x4000ee6c30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018c2300)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40002fc000)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40002fd570)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4000147218)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 393ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   },
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium encryption



#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
458        Disabled           Disabled          1282951    k8s:eks.amazonaws.com/component=coredns                                             10.18.0.61    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh19                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
792        Disabled           Disabled          4          reserved:health                                                                     10.18.0.213   ready   
2015       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
2134       Disabled           Disabled          1282951    k8s:eks.amazonaws.com/component=coredns                                             10.18.0.187   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh19                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2860       Disabled           Disabled          1252286    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.18.0.205   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh19                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
```

#### BPF Policy Get 458

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83146   958       0        
Allow    Egress      0          ANY          NONE         disabled    14029   146       0        

```


#### BPF CT List 458

```
Invalid argument: unknown type 458
```


#### Endpoint Get 458

```
[
  {
    "id": 458,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-458-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "af7cedc5-8e1d-49bd-8dfb-cef878575076"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-458",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:27.221Z",
            "success-count": 3
          },
          "uuid": "1e28cf56-fe41-4b23-9b10-d3f906bce126"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-cpgvv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:27.220Z",
            "success-count": 1
          },
          "uuid": "d8da37b4-7e22-4e9f-8602-3a69032ab844"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-458",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:31.261Z",
            "success-count": 1
          },
          "uuid": "1a34859a-9e55-4b7c-a7a1-5739dd5da53a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (458)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:07.291Z",
            "success-count": 90
          },
          "uuid": "d3f064d3-b150-4e61-b422-fc45cfaeddce"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "41e5d76a31ce15bd70907d488b3ce9cbf59a815f3ca615b90e4ac50aa8387692:eth0",
        "container-id": "41e5d76a31ce15bd70907d488b3ce9cbf59a815f3ca615b90e4ac50aa8387692",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-cpgvv",
        "pod-name": "kube-system/coredns-cc6ccd49c-cpgvv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1282951,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh19",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh19",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:13Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.18.0.61",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "7a:f3:a6:96:76:d9",
        "interface-index": 11,
        "interface-name": "lxccaac667841dc",
        "mac": "02:4b:e9:3f:f8:28"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1282951,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1282951,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 458

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 458

```
Timestamp              Status   State                   Message
2024-10-25T10:24:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:13Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:24:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:30Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:27Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1282951

```
ID        LABELS
1282951   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh19
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 792

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    437870   5601      0        
Allow    Ingress     1          ANY          NONE         disabled    11620    134       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 792

```
Invalid argument: unknown type 792
```


#### Endpoint Get 792

```
[
  {
    "id": 792,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-792-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "cc59359a-353e-4ede-ac78-bddac0eb1767"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-792",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:25.447Z",
            "success-count": 3
          },
          "uuid": "b1935012-3d98-4f56-83fb-954781597963"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-792",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:31.268Z",
            "success-count": 1
          },
          "uuid": "fac03c68-7cc7-4d5a-bc7c-beba78ba303c"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:13Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.18.0.213",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ce:1b:6f:85:d6:21",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "f2:1e:ca:52:48:a5"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 792

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 792

```
Timestamp              Status   State                   Message
2024-10-25T10:24:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:13Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:24:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:25Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:24Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2015

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2015

```
Invalid argument: unknown type 2015
```


#### Endpoint Get 2015

```
[
  {
    "id": 2015,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2015-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "eda16891-b099-466e-9f86-300f40dc1378"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2015",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:24.366Z",
            "success-count": 3
          },
          "uuid": "39d33b43-de25-4b06-98aa-8c2fd861269d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2015",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:25.530Z",
            "success-count": 1
          },
          "uuid": "c8d69279-bd45-4c21-9db6-f41e001755bd"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:13Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "32:34:0c:3f:46:05",
        "interface-name": "cilium_host",
        "mac": "32:34:0c:3f:46:05"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2015

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2015

```
Timestamp              Status   State                   Message
2024-10-25T10:24:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:13Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:24:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:30Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:24Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:24Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2134

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85532   988       0        
Allow    Egress      0          ANY          NONE         disabled    12766   133       0        

```


#### BPF CT List 2134

```
Invalid argument: unknown type 2134
```


#### Endpoint Get 2134

```
[
  {
    "id": 2134,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2134-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "22e8b5a0-8151-4b7f-aa35-41cb08d02a3d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2134",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:25.191Z",
            "success-count": 3
          },
          "uuid": "774f39b0-891f-43e4-8df8-1bb1626055e4"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-xghjx",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:25.189Z",
            "success-count": 1
          },
          "uuid": "c7821fb6-0448-4247-b1fe-5409c2d80831"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2134",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:27.635Z",
            "success-count": 1
          },
          "uuid": "e2dd9959-8284-4762-851d-0af2e179004b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2134)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.270Z",
            "success-count": 90
          },
          "uuid": "d4234524-1c63-4e57-8369-80cf872fd015"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fe4eb0fe123d09bf5599dd1937ca00648edb3533eedd876cad02fd9ba8023853:eth0",
        "container-id": "fe4eb0fe123d09bf5599dd1937ca00648edb3533eedd876cad02fd9ba8023853",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-xghjx",
        "pod-name": "kube-system/coredns-cc6ccd49c-xghjx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1282951,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh19",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh19",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:13Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.18.0.187",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "aa:13:45:7e:72:e4",
        "interface-index": 9,
        "interface-name": "lxc115e46717728",
        "mac": "fa:28:f5:fa:0f:02"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1282951,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1282951,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2134

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2134

```
Timestamp              Status   State                   Message
2024-10-25T10:24:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:13Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:24:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:25Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:25Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1282951

```
ID        LABELS
1282951   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh19
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2860

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3823587   34859     0        
Allow    Ingress     1          ANY          NONE         disabled    2532389   25006     0        
Allow    Egress      0          ANY          NONE         disabled    3474409   32603     0        

```


#### BPF CT List 2860

```
Invalid argument: unknown type 2860
```


#### Endpoint Get 2860

```
[
  {
    "id": 2860,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2860-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "99fb9965-bbc7-465d-9f79-58c8b6acfe9b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2860",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:15.670Z",
            "success-count": 2
          },
          "uuid": "52948b54-33f6-4dbc-9e5a-966d520a1ef9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-5d768676b9-4r6mj",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:15.669Z",
            "success-count": 1
          },
          "uuid": "11030288-cb41-4554-a10a-9a946add52c9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2860",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:15.706Z",
            "success-count": 1
          },
          "uuid": "e4d68d41-755b-4513-9ab5-645832be9e7c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2860)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.708Z",
            "success-count": 37
          },
          "uuid": "9eef6449-2147-45c9-9ff1-3090bd8e7792"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "616e5ddbf31163a7ff269754d952631e8419bfa212f30ea7de6b4cf68ee3d387:eth0",
        "container-id": "616e5ddbf31163a7ff269754d952631e8419bfa212f30ea7de6b4cf68ee3d387",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-5d768676b9-4r6mj",
        "pod-name": "kube-system/clustermesh-apiserver-5d768676b9-4r6mj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1252286,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh19",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=5d768676b9"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh19",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:13Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.18.0.205",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1e:95:85:aa:e2:c0",
        "interface-index": 15,
        "interface-name": "lxce9094c6adc0b",
        "mac": "22:e6:2e:49:b0:ae"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1252286,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1252286,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2860

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2860

```
Timestamp              Status   State                   Message
2024-10-25T10:24:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:13Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:24:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:23:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:15Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:23:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:23:15Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:23:15Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1252286

```
ID        LABELS
1252286   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh19
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37784370                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37784370                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37784370                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d000000 rw-p 00000000 00:00 0 
400d000000-4010000000 ---p 00000000 00:00 0 
ffff6a4aa000-ffff6a6f0000 rw-p 00000000 00:00 0 
ffff6a6f8000-ffff6a7d9000 rw-p 00000000 00:00 0 
ffff6a7d9000-ffff6a81a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6a81a000-ffff6a85b000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6a85b000-ffff6a89b000 rw-p 00000000 00:00 0 
ffff6a89b000-ffff6a89d000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6a89d000-ffff6a89f000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6a89f000-ffff6ae46000 rw-p 00000000 00:00 0 
ffff6ae46000-ffff6af46000 rw-p 00000000 00:00 0 
ffff6af46000-ffff6af57000 rw-p 00000000 00:00 0 
ffff6af57000-ffff6cf57000 rw-p 00000000 00:00 0 
ffff6cf57000-ffff6cfd7000 ---p 00000000 00:00 0 
ffff6cfd7000-ffff6cfd8000 rw-p 00000000 00:00 0 
ffff6cfd8000-ffff8cfd7000 ---p 00000000 00:00 0 
ffff8cfd7000-ffff8cfd8000 rw-p 00000000 00:00 0 
ffff8cfd8000-ffffacf67000 ---p 00000000 00:00 0 
ffffacf67000-ffffacf68000 rw-p 00000000 00:00 0 
ffffacf68000-ffffb0f59000 ---p 00000000 00:00 0 
ffffb0f59000-ffffb0f5a000 rw-p 00000000 00:00 0 
ffffb0f5a000-ffffb1757000 ---p 00000000 00:00 0 
ffffb1757000-ffffb1758000 rw-p 00000000 00:00 0 
ffffb1758000-ffffb1857000 ---p 00000000 00:00 0 
ffffb1857000-ffffb18b7000 rw-p 00000000 00:00 0 
ffffb18b7000-ffffb18b9000 r--p 00000000 00:00 0                          [vvar]
ffffb18b9000-ffffb18ba000 r-xp 00000000 00:00 0                          [vdso]
fffffa39e000-fffffa3bf000 rw-p 00000000 00:00 0                          [stack]

```

