Endpoint ID: 458
Path: /sys/fs/bpf/tc/globals/cilium_policy_00458

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83146   958       0        
Allow    Egress      0          ANY          NONE         disabled    14029   146       0        


Endpoint ID: 792
Path: /sys/fs/bpf/tc/globals/cilium_policy_00792

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    440880   5639      0        
Allow    Ingress     1          ANY          NONE         disabled    11620    134       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2015
Path: /sys/fs/bpf/tc/globals/cilium_policy_02015

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2134
Path: /sys/fs/bpf/tc/globals/cilium_policy_02134

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85532   988       0        
Allow    Egress      0          ANY          NONE         disabled    12766   133       0        


Endpoint ID: 2860
Path: /sys/fs/bpf/tc/globals/cilium_policy_02860

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3823587   34859     0        
Allow    Ingress     1          ANY          NONE         disabled    2532389   25006     0        
Allow    Egress      0          ANY          NONE         disabled    3474843   32608     0        


