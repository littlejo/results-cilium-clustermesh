32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
71: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
74: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
78: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
79: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
82: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
83: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
86: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
114: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
117: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
469: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
472: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
473: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 127
474: sched_cls  name tail_handle_ipv4  tag 6ce05e6718179b23  gpl
	loaded_at 2024-10-25T10:14:28+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,97
	btf_id 128
475: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:28+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,97
	btf_id 129
476: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:28+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 130
477: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
480: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
502: sched_cls  name tail_ipv4_ct_egress  tag 3a07d51eec795bb0  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,110,78,79,109,80
	btf_id 159
505: sched_cls  name tail_handle_ipv4_cont  tag 185782db51434320  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,109,37,106,78,79,35,72,70,73,110,36,33,34,77
	btf_id 160
506: sched_cls  name cil_from_container  tag 55435d6bf8ca93fb  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,72
	btf_id 163
509: sched_cls  name tail_ipv4_to_endpoint  tag 93a20167fd2a7023  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,109,37,78,79,76,106,35,110,36,33,34
	btf_id 164
511: sched_cls  name tail_ipv4_ct_ingress  tag 265af11e2fba0d56  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,110,78,79,109,80
	btf_id 167
515: sched_cls  name handle_policy  tag 62a250ff93973b7e  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,110,78,79,109,37,76,106,35,80,71,36,33,34
	btf_id 170
518: sched_cls  name tail_handle_ipv4  tag 5011827f1c61c972  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,110
	btf_id 173
519: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,110
	btf_id 176
520: sched_cls  name tail_handle_arp  tag 61937156ba7a35b8  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,110
	btf_id 177
521: sched_cls  name __send_drop_notify  tag 44b9ba88926c0858  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 178
524: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 181
525: sched_cls  name tail_handle_ipv4_from_host  tag b684912cf4fee223  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,111
	btf_id 182
527: sched_cls  name __send_drop_notify  tag 406da74f7f044cc7  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 184
529: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,111
	btf_id 187
530: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,111
	btf_id 189
531: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,114
	btf_id 188
534: sched_cls  name __send_drop_notify  tag 406da74f7f044cc7  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 193
537: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,115
	btf_id 196
538: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 197
539: sched_cls  name tail_handle_ipv4_from_host  tag b684912cf4fee223  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,115
	btf_id 199
540: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,118
	btf_id 201
541: sched_cls  name tail_ipv4_ct_egress  tag 3a07d51eec795bb0  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,114,78,79,113,80
	btf_id 198
543: sched_cls  name tail_handle_ipv4_from_host  tag b684912cf4fee223  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,118
	btf_id 203
545: sched_cls  name __send_drop_notify  tag 406da74f7f044cc7  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 205
546: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,118,71
	btf_id 206
548: sched_cls  name tail_handle_ipv4_cont  tag 4bfb81b17d85e39a  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,113,37,87,78,79,35,72,70,73,114,36,33,34,77
	btf_id 208
549: sched_cls  name tail_handle_arp  tag 8e4675822da81bde  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,120
	btf_id 211
550: sched_cls  name tail_ipv4_to_endpoint  tag b5079f82e20adee0  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,113,37,78,79,76,87,35,114,36,33,34
	btf_id 209
551: sched_cls  name tail_ipv4_ct_ingress  tag 17be7fb6159103fe  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,114,78,79,113,80
	btf_id 212
552: sched_cls  name handle_policy  tag 08097d667975bad4  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,120,78,79,119,37,76,98,35,80,71,36,33,34
	btf_id 213
553: sched_cls  name __send_drop_notify  tag 293fe12171cc0af1  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 214
554: sched_cls  name tail_ipv4_to_endpoint  tag 127c0a72a1f19694  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,119,37,78,79,76,98,35,120,36,33,34
	btf_id 215
555: sched_cls  name tail_handle_ipv4  tag 196313afa50d5cf8  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,114
	btf_id 216
556: sched_cls  name tail_handle_ipv4  tag bc5b895c2b09745a  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,120
	btf_id 217
557: sched_cls  name cil_from_container  tag 6d2d058632c35ff5  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 120,72
	btf_id 219
558: sched_cls  name __send_drop_notify  tag 5ac2c7a3cec305ac  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 220
559: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,120,78,79,119,80
	btf_id 221
560: sched_cls  name tail_ipv4_ct_ingress  tag 301bfe616856d5c2  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,120,78,79,119,80
	btf_id 222
561: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,120
	btf_id 223
563: sched_cls  name handle_policy  tag 90544e52421438bb  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,114,78,79,113,37,76,87,35,80,71,36,33,34
	btf_id 218
564: sched_cls  name tail_handle_arp  tag ea1ebdb34cfd615d  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,114
	btf_id 226
565: sched_cls  name tail_handle_ipv4_cont  tag a772fa852120639d  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,119,37,98,78,79,35,72,70,73,120,36,33,34,77
	btf_id 225
566: sched_cls  name cil_from_container  tag 4052efa0bafee783  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,72
	btf_id 227
567: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
570: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
571: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
574: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
614: sched_cls  name tail_ipv4_ct_ingress  tag 8e9d0be67061c97a  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,135,78,79,134,80
	btf_id 241
615: sched_cls  name tail_ipv4_ct_egress  tag 5f7bd8634466d601  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,135,78,79,134,80
	btf_id 242
616: sched_cls  name __send_drop_notify  tag b4718c10fcc05156  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 243
617: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,135
	btf_id 244
618: sched_cls  name handle_policy  tag a8088a4b805ee0a9  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,135,78,79,134,37,76,133,35,80,71,36,33,34
	btf_id 245
619: sched_cls  name tail_ipv4_to_endpoint  tag a33e41739ec3cb30  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,134,37,78,79,76,133,35,135,36,33,34
	btf_id 246
620: sched_cls  name tail_handle_arp  tag 3f70f58319eba903  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,135
	btf_id 247
622: sched_cls  name cil_from_container  tag cf596de7e69657ef  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,72
	btf_id 249
623: sched_cls  name tail_handle_ipv4_cont  tag 2424324d2a80ef17  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,134,37,133,78,79,35,72,70,73,135,36,33,34,77
	btf_id 250
624: sched_cls  name tail_handle_ipv4  tag 6167128be60c3c24  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,135
	btf_id 251
625: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
628: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
641: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
644: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
645: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
648: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
649: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
652: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
