key: 01 00 00 00  value: ac 1f 90 93 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 50 00 48 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 50 00 8f 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 50 00 5d 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: ac 1f de 7e 01 bb 00 00  00 00 00 00
key: 04 00 00 00  value: ac 1f 85 33 10 94 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 50 00 8f 00 35 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 50 00 5d 23 c1 00 00  00 00 00 00
Found 8 elements
