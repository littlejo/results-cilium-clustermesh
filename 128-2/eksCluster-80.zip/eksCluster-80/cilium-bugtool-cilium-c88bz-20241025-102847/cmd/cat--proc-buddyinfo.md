Node 0, zone      DMA    101     35      6      4     24    113     50     17      3      5    165 
Node 0, zone   Normal    148     45     43      0     18      6      8      3      5      3      6 
