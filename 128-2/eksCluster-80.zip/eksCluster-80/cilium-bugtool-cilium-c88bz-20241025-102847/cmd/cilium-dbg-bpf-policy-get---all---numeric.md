Endpoint ID: 70
Path: /sys/fs/bpf/tc/globals/cilium_policy_00070

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 133
Path: /sys/fs/bpf/tc/globals/cilium_policy_00133

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83760   962       0        
Allow    Egress      0          ANY          NONE         disabled    13044   136       0        


Endpoint ID: 281
Path: /sys/fs/bpf/tc/globals/cilium_policy_00281

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3903742   35738     0        
Allow    Ingress     1          ANY          NONE         disabled    2569007   25289     0        
Allow    Egress      0          ANY          NONE         disabled    3508317   33067     0        


Endpoint ID: 1228
Path: /sys/fs/bpf/tc/globals/cilium_policy_01228

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85093   976       0        
Allow    Egress      0          ANY          NONE         disabled    14214   150       0        


Endpoint ID: 1359
Path: /sys/fs/bpf/tc/globals/cilium_policy_01359

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    445192   5704      0        
Allow    Ingress     1          ANY          NONE         disabled    12358    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


