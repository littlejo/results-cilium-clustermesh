35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
71: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
74: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
78: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
79: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
82: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
125: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
128: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
469: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 39
	btf_id 115
470: sched_cls  name tail_handle_ipv4  tag 01e052d97d183db1  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 73,72,79,74,95
	btf_id 116
471: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 74,95
	btf_id 117
472: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 118
473: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 74,73,97
	btf_id 120
474: sched_cls  name tail_handle_ipv4_from_host  tag ba3b8bdb8b4ad855  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 72,73,74,75,39,79,97
	btf_id 121
475: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 74,97
	btf_id 122
478: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 74
	btf_id 125
479: sched_cls  name __send_drop_notify  tag de8f4cf2235c0daa  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 39
	btf_id 126
481: sched_cls  name tail_handle_ipv4_from_host  tag ba3b8bdb8b4ad855  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 72,73,74,75,39,79,99
	btf_id 129
482: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 74,99
	btf_id 130
485: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 74
	btf_id 133
486: sched_cls  name __send_drop_notify  tag de8f4cf2235c0daa  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 39
	btf_id 134
487: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 74,101,73
	btf_id 136
490: sched_cls  name __send_drop_notify  tag de8f4cf2235c0daa  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 39
	btf_id 139
492: sched_cls  name tail_handle_ipv4_from_host  tag ba3b8bdb8b4ad855  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 72,73,74,75,39,79,101
	btf_id 141
493: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 74,101
	btf_id 142
497: sched_cls  name tail_ipv4_ct_egress  tag 109a4115286dee22  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 74,107,80,81,106,82
	btf_id 148
498: sched_cls  name tail_handle_ipv4_cont  tag 71fbbe0276864299  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 73,106,39,103,80,81,37,74,72,75,107,38,35,36,79
	btf_id 150
501: sched_cls  name tail_ipv4_ct_ingress  tag a0bdfd0415f17b52  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 74,107,80,81,106,82
	btf_id 151
504: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 74,107
	btf_id 153
507: sched_cls  name handle_policy  tag 2bb803718adf22b5  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 74,107,80,81,106,39,78,103,37,82,73,38,35,36
	btf_id 157
510: sched_cls  name tail_handle_ipv4  tag 89a9b8f7941f3881  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 82,74,76,80,81,77,37,107
	btf_id 160
511: sched_cls  name __send_drop_notify  tag e88592f9af5bfecc  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 39
	btf_id 163
513: sched_cls  name cil_from_container  tag d1df45a2f6a3535b  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 109,74
	btf_id 166
514: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 74,109,80,81,108,82
	btf_id 167
515: sched_cls  name tail_ipv4_to_endpoint  tag 16c7b7949d80879e  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 73,74,106,39,80,81,78,103,37,107,38,35,36
	btf_id 164
516: sched_cls  name cil_from_container  tag d61311a27543bb66  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,74
	btf_id 169
517: sched_cls  name tail_handle_arp  tag 7fd4f63e9aeffa60  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 74,107
	btf_id 170
518: sched_cls  name tail_ipv4_to_endpoint  tag 6c1692b2021fcd13  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 73,74,108,39,80,81,78,96,37,109,38,35,36
	btf_id 168
519: sched_cls  name tail_handle_ipv4  tag adbcd03197219b3c  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 82,74,76,80,81,77,37,109
	btf_id 171
520: sched_cls  name tail_ipv4_ct_ingress  tag 8988e48fc201d7af  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 74,109,80,81,108,82
	btf_id 172
521: sched_cls  name tail_handle_arp  tag e7f9aee37f47c363  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 74,109
	btf_id 173
522: sched_cls  name tail_handle_ipv4_cont  tag 79eb07df065be5d5  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 73,108,39,96,80,81,37,74,72,75,109,38,35,36,79
	btf_id 174
524: sched_cls  name __send_drop_notify  tag 0e94b4ec255a9b74  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 39
	btf_id 176
525: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 74,109
	btf_id 177
526: sched_cls  name handle_policy  tag fcb7e65f62048c55  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 74,109,80,81,108,39,78,96,37,82,73,38,35,36
	btf_id 178
527: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
530: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: sched_cls  name cil_from_container  tag e99289501f5ccba3  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,74
	btf_id 181
536: sched_cls  name handle_policy  tag d706b84ce5a408e2  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 74,113,80,81,114,39,78,112,37,82,73,38,35,36
	btf_id 182
537: sched_cls  name tail_ipv4_to_endpoint  tag 245e4d542e4d30aa  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 73,74,114,39,80,81,78,112,37,113,38,35,36
	btf_id 183
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 74,113
	btf_id 184
539: sched_cls  name tail_ipv4_ct_ingress  tag 15c8388f6d6e0a80  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 74,113,80,81,114,82
	btf_id 185
540: sched_cls  name __send_drop_notify  tag cd72292a8b8bfc34  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 39
	btf_id 186
541: sched_cls  name tail_handle_arp  tag c1ae2d6249ffda15  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 74,113
	btf_id 187
542: sched_cls  name tail_handle_ipv4_cont  tag 3bd5eb1b7e257099  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 73,114,39,112,80,81,37,74,72,75,113,38,35,36,79
	btf_id 188
543: sched_cls  name tail_handle_ipv4  tag e2fa8a48109848aa  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 82,74,76,80,81,77,37,113
	btf_id 189
544: sched_cls  name tail_ipv4_ct_egress  tag 109a4115286dee22  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 74,113,80,81,114,82
	btf_id 190
546: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
550: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
553: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: sched_cls  name tail_ipv4_ct_egress  tag 76c56fc0d4500c28  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 74,129,80,81,128,82
	btf_id 205
594: sched_cls  name handle_policy  tag def7aa8046183e33  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 74,129,80,81,128,39,78,127,37,82,73,38,35,36
	btf_id 206
595: sched_cls  name __send_drop_notify  tag 42e28a94c0ed4b2b  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 39
	btf_id 207
596: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 74,129
	btf_id 208
597: sched_cls  name tail_handle_ipv4  tag 41e8e517d7c627f8  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 82,74,76,80,81,77,37,129
	btf_id 209
598: sched_cls  name tail_handle_arp  tag d8153674c1d4a36a  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 74,129
	btf_id 210
599: sched_cls  name tail_ipv4_ct_ingress  tag 3c66fb9dfd18edbb  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 74,129,80,81,128,82
	btf_id 211
600: sched_cls  name cil_from_container  tag 0540f2dfc507d257  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,74
	btf_id 212
601: sched_cls  name tail_ipv4_to_endpoint  tag b7593b8cf7d1c789  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 73,74,128,39,80,81,78,127,37,129,38,35,36
	btf_id 213
602: sched_cls  name tail_handle_ipv4_cont  tag 6602f69f4c6240ec  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 73,128,39,127,80,81,37,74,72,75,129,38,35,36,79
	btf_id 214
604: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
607: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
628: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
631: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
