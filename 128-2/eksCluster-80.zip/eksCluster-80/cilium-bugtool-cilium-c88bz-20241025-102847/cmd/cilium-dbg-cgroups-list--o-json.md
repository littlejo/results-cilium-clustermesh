[
  {
    "containers": [
      {
        "cgroup-id": 7283,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac39d2b2_a1f5_44f9_982f_e46eb8c783b7.slice/cri-containerd-26e22787ee8630f6907ae0302978583bd41fe44120bc97a71c26c77ab425ce41.scope"
      }
    ],
    "ips": [
      "10.80.0.143"
    ],
    "name": "coredns-cc6ccd49c-f8lhs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode203b028_fdc2_4ca4_91ed_5de656bfcb45.slice/cri-containerd-1e3af51f7b1e7c567d3b4204d48fc73c25791e2d6f9e79add87b722d8777fd0b.scope"
      }
    ],
    "ips": [
      "10.80.0.93"
    ],
    "name": "coredns-cc6ccd49c-gbhr2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8963,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53e4c45b_5147_48a1_af53_c43de1103f6d.slice/cri-containerd-413a7c6671e4fd3920162797f450058ee8584ba5f570e11f685fc087ad7f3a13.scope"
      },
      {
        "cgroup-id": 8879,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53e4c45b_5147_48a1_af53_c43de1103f6d.slice/cri-containerd-c1b174c7f940b4df47073fc760129c4d6836484a85cc64cc4980d971f9664ba3.scope"
      },
      {
        "cgroup-id": 9047,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53e4c45b_5147_48a1_af53_c43de1103f6d.slice/cri-containerd-c1e72f77ee5169c720c897dfe5f007bb1c4d18c45f4afdeed11ca2bdd330d2aa.scope"
      }
    ],
    "ips": [
      "10.80.0.72"
    ],
    "name": "clustermesh-apiserver-5f876cfc56-c94xr",
    "namespace": "kube-system"
  }
]

