REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     204086    83304237   1132   bpf_host.c
Interface                 INGRESS     8812      686864     677    bpf_overlay.c
Success                   EGRESS      3775      287074     1694   bpf_host.c
Success                   EGRESS      8164      641296     53     encap.h
Success                   EGRESS      85897     11837107   1308   bpf_lxc.c
Success                   INGRESS     101184    12089151   235    trace.h
Success                   INGRESS     95498     11645455   86     l3.h
Unsupported L3 protocol   EGRESS      42        3188       1492   bpf_lxc.c
