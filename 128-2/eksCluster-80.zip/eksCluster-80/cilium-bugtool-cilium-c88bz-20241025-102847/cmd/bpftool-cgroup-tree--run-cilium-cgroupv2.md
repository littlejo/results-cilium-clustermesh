CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac39d2b2_a1f5_44f9_982f_e46eb8c783b7.slice/cri-containerd-af2f705c782ae78028ea2cb40c7da3da1a0f486e1b5afdce8c7620e1c862da6d.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac39d2b2_a1f5_44f9_982f_e46eb8c783b7.slice/cri-containerd-26e22787ee8630f6907ae0302978583bd41fe44120bc97a71c26c77ab425ce41.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode203b028_fdc2_4ca4_91ed_5de656bfcb45.slice/cri-containerd-1e3af51f7b1e7c567d3b4204d48fc73c25791e2d6f9e79add87b722d8777fd0b.scope
    553      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode203b028_fdc2_4ca4_91ed_5de656bfcb45.slice/cri-containerd-d38e83c924c62fb2dd3eeaa14c59c27e2446f364ef2a5b0ddd9afabafa52446e.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9183e67c_22bb_45bc_ac48_f2ae0eb1b37f.slice/cri-containerd-5122e4ff43bd19f47d8fea9e90330a1ac4f86c183ac4130ff3d0f6683c3e98fa.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9183e67c_22bb_45bc_ac48_f2ae0eb1b37f.slice/cri-containerd-fc88f607e2dcf65de394c828c96e4a32685ac2ded30d9637a5aef44fc6938c5d.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde950275_a75e_48d7_994b_8e50eed52215.slice/cri-containerd-ba2fee8d209b1e4987e47c547800005cb5c5a13d2ae5544cf54ae5ea931e8aa8.scope
    128      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde950275_a75e_48d7_994b_8e50eed52215.slice/cri-containerd-e874dfdb37dfab2b34d3a219b42832d80b6a58cc925270993f1a6c25734f6872.scope
    74       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79951334_4da6_4893_9e49_34d6eb88d08b.slice/cri-containerd-354124bf427b3b0390c327306fe9ae16c7daeecb87091af227b83aabb8275bed.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79951334_4da6_4893_9e49_34d6eb88d08b.slice/cri-containerd-96ff7d33d03fa7d659304a546d14fb13f521e90101f1029e0043dc9bdcaf7645.scope
    82       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53e4c45b_5147_48a1_af53_c43de1103f6d.slice/cri-containerd-413a7c6671e4fd3920162797f450058ee8584ba5f570e11f685fc087ad7f3a13.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53e4c45b_5147_48a1_af53_c43de1103f6d.slice/cri-containerd-c1e72f77ee5169c720c897dfe5f007bb1c4d18c45f4afdeed11ca2bdd330d2aa.scope
    631      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53e4c45b_5147_48a1_af53_c43de1103f6d.slice/cri-containerd-c1b174c7f940b4df47073fc760129c4d6836484a85cc64cc4980d971f9664ba3.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53e4c45b_5147_48a1_af53_c43de1103f6d.slice/cri-containerd-2fd1f5dbe344476104a8b69ad5fa2c0c7cbcbfe5f5317f992587ea80b60149df.scope
    607      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeed0fca1_e4af_42e3_b107_9823cbf37ba8.slice/cri-containerd-88a6503ad585a6fe992cfbf585257cd762ca22b6e7aab4df3351c0e85230b2db.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeed0fca1_e4af_42e3_b107_9823cbf37ba8.slice/cri-containerd-f9f67c4da9c99b7da31a582daa2d13b88166e9363a3bbae395b7c04a679d646f.scope
    78       cgroup_device   multi                                          
