fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcf396a6a62f58 proto kernel metric 256 pref medium
fe80::/64 dev lxc73cf4b7aebca proto kernel metric 256 pref medium
fe80::/64 dev lxccf8266c89fa3 proto kernel metric 256 pref medium
