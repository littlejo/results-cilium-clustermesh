alloc: 67.71MB (71000440 bytes)
total-alloc: 1.30GB (1394231560 bytes)
sys: 202.07MB (211884356 bytes)
lookups: 0
mallocs: 47186521
frees: 46698782
heap-alloc: 67.71MB (71000440 bytes)
heap-sys: 159.45MB (167190528 bytes)
heap-idle: 52.26MB (54796288 bytes)
heap-in-use: 107.19MB (112394240 bytes)
heap-released: 2.69MB (2818048 bytes)
heap-objects: 487739
stack-in-use: 32.53MB (34111488 bytes)
stack-sys: 32.53MB (34111488 bytes)
stack-mspan-inuse: 1.82MB (1904640 bytes)
stack-mspan-sys: 2.38MB (2496960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 735.09KB (752729 bytes)
gc-sys: 5.07MB (5319896 bytes)
next-gc: when heap-alloc >= 145.46MB (152522040 bytes)
last-gc: 2024-10-25 10:29:19.038998533 +0000 UTC
gc-pause-total: 11.878363ms
gc-pause: 68874
gc-pause-end: 1729852159038998533
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003056137770215925
enable-gc: true
debug-gc: false
