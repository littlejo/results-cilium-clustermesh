key: 85 00 00 00  value: 18 02 00 00
key: 19 01 00 00  value: 52 02 00 00
key: cc 04 00 00  value: fb 01 00 00
key: 4f 05 00 00  value: 0e 02 00 00
Found 4 elements
