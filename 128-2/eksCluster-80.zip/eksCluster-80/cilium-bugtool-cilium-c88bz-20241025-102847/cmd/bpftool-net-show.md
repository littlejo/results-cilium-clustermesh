xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 487
cilium_net(4) clsact/ingress cil_to_host-cilium_net id 485
cilium_host(5) clsact/ingress cil_to_host-cilium_host id 478
cilium_host(5) clsact/egress cil_from_host-cilium_host id 473
cilium_vxlan(6) clsact/ingress cil_from_overlay-cilium_vxlan id 471
cilium_vxlan(6) clsact/egress cil_to_overlay-cilium_vxlan id 472
lxc_health(8) clsact/ingress cil_from_container-lxc_health id 513
lxcf396a6a62f58(10) clsact/ingress cil_from_container-lxcf396a6a62f58 id 516
lxc73cf4b7aebca(12) clsact/ingress cil_from_container-lxc73cf4b7aebca id 535
lxccf8266c89fa3(16) clsact/ingress cil_from_container-lxccf8266c89fa3 id 600

flow_dissector:

netfilter:

