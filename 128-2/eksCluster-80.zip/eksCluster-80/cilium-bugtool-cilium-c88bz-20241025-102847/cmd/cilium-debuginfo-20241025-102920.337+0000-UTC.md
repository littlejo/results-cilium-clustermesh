# Cilium debug information

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.80.0.0/24, 
Allocated addresses:
  10.80.0.143 (kube-system/coredns-cc6ccd49c-f8lhs)
  10.80.0.211 (router)
  10.80.0.72 (kube-system/clustermesh-apiserver-5f876cfc56-c94xr)
  10.80.0.8 (health)
  10.80.0.93 (kube-system/coredns-cc6ccd49c-gbhr2)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b50a9e94220b070a
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    7s ago         never        0       no error   
  ct-map-pressure                                                     8s ago         never        0       no error   
  daemon-validate-config                                              55s ago        never        0       no error   
  dns-garbage-collector-job                                           11s ago        never        0       no error   
  endpoint-1228-regeneration-recovery                                 never          never        0       no error   
  endpoint-133-regeneration-recovery                                  never          never        0       no error   
  endpoint-1359-regeneration-recovery                                 never          never        0       no error   
  endpoint-281-regeneration-recovery                                  never          never        0       no error   
  endpoint-70-regeneration-recovery                                   never          never        0       no error   
  endpoint-gc                                                         11s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                8s ago         never        0       no error   
  ipcache-inject-labels                                               9s ago         never        0       no error   
  k8s-heartbeat                                                       11s ago        never        0       no error   
  link-cache                                                          8s ago         never        0       no error   
  local-identity-checkpoint                                           14m34s ago     never        0       no error   
  node-neighbor-link-updater                                          8s ago         never        0       no error   
  remote-etcd-cmesh1                                                  4m59s ago      never        0       no error   
  remote-etcd-cmesh10                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh100                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh101                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh102                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh103                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh104                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh105                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh106                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh107                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh108                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh109                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh11                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh110                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh111                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh112                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh113                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh114                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh115                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh116                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh117                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh118                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh119                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh12                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh120                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh121                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh122                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh123                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh124                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh125                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh126                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh127                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh128                                                4m59s ago      never        0       no error   
  remote-etcd-cmesh13                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh14                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh15                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh16                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh17                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh18                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh19                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh2                                                  4m59s ago      never        0       no error   
  remote-etcd-cmesh20                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh21                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh22                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh23                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh24                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh25                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh26                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh27                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh28                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh29                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh3                                                  4m59s ago      never        0       no error   
  remote-etcd-cmesh30                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh31                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh32                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh33                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh34                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh35                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh36                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh37                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh38                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh39                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh4                                                  4m59s ago      never        0       no error   
  remote-etcd-cmesh40                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh41                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh42                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh43                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh44                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh45                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh46                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh47                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh48                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh49                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh5                                                  4m59s ago      never        0       no error   
  remote-etcd-cmesh50                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh51                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh52                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh53                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh54                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh55                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh56                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh57                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh58                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh59                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh6                                                  4m59s ago      never        0       no error   
  remote-etcd-cmesh60                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh61                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh62                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh63                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh64                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh65                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh66                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh67                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh68                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh69                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh7                                                  4m59s ago      never        0       no error   
  remote-etcd-cmesh70                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh71                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh72                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh73                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh74                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh75                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh76                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh77                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh78                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh79                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh8                                                  4m59s ago      never        0       no error   
  remote-etcd-cmesh80                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh82                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh83                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh84                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh85                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh86                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh87                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh88                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh89                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh9                                                  4m59s ago      never        0       no error   
  remote-etcd-cmesh90                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh91                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh92                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh93                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh94                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh95                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh96                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh97                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh98                                                 4m59s ago      never        0       no error   
  remote-etcd-cmesh99                                                 4m59s ago      never        0       no error   
  resolve-identity-1228                                               5s ago         never        0       no error   
  resolve-identity-133                                                4m57s ago      never        0       no error   
  resolve-identity-1359                                               7s ago         never        0       no error   
  resolve-identity-281                                                1m3s ago       never        0       no error   
  resolve-identity-70                                                 9s ago         never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-5f876cfc56-c94xr   6m3s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-f8lhs                  15m5s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-gbhr2                  14m57s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      15m9s ago      never        0       no error   
  sync-policymap-1228                                                 4s ago         never        0       no error   
  sync-policymap-133                                                  14m56s ago     never        0       no error   
  sync-policymap-1359                                                 4s ago         never        0       no error   
  sync-policymap-281                                                  6m3s ago       never        0       no error   
  sync-policymap-70                                                   7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1228)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (133)                                    6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (281)                                    13s ago        never        0       no error   
  sync-utime                                                          9s ago         never        0       no error   
  write-cni-file                                                      15m11s ago     never        0       no error   
Proxy Status:            OK, ip 10.80.0.211, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 5308416, max 5373951
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 63.40   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
k8s-client-connection-keep-alive:30s
policy-accounting:true
hubble-export-file-path:
enable-ipv6:false
service-no-backend-response:reject
enable-hubble-recorder-api:true
enable-identity-mark:true
monitor-aggregation-flags:all
k8s-client-qps:10
enable-local-redirect-policy:false
k8s-sync-timeout:3m0s
enable-ipv4:true
identity-heartbeat-timeout:30m0s
hubble-redact-http-urlquery:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-monitor:true
max-controller-interval:0
enable-high-scale-ipcache:false
wireguard-persistent-keepalive:0s
hubble-export-allowlist:
max-connected-clusters:255
enable-health-check-loadbalancer-ip:false
enable-ipsec-xfrm-state-caching:true
bpf-auth-map-max:524288
envoy-base-id:0
bpf-lb-maglev-map-max:0
allocator-list-timeout:3m0s
mesh-auth-mutual-listener-port:0
procfs:/host/proc
ipv6-node:auto
controller-group-metrics:
disable-endpoint-crd:false
dns-max-ips-per-restored-rule:1000
enable-unreachable-routes:false
l2-announcements-retry-period:2s
metrics:
kvstore-lease-ttl:15m0s
bpf-ct-timeout-service-tcp:2h13m20s
disable-envoy-version-check:false
bgp-announce-pod-cidr:false
enable-custom-calls:false
hubble-drop-events:false
hubble-redact-enabled:false
bpf-lb-maglev-table-size:16381
lib-dir:/var/lib/cilium
log-driver:
kube-proxy-replacement:false
cni-external-routing:false
enable-tcx:true
container-ip-local-reserved-ports:auto
vtep-endpoint:
bpf-lb-mode:snat
proxy-max-connection-duration-seconds:0
identity-gc-interval:15m0s
ipv6-service-range:auto
proxy-xff-num-trusted-hops-ingress:0
remove-cilium-node-taints:true
disable-iptables-feeder-rules:
bpf-lb-dsr-dispatch:opt
enable-auto-protect-node-port-range:true
cflags:
ipv4-service-loopback-address:169.254.42.1
clustermesh-enable-endpoint-sync:false
bpf-lb-service-backend-map-max:0
egress-gateway-reconciliation-trigger-interval:1s
restore:true
monitor-aggregation:medium
exclude-local-address:
l2-announcements-renew-deadline:5s
custom-cni-conf:false
enable-k8s:true
hubble-drop-events-interval:2m0s
envoy-keep-cap-netbindservice:false
k8s-service-proxy-name:
clustermesh-enable-mcs-api:false
enable-ipv4-masquerade:true
local-max-addr-scope:252
enable-node-selector-labels:false
read-cni-conf:
enable-ipv4-big-tcp:false
cni-chaining-target:
bpf-map-event-buffers:
external-envoy-proxy:true
cmdref:
monitor-queue-size:0
use-full-tls-context:false
enable-host-port:false
encryption-strict-mode-cidr:
encryption-strict-mode-allow-remote-node-identities:false
enable-runtime-device-detection:true
dnsproxy-insecure-skip-transparent-mode-check:false
k8s-client-connection-timeout:30s
hubble-monitor-events:
cluster-pool-ipv4-cidr:10.80.0.0/16
mesh-auth-enabled:true
enable-ip-masq-agent:false
proxy-max-requests-per-connection:0
use-cilium-internal-ip-for-ipsec:false
max-internal-timer-delay:0s
disable-external-ip-mitigation:false
endpoint-bpf-prog-watchdog-interval:30s
conntrack-gc-interval:0s
mesh-auth-signal-backoff-duration:1s
enable-active-connection-tracking:false
hubble-event-queue-size:0
bpf-events-drop-enabled:true
enable-bpf-masquerade:false
proxy-portrange-min:10000
bpf-lb-acceleration:disabled
proxy-connect-timeout:2
tofqdns-endpoint-max-ip-per-hostname:50
cluster-health-port:4240
bpf-filter-priority:1
bpf-node-map-max:16384
hubble-listen-address::4244
egress-gateway-policy-map-max:16384
ipam-multi-pool-pre-allocation:
tofqdns-enable-dns-compression:true
k8s-client-burst:20
cluster-pool-ipv4-mask-size:24
nat-map-stats-interval:30s
dnsproxy-enable-transparent-mode:true
bpf-lb-rss-ipv6-src-cidr:
node-port-mode:snat
bpf-ct-timeout-regular-tcp-fin:10s
ipsec-key-file:
hubble-export-file-compress:false
enable-ipv4-egress-gateway:false
ipv4-node:auto
bpf-fragments-map-max:8192
encrypt-interface:
ipv4-native-routing-cidr:
nodeport-addresses:
unmanaged-pod-watcher-interval:15
tofqdns-min-ttl:0
multicast-enabled:false
vtep-cidr:
enable-ipv6-ndp:false
policy-cidr-match-mode:
ipv6-pod-subnets:
pprof-address:localhost
bpf-root:/sys/fs/bpf
config-dir:/tmp/cilium/config-map
enable-k8s-networkpolicy:true
bpf-events-policy-verdict-enabled:true
mesh-auth-gc-interval:5m0s
bpf-ct-timeout-service-any:1m0s
enable-l7-proxy:true
agent-labels:
routing-mode:tunnel
tofqdns-proxy-port:0
node-port-acceleration:disabled
vtep-mac:
l2-announcements-lease-duration:15s
hubble-socket-path:/var/run/cilium/hubble.sock
enable-tracing:false
api-rate-limit:
clustermesh-ip-identities-sync-timeout:1m0s
identity-change-grace-period:5s
enable-local-node-route:true
hubble-flowlogs-config-path:
enable-masquerade-to-route-source:false
enable-ipv6-big-tcp:false
enable-pmtu-discovery:false
bpf-policy-map-full-reconciliation-interval:15m0s
enable-cilium-api-server-access:
enable-ipsec-key-watcher:true
srv6-encap-mode:reduced
state-dir:/var/run/cilium
http-normalize-path:true
enable-mke:false
enable-ingress-controller:false
cni-exclusive:true
bpf-lb-affinity-map-max:0
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-node-port:false
enable-cilium-health-api-server-access:
node-port-bind-protection:true
bpf-lb-sock-terminate-pod-connections:false
enable-health-checking:true
auto-direct-node-routes:false
auto-create-cilium-node-resource:true
http-retry-timeout:0
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-wireguard:false
iptables-lock-timeout:5s
log-opt:
ipv6-mcast-device:
dnsproxy-socket-linger-timeout:10
ip-masq-agent-config-path:/etc/config/ip-masq-agent
bpf-sock-rev-map-max:262144
envoy-config-timeout:2m0s
tofqdns-max-deferred-connection-deletes:10000
bgp-announce-lb-ip:false
prepend-iptables-chains:true
bpf-ct-global-any-max:262144
ipv4-pod-subnets:
enable-envoy-config:false
hubble-recorder-sink-queue-size:1024
egress-multi-home-ip-rule-compat:false
policy-audit-mode:false
enable-endpoint-health-checking:true
bpf-lb-rss-ipv4-src-cidr:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
cluster-name:cmesh81
ipsec-key-rotation-duration:5m0s
gateway-api-secrets-namespace:
dnsproxy-lock-count:131
socket-path:/var/run/cilium/cilium.sock
bpf-lb-sock-hostns-only:false
enable-bpf-clock-probe:false
mesh-auth-queue-size:1024
bypass-ip-availability-upon-restore:false
config:
route-metric:0
exclude-node-label-patterns:
bpf-map-dynamic-size-ratio:0.0025
k8s-namespace:kube-system
hubble-redact-http-userinfo:true
pprof-port:6060
http-request-timeout:3600
log-system-load:false
http-idle-timeout:0
hubble-redact-kafka-apikey:false
trace-payloadlen:128
hubble-recorder-storage-path:/var/run/cilium/pcaps
bpf-policy-map-max:16384
kvstore-periodic-sync:5m0s
nodes-gc-interval:5m0s
bpf-lb-map-max:65536
envoy-secrets-namespace:
enable-service-topology:false
bpf-lb-source-range-map-max:0
bpf-lb-service-map-max:0
mke-cgroup-mount:
proxy-admin-port:0
mesh-auth-rotated-identities-queue-size:1024
install-no-conntrack-iptables-rules:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
kvstore:
hubble-disable-tls:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
nat-map-stats-entries:32
debug-verbose:
bpf-neigh-global-max:524288
bpf-events-trace-enabled:true
enable-bpf-tproxy:false
node-labels:
datapath-mode:veth
hubble-redact-http-headers-deny:
enable-recorder:false
proxy-portrange-max:20000
cluster-id:81
bpf-ct-timeout-regular-any:1m0s
proxy-gid:1337
annotate-k8s-node:false
iptables-random-fully:false
debug:false
enable-l2-pod-announcements:false
dnsproxy-concurrency-processing-grace-period:0s
enable-sctp:false
enable-bgp-control-plane:false
certificates-directory:/var/run/cilium/certs
bpf-lb-rev-nat-map-max:0
keep-config:false
hubble-skip-unknown-cgroup-ids:true
k8s-heartbeat-timeout:30s
direct-routing-skip-unreachable:false
gops-port:9890
encrypt-node:false
proxy-idle-timeout-seconds:60
bpf-lb-external-clusterip:false
vlan-bpf-bypass:
k8s-require-ipv6-pod-cidr:false
conntrack-gc-max-interval:0s
join-cluster:false
k8s-service-cache-size:128
enable-ipip-termination:false
hubble-drop-events-reasons:auth_required,policy_denied
agent-health-port:9879
node-port-range:
tofqdns-idle-connection-grace-period:0s
dnsproxy-concurrency-limit:0
arping-refresh-period:30s
set-cilium-node-taints:true
envoy-log:
enable-k8s-terminating-endpoint:true
enable-host-firewall:false
monitor-aggregation-interval:5s
enable-ipv4-fragment-tracking:true
bpf-ct-timeout-regular-tcp:2h13m20s
hubble-prefer-ipv6:false
dns-policy-unload-on-shutdown:false
hubble-redact-http-headers-allow:
enable-endpoint-routes:false
clustermesh-config:/var/lib/cilium/clustermesh/
enable-bandwidth-manager:false
policy-queue-size:100
enable-well-known-identities:false
direct-routing-device:
ipv6-native-routing-cidr:
bpf-ct-global-tcp-max:524288
enable-vtep:false
enable-hubble:true
enable-cilium-endpoint-slice:false
hubble-event-buffer-capacity:4095
enable-encryption-strict-mode:false
ipv6-range:auto
kvstore-opt:
operator-prometheus-serve-addr::9963
hubble-metrics:
bpf-lb-algorithm:random
ipv4-range:auto
enable-icmp-rules:true
vtep-mask:
policy-trigger-interval:1s
local-router-ipv6:
enable-policy:default
enable-l2-neigh-discovery:true
bpf-lb-dsr-l4-xlate:frontend
hubble-export-fieldmask:
force-device-detection:false
tofqdns-dns-reject-response-code:refused
cilium-endpoint-gc-interval:5m0s
envoy-config-retry-interval:15s
fqdn-regex-compile-lru-size:1024
bpf-ct-timeout-regular-tcp-syn:1m0s
install-iptables-rules:true
allow-localhost:auto
identity-allocation-mode:crd
enable-metrics:true
cgroup-root:/run/cilium/cgroupv2
ipv6-cluster-alloc-cidr:f00d::/64
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
version:false
enable-stale-cilium-endpoint-cleanup:true
l2-pod-announcements-interface:
kube-proxy-replacement-healthz-bind-address:
cni-chaining-mode:none
mesh-auth-spiffe-trust-domain:spiffe.cilium
crd-wait-timeout:5m0s
agent-liveness-update-interval:1s
hubble-export-denylist:
ipam-cilium-node-update-rate:15s
tofqdns-proxy-response-max-delay:100ms
enable-k8s-endpoint-slice:true
k8s-kubeconfig-path:
proxy-prometheus-port:0
tunnel-protocol:vxlan
cni-log-file:/var/run/cilium/cilium-cni.log
enable-external-ips:false
enable-gateway-api:false
enable-xdp-prefilter:false
static-cnp-path:
enable-ipv6-masquerade:true
mtu:0
enable-l2-announcements:false
http-max-grpc-timeout:0
config-sources:config-map:kube-system/cilium-config
hubble-metrics-server:
preallocate-bpf-maps:false
labels:
bpf-ct-timeout-service-tcp-grace:1m0s
enable-svc-source-range-check:true
enable-bbr:false
enable-srv6:false
http-retry-count:3
dnsproxy-lock-timeout:500ms
trace-sock:true
ipv4-service-range:auto
tofqdns-pre-cache:
kvstore-connectivity-timeout:2m0s
endpoint-queue-size:25
devices:
enable-health-check-nodeport:true
pprof:false
identity-restore-grace-period:30s
k8s-api-server:
enable-k8s-api-discovery:false
enable-route-mtu-for-cni-chaining:false
enable-wireguard-userspace-fallback:false
egress-masquerade-interfaces:ens+
enable-session-affinity:false
mesh-auth-mutual-connect-timeout:5s
enable-xt-socket-fallback:true
enable-ipsec:false
mesh-auth-spire-admin-socket:
kvstore-max-consecutive-quorum-errors:2
node-port-algorithm:random
fixed-identity-mapping:
bpf-lb-sock:false
set-cilium-is-up-condition:true
k8s-require-ipv4-pod-cidr:false
label-prefix-file:
endpoint-gc-interval:5m0s
ipam:cluster-pool
hubble-export-file-max-backups:5
ingress-secrets-namespace:
enable-nat46x64-gateway:false
synchronize-k8s-nodes:true
operator-api-serve-addr:127.0.0.1:9234
derive-masq-ip-addr-from-device:
tunnel-port:0
clustermesh-sync-timeout:1m0s
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-host-legacy-routing:false
enable-ipsec-encrypted-overlay:false
proxy-xff-num-trusted-hops-egress:0
prometheus-serve-addr:
local-router-ipv4:
bpf-nat-global-max:524288
bgp-config-path:/var/lib/cilium/bgp/config.yaml
allow-icmp-frag-needed:true
hubble-export-file-max-size-mb:10
ipam-default-ip-pool:default
```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 29419390                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 29419390                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 29419390                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c000000 rw-p 00000000 00:00 0 
ffff76f07000-ffff770bc000 rw-p 00000000 00:00 0 
ffff770c4000-ffff771a5000 rw-p 00000000 00:00 0 
ffff771a5000-ffff771e6000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff771e6000-ffff77227000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff77227000-ffff77267000 rw-p 00000000 00:00 0 
ffff77267000-ffff77269000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff77269000-ffff7726b000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff7726b000-ffff77832000 rw-p 00000000 00:00 0 
ffff77832000-ffff77932000 rw-p 00000000 00:00 0 
ffff77932000-ffff77943000 rw-p 00000000 00:00 0 
ffff77943000-ffff79943000 rw-p 00000000 00:00 0 
ffff79943000-ffff799c3000 ---p 00000000 00:00 0 
ffff799c3000-ffff799c4000 rw-p 00000000 00:00 0 
ffff799c4000-ffff999c3000 ---p 00000000 00:00 0 
ffff999c3000-ffff999c4000 rw-p 00000000 00:00 0 
ffff999c4000-ffffb9953000 ---p 00000000 00:00 0 
ffffb9953000-ffffb9954000 rw-p 00000000 00:00 0 
ffffb9954000-ffffbd945000 ---p 00000000 00:00 0 
ffffbd945000-ffffbd946000 rw-p 00000000 00:00 0 
ffffbd946000-ffffbe143000 ---p 00000000 00:00 0 
ffffbe143000-ffffbe144000 rw-p 00000000 00:00 0 
ffffbe144000-ffffbe243000 ---p 00000000 00:00 0 
ffffbe243000-ffffbe2a3000 rw-p 00000000 00:00 0 
ffffbe2a3000-ffffbe2a5000 r--p 00000000 00:00 0                          [vvar]
ffffbe2a5000-ffffbe2a6000 r-xp 00000000 00:00 0                          [vdso]
ffffe12eb000-ffffe130c000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Service list

```
ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.144.147:443 (active)   
                                          2 => 172.31.222.126:443 (active)   
2    10.100.248.144:443    ClusterIP      1 => 172.31.133.51:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.80.0.143:53 (active)       
                                          2 => 10.80.0.93:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.80.0.143:9153 (active)     
                                          2 => 10.80.0.93:9153 (active)      
5    10.100.120.244:2379   ClusterIP      1 => 10.80.0.72:2379 (active)      
```

#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40010cc420)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001c56000,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001c56000,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40023e4210)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001ce9ad0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40028120b0)(frontends:[10.100.120.244]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40023e4000)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40023e40b0)(frontends:[10.100.248.144]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000f8dce0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4001974680)(172.31.144.147:443/TCP,172.31.222.126:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000f8dce8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-hx78b": (*k8s.Endpoints)(0x40029515f0)(172.31.133.51:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000f8dcf0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-m2bcm": (*k8s.Endpoints)(0x40023f3a00)(10.80.0.143:53/TCP[eu-west-3a],10.80.0.143:53/UDP[eu-west-3a],10.80.0.143:9153/TCP[eu-west-3a],10.80.0.93:53/TCP[eu-west-3a],10.80.0.93:53/UDP[eu-west-3a],10.80.0.93:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001487228)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-5gsnr": (*k8s.Endpoints)(0x4002277c70)(10.80.0.72:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001720460)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400077a9b0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4004394cc0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40001023c0,
  gcExited: (chan struct {}) 0x4000102540,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001a60280)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001353180)({
      MetricVec: (*prometheus.MetricVec)(0x4001aa1530)({
       metricMap: (*prometheus.metricMap)(0x4001aa1560)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177c180)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001a60300)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001353188)({
      MetricVec: (*prometheus.MetricVec)(0x4001aa15c0)({
       metricMap: (*prometheus.metricMap)(0x4001aa15f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177c1e0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001a60380)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001353190)({
      MetricVec: (*prometheus.MetricVec)(0x4001aa1650)({
       metricMap: (*prometheus.metricMap)(0x4001aa1680)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177c240)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001a60400)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001353198)({
      MetricVec: (*prometheus.MetricVec)(0x4001aa16e0)({
       metricMap: (*prometheus.metricMap)(0x4001aa1710)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177c2a0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001a60480)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013531a0)({
      MetricVec: (*prometheus.MetricVec)(0x4001aa1770)({
       metricMap: (*prometheus.metricMap)(0x4001aa17a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177c300)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001a60500)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013531a8)({
      MetricVec: (*prometheus.MetricVec)(0x4001aa1800)({
       metricMap: (*prometheus.metricMap)(0x4001aa1830)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177c360)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001a60580)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013531b0)({
      MetricVec: (*prometheus.MetricVec)(0x4001aa1890)({
       metricMap: (*prometheus.metricMap)(0x4001aa18c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177c3c0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001a60600)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013531b8)({
      MetricVec: (*prometheus.MetricVec)(0x4001aa1920)({
       metricMap: (*prometheus.metricMap)(0x4001aa1950)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177c420)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001a60680)({
     ObserverVec: (*prometheus.HistogramVec)(0x40013531c0)({
      MetricVec: (*prometheus.MetricVec)(0x4001aa19b0)({
       metricMap: (*prometheus.metricMap)(0x4001aa19e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400177c480)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001720460)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40010af6c0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001a130c8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 353ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.80.0.72": (string) (len=50) "kube-system/clustermesh-apiserver-5f876cfc56-c94xr",
  (string) (len=11) "10.80.0.211": (string) (len=6) "router",
  (string) (len=9) "10.80.0.8": (string) (len=6) "health",
  (string) (len=11) "10.80.0.143": (string) (len=35) "kube-system/coredns-cc6ccd49c-f8lhs",
  (string) (len=10) "10.80.0.93": (string) (len=35) "kube-system/coredns-cc6ccd49c-gbhr2"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.133.51": (string) (len=7) "node-ip"
}

```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
70         Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
133        Disabled           Disabled          5365663    k8s:eks.amazonaws.com/component=coredns                                             10.80.0.93    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh81                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
281        Disabled           Disabled          5364893    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.80.0.72    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh81                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1228       Disabled           Disabled          5365663    k8s:eks.amazonaws.com/component=coredns                                             10.80.0.143   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh81                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1359       Disabled           Disabled          4          reserved:health                                                                     10.80.0.8     ready   
```

#### BPF Policy Get 70

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 70

```
Invalid argument: unknown type 70
```


#### Endpoint Get 70

```
[
  {
    "id": 70,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-70-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c97a5033-375d-45e8-b683-3cf9a8466073"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-70",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.328Z",
            "success-count": 4
          },
          "uuid": "34dc6e42-9dca-4f1e-965c-789c0c109a49"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-70",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.422Z",
            "success-count": 2
          },
          "uuid": "7e7de2f5-7f95-4b6b-a2b2-d61a9673f317"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:22Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "42:d7:bf:6f:b1:7e",
        "interface-name": "cilium_host",
        "mac": "42:d7:bf:6f:b1:7e"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 70

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 70

```
Timestamp              Status   State                   Message
2024-10-25T10:24:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:22Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:24:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:47Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:15Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:13Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:11Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:11Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:11Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 133

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83760   962       0        
Allow    Egress      0          ANY          NONE         disabled    13044   136       0        

```


#### BPF CT List 133

```
Invalid argument: unknown type 133
```


#### Endpoint Get 133

```
[
  {
    "id": 133,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-133-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "28e2694d-def7-4426-83af-3356d0daef11"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-133",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:23.312Z",
            "success-count": 3
          },
          "uuid": "adccd8d5-9342-4800-978b-49256ecba399"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-gbhr2",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:23.309Z",
            "success-count": 1
          },
          "uuid": "194ef732-a128-4663-a852-cb5d782540b1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-133",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:23.347Z",
            "success-count": 1
          },
          "uuid": "eddd04bd-1023-48b0-a1ab-113b0de33eac"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (133)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.381Z",
            "success-count": 91
          },
          "uuid": "7e934135-1e19-42e6-a8f2-34791527f011"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d38e83c924c62fb2dd3eeaa14c59c27e2446f364ef2a5b0ddd9afabafa52446e:eth0",
        "container-id": "d38e83c924c62fb2dd3eeaa14c59c27e2446f364ef2a5b0ddd9afabafa52446e",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-gbhr2",
        "pod-name": "kube-system/coredns-cc6ccd49c-gbhr2"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5365663,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh81",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh81",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:22Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.80.0.93",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "12:40:b5:67:2b:ac",
        "interface-index": 12,
        "interface-name": "lxc73cf4b7aebca",
        "mac": "9e:eb:5f:0a:57:51"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5365663,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5365663,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 133

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 133

```
Timestamp              Status   State                   Message
2024-10-25T10:24:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:22Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:24:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:47Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:23Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:23Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:23Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5365663

```
ID        LABELS
5365663   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh81
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 281

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3903742   35738     0        
Allow    Ingress     1          ANY          NONE         disabled    2569007   25289     0        
Allow    Egress      0          ANY          NONE         disabled    3508317   33067     0        

```


#### BPF CT List 281

```
Invalid argument: unknown type 281
```


#### Endpoint Get 281

```
[
  {
    "id": 281,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-281-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0adb62e0-722c-4521-91ba-373cd75b9373"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-281",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:16.599Z",
            "success-count": 2
          },
          "uuid": "69bbf7d0-5654-4678-afc2-5905d80f164c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-5f876cfc56-c94xr",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:16.597Z",
            "success-count": 1
          },
          "uuid": "9fd35996-7395-44e3-be45-f7c3f9adf391"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-281",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:16.637Z",
            "success-count": 1
          },
          "uuid": "8804fc74-9824-4c26-ab35-33748083e3e9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (281)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:16.639Z",
            "success-count": 38
          },
          "uuid": "1e8ce708-2e5a-4d4a-ac17-f5eddcf03ab7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "2fd1f5dbe344476104a8b69ad5fa2c0c7cbcbfe5f5317f992587ea80b60149df:eth0",
        "container-id": "2fd1f5dbe344476104a8b69ad5fa2c0c7cbcbfe5f5317f992587ea80b60149df",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-5f876cfc56-c94xr",
        "pod-name": "kube-system/clustermesh-apiserver-5f876cfc56-c94xr"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5364893,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh81",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=5f876cfc56"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh81",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:22Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.80.0.72",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "9e:55:0f:55:eb:21",
        "interface-index": 16,
        "interface-name": "lxccf8266c89fa3",
        "mac": "02:89:4f:1c:6f:ad"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5364893,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5364893,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 281

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 281

```
Timestamp              Status   State                   Message
2024-10-25T10:24:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:22Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:24:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:23:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:23:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:23:16Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:23:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5364893

```
ID        LABELS
5364893   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh81
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1228

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85093   976       0        
Allow    Egress      0          ANY          NONE         disabled    14214   150       0        

```


#### BPF CT List 1228

```
Invalid argument: unknown type 1228
```


#### Endpoint Get 1228

```
[
  {
    "id": 1228,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1228-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "746a7a37-41d5-4392-af37-ab345ff904ac"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1228",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.360Z",
            "success-count": 4
          },
          "uuid": "2bb276ae-1caf-4aad-b7b8-68b097356c1c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-f8lhs",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:14.357Z",
            "success-count": 1
          },
          "uuid": "67a2f121-3a69-4df3-86f5-329d7b3751e7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1228",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:15.711Z",
            "success-count": 2
          },
          "uuid": "29637626-b530-456d-9194-6ce96a78e3a8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1228)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.434Z",
            "success-count": 92
          },
          "uuid": "af68e90b-ede5-4f1c-b406-537e4285a460"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "af2f705c782ae78028ea2cb40c7da3da1a0f486e1b5afdce8c7620e1c862da6d:eth0",
        "container-id": "af2f705c782ae78028ea2cb40c7da3da1a0f486e1b5afdce8c7620e1c862da6d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-f8lhs",
        "pod-name": "kube-system/coredns-cc6ccd49c-f8lhs"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5365663,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh81",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh81",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:22Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.80.0.143",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "d6:01:e8:51:26:b5",
        "interface-index": 10,
        "interface-name": "lxcf396a6a62f58",
        "mac": "ea:a3:dd:33:15:f1"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5365663,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5365663,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1228

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1228

```
Timestamp              Status    State                   Message
2024-10-25T10:24:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:22Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:24:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:48Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:48Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:48Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:48Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:47Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:47Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:47Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:47Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:15Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:14Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:14Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:14Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:14Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:14Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 5365663

```
ID        LABELS
5365663   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh81
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1359

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    444630   5697      0        
Allow    Ingress     1          ANY          NONE         disabled    12358    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1359

```
Invalid argument: unknown type 1359
```


#### Endpoint Get 1359

```
[
  {
    "id": 1359,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1359-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8c3d9708-3953-44a0-b86a-9fbe61e1d851"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1359",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.422Z",
            "success-count": 4
          },
          "uuid": "cac0d12a-4427-4b4c-9419-9cb70373a087"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1359",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:15.705Z",
            "success-count": 2
          },
          "uuid": "91b54497-9a77-4b98-8ab1-eabd9926d347"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:24:22Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.80.0.8",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ee:14:8b:95:3a:8a",
        "interface-index": 8,
        "interface-name": "lxc_health",
        "mac": "7e:9b:f6:3e:53:53"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1359

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1359

```
Timestamp              Status   State                   Message
2024-10-25T10:24:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:24:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:22Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:24:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:24:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:24:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:47Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:15Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:15Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:12Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:12Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:11Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```

