IP ADDRESS        LOCAL ENDPOINT INFO
10.80.0.143:0     id=1228  sec_id=5365663 flags=0x0000 ifindex=10  mac=EA:A3:DD:33:15:F1 nodemac=D6:01:E8:51:26:B5   
172.31.133.51:0   (localhost)                                                                                        
10.80.0.8:0       id=1359  sec_id=4     flags=0x0000 ifindex=8   mac=7E:9B:F6:3E:53:53 nodemac=EE:14:8B:95:3A:8A     
10.80.0.72:0      id=281   sec_id=5364893 flags=0x0000 ifindex=16  mac=02:89:4F:1C:6F:AD nodemac=9E:55:0F:55:EB:21   
10.80.0.93:0      id=133   sec_id=5365663 flags=0x0000 ifindex=12  mac=9E:EB:5F:0A:57:51 nodemac=12:40:B5:67:2B:AC   
10.80.0.211:0     (localhost)                                                                                        
