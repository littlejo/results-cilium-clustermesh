1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a3:68:5d:94:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.133.51/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2679sec preferred_lft 2679sec
    inet6 fe80::4a3:68ff:fe5d:945d/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:fb:ac:80:8d:56 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84fb:acff:fe80:8d56/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:d7:bf:6f:b1:7e brd ff:ff:ff:ff:ff:ff
    inet 10.80.0.211/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::40d7:bfff:fe6f:b17e/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 02:2a:93:71:20:00 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2a:93ff:fe71:2000/64 scope link 
       valid_lft forever preferred_lft forever
8: lxc_health@if7: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:14:8b:95:3a:8a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ec14:8bff:fe95:3a8a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxcf396a6a62f58@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:01:e8:51:26:b5 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d401:e8ff:fe51:26b5/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc73cf4b7aebca@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:40:b5:67:2b:ac brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::1040:b5ff:fe67:2bac/64 scope link 
       valid_lft forever preferred_lft forever
16: lxccf8266c89fa3@if15: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:55:0f:55:eb:21 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9c55:fff:fe55:eb21/64 scope link 
       valid_lft forever preferred_lft forever
