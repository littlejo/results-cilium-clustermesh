Total: 533
TCP:   1073 (estab 289, closed 765, orphaned 0, timewait 314)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  308       298       10       
INET	  318       304       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:41773      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:22326 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.133.51%ens5:68         0.0.0.0:*    uid:192 ino:16415 sk:1002 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:23487 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15437 sk:1004 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:23486 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15438 sk:1006 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4a3:68ff:fe5d:945d]%ens5:546           [::]:*    uid:192 ino:16413 sk:1007 cgroup:unreachable:c4e v6only:1 <->                   
