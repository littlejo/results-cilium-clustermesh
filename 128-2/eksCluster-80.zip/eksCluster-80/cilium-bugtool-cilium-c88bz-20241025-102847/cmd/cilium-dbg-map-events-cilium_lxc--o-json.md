{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:11.115Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.133.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:11.115Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.703Z",
  "value": "id=1359  sec_id=4     flags=0x0000 ifindex=8   mac=7E:9B:F6:3E:53:53 nodemac=EE:14:8B:95:3A:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.710Z",
  "value": "id=1228  sec_id=5365663 flags=0x0000 ifindex=10  mac=EA:A3:DD:33:15:F1 nodemac=D6:01:E8:51:26:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.718Z",
  "value": "id=1228  sec_id=5365663 flags=0x0000 ifindex=10  mac=EA:A3:DD:33:15:F1 nodemac=D6:01:E8:51:26:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.736Z",
  "value": "id=1359  sec_id=4     flags=0x0000 ifindex=8   mac=7E:9B:F6:3E:53:53 nodemac=EE:14:8B:95:3A:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:23.346Z",
  "value": "id=133   sec_id=5365663 flags=0x0000 ifindex=12  mac=9E:EB:5F:0A:57:51 nodemac=12:40:B5:67:2B:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:47.237Z",
  "value": "id=1359  sec_id=4     flags=0x0000 ifindex=8   mac=7E:9B:F6:3E:53:53 nodemac=EE:14:8B:95:3A:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:47.238Z",
  "value": "id=1228  sec_id=5365663 flags=0x0000 ifindex=10  mac=EA:A3:DD:33:15:F1 nodemac=D6:01:E8:51:26:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:47.238Z",
  "value": "id=133   sec_id=5365663 flags=0x0000 ifindex=12  mac=9E:EB:5F:0A:57:51 nodemac=12:40:B5:67:2B:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:47.264Z",
  "value": "id=1910  sec_id=5364893 flags=0x0000 ifindex=14  mac=0E:94:26:CA:5E:51 nodemac=8A:E9:73:46:C3:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:47.264Z",
  "value": "id=1910  sec_id=5364893 flags=0x0000 ifindex=14  mac=0E:94:26:CA:5E:51 nodemac=8A:E9:73:46:C3:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:48.236Z",
  "value": "id=133   sec_id=5365663 flags=0x0000 ifindex=12  mac=9E:EB:5F:0A:57:51 nodemac=12:40:B5:67:2B:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:48.236Z",
  "value": "id=1359  sec_id=4     flags=0x0000 ifindex=8   mac=7E:9B:F6:3E:53:53 nodemac=EE:14:8B:95:3A:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:48.236Z",
  "value": "id=1910  sec_id=5364893 flags=0x0000 ifindex=14  mac=0E:94:26:CA:5E:51 nodemac=8A:E9:73:46:C3:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:48.237Z",
  "value": "id=1228  sec_id=5365663 flags=0x0000 ifindex=10  mac=EA:A3:DD:33:15:F1 nodemac=D6:01:E8:51:26:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.637Z",
  "value": "id=281   sec_id=5364893 flags=0x0000 ifindex=16  mac=02:89:4F:1C:6F:AD nodemac=9E:55:0F:55:EB:21"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.80.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.964Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:20.757Z",
  "value": "id=281   sec_id=5364893 flags=0x0000 ifindex=16  mac=02:89:4F:1C:6F:AD nodemac=9E:55:0F:55:EB:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:20.759Z",
  "value": "id=133   sec_id=5365663 flags=0x0000 ifindex=12  mac=9E:EB:5F:0A:57:51 nodemac=12:40:B5:67:2B:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:20.760Z",
  "value": "id=1359  sec_id=4     flags=0x0000 ifindex=8   mac=7E:9B:F6:3E:53:53 nodemac=EE:14:8B:95:3A:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:20.761Z",
  "value": "id=1228  sec_id=5365663 flags=0x0000 ifindex=10  mac=EA:A3:DD:33:15:F1 nodemac=D6:01:E8:51:26:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:21.751Z",
  "value": "id=1359  sec_id=4     flags=0x0000 ifindex=8   mac=7E:9B:F6:3E:53:53 nodemac=EE:14:8B:95:3A:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:21.751Z",
  "value": "id=133   sec_id=5365663 flags=0x0000 ifindex=12  mac=9E:EB:5F:0A:57:51 nodemac=12:40:B5:67:2B:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:21.752Z",
  "value": "id=1228  sec_id=5365663 flags=0x0000 ifindex=10  mac=EA:A3:DD:33:15:F1 nodemac=D6:01:E8:51:26:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:21.752Z",
  "value": "id=281   sec_id=5364893 flags=0x0000 ifindex=16  mac=02:89:4F:1C:6F:AD nodemac=9E:55:0F:55:EB:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:22.752Z",
  "value": "id=281   sec_id=5364893 flags=0x0000 ifindex=16  mac=02:89:4F:1C:6F:AD nodemac=9E:55:0F:55:EB:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:22.752Z",
  "value": "id=133   sec_id=5365663 flags=0x0000 ifindex=12  mac=9E:EB:5F:0A:57:51 nodemac=12:40:B5:67:2B:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:22.752Z",
  "value": "id=1228  sec_id=5365663 flags=0x0000 ifindex=10  mac=EA:A3:DD:33:15:F1 nodemac=D6:01:E8:51:26:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:22.752Z",
  "value": "id=1359  sec_id=4     flags=0x0000 ifindex=8   mac=7E:9B:F6:3E:53:53 nodemac=EE:14:8B:95:3A:8A"
}

