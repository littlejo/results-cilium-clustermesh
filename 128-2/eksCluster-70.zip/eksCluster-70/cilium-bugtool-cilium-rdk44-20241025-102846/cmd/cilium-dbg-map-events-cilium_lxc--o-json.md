{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:37.511Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.176.0:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:37.511Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:40.771Z",
  "value": "id=84    sec_id=4715518 flags=0x0000 ifindex=9   mac=82:22:40:DD:50:E1 nodemac=8A:2C:5B:A6:6F:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:44.066Z",
  "value": "id=797   sec_id=4     flags=0x0000 ifindex=7   mac=C6:FF:4D:FF:26:30 nodemac=02:51:02:72:45:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:44.071Z",
  "value": "id=3714  sec_id=4715518 flags=0x0000 ifindex=11  mac=16:E0:32:38:C3:FA nodemac=FE:D5:15:27:F7:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:44.122Z",
  "value": "id=84    sec_id=4715518 flags=0x0000 ifindex=9   mac=82:22:40:DD:50:E1 nodemac=8A:2C:5B:A6:6F:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:44.160Z",
  "value": "id=797   sec_id=4     flags=0x0000 ifindex=7   mac=C6:FF:4D:FF:26:30 nodemac=02:51:02:72:45:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:44.202Z",
  "value": "id=3714  sec_id=4715518 flags=0x0000 ifindex=11  mac=16:E0:32:38:C3:FA nodemac=FE:D5:15:27:F7:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:53.595Z",
  "value": "id=3714  sec_id=4715518 flags=0x0000 ifindex=11  mac=16:E0:32:38:C3:FA nodemac=FE:D5:15:27:F7:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:53.595Z",
  "value": "id=797   sec_id=4     flags=0x0000 ifindex=7   mac=C6:FF:4D:FF:26:30 nodemac=02:51:02:72:45:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:53.599Z",
  "value": "id=84    sec_id=4715518 flags=0x0000 ifindex=9   mac=82:22:40:DD:50:E1 nodemac=8A:2C:5B:A6:6F:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:53.625Z",
  "value": "id=2685  sec_id=4706226 flags=0x0000 ifindex=13  mac=AA:5A:C1:44:E7:20 nodemac=FA:DA:80:EC:6A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:54.595Z",
  "value": "id=3714  sec_id=4715518 flags=0x0000 ifindex=11  mac=16:E0:32:38:C3:FA nodemac=FE:D5:15:27:F7:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:54.595Z",
  "value": "id=84    sec_id=4715518 flags=0x0000 ifindex=9   mac=82:22:40:DD:50:E1 nodemac=8A:2C:5B:A6:6F:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:54.596Z",
  "value": "id=797   sec_id=4     flags=0x0000 ifindex=7   mac=C6:FF:4D:FF:26:30 nodemac=02:51:02:72:45:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:54.596Z",
  "value": "id=2685  sec_id=4706226 flags=0x0000 ifindex=13  mac=AA:5A:C1:44:E7:20 nodemac=FA:DA:80:EC:6A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.551Z",
  "value": "id=1873  sec_id=4706226 flags=0x0000 ifindex=15  mac=96:82:B3:F5:9D:16 nodemac=9E:45:67:15:6D:45"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.70.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:21.567Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:28.172Z",
  "value": "id=1873  sec_id=4706226 flags=0x0000 ifindex=15  mac=96:82:B3:F5:9D:16 nodemac=9E:45:67:15:6D:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:28.182Z",
  "value": "id=84    sec_id=4715518 flags=0x0000 ifindex=9   mac=82:22:40:DD:50:E1 nodemac=8A:2C:5B:A6:6F:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:28.182Z",
  "value": "id=3714  sec_id=4715518 flags=0x0000 ifindex=11  mac=16:E0:32:38:C3:FA nodemac=FE:D5:15:27:F7:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:28.182Z",
  "value": "id=797   sec_id=4     flags=0x0000 ifindex=7   mac=C6:FF:4D:FF:26:30 nodemac=02:51:02:72:45:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.156Z",
  "value": "id=1873  sec_id=4706226 flags=0x0000 ifindex=15  mac=96:82:B3:F5:9D:16 nodemac=9E:45:67:15:6D:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.156Z",
  "value": "id=3714  sec_id=4715518 flags=0x0000 ifindex=11  mac=16:E0:32:38:C3:FA nodemac=FE:D5:15:27:F7:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.157Z",
  "value": "id=84    sec_id=4715518 flags=0x0000 ifindex=9   mac=82:22:40:DD:50:E1 nodemac=8A:2C:5B:A6:6F:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.157Z",
  "value": "id=797   sec_id=4     flags=0x0000 ifindex=7   mac=C6:FF:4D:FF:26:30 nodemac=02:51:02:72:45:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.156Z",
  "value": "id=1873  sec_id=4706226 flags=0x0000 ifindex=15  mac=96:82:B3:F5:9D:16 nodemac=9E:45:67:15:6D:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.156Z",
  "value": "id=84    sec_id=4715518 flags=0x0000 ifindex=9   mac=82:22:40:DD:50:E1 nodemac=8A:2C:5B:A6:6F:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.157Z",
  "value": "id=3714  sec_id=4715518 flags=0x0000 ifindex=11  mac=16:E0:32:38:C3:FA nodemac=FE:D5:15:27:F7:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.157Z",
  "value": "id=797   sec_id=4     flags=0x0000 ifindex=7   mac=C6:FF:4D:FF:26:30 nodemac=02:51:02:72:45:A5"
}

