29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:18:59+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
55: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
58: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
59: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
62: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:19:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
452: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
455: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
456: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:19:41+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 124
457: sched_cls  name tail_handle_ipv4  tag f6076a1c9bdf0068  gpl
	loaded_at 2024-10-25T10:19:41+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,93
	btf_id 125
458: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:19:41+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,93
	btf_id 126
459: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:19:41+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
460: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
463: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
486: sched_cls  name __send_drop_notify  tag 48a84b2866606717  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 154
487: sched_cls  name tail_ipv4_ct_egress  tag ac52658331422318  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 155
489: sched_cls  name tail_ipv4_to_endpoint  tag bd2926a7771b61e2  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,83,31,102,32,29,30
	btf_id 157
490: sched_cls  name tail_ipv4_ct_ingress  tag c25ed68a6c32661d  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 158
491: sched_cls  name tail_handle_ipv4_cont  tag 0d1ed6bb006bc403  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,83,74,75,31,68,66,69,102,32,29,30,73
	btf_id 159
492: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,102
	btf_id 160
493: sched_cls  name tail_handle_arp  tag 1d57b1bc81a3c535  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,102
	btf_id 161
494: sched_cls  name tail_handle_ipv4  tag 16891a2a1c3e76e5  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,102
	btf_id 162
495: sched_cls  name handle_policy  tag dcf15147f0975368  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,102,74,75,101,33,72,83,31,76,67,32,29,30
	btf_id 163
496: sched_cls  name cil_from_container  tag ef968e66d190f5f4  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 102,68
	btf_id 164
497: sched_cls  name handle_policy  tag 19a911316e81a57e  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,104,74,75,103,33,72,94,31,76,67,32,29,30
	btf_id 166
498: sched_cls  name cil_from_container  tag eab025bd126de00b  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 104,68
	btf_id 167
499: sched_cls  name tail_ipv4_to_endpoint  tag 763ae81b50852ab1  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,103,33,74,75,72,94,31,104,32,29,30
	btf_id 168
500: sched_cls  name tail_handle_ipv4  tag f23a2e9f4df72508  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 169
501: sched_cls  name tail_ipv4_ct_ingress  tag a7887b535be9c6c6  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 170
502: sched_cls  name __send_drop_notify  tag 00d08428ef53ff08  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 171
503: sched_cls  name tail_handle_arp  tag 58eb01f41e99c2c2  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 172
504: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 173
505: sched_cls  name tail_handle_ipv4_cont  tag c6f53fc3d040fc1a  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,103,33,94,74,75,31,68,66,69,104,32,29,30,73
	btf_id 174
506: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 175
508: sched_cls  name tail_handle_ipv4_cont  tag 3d7ff3b6b3df7bd5  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,106,33,95,74,75,31,68,66,69,105,32,29,30,73
	btf_id 178
509: sched_cls  name tail_ipv4_ct_ingress  tag 239a585c18fb11ea  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 179
510: sched_cls  name __send_drop_notify  tag 642861897a401e10  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 180
511: sched_cls  name tail_ipv4_ct_egress  tag ac52658331422318  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 181
512: sched_cls  name tail_ipv4_to_endpoint  tag 9075419b5782d62f  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,106,33,74,75,72,95,31,105,32,29,30
	btf_id 182
513: sched_cls  name cil_from_container  tag dc9cf3acdc035b68  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 105,68
	btf_id 183
514: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
518: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
519: sched_cls  name handle_policy  tag 140262dac77b59cc  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,105,74,75,106,33,72,95,31,76,67,32,29,30
	btf_id 185
520: sched_cls  name tail_handle_arp  tag e54a60e18d726d21  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,105
	btf_id 186
521: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,105
	btf_id 187
522: sched_cls  name tail_handle_ipv4  tag ef82a0d93a55c7da  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,105
	btf_id 188
523: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
526: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
528: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 192
530: sched_cls  name __send_drop_notify  tag a1079d6e06162084  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 194
531: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,109
	btf_id 195
532: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 196
533: sched_cls  name tail_handle_ipv4_from_host  tag 555e4254d2a81b12  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 197
534: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,112
	btf_id 199
536: sched_cls  name __send_drop_notify  tag a1079d6e06162084  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 201
538: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 203
539: sched_cls  name tail_handle_ipv4_from_host  tag 555e4254d2a81b12  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,112
	btf_id 204
542: sched_cls  name __send_drop_notify  tag a1079d6e06162084  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 208
545: sched_cls  name tail_handle_ipv4_from_host  tag 555e4254d2a81b12  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,114
	btf_id 211
546: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,114,67
	btf_id 212
547: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:19:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,114
	btf_id 213
587: sched_cls  name cil_from_container  tag 22b6ee364af35b05  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 126,68
	btf_id 227
589: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,126
	btf_id 229
590: sched_cls  name tail_handle_ipv4  tag 6be7f2796cf58a17  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,126
	btf_id 230
591: sched_cls  name __send_drop_notify  tag 15d216763f753f89  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 231
592: sched_cls  name tail_ipv4_ct_ingress  tag 3b093f78fbbc700d  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,126,74,75,127,76
	btf_id 232
593: sched_cls  name handle_policy  tag 7c3f48624bfe281f  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,126,74,75,127,33,72,125,31,76,67,32,29,30
	btf_id 233
594: sched_cls  name tail_handle_ipv4_cont  tag 90ea1bf11da16601  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,127,33,125,74,75,31,68,66,69,126,32,29,30,73
	btf_id 234
595: sched_cls  name tail_ipv4_ct_egress  tag a63990bd0e0c152b  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,126,74,75,127,76
	btf_id 235
596: sched_cls  name tail_handle_arp  tag 2ddc5248b1c55ae7  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,126
	btf_id 236
597: sched_cls  name tail_ipv4_to_endpoint  tag 7225c73cd9ffd087  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,127,33,74,75,72,125,31,126,32,29,30
	btf_id 237
598: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
601: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
614: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
617: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
618: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
621: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
622: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
625: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
