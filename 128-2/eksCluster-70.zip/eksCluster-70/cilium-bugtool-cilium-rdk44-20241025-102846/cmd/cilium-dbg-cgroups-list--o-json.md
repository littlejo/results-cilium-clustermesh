[
  {
    "containers": [
      {
        "cgroup-id": 6705,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0a45bca_45a8_417f_b57d_6305a03162f6.slice/cri-containerd-fc3e9b3abfcbc960845bf8d3f3f83aedc673529ef704753fbfc06b52fd950941.scope"
      }
    ],
    "ips": [
      "10.70.0.77"
    ],
    "name": "coredns-cc6ccd49c-hvzqr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6873,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfa758dc8_dc8f_4ecb_9bc0_72d587a0219e.slice/cri-containerd-4f98a46e81ee81b1ff9e279f4e759cb25187c2365f389e382de1129558046693.scope"
      }
    ],
    "ips": [
      "10.70.0.190"
    ],
    "name": "coredns-cc6ccd49c-kb9rx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8301,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16b94c31_ac1e_45ef_94c9_d7b237c32517.slice/cri-containerd-f1f333795705115ef584aac317435dd6bb50a44ae7d86b9581537ed2d99a54cb.scope"
      },
      {
        "cgroup-id": 8217,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16b94c31_ac1e_45ef_94c9_d7b237c32517.slice/cri-containerd-9bdab8eb93caeef854e277b787cc5eb253fc47a582977fb2733eaeedadde0fb3.scope"
      },
      {
        "cgroup-id": 8385,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16b94c31_ac1e_45ef_94c9_d7b237c32517.slice/cri-containerd-64f3b2efdbf0a07f7d8b6aaf9ece6e8a9e3e122e006c9b3e2a46829659a88f60.scope"
      }
    ],
    "ips": [
      "10.70.0.13"
    ],
    "name": "clustermesh-apiserver-856d9f5566-n65mt",
    "namespace": "kube-system"
  }
]

