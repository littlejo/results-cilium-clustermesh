1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:6f:b9:18:2b:03 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.176.0/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3014sec preferred_lft 3014sec
    inet6 fe80::46f:b9ff:fe18:2b03/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:ff:c2:26:85:fe brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ecff:c2ff:fe26:85fe/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:26:7b:b6:34:e1 brd ff:ff:ff:ff:ff:ff
    inet 10.70.0.37/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9c26:7bff:feb6:34e1/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 12:4e:40:9d:26:c1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::104e:40ff:fe9d:26c1/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:51:02:72:45:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::51:2ff:fe72:45a5/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc00f9adbef0a1@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:2c:5b:a6:6f:92 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::882c:5bff:fea6:6f92/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc1f33bdb77da7@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:d5:15:27:f7:78 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fcd5:15ff:fe27:f778/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc2a74c5a54c61@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:45:67:15:6d:45 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9c45:67ff:fe15:6d45/64 scope link 
       valid_lft forever preferred_lft forever
