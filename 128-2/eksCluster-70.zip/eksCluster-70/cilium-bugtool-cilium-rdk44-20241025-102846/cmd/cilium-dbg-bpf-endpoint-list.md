IP ADDRESS       LOCAL ENDPOINT INFO
10.70.0.13:0     id=1873  sec_id=4706226 flags=0x0000 ifindex=15  mac=96:82:B3:F5:9D:16 nodemac=9E:45:67:15:6D:45   
10.70.0.18:0     id=797   sec_id=4     flags=0x0000 ifindex=7   mac=C6:FF:4D:FF:26:30 nodemac=02:51:02:72:45:A5     
10.70.0.37:0     (localhost)                                                                                        
10.70.0.190:0    id=3714  sec_id=4715518 flags=0x0000 ifindex=11  mac=16:E0:32:38:C3:FA nodemac=FE:D5:15:27:F7:78   
10.70.0.77:0     id=84    sec_id=4715518 flags=0x0000 ifindex=9   mac=82:22:40:DD:50:E1 nodemac=8A:2C:5B:A6:6F:92   
172.31.176.0:0   (localhost)                                                                                        
