KEY             VALUE
AgentLiveness   599070225442
UTimeOffset     3378616271484375
