xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 546
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 538
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 532
cilium_host(4) clsact/egress cil_from_host-cilium_host id 531
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 458
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 459
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 498
lxc00f9adbef0a1(9) clsact/ingress cil_from_container-lxc00f9adbef0a1 id 496
lxc1f33bdb77da7(11) clsact/ingress cil_from_container-lxc1f33bdb77da7 id 513
lxc2a74c5a54c61(15) clsact/ingress cil_from_container-lxc2a74c5a54c61 id 587

flow_dissector:

netfilter:

