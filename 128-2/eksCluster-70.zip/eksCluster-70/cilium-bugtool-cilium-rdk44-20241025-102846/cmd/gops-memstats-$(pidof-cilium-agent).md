alloc: 102.86MB (107855760 bytes)
total-alloc: 1.27GB (1364123056 bytes)
sys: 202.07MB (211884356 bytes)
lookups: 0
mallocs: 47018140
frees: 45936888
heap-alloc: 102.86MB (107855760 bytes)
heap-sys: 157.38MB (165019648 bytes)
heap-idle: 34.98MB (36675584 bytes)
heap-in-use: 122.40MB (128344064 bytes)
heap-released: 6.75MB (7077888 bytes)
heap-objects: 1081252
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 2.05MB (2153440 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 729.33KB (746833 bytes)
gc-sys: 5.04MB (5285056 bytes)
next-gc: when heap-alloc >= 142.93MB (149871960 bytes)
last-gc: 2024-10-25 10:28:06.63267639 +0000 UTC
gc-pause-total: 8.626934ms
gc-pause: 106316
gc-pause-end: 1729852086632676390
num-gc: 70
num-forced-gc: 0
gc-cpu-fraction: 0.000587615935581537
enable-gc: true
debug-gc: false
