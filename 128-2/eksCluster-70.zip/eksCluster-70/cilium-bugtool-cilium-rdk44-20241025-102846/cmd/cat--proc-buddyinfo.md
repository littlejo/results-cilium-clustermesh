Node 0, zone      DMA      5      6      4      4     10      9      8      7      6      6    222 
Node 0, zone   Normal      2      2      2      4      2      4      1      0      1      1     53 
