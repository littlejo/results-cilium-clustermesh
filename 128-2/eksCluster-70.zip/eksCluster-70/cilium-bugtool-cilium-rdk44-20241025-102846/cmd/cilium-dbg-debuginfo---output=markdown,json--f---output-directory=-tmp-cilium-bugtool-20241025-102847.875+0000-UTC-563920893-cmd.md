markdown output at /tmp/cilium-bugtool-20241025-102847.875+0000-UTC-563920893/cmd/cilium-debuginfo-20241025-102849.191+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102847.875+0000-UTC-563920893/cmd/cilium-debuginfo-20241025-102849.191+0000-UTC.json
