Endpoint ID: 84
Path: /sys/fs/bpf/tc/globals/cilium_policy_00084

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    50905   586       0        
Allow    Egress      0          ANY          NONE         disabled    12004   121       0        


Endpoint ID: 797
Path: /sys/fs/bpf/tc/globals/cilium_policy_00797

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    398676   5094      0        
Allow    Ingress     1          ANY          NONE         disabled    8212     97        0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1873
Path: /sys/fs/bpf/tc/globals/cilium_policy_01873

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3282803   31921     0        
Allow    Ingress     1          ANY          NONE         disabled    3085755   31217     0        
Allow    Egress      0          ANY          NONE         disabled    3724457   35864     0        


Endpoint ID: 3201
Path: /sys/fs/bpf/tc/globals/cilium_policy_03201

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3714
Path: /sys/fs/bpf/tc/globals/cilium_policy_03714

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    51802   598       0        
Allow    Egress      0          ANY          NONE         disabled    12042   121       0        


