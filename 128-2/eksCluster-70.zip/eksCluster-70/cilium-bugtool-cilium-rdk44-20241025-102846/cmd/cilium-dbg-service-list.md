ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.223.138:443 (active)   
                                         2 => 172.31.161.78:443 (active)    
2    10.100.121.142:443   ClusterIP      1 => 172.31.176.0:4244 (active)    
3    10.100.0.10:53       ClusterIP      1 => 10.70.0.77:53 (active)        
                                         2 => 10.70.0.190:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.70.0.77:9153 (active)      
                                         2 => 10.70.0.190:9153 (active)     
5    10.100.252.78:2379   ClusterIP      1 => 10.70.0.13:2379 (active)      
