fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc00f9adbef0a1 proto kernel metric 256 pref medium
fe80::/64 dev lxc1f33bdb77da7 proto kernel metric 256 pref medium
fe80::/64 dev lxc2a74c5a54c61 proto kernel metric 256 pref medium
