REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     192099    95907802   1132   bpf_host.c
Interface                 INGRESS     9584      750983     677    bpf_overlay.c
Success                   EGRESS      5170      398663     1694   bpf_host.c
Success                   EGRESS      81132     10682455   1308   bpf_lxc.c
Success                   EGRESS      9929      777250     53     encap.h
Success                   INGRESS     92321     10992936   86     l3.h
Success                   INGRESS     97384     11389162   235    trace.h
Unsupported L3 protocol   EGRESS      33        2462       1492   bpf_lxc.c
