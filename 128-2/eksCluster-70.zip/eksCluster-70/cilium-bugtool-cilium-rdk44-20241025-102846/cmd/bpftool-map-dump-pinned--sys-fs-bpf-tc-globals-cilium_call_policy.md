key: 54 00 00 00  value: ef 01 00 00
key: 1d 03 00 00  value: f1 01 00 00
key: 51 07 00 00  value: 51 02 00 00
key: 82 0e 00 00  value: 07 02 00 00
Found 4 elements
