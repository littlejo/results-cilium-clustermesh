CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfa758dc8_dc8f_4ecb_9bc0_72d587a0219e.slice/cri-containerd-4d72497a1fc0c4d6b3cfcb036299eec024141f3e1f3921c9c18ef944c814b031.scope
    518      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfa758dc8_dc8f_4ecb_9bc0_72d587a0219e.slice/cri-containerd-4f98a46e81ee81b1ff9e279f4e759cb25187c2365f389e382de1129558046693.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0a45bca_45a8_417f_b57d_6305a03162f6.slice/cri-containerd-fc3e9b3abfcbc960845bf8d3f3f83aedc673529ef704753fbfc06b52fd950941.scope
    463      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0a45bca_45a8_417f_b57d_6305a03162f6.slice/cri-containerd-00c3e172114c908427eb4fe02fe5e869a7d1b96766b171ab17aad5161552a9b0.scope
    455      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0792ef71_9f44_475d_a53d_ac61b344754b.slice/cri-containerd-fb06ed2a3ca3f67589bd7aabf06ec7a9676238581e16e7882a49dd6f3b46b151.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0792ef71_9f44_475d_a53d_ac61b344754b.slice/cri-containerd-3034bb9a82d8257e636ba1c76f6d52e25e3720adaca32468f7ef130ebf08be3a.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ffb1737_a1ac_412c_b177_07ef4d09262c.slice/cri-containerd-181a09397da555a6636ab1dc1df1b61d84e86e7d661e6cdcf75912940937a6f1.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ffb1737_a1ac_412c_b177_07ef4d09262c.slice/cri-containerd-0de0eedf389e9f83f297efa35efcc6c62c9c66e1524b892e779cf691cf919df7.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b883556_5f17_4084_8523_32fee2e6cc56.slice/cri-containerd-b0449cd2f85ba9f4cda1442dc42b0454f17a88d1ca1cf21163a48bba4bebe09e.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b883556_5f17_4084_8523_32fee2e6cc56.slice/cri-containerd-aefe13cc7a1630c134523fecb01ee97ad302bcc18d6045e1861bcc872cfc1c38.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3087372e_57d3_4d2c_8e63_c5a963a1cf51.slice/cri-containerd-3e3f389bcc35b6fff1257fde0f2fc447fe30543a159c04f4a3083883bb28d1cd.scope
    58       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3087372e_57d3_4d2c_8e63_c5a963a1cf51.slice/cri-containerd-f6bc19643d5a3f7c5f299cff69d24a06862d30849df0e8ba12026b2627071d20.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16b94c31_ac1e_45ef_94c9_d7b237c32517.slice/cri-containerd-f1f333795705115ef584aac317435dd6bb50a44ae7d86b9581537ed2d99a54cb.scope
    621      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16b94c31_ac1e_45ef_94c9_d7b237c32517.slice/cri-containerd-64f3b2efdbf0a07f7d8b6aaf9ece6e8a9e3e122e006c9b3e2a46829659a88f60.scope
    625      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16b94c31_ac1e_45ef_94c9_d7b237c32517.slice/cri-containerd-e4ad652fbc580f726bbc5c6c990607c46bbd3847e640b69693e139e86c32f95d.scope
    601      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16b94c31_ac1e_45ef_94c9_d7b237c32517.slice/cri-containerd-9bdab8eb93caeef854e277b787cc5eb253fc47a582977fb2733eaeedadde0fb3.scope
    617      cgroup_device   multi                                          
