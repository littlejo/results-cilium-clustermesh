USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         671  0.0  0.2 1616264 8848 ?        Ssl  10:28   0:00 /usr/sbin/runc init
root         665  0.0  0.2 1616264 8820 ?        Ssl  10:28   0:00 /usr/sbin/runc init
root         638  0.0  0.4 1240176 16348 ?       Rsl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         678  0.0  0.0   6408  1648 ?        R    10:28   0:00  \_ ps auxfw
root           1  3.5  7.0 1537844 276828 ?      Ssl  10:19   0:18 cilium-agent --config-dir=/tmp/cilium/config-map
root         389  0.0  0.1 1228848 5520 ?        Sl   10:19   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
