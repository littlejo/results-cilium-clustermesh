fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc076dcbb360c8 proto kernel metric 256 pref medium
fe80::/64 dev lxc25e19c16049e proto kernel metric 256 pref medium
fe80::/64 dev lxce410ec453546 proto kernel metric 256 pref medium
