KEY             VALUE
AgentLiveness   582219470481
UTimeOffset     3378616294921875
