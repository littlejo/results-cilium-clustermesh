Endpoint ID: 83
Path: /sys/fs/bpf/tc/globals/cilium_policy_00083

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    49453   568       0        
Allow    Egress      0          ANY          NONE         disabled    11410   114       0        


Endpoint ID: 304
Path: /sys/fs/bpf/tc/globals/cilium_policy_00304

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 451
Path: /sys/fs/bpf/tc/globals/cilium_policy_00451

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3394432   31631     0        
Allow    Ingress     1          ANY          NONE         disabled    2671831   26622     0        
Allow    Egress      0          ANY          NONE         disabled    3132962   30081     0        


Endpoint ID: 1575
Path: /sys/fs/bpf/tc/globals/cilium_policy_01575

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    49154   565       0        
Allow    Egress      0          ANY          NONE         disabled    11617   115       0        


Endpoint ID: 1871
Path: /sys/fs/bpf/tc/globals/cilium_policy_01871

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    388126   4933      0        
Allow    Ingress     1          ANY          NONE         disabled    6896     80        0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


