top - 10:28:41 up 9 min,  0 users,  load average: 0.05, 0.17, 0.15
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 45.2 us, 29.0 sy,  0.0 ni, 25.8 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1204.1 free,    875.8 used,   1756.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2792.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1537844 282028  80432 R  26.7   7.2   0:18.97 cilium-+
    638 root      20   0 1240176  16348  11352 S   6.7   0.4   0:00.03 cilium-+
    389 root      20   0 1228848   5520   2864 S   0.0   0.1   0:00.26 cilium-+
    692 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    704 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    705 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    729 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
