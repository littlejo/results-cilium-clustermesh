IP ADDRESS         LOCAL ENDPOINT INFO
10.108.0.127:0     id=1871  sec_id=4     flags=0x0000 ifindex=7   mac=5A:CA:EA:A9:2A:57 nodemac=AE:91:B0:68:29:E0     
172.31.173.246:0   (localhost)                                                                                        
10.108.0.89:0      id=451   sec_id=7187788 flags=0x0000 ifindex=15  mac=86:7D:5D:6B:0D:D0 nodemac=92:34:8B:6E:B9:D2   
10.108.0.5:0       (localhost)                                                                                        
10.108.0.171:0     id=83    sec_id=7180185 flags=0x0000 ifindex=11  mac=0E:E1:6F:7C:18:A4 nodemac=A6:6D:34:05:64:19   
10.108.0.40:0      id=1575  sec_id=7180185 flags=0x0000 ifindex=9   mac=86:DF:D6:47:8C:6C nodemac=26:CF:6C:08:16:56   
