ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.206.125:443 (active)    
                                         2 => 172.31.154.7:443 (active)      
2    10.100.170.236:443   ClusterIP      1 => 172.31.173.246:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.108.0.40:53 (active)        
                                         2 => 10.108.0.171:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.108.0.40:9153 (active)      
                                         2 => 10.108.0.171:9153 (active)     
5    10.100.31.153:2379   ClusterIP      1 => 10.108.0.89:2379 (active)      
