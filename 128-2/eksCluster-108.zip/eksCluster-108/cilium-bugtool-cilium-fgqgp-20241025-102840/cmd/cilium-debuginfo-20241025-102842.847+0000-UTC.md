# Cilium debug information

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.206.125:443 (active)    
                                         2 => 172.31.154.7:443 (active)      
2    10.100.170.236:443   ClusterIP      1 => 172.31.173.246:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.108.0.40:53 (active)        
                                         2 => 10.108.0.171:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.108.0.40:9153 (active)      
                                         2 => 10.108.0.171:9153 (active)     
5    10.100.31.153:2379   ClusterIP      1 => 10.108.0.89:2379 (active)      
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37790805                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37790805                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37790805                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d800000 rw-p 00000000 00:00 0 
400d800000-4010000000 ---p 00000000 00:00 0 
ffff5b573000-ffff5b799000 rw-p 00000000 00:00 0 
ffff5b7a1000-ffff5b882000 rw-p 00000000 00:00 0 
ffff5b882000-ffff5b8c3000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5b8c3000-ffff5b904000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5b904000-ffff5b944000 rw-p 00000000 00:00 0 
ffff5b944000-ffff5b946000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5b946000-ffff5b948000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5b948000-ffff5beef000 rw-p 00000000 00:00 0 
ffff5beef000-ffff5bfef000 rw-p 00000000 00:00 0 
ffff5bfef000-ffff5c000000 rw-p 00000000 00:00 0 
ffff5c000000-ffff5e000000 rw-p 00000000 00:00 0 
ffff5e000000-ffff5e080000 ---p 00000000 00:00 0 
ffff5e080000-ffff5e081000 rw-p 00000000 00:00 0 
ffff5e081000-ffff7e080000 ---p 00000000 00:00 0 
ffff7e080000-ffff7e081000 rw-p 00000000 00:00 0 
ffff7e081000-ffff9e010000 ---p 00000000 00:00 0 
ffff9e010000-ffff9e011000 rw-p 00000000 00:00 0 
ffff9e011000-ffffa2002000 ---p 00000000 00:00 0 
ffffa2002000-ffffa2003000 rw-p 00000000 00:00 0 
ffffa2003000-ffffa2800000 ---p 00000000 00:00 0 
ffffa2800000-ffffa2801000 rw-p 00000000 00:00 0 
ffffa2801000-ffffa2900000 ---p 00000000 00:00 0 
ffffa2900000-ffffa2960000 rw-p 00000000 00:00 0 
ffffa2960000-ffffa2962000 r--p 00000000 00:00 0                          [vvar]
ffffa2962000-ffffa2963000 r-xp 00000000 00:00 0                          [vdso]
fffffccca000-fffffcceb000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.108.0.5": (string) (len=6) "router",
  (string) (len=12) "10.108.0.127": (string) (len=6) "health",
  (string) (len=11) "10.108.0.40": (string) (len=35) "kube-system/coredns-cc6ccd49c-mkwj5",
  (string) (len=12) "10.108.0.171": (string) (len=35) "kube-system/coredns-cc6ccd49c-ww7st",
  (string) (len=11) "10.108.0.89": (string) (len=50) "kube-system/clustermesh-apiserver-6f6fdbfccf-6vsps"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.173.246": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40012f91e0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40013b2480,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40013b2480,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40020908f0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40029dafd0)(frontends:[10.100.31.153]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000a7bb80)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000a7bc30)(frontends:[10.100.170.236]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000a7bd90)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000c9dbe8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x400317eb60)(172.31.154.7:443/TCP,172.31.206.125:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000c9dbf0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-drjvf": (*k8s.Endpoints)(0x4002a56820)(172.31.173.246:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000c9dc00)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-jdvgs": (*k8s.Endpoints)(0x4002b7b450)(10.108.0.171:53/TCP[eu-west-3a],10.108.0.171:53/UDP[eu-west-3a],10.108.0.171:9153/TCP[eu-west-3a],10.108.0.40:53/TCP[eu-west-3a],10.108.0.40:53/UDP[eu-west-3a],10.108.0.40:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001a40768)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-cx5rb": (*k8s.Endpoints)(0x400344c820)(10.108.0.89:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400184fd50)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4001c77680)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40081d6ee8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40008970e0,
  gcExited: (chan struct {}) 0x4000897140,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40019a3800)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001a17208)({
      MetricVec: (*prometheus.MetricVec)(0x4001bbbc20)({
       metricMap: (*prometheus.metricMap)(0x4001bbbc50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8d6e0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40019a3880)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001a17210)({
      MetricVec: (*prometheus.MetricVec)(0x4001bbbcb0)({
       metricMap: (*prometheus.metricMap)(0x4001bbbce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8d740)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40019a3900)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a17218)({
      MetricVec: (*prometheus.MetricVec)(0x4001bbbd40)({
       metricMap: (*prometheus.metricMap)(0x4001bbbd70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8d7a0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40019a3980)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a17220)({
      MetricVec: (*prometheus.MetricVec)(0x4001bbbdd0)({
       metricMap: (*prometheus.metricMap)(0x4001bbbe00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8d800)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40019a3a00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a17228)({
      MetricVec: (*prometheus.MetricVec)(0x4001bbbe60)({
       metricMap: (*prometheus.metricMap)(0x4001bbbe90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8d860)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40019a3a80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a17230)({
      MetricVec: (*prometheus.MetricVec)(0x4001bbbef0)({
       metricMap: (*prometheus.metricMap)(0x4001bbbf20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001bd2000)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40019a3b00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a17238)({
      MetricVec: (*prometheus.MetricVec)(0x4001bd4000)({
       metricMap: (*prometheus.metricMap)(0x4001bd4030)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001bd2060)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40019a3b80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a17240)({
      MetricVec: (*prometheus.MetricVec)(0x4001bd4090)({
       metricMap: (*prometheus.metricMap)(0x4001bd40c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001bd20c0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40019a3c00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001a17248)({
      MetricVec: (*prometheus.MetricVec)(0x4001bd4120)({
       metricMap: (*prometheus.metricMap)(0x4001bd4150)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001bd2120)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400184fd50)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001370fc0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40010b8b40)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 386ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   },
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium environment keys

```
bgp-config-path:/var/lib/cilium/bgp/config.yaml
clustermesh-config:/var/lib/cilium/clustermesh/
dnsproxy-enable-transparent-mode:true
kvstore:
enable-envoy-config:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
tunnel-port:0
l2-announcements-lease-duration:15s
cni-external-routing:false
http-retry-timeout:0
enable-local-node-route:true
bgp-announce-lb-ip:false
local-router-ipv4:
enable-metrics:true
install-iptables-rules:true
enable-l2-announcements:false
enable-auto-protect-node-port-range:true
tofqdns-proxy-response-max-delay:100ms
enable-gateway-api:false
direct-routing-skip-unreachable:false
l2-announcements-renew-deadline:5s
enable-pmtu-discovery:false
fixed-identity-mapping:
ipam:cluster-pool
k8s-client-connection-timeout:30s
bpf-filter-priority:1
bpf-lb-sock:false
enable-health-check-loadbalancer-ip:false
cluster-health-port:4240
set-cilium-node-taints:true
enable-host-port:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-wireguard-userspace-fallback:false
use-cilium-internal-ip-for-ipsec:false
trace-payloadlen:128
enable-sctp:false
mesh-auth-enabled:true
bpf-ct-timeout-regular-tcp-fin:10s
bpf-lb-source-range-map-max:0
install-no-conntrack-iptables-rules:false
exclude-node-label-patterns:
procfs:/host/proc
proxy-gid:1337
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
bpf-lb-affinity-map-max:0
enable-ipv4-masquerade:true
dnsproxy-concurrency-limit:0
ipam-default-ip-pool:default
hubble-prefer-ipv6:false
cluster-id:109
state-dir:/var/run/cilium
hubble-socket-path:/var/run/cilium/hubble.sock
enable-xdp-prefilter:false
external-envoy-proxy:true
hubble-redact-enabled:false
node-port-mode:snat
ipv6-range:auto
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-ipv6-big-tcp:false
config-sources:config-map:kube-system/cilium-config
hubble-recorder-storage-path:/var/run/cilium/pcaps
mtu:0
use-full-tls-context:false
exclude-local-address:
k8s-namespace:kube-system
hubble-flowlogs-config-path:
l2-pod-announcements-interface:
enable-host-legacy-routing:false
bpf-ct-global-tcp-max:524288
enable-ipv6-masquerade:true
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-health-checking:true
vtep-cidr:
hubble-disable-tls:false
hubble-export-file-path:
keep-config:false
tofqdns-min-ttl:0
k8s-client-qps:10
enable-ipv4:true
hubble-export-file-max-size-mb:10
identity-heartbeat-timeout:30m0s
proxy-prometheus-port:0
enable-endpoint-routes:false
ingress-secrets-namespace:
enable-hubble-recorder-api:true
k8s-kubeconfig-path:
container-ip-local-reserved-ports:auto
bpf-events-trace-enabled:true
hubble-listen-address::4244
allow-localhost:auto
nat-map-stats-interval:30s
ipv6-native-routing-cidr:
bpf-ct-timeout-service-any:1m0s
envoy-config-retry-interval:15s
dnsproxy-socket-linger-timeout:10
bpf-lb-mode:snat
mesh-auth-spiffe-trust-domain:spiffe.cilium
disable-envoy-version-check:false
log-opt:
enable-bpf-clock-probe:false
proxy-max-connection-duration-seconds:0
cmdref:
route-metric:0
bpf-lb-map-max:65536
k8s-service-proxy-name:
bpf-lb-service-map-max:0
disable-external-ip-mitigation:false
enable-route-mtu-for-cni-chaining:false
ipam-cilium-node-update-rate:15s
bpf-lb-rss-ipv6-src-cidr:
envoy-secrets-namespace:
monitor-aggregation-interval:5s
ipv4-node:auto
allocator-list-timeout:3m0s
tofqdns-proxy-port:0
wireguard-persistent-keepalive:0s
enable-active-connection-tracking:false
enable-ipv6:false
bpf-nat-global-max:524288
enable-endpoint-health-checking:true
nodes-gc-interval:5m0s
tofqdns-enable-dns-compression:true
proxy-xff-num-trusted-hops-egress:0
cluster-pool-ipv4-mask-size:24
monitor-aggregation:medium
enable-identity-mark:true
enable-ip-masq-agent:false
enable-k8s-endpoint-slice:true
enable-srv6:false
enable-bandwidth-manager:false
egress-masquerade-interfaces:ens+
bpf-map-dynamic-size-ratio:0.0025
prometheus-serve-addr:
ipv6-mcast-device:
vlan-bpf-bypass:
kvstore-max-consecutive-quorum-errors:2
hubble-metrics:
hubble-event-buffer-capacity:4095
ipv4-pod-subnets:
debug:false
restore:true
mesh-auth-gc-interval:5m0s
enable-service-topology:false
bpf-lb-external-clusterip:false
enable-node-port:false
prepend-iptables-chains:true
clustermesh-enable-endpoint-sync:false
hubble-export-allowlist:
envoy-base-id:0
bpf-ct-timeout-regular-tcp:2h13m20s
hubble-drop-events-reasons:auth_required,policy_denied
enable-bpf-masquerade:false
bpf-lb-acceleration:disabled
allow-icmp-frag-needed:true
enable-nat46x64-gateway:false
hubble-monitor-events:
bpf-lb-maglev-table-size:16381
identity-gc-interval:15m0s
remove-cilium-node-taints:true
enable-bgp-control-plane:false
kube-proxy-replacement-healthz-bind-address:
cni-chaining-mode:none
enable-session-affinity:false
bgp-announce-pod-cidr:false
enable-high-scale-ipcache:false
cni-log-file:/var/run/cilium/cilium-cni.log
bpf-fragments-map-max:8192
bpf-ct-timeout-service-tcp-grace:1m0s
identity-allocation-mode:crd
identity-restore-grace-period:30s
clustermesh-enable-mcs-api:false
derive-masq-ip-addr-from-device:
k8s-sync-timeout:3m0s
version:false
certificates-directory:/var/run/cilium/certs
kvstore-periodic-sync:5m0s
http-normalize-path:true
tofqdns-endpoint-max-ip-per-hostname:50
encryption-strict-mode-allow-remote-node-identities:false
cflags:
operator-api-serve-addr:127.0.0.1:9234
enable-external-ips:false
dns-max-ips-per-restored-rule:1000
ipsec-key-rotation-duration:5m0s
enable-stale-cilium-endpoint-cleanup:true
enable-svc-source-range-check:true
controller-group-metrics:
enable-recorder:false
hubble-metrics-server:
proxy-portrange-max:20000
enable-xt-socket-fallback:true
enable-ingress-controller:false
iptables-random-fully:false
policy-trigger-interval:1s
enable-encryption-strict-mode:false
multicast-enabled:false
proxy-connect-timeout:2
kube-proxy-replacement:false
join-cluster:false
dnsproxy-insecure-skip-transparent-mode-check:false
cgroup-root:/run/cilium/cgroupv2
hubble-export-fieldmask:
bpf-ct-timeout-regular-tcp-syn:1m0s
auto-create-cilium-node-resource:true
auto-direct-node-routes:false
preallocate-bpf-maps:false
node-port-range:
enable-l2-neigh-discovery:true
enable-unreachable-routes:false
unmanaged-pod-watcher-interval:15
bypass-ip-availability-upon-restore:false
envoy-config-timeout:2m0s
proxy-xff-num-trusted-hops-ingress:0
enable-masquerade-to-route-source:false
datapath-mode:veth
enable-policy:default
enable-vtep:false
egress-multi-home-ip-rule-compat:false
enable-ipv6-ndp:false
enable-host-firewall:false
bpf-ct-global-any-max:262144
gops-port:9890
dnsproxy-concurrency-processing-grace-period:0s
endpoint-queue-size:25
proxy-portrange-min:10000
k8s-client-connection-keep-alive:30s
hubble-drop-events-interval:2m0s
k8s-require-ipv6-pod-cidr:false
endpoint-bpf-prog-watchdog-interval:30s
debug-verbose:
enable-ipip-termination:false
bpf-lb-sock-hostns-only:false
set-cilium-is-up-condition:true
hubble-skip-unknown-cgroup-ids:true
encryption-strict-mode-cidr:
hubble-export-denylist:
enable-cilium-health-api-server-access:
tofqdns-pre-cache:
enable-tracing:false
enable-wireguard:false
k8s-heartbeat-timeout:30s
enable-ipsec:false
enable-icmp-rules:true
mesh-auth-signal-backoff-duration:1s
policy-audit-mode:false
enable-ipv4-big-tcp:false
bpf-map-event-buffers:
enable-k8s-terminating-endpoint:true
http-retry-count:3
operator-prometheus-serve-addr::9963
hubble-drop-events:false
pprof-address:localhost
ipv6-service-range:auto
bpf-node-map-max:16384
clustermesh-sync-timeout:1m0s
cluster-name:cmesh109
vtep-mac:
local-max-addr-scope:252
mesh-auth-rotated-identities-queue-size:1024
max-connected-clusters:255
cilium-endpoint-gc-interval:5m0s
tofqdns-idle-connection-grace-period:0s
nat-map-stats-entries:32
nodeport-addresses:
routing-mode:tunnel
arping-refresh-period:30s
api-rate-limit:
mesh-auth-mutual-listener-port:0
l2-announcements-retry-period:2s
k8s-client-burst:20
enable-ipsec-xfrm-state-caching:true
tunnel-protocol:vxlan
bpf-lb-rss-ipv4-src-cidr:
bpf-ct-timeout-regular-any:1m0s
bpf-lb-rev-nat-map-max:0
cni-exclusive:true
vtep-mask:
ipv6-pod-subnets:
annotate-k8s-node:false
local-router-ipv6:
hubble-redact-http-headers-deny:
mesh-auth-mutual-connect-timeout:5s
clustermesh-ip-identities-sync-timeout:1m0s
bpf-sock-rev-map-max:262144
bpf-policy-map-max:16384
ipsec-key-file:
max-controller-interval:0
synchronize-k8s-nodes:true
enable-cilium-endpoint-slice:false
disable-iptables-feeder-rules:
cluster-pool-ipv4-cidr:10.108.0.0/16
enable-ipv4-fragment-tracking:true
enable-k8s-networkpolicy:true
policy-queue-size:100
enable-tcx:true
hubble-recorder-sink-queue-size:1024
monitor-aggregation-flags:all
tofqdns-dns-reject-response-code:refused
mke-cgroup-mount:
bpf-lb-dsr-dispatch:opt
enable-hubble:true
hubble-redact-http-userinfo:true
gateway-api-secrets-namespace:
pprof-port:6060
enable-runtime-device-detection:true
enable-health-check-nodeport:true
enable-local-redirect-policy:false
bpf-ct-timeout-service-tcp:2h13m20s
bpf-neigh-global-max:524288
bpf-lb-algorithm:random
enable-bpf-tproxy:false
ipv4-service-range:auto
http-request-timeout:3600
max-internal-timer-delay:0s
bpf-lb-maglev-map-max:0
k8s-api-server:
enable-l2-pod-announcements:false
dnsproxy-lock-count:131
lib-dir:/var/lib/cilium
policy-accounting:true
k8s-require-ipv4-pod-cidr:false
enable-monitor:true
disable-endpoint-crd:false
config:
srv6-encap-mode:reduced
agent-health-port:9879
egress-gateway-reconciliation-trigger-interval:1s
service-no-backend-response:reject
k8s-service-cache-size:128
iptables-lock-timeout:5s
static-cnp-path:
fqdn-regex-compile-lru-size:1024
egress-gateway-policy-map-max:16384
metrics:
enable-l7-proxy:true
bpf-lb-sock-terminate-pod-connections:false
ipv6-cluster-alloc-cidr:f00d::/64
node-port-bind-protection:true
devices:
enable-mke:false
bpf-lb-service-backend-map-max:0
pprof:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
vtep-endpoint:
dns-policy-unload-on-shutdown:false
monitor-queue-size:0
http-idle-timeout:0
identity-change-grace-period:5s
kvstore-opt:
node-port-algorithm:random
read-cni-conf:
ipv4-range:auto
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-k8s:true
conntrack-gc-interval:0s
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
kvstore-connectivity-timeout:2m0s
bpf-events-policy-verdict-enabled:true
hubble-redact-http-urlquery:false
config-dir:/tmp/cilium/config-map
endpoint-gc-interval:5m0s
node-labels:
agent-labels:
enable-well-known-identities:false
ipv6-node:auto
dnsproxy-lock-timeout:500ms
bpf-events-drop-enabled:true
proxy-max-requests-per-connection:0
enable-cilium-api-server-access:
socket-path:/var/run/cilium/cilium.sock
kvstore-lease-ttl:15m0s
encrypt-node:false
ipam-multi-pool-pre-allocation:
label-prefix-file:
labels:
direct-routing-device:
hubble-redact-kafka-apikey:false
enable-node-selector-labels:false
enable-custom-calls:false
enable-ipsec-key-watcher:true
bpf-policy-map-full-reconciliation-interval:15m0s
ipv4-service-loopback-address:169.254.42.1
bpf-lb-dsr-l4-xlate:frontend
cni-chaining-target:
encrypt-interface:
envoy-keep-cap-netbindservice:false
proxy-idle-timeout-seconds:60
bpf-root:/sys/fs/bpf
force-device-detection:false
enable-ipv4-egress-gateway:false
crd-wait-timeout:5m0s
bpf-auth-map-max:524288
conntrack-gc-max-interval:0s
enable-ipsec-encrypted-overlay:false
hubble-redact-http-headers-allow:
node-port-acceleration:disabled
policy-cidr-match-mode:
custom-cni-conf:false
log-driver:
proxy-admin-port:0
tofqdns-max-deferred-connection-deletes:10000
mesh-auth-spire-admin-socket:
trace-sock:true
log-system-load:false
enable-k8s-api-discovery:false
envoy-log:
agent-liveness-update-interval:1s
hubble-export-file-max-backups:5
http-max-grpc-timeout:0
hubble-event-queue-size:0
enable-bbr:false
mesh-auth-queue-size:1024
ipv4-native-routing-cidr:
hubble-export-file-compress:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
83         Disabled           Disabled          7180185    k8s:eks.amazonaws.com/component=coredns                                             10.108.0.171   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh109                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
304        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                 
                                                           reserved:host                                                                                              
451        Disabled           Disabled          7187788    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.108.0.89    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh109                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
1575       Disabled           Disabled          7180185    k8s:eks.amazonaws.com/component=coredns                                             10.108.0.40    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh109                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
1871       Disabled           Disabled          4          reserved:health                                                                     10.108.0.127   ready   
```

#### BPF Policy Get 83

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    48424   556       0        
Allow    Egress      0          ANY          NONE         disabled    11410   114       0        

```


#### BPF CT List 83

```
Invalid argument: unknown type 83
```


#### Endpoint Get 83

```
[
  {
    "id": 83,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-83-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "04150338-261b-41f6-839e-136a82b2ac44"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-83",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:53.249Z",
            "success-count": 2
          },
          "uuid": "30984fdc-db1c-4327-8a66-ce7bc7e5b373"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-ww7st",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:53.248Z",
            "success-count": 1
          },
          "uuid": "f1d2e083-21a7-41c9-86db-3f682fb5faed"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-83",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:56.010Z",
            "success-count": 1
          },
          "uuid": "6a4e36ff-16a8-4461-83e5-ee3e567a98d3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (83)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:33.295Z",
            "success-count": 54
          },
          "uuid": "44a691ea-ade3-475d-86a6-7f4fb8b314fa"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "a3bfd771480089f0c0a8deebe66ad1efd1a3cd22392d68f9c0f6851439ce337a:eth0",
        "container-id": "a3bfd771480089f0c0a8deebe66ad1efd1a3cd22392d68f9c0f6851439ce337a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-ww7st",
        "pod-name": "kube-system/coredns-cc6ccd49c-ww7st"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7180185,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:33Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.171",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a6:6d:34:05:64:19",
        "interface-index": 11,
        "interface-name": "lxc25e19c16049e",
        "mac": "0e:e1:6f:7c:18:a4"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7180185,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7180185,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 83

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 83

```
Timestamp              Status   State                   Message
2024-10-25T10:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:33Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:20:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:20:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:20:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:20:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:20:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:20:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:20:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:20:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:19:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:19:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:19:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:19:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:19:53Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:19:53Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7180185

```
ID        LABELS
7180185   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh109
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 304

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 304

```
Invalid argument: unknown type 304
```


#### Endpoint Get 304

```
[
  {
    "id": 304,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-304-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "93c96f32-a93f-482a-8bd7-8b1d781706d3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-304",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:51.757Z",
            "success-count": 2
          },
          "uuid": "41689ceb-113a-4735-a377-18e7c2ef84ab"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-304",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:52.813Z",
            "success-count": 1
          },
          "uuid": "fde06132-4d77-4407-b9da-5a779c68e469"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:33Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "1e:8c:4c:fb:ce:40",
        "interface-name": "cilium_host",
        "mac": "1e:8c:4c:fb:ce:40"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 304

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 304

```
Timestamp              Status   State                   Message
2024-10-25T10:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:33Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:20:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:20:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:20:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:20:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:20:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:20:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:20:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:20:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:19:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:19:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:19:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:51Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:19:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:19:51Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:19:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 451

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3123254   29987     0        
Allow    Ingress     1          ANY          NONE         disabled    2625857   26114     0        
Allow    Egress      0          ANY          NONE         disabled    2938517   28871     0        

```


#### BPF CT List 451

```
Invalid argument: unknown type 451
```


#### Endpoint Get 451

```
[
  {
    "id": 451,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-451-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e4a2af28-3ed4-4369-80ed-5a0de778b669"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-451",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:02.765Z",
            "success-count": 2
          },
          "uuid": "222ff5b4-fd30-4109-b307-897077526e08"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6f6fdbfccf-6vsps",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:02.764Z",
            "success-count": 1
          },
          "uuid": "94547c9e-b982-41b2-8032-bc3b793f9f39"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-451",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:02.801Z",
            "success-count": 1
          },
          "uuid": "c71c1f73-3417-400d-b94c-683d8c163630"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (451)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:42.809Z",
            "success-count": 36
          },
          "uuid": "0af93120-2a50-47b5-9627-b2b8612658e4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "4629c1ae1832acb0f7b6179690ee6b27844f9762638033ccd2242e3ff3c06c3d:eth0",
        "container-id": "4629c1ae1832acb0f7b6179690ee6b27844f9762638033ccd2242e3ff3c06c3d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6f6fdbfccf-6vsps",
        "pod-name": "kube-system/clustermesh-apiserver-6f6fdbfccf-6vsps"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7187788,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6f6fdbfccf"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:33Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.89",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "92:34:8b:6e:b9:d2",
        "interface-index": 15,
        "interface-name": "lxce410ec453546",
        "mac": "86:7d:5d:6b:0d:d0"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7187788,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7187788,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 451

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 451

```
Timestamp              Status   State                   Message
2024-10-25T10:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:33Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:02Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:23:02Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:23:02Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7187788

```
ID        LABELS
7187788   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh109
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1575

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    49154   565       0        
Allow    Egress      0          ANY          NONE         disabled    11617   115       0        

```


#### BPF CT List 1575

```
Invalid argument: unknown type 1575
```


#### Endpoint Get 1575

```
[
  {
    "id": 1575,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1575-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "791c25ea-c680-4dbe-bf59-1698194c0b0e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1575",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:53.184Z",
            "success-count": 2
          },
          "uuid": "fc8656d5-f8c1-42a7-9993-4481a437a11f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-mkwj5",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:53.183Z",
            "success-count": 1
          },
          "uuid": "034dbae9-9c2d-4631-9c04-c19be450c666"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1575",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:55.935Z",
            "success-count": 1
          },
          "uuid": "9c9700b3-980e-4032-8285-af28d96dcc41"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1575)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:43.250Z",
            "success-count": 55
          },
          "uuid": "9eb74d58-c144-42b6-9a4c-57b68cf8ea7d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3de71914f21047ce73324d9ef801b8b997bfb9d452c21ce275d27cd05b19b0cc:eth0",
        "container-id": "3de71914f21047ce73324d9ef801b8b997bfb9d452c21ce275d27cd05b19b0cc",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-mkwj5",
        "pod-name": "kube-system/coredns-cc6ccd49c-mkwj5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7180185,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh109",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:33Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.40",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "26:cf:6c:08:16:56",
        "interface-index": 9,
        "interface-name": "lxc076dcbb360c8",
        "mac": "86:df:d6:47:8c:6c"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7180185,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7180185,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1575

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1575

```
Timestamp              Status   State                   Message
2024-10-25T10:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:33Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:20:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:20:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:20:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:20:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:20:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:20:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:20:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:20:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:19:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:56Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:19:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:19:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:19:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:19:53Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:19:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:19:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:19:53Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:19:53Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7180185

```
ID        LABELS
7180185   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh109
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1871

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    384818   4889      0        
Allow    Ingress     1          ANY          NONE         disabled    6896     80        0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1871

```
Invalid argument: unknown type 1871
```


#### Endpoint Get 1871

```
[
  {
    "id": 1871,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1871-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "534d1265-033a-4159-9c39-c78d35e8766d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1871",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:52.824Z",
            "success-count": 2
          },
          "uuid": "2e2a75e9-bfbc-4e2f-96fb-d5b6a3cfde8a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1871",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:55.942Z",
            "success-count": 1
          },
          "uuid": "7324b9c1-1cd2-4160-af4a-3c4d8d9388d9"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:33Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.108.0.127",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ae:91:b0:68:29:e0",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "5a:ca:ea:a9:2a:57"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1871

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1871

```
Timestamp              Status   State                   Message
2024-10-25T10:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:33Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:20:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:20:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:20:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:20:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:20:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:20:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:20:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:20:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:19:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:19:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:19:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:52Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:19:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:19:52Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:19:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.108.0.0/24, 
Allocated addresses:
  10.108.0.127 (health)
  10.108.0.171 (kube-system/coredns-cc6ccd49c-ww7st)
  10.108.0.40 (kube-system/coredns-cc6ccd49c-mkwj5)
  10.108.0.5 (router)
  10.108.0.89 (kube-system/clustermesh-apiserver-6f6fdbfccf-6vsps)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c589cfcc6dc7f156
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    52s ago        never        0       no error   
  ct-map-pressure                                                     23s ago        never        0       no error   
  daemon-validate-config                                              45s ago        never        0       no error   
  dns-garbage-collector-job                                           55s ago        never        0       no error   
  endpoint-1575-regeneration-recovery                                 never          never        0       no error   
  endpoint-1871-regeneration-recovery                                 never          never        0       no error   
  endpoint-304-regeneration-recovery                                  never          never        0       no error   
  endpoint-451-regeneration-recovery                                  never          never        0       no error   
  endpoint-83-regeneration-recovery                                   never          never        0       no error   
  endpoint-gc                                                         3m55s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                23s ago        never        0       no error   
  ipcache-inject-labels                                               53s ago        never        0       no error   
  k8s-heartbeat                                                       25s ago        never        0       no error   
  link-cache                                                          8s ago         never        0       no error   
  local-identity-checkpoint                                           8m31s ago      never        0       no error   
  node-neighbor-link-updater                                          3s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m13s ago      never        0       no error   
  remote-etcd-cmesh10                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh100                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh101                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh102                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh103                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh104                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh105                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh106                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh107                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh108                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh11                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh110                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh111                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh112                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh113                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh114                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh115                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh116                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh117                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh118                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh119                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh12                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh120                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh121                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh122                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh123                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh124                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh125                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh126                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh127                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh128                                                5m13s ago      never        0       no error   
  remote-etcd-cmesh13                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh14                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh15                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh16                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh17                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh18                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh19                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh2                                                  5m13s ago      never        0       no error   
  remote-etcd-cmesh20                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh21                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh22                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh23                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh24                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh25                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh26                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh27                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh28                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh29                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh3                                                  5m13s ago      never        0       no error   
  remote-etcd-cmesh30                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh31                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh32                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh33                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh34                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh35                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh36                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh37                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh38                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh39                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh4                                                  5m13s ago      never        0       no error   
  remote-etcd-cmesh40                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh41                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh42                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh43                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh44                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh45                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh46                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh47                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh48                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh49                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh5                                                  5m13s ago      never        0       no error   
  remote-etcd-cmesh50                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh51                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh52                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh53                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh54                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh55                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh56                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh57                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh58                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh59                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh6                                                  5m13s ago      never        0       no error   
  remote-etcd-cmesh60                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh61                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh62                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh63                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh64                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh65                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh66                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh67                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh68                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh69                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh7                                                  5m13s ago      never        0       no error   
  remote-etcd-cmesh70                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh71                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh72                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh73                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh74                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh75                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh76                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh77                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh78                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh79                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh8                                                  5m13s ago      never        0       no error   
  remote-etcd-cmesh80                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh81                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh82                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh83                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh84                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh85                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh86                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh87                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh88                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh89                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh9                                                  5m13s ago      never        0       no error   
  remote-etcd-cmesh90                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh91                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh92                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh93                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh94                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh95                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh96                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh97                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh98                                                 5m13s ago      never        0       no error   
  remote-etcd-cmesh99                                                 5m13s ago      never        0       no error   
  resolve-identity-1575                                               3m51s ago      never        0       no error   
  resolve-identity-1871                                               3m52s ago      never        0       no error   
  resolve-identity-304                                                3m53s ago      never        0       no error   
  resolve-identity-451                                                42s ago        never        0       no error   
  resolve-identity-83                                                 3m51s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6f6fdbfccf-6vsps   5m42s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-mkwj5                  8m51s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-ww7st                  8m51s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      8m53s ago      never        0       no error   
  sync-policymap-1575                                                 8m49s ago      never        0       no error   
  sync-policymap-1871                                                 8m49s ago      never        0       no error   
  sync-policymap-304                                                  8m52s ago      never        0       no error   
  sync-policymap-451                                                  5m42s ago      never        0       no error   
  sync-policymap-83                                                   8m48s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1575)                                   11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (451)                                    12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (83)                                     11s ago        never        0       no error   
  sync-utime                                                          53s ago        never        0       no error   
  write-cni-file                                                      8m55s ago      never        0       no error   
Proxy Status:            OK, ip 10.108.0.5, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 7143424, max 7208959
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 92.28   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```
