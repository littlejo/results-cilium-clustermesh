CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d17d73c_0ad1_4822_9dd6_8c747e1fc0eb.slice/cri-containerd-6915048bb7d1bff10f5586fb92f9e4ba9e2f1b2f18927bbeea4bd0420058c703.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d17d73c_0ad1_4822_9dd6_8c747e1fc0eb.slice/cri-containerd-f683e0bb55c10c63de2408e6c3ebb448af796fe3a01b6c971994047579a2017e.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod804d8d4f_1def_4dcb_a773_cd4e7f02d81a.slice/cri-containerd-135b388f234b52fe9f782f99175a9598a0ef0e1110cf253d58c77850a8911874.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod804d8d4f_1def_4dcb_a773_cd4e7f02d81a.slice/cri-containerd-3de71914f21047ce73324d9ef801b8b997bfb9d452c21ce275d27cd05b19b0cc.scope
    489      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3266fdc1_77cb_4e0f_888a_46a971d691a7.slice/cri-containerd-a376bb8cbb15a6aadaa8fd40f2056298b3b0e3db7235ab89dc98623c59887050.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3266fdc1_77cb_4e0f_888a_46a971d691a7.slice/cri-containerd-d0655a35cc4a73ed594fb82f5509addfd986cbb7b8319e40da274d725c2e5b52.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd8c5a35_511a_49e5_88d8_02c9d266a4ea.slice/cri-containerd-a3bfd771480089f0c0a8deebe66ad1efd1a3cd22392d68f9c0f6851439ce337a.scope
    501      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd8c5a35_511a_49e5_88d8_02c9d266a4ea.slice/cri-containerd-76c687e6a431a574fad5da2ff9faa590b7e70965544f9cd72b7df7e9b9814a66.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c82082a_7d5a_4824_9b28_c28729269588.slice/cri-containerd-04c1bcdf6d919b6af23760c2fa8e3ded78d56b593b817fee0939c9d20e8c3bdf.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c82082a_7d5a_4824_9b28_c28729269588.slice/cri-containerd-cc386a5362d176dfa79c299b54c55f552355ca938301dde867d5da7dc20d09d5.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0daebb3f_a721_4287_aa28_f3a20648d510.slice/cri-containerd-ab3819c9a315b391a423b2b5b344f07c4a52cf322f00a6ce6cd4a75a54224dab.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0daebb3f_a721_4287_aa28_f3a20648d510.slice/cri-containerd-ff260b43949c9863562ad9c0195d0df6978499bc628e177d374f71b3168ba92f.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a548db5_4548_4899_946b_ec513d198deb.slice/cri-containerd-4629c1ae1832acb0f7b6179690ee6b27844f9762638033ccd2242e3ff3c06c3d.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a548db5_4548_4899_946b_ec513d198deb.slice/cri-containerd-47f60d281d131570ce775f22d55d78d2315b65c513ce2810175e6463604906dc.scope
    617      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a548db5_4548_4899_946b_ec513d198deb.slice/cri-containerd-ac9554ba09bf1c1e6a77e7d0b56362cf3c8ef5e366dedafbcf989bc7df659990.scope
    613      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a548db5_4548_4899_946b_ec513d198deb.slice/cri-containerd-69c1221bd38a1230d1781e7c261516f87c63dc73b139b8fea5fe203221c593f1.scope
    609      cgroup_device   multi                                          
