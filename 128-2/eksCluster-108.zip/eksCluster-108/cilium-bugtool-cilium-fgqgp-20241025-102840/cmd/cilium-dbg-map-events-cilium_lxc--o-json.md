{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:51.646Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.173.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:51.646Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:55.935Z",
  "value": "id=1575  sec_id=7180185 flags=0x0000 ifindex=9   mac=86:DF:D6:47:8C:6C nodemac=26:CF:6C:08:16:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:55.940Z",
  "value": "id=1871  sec_id=4     flags=0x0000 ifindex=7   mac=5A:CA:EA:A9:2A:57 nodemac=AE:91:B0:68:29:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:56.003Z",
  "value": "id=83    sec_id=7180185 flags=0x0000 ifindex=11  mac=0E:E1:6F:7C:18:A4 nodemac=A6:6D:34:05:64:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:56.089Z",
  "value": "id=1575  sec_id=7180185 flags=0x0000 ifindex=9   mac=86:DF:D6:47:8C:6C nodemac=26:CF:6C:08:16:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:56.131Z",
  "value": "id=1871  sec_id=4     flags=0x0000 ifindex=7   mac=5A:CA:EA:A9:2A:57 nodemac=AE:91:B0:68:29:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:20:10.831Z",
  "value": "id=1575  sec_id=7180185 flags=0x0000 ifindex=9   mac=86:DF:D6:47:8C:6C nodemac=26:CF:6C:08:16:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:20:10.831Z",
  "value": "id=1871  sec_id=4     flags=0x0000 ifindex=7   mac=5A:CA:EA:A9:2A:57 nodemac=AE:91:B0:68:29:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:20:10.831Z",
  "value": "id=83    sec_id=7180185 flags=0x0000 ifindex=11  mac=0E:E1:6F:7C:18:A4 nodemac=A6:6D:34:05:64:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:20:10.863Z",
  "value": "id=1615  sec_id=7187788 flags=0x0000 ifindex=13  mac=4E:3D:4F:5D:3F:2B nodemac=CE:D0:14:84:23:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:20:11.831Z",
  "value": "id=1871  sec_id=4     flags=0x0000 ifindex=7   mac=5A:CA:EA:A9:2A:57 nodemac=AE:91:B0:68:29:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:20:11.831Z",
  "value": "id=1615  sec_id=7187788 flags=0x0000 ifindex=13  mac=4E:3D:4F:5D:3F:2B nodemac=CE:D0:14:84:23:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:20:11.831Z",
  "value": "id=1575  sec_id=7180185 flags=0x0000 ifindex=9   mac=86:DF:D6:47:8C:6C nodemac=26:CF:6C:08:16:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:20:11.831Z",
  "value": "id=83    sec_id=7180185 flags=0x0000 ifindex=11  mac=0E:E1:6F:7C:18:A4 nodemac=A6:6D:34:05:64:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:02.800Z",
  "value": "id=451   sec_id=7187788 flags=0x0000 ifindex=15  mac=86:7D:5D:6B:0D:D0 nodemac=92:34:8B:6E:B9:D2"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.108.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.786Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.200Z",
  "value": "id=451   sec_id=7187788 flags=0x0000 ifindex=15  mac=86:7D:5D:6B:0D:D0 nodemac=92:34:8B:6E:B9:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.201Z",
  "value": "id=1871  sec_id=4     flags=0x0000 ifindex=7   mac=5A:CA:EA:A9:2A:57 nodemac=AE:91:B0:68:29:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.201Z",
  "value": "id=1575  sec_id=7180185 flags=0x0000 ifindex=9   mac=86:DF:D6:47:8C:6C nodemac=26:CF:6C:08:16:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.201Z",
  "value": "id=83    sec_id=7180185 flags=0x0000 ifindex=11  mac=0E:E1:6F:7C:18:A4 nodemac=A6:6D:34:05:64:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.201Z",
  "value": "id=1575  sec_id=7180185 flags=0x0000 ifindex=9   mac=86:DF:D6:47:8C:6C nodemac=26:CF:6C:08:16:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.201Z",
  "value": "id=451   sec_id=7187788 flags=0x0000 ifindex=15  mac=86:7D:5D:6B:0D:D0 nodemac=92:34:8B:6E:B9:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.201Z",
  "value": "id=1871  sec_id=4     flags=0x0000 ifindex=7   mac=5A:CA:EA:A9:2A:57 nodemac=AE:91:B0:68:29:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.201Z",
  "value": "id=83    sec_id=7180185 flags=0x0000 ifindex=11  mac=0E:E1:6F:7C:18:A4 nodemac=A6:6D:34:05:64:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.200Z",
  "value": "id=1871  sec_id=4     flags=0x0000 ifindex=7   mac=5A:CA:EA:A9:2A:57 nodemac=AE:91:B0:68:29:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.201Z",
  "value": "id=1575  sec_id=7180185 flags=0x0000 ifindex=9   mac=86:DF:D6:47:8C:6C nodemac=26:CF:6C:08:16:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.202Z",
  "value": "id=83    sec_id=7180185 flags=0x0000 ifindex=11  mac=0E:E1:6F:7C:18:A4 nodemac=A6:6D:34:05:64:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.202Z",
  "value": "id=451   sec_id=7187788 flags=0x0000 ifindex=15  mac=86:7D:5D:6B:0D:D0 nodemac=92:34:8B:6E:B9:D2"
}

