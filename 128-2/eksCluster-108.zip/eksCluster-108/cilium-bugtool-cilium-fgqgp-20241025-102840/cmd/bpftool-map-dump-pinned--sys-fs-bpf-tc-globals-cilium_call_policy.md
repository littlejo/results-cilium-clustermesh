key: 53 00 00 00  value: db 01 00 00
key: c3 01 00 00  value: 48 02 00 00
key: 27 06 00 00  value: e1 01 00 00
key: 4f 07 00 00  value: fd 01 00 00
Found 4 elements
