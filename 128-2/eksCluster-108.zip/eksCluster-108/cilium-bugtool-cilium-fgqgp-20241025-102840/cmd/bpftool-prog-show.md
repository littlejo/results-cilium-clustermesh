32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:19:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:19:07+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:19:08+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:19:08+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:19:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:19:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:19:08+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:19:08+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:19:13+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
64: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:19:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
444: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:19:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 112
445: sched_cls  name tail_handle_ipv4  tag b6fc2d78974b875c  gpl
	loaded_at 2024-10-25T10:19:53+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 113
446: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:19:53+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 114
447: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:19:53+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 115
470: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:19:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,97
	btf_id 141
471: sched_cls  name tail_ipv4_ct_egress  tag 5ab40777201672a1  gpl
	loaded_at 2024-10-25T10:19:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,97,74,75,98,76
	btf_id 142
472: sched_cls  name tail_ipv4_ct_ingress  tag efef90da23ce300e  gpl
	loaded_at 2024-10-25T10:19:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,97,74,75,98,76
	btf_id 143
473: sched_cls  name __send_drop_notify  tag 62f7eb4344a4c67a  gpl
	loaded_at 2024-10-25T10:19:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 144
474: sched_cls  name tail_handle_ipv4_cont  tag ef29017a89afda5f  gpl
	loaded_at 2024-10-25T10:19:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,98,33,96,74,75,31,68,66,69,97,32,29,30,73
	btf_id 145
475: sched_cls  name handle_policy  tag b82ec9ab378a0dc4  gpl
	loaded_at 2024-10-25T10:19:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,97,74,75,98,33,72,96,31,76,67,32,29,30
	btf_id 146
477: sched_cls  name tail_handle_arp  tag e99fcba04435e78c  gpl
	loaded_at 2024-10-25T10:19:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,97
	btf_id 148
478: sched_cls  name tail_handle_ipv4  tag aa2455fb1c74337a  gpl
	loaded_at 2024-10-25T10:19:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,97
	btf_id 149
479: sched_cls  name tail_ipv4_to_endpoint  tag 7acffadc47e61062  gpl
	loaded_at 2024-10-25T10:19:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,98,33,74,75,72,96,31,97,32,29,30
	btf_id 150
480: sched_cls  name cil_from_container  tag ad43ab52f6df66f3  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 97,68
	btf_id 151
481: sched_cls  name handle_policy  tag 862f79b1fac43c2d  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,100,74,75,99,33,72,90,31,76,67,32,29,30
	btf_id 153
482: sched_cls  name __send_drop_notify  tag 9f61190fd939dfbd  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 154
484: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 156
485: sched_cls  name tail_handle_ipv4  tag ec6e062feedefff0  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 157
486: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
489: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
490: sched_cls  name tail_handle_arp  tag 40fd909aa6077a67  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 158
491: sched_cls  name tail_ipv4_ct_ingress  tag 657bb8d274473236  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 159
492: sched_cls  name tail_handle_ipv4_cont  tag 81e271acff69f758  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,99,33,90,74,75,31,68,66,69,100,32,29,30,73
	btf_id 160
493: sched_cls  name tail_ipv4_to_endpoint  tag 163dc0d9c5fb892e  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,99,33,74,75,72,90,31,100,32,29,30
	btf_id 161
494: sched_cls  name tail_ipv4_ct_egress  tag 5ab40777201672a1  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 162
495: sched_cls  name cil_from_container  tag eece8db750ff6335  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,68
	btf_id 163
496: sched_cls  name tail_handle_arp  tag cb8a8a0edc0e0583  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,102
	btf_id 165
497: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
500: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,102,74,75,103,76
	btf_id 166
501: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
502: sched_cls  name __send_drop_notify  tag f19f5683b74f2787  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 167
503: sched_cls  name tail_handle_ipv4  tag 6789a8851022d6f4  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,102
	btf_id 168
504: sched_cls  name cil_from_container  tag 3e5cab240efcc5a9  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 102,68
	btf_id 169
505: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,102
	btf_id 170
507: sched_cls  name tail_handle_ipv4_cont  tag 32944b49d280ed09  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,103,33,91,74,75,31,68,66,69,102,32,29,30,73
	btf_id 172
508: sched_cls  name tail_ipv4_to_endpoint  tag b5c5df0ddd59ca3b  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,103,33,74,75,72,91,31,102,32,29,30
	btf_id 173
509: sched_cls  name handle_policy  tag 355fd2eb46c20402  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,102,74,75,103,33,72,91,31,76,67,32,29,30
	btf_id 174
510: sched_cls  name tail_ipv4_ct_ingress  tag 3bfd16e110bacd09  gpl
	loaded_at 2024-10-25T10:19:56+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,102,74,75,103,76
	btf_id 175
511: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 177
512: sched_cls  name __send_drop_notify  tag a80638b900d474cf  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 178
513: sched_cls  name tail_handle_ipv4_from_host  tag 580bc3884890d493  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,105
	btf_id 179
514: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,105
	btf_id 180
516: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,105
	btf_id 182
519: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 186
520: sched_cls  name __send_drop_notify  tag a80638b900d474cf  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 187
521: sched_cls  name tail_handle_ipv4_from_host  tag 580bc3884890d493  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,107
	btf_id 188
522: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,107
	btf_id 189
528: sched_cls  name __send_drop_notify  tag a80638b900d474cf  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 196
529: sched_cls  name tail_handle_ipv4_from_host  tag 580bc3884890d493  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 197
530: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 198
531: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,109,67
	btf_id 199
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
536: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
539: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
579: sched_cls  name tail_ipv4_to_endpoint  tag e787da32c9eab55e  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,124,33,74,75,72,123,31,125,32,29,30
	btf_id 215
580: sched_cls  name tail_ipv4_ct_egress  tag dada8d9ee4aabaf1  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,125,74,75,124,76
	btf_id 216
581: sched_cls  name __send_drop_notify  tag 7ec31b8440aa5105  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 217
582: sched_cls  name tail_ipv4_ct_ingress  tag b67e481546de478f  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,125,74,75,124,76
	btf_id 218
583: sched_cls  name tail_handle_ipv4  tag f9973d894a42bc71  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,125
	btf_id 219
584: sched_cls  name handle_policy  tag d9d9bbf331a99d77  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,125,74,75,124,33,72,123,31,76,67,32,29,30
	btf_id 220
585: sched_cls  name cil_from_container  tag b6d6790aa4db8749  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 125,68
	btf_id 221
587: sched_cls  name tail_handle_ipv4_cont  tag dcd1fd00173d9d1f  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,124,33,123,74,75,31,68,66,69,125,32,29,30,73
	btf_id 223
588: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,125
	btf_id 224
589: sched_cls  name tail_handle_arp  tag c811cdec1d86c187  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,125
	btf_id 225
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
606: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
609: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
610: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
613: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
614: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
617: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
