alloc: 93.63MB (98178184 bytes)
total-alloc: 1.22GB (1314651592 bytes)
sys: 210.13MB (220341588 bytes)
lookups: 0
mallocs: 46217688
frees: 45324786
heap-alloc: 93.63MB (98178184 bytes)
heap-sys: 165.88MB (173940736 bytes)
heap-idle: 45.97MB (48201728 bytes)
heap-in-use: 119.91MB (125739008 bytes)
heap-released: 9.38MB (9830400 bytes)
heap-objects: 892902
stack-in-use: 34.09MB (35749888 bytes)
stack-sys: 34.09MB (35749888 bytes)
stack-mspan-inuse: 1.96MB (2060320 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 685.07KB (701513 bytes)
gc-sys: 5.16MB (5411144 bytes)
next-gc: when heap-alloc >= 144.15MB (151156264 bytes)
last-gc: 2024-10-25 10:28:10.583624805 +0000 UTC
gc-pause-total: 17.855278ms
gc-pause: 57978
gc-pause-end: 1729852090583624805
num-gc: 70
num-forced-gc: 0
gc-cpu-fraction: 0.0005158630285608906
enable-gc: true
debug-gc: false
