markdown output at /tmp/cilium-bugtool-20241025-102841.579+0000-UTC-3155598467/cmd/cilium-debuginfo-20241025-102842.847+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.579+0000-UTC-3155598467/cmd/cilium-debuginfo-20241025-102842.847+0000-UTC.json
