[
  {
    "containers": [
      {
        "cgroup-id": 6818,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod804d8d4f_1def_4dcb_a773_cd4e7f02d81a.slice/cri-containerd-135b388f234b52fe9f782f99175a9598a0ef0e1110cf253d58c77850a8911874.scope"
      }
    ],
    "ips": [
      "10.108.0.40"
    ],
    "name": "coredns-cc6ccd49c-mkwj5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8330,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a548db5_4548_4899_946b_ec513d198deb.slice/cri-containerd-ac9554ba09bf1c1e6a77e7d0b56362cf3c8ef5e366dedafbcf989bc7df659990.scope"
      },
      {
        "cgroup-id": 8246,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a548db5_4548_4899_946b_ec513d198deb.slice/cri-containerd-69c1221bd38a1230d1781e7c261516f87c63dc73b139b8fea5fe203221c593f1.scope"
      },
      {
        "cgroup-id": 8414,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a548db5_4548_4899_946b_ec513d198deb.slice/cri-containerd-47f60d281d131570ce775f22d55d78d2315b65c513ce2810175e6463604906dc.scope"
      }
    ],
    "ips": [
      "10.108.0.89"
    ],
    "name": "clustermesh-apiserver-6f6fdbfccf-6vsps",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6902,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd8c5a35_511a_49e5_88d8_02c9d266a4ea.slice/cri-containerd-76c687e6a431a574fad5da2ff9faa590b7e70965544f9cd72b7df7e9b9814a66.scope"
      }
    ],
    "ips": [
      "10.108.0.171"
    ],
    "name": "coredns-cc6ccd49c-ww7st",
    "namespace": "kube-system"
  }
]

