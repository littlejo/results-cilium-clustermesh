REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     182367    94712897   1132   bpf_host.c
Interface                 INGRESS     8165      637838     677    bpf_overlay.c
Success                   EGRESS      3915      296270     1694   bpf_host.c
Success                   EGRESS      75951     10380647   1308   bpf_lxc.c
Success                   EGRESS      7858      614452     53     encap.h
Success                   INGRESS     86925     10349507   86     l3.h
Success                   INGRESS     91823     10734911   235    trace.h
Unsupported L3 protocol   EGRESS      34        2532       1492   bpf_lxc.c
