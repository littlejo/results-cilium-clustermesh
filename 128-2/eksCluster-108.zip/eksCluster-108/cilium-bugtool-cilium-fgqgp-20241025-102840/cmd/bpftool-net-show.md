xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 531
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 519
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 511
cilium_host(4) clsact/egress cil_from_host-cilium_host id 516
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 446
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 447
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 504
lxc076dcbb360c8(9) clsact/ingress cil_from_container-lxc076dcbb360c8 id 495
lxc25e19c16049e(11) clsact/ingress cil_from_container-lxc25e19c16049e id 480
lxce410ec453546(15) clsact/ingress cil_from_container-lxce410ec453546 id 585

flow_dissector:

netfilter:

