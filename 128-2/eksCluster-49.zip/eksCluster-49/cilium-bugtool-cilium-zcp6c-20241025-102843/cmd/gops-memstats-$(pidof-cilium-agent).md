alloc: 115.90MB (121528944 bytes)
total-alloc: 1.35GB (1452620736 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 48191393
frees: 46943559
heap-alloc: 115.90MB (121528944 bytes)
heap-sys: 161.29MB (169123840 bytes)
heap-idle: 27.44MB (28770304 bytes)
heap-in-use: 133.85MB (140353536 bytes)
heap-released: 40.00KB (40960 bytes)
heap-objects: 1247834
stack-in-use: 34.69MB (36372480 bytes)
stack-sys: 34.69MB (36372480 bytes)
stack-mspan-inuse: 2.22MB (2326400 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 915.83KB (937809 bytes)
gc-sys: 5.12MB (5372064 bytes)
next-gc: when heap-alloc >= 145.67MB (152743016 bytes)
last-gc: 2024-10-25 10:28:45.539272902 +0000 UTC
gc-pause-total: 6.534225ms
gc-pause: 58019
gc-pause-end: 1729852125539272902
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.0003526626209622729
enable-gc: true
debug-gc: false
