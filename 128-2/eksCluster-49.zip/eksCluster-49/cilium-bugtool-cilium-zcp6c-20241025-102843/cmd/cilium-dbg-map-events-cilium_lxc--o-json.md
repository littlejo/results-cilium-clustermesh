{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.066Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.231.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.066Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.246.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.066Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.450Z",
  "value": "id=113   sec_id=4     flags=0x0000 ifindex=10  mac=D2:52:73:17:9E:68 nodemac=9E:26:78:55:43:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.453Z",
  "value": "id=1545  sec_id=3281168 flags=0x0000 ifindex=12  mac=DA:E4:6E:5A:91:79 nodemac=D6:B2:C8:85:58:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.497Z",
  "value": "id=113   sec_id=4     flags=0x0000 ifindex=10  mac=D2:52:73:17:9E:68 nodemac=9E:26:78:55:43:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.498Z",
  "value": "id=1545  sec_id=3281168 flags=0x0000 ifindex=12  mac=DA:E4:6E:5A:91:79 nodemac=D6:B2:C8:85:58:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.507Z",
  "value": "id=706   sec_id=3281168 flags=0x0000 ifindex=14  mac=EA:1A:60:15:C4:A5 nodemac=8A:E5:B8:FA:53:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.865Z",
  "value": "id=113   sec_id=4     flags=0x0000 ifindex=10  mac=D2:52:73:17:9E:68 nodemac=9E:26:78:55:43:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.866Z",
  "value": "id=1545  sec_id=3281168 flags=0x0000 ifindex=12  mac=DA:E4:6E:5A:91:79 nodemac=D6:B2:C8:85:58:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.866Z",
  "value": "id=706   sec_id=3281168 flags=0x0000 ifindex=14  mac=EA:1A:60:15:C4:A5 nodemac=8A:E5:B8:FA:53:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.895Z",
  "value": "id=143   sec_id=3285871 flags=0x0000 ifindex=16  mac=C6:49:D4:44:74:A9 nodemac=3E:0A:D6:F0:09:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.866Z",
  "value": "id=1545  sec_id=3281168 flags=0x0000 ifindex=12  mac=DA:E4:6E:5A:91:79 nodemac=D6:B2:C8:85:58:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.866Z",
  "value": "id=143   sec_id=3285871 flags=0x0000 ifindex=16  mac=C6:49:D4:44:74:A9 nodemac=3E:0A:D6:F0:09:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.866Z",
  "value": "id=706   sec_id=3281168 flags=0x0000 ifindex=14  mac=EA:1A:60:15:C4:A5 nodemac=8A:E5:B8:FA:53:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.867Z",
  "value": "id=113   sec_id=4     flags=0x0000 ifindex=10  mac=D2:52:73:17:9E:68 nodemac=9E:26:78:55:43:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:12.547Z",
  "value": "id=809   sec_id=3285871 flags=0x0000 ifindex=18  mac=52:29:46:59:1C:21 nodemac=8A:D5:90:13:10:0B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.49.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:19.531Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.969Z",
  "value": "id=809   sec_id=3285871 flags=0x0000 ifindex=18  mac=52:29:46:59:1C:21 nodemac=8A:D5:90:13:10:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.971Z",
  "value": "id=113   sec_id=4     flags=0x0000 ifindex=10  mac=D2:52:73:17:9E:68 nodemac=9E:26:78:55:43:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.971Z",
  "value": "id=1545  sec_id=3281168 flags=0x0000 ifindex=12  mac=DA:E4:6E:5A:91:79 nodemac=D6:B2:C8:85:58:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.972Z",
  "value": "id=706   sec_id=3281168 flags=0x0000 ifindex=14  mac=EA:1A:60:15:C4:A5 nodemac=8A:E5:B8:FA:53:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.970Z",
  "value": "id=1545  sec_id=3281168 flags=0x0000 ifindex=12  mac=DA:E4:6E:5A:91:79 nodemac=D6:B2:C8:85:58:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.970Z",
  "value": "id=113   sec_id=4     flags=0x0000 ifindex=10  mac=D2:52:73:17:9E:68 nodemac=9E:26:78:55:43:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.970Z",
  "value": "id=706   sec_id=3281168 flags=0x0000 ifindex=14  mac=EA:1A:60:15:C4:A5 nodemac=8A:E5:B8:FA:53:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.971Z",
  "value": "id=809   sec_id=3285871 flags=0x0000 ifindex=18  mac=52:29:46:59:1C:21 nodemac=8A:D5:90:13:10:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.970Z",
  "value": "id=706   sec_id=3281168 flags=0x0000 ifindex=14  mac=EA:1A:60:15:C4:A5 nodemac=8A:E5:B8:FA:53:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.970Z",
  "value": "id=1545  sec_id=3281168 flags=0x0000 ifindex=12  mac=DA:E4:6E:5A:91:79 nodemac=D6:B2:C8:85:58:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.971Z",
  "value": "id=113   sec_id=4     flags=0x0000 ifindex=10  mac=D2:52:73:17:9E:68 nodemac=9E:26:78:55:43:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.971Z",
  "value": "id=809   sec_id=3285871 flags=0x0000 ifindex=18  mac=52:29:46:59:1C:21 nodemac=8A:D5:90:13:10:0B"
}

