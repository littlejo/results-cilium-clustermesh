key: 71 00 00 00  value: 1b 02 00 00
key: c2 02 00 00  value: 22 02 00 00
key: 29 03 00 00  value: 64 02 00 00
key: 09 06 00 00  value: 08 02 00 00
Found 4 elements
