IP ADDRESS         LOCAL ENDPOINT INFO
10.49.0.51:0       id=706   sec_id=3281168 flags=0x0000 ifindex=14  mac=EA:1A:60:15:C4:A5 nodemac=8A:E5:B8:FA:53:86   
10.49.0.34:0       id=809   sec_id=3285871 flags=0x0000 ifindex=18  mac=52:29:46:59:1C:21 nodemac=8A:D5:90:13:10:0B   
172.31.231.255:0   (localhost)                                                                                        
10.49.0.28:0       id=113   sec_id=4     flags=0x0000 ifindex=10  mac=D2:52:73:17:9E:68 nodemac=9E:26:78:55:43:91     
10.49.0.108:0      (localhost)                                                                                        
172.31.246.108:0   (localhost)                                                                                        
10.49.0.73:0       id=1545  sec_id=3281168 flags=0x0000 ifindex=12  mac=DA:E4:6E:5A:91:79 nodemac=D6:B2:C8:85:58:5D   
