[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod325dc416_7d6c_4880_a5db_71b1d02e65e3.slice/cri-containerd-8b9098bffd724c461267258eacefdca4a8e9566c1db3ea092e11a2b598ed25f4.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod325dc416_7d6c_4880_a5db_71b1d02e65e3.slice/cri-containerd-d8e5d0de834093d5b69fb16156f9af00165e25efbee2ce23b4ce76129ac14ae5.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod325dc416_7d6c_4880_a5db_71b1d02e65e3.slice/cri-containerd-6f2db35304a09730a7a77c623d485b810979f22415a5b2c416ece0a6ea1a47f7.scope"
      }
    ],
    "ips": [
      "10.49.0.34"
    ],
    "name": "clustermesh-apiserver-69949878cc-f7w7v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2b2258d_9586_4f33_a4cd_446e2bbd9057.slice/cri-containerd-ed04f42563b973b1a325c4b05cfcc9996dcf5ffb4f774216c6d472de27ec31c5.scope"
      }
    ],
    "ips": [
      "10.49.0.73"
    ],
    "name": "coredns-cc6ccd49c-sfk5f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99ecf9b9_4ab1_4ee3_bd75_dbbdba79c3e7.slice/cri-containerd-f6f2f4c7f863054928889a0c0c0ce02d403be0ce3532748c0ad516beb3e5f296.scope"
      }
    ],
    "ips": [
      "10.49.0.51"
    ],
    "name": "coredns-cc6ccd49c-f4s4k",
    "namespace": "kube-system"
  }
]

