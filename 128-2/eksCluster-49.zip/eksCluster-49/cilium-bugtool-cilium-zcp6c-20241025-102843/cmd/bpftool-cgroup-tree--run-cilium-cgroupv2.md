CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd36f76f5_7db8_4a41_8378_6e58ccaeb36f.slice/cri-containerd-ad9d70bcc712a9a395e7f7f925c4a04120b1c6d35024e6ad054aee0a0850f457.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd36f76f5_7db8_4a41_8378_6e58ccaeb36f.slice/cri-containerd-d7a8b6670a08cb3f042d2b85a36eeff1e8fbfca0442f06751f346cddad0b045a.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2b2258d_9586_4f33_a4cd_446e2bbd9057.slice/cri-containerd-e57b76ba625cd0fc1bd8bbb96deef7fdcac0fd076f59a92f5f917add8897ad2b.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2b2258d_9586_4f33_a4cd_446e2bbd9057.slice/cri-containerd-ed04f42563b973b1a325c4b05cfcc9996dcf5ffb4f774216c6d472de27ec31c5.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode46894e2_96a0_48e9_9080_24cd8ca0286c.slice/cri-containerd-ff575e677037cae4af34f298b349cb7167cd13dd20ee1a6f6b684e35467652d2.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode46894e2_96a0_48e9_9080_24cd8ca0286c.slice/cri-containerd-f9119defb5801425685e513d148277266d631845612eed5dad386e1286a35f0e.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99ecf9b9_4ab1_4ee3_bd75_dbbdba79c3e7.slice/cri-containerd-50a2461a728c84901be31d720623dae4f8edb3bb812aa369762bd4796c029b19.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99ecf9b9_4ab1_4ee3_bd75_dbbdba79c3e7.slice/cri-containerd-f6f2f4c7f863054928889a0c0c0ce02d403be0ce3532748c0ad516beb3e5f296.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99925ffd_5421_4a6d_947a_3be622866ebe.slice/cri-containerd-b8b2c2f827bc87cbb15b4a1281631ac65b9aa9d000327887efed4301ed53efcb.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99925ffd_5421_4a6d_947a_3be622866ebe.slice/cri-containerd-1e925edd2a5b23c91f90fb7672b82f69ac1dc464362fcdaf9b2280c273c1ffc2.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod325dc416_7d6c_4880_a5db_71b1d02e65e3.slice/cri-containerd-6f2db35304a09730a7a77c623d485b810979f22415a5b2c416ece0a6ea1a47f7.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod325dc416_7d6c_4880_a5db_71b1d02e65e3.slice/cri-containerd-fad48fd4634f193a9cb980771bf64d645ead01da8b7afe308e9f418ee22d2219.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod325dc416_7d6c_4880_a5db_71b1d02e65e3.slice/cri-containerd-8b9098bffd724c461267258eacefdca4a8e9566c1db3ea092e11a2b598ed25f4.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod325dc416_7d6c_4880_a5db_71b1d02e65e3.slice/cri-containerd-d8e5d0de834093d5b69fb16156f9af00165e25efbee2ce23b4ce76129ac14ae5.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd46a69f9_26d0_44ec_8755_cf368dd29364.slice/cri-containerd-a9d116c632d95362b9ce9a8ba40d81ad81717ccb0601520d52f18e3e8a0b8015.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd46a69f9_26d0_44ec_8755_cf368dd29364.slice/cri-containerd-e798dbb810465befdd9c1e0216c377a3af3818a9b3fe306665d84181fe4c5778.scope
    99       cgroup_device   multi                                          
