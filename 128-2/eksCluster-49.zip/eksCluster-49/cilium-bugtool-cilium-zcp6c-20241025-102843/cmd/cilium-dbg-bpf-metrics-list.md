REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10162     795239     677    bpf_overlay.c
Interface                 INGRESS     224449    85875727   1132   bpf_host.c
Success                   EGRESS      10390     812275     53     encap.h
Success                   EGRESS      5210      401330     1694   bpf_host.c
Success                   EGRESS      96860     12626949   1308   bpf_lxc.c
Success                   INGRESS     107204    13299372   86     l3.h
Success                   INGRESS     112805    13737187   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
