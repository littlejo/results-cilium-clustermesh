Node 0, zone      DMA     27      8      9     15      2     26     12      5      1      3    165 
Node 0, zone   Normal    237    109     48     26     27     13      3      1      4      3      6 
