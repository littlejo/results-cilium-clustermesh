Endpoint ID: 113
Path: /sys/fs/bpf/tc/globals/cilium_policy_00113

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439073   5617      0        
Allow    Ingress     1          ANY          NONE         disabled    10370    121       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 706
Path: /sys/fs/bpf/tc/globals/cilium_policy_00706

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69324   798       0        
Allow    Egress      0          ANY          NONE         disabled    12553   128       0        


Endpoint ID: 809
Path: /sys/fs/bpf/tc/globals/cilium_policy_00809

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3817204   36560     0        
Allow    Ingress     1          ANY          NONE         disabled    3403751   34728     0        
Allow    Egress      0          ANY          NONE         disabled    5420317   49774     0        


Endpoint ID: 1545
Path: /sys/fs/bpf/tc/globals/cilium_policy_01545

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69390   799       0        
Allow    Egress      0          ANY          NONE         disabled    11826   119       0        


Endpoint ID: 2900
Path: /sys/fs/bpf/tc/globals/cilium_policy_02900

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


