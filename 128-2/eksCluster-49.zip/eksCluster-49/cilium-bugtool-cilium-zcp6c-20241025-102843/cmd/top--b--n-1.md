top - 10:28:45 up 13 min,  0 users,  load average: 0.06, 0.11, 0.11
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.4 us, 32.1 sy,  0.0 ni, 17.9 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   3836.2 total,    777.7 free,    917.1 used,   2141.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2750.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 279436  79168 S  40.0   7.1   0:20.28 cilium-+
    614 root      20   0 1240432  16660  11484 S   6.7   0.4   0:00.04 cilium-+
    397 root      20   0 1228848   5928   3060 S   0.0   0.2   0:00.25 cilium-+
    644 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    687 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
    706 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    712 root      20   0 1692104   9220   6456 R   0.0   0.2   0:00.00 runc:[2+
