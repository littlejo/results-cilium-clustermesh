ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.165.40:443 (active)     
                                         2 => 172.31.254.79:443 (active)     
2    10.100.173.224:443   ClusterIP      1 => 172.31.231.255:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.49.0.51:53 (active)         
                                         2 => 10.49.0.73:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.49.0.51:9153 (active)       
                                         2 => 10.49.0.73:9153 (active)       
5    10.100.241.79:2379   ClusterIP      1 => 10.49.0.34:2379 (active)       
