Endpoint ID: 43
Path: /sys/fs/bpf/tc/globals/cilium_policy_00043

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3816159   34824     0        
Allow    Ingress     1          ANY          NONE         disabled    2730256   27160     0        
Allow    Egress      0          ANY          NONE         disabled    3433791   32151     0        


Endpoint ID: 809
Path: /sys/fs/bpf/tc/globals/cilium_policy_00809

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435288   5551      0        
Allow    Ingress     1          ANY          NONE         disabled    12822    149       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1070
Path: /sys/fs/bpf/tc/globals/cilium_policy_01070

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89080   1026      0        
Allow    Egress      0          ANY          NONE         disabled    14191   149       0        


Endpoint ID: 1199
Path: /sys/fs/bpf/tc/globals/cilium_policy_01199

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89397   1028      0        
Allow    Egress      0          ANY          NONE         disabled    13507   141       0        


Endpoint ID: 1932
Path: /sys/fs/bpf/tc/globals/cilium_policy_01932

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


