key: 01 00 00 00  value: bf 01 00 00
key: 07 00 00 00  value: bc 01 00 00
Found 2 elements
