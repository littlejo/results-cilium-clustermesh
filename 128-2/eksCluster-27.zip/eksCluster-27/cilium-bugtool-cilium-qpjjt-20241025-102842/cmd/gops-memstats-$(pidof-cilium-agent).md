alloc: 120.08MB (125910016 bytes)
total-alloc: 1.32GB (1414300344 bytes)
sys: 214.63MB (225060180 bytes)
lookups: 0
mallocs: 47448692
frees: 46246774
heap-alloc: 120.08MB (125910016 bytes)
heap-sys: 169.70MB (177946624 bytes)
heap-idle: 28.59MB (29982720 bytes)
heap-in-use: 141.11MB (147963904 bytes)
heap-released: 3.56MB (3735552 bytes)
heap-objects: 1201918
stack-in-use: 34.25MB (35913728 bytes)
stack-sys: 34.25MB (35913728 bytes)
stack-mspan-inuse: 2.23MB (2336320 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.10MB (1156505 bytes)
gc-sys: 5.20MB (5450128 bytes)
next-gc: when heap-alloc >= 160.28MB (168061704 bytes)
last-gc: 2024-10-25 10:28:43.623332536 +0000 UTC
gc-pause-total: 6.864377ms
gc-pause: 365674
gc-pause-end: 1729852123623332536
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00032453562724930884
enable-gc: true
debug-gc: false
