1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9f:4e:ba:83:c5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.253.235/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2636sec preferred_lft 2636sec
    inet6 fe80::89f:4eff:feba:83c5/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:0d:a4:3b:85:06 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a80d:a4ff:fe3b:8506/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:b5:01:53:b2:a9 brd ff:ff:ff:ff:ff:ff
    inet 10.27.0.236/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9cb5:1ff:fe53:b2a9/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8e:22:e1:f2:0f:14 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c22:e1ff:fef2:f14/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:6b:00:1e:de:67 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::106b:ff:fe1e:de67/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcd2db889fe49f@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:1f:15:27:d4:a0 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::381f:15ff:fe27:d4a0/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc0dcdbf9b6109@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:81:56:66:88:2d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f081:56ff:fe66:882d/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc7819c47a8f06@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:69:bb:0c:64:d0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c469:bbff:fe0c:64d0/64 scope link 
       valid_lft forever preferred_lft forever
