{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:17.080Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.253.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:17.080Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:21.597Z",
  "value": "id=809   sec_id=4     flags=0x0000 ifindex=7   mac=C6:9F:4D:00:B1:06 nodemac=12:6B:00:1E:DE:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:21.598Z",
  "value": "id=1199  sec_id=1870740 flags=0x0000 ifindex=9   mac=BE:6E:BA:82:42:AE nodemac=3A:1F:15:27:D4:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:21.658Z",
  "value": "id=1070  sec_id=1870740 flags=0x0000 ifindex=11  mac=96:63:DC:E0:50:DA nodemac=F2:81:56:66:88:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:21.667Z",
  "value": "id=809   sec_id=4     flags=0x0000 ifindex=7   mac=C6:9F:4D:00:B1:06 nodemac=12:6B:00:1E:DE:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:37.337Z",
  "value": "id=809   sec_id=4     flags=0x0000 ifindex=7   mac=C6:9F:4D:00:B1:06 nodemac=12:6B:00:1E:DE:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:37.338Z",
  "value": "id=1199  sec_id=1870740 flags=0x0000 ifindex=9   mac=BE:6E:BA:82:42:AE nodemac=3A:1F:15:27:D4:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:37.339Z",
  "value": "id=1070  sec_id=1870740 flags=0x0000 ifindex=11  mac=96:63:DC:E0:50:DA nodemac=F2:81:56:66:88:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:37.369Z",
  "value": "id=320   sec_id=1856085 flags=0x0000 ifindex=13  mac=DE:2C:1F:D4:61:5C nodemac=76:3A:08:99:0E:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.337Z",
  "value": "id=1199  sec_id=1870740 flags=0x0000 ifindex=9   mac=BE:6E:BA:82:42:AE nodemac=3A:1F:15:27:D4:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.338Z",
  "value": "id=1070  sec_id=1870740 flags=0x0000 ifindex=11  mac=96:63:DC:E0:50:DA nodemac=F2:81:56:66:88:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.338Z",
  "value": "id=809   sec_id=4     flags=0x0000 ifindex=7   mac=C6:9F:4D:00:B1:06 nodemac=12:6B:00:1E:DE:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.338Z",
  "value": "id=320   sec_id=1856085 flags=0x0000 ifindex=13  mac=DE:2C:1F:D4:61:5C nodemac=76:3A:08:99:0E:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.062Z",
  "value": "id=43    sec_id=1856085 flags=0x0000 ifindex=15  mac=9A:A7:94:7F:CB:05 nodemac=C6:69:BB:0C:64:D0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.27.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.655Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.019Z",
  "value": "id=1070  sec_id=1870740 flags=0x0000 ifindex=11  mac=96:63:DC:E0:50:DA nodemac=F2:81:56:66:88:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.019Z",
  "value": "id=43    sec_id=1856085 flags=0x0000 ifindex=15  mac=9A:A7:94:7F:CB:05 nodemac=C6:69:BB:0C:64:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.020Z",
  "value": "id=809   sec_id=4     flags=0x0000 ifindex=7   mac=C6:9F:4D:00:B1:06 nodemac=12:6B:00:1E:DE:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.020Z",
  "value": "id=1199  sec_id=1870740 flags=0x0000 ifindex=9   mac=BE:6E:BA:82:42:AE nodemac=3A:1F:15:27:D4:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.019Z",
  "value": "id=43    sec_id=1856085 flags=0x0000 ifindex=15  mac=9A:A7:94:7F:CB:05 nodemac=C6:69:BB:0C:64:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.020Z",
  "value": "id=809   sec_id=4     flags=0x0000 ifindex=7   mac=C6:9F:4D:00:B1:06 nodemac=12:6B:00:1E:DE:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.020Z",
  "value": "id=1199  sec_id=1870740 flags=0x0000 ifindex=9   mac=BE:6E:BA:82:42:AE nodemac=3A:1F:15:27:D4:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.020Z",
  "value": "id=1070  sec_id=1870740 flags=0x0000 ifindex=11  mac=96:63:DC:E0:50:DA nodemac=F2:81:56:66:88:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:40.020Z",
  "value": "id=43    sec_id=1856085 flags=0x0000 ifindex=15  mac=9A:A7:94:7F:CB:05 nodemac=C6:69:BB:0C:64:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:40.020Z",
  "value": "id=1199  sec_id=1870740 flags=0x0000 ifindex=9   mac=BE:6E:BA:82:42:AE nodemac=3A:1F:15:27:D4:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:40.020Z",
  "value": "id=809   sec_id=4     flags=0x0000 ifindex=7   mac=C6:9F:4D:00:B1:06 nodemac=12:6B:00:1E:DE:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:40.021Z",
  "value": "id=1070  sec_id=1870740 flags=0x0000 ifindex=11  mac=96:63:DC:E0:50:DA nodemac=F2:81:56:66:88:2D"
}

