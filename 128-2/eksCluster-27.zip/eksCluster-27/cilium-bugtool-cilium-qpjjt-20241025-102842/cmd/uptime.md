 10:28:43 up 16 min,  0 users,  load average: 0.27, 0.16, 0.12
