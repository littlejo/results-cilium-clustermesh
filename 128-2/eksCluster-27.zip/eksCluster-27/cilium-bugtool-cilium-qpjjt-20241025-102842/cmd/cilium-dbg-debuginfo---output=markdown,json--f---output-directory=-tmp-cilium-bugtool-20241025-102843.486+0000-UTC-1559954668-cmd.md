markdown output at /tmp/cilium-bugtool-20241025-102843.486+0000-UTC-1559954668/cmd/cilium-debuginfo-20241025-102914.086+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.486+0000-UTC-1559954668/cmd/cilium-debuginfo-20241025-102914.086+0000-UTC.json
