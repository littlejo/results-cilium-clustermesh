xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 507
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 503
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 493
cilium_host(4) clsact/egress cil_from_host-cilium_host id 496
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 445
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 446
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 531
lxcd2db889fe49f(9) clsact/ingress cil_from_container-lxcd2db889fe49f id 478
lxc0dcdbf9b6109(11) clsact/ingress cil_from_container-lxc0dcdbf9b6109 id 506
lxc7819c47a8f06(15) clsact/ingress cil_from_container-lxc7819c47a8f06 id 591

flow_dissector:

netfilter:

