CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b7621d7_6ca5_4ec4_9105_d3c2cd3f8469.slice/cri-containerd-d4b65e53c6b3c27b211d11f9bca30d8c4bc00c225a7ef50e01a30744e00f33c4.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b7621d7_6ca5_4ec4_9105_d3c2cd3f8469.slice/cri-containerd-01280cefe3ad0acbb207bae63a3c33b450a61302750ca31713ab143c81d9a934.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50642356_a723_437a_b231_fb399a0f949d.slice/cri-containerd-82392cd055c163ca2b60f1dcbf19d359775cbae5b7488c029272157d0e2a5a5b.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50642356_a723_437a_b231_fb399a0f949d.slice/cri-containerd-1cfeb46bba238c286685d9f045ecfc20a7b6641c2d5472417e3a138cb3aba80d.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca311857_dd2c_4fa8_8fe7_649c94acb473.slice/cri-containerd-ac1bd48c4cfbdbb358252b5ba9fa5deaeddc3db0cd8b0ab9bd781227e03427c2.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca311857_dd2c_4fa8_8fe7_649c94acb473.slice/cri-containerd-9b78ab021decae506ac6d8061fe9a8b3ecbdcff47e74cfbc0654a71aba40510d.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb622bec_3849_46df_b41f_6cb4229cf96f.slice/cri-containerd-3545588eaf63ea4aab9b7b21c8bd4a587258490eec23376e5283577451523b6e.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb622bec_3849_46df_b41f_6cb4229cf96f.slice/cri-containerd-1cf3bf9c28d7cb78e03671d0e98e0cdf524d89ffcd9f839e1c45d62a89aa2639.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4597aedc_196b_447b_a236_7956f9137470.slice/cri-containerd-2a033233e7d9bd27e7e70151ca604f827f5e51f2eaa137a16ae1429f5b248587.scope
    619      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4597aedc_196b_447b_a236_7956f9137470.slice/cri-containerd-578abb543541e1c64bfd037ae542a2a405b0c731cb86be41ffe59f17dfe546f8.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4597aedc_196b_447b_a236_7956f9137470.slice/cri-containerd-ff457107743659edec7126b546c881f789947881936a569ec061a4e926f74b83.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4597aedc_196b_447b_a236_7956f9137470.slice/cri-containerd-6b5cf696cc22bbfdb0f899835441484b8fad19fc6a0d87d52d28865db677df51.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda85d1a63_70ad_4494_9037_f712a0644be5.slice/cri-containerd-3d9bfe6c69fe84c9d259eaeadf7dd9c72b11a449c8c37717e85a90f930cdc5d0.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda85d1a63_70ad_4494_9037_f712a0644be5.slice/cri-containerd-03b66c30d8910a2020e6968f81b53994f456a001ffe381e7399009446c5c42ad.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf2a8473_98d6_4038_9add_b9ff1471707f.slice/cri-containerd-1984aabf999d392efb7f92df41ff782900dd9a5a6e1106f046e3d5fb239d1ef4.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf2a8473_98d6_4038_9add_b9ff1471707f.slice/cri-containerd-f7bc6676ff43eedba3855dbd07ca8ba9b983e134e9dc3938d140220f2692e2b8.scope
    65       cgroup_device   multi                                          
