IP ADDRESS         LOCAL ENDPOINT INFO
10.27.0.220:0      id=809   sec_id=4     flags=0x0000 ifindex=7   mac=C6:9F:4D:00:B1:06 nodemac=12:6B:00:1E:DE:67     
172.31.253.235:0   (localhost)                                                                                        
10.27.0.43:0       id=43    sec_id=1856085 flags=0x0000 ifindex=15  mac=9A:A7:94:7F:CB:05 nodemac=C6:69:BB:0C:64:D0   
10.27.0.6:0        id=1070  sec_id=1870740 flags=0x0000 ifindex=11  mac=96:63:DC:E0:50:DA nodemac=F2:81:56:66:88:2D   
10.27.0.75:0       id=1199  sec_id=1870740 flags=0x0000 ifindex=9   mac=BE:6E:BA:82:42:AE nodemac=3A:1F:15:27:D4:A0   
10.27.0.236:0      (localhost)                                                                                        
