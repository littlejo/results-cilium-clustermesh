top - 10:28:43 up 16 min,  0 users,  load average: 0.27, 0.16, 0.12
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.3 us, 16.7 sy,  0.0 ni, 70.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1178.7 free,    901.6 used,   1755.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2766.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    688 root      20   0 1240432  16724  11484 S   6.7   0.4   0:00.02 cilium-+
      1 root      20   0 1538356 288444  78152 S   0.0   7.3   0:20.25 cilium-+
    411 root      20   0 1228848   6688   3900 S   0.0   0.2   0:00.26 cilium-+
    675 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    716 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    734 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
