[
  {
    "containers": [
      {
        "cgroup-id": 8380,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4597aedc_196b_447b_a236_7956f9137470.slice/cri-containerd-6b5cf696cc22bbfdb0f899835441484b8fad19fc6a0d87d52d28865db677df51.scope"
      },
      {
        "cgroup-id": 8296,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4597aedc_196b_447b_a236_7956f9137470.slice/cri-containerd-578abb543541e1c64bfd037ae542a2a405b0c731cb86be41ffe59f17dfe546f8.scope"
      },
      {
        "cgroup-id": 8212,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4597aedc_196b_447b_a236_7956f9137470.slice/cri-containerd-2a033233e7d9bd27e7e70151ca604f827f5e51f2eaa137a16ae1429f5b248587.scope"
      }
    ],
    "ips": [
      "10.27.0.43"
    ],
    "name": "clustermesh-apiserver-888bd477d-67g8w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6868,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50642356_a723_437a_b231_fb399a0f949d.slice/cri-containerd-1cfeb46bba238c286685d9f045ecfc20a7b6641c2d5472417e3a138cb3aba80d.scope"
      }
    ],
    "ips": [
      "10.27.0.6"
    ],
    "name": "coredns-cc6ccd49c-gpc6c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6784,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca311857_dd2c_4fa8_8fe7_649c94acb473.slice/cri-containerd-ac1bd48c4cfbdbb358252b5ba9fa5deaeddc3db0cd8b0ab9bd781227e03427c2.scope"
      }
    ],
    "ips": [
      "10.27.0.75"
    ],
    "name": "coredns-cc6ccd49c-9c784",
    "namespace": "kube-system"
  }
]

