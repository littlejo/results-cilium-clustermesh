USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         688  1.0  0.4 1240432 16252 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         702  0.0  0.0    364     4 ?        R    10:28   0:00  \_ cat /proc/net/xfrm_stat
root         703  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         675  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         652  0.0  0.0 1228744 3780 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         645  0.0  0.2 1229320 8280 ?        Rsl  10:28   0:00 /bin/gops stack 1
root           1  2.1  7.3 1538356 287104 ?      Ssl  10:13   0:20 cilium-agent --config-dir=/tmp/cilium/config-map
root         411  0.0  0.1 1228848 6688 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
