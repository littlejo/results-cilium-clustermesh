REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     208329    99046890   1132   bpf_host.c
Interface                 INGRESS     8800      685968     677    bpf_overlay.c
Success                   EGRESS      3930      297224     1694   bpf_host.c
Success                   EGRESS      8330      650852     53     encap.h
Success                   EGRESS      85420     11812267   1308   bpf_lxc.c
Success                   INGRESS     102442    12160851   235    trace.h
Success                   INGRESS     96923     11728201   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
