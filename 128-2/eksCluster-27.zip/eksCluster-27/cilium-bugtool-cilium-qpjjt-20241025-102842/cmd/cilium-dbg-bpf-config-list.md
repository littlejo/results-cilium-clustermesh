KEY             VALUE
AgentLiveness   1005641213378
UTimeOffset     3378615523437500
