32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:30+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:31+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:32+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:32+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:32+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:32+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:36+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
444: sched_cls  name tail_handle_ipv4  tag 6a5b084ca85fe403  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 112
445: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 113
446: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
447: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 115
470: sched_cls  name handle_policy  tag f5466441bed4d3ff  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,99,74,75,101,33,72,97,31,76,67,32,29,30
	btf_id 143
472: sched_cls  name tail_handle_arp  tag 1f3c0f0f30f2200d  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,99
	btf_id 145
475: sched_cls  name tail_ipv4_to_endpoint  tag e2b3f1fe604aa118  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,97,31,99,32,29,30
	btf_id 147
477: sched_cls  name __send_drop_notify  tag 4d1660d2517ae5ee  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 150
478: sched_cls  name cil_from_container  tag d80b03e76674f49f  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 99,68
	btf_id 151
481: sched_cls  name tail_handle_ipv4_cont  tag f7abeae3d78633f6  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,97,74,75,31,68,66,69,99,32,29,30,73
	btf_id 154
484: sched_cls  name tail_handle_ipv4  tag a8bdd989fb4d994b  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,99
	btf_id 156
485: sched_cls  name tail_ipv4_ct_egress  tag 66c1b42fa43a4bd9  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,101,76
	btf_id 159
487: sched_cls  name tail_ipv4_ct_ingress  tag a5cbbc4d97376257  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,101,76
	btf_id 160
489: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,99
	btf_id 162
491: sched_cls  name tail_handle_ipv4_from_host  tag 04f88813fa863419  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,103
	btf_id 166
493: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 169
494: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,103
	btf_id 170
496: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,103
	btf_id 172
497: sched_cls  name __send_drop_notify  tag 05c0a21d131da463  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 173
500: sched_cls  name __send_drop_notify  tag 05c0a21d131da463  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 177
501: sched_cls  name tail_handle_ipv4_from_host  tag 04f88813fa863419  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,107
	btf_id 178
503: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 180
504: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,107
	btf_id 181
505: sched_cls  name tail_ipv4_ct_egress  tag 66c1b42fa43a4bd9  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,106,74,75,105,76
	btf_id 167
506: sched_cls  name cil_from_container  tag c4f092d48656bbe5  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 106,68
	btf_id 182
507: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,109,67
	btf_id 184
509: sched_cls  name __send_drop_notify  tag 05c0a21d131da463  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 186
510: sched_cls  name tail_handle_ipv4_from_host  tag 04f88813fa863419  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 187
513: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 190
514: sched_cls  name __send_drop_notify  tag a4791b593968034c  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 193
515: sched_cls  name tail_ipv4_to_endpoint  tag 0091787b4de96bff  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,105,33,74,75,72,102,31,106,32,29,30
	btf_id 191
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,106
	btf_id 195
517: sched_cls  name handle_policy  tag 494aae03ccf1b18f  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,111,74,75,112,33,72,90,31,76,67,32,29,30
	btf_id 194
519: sched_cls  name tail_handle_ipv4_cont  tag 545ecafda49b2a9c  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,105,33,102,74,75,31,68,66,69,106,32,29,30,73
	btf_id 197
520: sched_cls  name tail_handle_ipv4_cont  tag e6cc9e86eea9bbda  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,112,33,90,74,75,31,68,66,69,111,32,29,30,73
	btf_id 198
521: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,111
	btf_id 200
522: sched_cls  name tail_ipv4_to_endpoint  tag 366e24525b9ca53d  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,112,33,74,75,72,90,31,111,32,29,30
	btf_id 201
523: sched_cls  name handle_policy  tag 5b2cd15e4287a19a  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,106,74,75,105,33,72,102,31,76,67,32,29,30
	btf_id 199
524: sched_cls  name __send_drop_notify  tag 5dc8776177436a17  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 203
525: sched_cls  name tail_handle_ipv4  tag c97db7402696315c  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,111
	btf_id 202
526: sched_cls  name tail_handle_ipv4  tag 1734febb350083af  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,106
	btf_id 204
527: sched_cls  name tail_ipv4_ct_ingress  tag 9ed34fda1c7564ce  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,106,74,75,105,76
	btf_id 206
528: sched_cls  name tail_handle_arp  tag ea0f4eaeb727c314  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,106
	btf_id 207
529: sched_cls  name tail_ipv4_ct_ingress  tag d1100aa0fcd1d407  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 205
530: sched_cls  name tail_handle_arp  tag 0ab12bfdec9595f4  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,111
	btf_id 208
531: sched_cls  name cil_from_container  tag f3e14eec0868a0c0  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 111,68
	btf_id 209
533: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 211
534: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
537: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
542: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
545: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
546: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: sched_cls  name __send_drop_notify  tag 86d2158bde87bb2f  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 227
590: sched_cls  name tail_handle_ipv4  tag 03577ec847a63144  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,129
	btf_id 228
591: sched_cls  name cil_from_container  tag e09cbb75630f43b1  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,68
	btf_id 229
592: sched_cls  name tail_handle_ipv4_cont  tag f9abc2bfdc384d40  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,128,33,127,74,75,31,68,66,69,129,32,29,30,73
	btf_id 230
593: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,129
	btf_id 231
594: sched_cls  name tail_handle_arp  tag 7636dd74c3fc1a0f  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,129
	btf_id 232
595: sched_cls  name handle_policy  tag 9a129502c44e83b9  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,129,74,75,128,33,72,127,31,76,67,32,29,30
	btf_id 233
596: sched_cls  name tail_ipv4_to_endpoint  tag 114971b444c51bba  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,128,33,74,75,72,127,31,129,32,29,30
	btf_id 234
597: sched_cls  name tail_ipv4_ct_egress  tag c912ee07fb1a60c2  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 235
598: sched_cls  name tail_ipv4_ct_ingress  tag 4c71aed8eb71e3dd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 236
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
616: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
619: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
