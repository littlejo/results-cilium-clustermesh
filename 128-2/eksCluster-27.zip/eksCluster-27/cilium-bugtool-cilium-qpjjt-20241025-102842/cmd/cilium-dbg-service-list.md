ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.149.205:443 (active)    
                                         2 => 172.31.235.135:443 (active)    
2    10.100.108.100:443   ClusterIP      1 => 172.31.253.235:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.27.0.75:53 (active)         
                                         2 => 10.27.0.6:53 (active)          
4    10.100.0.10:9153     ClusterIP      1 => 10.27.0.75:9153 (active)       
                                         2 => 10.27.0.6:9153 (active)        
5    10.100.228.61:2379   ClusterIP      1 => 10.27.0.43:2379 (active)       
