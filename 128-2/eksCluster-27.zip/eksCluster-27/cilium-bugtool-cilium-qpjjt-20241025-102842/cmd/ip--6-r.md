fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcd2db889fe49f proto kernel metric 256 pref medium
fe80::/64 dev lxc0dcdbf9b6109 proto kernel metric 256 pref medium
fe80::/64 dev lxc7819c47a8f06 proto kernel metric 256 pref medium
