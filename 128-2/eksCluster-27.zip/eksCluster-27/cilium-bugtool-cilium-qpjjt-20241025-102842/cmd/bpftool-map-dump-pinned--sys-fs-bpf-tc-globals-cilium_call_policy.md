key: 2b 00 00 00  value: 53 02 00 00
key: 29 03 00 00  value: 05 02 00 00
key: 2e 04 00 00  value: 0b 02 00 00
key: af 04 00 00  value: d6 01 00 00
Found 4 elements
