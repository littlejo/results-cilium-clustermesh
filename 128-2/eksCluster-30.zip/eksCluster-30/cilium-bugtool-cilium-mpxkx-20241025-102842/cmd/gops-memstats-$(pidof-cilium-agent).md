alloc: 95.83MB (100487640 bytes)
total-alloc: 1.32GB (1420324728 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 47676077
frees: 46721224
heap-alloc: 95.83MB (100487640 bytes)
heap-sys: 161.38MB (169222144 bytes)
heap-idle: 40.02MB (41959424 bytes)
heap-in-use: 121.37MB (127262720 bytes)
heap-released: 1.27MB (1335296 bytes)
heap-objects: 954853
stack-in-use: 34.59MB (36274176 bytes)
stack-sys: 34.59MB (36274176 bytes)
stack-mspan-inuse: 2.03MB (2130560 bytes)
stack-mspan-sys: 2.46MB (2578560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 927.27KB (949521 bytes)
gc-sys: 5.14MB (5390592 bytes)
next-gc: when heap-alloc >= 146.51MB (153629288 bytes)
last-gc: 2024-10-25 10:28:51.227179299 +0000 UTC
gc-pause-total: 11.578537ms
gc-pause: 60940
gc-pause-end: 1729852131227179299
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0004036460628475745
enable-gc: true
debug-gc: false
