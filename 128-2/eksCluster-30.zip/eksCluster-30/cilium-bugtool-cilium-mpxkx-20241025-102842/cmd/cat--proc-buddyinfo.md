Node 0, zone      DMA     36     54     23     20      7     37     48     11      3      4    161 
Node 0, zone   Normal    376    181     13     25      7      5     10      3      1      2      7 
