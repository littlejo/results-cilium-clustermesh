Endpoint ID: 141
Path: /sys/fs/bpf/tc/globals/cilium_policy_00141

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 437
Path: /sys/fs/bpf/tc/globals/cilium_policy_00437

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69665   801       0        
Allow    Egress      0          ANY          NONE         disabled    12758   130       0        


Endpoint ID: 695
Path: /sys/fs/bpf/tc/globals/cilium_policy_00695

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3855940   36488     0        
Allow    Ingress     1          ANY          NONE         disabled    3077671   31085     0        
Allow    Egress      0          ANY          NONE         disabled    4733683   43744     0        


Endpoint ID: 1732
Path: /sys/fs/bpf/tc/globals/cilium_policy_01732

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68939   790       0        
Allow    Egress      0          ANY          NONE         disabled    13054   134       0        


Endpoint ID: 3685
Path: /sys/fs/bpf/tc/globals/cilium_policy_03685

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    431168   5499      0        
Allow    Ingress     1          ANY          NONE         disabled    10296    120       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


