ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.215.98:443 (active)     
                                        2 => 172.31.143.71:443 (active)     
2    10.100.175.10:443   ClusterIP      1 => 172.31.161.158:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.30.0.141:53 (active)        
                                        2 => 10.30.0.148:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.30.0.141:9153 (active)      
                                        2 => 10.30.0.148:9153 (active)      
5    10.100.49.96:2379   ClusterIP      1 => 10.30.0.33:2379 (active)       
