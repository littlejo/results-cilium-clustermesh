{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.551Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.161.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.551Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.175.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.551Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.307Z",
  "value": "id=3685  sec_id=4     flags=0x0000 ifindex=10  mac=66:59:11:17:B9:86 nodemac=D6:D8:08:AB:B5:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.311Z",
  "value": "id=1732  sec_id=2037924 flags=0x0000 ifindex=12  mac=62:72:D6:58:89:28 nodemac=22:55:95:F9:9A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.359Z",
  "value": "id=3685  sec_id=4     flags=0x0000 ifindex=10  mac=66:59:11:17:B9:86 nodemac=D6:D8:08:AB:B5:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.360Z",
  "value": "id=1732  sec_id=2037924 flags=0x0000 ifindex=12  mac=62:72:D6:58:89:28 nodemac=22:55:95:F9:9A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.368Z",
  "value": "id=437   sec_id=2037924 flags=0x0000 ifindex=14  mac=D6:FB:8A:FA:08:34 nodemac=52:12:93:9A:9E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.417Z",
  "value": "id=1732  sec_id=2037924 flags=0x0000 ifindex=12  mac=62:72:D6:58:89:28 nodemac=22:55:95:F9:9A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.418Z",
  "value": "id=3685  sec_id=4     flags=0x0000 ifindex=10  mac=66:59:11:17:B9:86 nodemac=D6:D8:08:AB:B5:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.419Z",
  "value": "id=437   sec_id=2037924 flags=0x0000 ifindex=14  mac=D6:FB:8A:FA:08:34 nodemac=52:12:93:9A:9E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.447Z",
  "value": "id=380   sec_id=2087625 flags=0x0000 ifindex=16  mac=4A:C3:87:49:A3:BA nodemac=A2:7B:A2:5A:55:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.448Z",
  "value": "id=380   sec_id=2087625 flags=0x0000 ifindex=16  mac=4A:C3:87:49:A3:BA nodemac=A2:7B:A2:5A:55:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.417Z",
  "value": "id=3685  sec_id=4     flags=0x0000 ifindex=10  mac=66:59:11:17:B9:86 nodemac=D6:D8:08:AB:B5:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.418Z",
  "value": "id=1732  sec_id=2037924 flags=0x0000 ifindex=12  mac=62:72:D6:58:89:28 nodemac=22:55:95:F9:9A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.418Z",
  "value": "id=380   sec_id=2087625 flags=0x0000 ifindex=16  mac=4A:C3:87:49:A3:BA nodemac=A2:7B:A2:5A:55:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.418Z",
  "value": "id=437   sec_id=2037924 flags=0x0000 ifindex=14  mac=D6:FB:8A:FA:08:34 nodemac=52:12:93:9A:9E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:57.007Z",
  "value": "id=695   sec_id=2087625 flags=0x0000 ifindex=18  mac=02:11:22:BA:80:B1 nodemac=56:D0:C2:A9:3F:A4"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.30.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.122Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.346Z",
  "value": "id=437   sec_id=2037924 flags=0x0000 ifindex=14  mac=D6:FB:8A:FA:08:34 nodemac=52:12:93:9A:9E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.347Z",
  "value": "id=695   sec_id=2087625 flags=0x0000 ifindex=18  mac=02:11:22:BA:80:B1 nodemac=56:D0:C2:A9:3F:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.347Z",
  "value": "id=3685  sec_id=4     flags=0x0000 ifindex=10  mac=66:59:11:17:B9:86 nodemac=D6:D8:08:AB:B5:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.348Z",
  "value": "id=1732  sec_id=2037924 flags=0x0000 ifindex=12  mac=62:72:D6:58:89:28 nodemac=22:55:95:F9:9A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.342Z",
  "value": "id=695   sec_id=2087625 flags=0x0000 ifindex=18  mac=02:11:22:BA:80:B1 nodemac=56:D0:C2:A9:3F:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.343Z",
  "value": "id=437   sec_id=2037924 flags=0x0000 ifindex=14  mac=D6:FB:8A:FA:08:34 nodemac=52:12:93:9A:9E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.343Z",
  "value": "id=3685  sec_id=4     flags=0x0000 ifindex=10  mac=66:59:11:17:B9:86 nodemac=D6:D8:08:AB:B5:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.344Z",
  "value": "id=1732  sec_id=2037924 flags=0x0000 ifindex=12  mac=62:72:D6:58:89:28 nodemac=22:55:95:F9:9A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.342Z",
  "value": "id=3685  sec_id=4     flags=0x0000 ifindex=10  mac=66:59:11:17:B9:86 nodemac=D6:D8:08:AB:B5:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.343Z",
  "value": "id=1732  sec_id=2037924 flags=0x0000 ifindex=12  mac=62:72:D6:58:89:28 nodemac=22:55:95:F9:9A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.343Z",
  "value": "id=437   sec_id=2037924 flags=0x0000 ifindex=14  mac=D6:FB:8A:FA:08:34 nodemac=52:12:93:9A:9E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.343Z",
  "value": "id=695   sec_id=2087625 flags=0x0000 ifindex=18  mac=02:11:22:BA:80:B1 nodemac=56:D0:C2:A9:3F:A4"
}

