[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3285ec7_67ac_43fd_b984_8d53b397d9a2.slice/cri-containerd-c3c1512f90e320504ed86cbb935e52acd47d4f623c255bd253609fcaa9204792.scope"
      }
    ],
    "ips": [
      "10.30.0.141"
    ],
    "name": "coredns-cc6ccd49c-szfl4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6f1a0da_15e8_46de_ac1e_ffce7d3dadb5.slice/cri-containerd-da597c31539bc029eb7c504676acf7b4201eebec481476c32f4c27fcef14fba6.scope"
      }
    ],
    "ips": [
      "10.30.0.148"
    ],
    "name": "coredns-cc6ccd49c-c5vms",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40ac0d23_6023_4f20_b4d7_2864da5b2da2.slice/cri-containerd-b095d36633a1eedb7044fb663358b93196d40f742789cf3b6f11c6f06e4075b3.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40ac0d23_6023_4f20_b4d7_2864da5b2da2.slice/cri-containerd-10e792ef6e737e51d13f2d004c12553254ee62e20e734a50cc380d62d1a49426.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40ac0d23_6023_4f20_b4d7_2864da5b2da2.slice/cri-containerd-05e83b0b26d725fca89aa50661ce47fb937b6f9fa7a714d89005a82623886561.scope"
      }
    ],
    "ips": [
      "10.30.0.33"
    ],
    "name": "clustermesh-apiserver-86fc96ddb-jzlcn",
    "namespace": "kube-system"
  }
]

