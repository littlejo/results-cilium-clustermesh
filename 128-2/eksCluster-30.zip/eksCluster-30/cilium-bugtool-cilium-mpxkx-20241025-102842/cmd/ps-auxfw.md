USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         671  0.0  0.4 1240432 16492 ?       Rsl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         686  0.0  0.0   2020   400 ?        R    10:28   0:00  \_ bash -c hostname
root         650  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         635  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         625  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  3.1  7.0 1472496 276360 ?      Ssl  10:16   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1228848 6896 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
