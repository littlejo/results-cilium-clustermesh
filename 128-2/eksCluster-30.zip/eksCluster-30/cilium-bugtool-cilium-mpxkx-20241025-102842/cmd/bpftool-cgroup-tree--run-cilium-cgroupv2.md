CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6f1a0da_15e8_46de_ac1e_ffce7d3dadb5.slice/cri-containerd-837386e36f8b22a3ad4a3556331afa07eeaca88f89ee41af4b6a3afde1ec2bad.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6f1a0da_15e8_46de_ac1e_ffce7d3dadb5.slice/cri-containerd-da597c31539bc029eb7c504676acf7b4201eebec481476c32f4c27fcef14fba6.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc1da8c44_338c_4308_be61_7c3a288d1449.slice/cri-containerd-28df3c4d721d431bc2b5d2c7fa822c0c22526cc42ee3c313fedc943b0dc189af.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc1da8c44_338c_4308_be61_7c3a288d1449.slice/cri-containerd-612ed4ac68297a1b3e4f850096bd04eb06ceb7b5765ddada3c7bdb810671d92f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67956ff8_f2ad_4d9a_8f26_093cf67778a3.slice/cri-containerd-f6b233420f85cd8902c64c2681bcb7d17fb0bb1759efa9afa4e785f9abb5f6d3.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67956ff8_f2ad_4d9a_8f26_093cf67778a3.slice/cri-containerd-d330fd149c8da6ba258486be469ab9bb15ae17f822a0cb9aebc1f7af76de32dd.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3285ec7_67ac_43fd_b984_8d53b397d9a2.slice/cri-containerd-c35d878e935ac2cc0b2fc37ecf85e4dbbe4dbdc67f5bea684f6971e19fef5c17.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3285ec7_67ac_43fd_b984_8d53b397d9a2.slice/cri-containerd-c3c1512f90e320504ed86cbb935e52acd47d4f623c255bd253609fcaa9204792.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40ac0d23_6023_4f20_b4d7_2864da5b2da2.slice/cri-containerd-b095d36633a1eedb7044fb663358b93196d40f742789cf3b6f11c6f06e4075b3.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40ac0d23_6023_4f20_b4d7_2864da5b2da2.slice/cri-containerd-05e83b0b26d725fca89aa50661ce47fb937b6f9fa7a714d89005a82623886561.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40ac0d23_6023_4f20_b4d7_2864da5b2da2.slice/cri-containerd-63ff665fcd46b3626a872c1bfbb9aaae5ca9bd0d3e45f14bb3b68afb442c2aff.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40ac0d23_6023_4f20_b4d7_2864da5b2da2.slice/cri-containerd-10e792ef6e737e51d13f2d004c12553254ee62e20e734a50cc380d62d1a49426.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6536ea75_4d38_4a6c_9ecd_5e1959a878ac.slice/cri-containerd-1361681b3e993a3298507345e5b0f556732c291b202fbab599c118fe94895454.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6536ea75_4d38_4a6c_9ecd_5e1959a878ac.slice/cri-containerd-5edf55f983b5f9c249990e69d85a5777e2fe39a1f4c3fc592d36c6efaca58a01.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84777e4d_c9a8_4136_aaf7_12998b611f0a.slice/cri-containerd-77b0f4b2a8d0264e3b2754c9f515a5b09ae668d2456dafc99e0b57cdca79afdc.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84777e4d_c9a8_4136_aaf7_12998b611f0a.slice/cri-containerd-c76a184a186e93fcc4337fab5f15495ab0a7a3cf1a4ce4daf655bfbaad039e8d.scope
    97       cgroup_device   multi                                          
