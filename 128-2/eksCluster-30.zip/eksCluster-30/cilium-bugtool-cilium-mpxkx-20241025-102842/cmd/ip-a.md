1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d0:34:28:e5:9b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.161.158/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2811sec preferred_lft 2811sec
    inet6 fe80::4d0:34ff:fe28:e59b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e6:0c:fc:d6:ef brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.175.58/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4e6:cff:fefc:d6ef/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:15:43:ff:c6:45 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1c15:43ff:feff:c645/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:2a:3b:1a:9d:66 brd ff:ff:ff:ff:ff:ff
    inet 10.30.0.203/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e42a:3bff:fe1a:9d66/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:6b:25:88:d8:4d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::946b:25ff:fe88:d84d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:d8:08:ab:b5:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d4d8:8ff:feab:b5e2/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc837cced0c1f1@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:55:95:f9:9a:90 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2055:95ff:fef9:9a90/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9bbb0e65bf0a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:12:93:9a:9e:39 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5012:93ff:fe9a:9e39/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc090723efcbe4@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:d0:c2:a9:3f:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::54d0:c2ff:fea9:3fa4/64 scope link 
       valid_lft forever preferred_lft forever
