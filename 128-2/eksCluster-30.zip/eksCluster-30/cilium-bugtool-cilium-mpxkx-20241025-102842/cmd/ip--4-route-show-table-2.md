default via 172.31.128.1 dev ens6 
172.31.128.1 dev ens6 scope link 
