key: b5 01 00 00  value: 2b 02 00 00
key: b7 02 00 00  value: 6e 02 00 00
key: c4 06 00 00  value: 19 02 00 00
key: 65 0e 00 00  value: 2d 02 00 00
Found 4 elements
