IP ADDRESS         LOCAL ENDPOINT INFO
10.30.0.141:0      id=437   sec_id=2037924 flags=0x0000 ifindex=14  mac=D6:FB:8A:FA:08:34 nodemac=52:12:93:9A:9E:39   
172.31.161.158:0   (localhost)                                                                                        
10.30.0.87:0       id=3685  sec_id=4     flags=0x0000 ifindex=10  mac=66:59:11:17:B9:86 nodemac=D6:D8:08:AB:B5:E2     
10.30.0.33:0       id=695   sec_id=2087625 flags=0x0000 ifindex=18  mac=02:11:22:BA:80:B1 nodemac=56:D0:C2:A9:3F:A4   
10.30.0.148:0      id=1732  sec_id=2037924 flags=0x0000 ifindex=12  mac=62:72:D6:58:89:28 nodemac=22:55:95:F9:9A:90   
10.30.0.203:0      (localhost)                                                                                        
172.31.175.58:0    (localhost)                                                                                        
