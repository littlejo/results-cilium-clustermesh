REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     214558    84612639   1132   bpf_host.c
Interface                 INGRESS     9416      735551     677    bpf_overlay.c
Success                   EGRESS      4593      350515     1694   bpf_host.c
Success                   EGRESS      92051     12217801   1308   bpf_lxc.c
Success                   EGRESS      9286      726424     53     encap.h
Success                   INGRESS     102444    12614939   86     l3.h
Success                   INGRESS     107916    13043881   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
