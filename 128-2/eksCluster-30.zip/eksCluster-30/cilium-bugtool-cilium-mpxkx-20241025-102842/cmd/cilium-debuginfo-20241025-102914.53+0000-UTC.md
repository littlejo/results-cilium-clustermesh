# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.30.0.0/24, 
Allocated addresses:
  10.30.0.141 (kube-system/coredns-cc6ccd49c-szfl4)
  10.30.0.148 (kube-system/coredns-cc6ccd49c-c5vms)
  10.30.0.203 (router)
  10.30.0.33 (kube-system/clustermesh-apiserver-86fc96ddb-jzlcn)
  10.30.0.87 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 951e0ec37a071057
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   21s ago        never        0       no error   
  ct-map-pressure                                                    22s ago        never        0       no error   
  daemon-validate-config                                             10s ago        never        0       no error   
  dns-garbage-collector-job                                          25s ago        never        0       no error   
  endpoint-141-regeneration-recovery                                 never          never        0       no error   
  endpoint-1732-regeneration-recovery                                never          never        0       no error   
  endpoint-3685-regeneration-recovery                                never          never        0       no error   
  endpoint-437-regeneration-recovery                                 never          never        0       no error   
  endpoint-695-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        2m25s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               22s ago        never        0       no error   
  ipcache-inject-labels                                              22s ago        never        0       no error   
  k8s-heartbeat                                                      25s ago        never        0       no error   
  link-cache                                                         7s ago         never        0       no error   
  local-identity-checkpoint                                          12m22s ago     never        0       no error   
  node-neighbor-link-updater                                         2s ago         never        0       no error   
  remote-etcd-cmesh1                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh10                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh100                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh101                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh102                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh103                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh104                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh105                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh106                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh107                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh108                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh109                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh11                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh110                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh111                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh112                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh113                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh114                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh115                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh116                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh117                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh118                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh119                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh12                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh120                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh121                                               6m20s ago      never        0       no error   
  remote-etcd-cmesh122                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh123                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh124                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh125                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh126                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh127                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh128                                               6m19s ago      never        0       no error   
  remote-etcd-cmesh13                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh14                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh15                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh16                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh17                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh18                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh19                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh2                                                 6m19s ago      never        0       no error   
  remote-etcd-cmesh20                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh21                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh22                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh23                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh24                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh25                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh26                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh27                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh28                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh29                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh3                                                 6m19s ago      never        0       no error   
  remote-etcd-cmesh30                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh32                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh33                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh34                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh35                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh36                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh37                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh38                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh39                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh4                                                 6m19s ago      never        0       no error   
  remote-etcd-cmesh40                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh41                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh42                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh43                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh44                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh45                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh46                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh47                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh48                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh49                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh5                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh50                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh51                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh52                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh53                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh54                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh55                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh56                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh57                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh58                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh59                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh6                                                 6m19s ago      never        0       no error   
  remote-etcd-cmesh60                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh61                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh62                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh63                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh64                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh65                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh66                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh67                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh68                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh69                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh7                                                 6m19s ago      never        0       no error   
  remote-etcd-cmesh70                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh71                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh72                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh73                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh74                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh75                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh76                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh77                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh78                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh79                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh8                                                 6m19s ago      never        0       no error   
  remote-etcd-cmesh80                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh81                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh82                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh83                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh84                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh85                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh86                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh87                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh88                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh89                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh9                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh90                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh91                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh92                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh93                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh94                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh95                                                6m19s ago      never        0       no error   
  remote-etcd-cmesh96                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh97                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh98                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh99                                                6m20s ago      never        0       no error   
  resolve-identity-141                                               2m22s ago      never        0       no error   
  resolve-identity-1732                                              2m20s ago      never        0       no error   
  resolve-identity-3685                                              2m21s ago      never        0       no error   
  resolve-identity-437                                               2m20s ago      never        0       no error   
  resolve-identity-695                                               2m17s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-86fc96ddb-jzlcn   7m17s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-c5vms                 12m20s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-szfl4                 12m20s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     12m22s ago     never        0       no error   
  sync-policymap-141                                                 12m21s ago     never        0       no error   
  sync-policymap-1732                                                12m18s ago     never        0       no error   
  sync-policymap-3685                                                12m18s ago     never        0       no error   
  sync-policymap-437                                                 12m18s ago     never        0       no error   
  sync-policymap-695                                                 7m17s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1732)                                  10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (437)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (695)                                   7s ago         never        0       no error   
  sync-utime                                                         22s ago        never        0       no error   
  write-cni-file                                                     12m25s ago     never        0       no error   
Proxy Status:            OK, ip 10.30.0.203, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 2031616, max 2097151
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 83.66   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
141        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
437        Disabled           Disabled          2037924    k8s:eks.amazonaws.com/component=coredns                                             10.30.0.141   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh31                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
695        Disabled           Disabled          2087625    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.30.0.33    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh31                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1732       Disabled           Disabled          2037924    k8s:eks.amazonaws.com/component=coredns                                             10.30.0.148   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh31                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3685       Disabled           Disabled          4          reserved:health                                                                     10.30.0.87    ready   
```

#### BPF Policy Get 141

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 141

```
Invalid argument: unknown type 141
```


#### Endpoint Get 141

```
[
  {
    "id": 141,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-141-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "924c5cbd-9be9-4625-ace6-441142e18024"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-141",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:51.728Z",
            "success-count": 3
          },
          "uuid": "c752f1d9-caf4-464b-ab8d-f4f75bedf4cb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-141",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:52.825Z",
            "success-count": 1
          },
          "uuid": "a93540b5-2ee6-4671-86c6-4b6df506836b"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:56Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "e6:2a:3b:1a:9d:66",
        "interface-name": "cilium_host",
        "mac": "e6:2a:3b:1a:9d:66"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 141

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 141

```
Timestamp              Status   State                   Message
2024-10-25T10:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:16:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:53Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:16:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:16:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:51Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:51Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 437

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69665   801       0        
Allow    Egress      0          ANY          NONE         disabled    12758   130       0        

```


#### BPF CT List 437

```
Invalid argument: unknown type 437
```


#### Endpoint Get 437

```
[
  {
    "id": 437,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-437-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "619b340c-60e9-4c19-bb32-27bdce9fe63b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-437",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:54.100Z",
            "success-count": 3
          },
          "uuid": "9b1e43f5-0858-4c52-be92-862144f115fc"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-szfl4",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:54.099Z",
            "success-count": 1
          },
          "uuid": "765d0a02-fa79-4dd4-bd53-d60ed84c3ca2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-437",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:56.369Z",
            "success-count": 1
          },
          "uuid": "fe5a19f7-e0ac-45a4-9abb-f21daa376eed"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (437)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.170Z",
            "success-count": 76
          },
          "uuid": "de40fda9-38e3-41aa-86be-6a232c6baf26"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "c35d878e935ac2cc0b2fc37ecf85e4dbbe4dbdc67f5bea684f6971e19fef5c17:eth0",
        "container-id": "c35d878e935ac2cc0b2fc37ecf85e4dbbe4dbdc67f5bea684f6971e19fef5c17",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-szfl4",
        "pod-name": "kube-system/coredns-cc6ccd49c-szfl4"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2037924,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh31",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh31",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:56Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.30.0.141",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "52:12:93:9a:9e:39",
        "interface-index": 14,
        "interface-name": "lxc9bbb0e65bf0a",
        "mac": "d6:fb:8a:fa:08:34"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2037924,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2037924,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 437

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 437

```
Timestamp              Status   State                   Message
2024-10-25T10:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:54Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:54Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2037924

```
ID        LABELS
2037924   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh31
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 695

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3844620   36364     0        
Allow    Ingress     1          ANY          NONE         disabled    3077671   31085     0        
Allow    Egress      0          ANY          NONE         disabled    4728721   43687     0        

```


#### BPF CT List 695

```
Invalid argument: unknown type 695
```


#### Endpoint Get 695

```
[
  {
    "id": 695,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-695-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1f90e8dc-db6f-4ec8-ac03-754e5aa67664"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-695",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:56.974Z",
            "success-count": 2
          },
          "uuid": "461471da-e145-42cd-bd12-8fd20c788044"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-86fc96ddb-jzlcn",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:56.972Z",
            "success-count": 1
          },
          "uuid": "5cd69c2b-88d7-4a57-80d2-378250d00c08"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-695",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:57.008Z",
            "success-count": 1
          },
          "uuid": "9b95d97a-60d7-4131-995f-3441524b9005"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (695)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:07.020Z",
            "success-count": 45
          },
          "uuid": "dd8de987-0be0-4e09-b691-ddde775b23da"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "63ff665fcd46b3626a872c1bfbb9aaae5ca9bd0d3e45f14bb3b68afb442c2aff:eth0",
        "container-id": "63ff665fcd46b3626a872c1bfbb9aaae5ca9bd0d3e45f14bb3b68afb442c2aff",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-86fc96ddb-jzlcn",
        "pod-name": "kube-system/clustermesh-apiserver-86fc96ddb-jzlcn"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2087625,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh31",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86fc96ddb"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh31",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:56Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.30.0.33",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "56:d0:c2:a9:3f:a4",
        "interface-index": 18,
        "interface-name": "lxc090723efcbe4",
        "mac": "02:11:22:ba:80:b1"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2087625,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2087625,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 695

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 695

```
Timestamp              Status   State                   Message
2024-10-25T10:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:56Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2087625

```
ID        LABELS
2087625   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh31
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1732

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68939   790       0        
Allow    Egress      0          ANY          NONE         disabled    13054   134       0        

```


#### BPF CT List 1732

```
Invalid argument: unknown type 1732
```


#### Endpoint Get 1732

```
[
  {
    "id": 1732,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1732-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d4ec13e1-53ad-4c6e-8276-dec356af52d3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1732",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:54.009Z",
            "success-count": 3
          },
          "uuid": "89d634c6-f344-4434-9549-75002dae0066"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-c5vms",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:54.008Z",
            "success-count": 1
          },
          "uuid": "ce3d8764-84dc-4654-aca0-01019b706785"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1732",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:56.313Z",
            "success-count": 1
          },
          "uuid": "02fb01ff-6fc6-45d2-ad12-11f08342b804"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1732)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.161Z",
            "success-count": 76
          },
          "uuid": "bba01617-0504-49eb-865c-4ca99eb3a520"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "837386e36f8b22a3ad4a3556331afa07eeaca88f89ee41af4b6a3afde1ec2bad:eth0",
        "container-id": "837386e36f8b22a3ad4a3556331afa07eeaca88f89ee41af4b6a3afde1ec2bad",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-c5vms",
        "pod-name": "kube-system/coredns-cc6ccd49c-c5vms"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2037924,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh31",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh31",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:56Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.30.0.148",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "22:55:95:f9:9a:90",
        "interface-index": 12,
        "interface-name": "lxc837cced0c1f1",
        "mac": "62:72:d6:58:89:28"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2037924,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2037924,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1732

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1732

```
Timestamp              Status    State                   Message
2024-10-25T10:22:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:56Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:11Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:11Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:11Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:11Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:10Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:10Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:10Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:10Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:56Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:54Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:54Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:16:54Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:53Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 2037924

```
ID        LABELS
2037924   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh31
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3685

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    431028   5497      0        
Allow    Ingress     1          ANY          NONE         disabled    10296    120       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3685

```
Invalid argument: unknown type 3685
```


#### Endpoint Get 3685

```
[
  {
    "id": 3685,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3685-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c0f8fe8d-2816-40f3-acfa-4ddf5292908f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3685",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:52.810Z",
            "success-count": 3
          },
          "uuid": "c986afaa-65b4-4bfd-9265-96e091987bdd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3685",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:56.308Z",
            "success-count": 1
          },
          "uuid": "d8b36dfb-fa29-4e65-829f-7953a4e0fb36"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:56Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.30.0.87",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "d6:d8:08:ab:b5:e2",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "66:59:11:17:b9:86"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3685

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3685

```
Timestamp              Status   State                   Message
2024-10-25T10:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:16:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:56Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:16:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:16:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:16:52Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:52Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33886326                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33886326                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33886326                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c400000 rw-p 00000000 00:00 0 
400c400000-4010000000 ---p 00000000 00:00 0 
ffff5d45b000-ffff5d641000 rw-p 00000000 00:00 0 
ffff5d649000-ffff5d7aa000 rw-p 00000000 00:00 0 
ffff5d7aa000-ffff5d7eb000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5d7eb000-ffff5d82c000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5d82c000-ffff5d82e000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5d82e000-ffff5d830000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5d830000-ffff5ddd7000 rw-p 00000000 00:00 0 
ffff5ddd7000-ffff5ded7000 rw-p 00000000 00:00 0 
ffff5ded7000-ffff5dee8000 rw-p 00000000 00:00 0 
ffff5dee8000-ffff5fee8000 rw-p 00000000 00:00 0 
ffff5fee8000-ffff5ff68000 ---p 00000000 00:00 0 
ffff5ff68000-ffff5ff69000 rw-p 00000000 00:00 0 
ffff5ff69000-ffff7ff68000 ---p 00000000 00:00 0 
ffff7ff68000-ffff7ff69000 rw-p 00000000 00:00 0 
ffff7ff69000-ffff9fef8000 ---p 00000000 00:00 0 
ffff9fef8000-ffff9fef9000 rw-p 00000000 00:00 0 
ffff9fef9000-ffffa3eea000 ---p 00000000 00:00 0 
ffffa3eea000-ffffa3eeb000 rw-p 00000000 00:00 0 
ffffa3eeb000-ffffa46e8000 ---p 00000000 00:00 0 
ffffa46e8000-ffffa46e9000 rw-p 00000000 00:00 0 
ffffa46e9000-ffffa47e8000 ---p 00000000 00:00 0 
ffffa47e8000-ffffa4848000 rw-p 00000000 00:00 0 
ffffa4848000-ffffa484a000 r--p 00000000 00:00 0                          [vvar]
ffffa484a000-ffffa484b000 r-xp 00000000 00:00 0                          [vdso]
ffffc64cd000-ffffc64ee000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.30.0.87": (string) (len=6) "health",
  (string) (len=11) "10.30.0.148": (string) (len=35) "kube-system/coredns-cc6ccd49c-c5vms",
  (string) (len=11) "10.30.0.141": (string) (len=35) "kube-system/coredns-cc6ccd49c-szfl4",
  (string) (len=10) "10.30.0.33": (string) (len=49) "kube-system/clustermesh-apiserver-86fc96ddb-jzlcn",
  (string) (len=11) "10.30.0.203": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.161.158": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001016bb0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001b436e0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001b436e0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001a41b80)(frontends:[10.100.175.10]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001a41c30)(frontends:[10.100.0.10]/ports=[dns-tcp metrics dns]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4003430dc0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4003359810)(frontends:[10.100.49.96]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001a41ad0)(frontends:[10.100.0.1]/ports=[https]/selector=map[])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001928c98)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-rljvt": (*k8s.Endpoints)(0x400315edd0)(10.30.0.141:53/TCP[eu-west-3a],10.30.0.141:53/UDP[eu-west-3a],10.30.0.141:9153/TCP[eu-west-3a],10.30.0.148:53/TCP[eu-west-3a],10.30.0.148:53/UDP[eu-west-3a],10.30.0.148:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x400178b700)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-qhjc7": (*k8s.Endpoints)(0x4003419790)(10.30.0.33:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001928c88)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002c8dc70)(172.31.143.71:443/TCP,172.31.215.98:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001928c90)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-xd8g6": (*k8s.Endpoints)(0x4003419ba0)(172.31.161.158:4244/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001a14930)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40021f7c20)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4008802c78
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001d491a0,
  gcExited: (chan struct {}) 0x4001d49200,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001c2c680)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000add948)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd4a50)({
       metricMap: (*prometheus.metricMap)(0x4001cd4a80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b2e0c0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001c2c700)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000add950)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd4ae0)({
       metricMap: (*prometheus.metricMap)(0x4001cd4b10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b2e120)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001c2c780)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000add958)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd4b70)({
       metricMap: (*prometheus.metricMap)(0x4001cd4ba0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b2e180)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001c2c800)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000add968)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd4c00)({
       metricMap: (*prometheus.metricMap)(0x4001cd4c30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b2e1e0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001c2c880)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000add970)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd4c90)({
       metricMap: (*prometheus.metricMap)(0x4001cd4cc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b2e240)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001c2c900)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000add978)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd4d20)({
       metricMap: (*prometheus.metricMap)(0x4001cd4d50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b2e2a0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001c2c980)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000add980)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd4db0)({
       metricMap: (*prometheus.metricMap)(0x4001cd4de0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b2e300)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001c2ca00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000add988)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd4e40)({
       metricMap: (*prometheus.metricMap)(0x4001cd4e70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b2e360)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001c2ca80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000add990)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd4ed0)({
       metricMap: (*prometheus.metricMap)(0x4001cd4f00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b2e3c0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001a14930)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001d86230)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40014e9308)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 501ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
agent-labels:
mesh-auth-spiffe-trust-domain:spiffe.cilium
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
policy-trigger-interval:1s
enable-ipv6-big-tcp:false
tofqdns-pre-cache:
nodeport-addresses:
policy-queue-size:100
force-device-detection:false
operator-api-serve-addr:127.0.0.1:9234
enable-srv6:false
use-full-tls-context:false
enable-ipv4:true
enable-bpf-tproxy:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
node-port-algorithm:random
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-policy:default
bpf-lb-rev-nat-map-max:0
ipv6-node:auto
dnsproxy-lock-timeout:500ms
node-port-range:
disable-envoy-version-check:false
dnsproxy-concurrency-processing-grace-period:0s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
hubble-event-buffer-capacity:4095
hubble-recorder-sink-queue-size:1024
hubble-disable-tls:false
local-router-ipv6:
policy-accounting:true
external-envoy-proxy:true
config:
bpf-nat-global-max:524288
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-host-legacy-routing:false
enable-ipsec:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
use-cilium-internal-ip-for-ipsec:false
ipv4-service-range:auto
enable-bandwidth-manager:false
bgp-announce-lb-ip:false
bpf-lb-rss-ipv4-src-cidr:
enable-ipv6-masquerade:true
ipam-cilium-node-update-rate:15s
enable-svc-source-range-check:true
enable-l2-pod-announcements:false
k8s-require-ipv4-pod-cidr:false
enable-local-node-route:true
http-retry-timeout:0
enable-unreachable-routes:false
remove-cilium-node-taints:true
bpf-ct-timeout-regular-any:1m0s
bpf-events-trace-enabled:true
kvstore:
policy-cidr-match-mode:
identity-gc-interval:15m0s
bpf-neigh-global-max:524288
container-ip-local-reserved-ports:auto
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-auto-protect-node-port-range:true
exclude-local-address:
bpf-sock-rev-map-max:262144
metrics:
max-controller-interval:0
enable-k8s-networkpolicy:true
log-opt:
hubble-export-allowlist:
enable-ipip-termination:false
enable-l7-proxy:true
envoy-base-id:0
pprof-address:localhost
bpf-lb-acceleration:disabled
bpf-lb-source-range-map-max:0
gops-port:9890
proxy-xff-num-trusted-hops-egress:0
l2-announcements-lease-duration:15s
ipsec-key-file:
proxy-admin-port:0
enable-custom-calls:false
endpoint-queue-size:25
enable-tracing:false
max-connected-clusters:255
log-system-load:false
routing-mode:tunnel
cluster-name:cmesh31
kvstore-lease-ttl:15m0s
bpf-lb-service-map-max:0
egress-masquerade-interfaces:ens+
dnsproxy-enable-transparent-mode:true
monitor-aggregation:medium
clustermesh-sync-timeout:1m0s
kvstore-periodic-sync:5m0s
ingress-secrets-namespace:
preallocate-bpf-maps:false
hubble-event-queue-size:0
http-request-timeout:3600
enable-k8s-api-discovery:false
fixed-identity-mapping:
k8s-kubeconfig-path:
k8s-client-connection-timeout:30s
hubble-metrics:
iptables-lock-timeout:5s
gateway-api-secrets-namespace:
ipv6-native-routing-cidr:
enable-k8s-endpoint-slice:true
wireguard-persistent-keepalive:0s
enable-bpf-masquerade:false
bpf-lb-maglev-map-max:0
enable-hubble:true
clustermesh-config:/var/lib/cilium/clustermesh/
max-internal-timer-delay:0s
nat-map-stats-interval:30s
service-no-backend-response:reject
mesh-auth-queue-size:1024
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
proxy-portrange-min:10000
pprof-port:6060
enable-endpoint-health-checking:true
bpf-lb-affinity-map-max:0
read-cni-conf:
hubble-drop-events:false
bpf-lb-dsr-dispatch:opt
socket-path:/var/run/cilium/cilium.sock
mesh-auth-rotated-identities-queue-size:1024
mesh-auth-spire-admin-socket:
ipam:cluster-pool
ip-masq-agent-config-path:/etc/config/ip-masq-agent
debug:false
enable-identity-mark:true
bpf-lb-mode:snat
procfs:/host/proc
route-metric:0
cni-chaining-mode:none
cflags:
k8s-client-connection-keep-alive:30s
enable-sctp:false
bpf-events-policy-verdict-enabled:true
node-port-bind-protection:true
endpoint-bpf-prog-watchdog-interval:30s
tofqdns-min-ttl:0
bpf-node-map-max:16384
label-prefix-file:
cni-chaining-target:
bpf-ct-timeout-regular-tcp:2h13m20s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
node-port-acceleration:disabled
k8s-api-server:
ipam-default-ip-pool:default
cni-exclusive:true
cluster-id:31
tofqdns-max-deferred-connection-deletes:10000
bpf-root:/sys/fs/bpf
bpf-ct-timeout-regular-tcp-fin:10s
ipv6-service-range:auto
bgp-announce-pod-cidr:false
http-normalize-path:true
bpf-lb-algorithm:random
debug-verbose:
state-dir:/var/run/cilium
tofqdns-endpoint-max-ip-per-hostname:50
enable-bgp-control-plane:false
ipv6-range:auto
bpf-map-event-buffers:
cluster-pool-ipv4-mask-size:24
enable-pmtu-discovery:false
ipv6-mcast-device:
ipv6-cluster-alloc-cidr:f00d::/64
crd-wait-timeout:5m0s
log-driver:
set-cilium-node-taints:true
enable-tcx:true
proxy-max-connection-duration-seconds:0
bpf-events-drop-enabled:true
enable-external-ips:false
enable-wireguard:false
config-dir:/tmp/cilium/config-map
vlan-bpf-bypass:
mesh-auth-signal-backoff-duration:1s
devices:
multicast-enabled:false
proxy-prometheus-port:0
local-router-ipv4:
install-no-conntrack-iptables-rules:false
nat-map-stats-entries:32
egress-multi-home-ip-rule-compat:false
tofqdns-dns-reject-response-code:refused
cgroup-root:/run/cilium/cgroupv2
enable-health-checking:true
enable-monitor:true
enable-bpf-clock-probe:false
kube-proxy-replacement-healthz-bind-address:
enable-xdp-prefilter:false
clustermesh-enable-mcs-api:false
disable-endpoint-crd:false
enable-node-selector-labels:false
k8s-client-burst:20
enable-high-scale-ipcache:false
enable-health-check-nodeport:true
envoy-log:
bpf-ct-timeout-service-tcp:2h13m20s
restore:true
bpf-lb-map-max:65536
dnsproxy-lock-count:131
k8s-heartbeat-timeout:30s
monitor-aggregation-flags:all
enable-endpoint-routes:false
l2-announcements-renew-deadline:5s
enable-runtime-device-detection:true
vtep-cidr:
proxy-max-requests-per-connection:0
enable-cilium-endpoint-slice:false
cilium-endpoint-gc-interval:5m0s
agent-liveness-update-interval:1s
enable-session-affinity:false
hubble-export-file-max-size-mb:10
bpf-ct-timeout-service-tcp-grace:1m0s
identity-change-grace-period:5s
enable-envoy-config:false
enable-health-check-loadbalancer-ip:false
dns-policy-unload-on-shutdown:false
hubble-flowlogs-config-path:
vtep-endpoint:
disable-iptables-feeder-rules:
http-max-grpc-timeout:0
envoy-secrets-namespace:
ipsec-key-rotation-duration:5m0s
enable-ipv6:false
allocator-list-timeout:3m0s
prometheus-serve-addr:
mesh-auth-enabled:true
api-rate-limit:
identity-restore-grace-period:30s
enable-l2-neigh-discovery:true
tunnel-port:0
enable-well-known-identities:false
direct-routing-device:
tofqdns-idle-connection-grace-period:0s
conntrack-gc-max-interval:0s
config-sources:config-map:kube-system/cilium-config
mesh-auth-gc-interval:5m0s
enable-service-topology:false
egress-gateway-policy-map-max:16384
k8s-namespace:kube-system
agent-health-port:9879
bpf-lb-sock:false
bpf-lb-rss-ipv6-src-cidr:
http-idle-timeout:0
k8s-client-qps:10
hubble-drop-events-interval:2m0s
version:false
mesh-auth-mutual-connect-timeout:5s
bpf-ct-timeout-service-any:1m0s
hubble-drop-events-reasons:auth_required,policy_denied
enable-cilium-api-server-access:
tunnel-protocol:vxlan
enable-ipv6-ndp:false
operator-prometheus-serve-addr::9963
k8s-require-ipv6-pod-cidr:false
enable-local-redirect-policy:false
bpf-lb-sock-hostns-only:false
iptables-random-fully:false
bpf-lb-external-clusterip:false
enable-node-port:false
monitor-queue-size:0
bpf-ct-global-any-max:262144
k8s-service-cache-size:128
enable-ipv4-masquerade:true
bypass-ip-availability-upon-restore:false
k8s-service-proxy-name:
cluster-pool-ipv4-cidr:10.30.0.0/16
bpf-ct-global-tcp-max:524288
enable-route-mtu-for-cni-chaining:false
custom-cni-conf:false
bpf-auth-map-max:524288
enable-ipsec-key-watcher:true
enable-wireguard-userspace-fallback:false
set-cilium-is-up-condition:true
enable-metrics:true
bpf-policy-map-max:16384
dnsproxy-insecure-skip-transparent-mode-check:false
hubble-skip-unknown-cgroup-ids:true
auto-create-cilium-node-resource:true
bpf-policy-map-full-reconciliation-interval:15m0s
kvstore-max-consecutive-quorum-errors:2
enable-masquerade-to-route-source:false
mesh-auth-mutual-listener-port:0
enable-l2-announcements:false
enable-recorder:false
ipv4-range:auto
encryption-strict-mode-cidr:
trace-payloadlen:128
proxy-xff-num-trusted-hops-ingress:0
enable-ipv4-fragment-tracking:true
enable-vtep:false
prepend-iptables-chains:true
egress-gateway-reconciliation-trigger-interval:1s
dns-max-ips-per-restored-rule:1000
bpf-map-dynamic-size-ratio:0.0025
encrypt-node:false
hubble-redact-http-headers-allow:
ipv4-native-routing-cidr:
static-cnp-path:
enable-host-port:false
tofqdns-proxy-port:0
ipv4-node:auto
enable-nat46x64-gateway:false
policy-audit-mode:false
enable-stale-cilium-endpoint-cleanup:true
enable-k8s-terminating-endpoint:true
auto-direct-node-routes:false
unmanaged-pod-watcher-interval:15
enable-icmp-rules:true
bpf-filter-priority:1
bpf-lb-maglev-table-size:16381
hubble-redact-kafka-apikey:false
trace-sock:true
hubble-export-file-path:
node-port-mode:snat
enable-xt-socket-fallback:true
l2-pod-announcements-interface:
tofqdns-proxy-response-max-delay:100ms
clustermesh-ip-identities-sync-timeout:1m0s
enable-k8s:true
enable-ip-masq-agent:false
bpf-fragments-map-max:8192
hubble-export-denylist:
derive-masq-ip-addr-from-device:
vtep-mac:
datapath-mode:veth
hubble-socket-path:/var/run/cilium/hubble.sock
bpf-lb-sock-terminate-pod-connections:false
pprof:false
proxy-connect-timeout:2
monitor-aggregation-interval:5s
enable-encryption-strict-mode:false
ipam-multi-pool-pre-allocation:
hubble-export-file-compress:false
direct-routing-skip-unreachable:false
hubble-redact-enabled:false
disable-external-ip-mitigation:false
http-retry-count:3
arping-refresh-period:30s
lib-dir:/var/lib/cilium
hubble-redact-http-userinfo:true
hubble-prefer-ipv6:false
hubble-listen-address::4244
encryption-strict-mode-allow-remote-node-identities:false
proxy-idle-timeout-seconds:60
vtep-mask:
bpf-lb-dsr-l4-xlate:frontend
hubble-metrics-server:
annotate-k8s-node:false
srv6-encap-mode:reduced
kube-proxy-replacement:false
certificates-directory:/var/run/cilium/certs
ipv4-service-loopback-address:169.254.42.1
bpf-lb-service-backend-map-max:0
nodes-gc-interval:5m0s
join-cluster:false
ipv4-pod-subnets:
local-max-addr-scope:252
allow-localhost:auto
enable-mke:false
allow-icmp-frag-needed:true
cmdref:
encrypt-interface:
identity-heartbeat-timeout:30m0s
enable-ipsec-xfrm-state-caching:true
clustermesh-enable-endpoint-sync:false
enable-ipv4-big-tcp:false
k8s-sync-timeout:3m0s
mke-cgroup-mount:
synchronize-k8s-nodes:true
fqdn-regex-compile-lru-size:1024
enable-host-firewall:false
exclude-node-label-patterns:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
hubble-monitor-events:
node-labels:
kvstore-connectivity-timeout:2m0s
enable-active-connection-tracking:false
enable-ipv4-egress-gateway:false
envoy-keep-cap-netbindservice:false
tofqdns-enable-dns-compression:true
l2-announcements-retry-period:2s
cni-external-routing:false
hubble-redact-http-headers-deny:
identity-allocation-mode:crd
enable-bbr:false
mtu:0
cluster-health-port:4240
ipv6-pod-subnets:
hubble-export-fieldmask:
enable-cilium-health-api-server-access:
dnsproxy-socket-linger-timeout:10
keep-config:false
hubble-redact-http-urlquery:false
install-iptables-rules:true
enable-ingress-controller:false
proxy-gid:1337
conntrack-gc-interval:0s
hubble-export-file-max-backups:5
cni-log-file:/var/run/cilium/cilium-cni.log
envoy-config-timeout:2m0s
enable-hubble-recorder-api:true
enable-gateway-api:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
labels:
controller-group-metrics:
endpoint-gc-interval:5m0s
envoy-config-retry-interval:15s
enable-ipsec-encrypted-overlay:false
kvstore-opt:
proxy-portrange-max:20000
dnsproxy-concurrency-limit:0
```


#### Service list

```
ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.215.98:443 (active)     
                                        2 => 172.31.143.71:443 (active)     
2    10.100.175.10:443   ClusterIP      1 => 172.31.161.158:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.30.0.141:53 (active)        
                                        2 => 10.30.0.148:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.30.0.141:9153 (active)      
                                        2 => 10.30.0.148:9153 (active)      
5    10.100.49.96:2379   ClusterIP      1 => 10.30.0.33:2379 (active)       
```
