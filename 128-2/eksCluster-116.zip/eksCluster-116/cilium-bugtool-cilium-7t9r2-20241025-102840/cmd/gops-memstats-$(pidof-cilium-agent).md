alloc: 128.46MB (134695288 bytes)
total-alloc: 1.34GB (1442480856 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 48042165
frees: 46759122
heap-alloc: 128.46MB (134695288 bytes)
heap-sys: 161.23MB (169066496 bytes)
heap-idle: 12.55MB (13156352 bytes)
heap-in-use: 148.69MB (155910144 bytes)
heap-released: 2.88MB (3014656 bytes)
heap-objects: 1283043
stack-in-use: 34.72MB (36405248 bytes)
stack-sys: 34.72MB (36405248 bytes)
stack-mspan-inuse: 2.32MB (2429920 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 877.13KB (898185 bytes)
gc-sys: 5.19MB (5437768 bytes)
next-gc: when heap-alloc >= 157.83MB (165493560 bytes)
last-gc: 2024-10-25 10:28:41.617888969 +0000 UTC
gc-pause-total: 4.289668ms
gc-pause: 70271
gc-pause-end: 1729852121617888969
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.0003554954886086382
enable-gc: true
debug-gc: false
