ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.172.241:443 (active)   
                                         2 => 172.31.217.174:443 (active)   
2    10.100.9.203:443     ClusterIP      1 => 172.31.163.31:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.116.0.250:9153 (active)    
                                         2 => 10.116.0.168:9153 (active)    
4    10.100.0.10:53       ClusterIP      1 => 10.116.0.250:53 (active)      
                                         2 => 10.116.0.168:53 (active)      
5    10.100.68.213:2379   ClusterIP      1 => 10.116.0.114:2379 (active)    
