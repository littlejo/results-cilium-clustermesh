Endpoint ID: 124
Path: /sys/fs/bpf/tc/globals/cilium_policy_00124

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    432577   5510      0        
Allow    Ingress     1          ANY          NONE         disabled    9972     117       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 346
Path: /sys/fs/bpf/tc/globals/cilium_policy_00346

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 644
Path: /sys/fs/bpf/tc/globals/cilium_policy_00644

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3855178   36623     0        
Allow    Ingress     1          ANY          NONE         disabled    3324812   33760     0        
Allow    Egress      0          ANY          NONE         disabled    4919656   45169     0        


Endpoint ID: 863
Path: /sys/fs/bpf/tc/globals/cilium_policy_00863

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    63700   730       0        
Allow    Egress      0          ANY          NONE         disabled    12278   124       0        


Endpoint ID: 882
Path: /sys/fs/bpf/tc/globals/cilium_policy_00882

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    64294   739       0        
Allow    Egress      0          ANY          NONE         disabled    12316   124       0        


