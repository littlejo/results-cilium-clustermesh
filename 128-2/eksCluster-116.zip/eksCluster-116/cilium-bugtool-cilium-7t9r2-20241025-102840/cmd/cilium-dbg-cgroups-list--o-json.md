[
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d1b230b_f87f_4311_946b_43913e92f8f7.slice/cri-containerd-5326ba8e6da7f2982d053563532d77459b6d1d309de4fc4779f418be2fb71391.scope"
      }
    ],
    "ips": [
      "10.116.0.168"
    ],
    "name": "coredns-cc6ccd49c-cckwj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5412fc6a_5d3d_4fd5_b420_beb744802bd1.slice/cri-containerd-25306f57f6c357444f674e9a7ae43308c2f2567f2677dac994883160e5dcb252.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5412fc6a_5d3d_4fd5_b420_beb744802bd1.slice/cri-containerd-23993cbcf35cb203d025f7ab612d2af12ccf5cc902291dc6937f76bda4bee3f9.scope"
      },
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5412fc6a_5d3d_4fd5_b420_beb744802bd1.slice/cri-containerd-de95bc53c4ad5b557b0492e6ddf34bcffadeac27023ff1d04bda1eeb46fd6723.scope"
      }
    ],
    "ips": [
      "10.116.0.114"
    ],
    "name": "clustermesh-apiserver-66bc96f6cf-kkxrv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6774,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd17c2404_204c_465d_9c4f_2560442ddd07.slice/cri-containerd-e980599f86e782d20471d3f605d1865c37b9cb066410481727b7785d242c15b9.scope"
      }
    ],
    "ips": [
      "10.116.0.250"
    ],
    "name": "coredns-cc6ccd49c-mp48w",
    "namespace": "kube-system"
  }
]

