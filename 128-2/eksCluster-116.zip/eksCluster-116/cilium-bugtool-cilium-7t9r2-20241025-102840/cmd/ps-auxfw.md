USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         688  0.0  0.2 1616520 8848 ?        Ssl  10:28   0:00 /usr/sbin/runc init
root         674  0.0  0.4 1240432 16296 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         695  0.0  0.0   6408  1648 ?        R    10:28   0:00  \_ ps auxfw
root         658  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.6  7.1 1538100 279488 ?      Ssl  10:17   0:17 cilium-agent --config-dir=/tmp/cilium/config-map
root         390  0.0  0.1 1228848 5760 ?        Sl   10:17   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
