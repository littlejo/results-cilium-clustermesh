{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:51.047Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.163.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:51.047Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:55.131Z",
  "value": "id=124   sec_id=4     flags=0x0000 ifindex=7   mac=D6:D7:8B:AE:7F:B5 nodemac=1E:8A:A3:50:9D:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:55.135Z",
  "value": "id=863   sec_id=7689467 flags=0x0000 ifindex=9   mac=6A:07:AE:C6:58:35 nodemac=32:1E:55:15:37:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:55.202Z",
  "value": "id=882   sec_id=7689467 flags=0x0000 ifindex=11  mac=A6:B8:81:00:74:0E nodemac=12:03:E5:29:38:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:55.224Z",
  "value": "id=124   sec_id=4     flags=0x0000 ifindex=7   mac=D6:D7:8B:AE:7F:B5 nodemac=1E:8A:A3:50:9D:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:08.752Z",
  "value": "id=124   sec_id=4     flags=0x0000 ifindex=7   mac=D6:D7:8B:AE:7F:B5 nodemac=1E:8A:A3:50:9D:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:08.753Z",
  "value": "id=863   sec_id=7689467 flags=0x0000 ifindex=9   mac=6A:07:AE:C6:58:35 nodemac=32:1E:55:15:37:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:08.753Z",
  "value": "id=882   sec_id=7689467 flags=0x0000 ifindex=11  mac=A6:B8:81:00:74:0E nodemac=12:03:E5:29:38:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:08.782Z",
  "value": "id=3296  sec_id=7671537 flags=0x0000 ifindex=13  mac=F6:E4:36:B1:35:99 nodemac=96:F6:12:BB:FC:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:09.752Z",
  "value": "id=3296  sec_id=7671537 flags=0x0000 ifindex=13  mac=F6:E4:36:B1:35:99 nodemac=96:F6:12:BB:FC:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:09.753Z",
  "value": "id=124   sec_id=4     flags=0x0000 ifindex=7   mac=D6:D7:8B:AE:7F:B5 nodemac=1E:8A:A3:50:9D:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:09.753Z",
  "value": "id=863   sec_id=7689467 flags=0x0000 ifindex=9   mac=6A:07:AE:C6:58:35 nodemac=32:1E:55:15:37:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:09.753Z",
  "value": "id=882   sec_id=7689467 flags=0x0000 ifindex=11  mac=A6:B8:81:00:74:0E nodemac=12:03:E5:29:38:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:44.000Z",
  "value": "id=644   sec_id=7671537 flags=0x0000 ifindex=15  mac=2A:AC:98:5C:0E:A2 nodemac=06:B5:E6:93:56:AF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.116.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:49.015Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.535Z",
  "value": "id=882   sec_id=7689467 flags=0x0000 ifindex=11  mac=A6:B8:81:00:74:0E nodemac=12:03:E5:29:38:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.535Z",
  "value": "id=644   sec_id=7671537 flags=0x0000 ifindex=15  mac=2A:AC:98:5C:0E:A2 nodemac=06:B5:E6:93:56:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.536Z",
  "value": "id=124   sec_id=4     flags=0x0000 ifindex=7   mac=D6:D7:8B:AE:7F:B5 nodemac=1E:8A:A3:50:9D:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.537Z",
  "value": "id=863   sec_id=7689467 flags=0x0000 ifindex=9   mac=6A:07:AE:C6:58:35 nodemac=32:1E:55:15:37:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.535Z",
  "value": "id=644   sec_id=7671537 flags=0x0000 ifindex=15  mac=2A:AC:98:5C:0E:A2 nodemac=06:B5:E6:93:56:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.535Z",
  "value": "id=863   sec_id=7689467 flags=0x0000 ifindex=9   mac=6A:07:AE:C6:58:35 nodemac=32:1E:55:15:37:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.535Z",
  "value": "id=124   sec_id=4     flags=0x0000 ifindex=7   mac=D6:D7:8B:AE:7F:B5 nodemac=1E:8A:A3:50:9D:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.536Z",
  "value": "id=882   sec_id=7689467 flags=0x0000 ifindex=11  mac=A6:B8:81:00:74:0E nodemac=12:03:E5:29:38:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.536Z",
  "value": "id=863   sec_id=7689467 flags=0x0000 ifindex=9   mac=6A:07:AE:C6:58:35 nodemac=32:1E:55:15:37:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.536Z",
  "value": "id=644   sec_id=7671537 flags=0x0000 ifindex=15  mac=2A:AC:98:5C:0E:A2 nodemac=06:B5:E6:93:56:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.536Z",
  "value": "id=882   sec_id=7689467 flags=0x0000 ifindex=11  mac=A6:B8:81:00:74:0E nodemac=12:03:E5:29:38:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.536Z",
  "value": "id=124   sec_id=4     flags=0x0000 ifindex=7   mac=D6:D7:8B:AE:7F:B5 nodemac=1E:8A:A3:50:9D:F3"
}

