xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 506
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 499
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 494
cilium_host(4) clsact/egress cil_from_host-cilium_host id 495
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 442
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 443
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 514
lxcb74d373b8043(9) clsact/ingress cil_from_container-lxcb74d373b8043 id 488
lxcde42dcab570a(11) clsact/ingress cil_from_container-lxcde42dcab570a id 520
lxc331e18286e61(15) clsact/ingress cil_from_container-lxc331e18286e61 id 593

flow_dissector:

netfilter:

