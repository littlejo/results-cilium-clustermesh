key: 7c 00 00 00  value: 12 02 00 00
key: 84 02 00 00  value: 4e 02 00 00
key: 5f 03 00 00  value: e7 01 00 00
key: 72 03 00 00  value: 05 02 00 00
Found 4 elements
