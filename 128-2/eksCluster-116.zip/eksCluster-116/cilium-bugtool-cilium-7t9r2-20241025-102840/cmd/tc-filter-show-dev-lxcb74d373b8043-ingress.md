filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb74d373b8043 direct-action not_in_hw id 488 tag ac8f8e11419256d3 jited 
