29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:17:13+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:17:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
441: sched_cls  name tail_handle_ipv4  tag dae9d905c163fec8  gpl
	loaded_at 2024-10-25T10:17:53+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 112
442: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:17:53+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 113
443: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:17:53+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
444: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:17:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 115
467: sched_cls  name tail_ipv4_ct_ingress  tag 757c9052af153182  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 143
468: sched_cls  name __send_drop_notify  tag 3e5ecb6de83cb966  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 144
470: sched_cls  name tail_handle_ipv4_cont  tag abee34348023b892  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,97,74,75,31,68,66,69,100,32,29,30,73
	btf_id 146
471: sched_cls  name tail_handle_arp  tag 6353d73215215029  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 148
472: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 149
474: sched_cls  name tail_ipv4_to_endpoint  tag 3a303ce22c9f7957  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,97,31,100,32,29,30
	btf_id 150
477: sched_cls  name tail_ipv4_ct_egress  tag da3cff891f66c126  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 152
480: sched_cls  name tail_handle_ipv4  tag 88d822cae53e503a  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 155
487: sched_cls  name handle_policy  tag d504e01095093508  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,100,74,75,101,33,72,97,31,76,67,32,29,30
	btf_id 159
488: sched_cls  name cil_from_container  tag ac8f8e11419256d3  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,68
	btf_id 166
489: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,105
	btf_id 168
490: sched_cls  name __send_drop_notify  tag 90343490853050a1  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 169
491: sched_cls  name tail_handle_ipv4_from_host  tag 7ce76953e1cf1ce6  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,105
	btf_id 170
494: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 173
495: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,105
	btf_id 174
496: sched_cls  name tail_handle_ipv4_from_host  tag 7ce76953e1cf1ce6  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 176
499: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 179
501: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 181
502: sched_cls  name __send_drop_notify  tag 90343490853050a1  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 182
503: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 184
504: sched_cls  name __send_drop_notify  tag 90343490853050a1  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 185
505: sched_cls  name tail_handle_ipv4_from_host  tag 7ce76953e1cf1ce6  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 186
506: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,110,67
	btf_id 187
509: sched_cls  name tail_ipv4_ct_ingress  tag bf1932eb1c829cb7  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 165
510: sched_cls  name __send_drop_notify  tag 7fbec26167245b72  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 190
512: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,111
	btf_id 194
513: sched_cls  name tail_ipv4_ct_egress  tag da3cff891f66c126  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 191
514: sched_cls  name cil_from_container  tag 29f068f504531505  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 111,68
	btf_id 195
515: sched_cls  name tail_handle_arp  tag 197210258d82d803  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,111
	btf_id 197
516: sched_cls  name tail_ipv4_to_endpoint  tag 4338901c6866d410  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,104,33,74,75,72,102,31,103,32,29,30
	btf_id 196
517: sched_cls  name handle_policy  tag dbdcede66150ceff  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,103,74,75,104,33,72,102,31,76,67,32,29,30
	btf_id 199
518: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 198
519: sched_cls  name tail_handle_ipv4_cont  tag 7a0a1bc6b6e13e43  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,104,33,102,74,75,31,68,66,69,103,32,29,30,73
	btf_id 200
520: sched_cls  name cil_from_container  tag a386c7b2b2b03077  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,68
	btf_id 202
521: sched_cls  name tail_handle_arp  tag ae1519915fa9aebc  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 203
522: sched_cls  name tail_handle_ipv4  tag 45deaa56222dd852  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 204
523: sched_cls  name tail_handle_ipv4  tag 2c8ad70c0eff4431  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,111
	btf_id 201
524: sched_cls  name __send_drop_notify  tag 82b75f210a552d49  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 206
525: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 205
526: sched_cls  name tail_ipv4_to_endpoint  tag c1e2f6b04c593348  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,112,33,74,75,72,90,31,111,32,29,30
	btf_id 207
528: sched_cls  name tail_handle_ipv4_cont  tag d7d68426e757c140  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,112,33,90,74,75,31,68,66,69,111,32,29,30,73
	btf_id 209
529: sched_cls  name tail_ipv4_ct_ingress  tag 7a27c823bca5a5e5  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 210
530: sched_cls  name handle_policy  tag 7594e127d30f1cd4  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,111,74,75,112,33,72,90,31,76,67,32,29,30
	btf_id 211
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: sched_cls  name tail_handle_ipv4  tag e26405e60fbf3a70  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,128
	btf_id 227
587: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,128
	btf_id 228
589: sched_cls  name tail_handle_arp  tag 06d107db9d043f2c  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,128
	btf_id 230
590: sched_cls  name handle_policy  tag 430f3ce407d9b29f  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,128,74,75,129,33,72,127,31,76,67,32,29,30
	btf_id 231
591: sched_cls  name tail_ipv4_to_endpoint  tag 31cfca21a4aef0cf  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,129,33,74,75,72,127,31,128,32,29,30
	btf_id 232
592: sched_cls  name tail_ipv4_ct_ingress  tag 26ab078f60b5a66c  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 233
593: sched_cls  name cil_from_container  tag f74670cdb4d1fd97  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,68
	btf_id 234
594: sched_cls  name tail_handle_ipv4_cont  tag d0601266067a2150  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,129,33,127,74,75,31,68,66,69,128,32,29,30,73
	btf_id 235
595: sched_cls  name __send_drop_notify  tag acbd8550a66c7952  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 236
596: sched_cls  name tail_ipv4_ct_egress  tag 7a033772093cf3f6  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 237
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
