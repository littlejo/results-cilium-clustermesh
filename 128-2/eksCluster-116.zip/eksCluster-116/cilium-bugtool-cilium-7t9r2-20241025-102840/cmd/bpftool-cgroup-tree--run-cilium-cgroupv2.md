CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d1b230b_f87f_4311_946b_43913e92f8f7.slice/cri-containerd-10df68b0867f8c5db283318913ac2b4bbaf7372714fa453f2fe9c63fc98bda00.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d1b230b_f87f_4311_946b_43913e92f8f7.slice/cri-containerd-5326ba8e6da7f2982d053563532d77459b6d1d309de4fc4779f418be2fb71391.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod922f5880_5ff4_4414_a2d3_6428ea37b9d6.slice/cri-containerd-8e3b6b306476244f1ba285f1c00f677bff8e125fafd4f5e7d55f9234b9fa2031.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod922f5880_5ff4_4414_a2d3_6428ea37b9d6.slice/cri-containerd-73b715f01e8bc411f919d6b50a5a03990bad8060c0caef6fda4964a13e9faf21.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf56f0d97_f0c7_4a85_9a6d_1195721053f5.slice/cri-containerd-333ffaafe253a0a9c86fe41d45158c4163e436df437f266822b782cd9c2a84a4.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf56f0d97_f0c7_4a85_9a6d_1195721053f5.slice/cri-containerd-45f8000f9f6b0e53fe7643e2b13cb53168b0e8b20f923af4ae97ee8e5f6151fa.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd17c2404_204c_465d_9c4f_2560442ddd07.slice/cri-containerd-3a0f68bce8ef788f6053109fd521b023068147afc8f64688b569d2ce050ad056.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd17c2404_204c_465d_9c4f_2560442ddd07.slice/cri-containerd-e980599f86e782d20471d3f605d1865c37b9cb066410481727b7785d242c15b9.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod08aeb454_899b_4e30_adba_b1fe3c3c862f.slice/cri-containerd-b02586e91226a6bd24703e8ed32b763f3b35b64c6e63d5a2755b172805e8f447.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod08aeb454_899b_4e30_adba_b1fe3c3c862f.slice/cri-containerd-5a942495c40f74840cce86aa91892a4f174237e25cd6884c52e2b380f5e5fd15.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5412fc6a_5d3d_4fd5_b420_beb744802bd1.slice/cri-containerd-de95bc53c4ad5b557b0492e6ddf34bcffadeac27023ff1d04bda1eeb46fd6723.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5412fc6a_5d3d_4fd5_b420_beb744802bd1.slice/cri-containerd-da920ee0d7f8b45bca4e1ff872d0304539c927cdb3e4ac6d920ed6ca42bb85f9.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5412fc6a_5d3d_4fd5_b420_beb744802bd1.slice/cri-containerd-25306f57f6c357444f674e9a7ae43308c2f2567f2677dac994883160e5dcb252.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5412fc6a_5d3d_4fd5_b420_beb744802bd1.slice/cri-containerd-23993cbcf35cb203d025f7ab612d2af12ccf5cc902291dc6937f76bda4bee3f9.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0cd5c528_143d_41e6_9f5e_102eddfae2fe.slice/cri-containerd-cd8d899a0ac18efcd7b5e6a97eae28ca39e313d59bbf665a5bad708031354ff4.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0cd5c528_143d_41e6_9f5e_102eddfae2fe.slice/cri-containerd-44a23707537f375d31057a99462e92201788f12fb5742aa0c1a96643b8bac1a5.scope
    65       cgroup_device   multi                                          
