REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10023     786527      677    bpf_overlay.c
Interface                 INGRESS     221534    100262278   1132   bpf_host.c
Success                   EGRESS      10256     802652      53     encap.h
Success                   EGRESS      5169      398413      1694   bpf_host.c
Success                   EGRESS      93897     12414428    1308   bpf_lxc.c
Success                   INGRESS     105664    13001264    86     l3.h
Success                   INGRESS     111167    13433284    235    trace.h
Unsupported L3 protocol   EGRESS      37        2782        1492   bpf_lxc.c
