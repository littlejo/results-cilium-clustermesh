# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.116.0.0/24, 
Allocated addresses:
  10.116.0.114 (kube-system/clustermesh-apiserver-66bc96f6cf-kkxrv)
  10.116.0.139 (router)
  10.116.0.168 (kube-system/coredns-cc6ccd49c-cckwj)
  10.116.0.248 (health)
  10.116.0.250 (kube-system/coredns-cc6ccd49c-mp48w)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34ba2dd20a370c1d
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    20s ago        never        0       no error   
  ct-map-pressure                                                     21s ago        never        0       no error   
  daemon-validate-config                                              10s ago        never        0       no error   
  dns-garbage-collector-job                                           23s ago        never        0       no error   
  endpoint-124-regeneration-recovery                                  never          never        0       no error   
  endpoint-346-regeneration-recovery                                  never          never        0       no error   
  endpoint-644-regeneration-recovery                                  never          never        0       no error   
  endpoint-863-regeneration-recovery                                  never          never        0       no error   
  endpoint-882-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         1m23s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                21s ago        never        0       no error   
  ipcache-inject-labels                                               21s ago        never        0       no error   
  k8s-heartbeat                                                       23s ago        never        0       no error   
  link-cache                                                          6s ago         never        0       no error   
  local-identity-checkpoint                                           10m25s ago     never        0       no error   
  node-neighbor-link-updater                                          1s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m10s ago      never        0       no error   
  remote-etcd-cmesh10                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh100                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh101                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh102                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh103                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh104                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh105                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh106                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh107                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh108                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh109                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh11                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh110                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh111                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh112                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh113                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh114                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh115                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh116                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh118                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh119                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh12                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh120                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh121                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh122                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh123                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh124                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh125                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh126                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh127                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh128                                                7m10s ago      never        0       no error   
  remote-etcd-cmesh13                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh14                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh15                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh16                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh17                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh18                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh19                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh2                                                  7m10s ago      never        0       no error   
  remote-etcd-cmesh20                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh21                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh22                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh23                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh24                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh25                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh26                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh27                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh28                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh29                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh3                                                  7m10s ago      never        0       no error   
  remote-etcd-cmesh30                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh31                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh32                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh33                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh34                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh35                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh36                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh37                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh38                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh39                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh4                                                  7m10s ago      never        0       no error   
  remote-etcd-cmesh40                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh41                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh42                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh43                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh44                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh45                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh46                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh47                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh48                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh49                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh5                                                  7m10s ago      never        0       no error   
  remote-etcd-cmesh50                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh51                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh52                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh53                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh54                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh55                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh56                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh57                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh58                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh59                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh6                                                  7m10s ago      never        0       no error   
  remote-etcd-cmesh60                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh61                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh62                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh63                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh64                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh65                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh66                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh67                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh68                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh69                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh7                                                  7m10s ago      never        0       no error   
  remote-etcd-cmesh70                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh71                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh72                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh73                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh74                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh75                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh76                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh77                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh78                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh79                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh8                                                  7m10s ago      never        0       no error   
  remote-etcd-cmesh80                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh81                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh82                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh83                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh84                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh85                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh86                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh87                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh88                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh89                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh9                                                  7m10s ago      never        0       no error   
  remote-etcd-cmesh90                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh91                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh92                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh93                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh94                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh95                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh96                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh97                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh98                                                 7m10s ago      never        0       no error   
  remote-etcd-cmesh99                                                 7m10s ago      never        0       no error   
  resolve-identity-124                                                1m20s ago      never        0       no error   
  resolve-identity-346                                                1m21s ago      never        0       no error   
  resolve-identity-644                                                2m28s ago      never        0       no error   
  resolve-identity-863                                                1m19s ago      never        0       no error   
  resolve-identity-882                                                1m19s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-66bc96f6cf-kkxrv   7m28s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-cckwj                  11m19s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-mp48w                  11m19s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      11m21s ago     never        0       no error   
  sync-policymap-124                                                  11m17s ago     never        0       no error   
  sync-policymap-346                                                  11m20s ago     never        0       no error   
  sync-policymap-644                                                  7m28s ago      never        0       no error   
  sync-policymap-863                                                  11m17s ago     never        0       no error   
  sync-policymap-882                                                  11m17s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (644)                                    8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (863)                                    9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (882)                                    9s ago         never        0       no error   
  sync-utime                                                          21s ago        never        0       no error   
  write-cni-file                                                      11m23s ago     never        0       no error   
Proxy Status:            OK, ip 10.116.0.139, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 7667712, max 7733247
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 95.14   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
bgp-announce-pod-cidr:false
kvstore-max-consecutive-quorum-errors:2
tofqdns-min-ttl:0
synchronize-k8s-nodes:true
hubble-recorder-sink-queue-size:1024
bpf-events-trace-enabled:true
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
direct-routing-skip-unreachable:false
clustermesh-sync-timeout:1m0s
proxy-connect-timeout:2
kvstore-lease-ttl:15m0s
http-retry-count:3
ipv4-node:auto
hubble-export-fieldmask:
proxy-xff-num-trusted-hops-ingress:0
nat-map-stats-entries:32
monitor-queue-size:0
monitor-aggregation:medium
enable-host-port:false
enable-gateway-api:false
hubble-monitor-events:
mtu:0
enable-envoy-config:false
enable-k8s-networkpolicy:true
bpf-ct-timeout-regular-tcp-syn:1m0s
hubble-export-allowlist:
bpf-ct-timeout-service-tcp:2h13m20s
bpf-lb-service-backend-map-max:0
enable-health-check-loadbalancer-ip:false
enable-health-check-nodeport:true
enable-stale-cilium-endpoint-cleanup:true
bpf-lb-algorithm:random
bpf-lb-affinity-map-max:0
enable-tracing:false
enable-unreachable-routes:false
http-max-grpc-timeout:0
hubble-listen-address::4244
enable-runtime-device-detection:true
allow-localhost:auto
egress-gateway-policy-map-max:16384
k8s-require-ipv4-pod-cidr:false
dnsproxy-lock-count:131
enable-vtep:false
monitor-aggregation-flags:all
external-envoy-proxy:true
mesh-auth-rotated-identities-queue-size:1024
controller-group-metrics:
bpf-lb-rss-ipv4-src-cidr:
enable-custom-calls:false
enable-l7-proxy:true
srv6-encap-mode:reduced
lib-dir:/var/lib/cilium
enable-ipsec-key-watcher:true
bgp-announce-lb-ip:false
bpf-node-map-max:16384
hubble-event-queue-size:0
config-sources:config-map:kube-system/cilium-config
ipv6-service-range:auto
enable-bpf-tproxy:false
ipam-multi-pool-pre-allocation:
tofqdns-endpoint-max-ip-per-hostname:50
envoy-secrets-namespace:
hubble-metrics-server:
bpf-lb-sock-terminate-pod-connections:false
gops-port:9890
api-rate-limit:
wireguard-persistent-keepalive:0s
enable-ipv4:true
auto-create-cilium-node-resource:true
k8s-client-connection-timeout:30s
l2-announcements-lease-duration:15s
tunnel-protocol:vxlan
procfs:/host/proc
install-no-conntrack-iptables-rules:false
enable-tcx:true
arping-refresh-period:30s
node-labels:
kube-proxy-replacement:false
enable-ingress-controller:false
annotate-k8s-node:false
k8s-client-qps:10
enable-pmtu-discovery:false
enable-route-mtu-for-cni-chaining:false
enable-wireguard:false
state-dir:/var/run/cilium
enable-wireguard-userspace-fallback:false
proxy-admin-port:0
routing-mode:tunnel
hubble-event-buffer-capacity:4095
vtep-mac:
hubble-metrics:
route-metric:0
enable-health-checking:true
join-cluster:false
enable-ipv6:false
enable-cilium-endpoint-slice:false
clustermesh-enable-mcs-api:false
enable-l2-announcements:false
direct-routing-device:
enable-local-redirect-policy:false
iptables-lock-timeout:5s
pprof:false
enable-recorder:false
keep-config:false
egress-masquerade-interfaces:ens+
enable-service-topology:false
tofqdns-max-deferred-connection-deletes:10000
l2-pod-announcements-interface:
nodeport-addresses:
config:
enable-ipip-termination:false
node-port-algorithm:random
http-idle-timeout:0
clustermesh-config:/var/lib/cilium/clustermesh/
envoy-config-retry-interval:15s
trace-sock:true
bpf-lb-maglev-table-size:16381
bpf-policy-map-full-reconciliation-interval:15m0s
enable-bpf-clock-probe:false
multicast-enabled:false
hubble-export-file-max-size-mb:10
enable-ipv6-big-tcp:false
allocator-list-timeout:3m0s
pprof-address:localhost
cluster-pool-ipv4-mask-size:24
kvstore-connectivity-timeout:2m0s
enable-ipv4-big-tcp:false
enable-ipsec:false
mesh-auth-mutual-listener-port:0
nat-map-stats-interval:30s
hubble-redact-http-headers-deny:
enable-sctp:false
bpf-auth-map-max:524288
mesh-auth-queue-size:1024
bpf-neigh-global-max:524288
enable-bpf-masquerade:false
http-retry-timeout:0
identity-allocation-mode:crd
cmdref:
bpf-nat-global-max:524288
bpf-lb-dsr-l4-xlate:frontend
ipsec-key-file:
egress-gateway-reconciliation-trigger-interval:1s
unmanaged-pod-watcher-interval:15
bpf-ct-timeout-regular-tcp-fin:10s
enable-encryption-strict-mode:false
bpf-ct-timeout-service-any:1m0s
devices:
hubble-redact-kafka-apikey:false
cni-external-routing:false
proxy-max-requests-per-connection:0
exclude-local-address:
dnsproxy-concurrency-limit:0
cluster-id:117
debug-verbose:
bpf-map-dynamic-size-ratio:0.0025
local-router-ipv6:
tofqdns-proxy-response-max-delay:100ms
cluster-name:cmesh117
certificates-directory:/var/run/cilium/certs
cni-log-file:/var/run/cilium/cilium-cni.log
k8s-require-ipv6-pod-cidr:false
log-driver:
hubble-export-file-path:
bpf-lb-service-map-max:0
exclude-node-label-patterns:
ipam:cluster-pool
prepend-iptables-chains:true
ingress-secrets-namespace:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-identity-mark:true
ipv4-native-routing-cidr:
trace-payloadlen:128
hubble-drop-events-interval:2m0s
hubble-drop-events-reasons:auth_required,policy_denied
kvstore-periodic-sync:5m0s
envoy-keep-cap-netbindservice:false
remove-cilium-node-taints:true
conntrack-gc-interval:0s
l2-announcements-renew-deadline:5s
cilium-endpoint-gc-interval:5m0s
enable-high-scale-ipcache:false
k8s-client-connection-keep-alive:30s
ipv4-service-range:auto
enable-svc-source-range-check:true
use-cilium-internal-ip-for-ipsec:false
tofqdns-dns-reject-response-code:refused
dnsproxy-socket-linger-timeout:10
ipv4-pod-subnets:
bypass-ip-availability-upon-restore:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
bpf-ct-global-tcp-max:524288
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
gateway-api-secrets-namespace:
agent-liveness-update-interval:1s
enable-external-ips:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-node-port:false
enable-ipsec-xfrm-state-caching:true
mesh-auth-gc-interval:5m0s
policy-audit-mode:false
enable-xt-socket-fallback:true
enable-bandwidth-manager:false
bpf-lb-maglev-map-max:0
debug:false
hubble-export-file-max-backups:5
bpf-lb-sock-hostns-only:false
enable-srv6:false
read-cni-conf:
envoy-config-timeout:2m0s
encrypt-interface:
tofqdns-proxy-port:0
enable-ipsec-encrypted-overlay:false
encryption-strict-mode-cidr:
hubble-redact-http-userinfo:true
kvstore:
k8s-heartbeat-timeout:30s
disable-endpoint-crd:false
bpf-lb-sock:false
tofqdns-pre-cache:
proxy-portrange-max:20000
enable-mke:false
custom-cni-conf:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
hubble-redact-enabled:false
clustermesh-enable-endpoint-sync:false
cgroup-root:/run/cilium/cgroupv2
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
http-request-timeout:3600
enable-k8s-terminating-endpoint:true
enable-ip-masq-agent:false
identity-restore-grace-period:30s
node-port-mode:snat
fixed-identity-mapping:
k8s-api-server:
dnsproxy-concurrency-processing-grace-period:0s
bpf-events-drop-enabled:true
disable-iptables-feeder-rules:
dnsproxy-enable-transparent-mode:true
envoy-log:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
encrypt-node:false
proxy-xff-num-trusted-hops-egress:0
local-max-addr-scope:252
fqdn-regex-compile-lru-size:1024
k8s-service-cache-size:128
endpoint-queue-size:25
cluster-pool-ipv4-cidr:10.116.0.0/16
bpf-ct-global-any-max:262144
enable-auto-protect-node-port-range:true
clustermesh-ip-identities-sync-timeout:1m0s
egress-multi-home-ip-rule-compat:false
enable-icmp-rules:true
dns-policy-unload-on-shutdown:false
k8s-client-burst:20
enable-l2-pod-announcements:false
bpf-ct-timeout-regular-tcp:2h13m20s
operator-prometheus-serve-addr::9963
enable-cilium-health-api-server-access:
cluster-health-port:4240
agent-labels:
bpf-map-event-buffers:
enable-node-selector-labels:false
dnsproxy-lock-timeout:500ms
datapath-mode:veth
enable-active-connection-tracking:false
max-connected-clusters:255
metrics:
enable-nat46x64-gateway:false
ipv6-range:auto
enable-ipv4-masquerade:true
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
vtep-endpoint:
encryption-strict-mode-allow-remote-node-identities:false
crd-wait-timeout:5m0s
config-dir:/tmp/cilium/config-map
force-device-detection:false
log-system-load:false
policy-cidr-match-mode:
preallocate-bpf-maps:false
bpf-root:/sys/fs/bpf
ipsec-key-rotation-duration:5m0s
tofqdns-enable-dns-compression:true
use-full-tls-context:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
cni-exclusive:true
iptables-random-fully:false
tunnel-port:0
ipv6-pod-subnets:
bpf-lb-rss-ipv6-src-cidr:
l2-announcements-retry-period:2s
dns-max-ips-per-restored-rule:1000
service-no-backend-response:reject
set-cilium-node-taints:true
disable-envoy-version-check:false
vlan-bpf-bypass:
bpf-policy-map-max:16384
kube-proxy-replacement-healthz-bind-address:
hubble-skip-unknown-cgroup-ids:true
monitor-aggregation-interval:5s
enable-hubble-recorder-api:true
cni-chaining-mode:none
bpf-events-policy-verdict-enabled:true
enable-k8s-api-discovery:false
enable-cilium-api-server-access:
static-cnp-path:
bpf-lb-dsr-dispatch:opt
operator-api-serve-addr:127.0.0.1:9234
mke-cgroup-mount:
ipv6-native-routing-cidr:
tofqdns-idle-connection-grace-period:0s
ipv4-service-loopback-address:169.254.42.1
set-cilium-is-up-condition:true
ipv6-cluster-alloc-cidr:f00d::/64
ipam-cilium-node-update-rate:15s
hubble-export-file-compress:false
policy-trigger-interval:1s
bpf-lb-acceleration:disabled
socket-path:/var/run/cilium/cilium.sock
version:false
log-opt:
allow-icmp-frag-needed:true
restore:true
hubble-prefer-ipv6:false
bpf-fragments-map-max:8192
hubble-redact-http-headers-allow:
http-normalize-path:true
mesh-auth-mutual-connect-timeout:5s
bpf-sock-rev-map-max:262144
conntrack-gc-max-interval:0s
enable-k8s:true
max-internal-timer-delay:0s
enable-monitor:true
pprof-port:6060
dnsproxy-insecure-skip-transparent-mode-check:false
policy-queue-size:100
policy-accounting:true
enable-endpoint-routes:false
hubble-redact-http-urlquery:false
hubble-disable-tls:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-metrics:true
enable-bgp-control-plane:false
enable-ipv6-masquerade:true
ipv4-range:auto
enable-l2-neigh-discovery:true
bpf-ct-timeout-regular-any:1m0s
k8s-service-proxy-name:
vtep-cidr:
hubble-export-denylist:
node-port-range:
enable-bbr:false
hubble-flowlogs-config-path:
identity-heartbeat-timeout:30m0s
install-iptables-rules:true
endpoint-gc-interval:5m0s
derive-masq-ip-addr-from-device:
cni-chaining-target:
cflags:
enable-ipv4-fragment-tracking:true
bpf-lb-rev-nat-map-max:0
mesh-auth-signal-backoff-duration:1s
enable-masquerade-to-route-source:false
node-port-bind-protection:true
proxy-gid:1337
mesh-auth-spiffe-trust-domain:spiffe.cilium
k8s-kubeconfig-path:
proxy-idle-timeout-seconds:60
identity-change-grace-period:5s
proxy-portrange-min:10000
node-port-acceleration:disabled
envoy-base-id:0
proxy-max-connection-duration-seconds:0
ipv6-node:auto
k8s-namespace:kube-system
hubble-drop-events:false
ipam-default-ip-pool:default
disable-external-ip-mitigation:false
agent-health-port:9879
enable-session-affinity:false
proxy-prometheus-port:0
label-prefix-file:
container-ip-local-reserved-ports:auto
bpf-lb-source-range-map-max:0
endpoint-bpf-prog-watchdog-interval:30s
mesh-auth-enabled:true
enable-ipv4-egress-gateway:false
ipv6-mcast-device:
bpf-lb-mode:snat
bpf-filter-priority:1
labels:
bpf-lb-external-clusterip:false
local-router-ipv4:
prometheus-serve-addr:
enable-host-legacy-routing:false
identity-gc-interval:15m0s
enable-local-node-route:true
enable-endpoint-health-checking:true
vtep-mask:
enable-ipv6-ndp:false
auto-direct-node-routes:false
nodes-gc-interval:5m0s
enable-k8s-endpoint-slice:true
mesh-auth-spire-admin-socket:
enable-hubble:true
hubble-socket-path:/var/run/cilium/hubble.sock
kvstore-opt:
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-lb-map-max:65536
k8s-sync-timeout:3m0s
max-controller-interval:0
enable-policy:default
enable-host-firewall:false
enable-well-known-identities:false
enable-xdp-prefilter:false
```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 39873287                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 39873287                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 39873287                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400cc00000 rw-p 00000000 00:00 0 
400cc00000-4010000000 ---p 00000000 00:00 0 
ffff5de8d000-ffff5e0a3000 rw-p 00000000 00:00 0 
ffff5e0ab000-ffff5e18c000 rw-p 00000000 00:00 0 
ffff5e18c000-ffff5e1cd000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff5e1cd000-ffff5e20e000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff5e20e000-ffff5e24e000 rw-p 00000000 00:00 0 
ffff5e24e000-ffff5e250000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff5e250000-ffff5e252000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff5e252000-ffff5e809000 rw-p 00000000 00:00 0 
ffff5e809000-ffff5e909000 rw-p 00000000 00:00 0 
ffff5e909000-ffff5e91a000 rw-p 00000000 00:00 0 
ffff5e91a000-ffff6091a000 rw-p 00000000 00:00 0 
ffff6091a000-ffff6099a000 ---p 00000000 00:00 0 
ffff6099a000-ffff6099b000 rw-p 00000000 00:00 0 
ffff6099b000-ffff8099a000 ---p 00000000 00:00 0 
ffff8099a000-ffff8099b000 rw-p 00000000 00:00 0 
ffff8099b000-ffffa092a000 ---p 00000000 00:00 0 
ffffa092a000-ffffa092b000 rw-p 00000000 00:00 0 
ffffa092b000-ffffa491c000 ---p 00000000 00:00 0 
ffffa491c000-ffffa491d000 rw-p 00000000 00:00 0 
ffffa491d000-ffffa511a000 ---p 00000000 00:00 0 
ffffa511a000-ffffa511b000 rw-p 00000000 00:00 0 
ffffa511b000-ffffa521a000 ---p 00000000 00:00 0 
ffffa521a000-ffffa527a000 rw-p 00000000 00:00 0 
ffffa527a000-ffffa527c000 r--p 00000000 00:00 0                          [vvar]
ffffa527c000-ffffa527d000 r-xp 00000000 00:00 0                          [vdso]
ffffdb18b000-ffffdb1ac000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=12) "10.116.0.139": (string) (len=6) "router",
  (string) (len=12) "10.116.0.248": (string) (len=6) "health",
  (string) (len=12) "10.116.0.250": (string) (len=35) "kube-system/coredns-cc6ccd49c-mp48w",
  (string) (len=12) "10.116.0.168": (string) (len=35) "kube-system/coredns-cc6ccd49c-cckwj",
  (string) (len=12) "10.116.0.114": (string) (len=50) "kube-system/clustermesh-apiserver-66bc96f6cf-kkxrv"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.163.31": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4002387290)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4000ee6c00,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4000ee6c00,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001832a50)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001832b00)(frontends:[10.100.9.203]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001832bb0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x400257a0b0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002e50790)(frontends:[10.100.68.213]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000d6dd38)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40015ab520)(172.31.172.241:443/TCP,172.31.217.174:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000d6dd40)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-vf5zn": (*k8s.Endpoints)(0x400257dd40)(172.31.163.31:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000d6dd48)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-bxn92": (*k8s.Endpoints)(0x40036bc8f0)(10.116.0.168:53/TCP[eu-west-3a],10.116.0.168:53/UDP[eu-west-3a],10.116.0.168:9153/TCP[eu-west-3a],10.116.0.250:53/TCP[eu-west-3a],10.116.0.250:53/UDP[eu-west-3a],10.116.0.250:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40015325a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-94mnv": (*k8s.Endpoints)(0x40015aaa90)(10.116.0.114:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40023aab60)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40028a32c0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4009a36318
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40028a8ea0,
  gcExited: (chan struct {}) 0x40028a8f00,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40023c7c00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001a308a8)({
      MetricVec: (*prometheus.MetricVec)(0x4000817230)({
       metricMap: (*prometheus.metricMap)(0x4000817260)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002397140)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40023c7c80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001a308b0)({
      MetricVec: (*prometheus.MetricVec)(0x4000817320)({
       metricMap: (*prometheus.metricMap)(0x4000817350)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40023971a0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40023c7d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a308b8)({
      MetricVec: (*prometheus.MetricVec)(0x40008173b0)({
       metricMap: (*prometheus.metricMap)(0x40008173e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002397200)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40023c7d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a308c0)({
      MetricVec: (*prometheus.MetricVec)(0x40008174a0)({
       metricMap: (*prometheus.metricMap)(0x40008174d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002397260)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40023c7e00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a308c8)({
      MetricVec: (*prometheus.MetricVec)(0x4000817530)({
       metricMap: (*prometheus.metricMap)(0x4000817560)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40023972c0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40023c7e80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a308d0)({
      MetricVec: (*prometheus.MetricVec)(0x40008175c0)({
       metricMap: (*prometheus.metricMap)(0x40008175f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002397320)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40023c7f00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a308d8)({
      MetricVec: (*prometheus.MetricVec)(0x4000817680)({
       metricMap: (*prometheus.metricMap)(0x40008176b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002397380)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001452800)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a308e0)({
      MetricVec: (*prometheus.MetricVec)(0x4000817710)({
       metricMap: (*prometheus.metricMap)(0x4000817740)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40023973e0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001452880)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001a308e8)({
      MetricVec: (*prometheus.MetricVec)(0x40008177a0)({
       metricMap: (*prometheus.metricMap)(0x4000817800)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002397440)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40023aab60)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40023abce0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4000078f90)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 320ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
124        Disabled           Disabled          4          reserved:health                                                                     10.116.0.248   ready   
346        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                 
                                                           reserved:host                                                                                              
644        Disabled           Disabled          7671537    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.116.0.114   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh117                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
863        Disabled           Disabled          7689467    k8s:eks.amazonaws.com/component=coredns                                             10.116.0.250   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh117                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
882        Disabled           Disabled          7689467    k8s:eks.amazonaws.com/component=coredns                                             10.116.0.168   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh117                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
```

#### BPF Policy Get 124

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    431954   5502      0        
Allow    Ingress     1          ANY          NONE         disabled    9972     117       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 124

```
Invalid argument: unknown type 124
```


#### Endpoint Get 124

```
[
  {
    "id": 124,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-124-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8766e854-a794-4bbb-807f-1643b9c082b1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-124",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:52.215Z",
            "success-count": 3
          },
          "uuid": "0e877067-b352-44d2-8b94-61b74451710c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-124",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:55.132Z",
            "success-count": 1
          },
          "uuid": "3bc1e3e1-9c1c-434e-bf24-cba2af01a18a"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.116.0.248",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "1e:8a:a3:50:9d:f3",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "d6:d7:8b:ae:7f:b5"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 124

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 124

```
Timestamp              Status   State                   Message
2024-10-25T10:22:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:17:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:52Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:52Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 346

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 346

```
Invalid argument: unknown type 346
```


#### Endpoint Get 346

```
[
  {
    "id": 346,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-346-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "26983108-2afd-4de1-91d5-1932af8b5004"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-346",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:51.165Z",
            "success-count": 3
          },
          "uuid": "eb8e1ec9-c0ab-4cf8-941b-3bf3c4b9a955"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-346",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:52.145Z",
            "success-count": 1
          },
          "uuid": "adf17db1-6a40-4483-ba7d-732c13279ce4"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "b2:8f:e2:ab:aa:36",
        "interface-name": "cilium_host",
        "mac": "b2:8f:e2:ab:aa:36"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 346

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 346

```
Timestamp              Status   State                   Message
2024-10-25T10:22:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:17:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:55Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:17:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:17:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:17:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:51Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:51Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 644

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3853118   36600     0        
Allow    Ingress     1          ANY          NONE         disabled    3323848   33749     0        
Allow    Egress      0          ANY          NONE         disabled    4916214   45131     0        

```


#### BPF CT List 644

```
Invalid argument: unknown type 644
```


#### Endpoint Get 644

```
[
  {
    "id": 644,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-644-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "600e1432-eecb-49d7-bf10-d89e224c5baa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-644",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:43.972Z",
            "success-count": 2
          },
          "uuid": "f71cf5e0-6930-4fa0-842e-8abdf95ae018"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-66bc96f6cf-kkxrv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:43.971Z",
            "success-count": 1
          },
          "uuid": "0a456c3d-a204-482c-be9f-e4f46a87b7a7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-644",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:44.000Z",
            "success-count": 1
          },
          "uuid": "a342514e-b8cf-4713-a66e-f1aa945c1be0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (644)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:04.018Z",
            "success-count": 46
          },
          "uuid": "287bc18a-2c9d-4a96-aee7-92553eca2e75"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "da920ee0d7f8b45bca4e1ff872d0304539c927cdb3e4ac6d920ed6ca42bb85f9:eth0",
        "container-id": "da920ee0d7f8b45bca4e1ff872d0304539c927cdb3e4ac6d920ed6ca42bb85f9",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-66bc96f6cf-kkxrv",
        "pod-name": "kube-system/clustermesh-apiserver-66bc96f6cf-kkxrv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7671537,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh117",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=66bc96f6cf"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh117",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.116.0.114",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "06:b5:e6:93:56:af",
        "interface-index": 15,
        "interface-name": "lxc331e18286e61",
        "mac": "2a:ac:98:5c:0e:a2"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7671537,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7671537,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 644

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 644

```
Timestamp              Status   State                   Message
2024-10-25T10:22:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:43Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:43Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7671537

```
ID        LABELS
7671537   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh117
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 863

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    63700   730       0        
Allow    Egress      0          ANY          NONE         disabled    12278   124       0        

```


#### BPF CT List 863

```
Invalid argument: unknown type 863
```


#### Endpoint Get 863

```
[
  {
    "id": 863,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-863-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0573bcec-c6b8-496b-b6be-52c8d01af557"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-863",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:52.981Z",
            "success-count": 3
          },
          "uuid": "a53b48a7-f119-420e-a4e4-52864c7697fb"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-mp48w",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:52.980Z",
            "success-count": 1
          },
          "uuid": "143d2d3a-c910-4d37-9366-8ee3852776a9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-863",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:55.141Z",
            "success-count": 1
          },
          "uuid": "17edcd19-9c9e-491b-a8ec-6ff39ceec8b3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (863)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.058Z",
            "success-count": 70
          },
          "uuid": "e51b5436-7d3e-416b-98b8-3bf0a8adea60"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3a0f68bce8ef788f6053109fd521b023068147afc8f64688b569d2ce050ad056:eth0",
        "container-id": "3a0f68bce8ef788f6053109fd521b023068147afc8f64688b569d2ce050ad056",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-mp48w",
        "pod-name": "kube-system/coredns-cc6ccd49c-mp48w"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7689467,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh117",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh117",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.116.0.250",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "32:1e:55:15:37:9f",
        "interface-index": 9,
        "interface-name": "lxcb74d373b8043",
        "mac": "6a:07:ae:c6:58:35"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7689467,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7689467,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 863

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 863

```
Timestamp              Status    State                   Message
2024-10-25T10:22:03Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:08Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:08Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:08Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:54Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:53Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:53Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:17:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:52Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:17:52Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 7689467

```
ID        LABELS
7689467   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh117
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 882

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    64294   739       0        
Allow    Egress      0          ANY          NONE         disabled    12316   124       0        

```


#### BPF CT List 882

```
Invalid argument: unknown type 882
```


#### Endpoint Get 882

```
[
  {
    "id": 882,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-882-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "012b39d1-d14d-462b-9850-73e2283605a6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-882",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:53.043Z",
            "success-count": 3
          },
          "uuid": "d43e62dd-3370-45ca-a4bc-c9fb30de5b77"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-cckwj",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:53.041Z",
            "success-count": 1
          },
          "uuid": "a7cefc2e-d717-4a4d-a003-4945ce2991ce"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-882",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:55.203Z",
            "success-count": 1
          },
          "uuid": "f807fa46-ce85-4414-af38-df2b703a55c5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (882)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.113Z",
            "success-count": 70
          },
          "uuid": "5c57a5fc-d0fb-488c-95bd-c4a4da4ac2e6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "10df68b0867f8c5db283318913ac2b4bbaf7372714fa453f2fe9c63fc98bda00:eth0",
        "container-id": "10df68b0867f8c5db283318913ac2b4bbaf7372714fa453f2fe9c63fc98bda00",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-cckwj",
        "pod-name": "kube-system/coredns-cc6ccd49c-cckwj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7689467,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh117",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh117",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.116.0.168",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "12:03:e5:29:38:6b",
        "interface-index": 11,
        "interface-name": "lxcde42dcab570a",
        "mac": "a6:b8:81:00:74:0e"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7689467,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7689467,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 882

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 882

```
Timestamp              Status   State                   Message
2024-10-25T10:22:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:17:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:53Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:53Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7689467

```
ID        LABELS
7689467   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh117
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.172.241:443 (active)   
                                         2 => 172.31.217.174:443 (active)   
2    10.100.9.203:443     ClusterIP      1 => 172.31.163.31:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.116.0.250:9153 (active)    
                                         2 => 10.116.0.168:9153 (active)    
4    10.100.0.10:53       ClusterIP      1 => 10.116.0.250:53 (active)      
                                         2 => 10.116.0.168:53 (active)      
5    10.100.68.213:2379   ClusterIP      1 => 10.116.0.114:2379 (active)    
```

#### Policy get

```
:
 []
Revision: 1

```

