1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:72:1e:da:5f:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.163.31/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2914sec preferred_lft 2914sec
    inet6 fe80::472:1eff:feda:5fcd/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:6e:96:df:e4:7c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c6e:96ff:fedf:e47c/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:8f:e2:ab:aa:36 brd ff:ff:ff:ff:ff:ff
    inet 10.116.0.139/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b08f:e2ff:feab:aa36/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ca:95:20:87:20:97 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c895:20ff:fe87:2097/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:8a:a3:50:9d:f3 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1c8a:a3ff:fe50:9df3/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcb74d373b8043@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:1e:55:15:37:9f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::301e:55ff:fe15:379f/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcde42dcab570a@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:03:e5:29:38:6b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1003:e5ff:fe29:386b/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc331e18286e61@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:b5:e6:93:56:af brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4b5:e6ff:fe93:56af/64 scope link 
       valid_lft forever preferred_lft forever
