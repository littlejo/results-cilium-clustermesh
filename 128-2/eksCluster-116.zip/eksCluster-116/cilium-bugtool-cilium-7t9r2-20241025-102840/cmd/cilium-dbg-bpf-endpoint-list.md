IP ADDRESS        LOCAL ENDPOINT INFO
10.116.0.139:0    (localhost)                                                                                        
172.31.163.31:0   (localhost)                                                                                        
10.116.0.250:0    id=863   sec_id=7689467 flags=0x0000 ifindex=9   mac=6A:07:AE:C6:58:35 nodemac=32:1E:55:15:37:9F   
10.116.0.168:0    id=882   sec_id=7689467 flags=0x0000 ifindex=11  mac=A6:B8:81:00:74:0E nodemac=12:03:E5:29:38:6B   
10.116.0.114:0    id=644   sec_id=7671537 flags=0x0000 ifindex=15  mac=2A:AC:98:5C:0E:A2 nodemac=06:B5:E6:93:56:AF   
10.116.0.248:0    id=124   sec_id=4     flags=0x0000 ifindex=7   mac=D6:D7:8B:AE:7F:B5 nodemac=1E:8A:A3:50:9D:F3     
