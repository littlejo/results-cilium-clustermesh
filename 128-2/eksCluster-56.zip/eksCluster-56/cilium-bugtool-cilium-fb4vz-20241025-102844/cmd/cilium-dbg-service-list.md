ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.145.77:443 (active)    
                                          2 => 172.31.226.213:443 (active)   
2    10.100.5.254:443      ClusterIP      1 => 172.31.158.50:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.56.0.160:53 (active)       
                                          2 => 10.56.0.41:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.56.0.160:9153 (active)     
                                          2 => 10.56.0.41:9153 (active)      
5    10.100.110.141:2379   ClusterIP      1 => 10.56.0.249:2379 (active)     
