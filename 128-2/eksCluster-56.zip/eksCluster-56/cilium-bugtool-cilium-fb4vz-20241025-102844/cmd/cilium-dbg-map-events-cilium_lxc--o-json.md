{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:49.838Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.158.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:49.838Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.170.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:49.838Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.487Z",
  "value": "id=1070  sec_id=4     flags=0x0000 ifindex=10  mac=B6:E5:D5:F5:EE:0A nodemac=B6:37:85:EE:7E:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.492Z",
  "value": "id=3459  sec_id=3739806 flags=0x0000 ifindex=12  mac=E2:AD:9E:BB:22:5C nodemac=FA:C7:9C:B1:8F:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.543Z",
  "value": "id=1070  sec_id=4     flags=0x0000 ifindex=10  mac=B6:E5:D5:F5:EE:0A nodemac=B6:37:85:EE:7E:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.544Z",
  "value": "id=3459  sec_id=3739806 flags=0x0000 ifindex=12  mac=E2:AD:9E:BB:22:5C nodemac=FA:C7:9C:B1:8F:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.545Z",
  "value": "id=610   sec_id=3739806 flags=0x0000 ifindex=14  mac=EE:79:21:46:38:E3 nodemac=32:DA:30:BA:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.017Z",
  "value": "id=1070  sec_id=4     flags=0x0000 ifindex=10  mac=B6:E5:D5:F5:EE:0A nodemac=B6:37:85:EE:7E:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.017Z",
  "value": "id=3459  sec_id=3739806 flags=0x0000 ifindex=12  mac=E2:AD:9E:BB:22:5C nodemac=FA:C7:9C:B1:8F:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.017Z",
  "value": "id=610   sec_id=3739806 flags=0x0000 ifindex=14  mac=EE:79:21:46:38:E3 nodemac=32:DA:30:BA:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.048Z",
  "value": "id=589   sec_id=3777465 flags=0x0000 ifindex=16  mac=9A:78:82:03:E8:A9 nodemac=52:CF:7A:13:A6:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.017Z",
  "value": "id=1070  sec_id=4     flags=0x0000 ifindex=10  mac=B6:E5:D5:F5:EE:0A nodemac=B6:37:85:EE:7E:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.017Z",
  "value": "id=589   sec_id=3777465 flags=0x0000 ifindex=16  mac=9A:78:82:03:E8:A9 nodemac=52:CF:7A:13:A6:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.018Z",
  "value": "id=610   sec_id=3739806 flags=0x0000 ifindex=14  mac=EE:79:21:46:38:E3 nodemac=32:DA:30:BA:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.018Z",
  "value": "id=3459  sec_id=3739806 flags=0x0000 ifindex=12  mac=E2:AD:9E:BB:22:5C nodemac=FA:C7:9C:B1:8F:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.374Z",
  "value": "id=3053  sec_id=3777465 flags=0x0000 ifindex=18  mac=92:FF:45:99:F4:EF nodemac=6A:C4:9F:C5:D8:69"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.56.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.772Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:27.314Z",
  "value": "id=3053  sec_id=3777465 flags=0x0000 ifindex=18  mac=92:FF:45:99:F4:EF nodemac=6A:C4:9F:C5:D8:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:27.319Z",
  "value": "id=1070  sec_id=4     flags=0x0000 ifindex=10  mac=B6:E5:D5:F5:EE:0A nodemac=B6:37:85:EE:7E:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:27.320Z",
  "value": "id=3459  sec_id=3739806 flags=0x0000 ifindex=12  mac=E2:AD:9E:BB:22:5C nodemac=FA:C7:9C:B1:8F:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:27.320Z",
  "value": "id=610   sec_id=3739806 flags=0x0000 ifindex=14  mac=EE:79:21:46:38:E3 nodemac=32:DA:30:BA:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:28.314Z",
  "value": "id=610   sec_id=3739806 flags=0x0000 ifindex=14  mac=EE:79:21:46:38:E3 nodemac=32:DA:30:BA:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:28.314Z",
  "value": "id=1070  sec_id=4     flags=0x0000 ifindex=10  mac=B6:E5:D5:F5:EE:0A nodemac=B6:37:85:EE:7E:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:28.314Z",
  "value": "id=3053  sec_id=3777465 flags=0x0000 ifindex=18  mac=92:FF:45:99:F4:EF nodemac=6A:C4:9F:C5:D8:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:28.315Z",
  "value": "id=3459  sec_id=3739806 flags=0x0000 ifindex=12  mac=E2:AD:9E:BB:22:5C nodemac=FA:C7:9C:B1:8F:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:29.315Z",
  "value": "id=610   sec_id=3739806 flags=0x0000 ifindex=14  mac=EE:79:21:46:38:E3 nodemac=32:DA:30:BA:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:29.315Z",
  "value": "id=1070  sec_id=4     flags=0x0000 ifindex=10  mac=B6:E5:D5:F5:EE:0A nodemac=B6:37:85:EE:7E:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:29.315Z",
  "value": "id=3053  sec_id=3777465 flags=0x0000 ifindex=18  mac=92:FF:45:99:F4:EF nodemac=6A:C4:9F:C5:D8:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:29.315Z",
  "value": "id=3459  sec_id=3739806 flags=0x0000 ifindex=12  mac=E2:AD:9E:BB:22:5C nodemac=FA:C7:9C:B1:8F:F3"
}

