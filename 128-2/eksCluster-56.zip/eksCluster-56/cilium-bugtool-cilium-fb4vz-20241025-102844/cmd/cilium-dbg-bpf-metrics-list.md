REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     204955    83137012   1132   bpf_host.c
Interface                 INGRESS     8820      687686     677    bpf_overlay.c
Success                   EGRESS      3689      280358     1694   bpf_host.c
Success                   EGRESS      8149      639363     53     encap.h
Success                   EGRESS      85284     11717169   1308   bpf_lxc.c
Success                   INGRESS     100345    12019996   235    trace.h
Success                   INGRESS     94692     11578160   86     l3.h
Unsupported L3 protocol   EGRESS      38        2852       1492   bpf_lxc.c
