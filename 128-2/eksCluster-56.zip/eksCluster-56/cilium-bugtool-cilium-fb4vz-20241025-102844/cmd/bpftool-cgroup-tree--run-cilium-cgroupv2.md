CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod655d28e6_51e6_403c_b726_84b74d65649d.slice/cri-containerd-3741c4425cef8bf8ecd475672a5ca5c31e2da3f54dbdd20513fe89477b0af368.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod655d28e6_51e6_403c_b726_84b74d65649d.slice/cri-containerd-7e44be676ddbe11a7b8228f21c0e401cd361724e1100190e055176582b39647d.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27e8d211_c4c2_4ca5_99e4_1c34349e37ae.slice/cri-containerd-2af7ed42cfee02e10453cd1a160dabc3369e96968c46e5332a121c1f9464e6f3.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27e8d211_c4c2_4ca5_99e4_1c34349e37ae.slice/cri-containerd-c16877c7390e13e53c5b8a26a0552ecb2fcb8bfcdb57bbf271d220cec9aae0c4.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a37e4a1_1001_46cc_a02b_2052b648425e.slice/cri-containerd-321664c45140f884f8c6a9b14b6de57dbcf1da165b30eac59fa5c046a72d6608.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a37e4a1_1001_46cc_a02b_2052b648425e.slice/cri-containerd-0c3a5cdc8066dc07daff892a008f74b8b01c66193a49ffec15c214195d709bd9.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda89bb8cc_8bf3_45d9_8370_a03ca5009fdc.slice/cri-containerd-f8f7e5231103223672b710002aec5be21c3bbe4c1d98152a221c897827507da0.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda89bb8cc_8bf3_45d9_8370_a03ca5009fdc.slice/cri-containerd-c949efcf29d92167d912cd4c41687ecd8a9cbd9c3fcea83270d0d51b2f01ae19.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03bc312a_1ab8_4db1_82e8_a58ccbb2c9fb.slice/cri-containerd-bee1dc9044500805041ffa075624c73bda417669261b274c656b02ab3b304e6b.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03bc312a_1ab8_4db1_82e8_a58ccbb2c9fb.slice/cri-containerd-ec19260782ae523e2f41215806c0a24d650143f7c795cc70db7cea0823292b88.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod631b2c42_e49e_47da_b1a3_310af1524178.slice/cri-containerd-c3a4a36cc8fb47e4bdbd9bad7e51f6dca3c234b6db6bce20d87daf686feefbb1.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod631b2c42_e49e_47da_b1a3_310af1524178.slice/cri-containerd-72602a8ae4bc6d46e6a1e00456963a7d333cb86a89cf6ea2fd8cb9b44d2f3dc8.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod631b2c42_e49e_47da_b1a3_310af1524178.slice/cri-containerd-3057028797627c21be2bd8f2a83289ec422cffa8e52e538f16cb97d65f229ff7.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod631b2c42_e49e_47da_b1a3_310af1524178.slice/cri-containerd-4d5f44ce8d6b956586053ac6033d74c9725deacbf68780e95976e8a054bf2bd3.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9e9e07f_360d_4693_90ad_ee7b2dbe981d.slice/cri-containerd-725351b97bf25d0dccfc8d7a9bf0a3a59527552b55e9987bd4d72ffa918149c6.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9e9e07f_360d_4693_90ad_ee7b2dbe981d.slice/cri-containerd-6b32462e04a16080400915f52d92ed6e0a1d932420cf098539f1ccbce8adbc78.scope
    94       cgroup_device   multi                                          
