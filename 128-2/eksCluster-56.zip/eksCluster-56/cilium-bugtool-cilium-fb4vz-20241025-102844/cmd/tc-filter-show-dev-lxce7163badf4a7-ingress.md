filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce7163badf4a7 direct-action not_in_hw id 539 tag fd584c04eae278c7 jited 
