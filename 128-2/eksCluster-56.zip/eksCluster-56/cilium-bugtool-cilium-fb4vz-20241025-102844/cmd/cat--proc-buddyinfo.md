Node 0, zone      DMA    216     57     24     15      2      5      6      3      2      2    172 
Node 0, zone   Normal    306     80      3      1      2      2      1      3      2      4      7 
