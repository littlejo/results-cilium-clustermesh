USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         622  0.0  0.3 1240432 15648 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         657  0.0  0.0   6408  1648 ?        R    10:28   0:00  \_ ps auxfw
root         658  0.0  0.0    216     4 ?        R    10:28   0:00  \_ [hostname]
root           1  2.7  6.9 1472560 271588 ?      Ssl  10:16   0:19 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1228848 6732 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
