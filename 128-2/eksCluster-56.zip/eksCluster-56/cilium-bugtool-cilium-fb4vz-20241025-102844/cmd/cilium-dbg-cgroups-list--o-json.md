[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod631b2c42_e49e_47da_b1a3_310af1524178.slice/cri-containerd-c3a4a36cc8fb47e4bdbd9bad7e51f6dca3c234b6db6bce20d87daf686feefbb1.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod631b2c42_e49e_47da_b1a3_310af1524178.slice/cri-containerd-3057028797627c21be2bd8f2a83289ec422cffa8e52e538f16cb97d65f229ff7.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod631b2c42_e49e_47da_b1a3_310af1524178.slice/cri-containerd-72602a8ae4bc6d46e6a1e00456963a7d333cb86a89cf6ea2fd8cb9b44d2f3dc8.scope"
      }
    ],
    "ips": [
      "10.56.0.249"
    ],
    "name": "clustermesh-apiserver-66b5d758c7-8d5rx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27e8d211_c4c2_4ca5_99e4_1c34349e37ae.slice/cri-containerd-2af7ed42cfee02e10453cd1a160dabc3369e96968c46e5332a121c1f9464e6f3.scope"
      }
    ],
    "ips": [
      "10.56.0.41"
    ],
    "name": "coredns-cc6ccd49c-sxhn9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda89bb8cc_8bf3_45d9_8370_a03ca5009fdc.slice/cri-containerd-c949efcf29d92167d912cd4c41687ecd8a9cbd9c3fcea83270d0d51b2f01ae19.scope"
      }
    ],
    "ips": [
      "10.56.0.160"
    ],
    "name": "coredns-cc6ccd49c-bwnpz",
    "namespace": "kube-system"
  }
]

