1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:87:6e:83:28:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.158.50/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2802sec preferred_lft 2802sec
    inet6 fe80::487:6eff:fe83:2875/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d9:5e:63:24:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.170.29/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d9:5eff:fe63:24d9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:f3:fc:1e:ed:51 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::88f3:fcff:fe1e:ed51/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:5f:6d:b2:12:b8 brd ff:ff:ff:ff:ff:ff
    inet 10.56.0.43/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e45f:6dff:feb2:12b8/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b2:56:34:0f:b8:be brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b056:34ff:fe0f:b8be/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:37:85:ee:7e:5b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b437:85ff:feee:7e5b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcbbcc3fdd14cf@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:c7:9c:b1:8f:f3 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f8c7:9cff:feb1:8ff3/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce7163badf4a7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:da:30:ba:88:db brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::30da:30ff:feba:88db/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc554b20cdbf93@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:c4:9f:c5:d8:69 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::68c4:9fff:fec5:d869/64 scope link 
       valid_lft forever preferred_lft forever
