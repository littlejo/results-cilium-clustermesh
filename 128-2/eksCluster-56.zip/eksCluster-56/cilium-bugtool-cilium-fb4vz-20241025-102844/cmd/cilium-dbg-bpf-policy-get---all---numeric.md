Endpoint ID: 610
Path: /sys/fs/bpf/tc/globals/cilium_policy_00610

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69863   804       0        
Allow    Egress      0          ANY          NONE         disabled    12817   131       0        


Endpoint ID: 1070
Path: /sys/fs/bpf/tc/globals/cilium_policy_01070

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    442598   5663      0        
Allow    Ingress     1          ANY          NONE         disabled    9982     115       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3053
Path: /sys/fs/bpf/tc/globals/cilium_policy_03053

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3870661   35476     0        
Allow    Ingress     1          ANY          NONE         disabled    2508337   24725     0        
Allow    Egress      0          ANY          NONE         disabled    3630176   34025     0        


Endpoint ID: 3349
Path: /sys/fs/bpf/tc/globals/cilium_policy_03349

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3459
Path: /sys/fs/bpf/tc/globals/cilium_policy_03459

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    70116   810       0        
Allow    Egress      0          ANY          NONE         disabled    13122   135       0        


