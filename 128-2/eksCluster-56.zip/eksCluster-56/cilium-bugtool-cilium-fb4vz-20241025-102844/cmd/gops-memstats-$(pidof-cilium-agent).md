alloc: 116.92MB (122600456 bytes)
total-alloc: 1.27GB (1366149264 bytes)
sys: 206.45MB (216474964 bytes)
lookups: 0
mallocs: 46876895
frees: 45666309
heap-alloc: 116.92MB (122600456 bytes)
heap-sys: 161.23MB (169058304 bytes)
heap-idle: 27.45MB (28786688 bytes)
heap-in-use: 133.77MB (140271616 bytes)
heap-released: 376.00KB (385024 bytes)
heap-objects: 1210586
stack-in-use: 34.75MB (36438016 bytes)
stack-sys: 34.75MB (36438016 bytes)
stack-mspan-inuse: 2.12MB (2226240 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1006.83KB (1030993 bytes)
gc-sys: 5.17MB (5421120 bytes)
next-gc: when heap-alloc >= 146.91MB (154042696 bytes)
last-gc: 2024-10-25 10:28:48.297768562 +0000 UTC
gc-pause-total: 6.661029ms
gc-pause: 115242
gc-pause-end: 1729852128297768562
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003749729077344433
enable-gc: true
debug-gc: false
