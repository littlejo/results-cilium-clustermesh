Total: 545
TCP:   1076 (estab 294, closed 763, orphaned 0, timewait 304)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  313       304       9        
INET	  323       310       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.158.50%ens5:68         0.0.0.0:*    uid:192 ino:15736 sk:261 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24325 sk:262 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15106 sk:263 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:46127      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:25067 sk:264 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24324 sk:26e cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15107 sk:26f cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::487:6eff:fe83:2875]%ens5:546           [::]:*    uid:192 ino:15734 sk:270 cgroup:unreachable:c4e v6only:1 <->                   
