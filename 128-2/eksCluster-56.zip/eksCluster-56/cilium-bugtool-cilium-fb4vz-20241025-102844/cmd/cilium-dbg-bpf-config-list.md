KEY             VALUE
AgentLiveness   839396575732
UTimeOffset     3378615855468750
