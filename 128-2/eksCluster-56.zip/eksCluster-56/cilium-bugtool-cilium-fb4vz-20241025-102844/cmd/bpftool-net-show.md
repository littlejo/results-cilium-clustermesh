xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 496
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 487
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 535
lxcbbcc3fdd14cf(12) clsact/ingress cil_from_container-lxcbbcc3fdd14cf id 532
lxce7163badf4a7(14) clsact/ingress cil_from_container-lxce7163badf4a7 id 539
lxc554b20cdbf93(18) clsact/ingress cil_from_container-lxc554b20cdbf93 id 612

flow_dissector:

netfilter:

