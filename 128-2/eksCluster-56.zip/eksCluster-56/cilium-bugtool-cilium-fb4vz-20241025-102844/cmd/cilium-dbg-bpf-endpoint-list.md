IP ADDRESS        LOCAL ENDPOINT INFO
10.56.0.43:0      (localhost)                                                                                        
10.56.0.249:0     id=3053  sec_id=3777465 flags=0x0000 ifindex=18  mac=92:FF:45:99:F4:EF nodemac=6A:C4:9F:C5:D8:69   
10.56.0.160:0     id=610   sec_id=3739806 flags=0x0000 ifindex=14  mac=EE:79:21:46:38:E3 nodemac=32:DA:30:BA:88:DB   
10.56.0.186:0     id=1070  sec_id=4     flags=0x0000 ifindex=10  mac=B6:E5:D5:F5:EE:0A nodemac=B6:37:85:EE:7E:5B     
172.31.170.29:0   (localhost)                                                                                        
10.56.0.41:0      id=3459  sec_id=3739806 flags=0x0000 ifindex=12  mac=E2:AD:9E:BB:22:5C nodemac=FA:C7:9C:B1:8F:F3   
172.31.158.50:0   (localhost)                                                                                        
