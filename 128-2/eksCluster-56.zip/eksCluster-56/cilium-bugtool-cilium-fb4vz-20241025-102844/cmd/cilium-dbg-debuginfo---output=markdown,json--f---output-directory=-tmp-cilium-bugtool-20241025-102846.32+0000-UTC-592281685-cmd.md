markdown output at /tmp/cilium-bugtool-20241025-102846.32+0000-UTC-592281685/cmd/cilium-debuginfo-20241025-102917.21+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102846.32+0000-UTC-592281685/cmd/cilium-debuginfo-20241025-102917.21+0000-UTC.json
