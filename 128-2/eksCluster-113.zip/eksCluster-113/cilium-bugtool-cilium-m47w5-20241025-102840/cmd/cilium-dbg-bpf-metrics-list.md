REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     206294    83382234   1132   bpf_host.c
Interface                 INGRESS     8810      687252     677    bpf_overlay.c
Success                   EGRESS      3964      299540     1694   bpf_host.c
Success                   EGRESS      7820      1236146    86     l3.h
Success                   EGRESS      8350      652296     53     encap.h
Success                   EGRESS      85843     11899697   1308   bpf_lxc.c
Success                   INGRESS     110132    13456504   235    trace.h
Success                   INGRESS     96817     11788740   86     l3.h
Unsupported L3 protocol   EGRESS      40        3012       1492   bpf_lxc.c
