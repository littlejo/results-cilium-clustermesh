CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9bef2a80_a391_4ed4_a188_d5ba8a2b4516.slice/cri-containerd-a1ef23531f6dbb0263b93ac30c0cbb94a36313968b0d1d5c22673cad3f176d3a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9bef2a80_a391_4ed4_a188_d5ba8a2b4516.slice/cri-containerd-008821ac86b5523e754cd9e13753b9bdd7551da222a9c1858ab60e566bf12e2d.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod373ff1be_cebf_48d3_821a_b11eb1e489e6.slice/cri-containerd-dc3a0429aaafdc6103c26e0ac92bcd863ac40961e2e347e28d28653ab61c6163.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod373ff1be_cebf_48d3_821a_b11eb1e489e6.slice/cri-containerd-6b3a784db5f060d34f22cf7b0b2f056e113ac1f00f124a379da72f2d79143e2f.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8567edc6_b115_4557_a781_5a13793ca36d.slice/cri-containerd-935297702a7db538aea9f893da7ff5b9bf9b26b62f079f9b30d223f88fc1201b.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8567edc6_b115_4557_a781_5a13793ca36d.slice/cri-containerd-66ad0af36a2097c07db4accfc593d2cbf782315773bf397df23d0624d079971f.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4cd635b7_c504_4b54_b055_b61c169783e0.slice/cri-containerd-14a5071d2d95604f64316a5d892e390087f366f51bfced2d3d5dc71715a87d0f.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4cd635b7_c504_4b54_b055_b61c169783e0.slice/cri-containerd-0c4008b7dbce97ff37d80807c516fbaa41e3185938d489bf2f30b68b356c34bc.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod552fc3bc_5168_4738_86c2_f4565c5b3e1f.slice/cri-containerd-5484fb9a72dc8ea25609d0116b0ad9bb2c4a6a0e0a6eba4c57b7d033c8122af8.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod552fc3bc_5168_4738_86c2_f4565c5b3e1f.slice/cri-containerd-a77ec8ac50aec02d5aa4ed9ab6bf023ab4e2e431c3246aba853cda1a0166a9ba.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb91fe8a_d5e3_488c_964c_7d45fa23c4d6.slice/cri-containerd-92a75be52e3a8bfff35bcb68108df500f0f134dc8ff31d0d596a1ba60aaba02f.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb91fe8a_d5e3_488c_964c_7d45fa23c4d6.slice/cri-containerd-eaaf7913828cc85897202dc835b0740ab3cdeef3f292904be0a02f5fc10d823c.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod647cb50f_c963_47d4_a948_b6390680b49c.slice/cri-containerd-c4acaf84027ea4791b6e292c3cd7ecfb6fd1b0305421e84946a18c631d824245.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod647cb50f_c963_47d4_a948_b6390680b49c.slice/cri-containerd-77a26606965bed2fb3076d58bb74ef1667f282994add27d2e721bb83b4b3abd2.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod647cb50f_c963_47d4_a948_b6390680b49c.slice/cri-containerd-f09da23bd84761aa05def987291ea07d4d1223a7c0a3566af72cce64f4e1c0fa.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod647cb50f_c963_47d4_a948_b6390680b49c.slice/cri-containerd-700ddb62fe7306acdd08e3aba2627df737bf84beafef9d91f084d53e3e3a0c26.scope
    649      cgroup_device   multi                                          
