xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(5) clsact/ingress cil_from_netdev-ens6 id 511
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 499
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 493
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 545
lxc0844a2ddf125(12) clsact/ingress cil_from_container-lxc0844a2ddf125 id 538
lxc1c265c907a52(14) clsact/ingress cil_from_container-lxc1c265c907a52 id 554
lxc74595ad31c8e(18) clsact/ingress cil_from_container-lxc74595ad31c8e id 624

flow_dissector:

netfilter:

