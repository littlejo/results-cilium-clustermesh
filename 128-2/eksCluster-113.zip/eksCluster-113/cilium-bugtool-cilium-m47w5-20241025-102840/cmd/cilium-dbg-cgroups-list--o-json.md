[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod647cb50f_c963_47d4_a948_b6390680b49c.slice/cri-containerd-700ddb62fe7306acdd08e3aba2627df737bf84beafef9d91f084d53e3e3a0c26.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod647cb50f_c963_47d4_a948_b6390680b49c.slice/cri-containerd-f09da23bd84761aa05def987291ea07d4d1223a7c0a3566af72cce64f4e1c0fa.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod647cb50f_c963_47d4_a948_b6390680b49c.slice/cri-containerd-c4acaf84027ea4791b6e292c3cd7ecfb6fd1b0305421e84946a18c631d824245.scope"
      }
    ],
    "ips": [
      "10.113.0.223"
    ],
    "name": "clustermesh-apiserver-7cdb49698f-mfdkd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8567edc6_b115_4557_a781_5a13793ca36d.slice/cri-containerd-66ad0af36a2097c07db4accfc593d2cbf782315773bf397df23d0624d079971f.scope"
      }
    ],
    "ips": [
      "10.113.0.87"
    ],
    "name": "coredns-cc6ccd49c-pdtlc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod373ff1be_cebf_48d3_821a_b11eb1e489e6.slice/cri-containerd-dc3a0429aaafdc6103c26e0ac92bcd863ac40961e2e347e28d28653ab61c6163.scope"
      }
    ],
    "ips": [
      "10.113.0.28"
    ],
    "name": "coredns-cc6ccd49c-fvfq6",
    "namespace": "kube-system"
  }
]

