key: cd 00 00 00  value: 27 02 00 00
key: df 08 00 00  value: 68 02 00 00
key: b4 0a 00 00  value: 25 02 00 00
key: 26 0b 00 00  value: 12 02 00 00
Found 4 elements
