markdown output at /tmp/cilium-bugtool-20241025-102841.98+0000-UTC-2505176737/cmd/cilium-debuginfo-20241025-102912.624+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.98+0000-UTC-2505176737/cmd/cilium-debuginfo-20241025-102912.624+0000-UTC.json
