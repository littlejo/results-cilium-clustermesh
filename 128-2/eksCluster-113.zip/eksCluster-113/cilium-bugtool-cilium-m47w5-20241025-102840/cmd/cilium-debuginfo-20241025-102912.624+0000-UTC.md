# Cilium debug information

#### Cilium environment keys

```
hubble-export-file-max-backups:5
bpf-ct-timeout-regular-any:1m0s
enable-mke:false
enable-encryption-strict-mode:false
http-request-timeout:3600
bpf-ct-timeout-service-tcp:2h13m20s
bpf-events-drop-enabled:true
cmdref:
kvstore-connectivity-timeout:2m0s
mesh-auth-gc-interval:5m0s
policy-audit-mode:false
monitor-aggregation-interval:5s
enable-l2-neigh-discovery:true
node-port-mode:snat
enable-wireguard-userspace-fallback:false
ipv6-range:auto
node-port-range:
enable-l2-pod-announcements:false
hubble-redact-enabled:false
vtep-endpoint:
tofqdns-proxy-response-max-delay:100ms
dns-max-ips-per-restored-rule:1000
enable-unreachable-routes:false
cluster-pool-ipv4-mask-size:24
bgp-announce-lb-ip:false
enable-service-topology:false
labels:
local-max-addr-scope:252
ipv6-native-routing-cidr:
local-router-ipv4:
enable-hubble:true
enable-monitor:true
bpf-lb-algorithm:random
mesh-auth-enabled:true
hubble-metrics:
enable-masquerade-to-route-source:false
proxy-gid:1337
ipam-multi-pool-pre-allocation:
bpf-lb-affinity-map-max:0
max-connected-clusters:255
agent-liveness-update-interval:1s
proxy-xff-num-trusted-hops-egress:0
enable-cilium-api-server-access:
tunnel-port:0
enable-hubble-recorder-api:true
hubble-listen-address::4244
enable-vtep:false
annotate-k8s-node:false
enable-health-check-nodeport:true
ipv6-cluster-alloc-cidr:f00d::/64
enable-ipsec-encrypted-overlay:false
encrypt-node:false
pprof-address:localhost
fixed-identity-mapping:
policy-accounting:true
unmanaged-pod-watcher-interval:15
k8s-api-server:
dns-policy-unload-on-shutdown:false
k8s-require-ipv6-pod-cidr:false
enable-pmtu-discovery:false
vtep-mac:
install-no-conntrack-iptables-rules:false
container-ip-local-reserved-ports:auto
enable-ipv6-big-tcp:false
bpf-filter-priority:1
k8s-namespace:kube-system
disable-iptables-feeder-rules:
routing-mode:tunnel
enable-l2-announcements:false
route-metric:0
egress-gateway-policy-map-max:16384
bpf-lb-maglev-map-max:0
enable-ipv4-fragment-tracking:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
debug:false
install-iptables-rules:true
hubble-redact-http-userinfo:true
force-device-detection:false
kvstore-periodic-sync:5m0s
api-rate-limit:
k8s-heartbeat-timeout:30s
bpf-lb-maglev-table-size:16381
node-port-bind-protection:true
enable-k8s-terminating-endpoint:true
auto-create-cilium-node-resource:true
cni-log-file:/var/run/cilium/cilium-cni.log
enable-host-port:false
cni-chaining-mode:none
auto-direct-node-routes:false
external-envoy-proxy:true
restore:true
config:
crd-wait-timeout:5m0s
cni-external-routing:false
enable-ipv4-masquerade:true
ipv4-service-loopback-address:169.254.42.1
enable-health-checking:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
dnsproxy-socket-linger-timeout:10
exclude-local-address:
enable-ip-masq-agent:false
proxy-max-connection-duration-seconds:0
use-full-tls-context:false
bpf-lb-sock-hostns-only:false
encryption-strict-mode-allow-remote-node-identities:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
bpf-lb-dsr-l4-xlate:frontend
mtu:0
dnsproxy-concurrency-limit:0
bpf-lb-acceleration:disabled
hubble-recorder-sink-queue-size:1024
k8s-service-cache-size:128
enable-external-ips:false
devices:
http-normalize-path:true
bpf-lb-map-max:65536
bpf-sock-rev-map-max:262144
bpf-events-trace-enabled:true
join-cluster:false
enable-bbr:false
endpoint-queue-size:25
enable-tcx:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
max-controller-interval:0
hubble-export-denylist:
kube-proxy-replacement:false
operator-api-serve-addr:127.0.0.1:9234
tofqdns-max-deferred-connection-deletes:10000
dnsproxy-lock-count:131
bpf-lb-rss-ipv6-src-cidr:
encrypt-interface:
enable-ipv6:false
bpf-policy-map-max:16384
identity-gc-interval:15m0s
l2-announcements-retry-period:2s
lib-dir:/var/lib/cilium
bpf-lb-rev-nat-map-max:0
proxy-portrange-min:10000
bpf-lb-sock:false
iptables-random-fully:false
vlan-bpf-bypass:
enable-policy:default
envoy-secrets-namespace:
http-retry-count:3
hubble-redact-http-urlquery:false
enable-k8s-api-discovery:false
ingress-secrets-namespace:
ipv6-service-range:auto
enable-bgp-control-plane:false
bpf-map-dynamic-size-ratio:0.0025
clustermesh-ip-identities-sync-timeout:1m0s
enable-runtime-device-detection:true
allow-localhost:auto
ipv4-native-routing-cidr:
bpf-lb-mode:snat
enable-identity-mark:true
config-dir:/tmp/cilium/config-map
prometheus-serve-addr:
metrics:
enable-gateway-api:false
hubble-event-queue-size:0
clustermesh-enable-mcs-api:false
custom-cni-conf:false
enable-ingress-controller:false
cluster-health-port:4240
ipam-cilium-node-update-rate:15s
bpf-events-policy-verdict-enabled:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
policy-cidr-match-mode:
hubble-monitor-events:
enable-icmp-rules:true
kvstore-opt:
enable-cilium-health-api-server-access:
http-retry-timeout:0
bpf-lb-dsr-dispatch:opt
endpoint-bpf-prog-watchdog-interval:30s
l2-announcements-lease-duration:15s
enable-srv6:false
tofqdns-endpoint-max-ip-per-hostname:50
hubble-export-allowlist:
mesh-auth-mutual-connect-timeout:5s
bpf-lb-service-map-max:0
enable-k8s:true
enable-ipv6-masquerade:true
max-internal-timer-delay:0s
mesh-auth-queue-size:1024
hubble-flowlogs-config-path:
remove-cilium-node-taints:true
bpf-lb-service-backend-map-max:0
cflags:
proxy-xff-num-trusted-hops-ingress:0
disable-envoy-version-check:false
hubble-export-file-max-size-mb:10
log-opt:
enable-xdp-prefilter:false
set-cilium-is-up-condition:true
nodeport-addresses:
bpf-lb-sock-terminate-pod-connections:false
version:false
bpf-root:/sys/fs/bpf
bpf-policy-map-full-reconciliation-interval:15m0s
ipv6-node:auto
enable-bpf-tproxy:false
enable-ipsec-xfrm-state-caching:true
bpf-ct-timeout-regular-tcp:2h13m20s
keep-config:false
cni-chaining-target:
http-idle-timeout:0
enable-svc-source-range-check:true
enable-k8s-endpoint-slice:true
tofqdns-min-ttl:0
kvstore-max-consecutive-quorum-errors:2
k8s-service-proxy-name:
hubble-prefer-ipv6:false
ipsec-key-file:
enable-endpoint-routes:false
bpf-map-event-buffers:
nodes-gc-interval:5m0s
service-no-backend-response:reject
ipv6-mcast-device:
proxy-max-requests-per-connection:0
enable-tracing:false
trace-payloadlen:128
hubble-export-file-compress:false
iptables-lock-timeout:5s
enable-xt-socket-fallback:true
disable-external-ip-mitigation:false
bpf-ct-global-any-max:262144
egress-multi-home-ip-rule-compat:false
datapath-mode:veth
bpf-ct-global-tcp-max:524288
clustermesh-enable-endpoint-sync:false
agent-labels:
cilium-endpoint-gc-interval:5m0s
bypass-ip-availability-upon-restore:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
set-cilium-node-taints:true
enable-ipv4-big-tcp:false
enable-auto-protect-node-port-range:true
k8s-kubeconfig-path:
dnsproxy-insecure-skip-transparent-mode-check:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
mesh-auth-rotated-identities-queue-size:1024
bgp-config-path:/var/lib/cilium/bgp/config.yaml
monitor-aggregation-flags:all
l2-pod-announcements-interface:
wireguard-persistent-keepalive:0s
local-router-ipv6:
proxy-idle-timeout-seconds:60
enable-k8s-networkpolicy:true
static-cnp-path:
arping-refresh-period:30s
enable-high-scale-ipcache:false
debug-verbose:
envoy-base-id:0
controller-group-metrics:
hubble-export-file-path:
bpf-fragments-map-max:8192
gateway-api-secrets-namespace:
policy-queue-size:100
endpoint-gc-interval:5m0s
proxy-admin-port:0
operator-prometheus-serve-addr::9963
synchronize-k8s-nodes:true
conntrack-gc-interval:0s
enable-active-connection-tracking:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
hubble-drop-events-interval:2m0s
tofqdns-proxy-port:0
enable-well-known-identities:false
dnsproxy-enable-transparent-mode:true
enable-ipip-termination:false
node-port-acceleration:disabled
allow-icmp-frag-needed:true
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-lb-rss-ipv4-src-cidr:
enable-recorder:false
egress-masquerade-interfaces:ens+
dnsproxy-lock-timeout:500ms
monitor-queue-size:0
bpf-auth-map-max:524288
hubble-drop-events:false
bpf-neigh-global-max:524288
enable-session-affinity:false
multicast-enabled:false
mesh-auth-spire-admin-socket:
enable-envoy-config:false
l2-announcements-renew-deadline:5s
enable-host-legacy-routing:false
log-system-load:false
ipsec-key-rotation-duration:5m0s
cni-exclusive:true
log-driver:
procfs:/host/proc
k8s-client-connection-timeout:30s
k8s-sync-timeout:3m0s
vtep-mask:
proxy-portrange-max:20000
policy-trigger-interval:1s
bpf-ct-timeout-regular-tcp-syn:1m0s
ipv4-pod-subnets:
envoy-keep-cap-netbindservice:false
state-dir:/var/run/cilium
preallocate-bpf-maps:false
tofqdns-pre-cache:
hubble-socket-path:/var/run/cilium/hubble.sock
envoy-log:
exclude-node-label-patterns:
envoy-config-retry-interval:15s
prepend-iptables-chains:true
ipv4-range:auto
enable-local-redirect-policy:false
enable-endpoint-health-checking:true
identity-change-grace-period:5s
enable-bpf-clock-probe:false
mesh-auth-signal-backoff-duration:1s
enable-cilium-endpoint-slice:false
enable-host-firewall:false
k8s-client-burst:20
certificates-directory:/var/run/cilium/certs
ipv4-node:auto
kvstore:
enable-stale-cilium-endpoint-cleanup:true
enable-metrics:true
dnsproxy-concurrency-processing-grace-period:0s
read-cni-conf:
direct-routing-skip-unreachable:false
monitor-aggregation:medium
bpf-nat-global-max:524288
cluster-pool-ipv4-cidr:10.113.0.0/16
vtep-cidr:
hubble-redact-http-headers-deny:
hubble-skip-unknown-cgroup-ids:true
enable-ipv4:true
enable-l7-proxy:true
cluster-name:cmesh114
tofqdns-dns-reject-response-code:refused
direct-routing-device:
hubble-drop-events-reasons:auth_required,policy_denied
label-prefix-file:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
tunnel-protocol:vxlan
node-port-algorithm:random
enable-bandwidth-manager:false
http-max-grpc-timeout:0
encryption-strict-mode-cidr:
enable-ipsec-key-watcher:true
bpf-ct-timeout-service-tcp-grace:1m0s
identity-allocation-mode:crd
identity-restore-grace-period:30s
identity-heartbeat-timeout:30m0s
conntrack-gc-max-interval:0s
disable-endpoint-crd:false
hubble-disable-tls:false
proxy-prometheus-port:0
tofqdns-enable-dns-compression:true
pprof-port:6060
bgp-announce-pod-cidr:false
hubble-metrics-server:
mesh-auth-mutual-listener-port:0
enable-ipv6-ndp:false
enable-route-mtu-for-cni-chaining:false
k8s-client-connection-keep-alive:30s
config-sources:config-map:kube-system/cilium-config
mke-cgroup-mount:
pprof:false
hubble-export-fieldmask:
enable-custom-calls:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
bpf-ct-timeout-service-any:1m0s
bpf-ct-timeout-regular-tcp-fin:10s
bpf-lb-source-range-map-max:0
cgroup-root:/run/cilium/cgroupv2
k8s-client-qps:10
enable-ipsec:false
hubble-redact-kafka-apikey:false
enable-ipv4-egress-gateway:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
ipv4-service-range:auto
proxy-connect-timeout:2
ipv6-pod-subnets:
trace-sock:true
agent-health-port:9879
enable-nat46x64-gateway:false
hubble-event-buffer-capacity:4095
tofqdns-idle-connection-grace-period:0s
node-labels:
hubble-redact-http-headers-allow:
cluster-id:114
bpf-lb-external-clusterip:false
enable-wireguard:false
enable-bpf-masquerade:false
fqdn-regex-compile-lru-size:1024
enable-health-check-loadbalancer-ip:false
clustermesh-sync-timeout:1m0s
nat-map-stats-interval:30s
egress-gateway-reconciliation-trigger-interval:1s
allocator-list-timeout:3m0s
enable-sctp:false
gops-port:9890
enable-node-selector-labels:false
ipam-default-ip-pool:default
enable-local-node-route:true
socket-path:/var/run/cilium/cilium.sock
use-cilium-internal-ip-for-ipsec:false
bpf-node-map-max:16384
kvstore-lease-ttl:15m0s
k8s-require-ipv4-pod-cidr:false
kube-proxy-replacement-healthz-bind-address:
derive-masq-ip-addr-from-device:
srv6-encap-mode:reduced
envoy-config-timeout:2m0s
nat-map-stats-entries:32
ipam:cluster-pool
enable-node-port:false
```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.113.0.0/24, 
Allocated addresses:
  10.113.0.127 (router)
  10.113.0.198 (health)
  10.113.0.223 (kube-system/clustermesh-apiserver-7cdb49698f-mfdkd)
  10.113.0.28 (kube-system/coredns-cc6ccd49c-fvfq6)
  10.113.0.87 (kube-system/coredns-cc6ccd49c-pdtlc)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8b84fba289242927
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    48s ago        never        0       no error   
  ct-map-pressure                                                     19s ago        never        0       no error   
  daemon-validate-config                                              37s ago        never        0       no error   
  dns-garbage-collector-job                                           52s ago        never        0       no error   
  endpoint-205-regeneration-recovery                                  never          never        0       no error   
  endpoint-2188-regeneration-recovery                                 never          never        0       no error   
  endpoint-2271-regeneration-recovery                                 never          never        0       no error   
  endpoint-2740-regeneration-recovery                                 never          never        0       no error   
  endpoint-2854-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                         2m52s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                19s ago        never        0       no error   
  ipcache-inject-labels                                               50s ago        never        0       no error   
  k8s-heartbeat                                                       22s ago        never        0       no error   
  link-cache                                                          4s ago         never        0       no error   
  local-identity-checkpoint                                           12m39s ago     never        0       no error   
  node-neighbor-link-updater                                          9s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m22s ago      never        0       no error   
  remote-etcd-cmesh10                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh100                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh101                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh102                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh103                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh104                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh105                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh106                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh107                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh108                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh109                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh11                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh110                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh111                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh112                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh113                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh115                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh116                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh117                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh118                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh119                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh12                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh120                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh121                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh122                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh123                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh124                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh125                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh126                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh127                                                5m22s ago      never        0       no error   
  remote-etcd-cmesh128                                                5m23s ago      never        0       no error   
  remote-etcd-cmesh13                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh14                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh15                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh16                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh17                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh18                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh19                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh2                                                  5m23s ago      never        0       no error   
  remote-etcd-cmesh20                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh21                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh22                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh23                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh24                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh25                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh26                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh27                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh28                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh29                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh3                                                  5m22s ago      never        0       no error   
  remote-etcd-cmesh30                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh31                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh32                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh33                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh34                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh35                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh36                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh37                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh38                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh39                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh4                                                  5m22s ago      never        0       no error   
  remote-etcd-cmesh40                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh41                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh42                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh43                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh44                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh45                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh46                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh47                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh48                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh49                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh5                                                  5m23s ago      never        0       no error   
  remote-etcd-cmesh50                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh51                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh52                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh53                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh54                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh55                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh56                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh57                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh58                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh59                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh6                                                  5m23s ago      never        0       no error   
  remote-etcd-cmesh60                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh61                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh62                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh63                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh64                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh65                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh66                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh67                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh68                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh69                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh7                                                  5m22s ago      never        0       no error   
  remote-etcd-cmesh70                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh71                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh72                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh73                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh74                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh75                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh76                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh77                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh78                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh79                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh8                                                  5m23s ago      never        0       no error   
  remote-etcd-cmesh80                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh81                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh82                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh83                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh84                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh85                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh86                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh87                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh88                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh89                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh9                                                  5m22s ago      never        0       no error   
  remote-etcd-cmesh90                                                 5m23s ago      never        0       no error   
  remote-etcd-cmesh91                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh92                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh93                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh94                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh95                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh96                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh97                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh98                                                 5m22s ago      never        0       no error   
  remote-etcd-cmesh99                                                 5m23s ago      never        0       no error   
  resolve-identity-205                                                2m48s ago      never        0       no error   
  resolve-identity-2188                                               2m49s ago      never        0       no error   
  resolve-identity-2271                                               56s ago        never        0       no error   
  resolve-identity-2740                                               2m47s ago      never        0       no error   
  resolve-identity-2854                                               2m47s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7cdb49698f-mfdkd   5m56s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-fvfq6                  12m47s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-pdtlc                  12m47s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      12m49s ago     never        0       no error   
  sync-policymap-205                                                  12m45s ago     never        0       no error   
  sync-policymap-2188                                                 12m48s ago     never        0       no error   
  sync-policymap-2271                                                 5m56s ago      never        0       no error   
  sync-policymap-2740                                                 12m45s ago     never        0       no error   
  sync-policymap-2854                                                 12m45s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (2271)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2740)                                   7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2854)                                   7s ago         never        0       no error   
  sync-utime                                                          50s ago        never        0       no error   
  write-cni-file                                                      12m52s ago     never        0       no error   
Proxy Status:            OK, ip 10.113.0.127, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 7471104, max 7536639
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 84.02   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.113.0.28": (string) (len=35) "kube-system/coredns-cc6ccd49c-fvfq6",
  (string) (len=11) "10.113.0.87": (string) (len=35) "kube-system/coredns-cc6ccd49c-pdtlc",
  (string) (len=12) "10.113.0.223": (string) (len=50) "kube-system/clustermesh-apiserver-7cdb49698f-mfdkd",
  (string) (len=12) "10.113.0.127": (string) (len=6) "router",
  (string) (len=12) "10.113.0.198": (string) (len=6) "health"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.195.97": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40016d2160)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001bab7a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001bab7a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002372bb0)(frontends:[10.100.96.90]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002372d10)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x400377c6e0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x400377c790)(frontends:[10.100.254.105]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002372b00)(frontends:[10.100.0.1]/ports=[https]/selector=map[])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40017b7648)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-fz6pj": (*k8s.Endpoints)(0x40026b1ba0)(172.31.195.97:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40017b7650)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-xqmn7": (*k8s.Endpoints)(0x4003656270)(10.113.0.28:53/TCP[eu-west-3b],10.113.0.28:53/UDP[eu-west-3b],10.113.0.28:9153/TCP[eu-west-3b],10.113.0.87:53/TCP[eu-west-3b],10.113.0.87:53/UDP[eu-west-3b],10.113.0.87:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40013ee7d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-jr2xj": (*k8s.Endpoints)(0x40033e7040)(10.113.0.223:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40017b7640)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x400186fad0)(172.31.184.7:443/TCP,172.31.243.127:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400044c380)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40023934f0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4004fc6a08
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002398c60,
  gcExited: (chan struct {}) 0x4002398cc0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4000fead80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40008b06c8)({
      MetricVec: (*prometheus.MetricVec)(0x4002494d50)({
       metricMap: (*prometheus.metricMap)(0x4002494d80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000dcfe60)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4000feae00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40008b06d0)({
      MetricVec: (*prometheus.MetricVec)(0x4002494de0)({
       metricMap: (*prometheus.metricMap)(0x4002494e10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000dcfec0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4000feae80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40008b06d8)({
      MetricVec: (*prometheus.MetricVec)(0x4002494e70)({
       metricMap: (*prometheus.metricMap)(0x4002494ea0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000dcff20)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4000feaf00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40008b06e0)({
      MetricVec: (*prometheus.MetricVec)(0x4002494f00)({
       metricMap: (*prometheus.metricMap)(0x4002494f30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024a2000)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4000feaf80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40008b06e8)({
      MetricVec: (*prometheus.MetricVec)(0x4002494f90)({
       metricMap: (*prometheus.metricMap)(0x4002494fc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024a2060)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4000feb000)({
     GaugeVec: (*prometheus.GaugeVec)(0x40008b06f0)({
      MetricVec: (*prometheus.MetricVec)(0x4002495020)({
       metricMap: (*prometheus.metricMap)(0x4002495050)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024a20c0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4000feb080)({
     GaugeVec: (*prometheus.GaugeVec)(0x40008b06f8)({
      MetricVec: (*prometheus.MetricVec)(0x40024950b0)({
       metricMap: (*prometheus.metricMap)(0x40024950e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024a2120)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4000feb100)({
     GaugeVec: (*prometheus.GaugeVec)(0x40008b0700)({
      MetricVec: (*prometheus.MetricVec)(0x4002495140)({
       metricMap: (*prometheus.metricMap)(0x4002495170)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024a2180)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4000feb180)({
     ObserverVec: (*prometheus.HistogramVec)(0x40008b0708)({
      MetricVec: (*prometheus.MetricVec)(0x40024951d0)({
       metricMap: (*prometheus.metricMap)(0x4002495200)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024a21e0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400044c380)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001b12850)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001b9d740)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 271ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
205        Disabled           Disabled          4          reserved:health                                                                     10.113.0.198   ready   
2188       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                 
                                                           reserved:host                                                                                              
2271       Disabled           Disabled          7489522    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.113.0.223   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh114                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
2740       Disabled           Disabled          7498628    k8s:eks.amazonaws.com/component=coredns                                             10.113.0.87    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh114                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
2854       Disabled           Disabled          7498628    k8s:eks.amazonaws.com/component=coredns                                             10.113.0.28    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh114                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
```

#### BPF Policy Get 205

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    431486   5493      0        
Allow    Ingress     1          ANY          NONE         disabled    10072    116       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 205

```
Invalid argument: unknown type 205
```


#### Endpoint Get 205

```
[
  {
    "id": 205,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-205-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "43da7fab-ae79-401f-b903-b7ad8ac95ee3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-205",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:23.731Z",
            "success-count": 3
          },
          "uuid": "97f3ee01-a0ca-4c38-8f3d-2555ea5da7c8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-205",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:26.874Z",
            "success-count": 1
          },
          "uuid": "43f429cb-3db1-4b9f-901c-23cd4b1c3191"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:51Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.113.0.198",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "e2:5b:db:d7:28:28",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "c2:ea:9c:d1:8c:6a"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 205

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 205

```
Timestamp              Status   State                   Message
2024-10-25T10:23:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:16:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:26Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:16:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:16:25Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:16:23Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:23Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2188

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2188

```
Invalid argument: unknown type 2188
```


#### Endpoint Get 2188

```
[
  {
    "id": 2188,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2188-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3eb825f4-203a-4a01-ab04-c7130bae714f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2188",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:22.668Z",
            "success-count": 3
          },
          "uuid": "18d3a06a-fa88-44a4-a53d-7fa185ad427c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2188",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:23.732Z",
            "success-count": 1
          },
          "uuid": "14a3436c-2e92-47b3-9a1f-72c074f4d21e"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:51Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "06:a3:54:0a:0f:6f",
        "interface-name": "cilium_host",
        "mac": "06:a3:54:0a:0f:6f"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2188

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2188

```
Timestamp              Status   State                   Message
2024-10-25T10:23:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:16:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:24Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:16:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:16:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:22Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2271

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3857589   35242     0        
Allow    Ingress     1          ANY          NONE         disabled    2669521   26533     0        
Allow    Egress      0          ANY          NONE         disabled    3457086   32424     0        

```


#### BPF CT List 2271

```
Invalid argument: unknown type 2271
```


#### Endpoint Get 2271

```
[
  {
    "id": 2271,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2271-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "155ed004-a67f-4d05-a9a3-8b1f90e6cefd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2271",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:15.971Z",
            "success-count": 2
          },
          "uuid": "2491c5a5-7680-44eb-ad0f-4fecc30b1741"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7cdb49698f-mfdkd",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:15.970Z",
            "success-count": 1
          },
          "uuid": "beb7dcbe-dce0-4eed-8592-293b1746fcea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2271",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:16.014Z",
            "success-count": 1
          },
          "uuid": "fefe8696-3b7e-449f-ab06-24b2443d3bdb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2271)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:06.014Z",
            "success-count": 37
          },
          "uuid": "40b4fc8a-b669-4609-b76e-f0418594c05d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "77a26606965bed2fb3076d58bb74ef1667f282994add27d2e721bb83b4b3abd2:eth0",
        "container-id": "77a26606965bed2fb3076d58bb74ef1667f282994add27d2e721bb83b4b3abd2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7cdb49698f-mfdkd",
        "pod-name": "kube-system/clustermesh-apiserver-7cdb49698f-mfdkd"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7489522,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh114",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7cdb49698f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh114",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:51Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.113.0.223",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "96:d6:3c:d8:bd:6f",
        "interface-index": 18,
        "interface-name": "lxc74595ad31c8e",
        "mac": "ce:20:49:a4:3f:cb"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7489522,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7489522,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2271

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2271

```
Timestamp              Status   State                   Message
2024-10-25T10:23:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:23:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:15Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:23:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:23:15Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:23:15Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7489522

```
ID        LABELS
7489522   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh114
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2740

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    213999   1930      0        
Allow    Ingress     1          ANY          NONE         disabled    72628    837       0        
Allow    Egress      0          ANY          NONE         disabled    60230    575       0        

```


#### BPF CT List 2740

```
Invalid argument: unknown type 2740
```


#### Endpoint Get 2740

```
[
  {
    "id": 2740,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2740-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "54e6c370-a99f-4df3-a83d-63405dd7df81"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2740",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:25.451Z",
            "success-count": 3
          },
          "uuid": "a69b752e-fe2f-424a-84b0-874d1a51b78a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-pdtlc",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:25.450Z",
            "success-count": 1
          },
          "uuid": "174177cd-32fe-4da9-aaf9-771355573078"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2740",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:26.931Z",
            "success-count": 1
          },
          "uuid": "698043e7-f1be-42e3-8d88-0e422cbb48a6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2740)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.515Z",
            "success-count": 78
          },
          "uuid": "b1a0318b-9fab-484f-9c91-51732b6f2818"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "935297702a7db538aea9f893da7ff5b9bf9b26b62f079f9b30d223f88fc1201b:eth0",
        "container-id": "935297702a7db538aea9f893da7ff5b9bf9b26b62f079f9b30d223f88fc1201b",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-pdtlc",
        "pod-name": "kube-system/coredns-cc6ccd49c-pdtlc"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7498628,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh114",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh114",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:51Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.113.0.87",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ee:8b:b9:cf:58:bb",
        "interface-index": 14,
        "interface-name": "lxc1c265c907a52",
        "mac": "e6:ed:f8:e1:e0:1b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7498628,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7498628,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2740

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2740

```
Timestamp              Status   State                   Message
2024-10-25T10:23:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:26Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:25Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:25Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7498628

```
ID        LABELS
7498628   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh114
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2854

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    219899   1980      0        
Allow    Ingress     1          ANY          NONE         disabled    71983    829       0        
Allow    Egress      0          ANY          NONE         disabled    61212    584       0        

```


#### BPF CT List 2854

```
Invalid argument: unknown type 2854
```


#### Endpoint Get 2854

```
[
  {
    "id": 2854,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2854-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "92d56574-24bb-47dd-b431-3992ab9849de"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2854",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:25.374Z",
            "success-count": 3
          },
          "uuid": "8553b183-6e33-4e20-8c88-fba9207f606d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-fvfq6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:25.372Z",
            "success-count": 1
          },
          "uuid": "77d3d6d2-5259-4222-8dd9-6a4843f5b70d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2854",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:26.878Z",
            "success-count": 1
          },
          "uuid": "e1be4323-d5ef-4fa1-9be7-7c3603a991eb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2854)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.446Z",
            "success-count": 78
          },
          "uuid": "9cb1894f-9507-4d53-bcc8-ec7fe94264ab"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "6b3a784db5f060d34f22cf7b0b2f056e113ac1f00f124a379da72f2d79143e2f:eth0",
        "container-id": "6b3a784db5f060d34f22cf7b0b2f056e113ac1f00f124a379da72f2d79143e2f",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-fvfq6",
        "pod-name": "kube-system/coredns-cc6ccd49c-fvfq6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7498628,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh114",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh114",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:51Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.113.0.28",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ae:b8:88:11:aa:5b",
        "interface-index": 12,
        "interface-name": "lxc0844a2ddf125",
        "mac": "86:b5:1e:a6:9b:f4"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7498628,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7498628,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2854

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2854

```
Timestamp              Status   State                   Message
2024-10-25T10:23:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:25Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:25Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:25Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:25Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7498628

```
ID        LABELS
7498628   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh114
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.184.7:443 (active)     
                                          2 => 172.31.243.127:443 (active)   
2    10.100.96.90:443      ClusterIP      1 => 172.31.195.97:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.113.0.28:53 (active)       
                                          2 => 10.113.0.87:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.113.0.28:9153 (active)     
                                          2 => 10.113.0.87:9153 (active)     
5    10.100.254.105:2379   ClusterIP      1 => 10.113.0.223:2379 (active)    
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 12597603                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 12597603                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 12597603                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c400000 rw-p 00000000 00:00 0 
400c400000-4010000000 ---p 00000000 00:00 0 
ffff67d62000-ffff67fa8000 rw-p 00000000 00:00 0 
ffff67fb0000-ffff680d1000 rw-p 00000000 00:00 0 
ffff680d1000-ffff68112000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff68112000-ffff68153000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff68153000-ffff68155000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff68155000-ffff68157000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff68157000-ffff686fe000 rw-p 00000000 00:00 0 
ffff686fe000-ffff687fe000 rw-p 00000000 00:00 0 
ffff687fe000-ffff6880f000 rw-p 00000000 00:00 0 
ffff6880f000-ffff6a80f000 rw-p 00000000 00:00 0 
ffff6a80f000-ffff6a88f000 ---p 00000000 00:00 0 
ffff6a88f000-ffff6a890000 rw-p 00000000 00:00 0 
ffff6a890000-ffff8a88f000 ---p 00000000 00:00 0 
ffff8a88f000-ffff8a890000 rw-p 00000000 00:00 0 
ffff8a890000-ffffaa81f000 ---p 00000000 00:00 0 
ffffaa81f000-ffffaa820000 rw-p 00000000 00:00 0 
ffffaa820000-ffffae811000 ---p 00000000 00:00 0 
ffffae811000-ffffae812000 rw-p 00000000 00:00 0 
ffffae812000-ffffaf00f000 ---p 00000000 00:00 0 
ffffaf00f000-ffffaf010000 rw-p 00000000 00:00 0 
ffffaf010000-ffffaf10f000 ---p 00000000 00:00 0 
ffffaf10f000-ffffaf16f000 rw-p 00000000 00:00 0 
ffffaf16f000-ffffaf171000 r--p 00000000 00:00 0                          [vvar]
ffffaf171000-ffffaf172000 r-xp 00000000 00:00 0                          [vdso]
ffffce46f000-ffffce490000 rw-p 00000000 00:00 0                          [stack]

```

