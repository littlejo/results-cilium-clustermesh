ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.184.7:443 (active)     
                                          2 => 172.31.243.127:443 (active)   
2    10.100.96.90:443      ClusterIP      1 => 172.31.195.97:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.113.0.28:53 (active)       
                                          2 => 10.113.0.87:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.113.0.28:9153 (active)     
                                          2 => 10.113.0.87:9153 (active)     
5    10.100.254.105:2379   ClusterIP      1 => 10.113.0.223:2379 (active)    
