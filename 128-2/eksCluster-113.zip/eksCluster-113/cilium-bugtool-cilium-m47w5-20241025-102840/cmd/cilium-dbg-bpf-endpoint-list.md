IP ADDRESS         LOCAL ENDPOINT INFO
10.113.0.28:0      id=2854  sec_id=7498628 flags=0x0000 ifindex=12  mac=86:B5:1E:A6:9B:F4 nodemac=AE:B8:88:11:AA:5B   
10.113.0.223:0     id=2271  sec_id=7489522 flags=0x0000 ifindex=18  mac=CE:20:49:A4:3F:CB nodemac=96:D6:3C:D8:BD:6F   
10.113.0.87:0      id=2740  sec_id=7498628 flags=0x0000 ifindex=14  mac=E6:ED:F8:E1:E0:1B nodemac=EE:8B:B9:CF:58:BB   
172.31.195.97:0    (localhost)                                                                                        
10.113.0.198:0     id=205   sec_id=4     flags=0x0000 ifindex=10  mac=C2:EA:9C:D1:8C:6A nodemac=E2:5B:DB:D7:28:28     
172.31.217.252:0   (localhost)                                                                                        
10.113.0.127:0     (localhost)                                                                                        
