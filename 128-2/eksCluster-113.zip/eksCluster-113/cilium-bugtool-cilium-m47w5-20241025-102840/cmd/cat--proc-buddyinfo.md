Node 0, zone      DMA      1      1      2      1      1     27     19      8      2      2    170 
Node 0, zone   Normal      3      1      1      1      1      3      2      2      2      1      9 
