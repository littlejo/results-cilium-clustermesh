key: 07 00 00 00  value: 0a 71 00 1c 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 71 00 57 00 35 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 71 00 57 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b8 07 01 bb 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f3 7f 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 71 00 1c 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 71 00 df 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f c3 61 10 94 00 00  00 00 00 00
Found 8 elements
