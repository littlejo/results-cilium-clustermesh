alloc: 83.55MB (87611056 bytes)
total-alloc: 1.32GB (1414579832 bytes)
sys: 206.51MB (216540500 bytes)
lookups: 0
mallocs: 47639119
frees: 46891489
heap-alloc: 83.55MB (87611056 bytes)
heap-sys: 161.57MB (169418752 bytes)
heap-idle: 49.61MB (52019200 bytes)
heap-in-use: 111.96MB (117399552 bytes)
heap-released: 544.00KB (557056 bytes)
heap-objects: 747630
stack-in-use: 34.41MB (36077568 bytes)
stack-sys: 34.41MB (36077568 bytes)
stack-mspan-inuse: 1.85MB (1936480 bytes)
stack-mspan-sys: 2.51MB (2627520 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 894.02KB (915473 bytes)
gc-sys: 5.24MB (5496896 bytes)
next-gc: when heap-alloc >= 147.40MB (154561480 bytes)
last-gc: 2024-10-25 10:28:52.759862444 +0000 UTC
gc-pause-total: 8.873258ms
gc-pause: 217208
gc-pause-end: 1729852132759862444
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003563995900012195
enable-gc: true
debug-gc: false
