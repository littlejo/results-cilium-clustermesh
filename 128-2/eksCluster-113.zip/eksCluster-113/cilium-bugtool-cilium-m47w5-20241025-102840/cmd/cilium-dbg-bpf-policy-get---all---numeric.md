Endpoint ID: 205
Path: /sys/fs/bpf/tc/globals/cilium_policy_00205

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    432682   5508      0        
Allow    Ingress     1          ANY          NONE         disabled    10072    116       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2188
Path: /sys/fs/bpf/tc/globals/cilium_policy_02188

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2271
Path: /sys/fs/bpf/tc/globals/cilium_policy_02271

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3857589   35242     0        
Allow    Ingress     1          ANY          NONE         disabled    2679657   26645     0        
Allow    Egress      0          ANY          NONE         disabled    3457586   32430     0        


Endpoint ID: 2740
Path: /sys/fs/bpf/tc/globals/cilium_policy_02740

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    213999   1930      0        
Allow    Ingress     1          ANY          NONE         disabled    72628    837       0        
Allow    Egress      0          ANY          NONE         disabled    60230    575       0        


Endpoint ID: 2854
Path: /sys/fs/bpf/tc/globals/cilium_policy_02854

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    219899   1980      0        
Allow    Ingress     1          ANY          NONE         disabled    71983    829       0        
Allow    Egress      0          ANY          NONE         disabled    61212    584       0        


