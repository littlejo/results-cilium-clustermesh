top - 10:28:42 up 14 min,  0 users,  load average: 1.01, 0.35, 0.20
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 30.0 sy,  0.0 ni, 13.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    791.5 free,    902.6 used,   2142.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2764.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538228 282312  78992 S  37.5   7.2   0:17.83 cilium-+
    414 root      20   0 1228848   6904   3844 S   0.0   0.2   0:00.24 cilium-+
    683 root      20   0 1240432  16712  11548 S   0.0   0.4   0:00.02 cilium-+
    687 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    717 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    747 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
