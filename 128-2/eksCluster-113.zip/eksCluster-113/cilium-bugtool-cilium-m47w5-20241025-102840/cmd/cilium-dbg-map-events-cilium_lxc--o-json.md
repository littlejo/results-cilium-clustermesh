{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.518Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.195.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.518Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.217.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.518Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.874Z",
  "value": "id=205   sec_id=4     flags=0x0000 ifindex=10  mac=C2:EA:9C:D1:8C:6A nodemac=E2:5B:DB:D7:28:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.877Z",
  "value": "id=2854  sec_id=7498628 flags=0x0000 ifindex=12  mac=86:B5:1E:A6:9B:F4 nodemac=AE:B8:88:11:AA:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.922Z",
  "value": "id=205   sec_id=4     flags=0x0000 ifindex=10  mac=C2:EA:9C:D1:8C:6A nodemac=E2:5B:DB:D7:28:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.929Z",
  "value": "id=2854  sec_id=7498628 flags=0x0000 ifindex=12  mac=86:B5:1E:A6:9B:F4 nodemac=AE:B8:88:11:AA:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.930Z",
  "value": "id=2740  sec_id=7498628 flags=0x0000 ifindex=14  mac=E6:ED:F8:E1:E0:1B nodemac=EE:8B:B9:CF:58:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:49.431Z",
  "value": "id=205   sec_id=4     flags=0x0000 ifindex=10  mac=C2:EA:9C:D1:8C:6A nodemac=E2:5B:DB:D7:28:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:49.431Z",
  "value": "id=2854  sec_id=7498628 flags=0x0000 ifindex=12  mac=86:B5:1E:A6:9B:F4 nodemac=AE:B8:88:11:AA:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:49.432Z",
  "value": "id=2740  sec_id=7498628 flags=0x0000 ifindex=14  mac=E6:ED:F8:E1:E0:1B nodemac=EE:8B:B9:CF:58:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:49.464Z",
  "value": "id=1570  sec_id=7489522 flags=0x0000 ifindex=16  mac=72:44:89:88:0E:0D nodemac=12:A4:94:DF:9C:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.431Z",
  "value": "id=205   sec_id=4     flags=0x0000 ifindex=10  mac=C2:EA:9C:D1:8C:6A nodemac=E2:5B:DB:D7:28:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.432Z",
  "value": "id=2854  sec_id=7498628 flags=0x0000 ifindex=12  mac=86:B5:1E:A6:9B:F4 nodemac=AE:B8:88:11:AA:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.432Z",
  "value": "id=1570  sec_id=7489522 flags=0x0000 ifindex=16  mac=72:44:89:88:0E:0D nodemac=12:A4:94:DF:9C:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.432Z",
  "value": "id=2740  sec_id=7498628 flags=0x0000 ifindex=14  mac=E6:ED:F8:E1:E0:1B nodemac=EE:8B:B9:CF:58:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.013Z",
  "value": "id=2271  sec_id=7489522 flags=0x0000 ifindex=18  mac=CE:20:49:A4:3F:CB nodemac=96:D6:3C:D8:BD:6F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.113.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.437Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:49.292Z",
  "value": "id=2740  sec_id=7498628 flags=0x0000 ifindex=14  mac=E6:ED:F8:E1:E0:1B nodemac=EE:8B:B9:CF:58:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:49.294Z",
  "value": "id=2271  sec_id=7489522 flags=0x0000 ifindex=18  mac=CE:20:49:A4:3F:CB nodemac=96:D6:3C:D8:BD:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:49.294Z",
  "value": "id=205   sec_id=4     flags=0x0000 ifindex=10  mac=C2:EA:9C:D1:8C:6A nodemac=E2:5B:DB:D7:28:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:49.295Z",
  "value": "id=2854  sec_id=7498628 flags=0x0000 ifindex=12  mac=86:B5:1E:A6:9B:F4 nodemac=AE:B8:88:11:AA:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:50.293Z",
  "value": "id=2740  sec_id=7498628 flags=0x0000 ifindex=14  mac=E6:ED:F8:E1:E0:1B nodemac=EE:8B:B9:CF:58:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:50.293Z",
  "value": "id=2271  sec_id=7489522 flags=0x0000 ifindex=18  mac=CE:20:49:A4:3F:CB nodemac=96:D6:3C:D8:BD:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:50.293Z",
  "value": "id=2854  sec_id=7498628 flags=0x0000 ifindex=12  mac=86:B5:1E:A6:9B:F4 nodemac=AE:B8:88:11:AA:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:50.293Z",
  "value": "id=205   sec_id=4     flags=0x0000 ifindex=10  mac=C2:EA:9C:D1:8C:6A nodemac=E2:5B:DB:D7:28:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:51.293Z",
  "value": "id=205   sec_id=4     flags=0x0000 ifindex=10  mac=C2:EA:9C:D1:8C:6A nodemac=E2:5B:DB:D7:28:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:51.293Z",
  "value": "id=2271  sec_id=7489522 flags=0x0000 ifindex=18  mac=CE:20:49:A4:3F:CB nodemac=96:D6:3C:D8:BD:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:51.294Z",
  "value": "id=2854  sec_id=7498628 flags=0x0000 ifindex=12  mac=86:B5:1E:A6:9B:F4 nodemac=AE:B8:88:11:AA:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:51.294Z",
  "value": "id=2740  sec_id=7498628 flags=0x0000 ifindex=14  mac=E6:ED:F8:E1:E0:1B nodemac=EE:8B:B9:CF:58:BB"
}

