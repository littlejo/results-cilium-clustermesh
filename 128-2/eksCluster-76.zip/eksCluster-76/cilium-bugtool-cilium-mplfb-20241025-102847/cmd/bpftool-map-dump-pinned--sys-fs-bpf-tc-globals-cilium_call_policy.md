key: 39 01 00 00  value: 50 02 00 00
key: 05 07 00 00  value: e7 01 00 00
key: 48 0d 00 00  value: 0c 02 00 00
key: 73 0d 00 00  value: 03 02 00 00
Found 4 elements
