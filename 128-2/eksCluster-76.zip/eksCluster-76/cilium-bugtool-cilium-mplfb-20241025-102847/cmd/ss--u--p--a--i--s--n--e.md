Total: 547
TCP:   1076 (estab 301, closed 756, orphaned 0, timewait 295)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  320       309       11       
INET	  330       315       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:42909      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=25)) ino:21290 sk:25d fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.158.228%ens5:68         0.0.0.0:*    uid:192 ino:15591 sk:25e cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:21802 sk:25f cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15279 sk:260 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:21801 sk:261 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15280 sk:262 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::421:92ff:fee5:2c67]%ens5:546           [::]:*    uid:192 ino:16453 sk:263 cgroup:unreachable:c4e v6only:1 <->                   
