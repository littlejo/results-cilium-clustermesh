alloc: 103.28MB (108296968 bytes)
total-alloc: 1.34GB (1434098456 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 47792654
frees: 46678748
heap-alloc: 103.28MB (108296968 bytes)
heap-sys: 161.26MB (169091072 bytes)
heap-idle: 39.20MB (41099264 bytes)
heap-in-use: 122.06MB (127991808 bytes)
heap-released: 2.47MB (2588672 bytes)
heap-objects: 1113906
stack-in-use: 34.72MB (36405248 bytes)
stack-sys: 34.72MB (36405248 bytes)
stack-mspan-inuse: 2.02MB (2121440 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 926.77KB (949009 bytes)
gc-sys: 5.15MB (5404976 bytes)
next-gc: when heap-alloc >= 147.21MB (154359464 bytes)
last-gc: 2024-10-25 10:28:51.07077689 +0000 UTC
gc-pause-total: 8.697779ms
gc-pause: 227048
gc-pause-end: 1729852131070776890
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003470900590037175
enable-gc: true
debug-gc: false
