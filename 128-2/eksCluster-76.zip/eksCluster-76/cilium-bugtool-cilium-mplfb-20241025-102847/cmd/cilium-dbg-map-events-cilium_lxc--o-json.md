{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:33.867Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.158.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:33.867Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.376Z",
  "value": "id=1797  sec_id=5050532 flags=0x0000 ifindex=9   mac=4E:BB:BF:25:76:EB nodemac=12:F1:C2:1C:2D:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.379Z",
  "value": "id=3400  sec_id=4     flags=0x0000 ifindex=7   mac=16:69:DD:05:DC:0C nodemac=B6:8E:80:D5:67:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.461Z",
  "value": "id=3443  sec_id=5050532 flags=0x0000 ifindex=11  mac=4E:1A:D3:47:FE:F5 nodemac=2E:18:50:75:15:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.483Z",
  "value": "id=3400  sec_id=4     flags=0x0000 ifindex=7   mac=16:69:DD:05:DC:0C nodemac=B6:8E:80:D5:67:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.907Z",
  "value": "id=3443  sec_id=5050532 flags=0x0000 ifindex=11  mac=4E:1A:D3:47:FE:F5 nodemac=2E:18:50:75:15:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.907Z",
  "value": "id=3400  sec_id=4     flags=0x0000 ifindex=7   mac=16:69:DD:05:DC:0C nodemac=B6:8E:80:D5:67:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.908Z",
  "value": "id=1797  sec_id=5050532 flags=0x0000 ifindex=9   mac=4E:BB:BF:25:76:EB nodemac=12:F1:C2:1C:2D:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.939Z",
  "value": "id=2623  sec_id=5051738 flags=0x0000 ifindex=13  mac=A6:25:5E:9C:FD:A2 nodemac=96:BF:E1:7E:C4:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.906Z",
  "value": "id=1797  sec_id=5050532 flags=0x0000 ifindex=9   mac=4E:BB:BF:25:76:EB nodemac=12:F1:C2:1C:2D:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.907Z",
  "value": "id=3443  sec_id=5050532 flags=0x0000 ifindex=11  mac=4E:1A:D3:47:FE:F5 nodemac=2E:18:50:75:15:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.907Z",
  "value": "id=3400  sec_id=4     flags=0x0000 ifindex=7   mac=16:69:DD:05:DC:0C nodemac=B6:8E:80:D5:67:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.907Z",
  "value": "id=2623  sec_id=5051738 flags=0x0000 ifindex=13  mac=A6:25:5E:9C:FD:A2 nodemac=96:BF:E1:7E:C4:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:31.081Z",
  "value": "id=313   sec_id=5051738 flags=0x0000 ifindex=15  mac=D6:CD:5F:CE:3B:4C nodemac=B6:FD:9E:BA:0E:A3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.76.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.758Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.671Z",
  "value": "id=3443  sec_id=5050532 flags=0x0000 ifindex=11  mac=4E:1A:D3:47:FE:F5 nodemac=2E:18:50:75:15:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.672Z",
  "value": "id=313   sec_id=5051738 flags=0x0000 ifindex=15  mac=D6:CD:5F:CE:3B:4C nodemac=B6:FD:9E:BA:0E:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.672Z",
  "value": "id=3400  sec_id=4     flags=0x0000 ifindex=7   mac=16:69:DD:05:DC:0C nodemac=B6:8E:80:D5:67:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.673Z",
  "value": "id=1797  sec_id=5050532 flags=0x0000 ifindex=9   mac=4E:BB:BF:25:76:EB nodemac=12:F1:C2:1C:2D:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.668Z",
  "value": "id=3443  sec_id=5050532 flags=0x0000 ifindex=11  mac=4E:1A:D3:47:FE:F5 nodemac=2E:18:50:75:15:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.668Z",
  "value": "id=313   sec_id=5051738 flags=0x0000 ifindex=15  mac=D6:CD:5F:CE:3B:4C nodemac=B6:FD:9E:BA:0E:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.668Z",
  "value": "id=1797  sec_id=5050532 flags=0x0000 ifindex=9   mac=4E:BB:BF:25:76:EB nodemac=12:F1:C2:1C:2D:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.668Z",
  "value": "id=3400  sec_id=4     flags=0x0000 ifindex=7   mac=16:69:DD:05:DC:0C nodemac=B6:8E:80:D5:67:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.668Z",
  "value": "id=3400  sec_id=4     flags=0x0000 ifindex=7   mac=16:69:DD:05:DC:0C nodemac=B6:8E:80:D5:67:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.668Z",
  "value": "id=3443  sec_id=5050532 flags=0x0000 ifindex=11  mac=4E:1A:D3:47:FE:F5 nodemac=2E:18:50:75:15:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.668Z",
  "value": "id=1797  sec_id=5050532 flags=0x0000 ifindex=9   mac=4E:BB:BF:25:76:EB nodemac=12:F1:C2:1C:2D:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.668Z",
  "value": "id=313   sec_id=5051738 flags=0x0000 ifindex=15  mac=D6:CD:5F:CE:3B:4C nodemac=B6:FD:9E:BA:0E:A3"
}

