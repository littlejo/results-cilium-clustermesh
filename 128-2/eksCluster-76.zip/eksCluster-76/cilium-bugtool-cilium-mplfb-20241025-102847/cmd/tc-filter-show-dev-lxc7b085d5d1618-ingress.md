filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7b085d5d1618 direct-action not_in_hw id 517 tag e57a8b72ae523ed9 jited 
