Endpoint ID: 313
Path: /sys/fs/bpf/tc/globals/cilium_policy_00313

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3925204   36579     0        
Allow    Ingress     1          ANY          NONE         disabled    2890842   28957     0        
Allow    Egress      0          ANY          NONE         disabled    4233451   39371     0        


Endpoint ID: 882
Path: /sys/fs/bpf/tc/globals/cilium_policy_00882

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1797
Path: /sys/fs/bpf/tc/globals/cilium_policy_01797

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89413   1029      0        
Allow    Egress      0          ANY          NONE         disabled    15341   163       0        


Endpoint ID: 3400
Path: /sys/fs/bpf/tc/globals/cilium_policy_03400

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    442508   5643      0        
Allow    Ingress     1          ANY          NONE         disabled    12772    148       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3443
Path: /sys/fs/bpf/tc/globals/cilium_policy_03443

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89281   1027      0        
Allow    Egress      0          ANY          NONE         disabled    14138   149       0        


