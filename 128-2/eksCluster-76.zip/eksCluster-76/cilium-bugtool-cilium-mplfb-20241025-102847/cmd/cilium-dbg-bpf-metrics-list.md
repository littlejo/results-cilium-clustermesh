REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     216622    100320176   1132   bpf_host.c
Interface                 INGRESS     9642      752427      677    bpf_overlay.c
Success                   EGRESS      4688      356873      1694   bpf_host.c
Success                   EGRESS      90066     12150793    1308   bpf_lxc.c
Success                   EGRESS      9448      738304      53     encap.h
Success                   INGRESS     100588    12319233    86     l3.h
Success                   INGRESS     106191    12758693    235    trace.h
Unsupported L3 protocol   EGRESS      38        2832        1492   bpf_lxc.c
