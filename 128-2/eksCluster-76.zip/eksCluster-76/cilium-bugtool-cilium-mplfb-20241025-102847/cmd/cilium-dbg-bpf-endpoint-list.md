IP ADDRESS         LOCAL ENDPOINT INFO
10.76.0.10:0       id=313   sec_id=5051738 flags=0x0000 ifindex=15  mac=D6:CD:5F:CE:3B:4C nodemac=B6:FD:9E:BA:0E:A3   
10.76.0.172:0      id=3400  sec_id=4     flags=0x0000 ifindex=7   mac=16:69:DD:05:DC:0C nodemac=B6:8E:80:D5:67:9F     
10.76.0.156:0      (localhost)                                                                                        
10.76.0.119:0      id=1797  sec_id=5050532 flags=0x0000 ifindex=9   mac=4E:BB:BF:25:76:EB nodemac=12:F1:C2:1C:2D:E0   
172.31.158.228:0   (localhost)                                                                                        
10.76.0.138:0      id=3443  sec_id=5050532 flags=0x0000 ifindex=11  mac=4E:1A:D3:47:FE:F5 nodemac=2E:18:50:75:15:2F   
