xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 513
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 504
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 496
cilium_host(4) clsact/egress cil_from_host-cilium_host id 495
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 444
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 447
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 521
lxca91a52c5bf32(9) clsact/ingress cil_from_container-lxca91a52c5bf32 id 481
lxc7b085d5d1618(11) clsact/ingress cil_from_container-lxc7b085d5d1618 id 517
lxcc09b62d7f114(15) clsact/ingress cil_from_container-lxcc09b62d7f114 id 597

flow_dissector:

netfilter:

