1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:21:92:e5:2c:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.158.228/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2648sec preferred_lft 2648sec
    inet6 fe80::421:92ff:fee5:2c67/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:64:52:fb:f2:cc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2864:52ff:fefb:f2cc/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:dd:90:ae:fb:8b brd ff:ff:ff:ff:ff:ff
    inet 10.76.0.156/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c0dd:90ff:feae:fb8b/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:c0:2e:3d:38:bb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::68c0:2eff:fe3d:38bb/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:8e:80:d5:67:9f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b48e:80ff:fed5:679f/64 scope link 
       valid_lft forever preferred_lft forever
9: lxca91a52c5bf32@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:f1:c2:1c:2d:e0 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::10f1:c2ff:fe1c:2de0/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc7b085d5d1618@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:18:50:75:15:2f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2c18:50ff:fe75:152f/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcc09b62d7f114@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:fd:9e:ba:0e:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b4fd:9eff:feba:ea3/64 scope link 
       valid_lft forever preferred_lft forever
