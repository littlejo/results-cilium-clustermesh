[
  {
    "containers": [
      {
        "cgroup-id": 8306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9fd142fd_3c89_4b56_87f6_530e961417c8.slice/cri-containerd-8997b4f6d4f9170ae838217a4b7675b89270451bbb20ea1e5fa62e9fa4bbb005.scope"
      },
      {
        "cgroup-id": 8222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9fd142fd_3c89_4b56_87f6_530e961417c8.slice/cri-containerd-809b53973ae5e6195012cb1ab5db8ef9619c1fc5e729b46182fa9467375b2122.scope"
      },
      {
        "cgroup-id": 8390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9fd142fd_3c89_4b56_87f6_530e961417c8.slice/cri-containerd-2664babfb03cb7eb95804269e24054bd5fc102164b4aa8b686d4fbd1fca0b5c2.scope"
      }
    ],
    "ips": [
      "10.76.0.10"
    ],
    "name": "clustermesh-apiserver-64dc5b6c5b-4wd6j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6878,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb5f7572_6a4f_4f11_98f3_84a916bf88c9.slice/cri-containerd-85ed4082b30752a49ede287efaa7b68d8151cecd530e71c6d26d9dc0c6c974f7.scope"
      }
    ],
    "ips": [
      "10.76.0.119"
    ],
    "name": "coredns-cc6ccd49c-5btjx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6794,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc64658f4_e767_457c_aa9d_61061d27bb1d.slice/cri-containerd-fdabeb3cc7a058637d06ca96c6187afa50f1bac2005ba8e433987c236880e1b9.scope"
      }
    ],
    "ips": [
      "10.76.0.138"
    ],
    "name": "coredns-cc6ccd49c-dnfbx",
    "namespace": "kube-system"
  }
]

