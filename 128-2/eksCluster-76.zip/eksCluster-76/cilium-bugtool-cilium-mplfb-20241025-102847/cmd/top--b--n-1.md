top - 10:28:48 up 16 min,  0 users,  load average: 0.11, 0.21, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 48.3 us, 48.3 sy,  0.0 ni,  3.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1186.6 free,    893.5 used,   1756.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2774.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 276908  79100 S  40.0   7.0   0:21.74 cilium-+
    645 root      20   0 1240432  16724  11548 S   6.7   0.4   0:00.03 cilium-+
    414 root      20   0 1228848   6044   2924 S   0.0   0.2   0:00.26 cilium-+
    675 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    679 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    680 root      20   0 1228744   3652   2976 S   0.0   0.1   0:00.00 gops
    691 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
    695 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    739 root      20   0 1229000   4020   3356 S   0.0   0.1   0:00.00 gops
