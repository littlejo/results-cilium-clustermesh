ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.251.114:443 (active)    
                                          2 => 172.31.191.20:443 (active)     
2    10.100.177.149:443    ClusterIP      1 => 172.31.158.228:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.76.0.119:9153 (active)      
                                          2 => 10.76.0.138:9153 (active)      
4    10.100.0.10:53        ClusterIP      1 => 10.76.0.119:53 (active)        
                                          2 => 10.76.0.138:53 (active)        
5    10.100.155.122:2379   ClusterIP      1 => 10.76.0.10:2379 (active)       
