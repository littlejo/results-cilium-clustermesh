markdown output at /tmp/cilium-bugtool-20241025-102848.588+0000-UTC-2544175302/cmd/cilium-debuginfo-20241025-102919.387+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102848.588+0000-UTC-2544175302/cmd/cilium-debuginfo-20241025-102919.387+0000-UTC.json
