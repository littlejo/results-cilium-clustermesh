CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb5f7572_6a4f_4f11_98f3_84a916bf88c9.slice/cri-containerd-6064c65a2388965f3b5a0cc41ab0cd10964c80c5b37f45d2d58d8e67f4d2c621.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb5f7572_6a4f_4f11_98f3_84a916bf88c9.slice/cri-containerd-85ed4082b30752a49ede287efaa7b68d8151cecd530e71c6d26d9dc0c6c974f7.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7eb099ea_eabe_4bcb_8248_d59ac0edf509.slice/cri-containerd-232976c3022247110c6deadc0c530d1365a533ce19c76cccc45d4f4aabd9c858.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7eb099ea_eabe_4bcb_8248_d59ac0edf509.slice/cri-containerd-512b1e5ba2fb697ee798bc262ccf4ae2cf993dcbc3fb6f5feb29716e60b3951f.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c4db3e8_cbb6_4baa_bfc9_9c4fb6c4af12.slice/cri-containerd-d73b948c4dcb1edf0e22f2898285752b07a359da0bd21b365b212c0a0e71c1f6.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c4db3e8_cbb6_4baa_bfc9_9c4fb6c4af12.slice/cri-containerd-6d00aa309d71a21d2c8eac1b1446c9da3ffbde50ab05fb626f1663b51b54e08e.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc64658f4_e767_457c_aa9d_61061d27bb1d.slice/cri-containerd-8cff8a8305cf73fc6b34a9ca7b65f16eefba000378fd75f38e4d018e69d89230.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc64658f4_e767_457c_aa9d_61061d27bb1d.slice/cri-containerd-fdabeb3cc7a058637d06ca96c6187afa50f1bac2005ba8e433987c236880e1b9.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9fd142fd_3c89_4b56_87f6_530e961417c8.slice/cri-containerd-8997b4f6d4f9170ae838217a4b7675b89270451bbb20ea1e5fa62e9fa4bbb005.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9fd142fd_3c89_4b56_87f6_530e961417c8.slice/cri-containerd-809b53973ae5e6195012cb1ab5db8ef9619c1fc5e729b46182fa9467375b2122.scope
    619      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9fd142fd_3c89_4b56_87f6_530e961417c8.slice/cri-containerd-387895ef30637beeadf98b5b6e53183069925a5d180ae10eb953196d72fceec7.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9fd142fd_3c89_4b56_87f6_530e961417c8.slice/cri-containerd-2664babfb03cb7eb95804269e24054bd5fc102164b4aa8b686d4fbd1fca0b5c2.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1be8831e_cf20_4c05_afc7_d2b60ef79990.slice/cri-containerd-31b62a2543ffcfa864cfdc93ecad818aae8bd463c11beaa4526236842d3f0d38.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1be8831e_cf20_4c05_afc7_d2b60ef79990.slice/cri-containerd-e767f1f3249ea673d500f7cead925630b617ca7b44bd1bd1546bae22f0c692f3.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ebd6d5d_f904_43b3_aafb_57972bca28b7.slice/cri-containerd-45a90d510a9a5987e915d112d7a5cbeb23d5a5507db73498534b9d804635ef72.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ebd6d5d_f904_43b3_aafb_57972bca28b7.slice/cri-containerd-fbce5b587052737effe099a9073e232a1a933b1c426e639fee101b93cc58b614.scope
    61       cgroup_device   multi                                          
