alloc: 111.44MB (116857080 bytes)
total-alloc: 1.33GB (1423426800 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 47704291
frees: 46542197
heap-alloc: 111.44MB (116857080 bytes)
heap-sys: 169.23MB (177455104 bytes)
heap-idle: 37.92MB (39763968 bytes)
heap-in-use: 131.31MB (137691136 bytes)
heap-released: 13.45MB (14098432 bytes)
heap-objects: 1162094
stack-in-use: 34.72MB (36405248 bytes)
stack-sys: 34.72MB (36405248 bytes)
stack-mspan-inuse: 2.15MB (2254720 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 924.07KB (946249 bytes)
gc-sys: 5.20MB (5452200 bytes)
next-gc: when heap-alloc >= 147.78MB (154962056 bytes)
last-gc: 2024-10-25 10:28:49.273730827 +0000 UTC
gc-pause-total: 15.563343ms
gc-pause: 995358
gc-pause-end: 1729852129273730827
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00045764858765667723
enable-gc: true
debug-gc: false
