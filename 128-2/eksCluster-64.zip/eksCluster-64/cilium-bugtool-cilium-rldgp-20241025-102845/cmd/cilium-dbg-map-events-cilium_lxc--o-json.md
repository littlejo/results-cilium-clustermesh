{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:38.375Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.129.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:38.375Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.165.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:38.375Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.227Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=0E:99:89:19:8C:C9 nodemac=36:1C:E5:9B:42:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.229Z",
  "value": "id=1468  sec_id=4316056 flags=0x0000 ifindex=12  mac=C6:04:69:30:C9:C5 nodemac=1A:07:DB:9D:8F:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.292Z",
  "value": "id=1010  sec_id=4316056 flags=0x0000 ifindex=14  mac=AA:1C:93:57:82:7F nodemac=AA:11:95:8C:4A:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.316Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=0E:99:89:19:8C:C9 nodemac=36:1C:E5:9B:42:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.487Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=0E:99:89:19:8C:C9 nodemac=36:1C:E5:9B:42:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.488Z",
  "value": "id=1468  sec_id=4316056 flags=0x0000 ifindex=12  mac=C6:04:69:30:C9:C5 nodemac=1A:07:DB:9D:8F:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.489Z",
  "value": "id=1010  sec_id=4316056 flags=0x0000 ifindex=14  mac=AA:1C:93:57:82:7F nodemac=AA:11:95:8C:4A:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.521Z",
  "value": "id=175   sec_id=4260343 flags=0x0000 ifindex=16  mac=D6:B7:58:40:AE:B4 nodemac=4E:11:FC:75:A1:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.488Z",
  "value": "id=175   sec_id=4260343 flags=0x0000 ifindex=16  mac=D6:B7:58:40:AE:B4 nodemac=4E:11:FC:75:A1:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.488Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=0E:99:89:19:8C:C9 nodemac=36:1C:E5:9B:42:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.488Z",
  "value": "id=1468  sec_id=4316056 flags=0x0000 ifindex=12  mac=C6:04:69:30:C9:C5 nodemac=1A:07:DB:9D:8F:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.488Z",
  "value": "id=1010  sec_id=4316056 flags=0x0000 ifindex=14  mac=AA:1C:93:57:82:7F nodemac=AA:11:95:8C:4A:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.886Z",
  "value": "id=2614  sec_id=4260343 flags=0x0000 ifindex=18  mac=42:CB:35:83:46:F1 nodemac=66:7F:72:2C:5F:E1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.731Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.954Z",
  "value": "id=1468  sec_id=4316056 flags=0x0000 ifindex=12  mac=C6:04:69:30:C9:C5 nodemac=1A:07:DB:9D:8F:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.954Z",
  "value": "id=1010  sec_id=4316056 flags=0x0000 ifindex=14  mac=AA:1C:93:57:82:7F nodemac=AA:11:95:8C:4A:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.955Z",
  "value": "id=2614  sec_id=4260343 flags=0x0000 ifindex=18  mac=42:CB:35:83:46:F1 nodemac=66:7F:72:2C:5F:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.956Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=0E:99:89:19:8C:C9 nodemac=36:1C:E5:9B:42:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.952Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=0E:99:89:19:8C:C9 nodemac=36:1C:E5:9B:42:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.952Z",
  "value": "id=2614  sec_id=4260343 flags=0x0000 ifindex=18  mac=42:CB:35:83:46:F1 nodemac=66:7F:72:2C:5F:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.952Z",
  "value": "id=1468  sec_id=4316056 flags=0x0000 ifindex=12  mac=C6:04:69:30:C9:C5 nodemac=1A:07:DB:9D:8F:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.952Z",
  "value": "id=1010  sec_id=4316056 flags=0x0000 ifindex=14  mac=AA:1C:93:57:82:7F nodemac=AA:11:95:8C:4A:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.952Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=0E:99:89:19:8C:C9 nodemac=36:1C:E5:9B:42:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.952Z",
  "value": "id=2614  sec_id=4260343 flags=0x0000 ifindex=18  mac=42:CB:35:83:46:F1 nodemac=66:7F:72:2C:5F:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.952Z",
  "value": "id=1468  sec_id=4316056 flags=0x0000 ifindex=12  mac=C6:04:69:30:C9:C5 nodemac=1A:07:DB:9D:8F:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.953Z",
  "value": "id=1010  sec_id=4316056 flags=0x0000 ifindex=14  mac=AA:1C:93:57:82:7F nodemac=AA:11:95:8C:4A:34"
}

