key: dd 00 00 00  value: 45 02 00 00
key: f2 03 00 00  value: 42 02 00 00
key: bc 05 00 00  value: 10 02 00 00
key: 36 0a 00 00  value: 85 02 00 00
Found 4 elements
