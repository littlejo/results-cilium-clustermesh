IP ADDRESS         LOCAL ENDPOINT INFO
10.64.0.112:0      (localhost)                                                                                        
10.64.0.234:0      id=1468  sec_id=4316056 flags=0x0000 ifindex=12  mac=C6:04:69:30:C9:C5 nodemac=1A:07:DB:9D:8F:3C   
10.64.0.213:0      id=2614  sec_id=4260343 flags=0x0000 ifindex=18  mac=42:CB:35:83:46:F1 nodemac=66:7F:72:2C:5F:E1   
10.64.0.169:0      id=221   sec_id=4     flags=0x0000 ifindex=10  mac=0E:99:89:19:8C:C9 nodemac=36:1C:E5:9B:42:51     
172.31.165.7:0     (localhost)                                                                                        
172.31.129.220:0   (localhost)                                                                                        
10.64.0.104:0      id=1010  sec_id=4316056 flags=0x0000 ifindex=14  mac=AA:1C:93:57:82:7F nodemac=AA:11:95:8C:4A:34   
