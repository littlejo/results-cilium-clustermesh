 10:28:47 up 13 min,  0 users,  load average: 0.04, 0.20, 0.22
