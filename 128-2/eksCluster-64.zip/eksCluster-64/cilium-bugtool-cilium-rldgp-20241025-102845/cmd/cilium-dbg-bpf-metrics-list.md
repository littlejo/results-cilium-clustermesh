REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     215431    84448881   1132   bpf_host.c
Interface                 INGRESS     9614      750133     677    bpf_overlay.c
Success                   EGRESS      4714      358621     1694   bpf_host.c
Success                   EGRESS      90808     12154509   1308   bpf_lxc.c
Success                   EGRESS      9453      738187     53     encap.h
Success                   INGRESS     101296    12466415   86     l3.h
Success                   INGRESS     106845    12901833   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
