Total: 546
TCP:   1068 (estab 296, closed 753, orphaned 0, timewait 305)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  315       304       11       
INET	  325       310       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15358 sk:1 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:33487      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:25340 sk:2 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.129.220%ens5:68         0.0.0.0:*    uid:192 ino:15605 sk:3 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24168 sk:4 cgroup:/ <->                                                  
UNCONN 0      0                                [::1]:323           [::]:*    ino:15359 sk:5 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::414:5eff:fe44:b607]%ens5:546           [::]:*    uid:192 ino:15596 sk:6 cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24167 sk:7 cgroup:/ v6only:1 <->                                         
