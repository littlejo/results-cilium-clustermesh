1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:14:5e:44:b6:07 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.129.220/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2778sec preferred_lft 2778sec
    inet6 fe80::414:5eff:fe44:b607/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:54:a2:26:d6:f5 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.165.7/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::454:a2ff:fe26:d6f5/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:d1:1e:88:6f:b3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dcd1:1eff:fe88:6fb3/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:17:a1:f0:b2:58 brd ff:ff:ff:ff:ff:ff
    inet 10.64.0.112/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1c17:a1ff:fef0:b258/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ba:be:1e:65:d1:7d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b8be:1eff:fe65:d17d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:1c:e5:9b:42:51 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::341c:e5ff:fe9b:4251/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd78ed7d10667@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:07:db:9d:8f:3c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1807:dbff:fe9d:8f3c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb2dbfc94fbfc@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:11:95:8c:4a:34 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::a811:95ff:fe8c:4a34/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8b821262339a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:7f:72:2c:5f:e1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::647f:72ff:fe2c:5fe1/64 scope link 
       valid_lft forever preferred_lft forever
