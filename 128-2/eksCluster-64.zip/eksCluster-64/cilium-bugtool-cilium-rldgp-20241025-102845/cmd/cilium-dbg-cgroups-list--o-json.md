[
  {
    "containers": [
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b5d1c29_021d_445b_88fc_cdb9c4a00600.slice/cri-containerd-5c443c96dcc95424e6c97163f4e879586fa90172e6d326de17f5876935ebbaf3.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b5d1c29_021d_445b_88fc_cdb9c4a00600.slice/cri-containerd-6e8e46290728e4b4efd23299f6406fafeedb20d61bcc011196c67b7c2737940a.scope"
      },
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b5d1c29_021d_445b_88fc_cdb9c4a00600.slice/cri-containerd-f4c2cf76e582e3dff0f33d4e249e8125c683be73a9fb1353ede33de80908e461.scope"
      }
    ],
    "ips": [
      "10.64.0.213"
    ],
    "name": "clustermesh-apiserver-85d7845c5c-nvc8s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e691d83_bb96_4f74_8835_e44a5f9ab47b.slice/cri-containerd-7fb63a8bb3d050e01a8a23a814cc125089183b9ec5f84b24c8e672583eba2d22.scope"
      }
    ],
    "ips": [
      "10.64.0.104"
    ],
    "name": "coredns-cc6ccd49c-nb4sh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36b91409_5572_4258_a7c4_5bb48ab109f2.slice/cri-containerd-cc1ed9eef8348e096580d9b9c22b87efabce18ef34da7a4b80fc94671261a8b1.scope"
      }
    ],
    "ips": [
      "10.64.0.234"
    ],
    "name": "coredns-cc6ccd49c-md6d6",
    "namespace": "kube-system"
  }
]

