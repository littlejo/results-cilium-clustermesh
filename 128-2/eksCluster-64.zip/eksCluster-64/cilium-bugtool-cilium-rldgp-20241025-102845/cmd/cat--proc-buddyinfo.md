Node 0, zone      DMA      3      2      2      3      5     68     37     12      3      3    159 
Node 0, zone   Normal     68     10      8      1      0      4      6      7      4      2      7 
