KEY             VALUE
AgentLiveness   861934027705
UTimeOffset     3378615812500000
