CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36b91409_5572_4258_a7c4_5bb48ab109f2.slice/cri-containerd-cc1ed9eef8348e096580d9b9c22b87efabce18ef34da7a4b80fc94671261a8b1.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36b91409_5572_4258_a7c4_5bb48ab109f2.slice/cri-containerd-c245e7d6692e9ea51c6b752ec329b324d8da5a89ebb6d6dcdc6992f8d5cd9eaa.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a817fce_bf92_4758_bc85_431d92086c98.slice/cri-containerd-12095bb67821b544d8ab37d840f9135194b233dd63a540401e9a3d6ce98f21eb.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a817fce_bf92_4758_bc85_431d92086c98.slice/cri-containerd-a125632ff538fe4ec6d40c21ea9696ac90d126e6548bf4ab28fa897f6ca770ea.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e691d83_bb96_4f74_8835_e44a5f9ab47b.slice/cri-containerd-7fb63a8bb3d050e01a8a23a814cc125089183b9ec5f84b24c8e672583eba2d22.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e691d83_bb96_4f74_8835_e44a5f9ab47b.slice/cri-containerd-b11a9ce3e7b2bd08efa61f401695a685f84824e1cd713b60885466e2cc198b8a.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1298cef_107d_4e25_95d8_0c769ff1cedd.slice/cri-containerd-7dd0c1300e9acb0d3757e43633f1749b15bc46edb59a688b61c18a5fbc8a7a20.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1298cef_107d_4e25_95d8_0c769ff1cedd.slice/cri-containerd-c65643f4579045d3018e7b9a2ba122ca184a79abe01dbf1eeabcd7cc1c53ec7c.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40a4c5a9_0054_40fa_90a8_25f4e6006dbe.slice/cri-containerd-dd52be191cf644867a3a0dd59a2205661322d24e7def53894786138ee7f91d07.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40a4c5a9_0054_40fa_90a8_25f4e6006dbe.slice/cri-containerd-b08e90c40478e52aa21a1b2258011ebbb92153cd477d858b7564c2f0b8bda1a3.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b5d1c29_021d_445b_88fc_cdb9c4a00600.slice/cri-containerd-f4c2cf76e582e3dff0f33d4e249e8125c683be73a9fb1353ede33de80908e461.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b5d1c29_021d_445b_88fc_cdb9c4a00600.slice/cri-containerd-5c443c96dcc95424e6c97163f4e879586fa90172e6d326de17f5876935ebbaf3.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b5d1c29_021d_445b_88fc_cdb9c4a00600.slice/cri-containerd-6e8e46290728e4b4efd23299f6406fafeedb20d61bcc011196c67b7c2737940a.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b5d1c29_021d_445b_88fc_cdb9c4a00600.slice/cri-containerd-9db70f7b96320d7f9e0b82e75de0b66d1a0d6afc139605b8eb6525d3cdd71f84.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b193005_f0f6_47f3_9a8f_5634ff4e9205.slice/cri-containerd-a9133650e06e54d6dd0df52b9aaa59ed89d271e4b94f3792a7153c720d0a80e6.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b193005_f0f6_47f3_9a8f_5634ff4e9205.slice/cri-containerd-fdcf17a6de66540fa2971aa8941b09e8fed280a87086359dc2a9dfb2dcd0e42f.scope
    97       cgroup_device   multi                                          
