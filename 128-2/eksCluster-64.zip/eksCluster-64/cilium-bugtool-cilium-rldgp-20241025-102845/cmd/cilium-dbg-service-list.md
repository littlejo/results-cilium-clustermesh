ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.187.77:443 (active)     
                                          2 => 172.31.225.110:443 (active)    
2    10.100.224.209:443    ClusterIP      1 => 172.31.129.220:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.64.0.234:53 (active)        
                                          2 => 10.64.0.104:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.64.0.234:9153 (active)      
                                          2 => 10.64.0.104:9153 (active)      
5    10.100.119.241:2379   ClusterIP      1 => 10.64.0.213:2379 (active)      
