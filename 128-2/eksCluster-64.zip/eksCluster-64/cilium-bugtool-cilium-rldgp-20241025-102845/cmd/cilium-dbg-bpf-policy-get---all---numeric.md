Endpoint ID: 221
Path: /sys/fs/bpf/tc/globals/cilium_policy_00221

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438992   5594      0        
Allow    Ingress     1          ANY          NONE         disabled    10600    124       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1010
Path: /sys/fs/bpf/tc/globals/cilium_policy_01010

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71917   828       0        
Allow    Egress      0          ANY          NONE         disabled    13421   139       0        


Endpoint ID: 1468
Path: /sys/fs/bpf/tc/globals/cilium_policy_01468

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    72115   831       0        
Allow    Egress      0          ANY          NONE         disabled    12247   124       0        


Endpoint ID: 2614
Path: /sys/fs/bpf/tc/globals/cilium_policy_02614

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3896417   36522     0        
Allow    Ingress     1          ANY          NONE         disabled    2991928   30041     0        
Allow    Egress      0          ANY          NONE         disabled    4463690   41374     0        


Endpoint ID: 2954
Path: /sys/fs/bpf/tc/globals/cilium_policy_02954

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


