[
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c7a3f09_2cc4_496a_837c_250ad4c777f8.slice/cri-containerd-6c384b7384d7f8d3015ed7239e7df3f5931360318d04fdc46a133741f50d0e24.scope"
      }
    ],
    "ips": [
      "10.22.0.76"
    ],
    "name": "coredns-cc6ccd49c-s2llk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc747fde8_0b8b_401e_83ee_5ae710bce8c0.slice/cri-containerd-1a69c361a02685b576728df307d3b70a21738046208beed513f7fe9a3e93a028.scope"
      }
    ],
    "ips": [
      "10.22.0.49"
    ],
    "name": "coredns-cc6ccd49c-s6kvs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0b3e241_b824_4a1f_87d0_202591ae218b.slice/cri-containerd-1bbacf16e195bd7cd1d5ccf6c28bef7504fc5a4c1f67d01918070b4bccc8a89a.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0b3e241_b824_4a1f_87d0_202591ae218b.slice/cri-containerd-386498dc60d8b7d1633b0b3f81c24501e920caed13be72a95acaf3c414d3b38b.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0b3e241_b824_4a1f_87d0_202591ae218b.slice/cri-containerd-59d78c63b30dcdbbb2911750fd6ff52d25afa6560a996bfeda4fc1d1fdc7da0a.scope"
      }
    ],
    "ips": [
      "10.22.0.112"
    ],
    "name": "clustermesh-apiserver-77f599fc67-q2d9h",
    "namespace": "kube-system"
  }
]

