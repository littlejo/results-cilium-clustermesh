xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 503
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 483
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 537
lxc1cfc8f2765b5(12) clsact/ingress cil_from_container-lxc1cfc8f2765b5 id 519
lxcd6bb18f1b195(14) clsact/ingress cil_from_container-lxcd6bb18f1b195 id 561
lxc65a0ad07cdff(18) clsact/ingress cil_from_container-lxc65a0ad07cdff id 618

flow_dissector:

netfilter:

