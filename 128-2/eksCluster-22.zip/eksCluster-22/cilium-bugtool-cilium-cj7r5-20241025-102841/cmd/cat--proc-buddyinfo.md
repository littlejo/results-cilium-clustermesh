Node 0, zone      DMA      1     50     17     15      0      2      4      2      2      4    167 
Node 0, zone   Normal    591    176     30     28     25     13      3      2      2      1      7 
