CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c569596_450b_4cda_8c48_c62120bed07f.slice/cri-containerd-3d29442be055ebd8340fac5901d5cf283dd7fa8c059a7ef0eebcaf2095adcc95.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c569596_450b_4cda_8c48_c62120bed07f.slice/cri-containerd-e23829ea60625388f8cfc6bce1e3df487356e8d207cf82dced891ee1f58c402a.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c7a3f09_2cc4_496a_837c_250ad4c777f8.slice/cri-containerd-37710e56a46726cdb61ec42e4a2cb4b1ad9d4a56e267984a4cebc7e4da479494.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c7a3f09_2cc4_496a_837c_250ad4c777f8.slice/cri-containerd-6c384b7384d7f8d3015ed7239e7df3f5931360318d04fdc46a133741f50d0e24.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc747fde8_0b8b_401e_83ee_5ae710bce8c0.slice/cri-containerd-1a69c361a02685b576728df307d3b70a21738046208beed513f7fe9a3e93a028.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc747fde8_0b8b_401e_83ee_5ae710bce8c0.slice/cri-containerd-0ef04f8b764730307a19482bf85fef2db2c0e0b041d0160a02bd39e25370fa53.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod253de3d0_7014_4dbe_b1a4_3edbf6bb3a3f.slice/cri-containerd-d7ee87aefbff0ba84db9fa221d3d9a1bc7ed1a66b3bb333748335aabc03f4230.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod253de3d0_7014_4dbe_b1a4_3edbf6bb3a3f.slice/cri-containerd-48abedf2402afea2d511ab98be6b21e26c3aa238ae199a3f1011bfade9446727.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb895fa6_5ac7_4c95_b126_e83267b1220c.slice/cri-containerd-e14042d670cd782a642005f4f6f0db1b20a3e621741e3ed955c352d138a7f599.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb895fa6_5ac7_4c95_b126_e83267b1220c.slice/cri-containerd-6a40932b651103225eac74cbcb4a26bd5f353474f3f94b4d8b5886dd316f5505.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e4fd325_a058_4780_b87d_42ad9b103d08.slice/cri-containerd-95320f7c6bf67d5763f8cc581322ee37ed1d750db0153d397727558a1700e107.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e4fd325_a058_4780_b87d_42ad9b103d08.slice/cri-containerd-8c194008deba30ee923daa6b0f53eff5804bc1561ad7d60ef9fe4abf1f11a4f7.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0b3e241_b824_4a1f_87d0_202591ae218b.slice/cri-containerd-59d78c63b30dcdbbb2911750fd6ff52d25afa6560a996bfeda4fc1d1fdc7da0a.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0b3e241_b824_4a1f_87d0_202591ae218b.slice/cri-containerd-1bbacf16e195bd7cd1d5ccf6c28bef7504fc5a4c1f67d01918070b4bccc8a89a.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0b3e241_b824_4a1f_87d0_202591ae218b.slice/cri-containerd-ccc78b8f7f52330bce4eef5dbf6c485f26870c785069f5eca08bfbf05282d323.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0b3e241_b824_4a1f_87d0_202591ae218b.slice/cri-containerd-386498dc60d8b7d1633b0b3f81c24501e920caed13be72a95acaf3c414d3b38b.scope
    639      cgroup_device   multi                                          
