IP ADDRESS         LOCAL ENDPOINT INFO
10.22.0.76:0       id=2130  sec_id=1565320 flags=0x0000 ifindex=12  mac=B6:D4:8E:CE:66:DC nodemac=0A:A4:EF:6A:22:6F   
10.22.0.112:0      id=3755  sec_id=1521205 flags=0x0000 ifindex=18  mac=66:40:C7:5D:EF:F1 nodemac=BA:22:87:5C:CD:07   
172.31.180.212:0   (localhost)                                                                                        
10.22.0.49:0       id=86    sec_id=1565320 flags=0x0000 ifindex=14  mac=2A:36:E7:A3:6A:69 nodemac=A6:55:A5:48:A1:B4   
10.22.0.208:0      id=92    sec_id=4     flags=0x0000 ifindex=10  mac=02:2A:02:2E:D5:A7 nodemac=DE:41:93:07:B7:10     
10.22.0.195:0      (localhost)                                                                                        
172.31.168.79:0    (localhost)                                                                                        
