KEY             VALUE
AgentLiveness   911030245346
UTimeOffset     3378615707031250
