Endpoint ID: 39
Path: /sys/fs/bpf/tc/globals/cilium_policy_00039

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 86
Path: /sys/fs/bpf/tc/globals/cilium_policy_00086

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78052   902       0        
Allow    Egress      0          ANY          NONE         disabled    13558   141       0        


Endpoint ID: 92
Path: /sys/fs/bpf/tc/globals/cilium_policy_00092

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    432162   5503      0        
Allow    Ingress     1          ANY          NONE         disabled    11844    140       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2130
Path: /sys/fs/bpf/tc/globals/cilium_policy_02130

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79275   917       0        
Allow    Egress      0          ANY          NONE         disabled    14008   146       0        


Endpoint ID: 3755
Path: /sys/fs/bpf/tc/globals/cilium_policy_03755

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3885313   36221     0        
Allow    Ingress     1          ANY          NONE         disabled    3030803   30495     0        
Allow    Egress      0          ANY          NONE         disabled    4206573   39061     0        


