{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:17.465Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.168.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:17.465Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.180.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:17.465Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:22.022Z",
  "value": "id=92    sec_id=4     flags=0x0000 ifindex=10  mac=02:2A:02:2E:D5:A7 nodemac=DE:41:93:07:B7:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:22.025Z",
  "value": "id=2130  sec_id=1565320 flags=0x0000 ifindex=12  mac=B6:D4:8E:CE:66:DC nodemac=0A:A4:EF:6A:22:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:22.026Z",
  "value": "id=2130  sec_id=1565320 flags=0x0000 ifindex=12  mac=B6:D4:8E:CE:66:DC nodemac=0A:A4:EF:6A:22:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:22.086Z",
  "value": "id=92    sec_id=4     flags=0x0000 ifindex=10  mac=02:2A:02:2E:D5:A7 nodemac=DE:41:93:07:B7:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:28.133Z",
  "value": "id=86    sec_id=1565320 flags=0x0000 ifindex=14  mac=2A:36:E7:A3:6A:69 nodemac=A6:55:A5:48:A1:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.561Z",
  "value": "id=86    sec_id=1565320 flags=0x0000 ifindex=14  mac=2A:36:E7:A3:6A:69 nodemac=A6:55:A5:48:A1:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.563Z",
  "value": "id=92    sec_id=4     flags=0x0000 ifindex=10  mac=02:2A:02:2E:D5:A7 nodemac=DE:41:93:07:B7:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.564Z",
  "value": "id=2130  sec_id=1565320 flags=0x0000 ifindex=12  mac=B6:D4:8E:CE:66:DC nodemac=0A:A4:EF:6A:22:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.610Z",
  "value": "id=525   sec_id=1521205 flags=0x0000 ifindex=16  mac=C6:24:72:60:23:A4 nodemac=FA:60:A0:EB:1D:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.610Z",
  "value": "id=525   sec_id=1521205 flags=0x0000 ifindex=16  mac=C6:24:72:60:23:A4 nodemac=FA:60:A0:EB:1D:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:08.560Z",
  "value": "id=92    sec_id=4     flags=0x0000 ifindex=10  mac=02:2A:02:2E:D5:A7 nodemac=DE:41:93:07:B7:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:08.560Z",
  "value": "id=525   sec_id=1521205 flags=0x0000 ifindex=16  mac=C6:24:72:60:23:A4 nodemac=FA:60:A0:EB:1D:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:08.561Z",
  "value": "id=86    sec_id=1565320 flags=0x0000 ifindex=14  mac=2A:36:E7:A3:6A:69 nodemac=A6:55:A5:48:A1:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:08.561Z",
  "value": "id=2130  sec_id=1565320 flags=0x0000 ifindex=12  mac=B6:D4:8E:CE:66:DC nodemac=0A:A4:EF:6A:22:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:31.046Z",
  "value": "id=3755  sec_id=1521205 flags=0x0000 ifindex=18  mac=66:40:C7:5D:EF:F1 nodemac=BA:22:87:5C:CD:07"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.22.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.393Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.343Z",
  "value": "id=86    sec_id=1565320 flags=0x0000 ifindex=14  mac=2A:36:E7:A3:6A:69 nodemac=A6:55:A5:48:A1:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.344Z",
  "value": "id=3755  sec_id=1521205 flags=0x0000 ifindex=18  mac=66:40:C7:5D:EF:F1 nodemac=BA:22:87:5C:CD:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.345Z",
  "value": "id=92    sec_id=4     flags=0x0000 ifindex=10  mac=02:2A:02:2E:D5:A7 nodemac=DE:41:93:07:B7:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.346Z",
  "value": "id=2130  sec_id=1565320 flags=0x0000 ifindex=12  mac=B6:D4:8E:CE:66:DC nodemac=0A:A4:EF:6A:22:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.334Z",
  "value": "id=3755  sec_id=1521205 flags=0x0000 ifindex=18  mac=66:40:C7:5D:EF:F1 nodemac=BA:22:87:5C:CD:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.334Z",
  "value": "id=86    sec_id=1565320 flags=0x0000 ifindex=14  mac=2A:36:E7:A3:6A:69 nodemac=A6:55:A5:48:A1:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.334Z",
  "value": "id=2130  sec_id=1565320 flags=0x0000 ifindex=12  mac=B6:D4:8E:CE:66:DC nodemac=0A:A4:EF:6A:22:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.335Z",
  "value": "id=92    sec_id=4     flags=0x0000 ifindex=10  mac=02:2A:02:2E:D5:A7 nodemac=DE:41:93:07:B7:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.335Z",
  "value": "id=3755  sec_id=1521205 flags=0x0000 ifindex=18  mac=66:40:C7:5D:EF:F1 nodemac=BA:22:87:5C:CD:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.336Z",
  "value": "id=92    sec_id=4     flags=0x0000 ifindex=10  mac=02:2A:02:2E:D5:A7 nodemac=DE:41:93:07:B7:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.336Z",
  "value": "id=2130  sec_id=1565320 flags=0x0000 ifindex=12  mac=B6:D4:8E:CE:66:DC nodemac=0A:A4:EF:6A:22:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.336Z",
  "value": "id=86    sec_id=1565320 flags=0x0000 ifindex=14  mac=2A:36:E7:A3:6A:69 nodemac=A6:55:A5:48:A1:B4"
}

