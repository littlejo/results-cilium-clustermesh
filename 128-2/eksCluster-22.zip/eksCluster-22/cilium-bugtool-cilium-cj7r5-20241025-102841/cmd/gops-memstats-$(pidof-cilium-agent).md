alloc: 120.65MB (126511760 bytes)
total-alloc: 1.33GB (1429948656 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47768571
frees: 46584248
heap-alloc: 120.65MB (126511760 bytes)
heap-sys: 165.05MB (173064192 bytes)
heap-idle: 25.73MB (26976256 bytes)
heap-in-use: 139.32MB (146087936 bytes)
heap-released: 2.84MB (2973696 bytes)
heap-objects: 1184323
stack-in-use: 34.72MB (36405248 bytes)
stack-sys: 34.72MB (36405248 bytes)
stack-mspan-inuse: 2.16MB (2264800 bytes)
stack-mspan-sys: 2.40MB (2513280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 954.91KB (977825 bytes)
gc-sys: 5.36MB (5622064 bytes)
next-gc: when heap-alloc >= 157.83MB (165497832 bytes)
last-gc: 2024-10-25 10:28:42.682916041 +0000 UTC
gc-pause-total: 15.664356ms
gc-pause: 958321
gc-pause-end: 1729852122682916041
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.00041380706207430086
enable-gc: true
debug-gc: false
