key: 56 00 00 00  value: 28 02 00 00
key: 5c 00 00 00  value: 1b 02 00 00
key: 52 08 00 00  value: 00 02 00 00
key: ab 0e 00 00  value: 6b 02 00 00
Found 4 elements
