 10:28:42 up 14 min,  0 users,  load average: 0.22, 0.26, 0.20
