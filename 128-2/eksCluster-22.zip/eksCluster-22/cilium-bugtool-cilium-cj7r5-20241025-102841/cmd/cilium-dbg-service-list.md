ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.197.111:443 (active)    
                                         2 => 172.31.137.9:443 (active)      
2    10.100.204.24:443    ClusterIP      1 => 172.31.180.212:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.22.0.76:53 (active)         
                                         2 => 10.22.0.49:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.22.0.76:9153 (active)       
                                         2 => 10.22.0.49:9153 (active)       
5    10.100.41.101:2379   ClusterIP      1 => 10.22.0.112:2379 (active)      
