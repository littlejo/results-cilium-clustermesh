[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd88f6cfd_7310_4a05_aa84_439550c3931a.slice/cri-containerd-da9a6dde3c69ace08706ec1b18c368f9cdf40149eec18ea036d09ffad2490fb5.scope"
      }
    ],
    "ips": [
      "10.59.0.13"
    ],
    "name": "coredns-cc6ccd49c-wr6v4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c61f949_cf3a_4af0_80b7_80962d6b346a.slice/cri-containerd-f7547afeb6c67064cdac4034437f87bd5d49d140c9f86270de6505199a7b1994.scope"
      }
    ],
    "ips": [
      "10.59.0.166"
    ],
    "name": "coredns-cc6ccd49c-9vlk2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a814a03_f56f_45ef_be54_d6bf41676ad6.slice/cri-containerd-f9f9bb12d0ff978e93b8d8a1a919369610d338ad192a4bf8f5e5e3547d5ca01c.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a814a03_f56f_45ef_be54_d6bf41676ad6.slice/cri-containerd-e2d93fba7006bf30049e9275c0e4036c3996da430af2aa3a767a87c7a6d5d639.scope"
      },
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a814a03_f56f_45ef_be54_d6bf41676ad6.slice/cri-containerd-93bc1f8b6a6a81cc8147421293d3cba5a2a64769f8c2a1ae336a95ddf185626f.scope"
      }
    ],
    "ips": [
      "10.59.0.181"
    ],
    "name": "clustermesh-apiserver-dc4744d8f-gxsxj",
    "namespace": "kube-system"
  }
]

