REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     209977    84108056   1132   bpf_host.c
Interface                 INGRESS     9485      741789     677    bpf_overlay.c
Success                   EGRESS      4557      348139     1694   bpf_host.c
Success                   EGRESS      88417     11954144   1308   bpf_lxc.c
Success                   EGRESS      9256      725818     53     encap.h
Success                   INGRESS     103385    12507057   235    trace.h
Success                   INGRESS     97808     12069501   86     l3.h
Unsupported L3 protocol   EGRESS      41        3086       1492   bpf_lxc.c
