Endpoint ID: 274
Path: /sys/fs/bpf/tc/globals/cilium_policy_00274

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    440648   5616      0        
Allow    Ingress     1          ANY          NONE         disabled    10584    124       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 904
Path: /sys/fs/bpf/tc/globals/cilium_policy_00904

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68110   781       0        
Allow    Egress      0          ANY          NONE         disabled    12554   128       0        


Endpoint ID: 1526
Path: /sys/fs/bpf/tc/globals/cilium_policy_01526

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3899206   36334     0        
Allow    Ingress     1          ANY          NONE         disabled    2720213   27042     0        
Allow    Egress      0          ANY          NONE         disabled    4237086   39446     0        


Endpoint ID: 1777
Path: /sys/fs/bpf/tc/globals/cilium_policy_01777

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2891
Path: /sys/fs/bpf/tc/globals/cilium_policy_02891

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68233   785       0        
Allow    Egress      0          ANY          NONE         disabled    12266   125       0        


