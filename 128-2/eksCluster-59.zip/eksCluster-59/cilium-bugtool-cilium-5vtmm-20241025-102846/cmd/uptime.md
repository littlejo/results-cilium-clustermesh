 10:28:48 up 13 min,  0 users,  load average: 0.60, 0.38, 0.20
