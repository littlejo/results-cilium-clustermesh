alloc: 94.62MB (99215152 bytes)
total-alloc: 1.30GB (1398517832 bytes)
sys: 206.45MB (216474964 bytes)
lookups: 0
mallocs: 47326498
frees: 46548520
heap-alloc: 94.62MB (99215152 bytes)
heap-sys: 161.23MB (169058304 bytes)
heap-idle: 39.52MB (41435136 bytes)
heap-in-use: 121.71MB (127623168 bytes)
heap-released: 3.55MB (3719168 bytes)
heap-objects: 777978
stack-in-use: 34.75MB (36438016 bytes)
stack-sys: 34.75MB (36438016 bytes)
stack-mspan-inuse: 1.90MB (1991520 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 945.79KB (968489 bytes)
gc-sys: 5.20MB (5454056 bytes)
next-gc: when heap-alloc >= 148.73MB (155958520 bytes)
last-gc: 2024-10-25 10:29:00.999259576 +0000 UTC
gc-pause-total: 9.718812ms
gc-pause: 71155
gc-pause-end: 1729852140999259576
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.00034330507884247456
enable-gc: true
debug-gc: false
