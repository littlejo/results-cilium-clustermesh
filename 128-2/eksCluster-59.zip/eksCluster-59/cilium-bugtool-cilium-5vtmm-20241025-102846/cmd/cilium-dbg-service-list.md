ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.161.245:443 (active)    
                                        2 => 172.31.254.230:443 (active)    
2    10.100.209.84:443   ClusterIP      1 => 172.31.249.105:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.59.0.166:53 (active)        
                                        2 => 10.59.0.13:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.59.0.166:9153 (active)      
                                        2 => 10.59.0.13:9153 (active)       
5    10.100.17.30:2379   ClusterIP      1 => 10.59.0.181:2379 (active)      
