key: 12 01 00 00  value: 24 02 00 00
key: 88 03 00 00  value: 04 02 00 00
key: f6 05 00 00  value: 69 02 00 00
key: 4b 0b 00 00  value: 21 02 00 00
Found 4 elements
