xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(4) clsact/ingress cil_from_netdev-ens6 id 503
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 494
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 488
cilium_host(7) clsact/egress cil_from_host-cilium_host id 485
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 540
lxcf6483ba2457c(12) clsact/ingress cil_from_container-lxcf6483ba2457c id 519
lxc20f17882f70a(14) clsact/ingress cil_from_container-lxc20f17882f70a id 542
lxcf5c61b8728c7(18) clsact/ingress cil_from_container-lxcf5c61b8728c7 id 612

flow_dissector:

netfilter:

