KEY             VALUE
AgentLiveness   821383245008
UTimeOffset     3378615894531250
