Node 0, zone      DMA     78     22      2     32     14     27     34      6      4      2    163 
Node 0, zone   Normal    231     32     16      2     26      1      1      3      1      2      8 
