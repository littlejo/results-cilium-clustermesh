top - 10:28:48 up 13 min,  0 users,  load average: 0.60, 0.38, 0.20
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 43.3 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,    766.1 free,    927.4 used,   2142.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2739.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472560 273104  79024 S  13.3   7.0   0:18.42 cilium-+
    656 root      20   0 1240432  16032  10768 S   6.7   0.4   0:00.03 cilium-+
    415 root      20   0 1228848   6408   3844 S   0.0   0.2   0:00.25 cilium-+
    642 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    655 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    715 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    737 root      20   0 1539912   8400   6332 S   0.0   0.2   0:00.00 runc:[2+
    745 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
