29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:15:43+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:15:43+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:15:43+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:43+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:16:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:17:03+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
479: sched_cls  name tail_handle_ipv4  tag b15ed8a725442e16  gpl
	loaded_at 2024-10-25T10:17:03+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
480: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:17:03+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:17:03+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
482: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 129
483: sched_cls  name tail_handle_ipv4_from_host  tag a13f2e02cfa504a5  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 130
485: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,102
	btf_id 132
487: sched_cls  name __send_drop_notify  tag badf139595e6fc11  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 134
488: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 135
489: sched_cls  name tail_handle_ipv4_from_host  tag a13f2e02cfa504a5  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 137
493: sched_cls  name __send_drop_notify  tag badf139595e6fc11  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 141
494: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 142
495: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 143
498: sched_cls  name __send_drop_notify  tag badf139595e6fc11  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 147
500: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 149
501: sched_cls  name tail_handle_ipv4_from_host  tag a13f2e02cfa504a5  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 150
502: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 151
503: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 153
506: sched_cls  name __send_drop_notify  tag badf139595e6fc11  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 156
508: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 158
509: sched_cls  name tail_handle_ipv4_from_host  tag a13f2e02cfa504a5  gpl
	loaded_at 2024-10-25T10:17:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 159
514: sched_cls  name tail_handle_arp  tag fd06aa64ca6e9ed5  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 166
516: sched_cls  name handle_policy  tag 6bdcaa089b84d915  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 168
517: sched_cls  name __send_drop_notify  tag b39e15ac25358ce9  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 170
518: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 171
519: sched_cls  name cil_from_container  tag d8c883974b6ade4b  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 172
520: sched_cls  name tail_ipv4_ct_ingress  tag e892e9da641f6047  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 173
522: sched_cls  name tail_ipv4_ct_egress  tag ab7537ce2961cffa  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 174
524: sched_cls  name tail_handle_ipv4  tag be0ae30a9677af57  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 176
526: sched_cls  name tail_handle_ipv4_cont  tag 2ab2df0fdb4b2841  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 178
528: sched_cls  name tail_ipv4_to_endpoint  tag 144f610c8d22881b  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 180
532: sched_cls  name tail_handle_ipv4_cont  tag e8840a5d40d83f00  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 184
533: sched_cls  name tail_ipv4_to_endpoint  tag 86238e158b33f4ac  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 186
534: sched_cls  name tail_handle_arp  tag 22bb6f65c1ac004b  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 187
535: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 190
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 191
537: sched_cls  name tail_ipv4_ct_ingress  tag c9f58a2da6ac742a  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 189
538: sched_cls  name tail_handle_ipv4_cont  tag d11d821b6a2f9115  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 192
539: sched_cls  name tail_handle_arp  tag 2b468f15f3dc23f7  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 193
540: sched_cls  name cil_from_container  tag 92fd2a5c8c796f27  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 195
541: sched_cls  name tail_ipv4_ct_egress  tag ab7537ce2961cffa  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 194
542: sched_cls  name cil_from_container  tag b9f4164a82fd0c6c  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 197
543: sched_cls  name tail_handle_ipv4  tag 875638242be2fbe2  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 196
544: sched_cls  name tail_ipv4_ct_ingress  tag 9c9a411b92e1a7e3  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 199
545: sched_cls  name handle_policy  tag b16fa11254273569  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 198
546: sched_cls  name tail_handle_ipv4  tag 61655381d00c3ea6  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 201
548: sched_cls  name handle_policy  tag 3992832a5aea471a  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 200
549: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 203
550: sched_cls  name __send_drop_notify  tag ab6a2b25d954a27e  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
551: sched_cls  name tail_ipv4_to_endpoint  tag c894164ab89a6c14  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 204
553: sched_cls  name __send_drop_notify  tag c50f1023bce1c8f6  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
561: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
562: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
565: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: sched_cls  name tail_ipv4_ct_ingress  tag 65552614f67125e2  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 221
610: sched_cls  name tail_ipv4_ct_egress  tag 95b8ed19114fce62  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 222
611: sched_cls  name tail_ipv4_to_endpoint  tag c2177b91c3587d27  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 223
612: sched_cls  name cil_from_container  tag fa0c81acb985a25d  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 224
614: sched_cls  name tail_handle_ipv4_cont  tag 7a3dfae85f358edd  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 226
615: sched_cls  name tail_handle_arp  tag 00d065fed5d1a27c  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 227
616: sched_cls  name tail_handle_ipv4  tag 8ec84b38dc568dea  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 228
617: sched_cls  name handle_policy  tag 56d23bc3ebb2d1f1  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 229
618: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 230
619: sched_cls  name __send_drop_notify  tag 3e531ea6104e5ffd  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 231
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
