# Cilium debug information

#### Policy get

```
:
 []
Revision: 1

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.59.0.181": (string) (len=49) "kube-system/clustermesh-apiserver-dc4744d8f-gxsxj",
  (string) (len=10) "10.59.0.86": (string) (len=6) "router",
  (string) (len=11) "10.59.0.133": (string) (len=6) "health",
  (string) (len=11) "10.59.0.166": (string) (len=35) "kube-system/coredns-cc6ccd49c-9vlk2",
  (string) (len=10) "10.59.0.13": (string) (len=35) "kube-system/coredns-cc6ccd49c-wr6v4"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.249.105": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x400143e8f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40018dfe00,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40018dfe00,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001827600)(frontends:[10.100.17.30]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x400143ed10)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x400143edc0)(frontends:[10.100.209.84]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x400143ef20)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001827550)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001334380)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4001f50d00)(172.31.161.245:443/TCP,172.31.254.230:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001334388)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-2bsfh": (*k8s.Endpoints)(0x4002cef450)(172.31.249.105:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001334390)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-hp7rc": (*k8s.Endpoints)(0x400277a750)(10.59.0.13:53/TCP[eu-west-3b],10.59.0.13:53/UDP[eu-west-3b],10.59.0.13:9153/TCP[eu-west-3b],10.59.0.166:53/TCP[eu-west-3b],10.59.0.166:53/UDP[eu-west-3b],10.59.0.166:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001a2a950)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-hqpvh": (*k8s.Endpoints)(0x4001f51110)(10.59.0.181:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4002359260)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40006485a0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40042eacc0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001be8ea0,
  gcExited: (chan struct {}) 0x4001be8f00,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4002371a80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001899230)({
      MetricVec: (*prometheus.MetricVec)(0x400188e600)({
       metricMap: (*prometheus.metricMap)(0x400188e630)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40022a4360)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4002371b00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001899238)({
      MetricVec: (*prometheus.MetricVec)(0x400188e690)({
       metricMap: (*prometheus.metricMap)(0x400188e6c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40022a43c0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4002371b80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001899240)({
      MetricVec: (*prometheus.MetricVec)(0x400188e720)({
       metricMap: (*prometheus.metricMap)(0x400188e750)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40022a4420)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4002371c00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001899248)({
      MetricVec: (*prometheus.MetricVec)(0x400188e7b0)({
       metricMap: (*prometheus.metricMap)(0x400188e7e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40022a4480)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4002371c80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001899250)({
      MetricVec: (*prometheus.MetricVec)(0x400188e840)({
       metricMap: (*prometheus.metricMap)(0x400188e870)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40022a44e0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4002371d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001899258)({
      MetricVec: (*prometheus.MetricVec)(0x400188e8d0)({
       metricMap: (*prometheus.metricMap)(0x400188e900)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40022a4540)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4002371d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001899260)({
      MetricVec: (*prometheus.MetricVec)(0x400188e960)({
       metricMap: (*prometheus.metricMap)(0x400188e990)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40022a45a0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4002371e00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001899268)({
      MetricVec: (*prometheus.MetricVec)(0x400188e9f0)({
       metricMap: (*prometheus.metricMap)(0x400188ea20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40022a4600)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4002371e80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001899270)({
      MetricVec: (*prometheus.MetricVec)(0x400188ea80)({
       metricMap: (*prometheus.metricMap)(0x400188eab0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40022a4660)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4002359260)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001940460)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001932978)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 361ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.59.0.0/24, 
Allocated addresses:
  10.59.0.13 (kube-system/coredns-cc6ccd49c-wr6v4)
  10.59.0.133 (health)
  10.59.0.166 (kube-system/coredns-cc6ccd49c-9vlk2)
  10.59.0.181 (kube-system/clustermesh-apiserver-dc4744d8f-gxsxj)
  10.59.0.86 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 54f108139eef80b8
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   16s ago        never        0       no error   
  ct-map-pressure                                                    17s ago        never        0       no error   
  daemon-validate-config                                             5s ago         never        0       no error   
  dns-garbage-collector-job                                          19s ago        never        0       no error   
  endpoint-1526-regeneration-recovery                                never          never        0       no error   
  endpoint-1777-regeneration-recovery                                never          never        0       no error   
  endpoint-274-regeneration-recovery                                 never          never        0       no error   
  endpoint-2891-regeneration-recovery                                never          never        0       no error   
  endpoint-904-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        2m19s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               17s ago        never        0       no error   
  ipcache-inject-labels                                              17s ago        never        0       no error   
  k8s-heartbeat                                                      20s ago        never        0       no error   
  link-cache                                                         2s ago         never        0       no error   
  local-identity-checkpoint                                          12m17s ago     never        0       no error   
  node-neighbor-link-updater                                         7s ago         never        0       no error   
  remote-etcd-cmesh1                                                 5m30s ago      never        0       no error   
  remote-etcd-cmesh10                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh100                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh101                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh102                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh103                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh104                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh105                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh106                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh107                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh108                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh109                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh11                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh110                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh111                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh112                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh113                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh114                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh115                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh116                                               5m31s ago      never        0       no error   
  remote-etcd-cmesh117                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh118                                               5m31s ago      never        0       no error   
  remote-etcd-cmesh119                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh12                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh120                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh121                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh122                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh123                                               5m31s ago      never        0       no error   
  remote-etcd-cmesh124                                               5m31s ago      never        0       no error   
  remote-etcd-cmesh125                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh126                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh127                                               5m31s ago      never        0       no error   
  remote-etcd-cmesh128                                               5m30s ago      never        0       no error   
  remote-etcd-cmesh13                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh14                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh15                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh16                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh17                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh18                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh19                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh2                                                 5m30s ago      never        0       no error   
  remote-etcd-cmesh20                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh21                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh22                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh23                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh24                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh25                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh26                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh27                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh28                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh29                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh3                                                 5m30s ago      never        0       no error   
  remote-etcd-cmesh30                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh31                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh32                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh33                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh34                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh35                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh36                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh37                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh38                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh39                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh4                                                 5m30s ago      never        0       no error   
  remote-etcd-cmesh40                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh41                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh42                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh43                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh44                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh45                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh46                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh47                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh48                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh49                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh5                                                 5m31s ago      never        0       no error   
  remote-etcd-cmesh50                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh51                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh52                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh53                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh54                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh55                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh56                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh57                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh58                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh59                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh6                                                 5m30s ago      never        0       no error   
  remote-etcd-cmesh61                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh62                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh63                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh64                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh65                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh66                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh67                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh68                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh69                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh7                                                 5m30s ago      never        0       no error   
  remote-etcd-cmesh70                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh71                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh72                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh73                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh74                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh75                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh76                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh77                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh78                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh79                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh8                                                 5m30s ago      never        0       no error   
  remote-etcd-cmesh80                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh81                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh82                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh83                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh84                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh85                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh86                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh87                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh88                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh89                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh9                                                 5m30s ago      never        0       no error   
  remote-etcd-cmesh90                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh91                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh92                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh93                                                5m31s ago      never        0       no error   
  remote-etcd-cmesh94                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh95                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh96                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh97                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh98                                                5m30s ago      never        0       no error   
  remote-etcd-cmesh99                                                5m30s ago      never        0       no error   
  resolve-identity-1526                                              1m48s ago      never        0       no error   
  resolve-identity-1777                                              2m17s ago      never        0       no error   
  resolve-identity-274                                               2m16s ago      never        0       no error   
  resolve-identity-2891                                              2m14s ago      never        0       no error   
  resolve-identity-904                                               2m14s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-dc4744d8f-gxsxj   6m48s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-9vlk2                 12m14s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-wr6v4                 12m14s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     12m17s ago     never        0       no error   
  sync-policymap-1526                                                6m48s ago      never        0       no error   
  sync-policymap-1777                                                12m16s ago     never        0       no error   
  sync-policymap-274                                                 12m12s ago     never        0       no error   
  sync-policymap-2891                                                12m12s ago     never        0       no error   
  sync-policymap-904                                                 12m12s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1526)                                  8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2891)                                  4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (904)                                   4s ago         never        0       no error   
  sync-utime                                                         17s ago        never        0       no error   
  write-cni-file                                                     12m20s ago     never        0       no error   
Proxy Status:            OK, ip 10.59.0.86, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3932160, max 3997695
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 81.91   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Service list

```
ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.161.245:443 (active)    
                                        2 => 172.31.254.230:443 (active)    
2    10.100.209.84:443   ClusterIP      1 => 172.31.249.105:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.59.0.166:53 (active)        
                                        2 => 10.59.0.13:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.59.0.166:9153 (active)      
                                        2 => 10.59.0.13:9153 (active)       
5    10.100.17.30:2379   ClusterIP      1 => 10.59.0.181:2379 (active)      
```

#### Cilium environment keys

```
node-port-range:
bpf-lb-dsr-dispatch:opt
bpf-lb-external-clusterip:false
proxy-max-requests-per-connection:0
bpf-lb-acceleration:disabled
http-retry-count:3
hubble-event-queue-size:0
hubble-redact-http-headers-allow:
ipv4-native-routing-cidr:
agent-liveness-update-interval:1s
hubble-redact-enabled:false
disable-iptables-feeder-rules:
tunnel-port:0
cluster-pool-ipv4-mask-size:24
version:false
clustermesh-ip-identities-sync-timeout:1m0s
service-no-backend-response:reject
enable-tracing:false
enable-hubble-recorder-api:true
lib-dir:/var/lib/cilium
enable-policy:default
enable-bgp-control-plane:false
hubble-socket-path:/var/run/cilium/hubble.sock
bpf-lb-affinity-map-max:0
envoy-keep-cap-netbindservice:false
cni-chaining-target:
use-full-tls-context:false
vtep-cidr:
allow-icmp-frag-needed:true
enable-k8s-terminating-endpoint:true
ingress-secrets-namespace:
mesh-auth-gc-interval:5m0s
enable-ipv6-big-tcp:false
identity-change-grace-period:5s
hubble-drop-events-interval:2m0s
bpf-ct-timeout-service-any:1m0s
route-metric:0
kvstore-opt:
enable-cilium-health-api-server-access:
bpf-lb-rss-ipv6-src-cidr:
bpf-node-map-max:16384
l2-announcements-retry-period:2s
bpf-fragments-map-max:8192
k8s-require-ipv4-pod-cidr:false
external-envoy-proxy:true
hubble-export-file-path:
enable-ipip-termination:false
egress-gateway-policy-map-max:16384
ip-masq-agent-config-path:/etc/config/ip-masq-agent
mesh-auth-enabled:true
enable-l2-pod-announcements:false
certificates-directory:/var/run/cilium/certs
enable-ipv6:false
dnsproxy-enable-transparent-mode:true
bpf-lb-service-map-max:0
enable-cilium-endpoint-slice:false
encryption-strict-mode-cidr:
hubble-listen-address::4244
cni-external-routing:false
encryption-strict-mode-allow-remote-node-identities:false
pprof-address:localhost
bpf-ct-timeout-service-tcp-grace:1m0s
enable-hubble:true
wireguard-persistent-keepalive:0s
http-retry-timeout:0
dnsproxy-concurrency-limit:0
enable-ipv6-masquerade:true
hubble-drop-events-reasons:auth_required,policy_denied
allocator-list-timeout:3m0s
http-request-timeout:3600
srv6-encap-mode:reduced
hubble-export-fieldmask:
k8s-kubeconfig-path:
enable-ip-masq-agent:false
k8s-client-connection-keep-alive:30s
enable-ipv6-ndp:false
cluster-name:cmesh60
enable-encryption-strict-mode:false
enable-bandwidth-manager:false
bpf-map-event-buffers:
bpf-lb-sock:false
nat-map-stats-interval:30s
trace-payloadlen:128
proxy-xff-num-trusted-hops-egress:0
k8s-client-connection-timeout:30s
hubble-export-file-compress:false
k8s-namespace:kube-system
endpoint-queue-size:25
enable-tcx:true
l2-announcements-renew-deadline:5s
proxy-prometheus-port:0
clustermesh-enable-mcs-api:false
custom-cni-conf:false
ipam-default-ip-pool:default
cflags:
cni-log-file:/var/run/cilium/cilium-cni.log
cilium-endpoint-gc-interval:5m0s
operator-prometheus-serve-addr::9963
disable-envoy-version-check:false
controller-group-metrics:
dnsproxy-lock-count:131
node-labels:
preallocate-bpf-maps:false
trace-sock:true
hubble-recorder-sink-queue-size:1024
identity-restore-grace-period:30s
enable-session-affinity:false
enable-l2-announcements:false
enable-host-legacy-routing:false
bpf-lb-service-backend-map-max:0
devices:
k8s-client-qps:10
tofqdns-proxy-response-max-delay:100ms
local-router-ipv4:
bgp-announce-lb-ip:false
cni-exclusive:true
conntrack-gc-max-interval:0s
bpf-lb-source-range-map-max:0
bypass-ip-availability-upon-restore:false
bpf-ct-timeout-regular-tcp-syn:1m0s
mtu:0
derive-masq-ip-addr-from-device:
enable-host-port:false
exclude-local-address:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
endpoint-bpf-prog-watchdog-interval:30s
ipv6-range:auto
enable-auto-protect-node-port-range:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-wireguard:false
enable-masquerade-to-route-source:false
config:
bpf-ct-timeout-regular-tcp-fin:10s
enable-svc-source-range-check:true
proxy-xff-num-trusted-hops-ingress:0
k8s-api-server:
nodes-gc-interval:5m0s
set-cilium-is-up-condition:true
envoy-config-retry-interval:15s
hubble-redact-http-userinfo:true
bpf-lb-maglev-map-max:0
disable-endpoint-crd:false
ipv4-service-loopback-address:169.254.42.1
ipv6-node:auto
enable-vtep:false
ipv4-node:auto
state-dir:/var/run/cilium
envoy-config-timeout:2m0s
ipam-cilium-node-update-rate:15s
ipv6-pod-subnets:
dns-policy-unload-on-shutdown:false
ipsec-key-file:
enable-k8s-api-discovery:false
nodeport-addresses:
ipv6-service-range:auto
enable-l7-proxy:true
hubble-monitor-events:
bpf-lb-algorithm:random
remove-cilium-node-taints:true
iptables-random-fully:false
max-controller-interval:0
egress-gateway-reconciliation-trigger-interval:1s
proxy-portrange-max:20000
bpf-map-dynamic-size-ratio:0.0025
enable-local-node-route:true
enable-xdp-prefilter:false
tofqdns-max-deferred-connection-deletes:10000
envoy-secrets-namespace:
k8s-sync-timeout:3m0s
vtep-mask:
crd-wait-timeout:5m0s
dnsproxy-socket-linger-timeout:10
envoy-base-id:0
tofqdns-idle-connection-grace-period:0s
enable-pmtu-discovery:false
proxy-max-connection-duration-seconds:0
enable-ipsec-xfrm-state-caching:true
policy-trigger-interval:1s
debug-verbose:
ipv4-range:auto
tofqdns-enable-dns-compression:true
bpf-events-drop-enabled:true
enable-nat46x64-gateway:false
cmdref:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
ipam:cluster-pool
api-rate-limit:
bpf-ct-timeout-regular-tcp:2h13m20s
enable-unreachable-routes:false
ipsec-key-rotation-duration:5m0s
enable-l2-neigh-discovery:true
bgp-announce-pod-cidr:false
gops-port:9890
kvstore-lease-ttl:15m0s
debug:false
egress-masquerade-interfaces:ens+
bpf-root:/sys/fs/bpf
use-cilium-internal-ip-for-ipsec:false
enable-external-ips:false
vlan-bpf-bypass:
force-device-detection:false
bpf-policy-map-max:16384
enable-recorder:false
enable-identity-mark:true
bpf-ct-global-any-max:262144
enable-health-check-nodeport:true
multicast-enabled:false
enable-wireguard-userspace-fallback:false
tunnel-protocol:vxlan
enable-health-checking:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
procfs:/host/proc
bpf-lb-rss-ipv4-src-cidr:
hubble-skip-unknown-cgroup-ids:true
enable-ipv4-masquerade:true
mesh-auth-rotated-identities-queue-size:1024
hubble-flowlogs-config-path:
operator-api-serve-addr:127.0.0.1:9234
disable-external-ip-mitigation:false
enable-ipsec-key-watcher:true
cluster-pool-ipv4-cidr:10.59.0.0/16
enable-monitor:true
bpf-ct-timeout-service-tcp:2h13m20s
annotate-k8s-node:false
http-max-grpc-timeout:0
l2-pod-announcements-interface:
set-cilium-node-taints:true
max-connected-clusters:255
conntrack-gc-interval:0s
keep-config:false
restore:true
enable-endpoint-health-checking:true
enable-sctp:false
enable-ingress-controller:false
hubble-disable-tls:false
enable-metrics:true
tofqdns-min-ttl:0
policy-accounting:true
pprof-port:6060
agent-labels:
kvstore-max-consecutive-quorum-errors:2
enable-ipsec-encrypted-overlay:false
prepend-iptables-chains:true
enable-icmp-rules:true
bpf-sock-rev-map-max:262144
synchronize-k8s-nodes:true
enable-high-scale-ipcache:false
enable-cilium-api-server-access:
bpf-filter-priority:1
log-driver:
dns-max-ips-per-restored-rule:1000
http-normalize-path:true
install-no-conntrack-iptables-rules:false
encrypt-node:false
enable-k8s-endpoint-slice:true
tofqdns-endpoint-max-ip-per-hostname:50
mesh-auth-spire-admin-socket:
enable-active-connection-tracking:false
socket-path:/var/run/cilium/cilium.sock
tofqdns-proxy-port:0
cluster-health-port:4240
hubble-metrics:
enable-node-port:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
routing-mode:tunnel
identity-allocation-mode:crd
datapath-mode:veth
arping-refresh-period:30s
enable-health-check-loadbalancer-ip:false
enable-well-known-identities:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
label-prefix-file:
monitor-aggregation-flags:all
allow-localhost:auto
mesh-auth-mutual-listener-port:0
bpf-lb-dsr-l4-xlate:frontend
clustermesh-enable-endpoint-sync:false
ipv6-native-routing-cidr:
node-port-algorithm:random
bpf-lb-sock-terminate-pod-connections:false
proxy-idle-timeout-seconds:60
enable-gateway-api:false
node-port-mode:snat
envoy-log:
egress-multi-home-ip-rule-compat:false
bpf-ct-global-tcp-max:524288
identity-heartbeat-timeout:30m0s
enable-bbr:false
enable-k8s-networkpolicy:true
enable-ipv4-egress-gateway:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
identity-gc-interval:15m0s
enable-srv6:false
iptables-lock-timeout:5s
container-ip-local-reserved-ports:auto
k8s-heartbeat-timeout:30s
log-system-load:false
enable-stale-cilium-endpoint-cleanup:true
enable-ipsec:false
enable-runtime-device-detection:true
hubble-export-file-max-backups:5
enable-service-topology:false
ipv4-pod-subnets:
mesh-auth-spiffe-trust-domain:spiffe.cilium
proxy-admin-port:0
labels:
bpf-nat-global-max:524288
fixed-identity-mapping:
kube-proxy-replacement:false
enable-mke:false
dnsproxy-concurrency-processing-grace-period:0s
cni-chaining-mode:none
mesh-auth-queue-size:1024
hubble-export-file-max-size-mb:10
cgroup-root:/run/cilium/cgroupv2
monitor-aggregation:medium
auto-direct-node-routes:false
bpf-lb-map-max:65536
mesh-auth-signal-backoff-duration:1s
hubble-event-buffer-capacity:4095
clustermesh-sync-timeout:1m0s
tofqdns-dns-reject-response-code:refused
hubble-export-allowlist:
vtep-endpoint:
k8s-service-proxy-name:
ipv6-mcast-device:
enable-envoy-config:false
node-port-acceleration:disabled
clustermesh-config:/var/lib/cilium/clustermesh/
hubble-drop-events:false
ipv4-service-range:auto
nat-map-stats-entries:32
hubble-redact-kafka-apikey:false
dnsproxy-insecure-skip-transparent-mode-check:false
monitor-queue-size:0
hubble-prefer-ipv6:false
monitor-aggregation-interval:5s
enable-node-selector-labels:false
gateway-api-secrets-namespace:
bpf-events-trace-enabled:true
hubble-redact-http-urlquery:false
local-max-addr-scope:252
kvstore:
policy-audit-mode:false
http-idle-timeout:0
enable-custom-calls:false
exclude-node-label-patterns:
pprof:false
enable-host-firewall:false
enable-bpf-masquerade:false
enable-xt-socket-fallback:true
read-cni-conf:
enable-k8s:true
ipam-multi-pool-pre-allocation:
hubble-redact-http-headers-deny:
bpf-neigh-global-max:524288
install-iptables-rules:true
cluster-id:60
bpf-ct-timeout-regular-any:1m0s
kvstore-periodic-sync:5m0s
direct-routing-skip-unreachable:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
tofqdns-pre-cache:
mesh-auth-mutual-connect-timeout:5s
endpoint-gc-interval:5m0s
enable-bpf-clock-probe:false
bpf-lb-maglev-table-size:16381
enable-route-mtu-for-cni-chaining:false
bpf-auth-map-max:524288
config-sources:config-map:kube-system/cilium-config
auto-create-cilium-node-resource:true
bpf-lb-sock-hostns-only:false
enable-ipv4-fragment-tracking:true
bpf-lb-rev-nat-map-max:0
bpf-lb-mode:snat
metrics:
k8s-require-ipv6-pod-cidr:false
fqdn-regex-compile-lru-size:1024
join-cluster:false
enable-bpf-tproxy:false
proxy-connect-timeout:2
dnsproxy-lock-timeout:500ms
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
config-dir:/tmp/cilium/config-map
k8s-service-cache-size:128
prometheus-serve-addr:
kvstore-connectivity-timeout:2m0s
local-router-ipv6:
log-opt:
enable-local-redirect-policy:false
enable-ipv4:true
unmanaged-pod-watcher-interval:15
mke-cgroup-mount:
direct-routing-device:
l2-announcements-lease-duration:15s
encrypt-interface:
proxy-gid:1337
static-cnp-path:
agent-health-port:9879
enable-endpoint-routes:false
vtep-mac:
proxy-portrange-min:10000
policy-cidr-match-mode:
policy-queue-size:100
hubble-metrics-server:
ipv6-cluster-alloc-cidr:f00d::/64
bpf-policy-map-full-reconciliation-interval:15m0s
hubble-export-denylist:
k8s-client-burst:20
enable-ipv4-big-tcp:false
node-port-bind-protection:true
bpf-events-policy-verdict-enabled:true
max-internal-timer-delay:0s
kube-proxy-replacement-healthz-bind-address:
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
274        Disabled           Disabled          4          reserved:health                                                                     10.59.0.133   ready   
904        Disabled           Disabled          3937054    k8s:eks.amazonaws.com/component=coredns                                             10.59.0.166   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh60                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1526       Disabled           Disabled          3938435    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.59.0.181   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh60                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1777       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
2891       Disabled           Disabled          3937054    k8s:eks.amazonaws.com/component=coredns                                             10.59.0.13    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh60                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 274

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    436868   5568      0        
Allow    Ingress     1          ANY          NONE         disabled    10584    124       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 274

```
Invalid argument: unknown type 274
```


#### Endpoint Get 274

```
[
  {
    "id": 274,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-274-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "381c05e0-42b8-4072-9c93-67eb06f5aac4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-274",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:03.079Z",
            "success-count": 3
          },
          "uuid": "c7ef3e09-440e-4252-9c25-9db390ca8606"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-274",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:06.519Z",
            "success-count": 1
          },
          "uuid": "bbdf161a-458c-4642-980d-30f99ce068e8"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.59.0.133",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "3a:2c:a1:d6:f2:d8",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "5e:50:24:1c:9a:6d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 274

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 274

```
Timestamp              Status   State                   Message
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:17:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:06Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:17:06Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:17:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:17:03Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:03Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:02Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 904

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68110   781       0        
Allow    Egress      0          ANY          NONE         disabled    12554   128       0        

```


#### BPF CT List 904

```
Invalid argument: unknown type 904
```


#### Endpoint Get 904

```
[
  {
    "id": 904,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-904-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "51d7237f-e654-4bb9-ad88-8ce90b19ee19"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-904",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:04.562Z",
            "success-count": 3
          },
          "uuid": "d4ff850b-1218-4a8d-8c60-eb0a8838c26d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-9vlk2",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:04.561Z",
            "success-count": 1
          },
          "uuid": "b35af737-67f4-4bf9-8825-258635a5c537"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-904",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:06.506Z",
            "success-count": 1
          },
          "uuid": "7b084833-5582-4399-8ca5-99369c97c754"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (904)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.633Z",
            "success-count": 75
          },
          "uuid": "0bd61e75-4d31-4cc4-b349-1fbaa6907004"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "89b49e64dfd676ce2428d22f253a37d780db5d0fa6fc2cd219abf982f5f897d2:eth0",
        "container-id": "89b49e64dfd676ce2428d22f253a37d780db5d0fa6fc2cd219abf982f5f897d2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-9vlk2",
        "pod-name": "kube-system/coredns-cc6ccd49c-9vlk2"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3937054,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh60",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh60",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.59.0.166",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "fa:ad:f4:e5:b1:69",
        "interface-index": 12,
        "interface-name": "lxcf6483ba2457c",
        "mac": "5a:5b:b8:b9:39:c6"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3937054,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3937054,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 904

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 904

```
Timestamp              Status   State                   Message
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:06Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:05Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:17:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:04Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:04Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3937054

```
ID        LABELS
3937054   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh60
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1526

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3897824   36319     0        
Allow    Ingress     1          ANY          NONE         disabled    2673573   26526     0        
Allow    Egress      0          ANY          NONE         disabled    4232302   39391     0        

```


#### BPF CT List 1526

```
Invalid argument: unknown type 1526
```


#### Endpoint Get 1526

```
[
  {
    "id": 1526,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1526-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "87ccbcfb-d368-4837-89a1-36a06a9dda48"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1526",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:30.880Z",
            "success-count": 2
          },
          "uuid": "fd707109-6852-432b-932b-5e143d5c8d79"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-dc4744d8f-gxsxj",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:30.878Z",
            "success-count": 1
          },
          "uuid": "7102df52-cb99-43e0-95d3-91af2efd2d1f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1526",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:30.918Z",
            "success-count": 1
          },
          "uuid": "5287bb02-b18a-49fd-8e4a-46e62789e57b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1526)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.941Z",
            "success-count": 42
          },
          "uuid": "0f280d70-32ab-42c5-bef5-ed3a5e24cd3d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b691a6edb626260a2e5732c0515839471000644b87c0541bd58e31e941728bef:eth0",
        "container-id": "b691a6edb626260a2e5732c0515839471000644b87c0541bd58e31e941728bef",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-dc4744d8f-gxsxj",
        "pod-name": "kube-system/clustermesh-apiserver-dc4744d8f-gxsxj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3938435,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh60",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=dc4744d8f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh60",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.59.0.181",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a6:85:ed:4a:10:20",
        "interface-index": 18,
        "interface-name": "lxcf5c61b8728c7",
        "mac": "16:58:8f:56:c6:ae"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3938435,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3938435,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1526

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1526

```
Timestamp              Status   State                   Message
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:30Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:30Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3938435

```
ID        LABELS
3938435   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh60
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1777

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1777

```
Invalid argument: unknown type 1777
```


#### Endpoint Get 1777

```
[
  {
    "id": 1777,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1777-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ad0f8c06-6b95-42fb-99e4-6965362ce808"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1777",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:02.020Z",
            "success-count": 3
          },
          "uuid": "03d12e51-05aa-4d6e-971b-c6187bed7a80"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1777",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:03.036Z",
            "success-count": 1
          },
          "uuid": "11b214d2-7429-4c70-a09a-6ab14cd93578"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:50Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "7a:65:26:c4:ee:1f",
        "interface-name": "cilium_host",
        "mac": "7a:65:26:c4:ee:1f"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1777

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1777

```
Timestamp              Status   State                   Message
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:17:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:17:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:03Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:17:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:17:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:02Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:02Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:02Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2891

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68233   785       0        
Allow    Egress      0          ANY          NONE         disabled    12266   125       0        

```


#### BPF CT List 2891

```
Invalid argument: unknown type 2891
```


#### Endpoint Get 2891

```
[
  {
    "id": 2891,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2891-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0796ae1b-c273-4d17-8e47-f5244ece1610"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2891",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:04.612Z",
            "success-count": 3
          },
          "uuid": "23273d02-424e-4e25-8956-3ff5a5ef0c6a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-wr6v4",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:04.610Z",
            "success-count": 1
          },
          "uuid": "db8c6c5e-01b6-4cc3-9c5c-31d19695e45b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2891",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:06.559Z",
            "success-count": 1
          },
          "uuid": "5e74f92c-8d0a-496e-8c3a-6607e1f98037"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2891)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.675Z",
            "success-count": 75
          },
          "uuid": "27eeb57f-736e-4a93-9afb-25fdeaa814be"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f58bfafbfff85f421a0cd8c03fe0e54ece77d456bd77139b2f75b0bf97657a5b:eth0",
        "container-id": "f58bfafbfff85f421a0cd8c03fe0e54ece77d456bd77139b2f75b0bf97657a5b",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-wr6v4",
        "pod-name": "kube-system/coredns-cc6ccd49c-wr6v4"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3937054,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh60",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh60",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:50Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.59.0.13",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a6:73:89:a9:f9:a1",
        "interface-index": 14,
        "interface-name": "lxc20f17882f70a",
        "mac": "02:f3:84:6e:8a:da"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3937054,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3937054,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2891

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2891

```
Timestamp              Status   State                   Message
2024-10-25T10:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:50Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:06Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:17:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:04Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:04Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3937054

```
ID        LABELS
3937054   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh60
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33617758                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33617758                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33617758                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c800000 rw-p 00000000 00:00 0 
400c800000-4010000000 ---p 00000000 00:00 0 
ffff774e5000-ffff7771b000 rw-p 00000000 00:00 0 
ffff77723000-ffff77804000 rw-p 00000000 00:00 0 
ffff77804000-ffff77845000 rw-s 00000000 00:0d 30                         anon_inode:[perf_event]
ffff77845000-ffff77886000 rw-s 00000000 00:0d 30                         anon_inode:[perf_event]
ffff77886000-ffff778c6000 rw-p 00000000 00:00 0 
ffff778c6000-ffff778c8000 rw-s 00000000 00:0d 30                         anon_inode:[perf_event]
ffff778c8000-ffff778ca000 rw-s 00000000 00:0d 30                         anon_inode:[perf_event]
ffff778ca000-ffff77e71000 rw-p 00000000 00:00 0 
ffff77e71000-ffff77f71000 rw-p 00000000 00:00 0 
ffff77f71000-ffff77f82000 rw-p 00000000 00:00 0 
ffff77f82000-ffff79f82000 rw-p 00000000 00:00 0 
ffff79f82000-ffff7a002000 ---p 00000000 00:00 0 
ffff7a002000-ffff7a003000 rw-p 00000000 00:00 0 
ffff7a003000-ffff9a002000 ---p 00000000 00:00 0 
ffff9a002000-ffff9a003000 rw-p 00000000 00:00 0 
ffff9a003000-ffffb9f92000 ---p 00000000 00:00 0 
ffffb9f92000-ffffb9f93000 rw-p 00000000 00:00 0 
ffffb9f93000-ffffbdf84000 ---p 00000000 00:00 0 
ffffbdf84000-ffffbdf85000 rw-p 00000000 00:00 0 
ffffbdf85000-ffffbe782000 ---p 00000000 00:00 0 
ffffbe782000-ffffbe783000 rw-p 00000000 00:00 0 
ffffbe783000-ffffbe882000 ---p 00000000 00:00 0 
ffffbe882000-ffffbe8e2000 rw-p 00000000 00:00 0 
ffffbe8e2000-ffffbe8e4000 r--p 00000000 00:00 0                          [vvar]
ffffbe8e4000-ffffbe8e5000 r-xp 00000000 00:00 0                          [vdso]
ffffed621000-ffffed642000 rw-p 00000000 00:00 0                          [stack]

```

