CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c61f949_cf3a_4af0_80b7_80962d6b346a.slice/cri-containerd-f7547afeb6c67064cdac4034437f87bd5d49d140c9f86270de6505199a7b1994.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c61f949_cf3a_4af0_80b7_80962d6b346a.slice/cri-containerd-89b49e64dfd676ce2428d22f253a37d780db5d0fa6fc2cd219abf982f5f897d2.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd88f6cfd_7310_4a05_aa84_439550c3931a.slice/cri-containerd-da9a6dde3c69ace08706ec1b18c368f9cdf40149eec18ea036d09ffad2490fb5.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd88f6cfd_7310_4a05_aa84_439550c3931a.slice/cri-containerd-f58bfafbfff85f421a0cd8c03fe0e54ece77d456bd77139b2f75b0bf97657a5b.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb11a24f_313a_4ecb_8aae_68b9b28c0531.slice/cri-containerd-9975ebc3cdd06a98807bf75437d02f2505da385fb64133af9356e2367f87c5df.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb11a24f_313a_4ecb_8aae_68b9b28c0531.slice/cri-containerd-0f11626e1266d8bef4a8bffd1c7838d1e506a3811ff729d4ba02b9f34fbd7aeb.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcaae10c3_19d5_48c7_a0de_53b65546b682.slice/cri-containerd-301a28486cb047365771393bc680cc5ab420b9467dc88340b8991856bae47ce2.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcaae10c3_19d5_48c7_a0de_53b65546b682.slice/cri-containerd-29ec1db33d525c75ffb780f0c97aa2465bb515832e6f44f0f7658a595800672d.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb0e09fb4_1e80_4c94_9437_f6bab6c6fbfb.slice/cri-containerd-88947f746b87da6900293dc4f19fc9628f06fb287b06b678926319b5acf6a62a.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb0e09fb4_1e80_4c94_9437_f6bab6c6fbfb.slice/cri-containerd-85184de6dd9d99f3316ef903d70ba4d2b4b94560b4544dcb41b58e66a80d8ecb.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0213082_dbaf_44a6_9442_789f7b7da5e4.slice/cri-containerd-a69add2fd8f24ad4c598d41c79e8a11d1718fa828f5a310a6e21c9286677a74f.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0213082_dbaf_44a6_9442_789f7b7da5e4.slice/cri-containerd-c487a21ac825a906beed4d390226902b06741295a3618f7466f0478e5dd0066c.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a814a03_f56f_45ef_be54_d6bf41676ad6.slice/cri-containerd-93bc1f8b6a6a81cc8147421293d3cba5a2a64769f8c2a1ae336a95ddf185626f.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a814a03_f56f_45ef_be54_d6bf41676ad6.slice/cri-containerd-e2d93fba7006bf30049e9275c0e4036c3996da430af2aa3a767a87c7a6d5d639.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a814a03_f56f_45ef_be54_d6bf41676ad6.slice/cri-containerd-f9f9bb12d0ff978e93b8d8a1a919369610d338ad192a4bf8f5e5e3547d5ca01c.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a814a03_f56f_45ef_be54_d6bf41676ad6.slice/cri-containerd-b691a6edb626260a2e5732c0515839471000644b87c0541bd58e31e941728bef.scope
    623      cgroup_device   multi                                          
