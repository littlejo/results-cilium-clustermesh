USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         656  0.0  0.4 1240432 16032 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         698  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         699  0.0  0.4 1240432 16032 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         655  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         642  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.5  6.9 1472560 273104 ?      Ssl  10:16   0:18 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.1 1228848 6408 ?        Sl   10:17   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
