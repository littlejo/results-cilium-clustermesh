IP ADDRESS         LOCAL ENDPOINT INFO
10.59.0.166:0      id=904   sec_id=3937054 flags=0x0000 ifindex=12  mac=5A:5B:B8:B9:39:C6 nodemac=FA:AD:F4:E5:B1:69   
172.31.249.105:0   (localhost)                                                                                        
10.59.0.181:0      id=1526  sec_id=3938435 flags=0x0000 ifindex=18  mac=16:58:8F:56:C6:AE nodemac=A6:85:ED:4A:10:20   
10.59.0.13:0       id=2891  sec_id=3937054 flags=0x0000 ifindex=14  mac=02:F3:84:6E:8A:DA nodemac=A6:73:89:A9:F9:A1   
10.59.0.86:0       (localhost)                                                                                        
10.59.0.133:0      id=274   sec_id=4     flags=0x0000 ifindex=10  mac=5E:50:24:1C:9A:6D nodemac=3A:2C:A1:D6:F2:D8     
172.31.252.46:0    (localhost)                                                                                        
