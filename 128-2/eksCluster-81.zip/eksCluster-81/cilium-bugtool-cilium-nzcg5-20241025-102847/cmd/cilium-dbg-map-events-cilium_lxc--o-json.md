{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:58.329Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.195.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:58.329Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.229.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:58.329Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.892Z",
  "value": "id=3680  sec_id=4     flags=0x0000 ifindex=10  mac=FE:A9:CA:E4:F1:66 nodemac=EA:A7:22:53:E7:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.899Z",
  "value": "id=506   sec_id=5395910 flags=0x0000 ifindex=12  mac=E6:FD:87:E5:11:7D nodemac=3E:00:95:25:23:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.969Z",
  "value": "id=42    sec_id=5395910 flags=0x0000 ifindex=14  mac=EE:DC:A5:1B:63:41 nodemac=2A:1B:A1:B3:2C:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.053Z",
  "value": "id=3680  sec_id=4     flags=0x0000 ifindex=10  mac=FE:A9:CA:E4:F1:66 nodemac=EA:A7:22:53:E7:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.095Z",
  "value": "id=506   sec_id=5395910 flags=0x0000 ifindex=12  mac=E6:FD:87:E5:11:7D nodemac=3E:00:95:25:23:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:14.820Z",
  "value": "id=3680  sec_id=4     flags=0x0000 ifindex=10  mac=FE:A9:CA:E4:F1:66 nodemac=EA:A7:22:53:E7:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:14.820Z",
  "value": "id=506   sec_id=5395910 flags=0x0000 ifindex=12  mac=E6:FD:87:E5:11:7D nodemac=3E:00:95:25:23:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:14.821Z",
  "value": "id=42    sec_id=5395910 flags=0x0000 ifindex=14  mac=EE:DC:A5:1B:63:41 nodemac=2A:1B:A1:B3:2C:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:14.849Z",
  "value": "id=1901  sec_id=5379799 flags=0x0000 ifindex=16  mac=66:59:10:02:01:19 nodemac=B2:A8:3E:9A:F2:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:15.820Z",
  "value": "id=506   sec_id=5395910 flags=0x0000 ifindex=12  mac=E6:FD:87:E5:11:7D nodemac=3E:00:95:25:23:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:15.820Z",
  "value": "id=3680  sec_id=4     flags=0x0000 ifindex=10  mac=FE:A9:CA:E4:F1:66 nodemac=EA:A7:22:53:E7:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:15.821Z",
  "value": "id=1901  sec_id=5379799 flags=0x0000 ifindex=16  mac=66:59:10:02:01:19 nodemac=B2:A8:3E:9A:F2:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:15.821Z",
  "value": "id=42    sec_id=5395910 flags=0x0000 ifindex=14  mac=EE:DC:A5:1B:63:41 nodemac=2A:1B:A1:B3:2C:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:49.428Z",
  "value": "id=1504  sec_id=5379799 flags=0x0000 ifindex=18  mac=5E:98:78:57:50:03 nodemac=92:5A:68:61:E9:D7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.81.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.855Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.936Z",
  "value": "id=1504  sec_id=5379799 flags=0x0000 ifindex=18  mac=5E:98:78:57:50:03 nodemac=92:5A:68:61:E9:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.940Z",
  "value": "id=3680  sec_id=4     flags=0x0000 ifindex=10  mac=FE:A9:CA:E4:F1:66 nodemac=EA:A7:22:53:E7:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.941Z",
  "value": "id=506   sec_id=5395910 flags=0x0000 ifindex=12  mac=E6:FD:87:E5:11:7D nodemac=3E:00:95:25:23:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.941Z",
  "value": "id=42    sec_id=5395910 flags=0x0000 ifindex=14  mac=EE:DC:A5:1B:63:41 nodemac=2A:1B:A1:B3:2C:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.003Z",
  "value": "id=1504  sec_id=5379799 flags=0x0000 ifindex=18  mac=5E:98:78:57:50:03 nodemac=92:5A:68:61:E9:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.005Z",
  "value": "id=3680  sec_id=4     flags=0x0000 ifindex=10  mac=FE:A9:CA:E4:F1:66 nodemac=EA:A7:22:53:E7:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.005Z",
  "value": "id=506   sec_id=5395910 flags=0x0000 ifindex=12  mac=E6:FD:87:E5:11:7D nodemac=3E:00:95:25:23:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.006Z",
  "value": "id=42    sec_id=5395910 flags=0x0000 ifindex=14  mac=EE:DC:A5:1B:63:41 nodemac=2A:1B:A1:B3:2C:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.937Z",
  "value": "id=1504  sec_id=5379799 flags=0x0000 ifindex=18  mac=5E:98:78:57:50:03 nodemac=92:5A:68:61:E9:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.937Z",
  "value": "id=3680  sec_id=4     flags=0x0000 ifindex=10  mac=FE:A9:CA:E4:F1:66 nodemac=EA:A7:22:53:E7:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.938Z",
  "value": "id=506   sec_id=5395910 flags=0x0000 ifindex=12  mac=E6:FD:87:E5:11:7D nodemac=3E:00:95:25:23:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.938Z",
  "value": "id=42    sec_id=5395910 flags=0x0000 ifindex=14  mac=EE:DC:A5:1B:63:41 nodemac=2A:1B:A1:B3:2C:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.937Z",
  "value": "id=1504  sec_id=5379799 flags=0x0000 ifindex=18  mac=5E:98:78:57:50:03 nodemac=92:5A:68:61:E9:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.937Z",
  "value": "id=506   sec_id=5395910 flags=0x0000 ifindex=12  mac=E6:FD:87:E5:11:7D nodemac=3E:00:95:25:23:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.938Z",
  "value": "id=42    sec_id=5395910 flags=0x0000 ifindex=14  mac=EE:DC:A5:1B:63:41 nodemac=2A:1B:A1:B3:2C:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.938Z",
  "value": "id=3680  sec_id=4     flags=0x0000 ifindex=10  mac=FE:A9:CA:E4:F1:66 nodemac=EA:A7:22:53:E7:49"
}

