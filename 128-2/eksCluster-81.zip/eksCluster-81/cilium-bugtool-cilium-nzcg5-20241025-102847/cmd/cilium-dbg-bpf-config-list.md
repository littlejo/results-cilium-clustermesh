KEY             VALUE
AgentLiveness   834887728660
UTimeOffset     3378615871093750
