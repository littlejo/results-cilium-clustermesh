Endpoint ID: 42
Path: /sys/fs/bpf/tc/globals/cilium_policy_00042

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69511   803       0        
Allow    Egress      0          ANY          NONE         disabled    12923   132       0        


Endpoint ID: 334
Path: /sys/fs/bpf/tc/globals/cilium_policy_00334

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 506
Path: /sys/fs/bpf/tc/globals/cilium_policy_00506

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69533   799       0        
Allow    Egress      0          ANY          NONE         disabled    12726   130       0        


Endpoint ID: 1504
Path: /sys/fs/bpf/tc/globals/cilium_policy_01504

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3995773   36863     0        
Allow    Ingress     1          ANY          NONE         disabled    3099378   31285     0        
Allow    Egress      0          ANY          NONE         disabled    3928808   36704     0        


Endpoint ID: 3680
Path: /sys/fs/bpf/tc/globals/cilium_policy_03680

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    446906   5718      0        
Allow    Ingress     1          ANY          NONE         disabled    10642    125       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


