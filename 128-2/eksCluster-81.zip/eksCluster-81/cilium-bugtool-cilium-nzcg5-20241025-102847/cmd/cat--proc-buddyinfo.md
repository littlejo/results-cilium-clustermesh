Node 0, zone      DMA      4     33      3      5      6      4      3      3      3      5    167 
Node 0, zone   Normal      3      1      2     18     21      5      2      2      2      2      8 
