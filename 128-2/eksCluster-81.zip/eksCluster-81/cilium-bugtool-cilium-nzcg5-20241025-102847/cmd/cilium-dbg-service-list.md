ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.212.220:443 (active)    
                                         2 => 172.31.166.40:443 (active)     
2    10.100.94.228:443    ClusterIP      1 => 172.31.195.150:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.81.0.9:53 (active)          
                                         2 => 10.81.0.144:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.81.0.9:9153 (active)        
                                         2 => 10.81.0.144:9153 (active)      
5    10.100.128.30:2379   ClusterIP      1 => 10.81.0.83:2379 (active)       
