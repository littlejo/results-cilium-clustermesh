alloc: 125.05MB (131123720 bytes)
total-alloc: 1.33GB (1430083656 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47782149
frees: 46504041
heap-alloc: 125.05MB (131123720 bytes)
heap-sys: 165.29MB (173318144 bytes)
heap-idle: 21.61MB (22659072 bytes)
heap-in-use: 143.68MB (150659072 bytes)
heap-released: 2.52MB (2646016 bytes)
heap-objects: 1278108
stack-in-use: 34.69MB (36372480 bytes)
stack-sys: 34.69MB (36372480 bytes)
stack-mspan-inuse: 2.27MB (2376000 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 891.19KB (912577 bytes)
gc-sys: 5.19MB (5439984 bytes)
next-gc: when heap-alloc >= 160.23MB (168014920 bytes)
last-gc: 2024-10-25 10:28:50.248976687 +0000 UTC
gc-pause-total: 13.161574ms
gc-pause: 3898834
gc-pause-end: 1729852130248976687
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.00048761660410515014
enable-gc: true
debug-gc: false
