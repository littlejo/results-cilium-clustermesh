markdown output at /tmp/cilium-bugtool-20241025-102850.177+0000-UTC-1700633005/cmd/cilium-debuginfo-20241025-102920.723+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102850.177+0000-UTC-1700633005/cmd/cilium-debuginfo-20241025-102920.723+0000-UTC.json
