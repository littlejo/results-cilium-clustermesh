USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         707  0.0  0.2 1539912 8352 ?        Ssl  10:28   0:00 /usr/sbin/runc init
root         689  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         677  0.0  0.4 1240432 16064 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         712  0.0  0.0   1748     4 ?        R    10:28   0:00  \_ bash -c cat /proc/net/xfrm_stat
root         713  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root           1  3.0  7.2 1538100 286656 ?      Ssl  10:16   0:21 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.1 1228848 5904 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
