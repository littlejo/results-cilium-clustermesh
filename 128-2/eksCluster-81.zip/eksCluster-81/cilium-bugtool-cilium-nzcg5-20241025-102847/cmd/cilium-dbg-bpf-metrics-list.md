REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10263     802896     677    bpf_overlay.c
Interface                 INGRESS     218030    84407190   1132   bpf_host.c
Success                   EGRESS      10390     813436     53     encap.h
Success                   EGRESS      5210      401162     1694   bpf_host.c
Success                   EGRESS      91812     12578612   1308   bpf_lxc.c
Success                   INGRESS     102571    12471870   86     l3.h
Success                   INGRESS     108273    12917510   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
