CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f51e967_f9fe_4a98_8cd9_bbf0d05b2b95.slice/cri-containerd-158437436e9cd70187e013f317106a3f370549b3f31d2974d539bff481492647.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f51e967_f9fe_4a98_8cd9_bbf0d05b2b95.slice/cri-containerd-b91524e3662815a1165f31e657b86a0644345cac8574d2a46922f18ffdcc9768.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod91557c6d_ec5f_4fa3_9302_53ffd0c513ab.slice/cri-containerd-9ac5da445c2bad13b55073c4c58950b0fc66810c5bd84208e6cc33f791e0ed33.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod91557c6d_ec5f_4fa3_9302_53ffd0c513ab.slice/cri-containerd-bc03d6d13d12f262c759a5276d8a5d4e39665afd7e1d16b1f09bd716499c0e14.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba60bdbf_3123_4eab_9b3c_ba4a0680930f.slice/cri-containerd-3fea4b20bc74c7ddf2c9edc1330dedf53f1a11f1083174d105fbef222d39e153.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba60bdbf_3123_4eab_9b3c_ba4a0680930f.slice/cri-containerd-883156ecdd645374cf1b535d81324d15b27c69ed337a27bc751967a6e114f077.scope
    525      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddbdc9e5a_ce60_4bfb_80ef_b1735b16d453.slice/cri-containerd-f5ff6344985607e241c4c9a43bca9ecf540e5e8d30ed06fa362e51c02693a905.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddbdc9e5a_ce60_4bfb_80ef_b1735b16d453.slice/cri-containerd-be51ed0d2879eacd1bf0101aa475bbb29b3284500044b54eeb93aad2620cb61b.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb27d018a_b8dc_44f6_86dc_21dd9d28d163.slice/cri-containerd-1a1bbe7e4f44872e85de38a3ac9283c5508566263ed6749823ef09894931e89a.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb27d018a_b8dc_44f6_86dc_21dd9d28d163.slice/cri-containerd-58599e302adc107231bcdba2f19884a8486f8edb7b3dd146ffefd49d01e4f1f3.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0f35835_b0e5_4127_ae89_d7ed83c59bdc.slice/cri-containerd-fd1da33265c5de20774ca34f4ad2872297244ccc880c457059224be528dd11cd.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0f35835_b0e5_4127_ae89_d7ed83c59bdc.slice/cri-containerd-94a64c3a7e610eb4f11914eda1430bd87ab3f5d066d286292986e55d66819e26.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6db45a16_e212_443d_8d60_c4135e447cad.slice/cri-containerd-0c2cfb9cc96c1c5e61febbb222edd345b7f476843ac15b99d17dbd59a23e4451.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6db45a16_e212_443d_8d60_c4135e447cad.slice/cri-containerd-f72d211487a5eb9bcad27bfa6034d6e7b4aa547f39424fd5211b7bc2e23a0c87.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6db45a16_e212_443d_8d60_c4135e447cad.slice/cri-containerd-b71551189e1eef478bbf5f784329b894860a2613f1c8a81120b864ec96aa20d5.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6db45a16_e212_443d_8d60_c4135e447cad.slice/cri-containerd-9f14d641b345f430658faaf6403feef043a3bc26f7c8a816bc5ecfaa9f7a760f.scope
    634      cgroup_device   multi                                          
