[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba60bdbf_3123_4eab_9b3c_ba4a0680930f.slice/cri-containerd-3fea4b20bc74c7ddf2c9edc1330dedf53f1a11f1083174d105fbef222d39e153.scope"
      }
    ],
    "ips": [
      "10.81.0.144"
    ],
    "name": "coredns-cc6ccd49c-5frf9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6db45a16_e212_443d_8d60_c4135e447cad.slice/cri-containerd-b71551189e1eef478bbf5f784329b894860a2613f1c8a81120b864ec96aa20d5.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6db45a16_e212_443d_8d60_c4135e447cad.slice/cri-containerd-0c2cfb9cc96c1c5e61febbb222edd345b7f476843ac15b99d17dbd59a23e4451.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6db45a16_e212_443d_8d60_c4135e447cad.slice/cri-containerd-f72d211487a5eb9bcad27bfa6034d6e7b4aa547f39424fd5211b7bc2e23a0c87.scope"
      }
    ],
    "ips": [
      "10.81.0.83"
    ],
    "name": "clustermesh-apiserver-5fb4d4b8cf-qfb8f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f51e967_f9fe_4a98_8cd9_bbf0d05b2b95.slice/cri-containerd-b91524e3662815a1165f31e657b86a0644345cac8574d2a46922f18ffdcc9768.scope"
      }
    ],
    "ips": [
      "10.81.0.9"
    ],
    "name": "coredns-cc6ccd49c-944g5",
    "namespace": "kube-system"
  }
]

