IP ADDRESS         LOCAL ENDPOINT INFO
172.31.195.150:0   (localhost)                                                                                        
10.81.0.83:0       id=1504  sec_id=5379799 flags=0x0000 ifindex=18  mac=5E:98:78:57:50:03 nodemac=92:5A:68:61:E9:D7   
10.81.0.9:0        id=42    sec_id=5395910 flags=0x0000 ifindex=14  mac=EE:DC:A5:1B:63:41 nodemac=2A:1B:A1:B3:2C:5F   
10.81.0.5:0        (localhost)                                                                                        
10.81.0.31:0       id=3680  sec_id=4     flags=0x0000 ifindex=10  mac=FE:A9:CA:E4:F1:66 nodemac=EA:A7:22:53:E7:49     
10.81.0.144:0      id=506   sec_id=5395910 flags=0x0000 ifindex=12  mac=E6:FD:87:E5:11:7D nodemac=3E:00:95:25:23:1F   
172.31.229.110:0   (localhost)                                                                                        
