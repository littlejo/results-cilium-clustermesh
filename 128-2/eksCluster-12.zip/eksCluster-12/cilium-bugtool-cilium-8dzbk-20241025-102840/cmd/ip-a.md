1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:69:63:4d:8b:91 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.170.139/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2736sec preferred_lft 2736sec
    inet6 fe80::469:63ff:fe4d:8b91/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a7:66:4a:8b:a9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.187.14/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a7:66ff:fe4a:8ba9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:53:0b:35:e0:16 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b853:bff:fe35:e016/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:85:2b:a5:fe:22 brd ff:ff:ff:ff:ff:ff
    inet 10.12.0.155/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4885:2bff:fea5:fe22/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:49:59:ef:63:87 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f449:59ff:feef:6387/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:b1:08:a2:27:6b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1cb1:8ff:fea2:276b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc15b60397c3c6@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:64:d5:61:2e:dc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3064:d5ff:fe61:2edc/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf2c28a5dcc6b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:03:d3:3e:dd:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::b403:d3ff:fe3e:ddc7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4b3c9c7b882b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:d5:42:3f:89:c5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::44d5:42ff:fe3f:89c5/64 scope link 
       valid_lft forever preferred_lft forever
