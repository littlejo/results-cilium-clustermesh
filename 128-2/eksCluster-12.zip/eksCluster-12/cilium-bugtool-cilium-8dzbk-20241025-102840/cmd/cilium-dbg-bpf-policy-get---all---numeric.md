Endpoint ID: 24
Path: /sys/fs/bpf/tc/globals/cilium_policy_00024

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77419   890       0        
Allow    Egress      0          ANY          NONE         disabled    13885   144       0        


Endpoint ID: 870
Path: /sys/fs/bpf/tc/globals/cilium_policy_00870

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    429404   5470      0        
Allow    Ingress     1          ANY          NONE         disabled    11374    133       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1920
Path: /sys/fs/bpf/tc/globals/cilium_policy_01920

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3850719   36045     0        
Allow    Ingress     1          ANY          NONE         disabled    3057904   30827     0        
Allow    Egress      0          ANY          NONE         disabled    4429625   41001     0        


Endpoint ID: 1990
Path: /sys/fs/bpf/tc/globals/cilium_policy_01990

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2188
Path: /sys/fs/bpf/tc/globals/cilium_policy_02188

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76829   887       0        
Allow    Egress      0          ANY          NONE         disabled    13214   136       0        


