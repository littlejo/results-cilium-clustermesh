[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04c98ebc_d8d7_420c_9f8b_9b878246f9cf.slice/cri-containerd-ed5ecfebdb133b63ca4d5f801930345aac92924157df0a68dbfbb3d8161ed265.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04c98ebc_d8d7_420c_9f8b_9b878246f9cf.slice/cri-containerd-05b5ec151e2cbd1e07fc4af64ff85190f14db6ae07d5da89e8a441ed806228fd.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04c98ebc_d8d7_420c_9f8b_9b878246f9cf.slice/cri-containerd-1800cff21b9afac0e1aca65995fd011ad4f2de9b1f066cb484694046f87362c7.scope"
      }
    ],
    "ips": [
      "10.12.0.4"
    ],
    "name": "clustermesh-apiserver-6b868d67c9-dx5s9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod166b2e40_17fd_454e_8ee9_ab2f23e31368.slice/cri-containerd-696151a935d1c211aff7739567dbb897c8954ff2761b33265dbf952e5e6379f8.scope"
      }
    ],
    "ips": [
      "10.12.0.124"
    ],
    "name": "coredns-cc6ccd49c-pb6zr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod039b367f_6f48_49d3_a741_893660630c01.slice/cri-containerd-5cc4eb25f6ee41dda63ae6c482ee7181a86ea1014f8e2f6b7b15ece54dc13f59.scope"
      }
    ],
    "ips": [
      "10.12.0.59"
    ],
    "name": "coredns-cc6ccd49c-7khkd",
    "namespace": "kube-system"
  }
]

