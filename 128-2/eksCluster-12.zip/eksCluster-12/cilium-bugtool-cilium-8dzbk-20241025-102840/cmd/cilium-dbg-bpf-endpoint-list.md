IP ADDRESS         LOCAL ENDPOINT INFO
10.12.0.4:0        id=1920  sec_id=899644 flags=0x0000 ifindex=18  mac=6A:20:E8:64:6F:6C nodemac=46:D5:42:3F:89:C5   
10.12.0.59:0       id=2188  sec_id=905284 flags=0x0000 ifindex=14  mac=2E:A7:3A:48:AD:D9 nodemac=B6:03:D3:3E:DD:C7   
10.12.0.142:0      id=870   sec_id=4     flags=0x0000 ifindex=10  mac=3E:A9:A4:D9:88:77 nodemac=1E:B1:08:A2:27:6B    
172.31.170.139:0   (localhost)                                                                                       
10.12.0.155:0      (localhost)                                                                                       
10.12.0.124:0      id=24    sec_id=905284 flags=0x0000 ifindex=12  mac=4A:77:6E:79:D9:01 nodemac=32:64:D5:61:2E:DC   
172.31.187.14:0    (localhost)                                                                                       
