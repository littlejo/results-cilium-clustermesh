KEY             VALUE
AgentLiveness   904254761094
UTimeOffset     3378615718750000
