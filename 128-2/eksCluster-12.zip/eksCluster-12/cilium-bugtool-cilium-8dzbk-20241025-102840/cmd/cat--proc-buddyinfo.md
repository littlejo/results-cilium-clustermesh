Node 0, zone      DMA     65     10      4      5      1      7      7      4      0      4    168 
Node 0, zone   Normal    469     67      8      0     12      8      9      5      3      1      7 
