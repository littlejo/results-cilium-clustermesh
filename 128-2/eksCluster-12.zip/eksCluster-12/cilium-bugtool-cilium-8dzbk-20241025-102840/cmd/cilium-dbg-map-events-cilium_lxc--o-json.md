{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.701Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.170.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.701Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.187.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.701Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.237Z",
  "value": "id=870   sec_id=4     flags=0x0000 ifindex=10  mac=3E:A9:A4:D9:88:77 nodemac=1E:B1:08:A2:27:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.244Z",
  "value": "id=24    sec_id=905284 flags=0x0000 ifindex=12  mac=4A:77:6E:79:D9:01 nodemac=32:64:D5:61:2E:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.245Z",
  "value": "id=24    sec_id=905284 flags=0x0000 ifindex=12  mac=4A:77:6E:79:D9:01 nodemac=32:64:D5:61:2E:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.271Z",
  "value": "id=870   sec_id=4     flags=0x0000 ifindex=10  mac=3E:A9:A4:D9:88:77 nodemac=1E:B1:08:A2:27:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:36.010Z",
  "value": "id=2188  sec_id=905284 flags=0x0000 ifindex=14  mac=2E:A7:3A:48:AD:D9 nodemac=B6:03:D3:3E:DD:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.120Z",
  "value": "id=870   sec_id=4     flags=0x0000 ifindex=10  mac=3E:A9:A4:D9:88:77 nodemac=1E:B1:08:A2:27:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.122Z",
  "value": "id=24    sec_id=905284 flags=0x0000 ifindex=12  mac=4A:77:6E:79:D9:01 nodemac=32:64:D5:61:2E:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.122Z",
  "value": "id=2188  sec_id=905284 flags=0x0000 ifindex=14  mac=2E:A7:3A:48:AD:D9 nodemac=B6:03:D3:3E:DD:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.151Z",
  "value": "id=629   sec_id=899644 flags=0x0000 ifindex=16  mac=3A:3B:D3:3D:2E:E7 nodemac=26:01:9D:96:CB:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.120Z",
  "value": "id=870   sec_id=4     flags=0x0000 ifindex=10  mac=3E:A9:A4:D9:88:77 nodemac=1E:B1:08:A2:27:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.120Z",
  "value": "id=629   sec_id=899644 flags=0x0000 ifindex=16  mac=3A:3B:D3:3D:2E:E7 nodemac=26:01:9D:96:CB:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.121Z",
  "value": "id=24    sec_id=905284 flags=0x0000 ifindex=12  mac=4A:77:6E:79:D9:01 nodemac=32:64:D5:61:2E:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.121Z",
  "value": "id=2188  sec_id=905284 flags=0x0000 ifindex=14  mac=2E:A7:3A:48:AD:D9 nodemac=B6:03:D3:3E:DD:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.538Z",
  "value": "id=1920  sec_id=899644 flags=0x0000 ifindex=18  mac=6A:20:E8:64:6F:6C nodemac=46:D5:42:3F:89:C5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.12.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:26.838Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:44.421Z",
  "value": "id=2188  sec_id=905284 flags=0x0000 ifindex=14  mac=2E:A7:3A:48:AD:D9 nodemac=B6:03:D3:3E:DD:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:44.421Z",
  "value": "id=1920  sec_id=899644 flags=0x0000 ifindex=18  mac=6A:20:E8:64:6F:6C nodemac=46:D5:42:3F:89:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:44.422Z",
  "value": "id=870   sec_id=4     flags=0x0000 ifindex=10  mac=3E:A9:A4:D9:88:77 nodemac=1E:B1:08:A2:27:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:44.422Z",
  "value": "id=24    sec_id=905284 flags=0x0000 ifindex=12  mac=4A:77:6E:79:D9:01 nodemac=32:64:D5:61:2E:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.422Z",
  "value": "id=870   sec_id=4     flags=0x0000 ifindex=10  mac=3E:A9:A4:D9:88:77 nodemac=1E:B1:08:A2:27:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.422Z",
  "value": "id=1920  sec_id=899644 flags=0x0000 ifindex=18  mac=6A:20:E8:64:6F:6C nodemac=46:D5:42:3F:89:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.422Z",
  "value": "id=24    sec_id=905284 flags=0x0000 ifindex=12  mac=4A:77:6E:79:D9:01 nodemac=32:64:D5:61:2E:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.423Z",
  "value": "id=2188  sec_id=905284 flags=0x0000 ifindex=14  mac=2E:A7:3A:48:AD:D9 nodemac=B6:03:D3:3E:DD:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:46.422Z",
  "value": "id=870   sec_id=4     flags=0x0000 ifindex=10  mac=3E:A9:A4:D9:88:77 nodemac=1E:B1:08:A2:27:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:46.422Z",
  "value": "id=1920  sec_id=899644 flags=0x0000 ifindex=18  mac=6A:20:E8:64:6F:6C nodemac=46:D5:42:3F:89:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:46.422Z",
  "value": "id=2188  sec_id=905284 flags=0x0000 ifindex=14  mac=2E:A7:3A:48:AD:D9 nodemac=B6:03:D3:3E:DD:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:46.422Z",
  "value": "id=24    sec_id=905284 flags=0x0000 ifindex=12  mac=4A:77:6E:79:D9:01 nodemac=32:64:D5:61:2E:DC"
}

