35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
110: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
113: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:15:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag a7b8a529928e7a1f  gpl
	loaded_at 2024-10-25T10:15:27+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:15:27+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:15:27+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
489: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 130
490: sched_cls  name __send_drop_notify  tag 6034707c6b2c974b  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 131
491: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 132
492: sched_cls  name tail_handle_ipv4_from_host  tag c2882d4277329f0f  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 133
494: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,102
	btf_id 135
495: sched_cls  name __send_drop_notify  tag 6034707c6b2c974b  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 137
496: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 138
497: sched_cls  name tail_handle_ipv4_from_host  tag c2882d4277329f0f  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 139
501: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 143
502: sched_cls  name __send_drop_notify  tag 6034707c6b2c974b  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 145
503: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 146
504: sched_cls  name tail_handle_ipv4_from_host  tag c2882d4277329f0f  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 147
505: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 148
509: sched_cls  name tail_handle_ipv4_from_host  tag c2882d4277329f0f  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 153
510: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 154
514: sched_cls  name __send_drop_notify  tag 6034707c6b2c974b  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 158
515: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 159
518: sched_cls  name handle_policy  tag 0f1b6f9035dd0baf  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 163
519: sched_cls  name cil_from_container  tag 89930cc5dd31e3c0  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 166
521: sched_cls  name __send_drop_notify  tag 307111a5e41609a8  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 168
522: sched_cls  name tail_handle_ipv4_cont  tag 43a85a43258a30ba  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 169
523: sched_cls  name tail_handle_arp  tag c1e004f8c3d9db22  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 170
525: sched_cls  name tail_ipv4_ct_ingress  tag 2675fe2e8dbe784e  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 171
528: sched_cls  name tail_handle_ipv4  tag a891cdb3826ce6b9  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 174
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 176
536: sched_cls  name tail_ipv4_to_endpoint  tag 552cf6e875e2f13b  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 178
537: sched_cls  name tail_ipv4_ct_egress  tag abd87a1d26108e53  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 185
538: sched_cls  name tail_handle_ipv4  tag 459a11c34feb7d09  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 184
539: sched_cls  name tail_handle_arp  tag 19e79148f0612f76  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 186
541: sched_cls  name tail_ipv4_to_endpoint  tag b0fd55bbbdcefbeb  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,114,41,82,83,80,100,39,115,40,37,38
	btf_id 188
542: sched_cls  name cil_from_container  tag d8bf3bc169daa2cb  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 115,76
	btf_id 189
543: sched_cls  name handle_policy  tag 9c365866d197be89  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,115,82,83,114,41,80,100,39,84,75,40,37,38
	btf_id 190
544: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 191
545: sched_cls  name tail_handle_ipv4_cont  tag 1f8d12ee6b543ce6  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,114,41,100,82,83,39,76,74,77,115,40,37,38,81
	btf_id 192
546: sched_cls  name tail_ipv4_ct_ingress  tag 0444bab673ada669  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 193
547: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 194
548: sched_cls  name __send_drop_notify  tag 3c79a42f7e0eb42c  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
553: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
556: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
557: sched_cls  name tail_handle_ipv4  tag 7f0cc64bd6fafca3  gpl
	loaded_at 2024-10-25T10:15:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,119
	btf_id 197
558: sched_cls  name tail_ipv4_ct_ingress  tag 10235f2e15369964  gpl
	loaded_at 2024-10-25T10:15:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 198
559: sched_cls  name tail_handle_ipv4_cont  tag 03e39a81e6cc78a1  gpl
	loaded_at 2024-10-25T10:15:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,120,41,118,82,83,39,76,74,77,119,40,37,38,81
	btf_id 199
560: sched_cls  name tail_ipv4_to_endpoint  tag f76bc16b36045f46  gpl
	loaded_at 2024-10-25T10:15:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,120,41,82,83,80,118,39,119,40,37,38
	btf_id 200
561: sched_cls  name tail_ipv4_ct_egress  tag abd87a1d26108e53  gpl
	loaded_at 2024-10-25T10:15:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 201
563: sched_cls  name cil_from_container  tag d0b30db212b1b8a3  gpl
	loaded_at 2024-10-25T10:15:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 119,76
	btf_id 203
564: sched_cls  name handle_policy  tag 71b59c9ce9251f85  gpl
	loaded_at 2024-10-25T10:15:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,119,82,83,120,41,80,118,39,84,75,40,37,38
	btf_id 204
565: sched_cls  name tail_handle_arp  tag 03316e257eb19b6f  gpl
	loaded_at 2024-10-25T10:15:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,119
	btf_id 205
566: sched_cls  name __send_drop_notify  tag 493c0d3805b3dc04  gpl
	loaded_at 2024-10-25T10:15:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
567: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,119
	btf_id 207
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
575: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
615: sched_cls  name __send_drop_notify  tag ba46dc71bf941c49  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 221
616: sched_cls  name tail_ipv4_to_endpoint  tag c0dbefe24e5e7c1f  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 222
617: sched_cls  name tail_handle_arp  tag b58695b80c3c6a3d  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 223
618: sched_cls  name tail_ipv4_ct_egress  tag eab9ad9de5931659  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 224
619: sched_cls  name cil_from_container  tag 5264d551bf509545  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 225
620: sched_cls  name tail_ipv4_ct_ingress  tag 36e5d228fd11e7af  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 226
621: sched_cls  name tail_handle_ipv4  tag 5b05aea946dd72ab  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 227
622: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 228
623: sched_cls  name handle_policy  tag 197cc8b5ec42360c  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 229
625: sched_cls  name tail_handle_ipv4_cont  tag b6f5434456b86ce8  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 231
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
