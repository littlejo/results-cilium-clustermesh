key: 18 00 00 00  value: 06 02 00 00
key: 66 03 00 00  value: 1f 02 00 00
key: 80 07 00 00  value: 6f 02 00 00
key: 8c 08 00 00  value: 34 02 00 00
Found 4 elements
