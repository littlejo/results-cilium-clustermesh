REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     214604    84853049   1132   bpf_host.c
Interface                 INGRESS     9455      738667     677    bpf_overlay.c
Success                   EGRESS      4655      354751     1694   bpf_host.c
Success                   EGRESS      91266     12247620   1308   bpf_lxc.c
Success                   EGRESS      9362      731127     53     encap.h
Success                   INGRESS     102177    12519722   86     l3.h
Success                   INGRESS     107626    12947544   235    trace.h
Unsupported L3 protocol   EGRESS      42        3188       1492   bpf_lxc.c
