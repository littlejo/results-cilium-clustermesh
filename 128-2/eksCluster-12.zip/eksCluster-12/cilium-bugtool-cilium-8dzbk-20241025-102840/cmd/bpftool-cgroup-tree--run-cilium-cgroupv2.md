CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod039b367f_6f48_49d3_a741_893660630c01.slice/cri-containerd-5cc4eb25f6ee41dda63ae6c482ee7181a86ea1014f8e2f6b7b15ece54dc13f59.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod039b367f_6f48_49d3_a741_893660630c01.slice/cri-containerd-c7691c28c19fb8f75988b9c421f67ab678fbb986eea2ee79f534707fcef53baf.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod166b2e40_17fd_454e_8ee9_ab2f23e31368.slice/cri-containerd-696151a935d1c211aff7739567dbb897c8954ff2761b33265dbf952e5e6379f8.scope
    556      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod166b2e40_17fd_454e_8ee9_ab2f23e31368.slice/cri-containerd-41557ee8c393210c319425af945793c8a7be996c30074a119ccc29d04b47363e.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7581059c_9c11_4fcb_9d44_aae0ca32f5cd.slice/cri-containerd-feb74fb21b871f558e0fb24db181b5d74dd4caacee2694b6ff52c2254b93a0db.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7581059c_9c11_4fcb_9d44_aae0ca32f5cd.slice/cri-containerd-3bd71da40b4bb1f2f52ce1631dabfe03d780047ad937b0397b11f4530956eec5.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea4a7947_a81a_4e43_8e7b_98ab4b9b412f.slice/cri-containerd-c1443fa27e554bccc7abbe29163f19d3f47b6540773d174f73d7b82c6b915605.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea4a7947_a81a_4e43_8e7b_98ab4b9b412f.slice/cri-containerd-c880bddb4b95bad569c1471423107c59f3aa6aed5ceca2c94461f9c3a895d063.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2abe0358_3cb0_4bd3_89a9_e95a67d4802f.slice/cri-containerd-5479386b2f279833708edd500198626fb9db9a444477f9dd21cf1a6cfd2eeb20.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2abe0358_3cb0_4bd3_89a9_e95a67d4802f.slice/cri-containerd-497f845e590df1388c62a02a712f8262a4a9eeafd3e81555e83707d0bc97e666.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6db15260_0a55_40be_a8d1_dddc99ad9953.slice/cri-containerd-57f74eb69fabbca0dafad57a4cf2de4f529bd0468f192da4d7ebb82083da349b.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6db15260_0a55_40be_a8d1_dddc99ad9953.slice/cri-containerd-05416548b355de6dc4018700568b98c0f3752be03ddb150feea03814dad2c360.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04c98ebc_d8d7_420c_9f8b_9b878246f9cf.slice/cri-containerd-ed5ecfebdb133b63ca4d5f801930345aac92924157df0a68dbfbb3d8161ed265.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04c98ebc_d8d7_420c_9f8b_9b878246f9cf.slice/cri-containerd-05b5ec151e2cbd1e07fc4af64ff85190f14db6ae07d5da89e8a441ed806228fd.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04c98ebc_d8d7_420c_9f8b_9b878246f9cf.slice/cri-containerd-1800cff21b9afac0e1aca65995fd011ad4f2de9b1f066cb484694046f87362c7.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04c98ebc_d8d7_420c_9f8b_9b878246f9cf.slice/cri-containerd-53b5221874036b158f8cef67d44558f66d278e7daff5d0a5aa91d5d0efe546b2.scope
    629      cgroup_device   multi                                          
