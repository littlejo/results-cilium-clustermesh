ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.153.135:443 (active)    
                                         2 => 172.31.194.60:443 (active)     
2    10.100.37.255:443    ClusterIP      1 => 172.31.170.139:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.12.0.124:53 (active)        
                                         2 => 10.12.0.59:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.12.0.124:9153 (active)      
                                         2 => 10.12.0.59:9153 (active)       
5    10.100.255.86:2379   ClusterIP      1 => 10.12.0.4:2379 (active)        
