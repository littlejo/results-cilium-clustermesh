Total: 552
TCP:   1067 (estab 300, closed 748, orphaned 0, timewait 291)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  319       309       10       
INET	  329       315       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:38739      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:23721 sk:259 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.170.139%ens5:68         0.0.0.0:*    uid:192 ino:16462 sk:25a cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:25184 sk:25b cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15195 sk:25c cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:25183 sk:25d cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15196 sk:25e cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::469:63ff:fe4d:8b91]%ens5:546           [::]:*    uid:192 ino:16458 sk:25f cgroup:unreachable:c4e v6only:1 <->                   
