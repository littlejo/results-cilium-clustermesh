alloc: 125.81MB (131922368 bytes)
total-alloc: 1.34GB (1433756848 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47834726
frees: 46584506
heap-alloc: 125.81MB (131922368 bytes)
heap-sys: 165.33MB (173359104 bytes)
heap-idle: 18.62MB (19521536 bytes)
heap-in-use: 146.71MB (153837568 bytes)
heap-released: 3.71MB (3891200 bytes)
heap-objects: 1250220
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 2.27MB (2380320 bytes)
stack-mspan-sys: 2.46MB (2578560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 896.33KB (917841 bytes)
gc-sys: 5.17MB (5421312 bytes)
next-gc: when heap-alloc >= 142.38MB (149295144 bytes)
last-gc: 2024-10-25 10:28:36.191542106 +0000 UTC
gc-pause-total: 9.142554ms
gc-pause: 80034
gc-pause-end: 1729852116191542106
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00036288700783708997
enable-gc: true
debug-gc: false
