USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         659  0.0  0.2 1539912 8752 ?        Rsl  10:28   0:00 /usr/sbin/runc init
root         658  0.0  0.2 1539912 8732 ?        Rsl  10:28   0:00 /usr/sbin/runc init
root         623  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         610  0.0  0.4 1240432 16684 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         669  0.0  0.0   3852  1296 ?        R    10:28   0:00  \_ bash -c cat /proc/net/xfrm_stat
root         670  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root           1  2.8  7.0 1472496 276504 ?      Ssl  10:15   0:23 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1228848 5528 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
