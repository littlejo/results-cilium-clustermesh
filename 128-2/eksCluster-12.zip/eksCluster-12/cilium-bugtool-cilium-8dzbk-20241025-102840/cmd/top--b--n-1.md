top - 10:28:42 up 14 min,  0 users,  load average: 0.05, 0.13, 0.14
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.6 us, 25.0 sy,  0.0 ni, 25.0 id,  0.0 wa,  0.0 hi,  9.4 si,  0.0 st
MiB Mem :   3836.2 total,    790.7 free,    905.0 used,   2140.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2762.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 282340  77668 S  40.0   7.2   0:23.39 cilium-+
    393 root      20   0 1228848   5528   2868 S   0.0   0.1   0:00.26 cilium-+
    610 root      20   0 1240432  16684  11484 S   0.0   0.4   0:00.03 cilium-+
    658 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    659 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    688 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
    707 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
