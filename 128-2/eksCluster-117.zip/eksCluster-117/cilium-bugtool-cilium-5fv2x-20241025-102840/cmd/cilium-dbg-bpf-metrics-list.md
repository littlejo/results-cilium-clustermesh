REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10087     790826     677    bpf_overlay.c
Interface                 INGRESS     222647    86017131   1132   bpf_host.c
Success                   EGRESS      10289     805080     53     encap.h
Success                   EGRESS      5187      399620     1694   bpf_host.c
Success                   EGRESS      94785     12567189   1308   bpf_lxc.c
Success                   INGRESS     106297    13046284   86     l3.h
Success                   INGRESS     111846    13481396   235    trace.h
Unsupported L3 protocol   EGRESS      42        3188       1492   bpf_lxc.c
