1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f2:37:1c:6b:7f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.209.231/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2715sec preferred_lft 2715sec
    inet6 fe80::8f2:37ff:fe1c:6b7f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:54:9b:fb:7c:a5 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.239.60/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::854:9bff:fefb:7ca5/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:2e:a7:b4:69:a9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c2e:a7ff:feb4:69a9/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:db:e4:da:46:07 brd ff:ff:ff:ff:ff:ff
    inet 10.117.0.238/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ecdb:e4ff:feda:4607/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4e:47:d8:b5:d8:9a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c47:d8ff:feb5:d89a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:81:3c:46:73:49 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c81:3cff:fe46:7349/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7acf2fc91f6a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:c2:44:11:ee:27 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6cc2:44ff:fe11:ee27/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc54391dbf8190@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:9f:a5:86:cc:ba brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::ec9f:a5ff:fe86:ccba/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf5e810428d3b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:a1:de:51:55:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d0a1:deff:fe51:55b0/64 scope link 
       valid_lft forever preferred_lft forever
