{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:56.855Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.209.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:56.855Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.239.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:56.855Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:01.590Z",
  "value": "id=3355  sec_id=4     flags=0x0000 ifindex=10  mac=DA:D3:1E:CC:79:83 nodemac=0E:81:3C:46:73:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:01.599Z",
  "value": "id=2027  sec_id=7740688 flags=0x0000 ifindex=12  mac=26:3F:99:AB:CF:4C nodemac=6E:C2:44:11:EE:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:01.601Z",
  "value": "id=2027  sec_id=7740688 flags=0x0000 ifindex=12  mac=26:3F:99:AB:CF:4C nodemac=6E:C2:44:11:EE:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:01.623Z",
  "value": "id=3355  sec_id=4     flags=0x0000 ifindex=10  mac=DA:D3:1E:CC:79:83 nodemac=0E:81:3C:46:73:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:09.117Z",
  "value": "id=789   sec_id=7740688 flags=0x0000 ifindex=14  mac=62:4F:CA:C8:AA:93 nodemac=EE:9F:A5:86:CC:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:49.378Z",
  "value": "id=789   sec_id=7740688 flags=0x0000 ifindex=14  mac=62:4F:CA:C8:AA:93 nodemac=EE:9F:A5:86:CC:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:49.379Z",
  "value": "id=3355  sec_id=4     flags=0x0000 ifindex=10  mac=DA:D3:1E:CC:79:83 nodemac=0E:81:3C:46:73:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:49.379Z",
  "value": "id=2027  sec_id=7740688 flags=0x0000 ifindex=12  mac=26:3F:99:AB:CF:4C nodemac=6E:C2:44:11:EE:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:49.412Z",
  "value": "id=1479  sec_id=7767784 flags=0x0000 ifindex=16  mac=42:85:FE:59:49:52 nodemac=7A:63:60:C6:86:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.378Z",
  "value": "id=3355  sec_id=4     flags=0x0000 ifindex=10  mac=DA:D3:1E:CC:79:83 nodemac=0E:81:3C:46:73:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.379Z",
  "value": "id=789   sec_id=7740688 flags=0x0000 ifindex=14  mac=62:4F:CA:C8:AA:93 nodemac=EE:9F:A5:86:CC:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.379Z",
  "value": "id=1479  sec_id=7767784 flags=0x0000 ifindex=16  mac=42:85:FE:59:49:52 nodemac=7A:63:60:C6:86:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.379Z",
  "value": "id=2027  sec_id=7740688 flags=0x0000 ifindex=12  mac=26:3F:99:AB:CF:4C nodemac=6E:C2:44:11:EE:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.027Z",
  "value": "id=499   sec_id=7767784 flags=0x0000 ifindex=18  mac=5A:D3:31:03:08:C2 nodemac=D2:A1:DE:51:55:B0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.117.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.316Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.318Z",
  "value": "id=3355  sec_id=4     flags=0x0000 ifindex=10  mac=DA:D3:1E:CC:79:83 nodemac=0E:81:3C:46:73:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.318Z",
  "value": "id=2027  sec_id=7740688 flags=0x0000 ifindex=12  mac=26:3F:99:AB:CF:4C nodemac=6E:C2:44:11:EE:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.318Z",
  "value": "id=789   sec_id=7740688 flags=0x0000 ifindex=14  mac=62:4F:CA:C8:AA:93 nodemac=EE:9F:A5:86:CC:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.319Z",
  "value": "id=499   sec_id=7767784 flags=0x0000 ifindex=18  mac=5A:D3:31:03:08:C2 nodemac=D2:A1:DE:51:55:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.313Z",
  "value": "id=499   sec_id=7767784 flags=0x0000 ifindex=18  mac=5A:D3:31:03:08:C2 nodemac=D2:A1:DE:51:55:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.314Z",
  "value": "id=2027  sec_id=7740688 flags=0x0000 ifindex=12  mac=26:3F:99:AB:CF:4C nodemac=6E:C2:44:11:EE:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.314Z",
  "value": "id=3355  sec_id=4     flags=0x0000 ifindex=10  mac=DA:D3:1E:CC:79:83 nodemac=0E:81:3C:46:73:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.314Z",
  "value": "id=789   sec_id=7740688 flags=0x0000 ifindex=14  mac=62:4F:CA:C8:AA:93 nodemac=EE:9F:A5:86:CC:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.314Z",
  "value": "id=499   sec_id=7767784 flags=0x0000 ifindex=18  mac=5A:D3:31:03:08:C2 nodemac=D2:A1:DE:51:55:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.314Z",
  "value": "id=3355  sec_id=4     flags=0x0000 ifindex=10  mac=DA:D3:1E:CC:79:83 nodemac=0E:81:3C:46:73:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.315Z",
  "value": "id=2027  sec_id=7740688 flags=0x0000 ifindex=12  mac=26:3F:99:AB:CF:4C nodemac=6E:C2:44:11:EE:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.315Z",
  "value": "id=789   sec_id=7740688 flags=0x0000 ifindex=14  mac=62:4F:CA:C8:AA:93 nodemac=EE:9F:A5:86:CC:BA"
}

