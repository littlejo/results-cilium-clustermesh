IP ADDRESS         LOCAL ENDPOINT INFO
10.117.0.145:0     id=3355  sec_id=4     flags=0x0000 ifindex=10  mac=DA:D3:1E:CC:79:83 nodemac=0E:81:3C:46:73:49     
10.117.0.58:0      id=499   sec_id=7767784 flags=0x0000 ifindex=18  mac=5A:D3:31:03:08:C2 nodemac=D2:A1:DE:51:55:B0   
172.31.209.231:0   (localhost)                                                                                        
172.31.239.60:0    (localhost)                                                                                        
10.117.0.137:0     id=2027  sec_id=7740688 flags=0x0000 ifindex=12  mac=26:3F:99:AB:CF:4C nodemac=6E:C2:44:11:EE:27   
10.117.0.238:0     (localhost)                                                                                        
10.117.0.30:0      id=789   sec_id=7740688 flags=0x0000 ifindex=14  mac=62:4F:CA:C8:AA:93 nodemac=EE:9F:A5:86:CC:BA   
