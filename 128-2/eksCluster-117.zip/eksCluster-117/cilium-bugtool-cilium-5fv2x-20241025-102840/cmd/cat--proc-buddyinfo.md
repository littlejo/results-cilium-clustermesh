Node 0, zone      DMA      2      0      3      2      0      3      6      3      2      4    167 
Node 0, zone   Normal    279     55     30      2      5      1      0      7      4      4      6 
