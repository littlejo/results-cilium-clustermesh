# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33802931                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33802931                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33802931                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c000000 rw-p 00000000 00:00 0 
ffff66e86000-ffff6709b000 rw-p 00000000 00:00 0 
ffff670a3000-ffff67184000 rw-p 00000000 00:00 0 
ffff67184000-ffff671c5000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff671c5000-ffff67206000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff67206000-ffff67246000 rw-p 00000000 00:00 0 
ffff67246000-ffff67248000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff67248000-ffff6724a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6724a000-ffff677f1000 rw-p 00000000 00:00 0 
ffff677f1000-ffff678f1000 rw-p 00000000 00:00 0 
ffff678f1000-ffff67902000 rw-p 00000000 00:00 0 
ffff67902000-ffff69902000 rw-p 00000000 00:00 0 
ffff69902000-ffff69982000 ---p 00000000 00:00 0 
ffff69982000-ffff69983000 rw-p 00000000 00:00 0 
ffff69983000-ffff89982000 ---p 00000000 00:00 0 
ffff89982000-ffff89983000 rw-p 00000000 00:00 0 
ffff89983000-ffffa9912000 ---p 00000000 00:00 0 
ffffa9912000-ffffa9913000 rw-p 00000000 00:00 0 
ffffa9913000-ffffad904000 ---p 00000000 00:00 0 
ffffad904000-ffffad905000 rw-p 00000000 00:00 0 
ffffad905000-ffffae102000 ---p 00000000 00:00 0 
ffffae102000-ffffae103000 rw-p 00000000 00:00 0 
ffffae103000-ffffae202000 ---p 00000000 00:00 0 
ffffae202000-ffffae262000 rw-p 00000000 00:00 0 
ffffae262000-ffffae264000 r--p 00000000 00:00 0                          [vvar]
ffffae264000-ffffae265000 r-xp 00000000 00:00 0                          [vdso]
ffffcf1c4000-ffffcf1e5000 rw-p 00000000 00:00 0                          [stack]

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.158.84:443 (active)     
                                          2 => 172.31.205.162:443 (active)    
2    10.100.163.239:443    ClusterIP      1 => 172.31.209.231:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.117.0.137:53 (active)       
                                          2 => 10.117.0.30:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.117.0.137:9153 (active)     
                                          2 => 10.117.0.30:9153 (active)      
5    10.100.140.241:2379   ClusterIP      1 => 10.117.0.58:2379 (active)      
```

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.117.0.58": (string) (len=50) "kube-system/clustermesh-apiserver-748b7c8b8c-jqkzk",
  (string) (len=12) "10.117.0.238": (string) (len=6) "router",
  (string) (len=12) "10.117.0.145": (string) (len=6) "health",
  (string) (len=12) "10.117.0.137": (string) (len=35) "kube-system/coredns-cc6ccd49c-l6vrz",
  (string) (len=11) "10.117.0.30": (string) (len=35) "kube-system/coredns-cc6ccd49c-pggt8"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.209.231": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001dc2420)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001dc1560,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001dc1560,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40036d86e0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40036d8840)(frontends:[10.100.140.241]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40008c8f20)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40008c8fd0)(frontends:[10.100.163.239]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40008c9130)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400147ad20)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40025f2d00)(172.31.158.84:443/TCP,172.31.205.162:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400147ad30)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-dk5m4": (*k8s.Endpoints)(0x4001e68340)(172.31.209.231:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400147ad40)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-559cw": (*k8s.Endpoints)(0x4003938a90)(10.117.0.137:53/TCP[eu-west-3b],10.117.0.137:53/UDP[eu-west-3b],10.117.0.137:9153/TCP[eu-west-3b],10.117.0.30:53/TCP[eu-west-3b],10.117.0.30:53/UDP[eu-west-3b],10.117.0.30:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001236330)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-4x2ck": (*k8s.Endpoints)(0x4003939c70)(10.117.0.58:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40003c7340)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400217eb40)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4007099dd0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40021812c0,
  gcExited: (chan struct {}) 0x4002181320,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4000aa5680)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001006bc8)({
      MetricVec: (*prometheus.MetricVec)(0x4001db6870)({
       metricMap: (*prometheus.metricMap)(0x4001db68a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000853da0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4000aa5700)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001006bd0)({
      MetricVec: (*prometheus.MetricVec)(0x4001db6900)({
       metricMap: (*prometheus.metricMap)(0x4001db6930)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000853e00)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4000aa5780)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001006bd8)({
      MetricVec: (*prometheus.MetricVec)(0x4001db6990)({
       metricMap: (*prometheus.metricMap)(0x4001db69c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000853e60)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4000aa5800)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001006be0)({
      MetricVec: (*prometheus.MetricVec)(0x4001db6a20)({
       metricMap: (*prometheus.metricMap)(0x4001db6a50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000853ec0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4000aa5880)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001006be8)({
      MetricVec: (*prometheus.MetricVec)(0x4001db6ab0)({
       metricMap: (*prometheus.metricMap)(0x4001db6ae0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000853f20)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4000aa5900)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001006bf0)({
      MetricVec: (*prometheus.MetricVec)(0x4001db6b40)({
       metricMap: (*prometheus.metricMap)(0x4001db6b70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001dc0000)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4000aa5980)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001006bf8)({
      MetricVec: (*prometheus.MetricVec)(0x4001db6bd0)({
       metricMap: (*prometheus.metricMap)(0x4001db6c00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001dc0060)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4000aa5a00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001006c00)({
      MetricVec: (*prometheus.MetricVec)(0x4001db6c60)({
       metricMap: (*prometheus.metricMap)(0x4001db6c90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001dc00c0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4000aa5a80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001006c08)({
      MetricVec: (*prometheus.MetricVec)(0x4001db6cf0)({
       metricMap: (*prometheus.metricMap)(0x4001db6d20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001dc0120)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40003c7340)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40018ee540)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d8e7f8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 434ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.117.0.0/24, 
Allocated addresses:
  10.117.0.137 (kube-system/coredns-cc6ccd49c-l6vrz)
  10.117.0.145 (health)
  10.117.0.238 (router)
  10.117.0.30 (kube-system/coredns-cc6ccd49c-pggt8)
  10.117.0.58 (kube-system/clustermesh-apiserver-748b7c8b8c-jqkzk)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f9842b6cd7ebe13e
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    14s ago        never        0       no error   
  ct-map-pressure                                                     15s ago        never        0       no error   
  daemon-validate-config                                              1s ago         never        0       no error   
  dns-garbage-collector-job                                           18s ago        never        0       no error   
  endpoint-2027-regeneration-recovery                                 never          never        0       no error   
  endpoint-3355-regeneration-recovery                                 never          never        0       no error   
  endpoint-499-regeneration-recovery                                  never          never        0       no error   
  endpoint-789-regeneration-recovery                                  never          never        0       no error   
  endpoint-917-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m18s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                15s ago        never        0       no error   
  ipcache-inject-labels                                               15s ago        never        0       no error   
  k8s-heartbeat                                                       18s ago        never        0       no error   
  link-cache                                                          0s ago         never        0       no error   
  local-identity-checkpoint                                           14m15s ago     never        0       no error   
  node-neighbor-link-updater                                          5s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m59s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m59s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m59s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m59s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m59s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m59s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m59s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m59s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m59s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m59s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m58s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m59s ago      never        0       no error   
  resolve-identity-2027                                               4m13s ago      never        0       no error   
  resolve-identity-3355                                               4m14s ago      never        0       no error   
  resolve-identity-499                                                2m27s ago      never        0       no error   
  resolve-identity-789                                                4m3s ago       never        0       no error   
  resolve-identity-917                                                4m15s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-748b7c8b8c-jqkzk   7m27s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-l6vrz                  14m13s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-pggt8                  14m3s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m15s ago     never        0       no error   
  sync-policymap-2027                                                 14m11s ago     never        0       no error   
  sync-policymap-3355                                                 14m11s ago     never        0       no error   
  sync-policymap-499                                                  7m27s ago      never        0       no error   
  sync-policymap-789                                                  14m3s ago      never        0       no error   
  sync-policymap-917                                                  14m14s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (2027)                                   3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (499)                                    7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (789)                                    3s ago         never        0       no error   
  sync-utime                                                          15s ago        never        0       no error   
  write-cni-file                                                      14m18s ago     never        0       no error   
Proxy Status:            OK, ip 10.117.0.238, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 7733248, max 7798783
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 76.49   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
enable-service-topology:false
disable-external-ip-mitigation:false
bypass-ip-availability-upon-restore:false
wireguard-persistent-keepalive:0s
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
hubble-prefer-ipv6:false
egress-gateway-policy-map-max:16384
ipv6-cluster-alloc-cidr:f00d::/64
hubble-event-queue-size:0
enable-gateway-api:false
enable-ipv4:true
cni-exclusive:true
node-port-mode:snat
proxy-connect-timeout:2
hubble-recorder-storage-path:/var/run/cilium/pcaps
tofqdns-dns-reject-response-code:refused
use-full-tls-context:false
lib-dir:/var/lib/cilium
enable-ipsec-xfrm-state-caching:true
proxy-portrange-max:20000
devices:
k8s-require-ipv4-pod-cidr:false
enable-hubble:true
clustermesh-enable-endpoint-sync:false
hubble-redact-kafka-apikey:false
log-system-load:false
enable-k8s:true
policy-trigger-interval:1s
enable-ipsec-key-watcher:true
bpf-ct-timeout-regular-tcp-fin:10s
enable-well-known-identities:false
config-dir:/tmp/cilium/config-map
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
cmdref:
cluster-health-port:4240
trace-sock:true
local-router-ipv4:
bpf-events-trace-enabled:true
enable-bpf-masquerade:false
ipsec-key-rotation-duration:5m0s
hubble-redact-http-urlquery:false
bpf-nat-global-max:524288
bpf-ct-timeout-regular-any:1m0s
hubble-export-file-max-size-mb:10
hubble-export-file-max-backups:5
enable-icmp-rules:true
bpf-lb-service-backend-map-max:0
enable-xdp-prefilter:false
exclude-local-address:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
pprof-address:localhost
allocator-list-timeout:3m0s
egress-gateway-reconciliation-trigger-interval:1s
endpoint-bpf-prog-watchdog-interval:30s
bpf-lb-sock-terminate-pod-connections:false
unmanaged-pod-watcher-interval:15
direct-routing-device:
enable-bandwidth-manager:false
hubble-export-fieldmask:
tunnel-port:0
enable-recorder:false
identity-gc-interval:15m0s
debug-verbose:
enable-ipsec:false
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-events-policy-verdict-enabled:true
hubble-drop-events-reasons:auth_required,policy_denied
auto-create-cilium-node-resource:true
identity-allocation-mode:crd
cflags:
bpf-sock-rev-map-max:262144
enable-host-legacy-routing:false
fqdn-regex-compile-lru-size:1024
bpf-lb-dsr-l4-xlate:frontend
proxy-gid:1337
envoy-base-id:0
bpf-node-map-max:16384
bpf-map-dynamic-size-ratio:0.0025
bpf-ct-timeout-service-tcp-grace:1m0s
hubble-metrics-server:
ingress-secrets-namespace:
bpf-ct-timeout-service-any:1m0s
http-retry-count:3
ipv4-pod-subnets:
bpf-root:/sys/fs/bpf
enable-nat46x64-gateway:false
disable-endpoint-crd:false
enable-unreachable-routes:false
enable-session-affinity:false
enable-srv6:false
disable-iptables-feeder-rules:
node-labels:
conntrack-gc-max-interval:0s
enable-k8s-terminating-endpoint:true
enable-ipv6-masquerade:true
http-normalize-path:true
api-rate-limit:
datapath-mode:veth
cluster-id:118
state-dir:/var/run/cilium
enable-wireguard-userspace-fallback:false
envoy-secrets-namespace:
agent-health-port:9879
agent-liveness-update-interval:1s
mesh-auth-signal-backoff-duration:1s
proxy-max-requests-per-connection:0
external-envoy-proxy:true
bpf-policy-map-full-reconciliation-interval:15m0s
arping-refresh-period:30s
enable-local-redirect-policy:false
bpf-lb-algorithm:random
ipv6-pod-subnets:
monitor-aggregation:medium
nodeport-addresses:
enable-sctp:false
enable-k8s-api-discovery:false
encrypt-node:false
encrypt-interface:
tofqdns-endpoint-max-ip-per-hostname:50
enable-xt-socket-fallback:true
conntrack-gc-interval:0s
bpf-neigh-global-max:524288
bpf-lb-sock-hostns-only:false
hubble-drop-events-interval:2m0s
proxy-portrange-min:10000
use-cilium-internal-ip-for-ipsec:false
custom-cni-conf:false
gateway-api-secrets-namespace:
enable-ingress-controller:false
enable-custom-calls:false
bpf-lb-rss-ipv4-src-cidr:
enable-encryption-strict-mode:false
hubble-socket-path:/var/run/cilium/hubble.sock
enable-host-firewall:false
hubble-export-file-path:
proxy-idle-timeout-seconds:60
enable-runtime-device-detection:true
hubble-event-buffer-capacity:4095
cni-log-file:/var/run/cilium/cilium-cni.log
bpf-auth-map-max:524288
hubble-redact-http-headers-allow:
k8s-sync-timeout:3m0s
hubble-export-denylist:
set-cilium-is-up-condition:true
l2-announcements-renew-deadline:5s
enable-ipsec-encrypted-overlay:false
enable-l2-pod-announcements:false
vtep-endpoint:
ipam:cluster-pool
cluster-pool-ipv4-mask-size:24
mesh-auth-enabled:true
hubble-export-allowlist:
ipam-cilium-node-update-rate:15s
enable-mke:false
dnsproxy-lock-timeout:500ms
label-prefix-file:
hubble-skip-unknown-cgroup-ids:true
enable-pmtu-discovery:false
routing-mode:tunnel
identity-change-grace-period:5s
k8s-client-burst:20
bpf-fragments-map-max:8192
proxy-prometheus-port:0
synchronize-k8s-nodes:true
http-retry-timeout:0
ipam-default-ip-pool:default
proxy-xff-num-trusted-hops-egress:0
vtep-mac:
http-max-grpc-timeout:0
proxy-max-connection-duration-seconds:0
bpf-policy-map-max:16384
version:false
dnsproxy-concurrency-limit:0
monitor-queue-size:0
log-driver:
enable-svc-source-range-check:true
dns-max-ips-per-restored-rule:1000
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
cluster-name:cmesh118
enable-active-connection-tracking:false
srv6-encap-mode:reduced
tofqdns-min-ttl:0
l2-announcements-retry-period:2s
enable-cilium-api-server-access:
l2-pod-announcements-interface:
http-idle-timeout:0
hubble-disable-tls:false
derive-masq-ip-addr-from-device:
pprof:false
enable-policy:default
disable-envoy-version-check:false
allow-localhost:auto
enable-l2-neigh-discovery:true
enable-k8s-networkpolicy:true
bpf-events-drop-enabled:true
bpf-lb-maglev-map-max:0
kvstore-periodic-sync:5m0s
bpf-lb-rss-ipv6-src-cidr:
envoy-config-timeout:2m0s
bpf-lb-source-range-map-max:0
enable-endpoint-routes:false
annotate-k8s-node:false
metrics:
enable-metrics:true
crd-wait-timeout:5m0s
mesh-auth-gc-interval:5m0s
nodes-gc-interval:5m0s
hubble-drop-events:false
enable-auto-protect-node-port-range:true
http-request-timeout:3600
static-cnp-path:
prepend-iptables-chains:true
config-sources:config-map:kube-system/cilium-config
k8s-kubeconfig-path:
enable-vtep:false
enable-ipv6:false
proxy-xff-num-trusted-hops-ingress:0
identity-heartbeat-timeout:30m0s
multicast-enabled:false
dnsproxy-lock-count:131
install-iptables-rules:true
operator-api-serve-addr:127.0.0.1:9234
k8s-client-qps:10
node-port-range:
container-ip-local-reserved-ports:auto
tofqdns-max-deferred-connection-deletes:10000
kube-proxy-replacement:false
enable-ipv4-big-tcp:false
k8s-service-proxy-name:
enable-node-selector-labels:false
bpf-lb-affinity-map-max:0
tofqdns-pre-cache:
bpf-lb-sock:false
read-cni-conf:
local-max-addr-scope:252
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-monitor:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
bpf-lb-acceleration:disabled
join-cluster:false
policy-cidr-match-mode:
enable-tcx:true
tofqdns-proxy-response-max-delay:100ms
dnsproxy-socket-linger-timeout:10
max-connected-clusters:255
bpf-map-event-buffers:
bpf-lb-maglev-table-size:16381
k8s-client-connection-keep-alive:30s
remove-cilium-node-taints:true
mtu:0
route-metric:0
tofqdns-idle-connection-grace-period:0s
bpf-lb-map-max:65536
tofqdns-enable-dns-compression:true
ipv4-node:auto
bpf-lb-service-map-max:0
keep-config:false
enable-ipv4-fragment-tracking:true
prometheus-serve-addr:
egress-multi-home-ip-rule-compat:false
enable-bgp-control-plane:false
bpf-filter-priority:1
enable-route-mtu-for-cni-chaining:false
enable-cilium-endpoint-slice:false
trace-payloadlen:128
identity-restore-grace-period:30s
kvstore:
enable-health-check-nodeport:true
auto-direct-node-routes:false
dns-policy-unload-on-shutdown:false
l2-announcements-lease-duration:15s
policy-accounting:true
mesh-auth-spiffe-trust-domain:spiffe.cilium
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-high-scale-ipcache:false
enable-ipv4-masquerade:true
mesh-auth-mutual-connect-timeout:5s
ipv4-service-loopback-address:169.254.42.1
service-no-backend-response:reject
procfs:/host/proc
cni-chaining-target:
enable-l2-announcements:false
cgroup-root:/run/cilium/cgroupv2
max-internal-timer-delay:0s
ipv6-mcast-device:
enable-tracing:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-endpoint-health-checking:true
vtep-mask:
enable-envoy-config:false
enable-external-ips:false
local-router-ipv6:
enable-masquerade-to-route-source:false
envoy-log:
vlan-bpf-bypass:
enable-node-port:false
hubble-listen-address::4244
k8s-client-connection-timeout:30s
tunnel-protocol:vxlan
hubble-redact-enabled:false
ipv6-range:auto
enable-local-node-route:true
ipv6-node:auto
hubble-metrics:
ipv4-range:auto
nat-map-stats-interval:30s
socket-path:/var/run/cilium/cilium.sock
proxy-admin-port:0
enable-hubble-recorder-api:true
node-port-algorithm:random
hubble-redact-http-userinfo:true
hubble-redact-http-headers-deny:
agent-labels:
bgp-announce-lb-ip:false
enable-ipv6-big-tcp:false
k8s-require-ipv6-pod-cidr:false
enable-ipv4-egress-gateway:false
node-port-acceleration:disabled
dnsproxy-enable-transparent-mode:true
bpf-lb-rev-nat-map-max:0
mke-cgroup-mount:
exclude-node-label-patterns:
enable-wireguard:false
cni-chaining-mode:none
enable-ipv6-ndp:false
kvstore-max-consecutive-quorum-errors:2
enable-health-check-loadbalancer-ip:false
pprof-port:6060
allow-icmp-frag-needed:true
mesh-auth-rotated-identities-queue-size:1024
monitor-aggregation-flags:all
max-controller-interval:0
hubble-monitor-events:
endpoint-gc-interval:5m0s
labels:
clustermesh-ip-identities-sync-timeout:1m0s
policy-audit-mode:false
certificates-directory:/var/run/cilium/certs
hubble-recorder-sink-queue-size:1024
preallocate-bpf-maps:false
iptables-random-fully:false
mesh-auth-mutual-listener-port:0
hubble-flowlogs-config-path:
enable-bbr:false
enable-health-checking:true
cluster-pool-ipv4-cidr:10.117.0.0/16
set-cilium-node-taints:true
enable-bpf-clock-probe:false
egress-masquerade-interfaces:ens+
bpf-lb-mode:snat
operator-prometheus-serve-addr::9963
hubble-export-file-compress:false
vtep-cidr:
kvstore-opt:
enable-identity-mark:true
enable-k8s-endpoint-slice:true
config:
nat-map-stats-entries:32
install-no-conntrack-iptables-rules:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
ipsec-key-file:
bpf-ct-global-tcp-max:524288
policy-queue-size:100
bpf-lb-external-clusterip:false
bpf-ct-global-any-max:262144
dnsproxy-insecure-skip-transparent-mode-check:false
clustermesh-sync-timeout:1m0s
bpf-lb-dsr-dispatch:opt
enable-ipip-termination:false
cilium-endpoint-gc-interval:5m0s
force-device-detection:false
kube-proxy-replacement-healthz-bind-address:
restore:true
log-opt:
ipv4-service-range:auto
encryption-strict-mode-allow-remote-node-identities:false
endpoint-queue-size:25
k8s-api-server:
clustermesh-enable-mcs-api:false
ipv4-native-routing-cidr:
mesh-auth-spire-admin-socket:
fixed-identity-mapping:
ipv6-native-routing-cidr:
k8s-namespace:kube-system
iptables-lock-timeout:5s
envoy-keep-cap-netbindservice:false
node-port-bind-protection:true
kvstore-lease-ttl:15m0s
kvstore-connectivity-timeout:2m0s
direct-routing-skip-unreachable:false
bpf-ct-timeout-regular-tcp:2h13m20s
mesh-auth-queue-size:1024
ipv6-service-range:auto
cni-external-routing:false
dnsproxy-concurrency-processing-grace-period:0s
enable-cilium-health-api-server-access:
monitor-aggregation-interval:5s
enable-bpf-tproxy:false
envoy-config-retry-interval:15s
controller-group-metrics:
enable-l7-proxy:true
ipam-multi-pool-pre-allocation:
enable-stale-cilium-endpoint-cleanup:true
bgp-announce-pod-cidr:false
enable-ip-masq-agent:false
gops-port:9890
encryption-strict-mode-cidr:
k8s-heartbeat-timeout:30s
enable-host-port:false
k8s-service-cache-size:128
bpf-ct-timeout-service-tcp:2h13m20s
debug:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-ct-timeout-regular-tcp-syn:1m0s
tofqdns-proxy-port:0
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
499        Disabled           Disabled          7767784    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.117.0.58    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh118                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
789        Disabled           Disabled          7740688    k8s:eks.amazonaws.com/component=coredns                                             10.117.0.30    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh118                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
917        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                 
                                                           reserved:host                                                                                              
2027       Disabled           Disabled          7740688    k8s:eks.amazonaws.com/component=coredns                                             10.117.0.137   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh118                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
3355       Disabled           Disabled          4          reserved:health                                                                     10.117.0.145   ready   
```

#### BPF Policy Get 499

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3843926   36411     0        
Allow    Ingress     1          ANY          NONE         disabled    3304387   33684     0        
Allow    Egress      0          ANY          NONE         disabled    4914406   45226     0        

```


#### BPF CT List 499

```
Invalid argument: unknown type 499
```


#### Endpoint Get 499

```
[
  {
    "id": 499,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-499-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "fa2a072a-544b-46b7-91a9-9305e294d541"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-499",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:44.983Z",
            "success-count": 2
          },
          "uuid": "f23bbffc-f43c-4b46-a96a-f980bf709ab0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-748b7c8b8c-jqkzk",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:44.982Z",
            "success-count": 1
          },
          "uuid": "7511fdce-d580-4830-9558-aa5ce29eac6b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-499",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:45.029Z",
            "success-count": 1
          },
          "uuid": "beaa95d5-c4cd-4fff-839c-3b6cbb44834d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (499)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.031Z",
            "success-count": 46
          },
          "uuid": "9a2ec7ec-82a1-4267-8c5b-2e20ba68478f"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "bf5ad202ee7bb155427f2b4dba15c8de9df94798874bbcc69dedc3325e6cd3aa:eth0",
        "container-id": "bf5ad202ee7bb155427f2b4dba15c8de9df94798874bbcc69dedc3325e6cd3aa",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-748b7c8b8c-jqkzk",
        "pod-name": "kube-system/clustermesh-apiserver-748b7c8b8c-jqkzk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7767784,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh118",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=748b7c8b8c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh118",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:15Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.117.0.58",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "d2:a1:de:51:55:b0",
        "interface-index": 18,
        "interface-name": "lxcf5e810428d3b",
        "mac": "5a:d3:31:03:08:c2"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7767784,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7767784,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 499

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 499

```
Timestamp              Status   State                   Message
2024-10-25T10:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:15Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:44Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:44Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7767784

```
ID        LABELS
7767784   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh118
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 789

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77955   891       0        
Allow    Egress      0          ANY          NONE         disabled    12699   132       0        

```


#### BPF CT List 789

```
Invalid argument: unknown type 789
```


#### Endpoint Get 789

```
[
  {
    "id": 789,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-789-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "dfe3ef43-88e6-4fdd-8c11-03233d15e3f1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-789",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:09.089Z",
            "success-count": 3
          },
          "uuid": "33092421-f387-46ec-ae6f-afb188e749c1"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-pggt8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:09.087Z",
            "success-count": 1
          },
          "uuid": "70a0afa7-0702-4958-a50a-d46b4dffd4af"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-789",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:09.117Z",
            "success-count": 1
          },
          "uuid": "f2852138-7f53-4f75-b982-3dd1b62409ea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (789)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.157Z",
            "success-count": 86
          },
          "uuid": "63482790-d763-45e1-8d80-6eaa1745bef7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0eb1c833f0d0c469644838983c0b1eb82b4a8d4ca8dc255a525f784d48f34cb4:eth0",
        "container-id": "0eb1c833f0d0c469644838983c0b1eb82b4a8d4ca8dc255a525f784d48f34cb4",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-pggt8",
        "pod-name": "kube-system/coredns-cc6ccd49c-pggt8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7740688,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh118",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh118",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:15Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.117.0.30",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ee:9f:a5:86:cc:ba",
        "interface-index": 14,
        "interface-name": "lxc54391dbf8190",
        "mac": "62:4f:ca:c8:aa:93"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7740688,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7740688,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 789

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 789

```
Timestamp              Status   State                   Message
2024-10-25T10:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:15Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:09Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:09Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:09Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7740688

```
ID        LABELS
7740688   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh118
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 917

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 917

```
Invalid argument: unknown type 917
```


#### Endpoint Get 917

```
[
  {
    "id": 917,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-917-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d06a998e-2aee-4872-a7ab-d1b533a61d8c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-917",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:57.036Z",
            "success-count": 3
          },
          "uuid": "00d140ef-ccc8-4a85-a758-2e460cb7d4a0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-917",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:58.096Z",
            "success-count": 1
          },
          "uuid": "7b10f841-0871-411a-a879-0bec790cd0f9"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:15Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "ee:db:e4:da:46:07",
        "interface-name": "cilium_host",
        "mac": "ee:db:e4:da:46:07"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 917

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 917

```
Timestamp              Status   State                   Message
2024-10-25T10:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:15Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:57Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2027

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79873   914       0        
Allow    Egress      0          ANY          NONE         disabled    14859   156       0        

```


#### BPF CT List 2027

```
Invalid argument: unknown type 2027
```


#### Endpoint Get 2027

```
[
  {
    "id": 2027,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2027-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5abd529d-a58a-434c-85a9-4f4b8a016fce"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2027",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:59.475Z",
            "success-count": 3
          },
          "uuid": "65985d08-38b6-4a02-8a59-4fdc5c7a3bc6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-l6vrz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:59.474Z",
            "success-count": 1
          },
          "uuid": "9ba30ca8-9042-492c-98e8-cb6df992008c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2027",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:01.601Z",
            "success-count": 1
          },
          "uuid": "c97406a7-1375-4d2f-83d4-7060f0a37bf6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2027)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.552Z",
            "success-count": 87
          },
          "uuid": "66068502-5a6a-4ad3-8933-ce15db74c874"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "6c5bef1899a83d0a5cf5aa152d974378ef55e822950083300ebe7e40cffe5b75:eth0",
        "container-id": "6c5bef1899a83d0a5cf5aa152d974378ef55e822950083300ebe7e40cffe5b75",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-l6vrz",
        "pod-name": "kube-system/coredns-cc6ccd49c-l6vrz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7740688,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh118",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh118",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:15Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.117.0.137",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "6e:c2:44:11:ee:27",
        "interface-index": 12,
        "interface-name": "lxc7acf2fc91f6a",
        "mac": "26:3f:99:ab:cf:4c"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7740688,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7740688,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2027

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2027

```
Timestamp              Status   State                   Message
2024-10-25T10:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:15Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:59Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:59Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7740688

```
ID        LABELS
7740688   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh118
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3355

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435735   5557      0        
Allow    Ingress     1          ANY          NONE         disabled    11738    135       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3355

```
Invalid argument: unknown type 3355
```


#### Endpoint Get 3355

```
[
  {
    "id": 3355,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3355-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f463b004-f62e-4b68-85eb-cf74a10e08e3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3355",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:58.094Z",
            "success-count": 3
          },
          "uuid": "d224a0c1-13cb-44eb-bf73-716882d817b7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3355",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:01.591Z",
            "success-count": 1
          },
          "uuid": "0840c7a0-ee98-4cff-9a67-6a4fd194050f"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:15Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.117.0.145",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "0e:81:3c:46:73:49",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "da:d3:1e:cc:79:83"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3355

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3355

```
Timestamp              Status   State                   Message
2024-10-25T10:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:15Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:15:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:01Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:15:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:58Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:58Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```

