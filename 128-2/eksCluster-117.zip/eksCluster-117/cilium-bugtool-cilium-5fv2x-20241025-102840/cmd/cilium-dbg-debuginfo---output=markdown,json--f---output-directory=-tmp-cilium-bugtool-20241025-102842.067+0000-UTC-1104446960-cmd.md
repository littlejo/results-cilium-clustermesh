markdown output at /tmp/cilium-bugtool-20241025-102842.067+0000-UTC-1104446960/cmd/cilium-debuginfo-20241025-102912.68+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.067+0000-UTC-1104446960/cmd/cilium-debuginfo-20241025-102912.68+0000-UTC.json
