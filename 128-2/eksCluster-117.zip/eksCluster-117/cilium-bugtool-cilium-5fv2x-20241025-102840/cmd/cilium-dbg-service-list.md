ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.158.84:443 (active)     
                                          2 => 172.31.205.162:443 (active)    
2    10.100.163.239:443    ClusterIP      1 => 172.31.209.231:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.117.0.137:53 (active)       
                                          2 => 10.117.0.30:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.117.0.137:9153 (active)     
                                          2 => 10.117.0.30:9153 (active)      
5    10.100.140.241:2379   ClusterIP      1 => 10.117.0.58:2379 (active)      
