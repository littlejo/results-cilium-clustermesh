USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         672  0.0  0.4 1240176 15820 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         695  0.0  0.0   6408  1640 ?        R    10:28   0:00  \_ ps auxfw
root         696  0.0  0.4 1240176 15820 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  3.1  7.0 1472496 277548 ?      Ssl  10:14   0:26 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.0  0.1 1228848 5532 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
