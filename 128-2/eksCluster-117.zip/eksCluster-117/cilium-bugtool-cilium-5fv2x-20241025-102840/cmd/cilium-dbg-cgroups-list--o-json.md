[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bda2a9_8e5f_44ea_8460_98f1e57febb7.slice/cri-containerd-a47500ea375d0a5255874bc90a485929ac8659511de7bfacda0dd9ab29db1d22.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bda2a9_8e5f_44ea_8460_98f1e57febb7.slice/cri-containerd-873c6eba9a532f04051436336386cece27aad098e1f4d05b90071eb4ca0b1f1b.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bda2a9_8e5f_44ea_8460_98f1e57febb7.slice/cri-containerd-cc7bd303ec35b16f9c1842ebef4468648e97ba84e47e84571242ca9b05d96cff.scope"
      }
    ],
    "ips": [
      "10.117.0.58"
    ],
    "name": "clustermesh-apiserver-748b7c8b8c-jqkzk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf17682ed_b5e5_4c3c_a014_c2682c115139.slice/cri-containerd-059b29db61f3cb91f082eec16b5b824e3b01350b71867ffb776fe7dc76c39088.scope"
      }
    ],
    "ips": [
      "10.117.0.137"
    ],
    "name": "coredns-cc6ccd49c-l6vrz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4bf14f49_2aaa_4f43_90c2_910a044fbd7a.slice/cri-containerd-c4bfe9b5e5a59b769a2562170519925e0258b152d17d5056da3d01e497b10219.scope"
      }
    ],
    "ips": [
      "10.117.0.30"
    ],
    "name": "coredns-cc6ccd49c-pggt8",
    "namespace": "kube-system"
  }
]

