CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf17682ed_b5e5_4c3c_a014_c2682c115139.slice/cri-containerd-059b29db61f3cb91f082eec16b5b824e3b01350b71867ffb776fe7dc76c39088.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf17682ed_b5e5_4c3c_a014_c2682c115139.slice/cri-containerd-6c5bef1899a83d0a5cf5aa152d974378ef55e822950083300ebe7e40cffe5b75.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddef3c7f5_c081_4129_b1e6_414ce9630c34.slice/cri-containerd-d7d3f67fbda336c121829c7ce46c057cb7bb192a5e7a87fc33be0ec5e575ad3e.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddef3c7f5_c081_4129_b1e6_414ce9630c34.slice/cri-containerd-97acab07cf45a0449ebce189dcf8737c8aee31ed34dc4195667ba76c060da4ac.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4bf14f49_2aaa_4f43_90c2_910a044fbd7a.slice/cri-containerd-c4bfe9b5e5a59b769a2562170519925e0258b152d17d5056da3d01e497b10219.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4bf14f49_2aaa_4f43_90c2_910a044fbd7a.slice/cri-containerd-0eb1c833f0d0c469644838983c0b1eb82b4a8d4ca8dc255a525f784d48f34cb4.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae94d787_dd6f_4065_958a_3635f05d6284.slice/cri-containerd-30006cef589cf28026b0d02eb3ea923e2bd3613297da9f9e9c7ebecb36a36c81.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae94d787_dd6f_4065_958a_3635f05d6284.slice/cri-containerd-f863ff70c34fb3c9a0eac79cced476cea02bbf2d69f9cb17e5b3d0da1567e6d8.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bda2a9_8e5f_44ea_8460_98f1e57febb7.slice/cri-containerd-a47500ea375d0a5255874bc90a485929ac8659511de7bfacda0dd9ab29db1d22.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bda2a9_8e5f_44ea_8460_98f1e57febb7.slice/cri-containerd-bf5ad202ee7bb155427f2b4dba15c8de9df94798874bbcc69dedc3325e6cd3aa.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bda2a9_8e5f_44ea_8460_98f1e57febb7.slice/cri-containerd-cc7bd303ec35b16f9c1842ebef4468648e97ba84e47e84571242ca9b05d96cff.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bda2a9_8e5f_44ea_8460_98f1e57febb7.slice/cri-containerd-873c6eba9a532f04051436336386cece27aad098e1f4d05b90071eb4ca0b1f1b.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0b22556_4b3e_4a2c_96df_da4dc0088dd1.slice/cri-containerd-434c81398a4b45af683503c9172962b9456269612ae347b55421ce748d3e9d25.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0b22556_4b3e_4a2c_96df_da4dc0088dd1.slice/cri-containerd-10215fafa2c9085b7ca27e902787876914ce85350246f2f75869adc6218945ca.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93fa97ab_2208_4fe7_8dcb_3528e81738a9.slice/cri-containerd-27a1e20fcb513662089119d94e644465c7617b0b7944b3095447df56edb9bc3b.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93fa97ab_2208_4fe7_8dcb_3528e81738a9.slice/cri-containerd-466019861dffd8588af214e390f0abb2067b184d98c2b20e97058189b3f774d9.scope
    91       cgroup_device   multi                                          
