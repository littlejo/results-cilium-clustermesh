key: f3 01 00 00  value: 6b 02 00 00
key: 15 03 00 00  value: 2e 02 00 00
key: eb 07 00 00  value: 05 02 00 00
key: 1b 0d 00 00  value: 19 02 00 00
Found 4 elements
