alloc: 92.65MB (97153640 bytes)
total-alloc: 1.36GB (1460799624 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 48242338
frees: 47357382
heap-alloc: 92.65MB (97153640 bytes)
heap-sys: 157.20MB (164831232 bytes)
heap-idle: 41.44MB (43450368 bytes)
heap-in-use: 115.76MB (121380864 bytes)
heap-released: 672.00KB (688128 bytes)
heap-objects: 884956
stack-in-use: 34.78MB (36470784 bytes)
stack-sys: 34.78MB (36470784 bytes)
stack-mspan-inuse: 1.92MB (2014720 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 956.38KB (979337 bytes)
gc-sys: 5.06MB (5305488 bytes)
next-gc: when heap-alloc >= 147.24MB (154396952 bytes)
last-gc: 2024-10-25 10:28:52.0226134 +0000 UTC
gc-pause-total: 8.5416ms
gc-pause: 67586
gc-pause-end: 1729852132022613400
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00035495278010486624
enable-gc: true
debug-gc: false
