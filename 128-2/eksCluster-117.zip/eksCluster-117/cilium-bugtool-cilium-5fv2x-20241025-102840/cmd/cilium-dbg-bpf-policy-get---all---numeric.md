Endpoint ID: 499
Path: /sys/fs/bpf/tc/globals/cilium_policy_00499

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3848270   36459     0        
Allow    Ingress     1          ANY          NONE         disabled    3304387   33684     0        
Allow    Egress      0          ANY          NONE         disabled    4920520   45294     0        


Endpoint ID: 789
Path: /sys/fs/bpf/tc/globals/cilium_policy_00789

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77955   891       0        
Allow    Egress      0          ANY          NONE         disabled    12699   132       0        


Endpoint ID: 917
Path: /sys/fs/bpf/tc/globals/cilium_policy_00917

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2027
Path: /sys/fs/bpf/tc/globals/cilium_policy_02027

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79873   914       0        
Allow    Egress      0          ANY          NONE         disabled    14859   156       0        


Endpoint ID: 3355
Path: /sys/fs/bpf/tc/globals/cilium_policy_03355

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    436110   5561      0        
Allow    Ingress     1          ANY          NONE         disabled    11738    135       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


