KEY             VALUE
AgentLiveness   925414504678
UTimeOffset     3378615677734375
