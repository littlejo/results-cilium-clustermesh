29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:14:37+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:15:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
471: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:16:16+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 116
472: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:16:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 117
473: sched_cls  name tail_handle_ipv4  tag 16796bbb9d3a2d7c  gpl
	loaded_at 2024-10-25T10:16:16+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,97
	btf_id 118
474: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:16:16+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,97
	btf_id 119
477: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 123
478: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,99
	btf_id 124
479: sched_cls  name tail_handle_ipv4_from_host  tag 7c725ebfa65634eb  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,99
	btf_id 125
480: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,99
	btf_id 126
481: sched_cls  name __send_drop_notify  tag 7bd8ec39d9c24a08  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
484: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 131
485: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 132
486: sched_cls  name tail_handle_ipv4_from_host  tag 7c725ebfa65634eb  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 133
488: sched_cls  name __send_drop_notify  tag 7bd8ec39d9c24a08  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 135
490: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 138
491: sched_cls  name tail_handle_ipv4_from_host  tag 7c725ebfa65634eb  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 139
493: sched_cls  name __send_drop_notify  tag 7bd8ec39d9c24a08  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 141
494: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:16:17+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,103,75
	btf_id 142
507: sched_cls  name tail_ipv4_to_endpoint  tag 54bd5b7bf7f21c3a  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,107,41,82,83,80,98,39,108,40,37,38
	btf_id 157
508: sched_cls  name tail_handle_arp  tag 2108513e9b0d2586  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 158
509: sched_cls  name tail_handle_ipv4_cont  tag 11beb99d90854db0  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,107,41,98,82,83,39,76,74,77,108,40,37,38,81
	btf_id 159
510: sched_cls  name cil_from_container  tag 18e8409abf39a528  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 108,76
	btf_id 160
511: sched_cls  name tail_ipv4_ct_ingress  tag 2ebafbe5712c55dd  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 161
512: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 162
513: sched_cls  name tail_handle_ipv4  tag aac18c96cd3d2677  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 163
514: sched_cls  name __send_drop_notify  tag 5fb8de89e01c095c  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 164
516: sched_cls  name handle_policy  tag e684b03d81edd15f  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,108,82,83,107,41,80,98,39,84,75,40,37,38
	btf_id 166
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:18+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 167
518: sched_cls  name tail_handle_ipv4  tag 3b425afae42c0c93  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 169
519: sched_cls  name tail_ipv4_to_endpoint  tag 257fef48c6d31422  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,109,39,110,40,37,38
	btf_id 170
520: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 171
521: sched_cls  name tail_handle_arp  tag 653701220d2159db  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 172
523: sched_cls  name tail_ipv4_ct_ingress  tag 8233ba87ed433013  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,111,84
	btf_id 174
524: sched_cls  name handle_policy  tag 53c02563ad2cc7f9  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,111,41,80,109,39,84,75,40,37,38
	btf_id 175
525: sched_cls  name tail_ipv4_ct_egress  tag 60d3dcae2345e86a  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,111,84
	btf_id 176
526: sched_cls  name tail_handle_ipv4_cont  tag e01c2aa58b8ae259  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,111,41,109,82,83,39,76,74,77,110,40,37,38,81
	btf_id 177
527: sched_cls  name __send_drop_notify  tag d77ebaa5dd0fc0bf  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
528: sched_cls  name cil_from_container  tag 8a73b5b0a97164c9  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 179
529: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
533: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
536: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
537: sched_cls  name __send_drop_notify  tag c0e2ac8c18e8c7da  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 181
538: sched_cls  name tail_ipv4_ct_ingress  tag 6537a5b7d320d4a7  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 182
539: sched_cls  name tail_ipv4_to_endpoint  tag 130bdef689a6a5e8  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 183
540: sched_cls  name handle_policy  tag 0a6a48848a0cbb82  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 184
541: sched_cls  name tail_handle_ipv4  tag 30be21a14da46821  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 185
542: sched_cls  name tail_handle_arp  tag 7373dab1ea7cbf0e  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 186
543: sched_cls  name tail_ipv4_ct_egress  tag 60d3dcae2345e86a  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 187
544: sched_cls  name tail_handle_ipv4_cont  tag bc4ccfcc7ab79911  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 188
545: sched_cls  name cil_from_container  tag 6945cab9e66b2dd4  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 189
546: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 190
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
595: sched_cls  name tail_handle_ipv4  tag cba7a74c1f92bc34  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,131
	btf_id 205
596: sched_cls  name __send_drop_notify  tag cdf781569ce6c09a  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
597: sched_cls  name tail_handle_ipv4_cont  tag 5254ee5fd6d50cd6  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,130,41,129,82,83,39,76,74,77,131,40,37,38,81
	btf_id 207
598: sched_cls  name tail_ipv4_to_endpoint  tag 94722c5ec761e666  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,130,41,82,83,80,129,39,131,40,37,38
	btf_id 208
599: sched_cls  name cil_from_container  tag 46f3f173d15bfe10  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 131,76
	btf_id 209
600: sched_cls  name tail_ipv4_ct_egress  tag 216717afc1e3c986  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,131,82,83,130,84
	btf_id 210
601: sched_cls  name handle_policy  tag b9a0d4ce13656ab9  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,131,82,83,130,41,80,129,39,84,75,40,37,38
	btf_id 211
602: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,131
	btf_id 212
603: sched_cls  name tail_ipv4_ct_ingress  tag 1c56a8ab685f746c  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,131,82,83,130,84
	btf_id 213
604: sched_cls  name tail_handle_arp  tag 45063a0d3da052f8  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,131
	btf_id 214
606: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
609: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
622: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
625: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
630: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
633: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
