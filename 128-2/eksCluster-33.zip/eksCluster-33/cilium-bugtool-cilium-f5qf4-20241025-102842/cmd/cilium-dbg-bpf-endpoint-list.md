IP ADDRESS         LOCAL ENDPOINT INFO
10.33.0.244:0      id=3348  sec_id=2254015 flags=0x0000 ifindex=14  mac=72:B8:55:65:6C:E8 nodemac=CE:B8:93:F8:05:DA   
172.31.229.207:0   (localhost)                                                                                        
10.33.0.47:0       id=431   sec_id=2276158 flags=0x0000 ifindex=18  mac=AA:0D:EC:4E:D1:AD nodemac=9E:E5:83:3F:0F:62   
10.33.0.206:0      id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC     
10.33.0.4:0        id=2133  sec_id=2254015 flags=0x0000 ifindex=12  mac=D6:93:A5:66:FE:7C nodemac=C6:F9:AF:59:88:A0   
10.33.0.3:0        (localhost)                                                                                        
