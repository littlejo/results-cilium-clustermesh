top - 10:28:44 up 14 min,  0 users,  load average: 0.03, 0.18, 0.25
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 57.6 us, 21.2 sy,  0.0 ni, 21.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    816.6 free,    906.9 used,   2112.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2760.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1537844 274972  79076 S  20.0   7.0   0:19.16 cilium-+
    671 root      20   0 1240432  15652  10896 S   6.7   0.4   0:00.03 cilium-+
    760 root      20   0 1243764  19456  14080 S   6.7   0.5   0:00.01 hubble
    408 root      20   0 1228848   6964   3908 S   0.0   0.2   0:00.25 cilium-+
    709 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    717 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    742 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    754 root      20   0    2208    792    712 S   0.0   0.0   0:00.00 timeout
