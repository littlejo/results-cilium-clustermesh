alloc: 110.18MB (115529984 bytes)
total-alloc: 1.34GB (1437922000 bytes)
sys: 206.13MB (216147284 bytes)
lookups: 0
mallocs: 47936372
frees: 46746154
heap-alloc: 110.18MB (115529984 bytes)
heap-sys: 161.32MB (169156608 bytes)
heap-idle: 33.67MB (35307520 bytes)
heap-in-use: 127.65MB (133849088 bytes)
heap-released: 9.25MB (9699328 bytes)
heap-objects: 1190218
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 2.11MB (2208320 bytes)
stack-mspan-sys: 2.33MB (2448000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 825.29KB (845097 bytes)
gc-sys: 5.11MB (5359728 bytes)
next-gc: when heap-alloc >= 146.42MB (153527704 bytes)
last-gc: 2024-10-25 10:28:44.308071972 +0000 UTC
gc-pause-total: 18.363984ms
gc-pause: 6040922
gc-pause-end: 1729852124308071972
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0004063584568496308
enable-gc: true
debug-gc: false
