Endpoint ID: 431
Path: /sys/fs/bpf/tc/globals/cilium_policy_00431

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3879388   36339     0        
Allow    Ingress     1          ANY          NONE         disabled    3212340   32582     0        
Allow    Egress      0          ANY          NONE         disabled    4449068   41300     0        


Endpoint ID: 1393
Path: /sys/fs/bpf/tc/globals/cilium_policy_01393

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438338   5598      0        
Allow    Ingress     1          ANY          NONE         disabled    10430    120       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2133
Path: /sys/fs/bpf/tc/globals/cilium_policy_02133

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    70303   808       0        
Allow    Egress      0          ANY          NONE         disabled    14046   146       0        


Endpoint ID: 3133
Path: /sys/fs/bpf/tc/globals/cilium_policy_03133

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3348
Path: /sys/fs/bpf/tc/globals/cilium_policy_03348

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    70626   812       0        
Allow    Egress      0          ANY          NONE         disabled    12063   122       0        


