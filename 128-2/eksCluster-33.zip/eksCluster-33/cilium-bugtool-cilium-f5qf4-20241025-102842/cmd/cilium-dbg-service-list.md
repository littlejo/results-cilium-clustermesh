ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.170.128:443 (active)    
                                        2 => 172.31.216.221:443 (active)    
2    10.100.72.216:443   ClusterIP      1 => 172.31.229.207:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.33.0.4:53 (active)          
                                        2 => 10.33.0.244:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.33.0.4:9153 (active)        
                                        2 => 10.33.0.244:9153 (active)      
5    10.100.8.37:2379    ClusterIP      1 => 10.33.0.47:2379 (active)       
