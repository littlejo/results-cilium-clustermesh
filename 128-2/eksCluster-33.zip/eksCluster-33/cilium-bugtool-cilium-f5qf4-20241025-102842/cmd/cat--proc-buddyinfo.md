Node 0, zone      DMA     32     13     19     22     12     13      9     14      4      3    173 
Node 0, zone   Normal      5     48      3      4      3      1      2      1      2      3      8 
