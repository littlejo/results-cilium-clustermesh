REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     217507    84829237   1132   bpf_host.c
Interface                 INGRESS     9623      750353     677    bpf_overlay.c
Success                   EGRESS      4692      357329     1694   bpf_host.c
Success                   EGRESS      91793     12299032   1308   bpf_lxc.c
Success                   EGRESS      9549      743692     53     encap.h
Success                   INGRESS     103756    12663702   86     l3.h
Success                   INGRESS     109336    13100632   235    trace.h
Unsupported L3 protocol   EGRESS      46        3528       1492   bpf_lxc.c
