KEY             VALUE
AgentLiveness   885207409176
UTimeOffset     3378615759765625
