CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb557dc0f_168f_4aae_936d_86b6cee4cc42.slice/cri-containerd-7f5fa80ab2117c92a641878b107fd80dbf9b892735af1effa54300040266d8aa.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb557dc0f_168f_4aae_936d_86b6cee4cc42.slice/cri-containerd-0fd10f0d8a94a965f109099eeda882cea6743b717690ae098f3254e8f45dc7fa.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf220dd5e_49bd_42c5_88ce_abec7b7c68b5.slice/cri-containerd-e0fadaa4783a06263fd1a811c87e4249d6d0023040d8d0b7589d2c18584023ee.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf220dd5e_49bd_42c5_88ce_abec7b7c68b5.slice/cri-containerd-14be9a88ca80be5299cfb16a9f54da07bbf1e66b17c1929cfdf8951c7963184c.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ad7f2dd_f97d_4855_a8ac_e27883786cec.slice/cri-containerd-083b11d6e7ad79d5715c3df3beaca293cf13cf5cc6b8ef4c859e1e683481f2c8.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ad7f2dd_f97d_4855_a8ac_e27883786cec.slice/cri-containerd-c01cdc5fdb5df1b7ffdc9caf77b02b9dfb3bc6e92ad8eb474271263f74b51bbf.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bc310a3_1e17_490c_b9d1_4a8cbca64da1.slice/cri-containerd-7fb0e22111e49c8d295cf9a87b1de96f0c005039dd320b65c1b45c4d75d351d3.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bc310a3_1e17_490c_b9d1_4a8cbca64da1.slice/cri-containerd-a7841f9ec78ae9b0d771e6ba9fa5a884cb76662a6fc594afd710a482dd50fa60.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded9ed218_880b_4d9b_8821_3717c8bea708.slice/cri-containerd-369c98420d734be0ea2376e9f7567a4ba1e4acdebd311f80616e88a2f8eea119.scope
    625      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded9ed218_880b_4d9b_8821_3717c8bea708.slice/cri-containerd-9e8efd2a5c833bfb4c0250ec3af52beb44eae3c3abbed879b86874841dc18255.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded9ed218_880b_4d9b_8821_3717c8bea708.slice/cri-containerd-f5c419faaddcb4b462605b6400adfab79fcfa86184bb84e8ca8d84fd1495fa04.scope
    633      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded9ed218_880b_4d9b_8821_3717c8bea708.slice/cri-containerd-20d7180ee69b37dcf963760e837f94e665ed5490090bc0a58be57c926773ace5.scope
    609      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52ac467c_dfd1_471f_b6d8_795c514334cc.slice/cri-containerd-de1630312f4775d1ba7eb9d8926257b42d64f80e8be63adb65fd03e88224e50c.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52ac467c_dfd1_471f_b6d8_795c514334cc.slice/cri-containerd-642fb8602dbaf6b629ab55d86046edfc7680cd9729edb4b23490c257c782edb7.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7eb6670_bbd5_495f_b4a7_11fd5e46eb7d.slice/cri-containerd-f3aa1f26577943b9fe727ec9b8dad3803a0ff15445b60af7a297da0b9fe3e201.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7eb6670_bbd5_495f_b4a7_11fd5e46eb7d.slice/cri-containerd-7b4afbde45c8d4c3bd973907ef73ff8459c0ee601e61a42151108d0e5c31d8d8.scope
    99       cgroup_device   multi                                          
