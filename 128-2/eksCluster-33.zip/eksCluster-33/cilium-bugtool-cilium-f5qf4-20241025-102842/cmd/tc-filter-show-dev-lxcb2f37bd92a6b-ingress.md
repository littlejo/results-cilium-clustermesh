filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb2f37bd92a6b direct-action not_in_hw id 528 tag 8a73b5b0a97164c9 jited 
