key: af 01 00 00  value: 59 02 00 00
key: 71 05 00 00  value: 04 02 00 00
key: 55 08 00 00  value: 0c 02 00 00
key: 14 0d 00 00  value: 1c 02 00 00
Found 4 elements
