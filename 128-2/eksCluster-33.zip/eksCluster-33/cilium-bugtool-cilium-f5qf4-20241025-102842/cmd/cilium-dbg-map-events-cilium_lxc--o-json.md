{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:14.648Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.229.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:14.648Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.906Z",
  "value": "id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.936Z",
  "value": "id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.824Z",
  "value": "id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.854Z",
  "value": "id=2133  sec_id=2254015 flags=0x0000 ifindex=12  mac=D6:93:A5:66:FE:7C nodemac=C6:F9:AF:59:88:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:27.825Z",
  "value": "id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:27.826Z",
  "value": "id=2133  sec_id=2254015 flags=0x0000 ifindex=12  mac=D6:93:A5:66:FE:7C nodemac=C6:F9:AF:59:88:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.928Z",
  "value": "id=3348  sec_id=2254015 flags=0x0000 ifindex=14  mac=72:B8:55:65:6C:E8 nodemac=CE:B8:93:F8:05:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.090Z",
  "value": "id=2133  sec_id=2254015 flags=0x0000 ifindex=12  mac=D6:93:A5:66:FE:7C nodemac=C6:F9:AF:59:88:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.090Z",
  "value": "id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.090Z",
  "value": "id=3348  sec_id=2254015 flags=0x0000 ifindex=14  mac=72:B8:55:65:6C:E8 nodemac=CE:B8:93:F8:05:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.120Z",
  "value": "id=368   sec_id=2276158 flags=0x0000 ifindex=16  mac=86:A7:4F:3C:4B:62 nodemac=F6:52:F7:65:6D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.090Z",
  "value": "id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.090Z",
  "value": "id=368   sec_id=2276158 flags=0x0000 ifindex=16  mac=86:A7:4F:3C:4B:62 nodemac=F6:52:F7:65:6D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.091Z",
  "value": "id=2133  sec_id=2254015 flags=0x0000 ifindex=12  mac=D6:93:A5:66:FE:7C nodemac=C6:F9:AF:59:88:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.091Z",
  "value": "id=3348  sec_id=2254015 flags=0x0000 ifindex=14  mac=72:B8:55:65:6C:E8 nodemac=CE:B8:93:F8:05:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.767Z",
  "value": "id=431   sec_id=2276158 flags=0x0000 ifindex=18  mac=AA:0D:EC:4E:D1:AD nodemac=9E:E5:83:3F:0F:62"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.33.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.311Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.005Z",
  "value": "id=431   sec_id=2276158 flags=0x0000 ifindex=18  mac=AA:0D:EC:4E:D1:AD nodemac=9E:E5:83:3F:0F:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.009Z",
  "value": "id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.009Z",
  "value": "id=2133  sec_id=2254015 flags=0x0000 ifindex=12  mac=D6:93:A5:66:FE:7C nodemac=C6:F9:AF:59:88:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.010Z",
  "value": "id=3348  sec_id=2254015 flags=0x0000 ifindex=14  mac=72:B8:55:65:6C:E8 nodemac=CE:B8:93:F8:05:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.982Z",
  "value": "id=3348  sec_id=2254015 flags=0x0000 ifindex=14  mac=72:B8:55:65:6C:E8 nodemac=CE:B8:93:F8:05:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.982Z",
  "value": "id=2133  sec_id=2254015 flags=0x0000 ifindex=12  mac=D6:93:A5:66:FE:7C nodemac=C6:F9:AF:59:88:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.983Z",
  "value": "id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.983Z",
  "value": "id=431   sec_id=2276158 flags=0x0000 ifindex=18  mac=AA:0D:EC:4E:D1:AD nodemac=9E:E5:83:3F:0F:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.983Z",
  "value": "id=1393  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:BE:6B:7F:59 nodemac=2E:06:43:04:C4:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.983Z",
  "value": "id=431   sec_id=2276158 flags=0x0000 ifindex=18  mac=AA:0D:EC:4E:D1:AD nodemac=9E:E5:83:3F:0F:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.983Z",
  "value": "id=2133  sec_id=2254015 flags=0x0000 ifindex=12  mac=D6:93:A5:66:FE:7C nodemac=C6:F9:AF:59:88:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.984Z",
  "value": "id=3348  sec_id=2254015 flags=0x0000 ifindex=14  mac=72:B8:55:65:6C:E8 nodemac=CE:B8:93:F8:05:DA"
}

