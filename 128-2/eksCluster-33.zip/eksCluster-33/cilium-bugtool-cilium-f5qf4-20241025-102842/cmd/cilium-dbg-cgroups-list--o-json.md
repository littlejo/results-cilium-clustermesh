[
  {
    "containers": [
      {
        "cgroup-id": 7871,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bc310a3_1e17_490c_b9d1_4a8cbca64da1.slice/cri-containerd-7fb0e22111e49c8d295cf9a87b1de96f0c005039dd320b65c1b45c4d75d351d3.scope"
      }
    ],
    "ips": [
      "10.33.0.244"
    ],
    "name": "coredns-cc6ccd49c-bcxsk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf220dd5e_49bd_42c5_88ce_abec7b7c68b5.slice/cri-containerd-e0fadaa4783a06263fd1a811c87e4249d6d0023040d8d0b7589d2c18584023ee.scope"
      }
    ],
    "ips": [
      "10.33.0.4"
    ],
    "name": "coredns-cc6ccd49c-rpvwp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded9ed218_880b_4d9b_8821_3717c8bea708.slice/cri-containerd-9e8efd2a5c833bfb4c0250ec3af52beb44eae3c3abbed879b86874841dc18255.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded9ed218_880b_4d9b_8821_3717c8bea708.slice/cri-containerd-369c98420d734be0ea2376e9f7567a4ba1e4acdebd311f80616e88a2f8eea119.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded9ed218_880b_4d9b_8821_3717c8bea708.slice/cri-containerd-f5c419faaddcb4b462605b6400adfab79fcfa86184bb84e8ca8d84fd1495fa04.scope"
      }
    ],
    "ips": [
      "10.33.0.47"
    ],
    "name": "clustermesh-apiserver-6b6c6fb48c-khg5b",
    "namespace": "kube-system"
  }
]

