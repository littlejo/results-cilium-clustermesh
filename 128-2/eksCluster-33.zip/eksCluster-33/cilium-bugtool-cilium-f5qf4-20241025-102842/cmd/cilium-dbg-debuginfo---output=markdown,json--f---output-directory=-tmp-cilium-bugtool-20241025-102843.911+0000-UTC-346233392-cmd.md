markdown output at /tmp/cilium-bugtool-20241025-102843.911+0000-UTC-346233392/cmd/cilium-debuginfo-20241025-102914.61+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.911+0000-UTC-346233392/cmd/cilium-debuginfo-20241025-102914.61+0000-UTC.json
