1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:2c:ad:e2:c7:cf brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.229.207/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2755sec preferred_lft 2755sec
    inet6 fe80::82c:adff:fee2:c7cf/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether 0a:80:59:eb:64:a9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:71:19:37:28:ae brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c871:19ff:fe37:28ae/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:26:ca:e4:71:2b brd ff:ff:ff:ff:ff:ff
    inet 10.33.0.3/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1426:caff:fee4:712b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 52:db:e7:0b:79:1a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::50db:e7ff:fe0b:791a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:06:43:04:c4:cc brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2c06:43ff:fe04:c4cc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb2f37bd92a6b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:f9:af:59:88:a0 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c4f9:afff:fe59:88a0/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd4af8659d76d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:b8:93:f8:05:da brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ccb8:93ff:fef8:5da/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc282fc31e7f3@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:e5:83:3f:0f:62 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9ce5:83ff:fe3f:f62/64 scope link 
       valid_lft forever preferred_lft forever
