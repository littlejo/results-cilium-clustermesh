xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 494
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 484
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 477
cilium_host(7) clsact/egress cil_from_host-cilium_host id 480
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 474
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 471
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 510
lxcb2f37bd92a6b(12) clsact/ingress cil_from_container-lxcb2f37bd92a6b id 528
lxcd4af8659d76d(14) clsact/ingress cil_from_container-lxcd4af8659d76d id 545
lxcc282fc31e7f3(18) clsact/ingress cil_from_container-lxcc282fc31e7f3 id 599

flow_dissector:

netfilter:

