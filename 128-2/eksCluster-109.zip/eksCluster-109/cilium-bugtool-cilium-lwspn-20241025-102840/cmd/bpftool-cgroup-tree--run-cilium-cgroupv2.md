CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e6c7634_5fec_4cf3_b1ba_d45f23dcb140.slice/cri-containerd-7b31e948f493ee3407e8b6bb58322ede6f0c246df1895d5a965f3163e3dd57ca.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e6c7634_5fec_4cf3_b1ba_d45f23dcb140.slice/cri-containerd-862a0bd4f2e8cfdbc93c4e4d05221c3ee63f1ae72906dd1c859f1a006c663d82.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf015580d_269e_49cd_88b9_3f68e7afb37b.slice/cri-containerd-93ab55b76a35af45022423314f6315ce5cec92bcd9be1d00e509a3a00511982f.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf015580d_269e_49cd_88b9_3f68e7afb37b.slice/cri-containerd-dbc343c5d618daf2e2ebb937ef36244ab63c71d17d6a5d7890584a5596442f67.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6e16565d_62e2_46ab_871e_84ef23848719.slice/cri-containerd-5c8d3db23ef82de298ae96da51d47a20d2018c52ed68dc91e71d561ea983baf7.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6e16565d_62e2_46ab_871e_84ef23848719.slice/cri-containerd-79991547fcb41d29b8b5e1d9d6889ee2fa4ef3aa7b000c47541e04a123b132a4.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62af4ed0_786c_498c_ab88_9c1cc3c70b9e.slice/cri-containerd-824fa96c3630f04db578340bb16abcff8ca2c5a5ce50646458eef857fab79573.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62af4ed0_786c_498c_ab88_9c1cc3c70b9e.slice/cri-containerd-36081d0506be171d5c5f10cb58efa02499ba2d44fb0c86faf7603dc54d131bc0.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb40ae49c_ec07_4a1b_b7b6_08e17677fc36.slice/cri-containerd-b85b939724218a4677c880c994f223572a32dd200f8c3f876fae28cb32445597.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb40ae49c_ec07_4a1b_b7b6_08e17677fc36.slice/cri-containerd-2d3de96fddaf77df26ec82d96aa5136b050cf6eb25b3a4019e0cf311a5824a7c.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53c3bad6_d897_4d9d_ac6c_e3fc0cb1f4a5.slice/cri-containerd-50f82c2e247f899f3b90450ad86c18d7338e4c7eff5f2a15acc0b88a947b9727.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53c3bad6_d897_4d9d_ac6c_e3fc0cb1f4a5.slice/cri-containerd-59bc72a33500efa8f170779bc5c5d38435a05c9f9318f3276459fa2f8eae048e.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53c3bad6_d897_4d9d_ac6c_e3fc0cb1f4a5.slice/cri-containerd-491f9fa1a14bdd40e772f23f6807625e34986f3b9b311505ed3f1ad33beab606.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53c3bad6_d897_4d9d_ac6c_e3fc0cb1f4a5.slice/cri-containerd-f2f37a50e9a60cb69818d22756b1cdddc0626210bccaf7a6fe6d5810e354a4ad.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod60cad535_b249_4e0b_bb47_9e56bbb8f37f.slice/cri-containerd-1ae2133282ee2c17d4d99e73322e10baf0865bac930317406ee589397f8f56e0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod60cad535_b249_4e0b_bb47_9e56bbb8f37f.slice/cri-containerd-23b68b987a1f9fc29d6d4f08d786a64b41003e69a34e50ed85d3926f907c6468.scope
    98       cgroup_device   multi                                          
