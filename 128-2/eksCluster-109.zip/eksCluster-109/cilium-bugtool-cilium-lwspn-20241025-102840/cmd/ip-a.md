1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:7d:51:14:f4:3b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.224.45/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2825sec preferred_lft 2825sec
    inet6 fe80::87d:51ff:fe14:f43b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c7:af:96:74:31 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.244.253/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8c7:afff:fe96:7431/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:84:c9:78:a4:ba brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ec84:c9ff:fe78:a4ba/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:dd:79:f3:74:be brd ff:ff:ff:ff:ff:ff
    inet 10.109.0.243/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::78dd:79ff:fef3:74be/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:d2:eb:6c:e8:e1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3cd2:ebff:fe6c:e8e1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:5d:2a:ee:49:64 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2c5d:2aff:feee:4964/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc32144aacb2a9@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:f6:01:fd:87:16 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f4f6:1ff:fefd:8716/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7b0ef9ec4f73@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:d9:d2:38:c4:47 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::14d9:d2ff:fe38:c447/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc87c20f2c13ac@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:d9:7d:ed:38:5f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6cd9:7dff:feed:385f/64 scope link 
       valid_lft forever preferred_lft forever
