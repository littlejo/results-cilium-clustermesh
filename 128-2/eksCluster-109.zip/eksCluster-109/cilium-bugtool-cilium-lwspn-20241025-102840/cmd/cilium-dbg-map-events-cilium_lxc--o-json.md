{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.923Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.224.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.923Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.244.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.923Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.276Z",
  "value": "id=245   sec_id=4     flags=0x0000 ifindex=10  mac=AA:3D:C9:C2:0A:58 nodemac=2E:5D:2A:EE:49:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.276Z",
  "value": "id=1455  sec_id=7215329 flags=0x0000 ifindex=14  mac=3E:BF:8B:52:20:E0 nodemac=16:D9:D2:38:C4:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.348Z",
  "value": "id=1579  sec_id=7215329 flags=0x0000 ifindex=12  mac=42:0C:1E:87:48:A8 nodemac=F6:F6:01:FD:87:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.349Z",
  "value": "id=1455  sec_id=7215329 flags=0x0000 ifindex=14  mac=3E:BF:8B:52:20:E0 nodemac=16:D9:D2:38:C4:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.354Z",
  "value": "id=245   sec_id=4     flags=0x0000 ifindex=10  mac=AA:3D:C9:C2:0A:58 nodemac=2E:5D:2A:EE:49:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.915Z",
  "value": "id=1455  sec_id=7215329 flags=0x0000 ifindex=14  mac=3E:BF:8B:52:20:E0 nodemac=16:D9:D2:38:C4:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.915Z",
  "value": "id=245   sec_id=4     flags=0x0000 ifindex=10  mac=AA:3D:C9:C2:0A:58 nodemac=2E:5D:2A:EE:49:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.915Z",
  "value": "id=1579  sec_id=7215329 flags=0x0000 ifindex=12  mac=42:0C:1E:87:48:A8 nodemac=F6:F6:01:FD:87:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.946Z",
  "value": "id=2890  sec_id=7223452 flags=0x0000 ifindex=16  mac=82:6C:16:70:AF:FC nodemac=1A:84:95:8B:68:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:21.915Z",
  "value": "id=245   sec_id=4     flags=0x0000 ifindex=10  mac=AA:3D:C9:C2:0A:58 nodemac=2E:5D:2A:EE:49:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:21.915Z",
  "value": "id=1579  sec_id=7215329 flags=0x0000 ifindex=12  mac=42:0C:1E:87:48:A8 nodemac=F6:F6:01:FD:87:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:21.915Z",
  "value": "id=1455  sec_id=7215329 flags=0x0000 ifindex=14  mac=3E:BF:8B:52:20:E0 nodemac=16:D9:D2:38:C4:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:21.915Z",
  "value": "id=2890  sec_id=7223452 flags=0x0000 ifindex=16  mac=82:6C:16:70:AF:FC nodemac=1A:84:95:8B:68:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.327Z",
  "value": "id=439   sec_id=7223452 flags=0x0000 ifindex=18  mac=CE:5E:C0:30:71:15 nodemac=6E:D9:7D:ED:38:5F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.109.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.703Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:50.739Z",
  "value": "id=1579  sec_id=7215329 flags=0x0000 ifindex=12  mac=42:0C:1E:87:48:A8 nodemac=F6:F6:01:FD:87:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:50.739Z",
  "value": "id=245   sec_id=4     flags=0x0000 ifindex=10  mac=AA:3D:C9:C2:0A:58 nodemac=2E:5D:2A:EE:49:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:50.739Z",
  "value": "id=439   sec_id=7223452 flags=0x0000 ifindex=18  mac=CE:5E:C0:30:71:15 nodemac=6E:D9:7D:ED:38:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:50.739Z",
  "value": "id=1455  sec_id=7215329 flags=0x0000 ifindex=14  mac=3E:BF:8B:52:20:E0 nodemac=16:D9:D2:38:C4:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:51.739Z",
  "value": "id=1455  sec_id=7215329 flags=0x0000 ifindex=14  mac=3E:BF:8B:52:20:E0 nodemac=16:D9:D2:38:C4:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:51.740Z",
  "value": "id=1579  sec_id=7215329 flags=0x0000 ifindex=12  mac=42:0C:1E:87:48:A8 nodemac=F6:F6:01:FD:87:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:51.740Z",
  "value": "id=439   sec_id=7223452 flags=0x0000 ifindex=18  mac=CE:5E:C0:30:71:15 nodemac=6E:D9:7D:ED:38:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:51.741Z",
  "value": "id=245   sec_id=4     flags=0x0000 ifindex=10  mac=AA:3D:C9:C2:0A:58 nodemac=2E:5D:2A:EE:49:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:52.740Z",
  "value": "id=245   sec_id=4     flags=0x0000 ifindex=10  mac=AA:3D:C9:C2:0A:58 nodemac=2E:5D:2A:EE:49:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:52.741Z",
  "value": "id=1455  sec_id=7215329 flags=0x0000 ifindex=14  mac=3E:BF:8B:52:20:E0 nodemac=16:D9:D2:38:C4:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:52.741Z",
  "value": "id=1579  sec_id=7215329 flags=0x0000 ifindex=12  mac=42:0C:1E:87:48:A8 nodemac=F6:F6:01:FD:87:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:52.742Z",
  "value": "id=439   sec_id=7223452 flags=0x0000 ifindex=18  mac=CE:5E:C0:30:71:15 nodemac=6E:D9:7D:ED:38:5F"
}

