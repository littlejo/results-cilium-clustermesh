IP ADDRESS         LOCAL ENDPOINT INFO
10.109.0.196:0     id=245   sec_id=4     flags=0x0000 ifindex=10  mac=AA:3D:C9:C2:0A:58 nodemac=2E:5D:2A:EE:49:64     
10.109.0.5:0       id=439   sec_id=7223452 flags=0x0000 ifindex=18  mac=CE:5E:C0:30:71:15 nodemac=6E:D9:7D:ED:38:5F   
172.31.244.253:0   (localhost)                                                                                        
10.109.0.163:0     id=1455  sec_id=7215329 flags=0x0000 ifindex=14  mac=3E:BF:8B:52:20:E0 nodemac=16:D9:D2:38:C4:47   
172.31.224.45:0    (localhost)                                                                                        
10.109.0.211:0     id=1579  sec_id=7215329 flags=0x0000 ifindex=12  mac=42:0C:1E:87:48:A8 nodemac=F6:F6:01:FD:87:16   
10.109.0.243:0     (localhost)                                                                                        
