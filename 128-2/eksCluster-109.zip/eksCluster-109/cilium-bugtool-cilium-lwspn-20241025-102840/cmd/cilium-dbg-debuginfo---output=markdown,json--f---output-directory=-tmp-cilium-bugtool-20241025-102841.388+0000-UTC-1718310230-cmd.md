markdown output at /tmp/cilium-bugtool-20241025-102841.388+0000-UTC-1718310230/cmd/cilium-debuginfo-20241025-102912.068+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.388+0000-UTC-1718310230/cmd/cilium-debuginfo-20241025-102912.068+0000-UTC.json
