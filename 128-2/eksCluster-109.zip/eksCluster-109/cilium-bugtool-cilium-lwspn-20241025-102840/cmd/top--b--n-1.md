top - 10:28:41 up 13 min,  0 users,  load average: 0.01, 0.08, 0.10
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 14.3 us, 28.6 sy,  0.0 ni, 57.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    805.7 free,    888.7 used,   2141.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2778.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    572 root      20   0 1240432  16196  11292 S   6.7   0.4   0:00.02 cilium-+
      1 root      20   0 1472240 271980  78972 S   0.0   6.9   0:16.86 cilium-+
    393 root      20   0 1228848   6384   3840 S   0.0   0.2   0:00.24 cilium-+
    625 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    642 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
    660 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    661 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
