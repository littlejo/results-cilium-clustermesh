REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     206245    83295379   1132   bpf_host.c
Interface                 INGRESS     9419      736837     677    bpf_overlay.c
Success                   EGRESS      4535      346623     1694   bpf_host.c
Success                   EGRESS      85472     11992682   1308   bpf_lxc.c
Success                   EGRESS      9190      720562     53     encap.h
Success                   INGRESS     101226    12129114   235    trace.h
Success                   INGRESS     95693     11694994   86     l3.h
Unsupported L3 protocol   EGRESS      42        3172       1492   bpf_lxc.c
