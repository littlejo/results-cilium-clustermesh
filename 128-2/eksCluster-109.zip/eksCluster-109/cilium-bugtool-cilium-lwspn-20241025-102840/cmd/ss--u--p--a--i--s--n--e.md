Total: 544
TCP:   1068 (estab 296, closed 753, orphaned 0, timewait 294)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  315       305       10       
INET	  325       311       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:36389      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:25081 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.224.45%ens5:68         0.0.0.0:*    uid:192 ino:15712 sk:1002 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24242 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15583 sk:1004 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24241 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15584 sk:1006 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::87d:51ff:fe14:f43b]%ens5:546           [::]:*    uid:192 ino:15709 sk:1007 cgroup:unreachable:c4e v6only:1 <->                   
