Endpoint ID: 245
Path: /sys/fs/bpf/tc/globals/cilium_policy_00245

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435007   5545      0        
Allow    Ingress     1          ANY          NONE         disabled    10624    124       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 439
Path: /sys/fs/bpf/tc/globals/cilium_policy_00439

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3827758   34822     0        
Allow    Ingress     1          ANY          NONE         disabled    2653298   26404     0        
Allow    Egress      0          ANY          NONE         disabled    3503046   32762     0        


Endpoint ID: 1091
Path: /sys/fs/bpf/tc/globals/cilium_policy_01091

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1455
Path: /sys/fs/bpf/tc/globals/cilium_policy_01455

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68146   783       0        
Allow    Egress      0          ANY          NONE         disabled    12369   126       0        


Endpoint ID: 1579
Path: /sys/fs/bpf/tc/globals/cilium_policy_01579

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    67156   768       0        
Allow    Egress      0          ANY          NONE         disabled    13042   134       0        


