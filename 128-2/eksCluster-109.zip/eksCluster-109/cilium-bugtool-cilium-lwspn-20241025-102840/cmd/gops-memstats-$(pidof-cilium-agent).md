alloc: 93.47MB (98013200 bytes)
total-alloc: 1.28GB (1379068168 bytes)
sys: 202.07MB (211884356 bytes)
lookups: 0
mallocs: 47117603
frees: 46212257
heap-alloc: 93.47MB (98013200 bytes)
heap-sys: 157.38MB (165027840 bytes)
heap-idle: 42.33MB (44384256 bytes)
heap-in-use: 115.05MB (120643584 bytes)
heap-released: 2.00MB (2097152 bytes)
heap-objects: 905346
stack-in-use: 34.59MB (36274176 bytes)
stack-sys: 34.59MB (36274176 bytes)
stack-mspan-inuse: 1.91MB (1999360 bytes)
stack-mspan-sys: 2.38MB (2496960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 753.27KB (771353 bytes)
gc-sys: 5.08MB (5323968 bytes)
next-gc: when heap-alloc >= 146.69MB (153817288 bytes)
last-gc: 2024-10-25 10:28:51.378067164 +0000 UTC
gc-pause-total: 5.653775ms
gc-pause: 120567
gc-pause-end: 1729852131378067164
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003535321195466247
enable-gc: true
debug-gc: false
