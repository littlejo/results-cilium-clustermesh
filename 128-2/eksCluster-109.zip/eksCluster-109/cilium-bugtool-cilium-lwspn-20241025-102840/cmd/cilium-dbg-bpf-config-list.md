KEY             VALUE
AgentLiveness   816484843132
UTimeOffset     3378615888671875
