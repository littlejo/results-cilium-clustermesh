ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.129.81:443 (active)    
                                         2 => 172.31.200.19:443 (active)    
2    10.100.234.9:443     ClusterIP      1 => 172.31.224.45:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.109.0.163:53 (active)      
                                         2 => 10.109.0.211:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.109.0.163:9153 (active)    
                                         2 => 10.109.0.211:9153 (active)    
5    10.100.44.112:2379   ClusterIP      1 => 10.109.0.5:2379 (active)      
