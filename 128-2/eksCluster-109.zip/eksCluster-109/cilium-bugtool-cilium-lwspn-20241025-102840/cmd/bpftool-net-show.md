xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 494
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 491
cilium_host(7) clsact/egress cil_from_host-cilium_host id 487
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 536
lxc32144aacb2a9(12) clsact/ingress cil_from_container-lxc32144aacb2a9 id 553
lxc7b0ef9ec4f73(14) clsact/ingress cil_from_container-lxc7b0ef9ec4f73 id 521
lxc87c20f2c13ac(18) clsact/ingress cil_from_container-lxc87c20f2c13ac id 614

flow_dissector:

netfilter:

