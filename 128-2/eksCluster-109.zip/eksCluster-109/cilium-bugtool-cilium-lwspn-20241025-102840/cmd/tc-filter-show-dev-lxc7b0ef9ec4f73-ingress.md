filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7b0ef9ec4f73 direct-action not_in_hw id 521 tag f4375e3d0001d4f7 jited 
