USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         572  1.0  0.4 1240432 16196 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         618  0.0  0.0   6408  1648 ?        R    10:28   0:00  \_ ps auxfw
root         624  0.0  0.0   3852  1292 ?        R    10:28   0:00  \_ bash -c hostname
root           1  2.3  6.8 1472240 270876 ?      Ssl  10:16   0:16 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1228848 6384 ?        Sl   10:17   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
