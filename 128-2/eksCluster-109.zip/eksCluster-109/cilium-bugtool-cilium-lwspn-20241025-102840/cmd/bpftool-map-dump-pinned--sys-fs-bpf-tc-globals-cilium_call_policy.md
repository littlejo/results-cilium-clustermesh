key: f5 00 00 00  value: 23 02 00 00
key: b7 01 00 00  value: 64 02 00 00
key: af 05 00 00  value: 14 02 00 00
key: 2b 06 00 00  value: 20 02 00 00
Found 4 elements
