[
  {
    "containers": [
      {
        "cgroup-id": 9220,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53c3bad6_d897_4d9d_ac6c_e3fc0cb1f4a5.slice/cri-containerd-50f82c2e247f899f3b90450ad86c18d7338e4c7eff5f2a15acc0b88a947b9727.scope"
      },
      {
        "cgroup-id": 9136,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53c3bad6_d897_4d9d_ac6c_e3fc0cb1f4a5.slice/cri-containerd-59bc72a33500efa8f170779bc5c5d38435a05c9f9318f3276459fa2f8eae048e.scope"
      },
      {
        "cgroup-id": 9304,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53c3bad6_d897_4d9d_ac6c_e3fc0cb1f4a5.slice/cri-containerd-491f9fa1a14bdd40e772f23f6807625e34986f3b9b311505ed3f1ad33beab606.scope"
      }
    ],
    "ips": [
      "10.109.0.5"
    ],
    "name": "clustermesh-apiserver-57dfd86f8f-ff77t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6e16565d_62e2_46ab_871e_84ef23848719.slice/cri-containerd-5c8d3db23ef82de298ae96da51d47a20d2018c52ed68dc91e71d561ea983baf7.scope"
      }
    ],
    "ips": [
      "10.109.0.211"
    ],
    "name": "coredns-cc6ccd49c-hkfbp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf015580d_269e_49cd_88b9_3f68e7afb37b.slice/cri-containerd-dbc343c5d618daf2e2ebb937ef36244ab63c71d17d6a5d7890584a5596442f67.scope"
      }
    ],
    "ips": [
      "10.109.0.163"
    ],
    "name": "coredns-cc6ccd49c-5b4rc",
    "namespace": "kube-system"
  }
]

