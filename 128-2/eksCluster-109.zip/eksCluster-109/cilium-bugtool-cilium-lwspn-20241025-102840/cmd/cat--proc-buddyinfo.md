Node 0, zone      DMA    133     60      2     22     10      2      1      2      3      4    168 
Node 0, zone   Normal    186     19      2      1     17     12      4      3      2      1      8 
