filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc87c20f2c13ac direct-action not_in_hw id 614 tag 12a7b583996f856f jited 
