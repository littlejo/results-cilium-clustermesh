{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:12.344Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:12.344Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:16.675Z",
  "value": "id=170   sec_id=1321319 flags=0x0000 ifindex=11  mac=7E:40:62:44:54:82 nodemac=4E:86:DB:24:FF:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:16.680Z",
  "value": "id=720   sec_id=1321319 flags=0x0000 ifindex=9   mac=76:38:25:79:94:96 nodemac=6A:0A:89:49:B0:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:16.739Z",
  "value": "id=2763  sec_id=4     flags=0x0000 ifindex=7   mac=FE:15:CE:37:33:35 nodemac=C6:5F:63:D1:3F:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:16.747Z",
  "value": "id=720   sec_id=1321319 flags=0x0000 ifindex=9   mac=76:38:25:79:94:96 nodemac=6A:0A:89:49:B0:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.559Z",
  "value": "id=2763  sec_id=4     flags=0x0000 ifindex=7   mac=FE:15:CE:37:33:35 nodemac=C6:5F:63:D1:3F:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.560Z",
  "value": "id=720   sec_id=1321319 flags=0x0000 ifindex=9   mac=76:38:25:79:94:96 nodemac=6A:0A:89:49:B0:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.560Z",
  "value": "id=170   sec_id=1321319 flags=0x0000 ifindex=11  mac=7E:40:62:44:54:82 nodemac=4E:86:DB:24:FF:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.588Z",
  "value": "id=3916  sec_id=1317395 flags=0x0000 ifindex=13  mac=62:41:49:74:5B:68 nodemac=66:5D:15:2B:81:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:36.560Z",
  "value": "id=3916  sec_id=1317395 flags=0x0000 ifindex=13  mac=62:41:49:74:5B:68 nodemac=66:5D:15:2B:81:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:36.560Z",
  "value": "id=720   sec_id=1321319 flags=0x0000 ifindex=9   mac=76:38:25:79:94:96 nodemac=6A:0A:89:49:B0:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:36.561Z",
  "value": "id=170   sec_id=1321319 flags=0x0000 ifindex=11  mac=7E:40:62:44:54:82 nodemac=4E:86:DB:24:FF:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:36.561Z",
  "value": "id=2763  sec_id=4     flags=0x0000 ifindex=7   mac=FE:15:CE:37:33:35 nodemac=C6:5F:63:D1:3F:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.148Z",
  "value": "id=3834  sec_id=1317395 flags=0x0000 ifindex=15  mac=56:25:55:FB:A6:30 nodemac=D6:DF:5C:60:31:B3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.19.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:19.488Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.427Z",
  "value": "id=720   sec_id=1321319 flags=0x0000 ifindex=9   mac=76:38:25:79:94:96 nodemac=6A:0A:89:49:B0:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.427Z",
  "value": "id=170   sec_id=1321319 flags=0x0000 ifindex=11  mac=7E:40:62:44:54:82 nodemac=4E:86:DB:24:FF:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.427Z",
  "value": "id=2763  sec_id=4     flags=0x0000 ifindex=7   mac=FE:15:CE:37:33:35 nodemac=C6:5F:63:D1:3F:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.428Z",
  "value": "id=3834  sec_id=1317395 flags=0x0000 ifindex=15  mac=56:25:55:FB:A6:30 nodemac=D6:DF:5C:60:31:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.427Z",
  "value": "id=2763  sec_id=4     flags=0x0000 ifindex=7   mac=FE:15:CE:37:33:35 nodemac=C6:5F:63:D1:3F:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.428Z",
  "value": "id=720   sec_id=1321319 flags=0x0000 ifindex=9   mac=76:38:25:79:94:96 nodemac=6A:0A:89:49:B0:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.428Z",
  "value": "id=3834  sec_id=1317395 flags=0x0000 ifindex=15  mac=56:25:55:FB:A6:30 nodemac=D6:DF:5C:60:31:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.428Z",
  "value": "id=170   sec_id=1321319 flags=0x0000 ifindex=11  mac=7E:40:62:44:54:82 nodemac=4E:86:DB:24:FF:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.428Z",
  "value": "id=720   sec_id=1321319 flags=0x0000 ifindex=9   mac=76:38:25:79:94:96 nodemac=6A:0A:89:49:B0:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.428Z",
  "value": "id=2763  sec_id=4     flags=0x0000 ifindex=7   mac=FE:15:CE:37:33:35 nodemac=C6:5F:63:D1:3F:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.429Z",
  "value": "id=170   sec_id=1321319 flags=0x0000 ifindex=11  mac=7E:40:62:44:54:82 nodemac=4E:86:DB:24:FF:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.429Z",
  "value": "id=3834  sec_id=1317395 flags=0x0000 ifindex=15  mac=56:25:55:FB:A6:30 nodemac=D6:DF:5C:60:31:B3"
}

