USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         645  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         614  2.0  0.4 1240176 16500 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         665  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         666  0.0  0.4 1240176 16500 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         604  0.0  0.1 1228744 3976 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         584  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  2.1  7.2 1538100 285120 ?      Ssl  10:13   0:20 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.0  0.1 1228848 5744 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
