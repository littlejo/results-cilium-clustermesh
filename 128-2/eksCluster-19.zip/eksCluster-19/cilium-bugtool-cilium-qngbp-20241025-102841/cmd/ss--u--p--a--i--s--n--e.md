Total: 549
TCP:   1085 (estab 317, closed 749, orphaned 0, timewait 285)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  336       324       12       
INET	  346       330       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:36853      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:20412 sk:262 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.210.89%ens5:68         0.0.0.0:*    uid:192 ino:15355 sk:263 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:21473 sk:264 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15603 sk:265 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:21472 sk:266 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15604 sk:267 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8a4:59ff:fe34:62f7]%ens5:546           [::]:*    uid:192 ino:15655 sk:268 cgroup:unreachable:c4e v6only:1 <->                   
