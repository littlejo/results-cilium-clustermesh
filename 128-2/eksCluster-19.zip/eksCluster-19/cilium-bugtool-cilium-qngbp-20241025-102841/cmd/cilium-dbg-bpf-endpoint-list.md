IP ADDRESS        LOCAL ENDPOINT INFO
10.19.0.12:0      (localhost)                                                                                        
10.19.0.59:0      id=720   sec_id=1321319 flags=0x0000 ifindex=9   mac=76:38:25:79:94:96 nodemac=6A:0A:89:49:B0:34   
10.19.0.39:0      id=170   sec_id=1321319 flags=0x0000 ifindex=11  mac=7E:40:62:44:54:82 nodemac=4E:86:DB:24:FF:3D   
172.31.210.89:0   (localhost)                                                                                        
10.19.0.84:0      id=2763  sec_id=4     flags=0x0000 ifindex=7   mac=FE:15:CE:37:33:35 nodemac=C6:5F:63:D1:3F:B6     
10.19.0.14:0      id=3834  sec_id=1317395 flags=0x0000 ifindex=15  mac=56:25:55:FB:A6:30 nodemac=D6:DF:5C:60:31:B3   
