xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 511
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 499
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 497
cilium_host(4) clsact/egress cil_from_host-cilium_host id 495
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 443
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 444
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 489
lxc07e944ff84cc(9) clsact/ingress cil_from_container-lxc07e944ff84cc id 517
lxcfe369812c272(11) clsact/ingress cil_from_container-lxcfe369812c272 id 485
lxc2556799e7507(15) clsact/ingress cil_from_container-lxc2556799e7507 id 589

flow_dissector:

netfilter:

