[
  {
    "containers": [
      {
        "cgroup-id": 8291,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e7b9daa_4caf_4bb6_90c5_fef2a2ca8b69.slice/cri-containerd-c5f0d3f009d0ae140980ad2661a6e516c57ecd751843c6417ce12ad573331dd2.scope"
      },
      {
        "cgroup-id": 8207,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e7b9daa_4caf_4bb6_90c5_fef2a2ca8b69.slice/cri-containerd-e6783fb7fd1247a04a7815722d8549fae735b06ee8ac04fd0d3d9dec50ff7aec.scope"
      },
      {
        "cgroup-id": 8375,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e7b9daa_4caf_4bb6_90c5_fef2a2ca8b69.slice/cri-containerd-95edd6949d6b2ea6d97ab2698e8f0497cc5e0d0f516ebfb51f0d5376286d91f4.scope"
      }
    ],
    "ips": [
      "10.19.0.14"
    ],
    "name": "clustermesh-apiserver-69cbc8f474-9zm8g",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6863,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a7a6ae8_ade7_4070_b48c_8866916973d3.slice/cri-containerd-6a372fcbab27d15e4221336f6e862c22c352f6a42e58da40c418f7b7d3799e37.scope"
      }
    ],
    "ips": [
      "10.19.0.39"
    ],
    "name": "coredns-cc6ccd49c-smwz4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6779,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9104c56e_153a_42a5_ac85_cbed20d7bb10.slice/cri-containerd-7371a1091c966c8ec60a726f3de77fa990f8eb5de215a19d7d99a8dc472cd68d.scope"
      }
    ],
    "ips": [
      "10.19.0.59"
    ],
    "name": "coredns-cc6ccd49c-xs66j",
    "namespace": "kube-system"
  }
]

