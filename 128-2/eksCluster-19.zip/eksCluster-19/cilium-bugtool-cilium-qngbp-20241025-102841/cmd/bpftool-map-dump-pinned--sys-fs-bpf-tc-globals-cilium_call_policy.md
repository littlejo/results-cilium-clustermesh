key: aa 00 00 00  value: d6 01 00 00
key: d0 02 00 00  value: 08 02 00 00
key: cb 0a 00 00  value: 0a 02 00 00
key: fa 0e 00 00  value: 4f 02 00 00
Found 4 elements
