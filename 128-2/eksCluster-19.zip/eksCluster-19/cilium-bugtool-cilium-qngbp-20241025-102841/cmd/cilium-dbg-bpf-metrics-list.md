REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     213465    99813004   1132   bpf_host.c
Interface                 INGRESS     8860      689373     677    bpf_overlay.c
Success                   EGRESS      3943      298130     1694   bpf_host.c
Success                   EGRESS      8453      658841     53     encap.h
Success                   EGRESS      89341     11953120   1308   bpf_lxc.c
Success                   INGRESS     105179    12715655   235    trace.h
Success                   INGRESS     99613     12280506   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
