29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:32+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
55: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
58: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
59: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
62: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
441: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:14+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 112
442: sched_cls  name tail_handle_ipv4  tag bc3d530a3feb2e30  gpl
	loaded_at 2024-10-25T10:13:14+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 113
443: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:14+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 114
444: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:14+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 115
468: sched_cls  name tail_ipv4_ct_egress  tag d8561f0d37b5ff19  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,100,76
	btf_id 144
469: sched_cls  name tail_handle_ipv4_cont  tag f9d16406ddbc1d96  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,97,74,75,31,68,66,69,101,32,29,30,73
	btf_id 145
470: sched_cls  name handle_policy  tag 6e56c4f0f3f46e51  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,101,74,75,100,33,72,97,31,76,67,32,29,30
	btf_id 146
475: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,101
	btf_id 151
477: sched_cls  name tail_ipv4_ct_ingress  tag 10b974f145a0b881  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,100,76
	btf_id 152
478: sched_cls  name __send_drop_notify  tag fd9c1cbf8efe959d  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 154
479: sched_cls  name tail_handle_arp  tag fc0b003666fc4b3c  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,101
	btf_id 156
481: sched_cls  name tail_ipv4_to_endpoint  tag 0388339f2760b273  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,97,31,101,32,29,30
	btf_id 158
484: sched_cls  name tail_handle_ipv4  tag f9ede7c03c36df37  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,101
	btf_id 159
485: sched_cls  name cil_from_container  tag c11b71fc377ef17b  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,68
	btf_id 162
487: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 165
488: sched_cls  name __send_drop_notify  tag 094d137b48e30bc4  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 166
489: sched_cls  name cil_from_container  tag d72d8af454989834  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 103,68
	btf_id 167
491: sched_cls  name __send_drop_notify  tag 2671c57182313cbb  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 170
492: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,106
	btf_id 171
494: sched_cls  name tail_handle_ipv4_from_host  tag b3e0ac109256d673  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,106
	btf_id 173
495: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,106
	btf_id 174
497: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 176
498: sched_cls  name tail_ipv4_to_endpoint  tag 0ed80d48044361dc  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,104,33,74,75,72,102,31,103,32,29,30
	btf_id 168
499: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 179
500: sched_cls  name __send_drop_notify  tag 2671c57182313cbb  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 180
501: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,107
	btf_id 181
503: sched_cls  name tail_handle_ipv4_from_host  tag b3e0ac109256d673  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,107
	btf_id 183
504: sched_cls  name tail_handle_ipv4_cont  tag 910c4933064de3d4  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,104,33,102,74,75,31,68,66,69,103,32,29,30,73
	btf_id 178
509: sched_cls  name __send_drop_notify  tag 2671c57182313cbb  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 190
510: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 191
511: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,109,67
	btf_id 192
512: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 186
513: sched_cls  name tail_handle_ipv4_from_host  tag b3e0ac109256d673  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 193
516: sched_cls  name tail_handle_ipv4  tag 6c971c91a863c322  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,111
	btf_id 198
517: sched_cls  name cil_from_container  tag 9bd292888f84d3bf  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,68
	btf_id 199
518: sched_cls  name __send_drop_notify  tag a0d9decb9dc7e7d0  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 200
519: sched_cls  name tail_handle_arp  tag 712497235fde10a8  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,111
	btf_id 201
520: sched_cls  name handle_policy  tag 5e8ef785deccb78d  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,111,74,75,112,33,72,90,31,76,67,32,29,30
	btf_id 202
521: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,111
	btf_id 203
522: sched_cls  name handle_policy  tag fe75a5b12487f260  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,103,74,75,104,33,72,102,31,76,67,32,29,30
	btf_id 194
523: sched_cls  name tail_ipv4_to_endpoint  tag 2ec8f0f5e8932f04  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,112,33,74,75,72,90,31,111,32,29,30
	btf_id 204
524: sched_cls  name tail_handle_ipv4_cont  tag 287962d72c7a9a83  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,112,33,90,74,75,31,68,66,69,111,32,29,30,73
	btf_id 206
525: sched_cls  name tail_handle_ipv4  tag b7ab8675f4be7552  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 205
526: sched_cls  name tail_handle_arp  tag 946af4da763b7fed  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 207
527: sched_cls  name tail_ipv4_ct_ingress  tag 9195377748fc4a76  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 208
528: sched_cls  name tail_ipv4_ct_egress  tag d8561f0d37b5ff19  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 209
529: sched_cls  name tail_ipv4_ct_ingress  tag 44944511ef058e6a  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 210
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,128
	btf_id 227
587: sched_cls  name tail_ipv4_ct_ingress  tag fe5cf5ea1dc3fea9  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 228
588: sched_cls  name tail_ipv4_ct_egress  tag cfa43a6621b75dd6  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 229
589: sched_cls  name cil_from_container  tag 72ec8068361e6c0a  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,68
	btf_id 230
590: sched_cls  name tail_ipv4_to_endpoint  tag a50b57a8cca71f79  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,129,33,74,75,72,127,31,128,32,29,30
	btf_id 231
591: sched_cls  name handle_policy  tag 884ed36bfb3afe90  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,128,74,75,129,33,72,127,31,76,67,32,29,30
	btf_id 232
592: sched_cls  name __send_drop_notify  tag 484209b9ad9a493b  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 233
594: sched_cls  name tail_handle_ipv4  tag 2ccff35fa98ebbbd  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,128
	btf_id 235
595: sched_cls  name tail_handle_ipv4_cont  tag a36aa298db65aea7  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,129,33,127,74,75,31,68,66,69,128,32,29,30,73
	btf_id 236
596: sched_cls  name tail_handle_arp  tag 3da96351433fdf9a  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,128
	btf_id 237
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
