1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a4:59:34:62:f7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.210.89/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2632sec preferred_lft 2632sec
    inet6 fe80::8a4:59ff:fe34:62f7/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:99:3e:16:0c:cb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7499:3eff:fe16:ccb/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:64:15:08:79:ef brd ff:ff:ff:ff:ff:ff
    inet 10.19.0.12/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b064:15ff:fe08:79ef/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6e:17:aa:05:cf:f0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c17:aaff:fe05:cff0/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:5f:63:d1:3f:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c45f:63ff:fed1:3fb6/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc07e944ff84cc@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:0a:89:49:b0:34 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::680a:89ff:fe49:b034/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcfe369812c272@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:86:db:24:ff:3d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4c86:dbff:fe24:ff3d/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc2556799e7507@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:df:5c:60:31:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d4df:5cff:fe60:31b3/64 scope link 
       valid_lft forever preferred_lft forever
