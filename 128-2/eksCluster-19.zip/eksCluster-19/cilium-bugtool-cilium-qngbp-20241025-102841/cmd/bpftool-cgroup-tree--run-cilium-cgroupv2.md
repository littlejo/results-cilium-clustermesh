CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda21e674c_fbc7_4c0a_893b_cfffaff10784.slice/cri-containerd-49d42cc832ec09ce9eca6e6deb492a172381713562821b7dfc972b20e426e835.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda21e674c_fbc7_4c0a_893b_cfffaff10784.slice/cri-containerd-835509ccd9f845d127170919a0e559acf96ff252b1fe23a08663de65a4c75c57.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1340a539_3ac4_4e17_9d99_b5ce75c79f1e.slice/cri-containerd-4e26728e73173a721c01e89aeda63c8b21f7653ec429f0c67494d8feafbade73.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1340a539_3ac4_4e17_9d99_b5ce75c79f1e.slice/cri-containerd-9ade6c4f893b2c9034839e2bc44461b2adf99d8e063b1056ce98f929f552f470.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a7a6ae8_ade7_4070_b48c_8866916973d3.slice/cri-containerd-6a372fcbab27d15e4221336f6e862c22c352f6a42e58da40c418f7b7d3799e37.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a7a6ae8_ade7_4070_b48c_8866916973d3.slice/cri-containerd-6550ab4db412773967b17ea0284bed80bf4a8877b57b64f7adc3612731c38549.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9104c56e_153a_42a5_ac85_cbed20d7bb10.slice/cri-containerd-3523df9062e6a8909e3d07e046947ef9abc7050d728fa9fc4e27164976e8e72c.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9104c56e_153a_42a5_ac85_cbed20d7bb10.slice/cri-containerd-7371a1091c966c8ec60a726f3de77fa990f8eb5de215a19d7d99a8dc472cd68d.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79b2d933_52b6_45f6_b4be_eda61be563cc.slice/cri-containerd-d51b7799bc2c881b38fc6025c10002f9d255ada10bef95adff71d2c8364c6061.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79b2d933_52b6_45f6_b4be_eda61be563cc.slice/cri-containerd-fc9179fc650ecb2505594eab0cfedf636a283038b1432fbacc712adc436a1811.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e7b9daa_4caf_4bb6_90c5_fef2a2ca8b69.slice/cri-containerd-6bde397fdb72377e58b45c93d8e176b374deac605d84a6eafa9658599008c428.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e7b9daa_4caf_4bb6_90c5_fef2a2ca8b69.slice/cri-containerd-95edd6949d6b2ea6d97ab2698e8f0497cc5e0d0f516ebfb51f0d5376286d91f4.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e7b9daa_4caf_4bb6_90c5_fef2a2ca8b69.slice/cri-containerd-c5f0d3f009d0ae140980ad2661a6e516c57ecd751843c6417ce12ad573331dd2.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e7b9daa_4caf_4bb6_90c5_fef2a2ca8b69.slice/cri-containerd-e6783fb7fd1247a04a7815722d8549fae735b06ee8ac04fd0d3d9dec50ff7aec.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda265a269_8230_403b_95f0_8f043dbf3eb4.slice/cri-containerd-247b7d57085afacea4a25e73282a17b4030cbb558614d898d14ac922fc510fea.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda265a269_8230_403b_95f0_8f043dbf3eb4.slice/cri-containerd-b04943e45f6dcc0819d4dd3b067c209ae79c764547f8f93d0f32675593144d5e.scope
    58       cgroup_device   multi                                          
