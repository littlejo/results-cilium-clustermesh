top - 10:28:42 up 16 min,  0 users,  load average: 0.08, 0.17, 0.17
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.0 us, 36.7 sy,  0.0 ni, 16.7 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,   1174.7 free,    905.1 used,   1756.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2762.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 290216  79404 S  26.7   7.4   0:20.32 cilium-+
    725 root      20   0 1243828  19220  13696 R  13.3   0.5   0:00.02 hubble
    614 root      20   0 1240432  16748  11548 S   6.7   0.4   0:00.03 cilium-+
    392 root      20   0 1228848   5744   2872 S   0.0   0.1   0:00.25 cilium-+
    669 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    695 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
    700 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    719 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
