alloc: 89.38MB (93724904 bytes)
total-alloc: 1.33GB (1428582200 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47702935
frees: 46846429
heap-alloc: 89.38MB (93724904 bytes)
heap-sys: 165.66MB (173711360 bytes)
heap-idle: 48.30MB (50651136 bytes)
heap-in-use: 117.36MB (123060224 bytes)
heap-released: 640.00KB (655360 bytes)
heap-objects: 856506
stack-in-use: 34.31MB (35979264 bytes)
stack-sys: 34.31MB (35979264 bytes)
stack-mspan-inuse: 1.94MB (2038560 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 924.08KB (946257 bytes)
gc-sys: 5.16MB (5413240 bytes)
next-gc: when heap-alloc >= 146.36MB (153470248 bytes)
last-gc: 2024-10-25 10:28:50.970265602 +0000 UTC
gc-pause-total: 8.712084ms
gc-pause: 89730
gc-pause-end: 1729852130970265602
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0002864880364951426
enable-gc: true
debug-gc: false
