Endpoint ID: 170
Path: /sys/fs/bpf/tc/globals/cilium_policy_00170

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    91214   1052      0        
Allow    Egress      0          ANY          NONE         disabled    15136   160       0        


Endpoint ID: 720
Path: /sys/fs/bpf/tc/globals/cilium_policy_00720

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    91742   1060      0        
Allow    Egress      0          ANY          NONE         disabled    15404   164       0        


Endpoint ID: 2763
Path: /sys/fs/bpf/tc/globals/cilium_policy_02763

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    436127   5578      0        
Allow    Ingress     1          ANY          NONE         disabled    13083    152       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3834
Path: /sys/fs/bpf/tc/globals/cilium_policy_03834

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3850784   36193     0        
Allow    Ingress     1          ANY          NONE         disabled    2827454   28169     0        
Allow    Egress      0          ANY          NONE         disabled    4470759   41315     0        


Endpoint ID: 3986
Path: /sys/fs/bpf/tc/globals/cilium_policy_03986

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


