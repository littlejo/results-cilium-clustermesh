key: 07 00 00 00  value: ac 1f c3 b9 01 bb 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 26 00 64 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ac b7 10 94 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 26 00 f5 23 c1 00 00  00 00 00 00
key: 03 00 00 00  value: 0a 26 00 64 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 26 00 8e 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f a3 8e 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 26 00 f5 00 35 00 00  00 00 00 00
Found 8 elements
