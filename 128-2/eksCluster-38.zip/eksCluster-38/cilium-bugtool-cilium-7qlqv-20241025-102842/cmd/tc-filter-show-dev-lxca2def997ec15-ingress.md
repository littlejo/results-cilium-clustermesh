filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca2def997ec15 direct-action not_in_hw id 490 tag bec9edd7c73fd338 jited 
