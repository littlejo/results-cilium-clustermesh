markdown output at /tmp/cilium-bugtool-20241025-102844.2+0000-UTC-2936253655/cmd/cilium-debuginfo-20241025-102845.184+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102844.2+0000-UTC-2936253655/cmd/cilium-debuginfo-20241025-102845.184+0000-UTC.json
