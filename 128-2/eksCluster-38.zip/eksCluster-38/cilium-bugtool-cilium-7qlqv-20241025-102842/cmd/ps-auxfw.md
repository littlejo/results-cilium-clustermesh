USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         635  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         629  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         611  0.0  0.4 1240432 16376 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         668  0.0  0.0   6408  1636 ?        R    10:28   0:00  \_ ps auxfw
root         671  0.0  0.0   4344  1380 ?        R    10:28   0:00  \_ ip a
root         606  0.0  0.0 1228744 3776 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         600  0.0  0.0 1228744 3604 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  2.9  7.0 1472560 276632 ?      Ssl  10:13   0:26 cilium-agent --config-dir=/tmp/cilium/config-map
root         390  0.0  0.1 1228848 5660 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
