Endpoint ID: 71
Path: /sys/fs/bpf/tc/globals/cilium_policy_00071

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 936
Path: /sys/fs/bpf/tc/globals/cilium_policy_00936

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84146   967       0        
Allow    Egress      0          ANY          NONE         disabled    14038   146       0        


Endpoint ID: 1350
Path: /sys/fs/bpf/tc/globals/cilium_policy_01350

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3267908   32032     0        
Allow    Ingress     1          ANY          NONE         disabled    3279891   33354     0        
Allow    Egress      0          ANY          NONE         disabled    4722909   44731     0        


Endpoint ID: 1989
Path: /sys/fs/bpf/tc/globals/cilium_policy_01989

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83816   962       0        
Allow    Egress      0          ANY          NONE         disabled    14522   152       0        


Endpoint ID: 2297
Path: /sys/fs/bpf/tc/globals/cilium_policy_02297

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    393904   5027      0        
Allow    Ingress     1          ANY          NONE         disabled    11702    135       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


