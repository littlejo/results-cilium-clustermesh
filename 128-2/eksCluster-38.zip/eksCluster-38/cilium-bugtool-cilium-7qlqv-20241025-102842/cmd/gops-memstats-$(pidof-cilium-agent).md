alloc: 128.56MB (134802384 bytes)
total-alloc: 1.33GB (1427635832 bytes)
sys: 206.45MB (216474964 bytes)
lookups: 0
mallocs: 47739407
frees: 46399405
heap-alloc: 128.56MB (134802384 bytes)
heap-sys: 161.10MB (168927232 bytes)
heap-idle: 17.50MB (18350080 bytes)
heap-in-use: 143.60MB (150577152 bytes)
heap-released: 192.00KB (196608 bytes)
heap-objects: 1340002
stack-in-use: 34.88MB (36569088 bytes)
stack-sys: 34.88MB (36569088 bytes)
stack-mspan-inuse: 2.25MB (2358560 bytes)
stack-mspan-sys: 2.52MB (2643840 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 860.39KB (881041 bytes)
gc-sys: 5.19MB (5445792 bytes)
next-gc: when heap-alloc >= 142.87MB (149809768 bytes)
last-gc: 2024-10-25 10:27:43.39159886 +0000 UTC
gc-pause-total: 7.255229ms
gc-pause: 115553
gc-pause-end: 1729852063391598860
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0002970850070736331
enable-gc: true
debug-gc: false
