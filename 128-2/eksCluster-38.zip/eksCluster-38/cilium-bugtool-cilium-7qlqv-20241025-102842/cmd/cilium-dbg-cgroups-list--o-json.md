[
  {
    "containers": [
      {
        "cgroup-id": 8538,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64ee45ad_1bff_400b_b9e0_0eaa52cecf25.slice/cri-containerd-704ec90b9c0c067885a1d9265a6e7a36675142118d03819e1f8a04cd7877f4bb.scope"
      },
      {
        "cgroup-id": 8454,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64ee45ad_1bff_400b_b9e0_0eaa52cecf25.slice/cri-containerd-6e7d09b1c1304c43ca0980632198dc6e7b33aa3dcb307b814c7b90fe888d7d44.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64ee45ad_1bff_400b_b9e0_0eaa52cecf25.slice/cri-containerd-e9507ca436cdc0eb02fc49306cdd42fbe760882fcf488e07ea237ec66dd4ba63.scope"
      }
    ],
    "ips": [
      "10.38.0.142"
    ],
    "name": "clustermesh-apiserver-6b8445b784-q9cbn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10bd00cb_f0f1_4da1_a772_314bc7bba805.slice/cri-containerd-e7fc34f7ef4686d87488f04cfb06f82950a058d57f7b24f227fcb4dacf7efa13.scope"
      }
    ],
    "ips": [
      "10.38.0.100"
    ],
    "name": "coredns-cc6ccd49c-r5trn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7026,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6215023c_b895_4b31_ac01_0c9058d70f26.slice/cri-containerd-289f9fb5812bd59af1f9cf8ccfbf4dbd247b629ff23e1bbccefaec8a4f96134b.scope"
      }
    ],
    "ips": [
      "10.38.0.245"
    ],
    "name": "coredns-cc6ccd49c-p82x8",
    "namespace": "kube-system"
  }
]

