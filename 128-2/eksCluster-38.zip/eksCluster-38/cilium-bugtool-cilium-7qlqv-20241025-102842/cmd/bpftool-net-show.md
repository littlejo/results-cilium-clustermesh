xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 474
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 468
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 461
cilium_host(4) clsact/egress cil_from_host-cilium_host id 460
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 454
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 451
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 505
lxca2def997ec15(9) clsact/ingress cil_from_container-lxca2def997ec15 id 490
lxcae41fdbd1d66(11) clsact/ingress cil_from_container-lxcae41fdbd1d66 id 508
lxc92691c1b7bf9(15) clsact/ingress cil_from_container-lxc92691c1b7bf9 id 581

flow_dissector:

netfilter:

