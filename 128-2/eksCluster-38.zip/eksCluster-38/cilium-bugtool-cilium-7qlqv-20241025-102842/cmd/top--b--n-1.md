top - 10:28:44 up 15 min,  0 users,  load average: 0.24, 0.26, 0.19
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 38.7 us, 35.5 sy,  0.0 ni, 19.4 id,  0.0 wa,  0.0 hi,  6.5 si,  0.0 st
MiB Mem :   3836.2 total,   1018.9 free,    899.0 used,   1918.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2768.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538164 285112  81336 S  60.0   7.3   0:26.60 cilium-+
    611 root      20   0 1240432  16376  11420 S   6.7   0.4   0:00.03 cilium-+
    390 root      20   0 1228848   5660   2740 S   0.0   0.1   0:00.26 cilium-+
    680 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    704 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
