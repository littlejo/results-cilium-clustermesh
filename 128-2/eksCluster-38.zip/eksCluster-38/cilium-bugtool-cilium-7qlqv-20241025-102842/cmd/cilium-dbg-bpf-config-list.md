KEY             VALUE
AgentLiveness   943212424660
UTimeOffset     3378615591796875
