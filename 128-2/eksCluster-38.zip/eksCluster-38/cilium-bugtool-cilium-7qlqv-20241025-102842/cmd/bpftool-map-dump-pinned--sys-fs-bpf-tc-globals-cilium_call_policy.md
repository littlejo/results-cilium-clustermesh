key: a8 03 00 00  value: 00 02 00 00
key: 46 05 00 00  value: 41 02 00 00
key: c5 07 00 00  value: e0 01 00 00
key: f9 08 00 00  value: 05 02 00 00
Found 4 elements
