CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bfd04d5_e559_4ccb_a102_3cb7252b78ae.slice/cri-containerd-4aeb912edb28c4a986834ae4a19d81c9788812fbdd9de3617776d4e37eec629c.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bfd04d5_e559_4ccb_a102_3cb7252b78ae.slice/cri-containerd-f27e793b97f015f6785e937ed43ea6badf0ffaefe20397cd77adef3de137ed55.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10bd00cb_f0f1_4da1_a772_314bc7bba805.slice/cri-containerd-e7fc34f7ef4686d87488f04cfb06f82950a058d57f7b24f227fcb4dacf7efa13.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10bd00cb_f0f1_4da1_a772_314bc7bba805.slice/cri-containerd-f35b61cc6b3b4c5de649497358e404a93f5226572f17ce5820b883c19853bd56.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba0fbb79_e979_421b_bdfc_8677343e1243.slice/cri-containerd-aa0f6335deeded45cfad932f336bac87c084f95162f7502547441c1e444af527.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba0fbb79_e979_421b_bdfc_8677343e1243.slice/cri-containerd-b6991976b15c4456709bdfb3619990018f9d8bf358b7121210bd189581847fe9.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6215023c_b895_4b31_ac01_0c9058d70f26.slice/cri-containerd-8e8f30643264ecb4ca3985de6db6e1b953322c4d741fb4fe8b20160add0118a7.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6215023c_b895_4b31_ac01_0c9058d70f26.slice/cri-containerd-289f9fb5812bd59af1f9cf8ccfbf4dbd247b629ff23e1bbccefaec8a4f96134b.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64ee45ad_1bff_400b_b9e0_0eaa52cecf25.slice/cri-containerd-704ec90b9c0c067885a1d9265a6e7a36675142118d03819e1f8a04cd7877f4bb.scope
    609      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64ee45ad_1bff_400b_b9e0_0eaa52cecf25.slice/cri-containerd-d7f6081297961f8f0f10d21001678dbce5f917d893c12892e54782468cfc1110.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64ee45ad_1bff_400b_b9e0_0eaa52cecf25.slice/cri-containerd-6e7d09b1c1304c43ca0980632198dc6e7b33aa3dcb307b814c7b90fe888d7d44.scope
    605      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64ee45ad_1bff_400b_b9e0_0eaa52cecf25.slice/cri-containerd-e9507ca436cdc0eb02fc49306cdd42fbe760882fcf488e07ea237ec66dd4ba63.scope
    613      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podedd600e5_4f7f_431d_bd35_060f4c6ed51a.slice/cri-containerd-1049987c97613d47f22fdd051dd2cfc855e300c116a7d332cf33ec60e05bff01.scope
    83       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podedd600e5_4f7f_431d_bd35_060f4c6ed51a.slice/cri-containerd-ae9b3bfd682bb4c36c7721d44afc80f6330a7e4489e36c5a275f625da5b3deb8.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod008d4323_c138_4c00_90ed_7195c6784731.slice/cri-containerd-af35ff6897ff0f6af10ca5898e31b2b7cccba125b3831bb756c9a6fa30d1825e.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod008d4323_c138_4c00_90ed_7195c6784731.slice/cri-containerd-a89704685d98904254914814d55ca3ac32089ff0f68a2014342864b25a05e185.scope
    79       cgroup_device   multi                                          
