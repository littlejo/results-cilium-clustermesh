1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c7:1d:00:a1:bf brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.172.183/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2671sec preferred_lft 2671sec
    inet6 fe80::4c7:1dff:fe00:a1bf/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:4e:1c:02:6c:93 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a04e:1cff:fe02:6c93/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:79:c3:19:87:56 brd ff:ff:ff:ff:ff:ff
    inet 10.38.0.205/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e479:c3ff:fe19:8756/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fe:22:c7:f0:77:01 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fc22:c7ff:fef0:7701/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:b5:86:25:06:27 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::24b5:86ff:fe25:627/64 scope link 
       valid_lft forever preferred_lft forever
9: lxca2def997ec15@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:8d:56:3b:5f:79 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2c8d:56ff:fe3b:5f79/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcae41fdbd1d66@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:7d:dd:2b:e0:b2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::6c7d:ddff:fe2b:e0b2/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc92691c1b7bf9@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:4c:17:a7:c7:2a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c04c:17ff:fea7:c72a/64 scope link 
       valid_lft forever preferred_lft forever
