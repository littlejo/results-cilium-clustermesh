 10:28:44 up 15 min,  0 users,  load average: 0.24, 0.26, 0.19
