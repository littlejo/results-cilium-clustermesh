IP ADDRESS         LOCAL ENDPOINT INFO
10.38.0.236:0      id=2297  sec_id=4     flags=0x0000 ifindex=7   mac=3E:8D:64:5B:76:B5 nodemac=26:B5:86:25:06:27     
10.38.0.205:0      (localhost)                                                                                        
10.38.0.100:0      id=1989  sec_id=2567020 flags=0x0000 ifindex=9   mac=3E:29:A6:8C:47:BA nodemac=2E:8D:56:3B:5F:79   
172.31.172.183:0   (localhost)                                                                                        
10.38.0.142:0      id=1350  sec_id=2616627 flags=0x0000 ifindex=15  mac=52:BE:C5:10:16:5D nodemac=C2:4C:17:A7:C7:2A   
10.38.0.245:0      id=936   sec_id=2567020 flags=0x0000 ifindex=11  mac=8A:5A:79:AC:F2:F6 nodemac=6E:7D:DD:2B:E0:B2   
